#!/bin/bash

if [ $# -eq 0 ]
then           
    ARGS=N    
else           
    ARGS=$1
fi             

NOW=$(date +"+%Y-%m-%d_%T")
SHLOG_DIR=/sqoopbin/scripts/etlpgm/cur_log
HISLOG_DIR=/sqoopbin/scripts/etlpgm/his_log

export HADOOP_OPTS=-Djava.security.egd=file:/dev/../dev/urandom
export ORACLE_BASE=/sw/oracle
export ORACLE_HOME=/sw/oracle/product/11.2.0.4/client_1
export LD_LIBRARY_PATH=/sw/oracle/product/11.2.0.4/client_1/lib:/sw/oracle/product/11.2.0.4/client_1/lib:
export PATH=/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/usr/lib64/qt-3.3/bin:/usr/hdp/3.0.0.0-1634/spark2/bin/:/var/opt/node/bin/:/opt/maven/bin:/usr/local/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/home/hdpapp/workspace/data-science-at-the-command-line/tools:/home/hdpapp/.local/bin:/home/hdpapp/bin
export TNS_ADMIN=/sw/oracle/product/11.2.0.4/client_1/network/admin
export ORACLE_SID=DBEDWP2
export NLS_LANG=American_America.KO16MSWIN949

#----------------------------------------------------#
# 작업내용 : THDDH_VPDUNTPD 테이블 sqoop 복제 작업
# 작업주기 :  
#----------------------------------------------------#

    echo " "
    echo "*-----------[ THDDH_VPDUNTPD.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_VPDUNTPD.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`  >  ${SHLOG_DIR}/THDDH_VPDUNTPD.shlog

#----------------------------------------------------#
# 테이블별 전체 데이터를 받아 오는 부분
#----------------------------------------------------#
#    /usr/bin/hadoop fs -rm -r -f  /tmp2/LAST_THDDH_VPDUNTPD  >> ${SHLOG_DIR}/THDDH_VPDUNTPD.shlog 2>&1 &&
#    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.LAST_THDDH_VPDUNTPD ; " >> ${SHLOG_DIR}/THDDH_VPDUNTPD.shlog 2>&1 &&
    /usr/hdp/3.0.0.0-1634/sqoop/bin/sqoop import -D mapred.child.java.opts="-Djava.security.egd=file:/dev/../dev/urandom" \
    --connect jdbc:oracle:thin:EDWHADOOP/wjdqhrP\!23@10.91.41.172:12560:DBEDWP2 \
    --username  EDWHADOOP \
    --password wjdqhrP\!23 \
    --query "SELECT /*+ FULL(THDDH_VPDUNTPD) */ REPLACE(REPLACE(UNT_PD_CD,CHR(13),''),CHR(10),'') UNT_PD_CD
, VF_DT
, VT_DT
, REPLACE(REPLACE(UNT_PD_NM,CHR(13),''),CHR(10),'') UNT_PD_NM
, REPLACE(REPLACE(UNT_PD_ABR_NM,CHR(13),''),CHR(10),'') UNT_PD_ABR_NM
, REPLACE(REPLACE(UNT_PD_ENG_NM,CHR(13),''),CHR(10),'') UNT_PD_ENG_NM
, REPLACE(REPLACE(UNT_PD_ENG_ABR_NM,CHR(13),''),CHR(10),'') UNT_PD_ENG_ABR_NM
, PD_AUTH_DT
, PD_SAL_TMRR_SUSP_DT
, SAL_BGN_DT
, SAL_ED_DT
, REPLACE(REPLACE(INS_BGN_TM,CHR(13),''),CHR(10),'') INS_BGN_TM
, REPLACE(REPLACE(INS_ED_TM,CHR(13),''),CHR(10),'') INS_ED_TM
, REPLACE(REPLACE(RPS_PD_CD,CHR(13),''),CHR(10),'') RPS_PD_CD
, REPLACE(REPLACE(OD_PD_CD,CHR(13),''),CHR(10),'') OD_PD_CD
, REPLACE(REPLACE(INS_ITMS_DIV_CD,CHR(13),''),CHR(10),'') INS_ITMS_DIV_CD
, REPLACE(REPLACE(OD_STIC_PD_CTG_CD,CHR(13),''),CHR(10),'') OD_STIC_PD_CTG_CD
, REPLACE(REPLACE(NW_STIC_PD_CTG_CD,CHR(13),''),CHR(10),'') NW_STIC_PD_CTG_CD
, REPLACE(REPLACE(FAMT_INS_PD_CTG_CD,CHR(13),''),CHR(10),'') FAMT_INS_PD_CTG_CD
, REPLACE(REPLACE(PD_AUTH_TP_CD,CHR(13),''),CHR(10),'') PD_AUTH_TP_CD
, ISP_STD_SCR
, REPLACE(REPLACE(GURT_SAV_DIV_CD,CHR(13),''),CHR(10),'') GURT_SAV_DIV_CD
, REPLACE(REPLACE(SPC_ACCT_DIV_CD,CHR(13),''),CHR(10),'') SPC_ACCT_DIV_CD
, REPLACE(REPLACE(DVND_PAY_YN,CHR(13),''),CHR(10),'') DVND_PAY_YN
, REPLACE(REPLACE(BZCC_JNT_PD_YN,CHR(13),''),CHR(10),'') BZCC_JNT_PD_YN
, REPLACE(REPLACE(FETS_SBC_PSB_YN,CHR(13),''),CHR(10),'') FETS_SBC_PSB_YN
, REPLACE(REPLACE(ACU_GURT_SPR_YN,CHR(13),''),CHR(10),'') ACU_GURT_SPR_YN
, REPLACE(REPLACE(RNWL_COV_BEIN_YN,CHR(13),''),CHR(10),'') RNWL_COV_BEIN_YN
, REPLACE(REPLACE(PREM_CMPT_AGE_STD_CD,CHR(13),''),CHR(10),'') PREM_CMPT_AGE_STD_CD
, REPLACE(REPLACE(HDTL_YN,CHR(13),''),CHR(10),'') HDTL_YN
, REPLACE(REPLACE(ALTN_PY_TRG_DIV_CD,CHR(13),''),CHR(10),'') ALTN_PY_TRG_DIV_CD
, REPLACE(REPLACE(PSTP_REVV_PSB_YN,CHR(13),''),CHR(10),'') PSTP_REVV_PSB_YN
, REPLACE(REPLACE(AYTM_PY_PSB_YN,CHR(13),''),CHR(10),'') AYTM_PY_PSB_YN
, FSS_DAT_OTPT_SEQ
, REPLACE(REPLACE(SAL_PLAN_INCL_YN,CHR(13),''),CHR(10),'') SAL_PLAN_INCL_YN
, REPLACE(REPLACE(PPBZ_FND_CTRB_INST_CD,CHR(13),''),CHR(10),'') PPBZ_FND_CTRB_INST_CD
, PBPF_BZ_FND_CTRB_RT
, REPLACE(REPLACE(APL_PREM_RDDW_UNT_CD,CHR(13),''),CHR(10),'') APL_PREM_RDDW_UNT_CD
, REPLACE(REPLACE(PD_MNDC_ISS_YN,CHR(13),''),CHR(10),'') PD_MNDC_ISS_YN
, REPLACE(REPLACE(ADJT_PSB_YN,CHR(13),''),CHR(10),'') ADJT_PSB_YN
, REPLACE(REPLACE(INDV_CRP_DIV_CD,CHR(13),''),CHR(10),'') INDV_CRP_DIV_CD
, REPLACE(REPLACE(GRUP_TRT_YN,CHR(13),''),CHR(10),'') GRUP_TRT_YN
, REPLACE(REPLACE(SMNS_POL_PSB_YN,CHR(13),''),CHR(10),'') SMNS_POL_PSB_YN
, REPLACE(REPLACE(GIRO_ISS_PSB_YN,CHR(13),''),CHR(10),'') GIRO_ISS_PSB_YN
, REPLACE(REPLACE(PLR_STUP_PSB_YN,CHR(13),''),CHR(10),'') PLR_STUP_PSB_YN
, REPLACE(REPLACE(HNDY_DSG_PSB_YN,CHR(13),''),CHR(10),'') HNDY_DSG_PSB_YN
, REPLACE(REPLACE(CLOG_DPC_INP_YN,CHR(13),''),CHR(10),'') CLOG_DPC_INP_YN
, REPLACE(REPLACE(KORE_PD_CD,CHR(13),''),CHR(10),'') KORE_PD_CD
, REPLACE(REPLACE(CLUS_DIV_CD,CHR(13),''),CHR(10),'') CLUS_DIV_CD
, REPLACE(REPLACE(LGTM_CTR_CR_XTR_MD_CD,CHR(13),''),CHR(10),'') LGTM_CTR_CR_XTR_MD_CD
, REPLACE(REPLACE(IPY_PSB_YN,CHR(13),''),CHR(10),'') IPY_PSB_YN
, REPLACE(REPLACE(SRP_APL_TRG_YN,CHR(13),''),CHR(10),'') SRP_APL_TRG_YN
, REPLACE(REPLACE(INCM_DDC_TRG_YN,CHR(13),''),CHR(10),'') INCM_DDC_TRG_YN
, REPLACE(REPLACE(HSEC_DIV_CD,CHR(13),''),CHR(10),'') HSEC_DIV_CD
, REPLACE(REPLACE(SECT_INS_DIV_CD,CHR(13),''),CHR(10),'') SECT_INS_DIV_CD
, REPLACE(REPLACE(PVCTR_ALLW_YN,CHR(13),''),CHR(10),'') PVCTR_ALLW_YN
, REPLACE(REPLACE(IPY_LPS_PRD_DIV_CD,CHR(13),''),CHR(10),'') IPY_LPS_PRD_DIV_CD
, REPLACE(REPLACE(IPY_PPN_PRD_DIV_CD,CHR(13),''),CHR(10),'') IPY_PPN_PRD_DIV_CD
, REPLACE(REPLACE(NCLAM_BNS_EN,CHR(13),''),CHR(10),'') NCLAM_BNS_EN
, REPLACE(REPLACE(RVW_ITMS_CRSS_PD_YN,CHR(13),''),CHR(10),'') RVW_ITMS_CRSS_PD_YN
, REPLACE(REPLACE(PRPY_PSB_TP_CD,CHR(13),''),CHR(10),'') PRPY_PSB_TP_CD
, REPLACE(REPLACE(LANN_DIV_CD,CHR(13),''),CHR(10),'') LANN_DIV_CD
, REPLACE(REPLACE(PD_GRP_CD,CHR(13),''),CHR(10),'') PD_GRP_CD
, REPLACE(REPLACE(CNCLL_DDC_AMT_SBTR_YN,CHR(13),''),CHR(10),'') CNCLL_DDC_AMT_SBTR_YN
, CNCLL_DDC_YR_NUM
, XPT_INTR
, REPLACE(REPLACE(BNCA_YN,CHR(13),''),CHR(10),'') BNCA_YN
, REPLACE(REPLACE(MID_AMT_PAY_YN,CHR(13),''),CHR(10),'') MID_AMT_PAY_YN
, REPLACE(REPLACE(HFWY_WDR_YN,CHR(13),''),CHR(10),'') HFWY_WDR_YN
, REPLACE(REPLACE(LNK_PD_CD,CHR(13),''),CHR(10),'') LNK_PD_CD
, REPLACE(REPLACE(APL_PD_CD,CHR(13),''),CHR(10),'') APL_PD_CD
, REPLACE(REPLACE(RPT_PD_CD,CHR(13),''),CHR(10),'') RPT_PD_CD
, REPLACE(REPLACE(RPT_PD_NM,CHR(13),''),CHR(10),'') RPT_PD_NM
, REPLACE(REPLACE(RMK_CON,CHR(13),''),CHR(10),'') RMK_CON
, REPLACE(REPLACE(BZPLN_PD_CTG_CD,CHR(13),''),CHR(10),'') BZPLN_PD_CTG_CD
, REPLACE(REPLACE(ITGR_PD_YN,CHR(13),''),CHR(10),'') ITGR_PD_YN
, REPLACE(REPLACE(EXPR_RFD_APL_DIV_CD,CHR(13),''),CHR(10),'') EXPR_RFD_APL_DIV_CD
, REPLACE(REPLACE(SLZ_PD_DIV_CD,CHR(13),''),CHR(10),'') SLZ_PD_DIV_CD
, REPLACE(REPLACE(ANN_DIV_CD,CHR(13),''),CHR(10),'') ANN_DIV_CD
, REPLACE(REPLACE(ANN_CAL_TP_CD,CHR(13),''),CHR(10),'') ANN_CAL_TP_CD
, REPLACE(REPLACE(PRPY_DC_APL_PREM_CD,CHR(13),''),CHR(10),'') PRPY_DC_APL_PREM_CD
, REPLACE(REPLACE(HFWY_WDR_RFD_STD_CON,CHR(13),''),CHR(10),'') HFWY_WDR_RFD_STD_CON
, REPLACE(REPLACE(CI_PD_YN,CHR(13),''),CHR(10),'') CI_PD_YN
, REPLACE(REPLACE(REGPE_NM,CHR(13),''),CHR(10),'') REGPE_NM
, REG_DT
, REPLACE(REPLACE(MME_RPT_PD_CD,CHR(13),''),CHR(10),'') MME_RPT_PD_CD
, REPLACE(REPLACE(MME_RPT_PD_CD_NM,CHR(13),''),CHR(10),'') MME_RPT_PD_CD_NM
, REPLACE(REPLACE(AYTM_PY_LM_AMT_DIV_CD,CHR(13),''),CHR(10),'') AYTM_PY_LM_AMT_DIV_CD
, REPLACE(REPLACE(ICLO_PSB_YN,CHR(13),''),CHR(10),'') ICLO_PSB_YN
, REPLACE(REPLACE(UNT_PD_SAL_NM,CHR(13),''),CHR(10),'') UNT_PD_SAL_NM
, REPLACE(REPLACE(ISP_PD_CTG_CD,CHR(13),''),CHR(10),'') ISP_PD_CTG_CD
, REPLACE(REPLACE(LGTM_INDV_GRUP_DIV_CD,CHR(13),''),CHR(10),'') LGTM_INDV_GRUP_DIV_CD
, REPLACE(REPLACE(KIDI_PD_CD,CHR(13),''),CHR(10),'') KIDI_PD_CD
, REPLACE(REPLACE(PRDY_AMT_PD_GRP_CD,CHR(13),''),CHR(10),'') PRDY_AMT_PD_GRP_CD
, STND_INTR
, REPLACE(REPLACE(MDF_RT_APL_DIV_CD,CHR(13),''),CHR(10),'') MDF_RT_APL_DIV_CD
, REPLACE(REPLACE(INDP_SIC_PD_YN,CHR(13),''),CHR(10),'') INDP_SIC_PD_YN
, REPLACE(REPLACE(CKUP_TRG_PD_YN,CHR(13),''),CHR(10),'') CKUP_TRG_PD_YN
, REPLACE(REPLACE(POL_OTPT_WY_DIV_CD,CHR(13),''),CHR(10),'') POL_OTPT_WY_DIV_CD
, SAL_BGN_DT1
, REPLACE(REPLACE(NW_KIDI_PD_CD,CHR(13),''),CHR(10),'') NW_KIDI_PD_CD
, REPLACE(REPLACE(STIC_IDC_PD_CTG_CD,CHR(13),''),CHR(10),'') STIC_IDC_PD_CTG_CD
, REPLACE(REPLACE(QRCD_ADR,CHR(13),''),CHR(10),'') QRCD_ADR
, AVG_PBAN_INTR
, EIH_LDG_DTM
, REPLACE(REPLACE(NW_FAMT_INS_PD_CTG_CD,CHR(13),''),CHR(10),'') NW_FAMT_INS_PD_CTG_CD
, REPLACE(REPLACE(AT_ALTN_PY_TP_CD,CHR(13),''),CHR(10),'') AT_ALTN_PY_TP_CD
, ICLO_STD_RT
, REPLACE(REPLACE(MFRC_PD_YN,CHR(13),''),CHR(10),'') MFRC_PD_YN
, REPLACE(REPLACE(PY_EXEM_LRG_TOP_YN,CHR(13),''),CHR(10),'') PY_EXEM_LRG_TOP_YN
, SCRN_EXPS_SQ
, REPLACE(REPLACE(SAL_BGN_TM,CHR(13),''),CHR(10),'') SAL_BGN_TM
, REPLACE(REPLACE(ITMGP_CD,CHR(13),''),CHR(10),'') ITMGP_CD
, REPLACE(REPLACE(GRUP_PREM_AGE_STD_CD,CHR(13),''),CHR(10),'') GRUP_PREM_AGE_STD_CD
, REPLACE(REPLACE(PDGP_CD,CHR(13),''),CHR(10),'') PDGP_CD
, REPLACE(REPLACE(INS_ITMS_CD,CHR(13),''),CHR(10),'') INS_ITMS_CD
, REPLACE(REPLACE(LNK_INDP_PD_CD,CHR(13),''),CHR(10),'') LNK_INDP_PD_CD
, REPLACE(REPLACE(MBL_CLUS_ADR,CHR(13),''),CHR(10),'') MBL_CLUS_ADR
, REPLACE(REPLACE(MLTD_OBJ_YN,CHR(13),''),CHR(10),'') MLTD_OBJ_YN FROM THDDH_VPDUNTPD
                       WHERE \$CONDITIONS "\
    --m 1 \
    --target-dir /tmp2/YK_THDDH_VPDUNTPD \
    --hive-import \
    --hive-overwrite \
    --hive-table DEFAULT.YK_THDDH_VPDUNTPD  >> ${SHLOG_DIR}/YK_THDDH_VPDUNTPD.shlog 2>&1 &&

#    --external-table-dir hdfs:///tmp2/temp_tbl/LAST_THDDH_VPDUNTPD \
#----------------------------------------------------#
# Hadoop 원본테이블에 변경분 최종 적용
#----------------------------------------------------#
#    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_VPDUNTPD_TMP ; " >> ${SHLOG_DIR}/THDDH_VPDUNTPD.shlog 2>&1 &&
#   /usr/bin/hive -e "CREATE EXTERNAL TABLE MERITZ.THDDH_VPDUNTPD_TMP STORED AS PARQUET TBLPROPERTIES ('PARQUET.COMPRESS'='SNAPPY') AS
#                                SELECT *
#                                FROM DEFAULT.LAST_THDDH_VPDUNTPD ;" >> ${SHLOG_DIR}/THDDH_VPDUNTPD.shlog 2>&1 &&
#    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.LAST_THDDH_VPDUNTPD ;" >> ${SHLOG_DIR}/THDDH_VPDUNTPD.shlog 2>&1 &&
#    /usr/bin/hdfs dfs -rm -r -f -skipTrash /tmp2/temp_tbl/LAST_THDDH_VPDUNTPD >> ${SHLOG_DIR}/THDDH_VPDUNTPD.shlog 2>&1 &&
#    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_VPDUNTPD ;" >> ${SHLOG_DIR}/THDDH_VPDUNTPD.shlog 2>&1 &&
#    /usr/bin/hive -e "ALTER TABLE MERITZ.THDDH_VPDUNTPD_TMP RENAME TO MERITZ.THDDH_VPDUNTPD ;" >> ${SHLOG_DIR}/THDDH_VPDUNTPD.shlog 2>&1 &&
#    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_VPDUNTPD_TMP ;" >> ${SHLOG_DIR}/THDDH_VPDUNTPD.shlog 2>&1 

if [ $? -ne 0 ]
then             
    echo "*-----------[ THDDH_VPDUNTPD.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/THDDH_VPDUNTPD.shlog"
    echo "*-----------[ THDDH_VPDUNTPD.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/THDDH_VPDUNTPD.shlog"  >>  ${SHLOG_DIR}/YK_THDDH_VPDUNTPD.shlog
    echo "*-----------[ THDDH_VPDUNTPD.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_VPDUNTPD.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/YK_THDDH_VPDUNTPD.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/YK_THDDH_VPDUNTPD.shlog

#    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/THDDH_VPDUNTPD.shlog
#    cp  /sqoopbin/scripts/etlpgm/cur_log/THDDH_VPDUNTPD.shlog /sqoopbin/scripts/etlpgm/his_log/THDDH_VPDUNTPD_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  THDDH_VPDUNTPD.sh cmd command error !! ***
    fi               

    exit -1      

else             
    echo "*-----------[ THDDH_VPDUNTPD.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_VPDUNTPD.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/THDDH_VPDUNTPD.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/YK_THDDH_VPDUNTPD.shlog

#    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/THDDH_VPDUNTPD.shlog
#    cp  /sqoopbin/scripts/etlpgm/cur_log/THDDH_VPDUNTPD.shlog /sqoopbin/scripts/etlpgm/his_log/THDDH_VPDUNTPD_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  THDDH_VPDUNTPD.sh cmd command error !! ***
        exit -1      
    else             
        exit 0       
    fi               
fi               
