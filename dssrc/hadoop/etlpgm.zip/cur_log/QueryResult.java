// ORM class for table 'null'
// WARNING: This class is AUTO-GENERATED. Modify at your own risk.
//
// Debug information:
// Generated date: Mon Apr 26 02:06:21 GMT 2021
// For connector: org.apache.sqoop.manager.OracleManager
import org.apache.hadoop.io.BytesWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.mapred.lib.db.DBWritable;
import org.apache.sqoop.lib.JdbcWritableBridge;
import org.apache.sqoop.lib.DelimiterSet;
import org.apache.sqoop.lib.FieldFormatter;
import org.apache.sqoop.lib.RecordParser;
import org.apache.sqoop.lib.BooleanParser;
import org.apache.sqoop.lib.BlobRef;
import org.apache.sqoop.lib.ClobRef;
import org.apache.sqoop.lib.LargeObjectLoader;
import org.apache.sqoop.lib.SqoopRecord;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.sql.Date;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

public class QueryResult extends SqoopRecord  implements DBWritable, Writable {
  private final int PROTOCOL_VERSION = 3;
  public int getClassFormatVersion() { return PROTOCOL_VERSION; }
  public static interface FieldSetterCommand {    void setField(Object value);  }  protected ResultSet __cur_result_set;
  private Map<String, FieldSetterCommand> setters = new HashMap<String, FieldSetterCommand>();
  private void init0() {
    setters.put("CLOG_YYMM", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.CLOG_YYMM = (String)value;
      }
    });
    setters.put("STD_DT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.STD_DT = (java.sql.Timestamp)value;
      }
    });
    setters.put("CTR_CHNG_STAT_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.CTR_CHNG_STAT_CD = (String)value;
      }
    });
    setters.put("POL_NO", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.POL_NO = (String)value;
      }
    });
    setters.put("COV_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.COV_CD = (String)value;
      }
    });
    setters.put("CTR_COV_ID", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.CTR_COV_ID = (String)value;
      }
    });
    setters.put("ENDR_NO", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.ENDR_NO = (java.math.BigDecimal)value;
      }
    });
    setters.put("UNT_PD_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.UNT_PD_CD = (String)value;
      }
    });
    setters.put("SBCP_YYMM", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.SBCP_YYMM = (String)value;
      }
    });
    setters.put("FEE_PAY_TP_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.FEE_PAY_TP_CD = (String)value;
      }
    });
    setters.put("SBCP_DT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.SBCP_DT = (java.sql.Timestamp)value;
      }
    });
    setters.put("ENDR_DT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.ENDR_DT = (java.sql.Timestamp)value;
      }
    });
    setters.put("DMG_RT_COV_DCTG_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.DMG_RT_COV_DCTG_CD = (String)value;
      }
    });
    setters.put("INS_PRD_TP_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.INS_PRD_TP_CD = (String)value;
      }
    });
    setters.put("INS_PRD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.INS_PRD = (java.math.BigDecimal)value;
      }
    });
    setters.put("PY_PRD_TP_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.PY_PRD_TP_CD = (String)value;
      }
    });
    setters.put("PY_PRD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.PY_PRD = (java.math.BigDecimal)value;
      }
    });
    setters.put("PY_CYC_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.PY_CYC_CD = (String)value;
      }
    });
    setters.put("SBC_AGE", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.SBC_AGE = (java.math.BigDecimal)value;
      }
    });
    setters.put("GNDR_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.GNDR_CD = (String)value;
      }
    });
    setters.put("INJR_GR_NUM", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.INJR_GR_NUM = (java.math.BigDecimal)value;
      }
    });
    setters.put("LAST_PY_YYMM", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.LAST_PY_YYMM = (String)value;
      }
    });
    setters.put("LAST_PY_TMS", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.LAST_PY_TMS = (java.math.BigDecimal)value;
      }
    });
    setters.put("RCRT_HDQT_ORG_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.RCRT_HDQT_ORG_CD = (String)value;
      }
    });
    setters.put("RCRT_BRCH_ORG_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.RCRT_BRCH_ORG_CD = (String)value;
      }
    });
    setters.put("RCRT_BCH_ORG_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.RCRT_BCH_ORG_CD = (String)value;
      }
    });
    setters.put("RCRT_TRTPE_ORG_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.RCRT_TRTPE_ORG_CD = (String)value;
      }
    });
    setters.put("RCRT_AGC_PLNR_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.RCRT_AGC_PLNR_CD = (String)value;
      }
    });
    setters.put("TRT_HDQT_ORG_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.TRT_HDQT_ORG_CD = (String)value;
      }
    });
    setters.put("TRT_BRCH_ORG_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.TRT_BRCH_ORG_CD = (String)value;
      }
    });
    setters.put("TRT_BCH_ORG_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.TRT_BCH_ORG_CD = (String)value;
      }
    });
    setters.put("TRTPE_ORG_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.TRTPE_ORG_CD = (String)value;
      }
    });
    setters.put("AGC_PLNR_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.AGC_PLNR_CD = (String)value;
      }
    });
    setters.put("HDQT_OPPN_DG_CF", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.HDQT_OPPN_DG_CF = (java.math.BigDecimal)value;
      }
    });
    setters.put("SLZ_PREM", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.SLZ_PREM = (java.math.BigDecimal)value;
      }
    });
    setters.put("IRTD_MKVL_AMT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.IRTD_MKVL_AMT = (java.math.BigDecimal)value;
      }
    });
    setters.put("BZEX_MKVL_AMT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.BZEX_MKVL_AMT = (java.math.BigDecimal)value;
      }
    });
    setters.put("RSKEX_MKVL_AMT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.RSKEX_MKVL_AMT = (java.math.BigDecimal)value;
      }
    });
    setters.put("EIH_LDG_DTM", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.EIH_LDG_DTM = (java.sql.Timestamp)value;
      }
    });
    setters.put("RB_EXP_CPR", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.RB_EXP_CPR = (java.math.BigDecimal)value;
      }
    });
    setters.put("RSK_PREM_CPR", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.RSK_PREM_CPR = (java.math.BigDecimal)value;
      }
    });
    setters.put("ORIG_PREM_CPR", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.ORIG_PREM_CPR = (java.math.BigDecimal)value;
      }
    });
    setters.put("MKVL_CPR", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.MKVL_CPR = (java.math.BigDecimal)value;
      }
    });
    setters.put("EXPR_RFD_AMT_CPR", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.EXPR_RFD_AMT_CPR = (java.math.BigDecimal)value;
      }
    });
    setters.put("CLAT_CPR", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.CLAT_CPR = (java.math.BigDecimal)value;
      }
    });
    setters.put("SRVL_BNT_CPR", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.SRVL_BNT_CPR = (java.math.BigDecimal)value;
      }
    });
    setters.put("ANN_PAY_AMT_CPR", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.ANN_PAY_AMT_CPR = (java.math.BigDecimal)value;
      }
    });
    setters.put("PO_ETPY_CPR", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.PO_ETPY_CPR = (java.math.BigDecimal)value;
      }
    });
    setters.put("MNCL_FEE_CPR", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.MNCL_FEE_CPR = (java.math.BigDecimal)value;
      }
    });
    setters.put("SAV_PREM_CPR", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.SAV_PREM_CPR = (java.math.BigDecimal)value;
      }
    });
    setters.put("XACQ_EXP_CPR", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.XACQ_EXP_CPR = (java.math.BigDecimal)value;
      }
    });
    setters.put("XPT_MTN_EXP_CPR", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.XPT_MTN_EXP_CPR = (java.math.BigDecimal)value;
      }
    });
    setters.put("XPT_MNCL_EXP_CPR", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.XPT_MNCL_EXP_CPR = (java.math.BigDecimal)value;
      }
    });
    setters.put("INS_AMT_CPR", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.INS_AMT_CPR = (java.math.BigDecimal)value;
      }
    });
    setters.put("NPTPY_NW_CTR_RSLFE_CPR", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.NPTPY_NW_CTR_RSLFE_CPR = (java.math.BigDecimal)value;
      }
    });
    setters.put("NPTPY_ETC_NPO_CPR", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.NPTPY_ETC_NPO_CPR = (java.math.BigDecimal)value;
      }
    });
    setters.put("TMN_MGI_CPR", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.TMN_MGI_CPR = (java.math.BigDecimal)value;
      }
    });
    setters.put("ACD_ATTM_RDY_AMT_CPR", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.ACD_ATTM_RDY_AMT_CPR = (java.math.BigDecimal)value;
      }
    });
    setters.put("PY_EXEM_PREM_CPR", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.PY_EXEM_PREM_CPR = (java.math.BigDecimal)value;
      }
    });
    setters.put("HFWY_WDR_CPR", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.HFWY_WDR_CPR = (java.math.BigDecimal)value;
      }
    });
    setters.put("TMN_RSK_PREM_CPR", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.TMN_RSK_PREM_CPR = (java.math.BigDecimal)value;
      }
    });
    setters.put("LCAT_PD_CLAT_CPR", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.LCAT_PD_CLAT_CPR = (java.math.BigDecimal)value;
      }
    });
    setters.put("TMN_ATTM_RDY_AMT_CPR", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.TMN_ATTM_RDY_AMT_CPR = (java.math.BigDecimal)value;
      }
    });
    setters.put("DMN15_WTHN_SLZ_PREM", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.DMN15_WTHN_SLZ_PREM = (java.math.BigDecimal)value;
      }
    });
    setters.put("DMN15_TMTD_RDY_AMT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.DMN15_TMTD_RDY_AMT = (java.math.BigDecimal)value;
      }
    });
    setters.put("OWN_CTR_YN", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.OWN_CTR_YN = (String)value;
      }
    });
    setters.put("CTR_CONV_SIC_SBC_YN", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.CTR_CONV_SIC_SBC_YN = (String)value;
      }
    });
    setters.put("SBC_AMT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.SBC_AMT = (java.math.BigDecimal)value;
      }
    });
    setters.put("CRD_FEE_CPR", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.CRD_FEE_CPR = (java.math.BigDecimal)value;
      }
    });
    setters.put("CUS_CNTRB_ERN_AMT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.CUS_CNTRB_ERN_AMT = (java.math.BigDecimal)value;
      }
    });
    setters.put("SUM_FEE_CPR", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.SUM_FEE_CPR = (java.math.BigDecimal)value;
      }
    });
    setters.put("ITRT_RISK_AMT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.ITRT_RISK_AMT = (java.math.BigDecimal)value;
      }
    });
    setters.put("KICS_MKVL_CPR", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.KICS_MKVL_CPR = (java.math.BigDecimal)value;
      }
    });
    setters.put("ITRT_DEPRC_MKVL_CPR", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.ITRT_DEPRC_MKVL_CPR = (java.math.BigDecimal)value;
      }
    });
    setters.put("ITRT_ASCD_MKVL_CPR", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.ITRT_ASCD_MKVL_CPR = (java.math.BigDecimal)value;
      }
    });
    setters.put("CTR_INS_PRD_TP_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.CTR_INS_PRD_TP_CD = (String)value;
      }
    });
    setters.put("MMPY_CNVS_PREM", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.MMPY_CNVS_PREM = (java.math.BigDecimal)value;
      }
    });
    setters.put("PLAN_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.PLAN_CD = (String)value;
      }
    });
    setters.put("COV_UNT_PD_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.COV_UNT_PD_CD = (String)value;
      }
    });
    setters.put("CSS_PREM_CPR", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.CSS_PREM_CPR = (java.math.BigDecimal)value;
      }
    });
    setters.put("CSS_INS_AMT_RFD_CPR", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.CSS_INS_AMT_RFD_CPR = (java.math.BigDecimal)value;
      }
    });
    setters.put("MKVL_BKPM_AMT_CPR", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.MKVL_BKPM_AMT_CPR = (java.math.BigDecimal)value;
      }
    });
    setters.put("CSS_RT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.CSS_RT = (java.math.BigDecimal)value;
      }
    });
    setters.put("CLF_DIV_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.CLF_DIV_CD = (String)value;
      }
    });
    setters.put("INS_SBC_SH_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.INS_SBC_SH_CD = (String)value;
      }
    });
    setters.put("SBC_DSG_FEE_PAY_TP_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.SBC_DSG_FEE_PAY_TP_CD = (String)value;
      }
    });
    setters.put("SBC_DSG_IRTD_MVAT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.SBC_DSG_IRTD_MVAT = (java.math.BigDecimal)value;
      }
    });
    setters.put("SBC_DSG_BZEX_MVAT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.SBC_DSG_BZEX_MVAT = (java.math.BigDecimal)value;
      }
    });
    setters.put("SBC_DSG_RSKEX_MVAT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.SBC_DSG_RSKEX_MVAT = (java.math.BigDecimal)value;
      }
    });
    setters.put("SBC_DSG_RB_EXP_CPR", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.SBC_DSG_RB_EXP_CPR = (java.math.BigDecimal)value;
      }
    });
    setters.put("SBC_DSG_RSK_PREM_CPR", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.SBC_DSG_RSK_PREM_CPR = (java.math.BigDecimal)value;
      }
    });
    setters.put("SBC_DSG_ORIG_PREM_CPR", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.SBC_DSG_ORIG_PREM_CPR = (java.math.BigDecimal)value;
      }
    });
    setters.put("SBC_DSG_MKVL_CPR", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.SBC_DSG_MKVL_CPR = (java.math.BigDecimal)value;
      }
    });
    setters.put("LWRT_TMN_RFD_TP_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.LWRT_TMN_RFD_TP_CD = (String)value;
      }
    });
    setters.put("LGTM_ITMS_DIV_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.LGTM_ITMS_DIV_CD = (String)value;
      }
    });
    setters.put("ADVEXP", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.ADVEXP = (java.math.BigDecimal)value;
      }
    });
    setters.put("TRTPE_TRFR_YN", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.TRTPE_TRFR_YN = (String)value;
      }
    });
    setters.put("DTBT_CTR_YN", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.DTBT_CTR_YN = (String)value;
      }
    });
    setters.put("INSPE_GRDE_VAL", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.INSPE_GRDE_VAL = (String)value;
      }
    });
    setters.put("PY_EXEM_TP_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.PY_EXEM_TP_CD = (String)value;
      }
    });
    setters.put("AMBA_CHN_DIV_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.AMBA_CHN_DIV_CD = (String)value;
      }
    });
    setters.put("PSINS_CRD_ETC_FEE", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.PSINS_CRD_ETC_FEE = (java.math.BigDecimal)value;
      }
    });
    setters.put("PSINS_AT_TRS_ETC_FEE", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.PSINS_AT_TRS_ETC_FEE = (java.math.BigDecimal)value;
      }
    });
    setters.put("PSINS_COMS_ETC_FEE", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.PSINS_COMS_ETC_FEE = (java.math.BigDecimal)value;
      }
    });
    setters.put("LGTM_CHGE_EXP", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.LGTM_CHGE_EXP = (java.math.BigDecimal)value;
      }
    });
    setters.put("LGTM_FIXT_EXP", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.LGTM_FIXT_EXP = (java.math.BigDecimal)value;
      }
    });
    setters.put("PSINS_ATNS_MKVL_AMT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.PSINS_ATNS_MKVL_AMT = (java.math.BigDecimal)value;
      }
    });
  }
  public QueryResult() {
    init0();
  }
  private String CLOG_YYMM;
  public String get_CLOG_YYMM() {
    return CLOG_YYMM;
  }
  public void set_CLOG_YYMM(String CLOG_YYMM) {
    this.CLOG_YYMM = CLOG_YYMM;
  }
  public QueryResult with_CLOG_YYMM(String CLOG_YYMM) {
    this.CLOG_YYMM = CLOG_YYMM;
    return this;
  }
  private java.sql.Timestamp STD_DT;
  public java.sql.Timestamp get_STD_DT() {
    return STD_DT;
  }
  public void set_STD_DT(java.sql.Timestamp STD_DT) {
    this.STD_DT = STD_DT;
  }
  public QueryResult with_STD_DT(java.sql.Timestamp STD_DT) {
    this.STD_DT = STD_DT;
    return this;
  }
  private String CTR_CHNG_STAT_CD;
  public String get_CTR_CHNG_STAT_CD() {
    return CTR_CHNG_STAT_CD;
  }
  public void set_CTR_CHNG_STAT_CD(String CTR_CHNG_STAT_CD) {
    this.CTR_CHNG_STAT_CD = CTR_CHNG_STAT_CD;
  }
  public QueryResult with_CTR_CHNG_STAT_CD(String CTR_CHNG_STAT_CD) {
    this.CTR_CHNG_STAT_CD = CTR_CHNG_STAT_CD;
    return this;
  }
  private String POL_NO;
  public String get_POL_NO() {
    return POL_NO;
  }
  public void set_POL_NO(String POL_NO) {
    this.POL_NO = POL_NO;
  }
  public QueryResult with_POL_NO(String POL_NO) {
    this.POL_NO = POL_NO;
    return this;
  }
  private String COV_CD;
  public String get_COV_CD() {
    return COV_CD;
  }
  public void set_COV_CD(String COV_CD) {
    this.COV_CD = COV_CD;
  }
  public QueryResult with_COV_CD(String COV_CD) {
    this.COV_CD = COV_CD;
    return this;
  }
  private String CTR_COV_ID;
  public String get_CTR_COV_ID() {
    return CTR_COV_ID;
  }
  public void set_CTR_COV_ID(String CTR_COV_ID) {
    this.CTR_COV_ID = CTR_COV_ID;
  }
  public QueryResult with_CTR_COV_ID(String CTR_COV_ID) {
    this.CTR_COV_ID = CTR_COV_ID;
    return this;
  }
  private java.math.BigDecimal ENDR_NO;
  public java.math.BigDecimal get_ENDR_NO() {
    return ENDR_NO;
  }
  public void set_ENDR_NO(java.math.BigDecimal ENDR_NO) {
    this.ENDR_NO = ENDR_NO;
  }
  public QueryResult with_ENDR_NO(java.math.BigDecimal ENDR_NO) {
    this.ENDR_NO = ENDR_NO;
    return this;
  }
  private String UNT_PD_CD;
  public String get_UNT_PD_CD() {
    return UNT_PD_CD;
  }
  public void set_UNT_PD_CD(String UNT_PD_CD) {
    this.UNT_PD_CD = UNT_PD_CD;
  }
  public QueryResult with_UNT_PD_CD(String UNT_PD_CD) {
    this.UNT_PD_CD = UNT_PD_CD;
    return this;
  }
  private String SBCP_YYMM;
  public String get_SBCP_YYMM() {
    return SBCP_YYMM;
  }
  public void set_SBCP_YYMM(String SBCP_YYMM) {
    this.SBCP_YYMM = SBCP_YYMM;
  }
  public QueryResult with_SBCP_YYMM(String SBCP_YYMM) {
    this.SBCP_YYMM = SBCP_YYMM;
    return this;
  }
  private String FEE_PAY_TP_CD;
  public String get_FEE_PAY_TP_CD() {
    return FEE_PAY_TP_CD;
  }
  public void set_FEE_PAY_TP_CD(String FEE_PAY_TP_CD) {
    this.FEE_PAY_TP_CD = FEE_PAY_TP_CD;
  }
  public QueryResult with_FEE_PAY_TP_CD(String FEE_PAY_TP_CD) {
    this.FEE_PAY_TP_CD = FEE_PAY_TP_CD;
    return this;
  }
  private java.sql.Timestamp SBCP_DT;
  public java.sql.Timestamp get_SBCP_DT() {
    return SBCP_DT;
  }
  public void set_SBCP_DT(java.sql.Timestamp SBCP_DT) {
    this.SBCP_DT = SBCP_DT;
  }
  public QueryResult with_SBCP_DT(java.sql.Timestamp SBCP_DT) {
    this.SBCP_DT = SBCP_DT;
    return this;
  }
  private java.sql.Timestamp ENDR_DT;
  public java.sql.Timestamp get_ENDR_DT() {
    return ENDR_DT;
  }
  public void set_ENDR_DT(java.sql.Timestamp ENDR_DT) {
    this.ENDR_DT = ENDR_DT;
  }
  public QueryResult with_ENDR_DT(java.sql.Timestamp ENDR_DT) {
    this.ENDR_DT = ENDR_DT;
    return this;
  }
  private String DMG_RT_COV_DCTG_CD;
  public String get_DMG_RT_COV_DCTG_CD() {
    return DMG_RT_COV_DCTG_CD;
  }
  public void set_DMG_RT_COV_DCTG_CD(String DMG_RT_COV_DCTG_CD) {
    this.DMG_RT_COV_DCTG_CD = DMG_RT_COV_DCTG_CD;
  }
  public QueryResult with_DMG_RT_COV_DCTG_CD(String DMG_RT_COV_DCTG_CD) {
    this.DMG_RT_COV_DCTG_CD = DMG_RT_COV_DCTG_CD;
    return this;
  }
  private String INS_PRD_TP_CD;
  public String get_INS_PRD_TP_CD() {
    return INS_PRD_TP_CD;
  }
  public void set_INS_PRD_TP_CD(String INS_PRD_TP_CD) {
    this.INS_PRD_TP_CD = INS_PRD_TP_CD;
  }
  public QueryResult with_INS_PRD_TP_CD(String INS_PRD_TP_CD) {
    this.INS_PRD_TP_CD = INS_PRD_TP_CD;
    return this;
  }
  private java.math.BigDecimal INS_PRD;
  public java.math.BigDecimal get_INS_PRD() {
    return INS_PRD;
  }
  public void set_INS_PRD(java.math.BigDecimal INS_PRD) {
    this.INS_PRD = INS_PRD;
  }
  public QueryResult with_INS_PRD(java.math.BigDecimal INS_PRD) {
    this.INS_PRD = INS_PRD;
    return this;
  }
  private String PY_PRD_TP_CD;
  public String get_PY_PRD_TP_CD() {
    return PY_PRD_TP_CD;
  }
  public void set_PY_PRD_TP_CD(String PY_PRD_TP_CD) {
    this.PY_PRD_TP_CD = PY_PRD_TP_CD;
  }
  public QueryResult with_PY_PRD_TP_CD(String PY_PRD_TP_CD) {
    this.PY_PRD_TP_CD = PY_PRD_TP_CD;
    return this;
  }
  private java.math.BigDecimal PY_PRD;
  public java.math.BigDecimal get_PY_PRD() {
    return PY_PRD;
  }
  public void set_PY_PRD(java.math.BigDecimal PY_PRD) {
    this.PY_PRD = PY_PRD;
  }
  public QueryResult with_PY_PRD(java.math.BigDecimal PY_PRD) {
    this.PY_PRD = PY_PRD;
    return this;
  }
  private String PY_CYC_CD;
  public String get_PY_CYC_CD() {
    return PY_CYC_CD;
  }
  public void set_PY_CYC_CD(String PY_CYC_CD) {
    this.PY_CYC_CD = PY_CYC_CD;
  }
  public QueryResult with_PY_CYC_CD(String PY_CYC_CD) {
    this.PY_CYC_CD = PY_CYC_CD;
    return this;
  }
  private java.math.BigDecimal SBC_AGE;
  public java.math.BigDecimal get_SBC_AGE() {
    return SBC_AGE;
  }
  public void set_SBC_AGE(java.math.BigDecimal SBC_AGE) {
    this.SBC_AGE = SBC_AGE;
  }
  public QueryResult with_SBC_AGE(java.math.BigDecimal SBC_AGE) {
    this.SBC_AGE = SBC_AGE;
    return this;
  }
  private String GNDR_CD;
  public String get_GNDR_CD() {
    return GNDR_CD;
  }
  public void set_GNDR_CD(String GNDR_CD) {
    this.GNDR_CD = GNDR_CD;
  }
  public QueryResult with_GNDR_CD(String GNDR_CD) {
    this.GNDR_CD = GNDR_CD;
    return this;
  }
  private java.math.BigDecimal INJR_GR_NUM;
  public java.math.BigDecimal get_INJR_GR_NUM() {
    return INJR_GR_NUM;
  }
  public void set_INJR_GR_NUM(java.math.BigDecimal INJR_GR_NUM) {
    this.INJR_GR_NUM = INJR_GR_NUM;
  }
  public QueryResult with_INJR_GR_NUM(java.math.BigDecimal INJR_GR_NUM) {
    this.INJR_GR_NUM = INJR_GR_NUM;
    return this;
  }
  private String LAST_PY_YYMM;
  public String get_LAST_PY_YYMM() {
    return LAST_PY_YYMM;
  }
  public void set_LAST_PY_YYMM(String LAST_PY_YYMM) {
    this.LAST_PY_YYMM = LAST_PY_YYMM;
  }
  public QueryResult with_LAST_PY_YYMM(String LAST_PY_YYMM) {
    this.LAST_PY_YYMM = LAST_PY_YYMM;
    return this;
  }
  private java.math.BigDecimal LAST_PY_TMS;
  public java.math.BigDecimal get_LAST_PY_TMS() {
    return LAST_PY_TMS;
  }
  public void set_LAST_PY_TMS(java.math.BigDecimal LAST_PY_TMS) {
    this.LAST_PY_TMS = LAST_PY_TMS;
  }
  public QueryResult with_LAST_PY_TMS(java.math.BigDecimal LAST_PY_TMS) {
    this.LAST_PY_TMS = LAST_PY_TMS;
    return this;
  }
  private String RCRT_HDQT_ORG_CD;
  public String get_RCRT_HDQT_ORG_CD() {
    return RCRT_HDQT_ORG_CD;
  }
  public void set_RCRT_HDQT_ORG_CD(String RCRT_HDQT_ORG_CD) {
    this.RCRT_HDQT_ORG_CD = RCRT_HDQT_ORG_CD;
  }
  public QueryResult with_RCRT_HDQT_ORG_CD(String RCRT_HDQT_ORG_CD) {
    this.RCRT_HDQT_ORG_CD = RCRT_HDQT_ORG_CD;
    return this;
  }
  private String RCRT_BRCH_ORG_CD;
  public String get_RCRT_BRCH_ORG_CD() {
    return RCRT_BRCH_ORG_CD;
  }
  public void set_RCRT_BRCH_ORG_CD(String RCRT_BRCH_ORG_CD) {
    this.RCRT_BRCH_ORG_CD = RCRT_BRCH_ORG_CD;
  }
  public QueryResult with_RCRT_BRCH_ORG_CD(String RCRT_BRCH_ORG_CD) {
    this.RCRT_BRCH_ORG_CD = RCRT_BRCH_ORG_CD;
    return this;
  }
  private String RCRT_BCH_ORG_CD;
  public String get_RCRT_BCH_ORG_CD() {
    return RCRT_BCH_ORG_CD;
  }
  public void set_RCRT_BCH_ORG_CD(String RCRT_BCH_ORG_CD) {
    this.RCRT_BCH_ORG_CD = RCRT_BCH_ORG_CD;
  }
  public QueryResult with_RCRT_BCH_ORG_CD(String RCRT_BCH_ORG_CD) {
    this.RCRT_BCH_ORG_CD = RCRT_BCH_ORG_CD;
    return this;
  }
  private String RCRT_TRTPE_ORG_CD;
  public String get_RCRT_TRTPE_ORG_CD() {
    return RCRT_TRTPE_ORG_CD;
  }
  public void set_RCRT_TRTPE_ORG_CD(String RCRT_TRTPE_ORG_CD) {
    this.RCRT_TRTPE_ORG_CD = RCRT_TRTPE_ORG_CD;
  }
  public QueryResult with_RCRT_TRTPE_ORG_CD(String RCRT_TRTPE_ORG_CD) {
    this.RCRT_TRTPE_ORG_CD = RCRT_TRTPE_ORG_CD;
    return this;
  }
  private String RCRT_AGC_PLNR_CD;
  public String get_RCRT_AGC_PLNR_CD() {
    return RCRT_AGC_PLNR_CD;
  }
  public void set_RCRT_AGC_PLNR_CD(String RCRT_AGC_PLNR_CD) {
    this.RCRT_AGC_PLNR_CD = RCRT_AGC_PLNR_CD;
  }
  public QueryResult with_RCRT_AGC_PLNR_CD(String RCRT_AGC_PLNR_CD) {
    this.RCRT_AGC_PLNR_CD = RCRT_AGC_PLNR_CD;
    return this;
  }
  private String TRT_HDQT_ORG_CD;
  public String get_TRT_HDQT_ORG_CD() {
    return TRT_HDQT_ORG_CD;
  }
  public void set_TRT_HDQT_ORG_CD(String TRT_HDQT_ORG_CD) {
    this.TRT_HDQT_ORG_CD = TRT_HDQT_ORG_CD;
  }
  public QueryResult with_TRT_HDQT_ORG_CD(String TRT_HDQT_ORG_CD) {
    this.TRT_HDQT_ORG_CD = TRT_HDQT_ORG_CD;
    return this;
  }
  private String TRT_BRCH_ORG_CD;
  public String get_TRT_BRCH_ORG_CD() {
    return TRT_BRCH_ORG_CD;
  }
  public void set_TRT_BRCH_ORG_CD(String TRT_BRCH_ORG_CD) {
    this.TRT_BRCH_ORG_CD = TRT_BRCH_ORG_CD;
  }
  public QueryResult with_TRT_BRCH_ORG_CD(String TRT_BRCH_ORG_CD) {
    this.TRT_BRCH_ORG_CD = TRT_BRCH_ORG_CD;
    return this;
  }
  private String TRT_BCH_ORG_CD;
  public String get_TRT_BCH_ORG_CD() {
    return TRT_BCH_ORG_CD;
  }
  public void set_TRT_BCH_ORG_CD(String TRT_BCH_ORG_CD) {
    this.TRT_BCH_ORG_CD = TRT_BCH_ORG_CD;
  }
  public QueryResult with_TRT_BCH_ORG_CD(String TRT_BCH_ORG_CD) {
    this.TRT_BCH_ORG_CD = TRT_BCH_ORG_CD;
    return this;
  }
  private String TRTPE_ORG_CD;
  public String get_TRTPE_ORG_CD() {
    return TRTPE_ORG_CD;
  }
  public void set_TRTPE_ORG_CD(String TRTPE_ORG_CD) {
    this.TRTPE_ORG_CD = TRTPE_ORG_CD;
  }
  public QueryResult with_TRTPE_ORG_CD(String TRTPE_ORG_CD) {
    this.TRTPE_ORG_CD = TRTPE_ORG_CD;
    return this;
  }
  private String AGC_PLNR_CD;
  public String get_AGC_PLNR_CD() {
    return AGC_PLNR_CD;
  }
  public void set_AGC_PLNR_CD(String AGC_PLNR_CD) {
    this.AGC_PLNR_CD = AGC_PLNR_CD;
  }
  public QueryResult with_AGC_PLNR_CD(String AGC_PLNR_CD) {
    this.AGC_PLNR_CD = AGC_PLNR_CD;
    return this;
  }
  private java.math.BigDecimal HDQT_OPPN_DG_CF;
  public java.math.BigDecimal get_HDQT_OPPN_DG_CF() {
    return HDQT_OPPN_DG_CF;
  }
  public void set_HDQT_OPPN_DG_CF(java.math.BigDecimal HDQT_OPPN_DG_CF) {
    this.HDQT_OPPN_DG_CF = HDQT_OPPN_DG_CF;
  }
  public QueryResult with_HDQT_OPPN_DG_CF(java.math.BigDecimal HDQT_OPPN_DG_CF) {
    this.HDQT_OPPN_DG_CF = HDQT_OPPN_DG_CF;
    return this;
  }
  private java.math.BigDecimal SLZ_PREM;
  public java.math.BigDecimal get_SLZ_PREM() {
    return SLZ_PREM;
  }
  public void set_SLZ_PREM(java.math.BigDecimal SLZ_PREM) {
    this.SLZ_PREM = SLZ_PREM;
  }
  public QueryResult with_SLZ_PREM(java.math.BigDecimal SLZ_PREM) {
    this.SLZ_PREM = SLZ_PREM;
    return this;
  }
  private java.math.BigDecimal IRTD_MKVL_AMT;
  public java.math.BigDecimal get_IRTD_MKVL_AMT() {
    return IRTD_MKVL_AMT;
  }
  public void set_IRTD_MKVL_AMT(java.math.BigDecimal IRTD_MKVL_AMT) {
    this.IRTD_MKVL_AMT = IRTD_MKVL_AMT;
  }
  public QueryResult with_IRTD_MKVL_AMT(java.math.BigDecimal IRTD_MKVL_AMT) {
    this.IRTD_MKVL_AMT = IRTD_MKVL_AMT;
    return this;
  }
  private java.math.BigDecimal BZEX_MKVL_AMT;
  public java.math.BigDecimal get_BZEX_MKVL_AMT() {
    return BZEX_MKVL_AMT;
  }
  public void set_BZEX_MKVL_AMT(java.math.BigDecimal BZEX_MKVL_AMT) {
    this.BZEX_MKVL_AMT = BZEX_MKVL_AMT;
  }
  public QueryResult with_BZEX_MKVL_AMT(java.math.BigDecimal BZEX_MKVL_AMT) {
    this.BZEX_MKVL_AMT = BZEX_MKVL_AMT;
    return this;
  }
  private java.math.BigDecimal RSKEX_MKVL_AMT;
  public java.math.BigDecimal get_RSKEX_MKVL_AMT() {
    return RSKEX_MKVL_AMT;
  }
  public void set_RSKEX_MKVL_AMT(java.math.BigDecimal RSKEX_MKVL_AMT) {
    this.RSKEX_MKVL_AMT = RSKEX_MKVL_AMT;
  }
  public QueryResult with_RSKEX_MKVL_AMT(java.math.BigDecimal RSKEX_MKVL_AMT) {
    this.RSKEX_MKVL_AMT = RSKEX_MKVL_AMT;
    return this;
  }
  private java.sql.Timestamp EIH_LDG_DTM;
  public java.sql.Timestamp get_EIH_LDG_DTM() {
    return EIH_LDG_DTM;
  }
  public void set_EIH_LDG_DTM(java.sql.Timestamp EIH_LDG_DTM) {
    this.EIH_LDG_DTM = EIH_LDG_DTM;
  }
  public QueryResult with_EIH_LDG_DTM(java.sql.Timestamp EIH_LDG_DTM) {
    this.EIH_LDG_DTM = EIH_LDG_DTM;
    return this;
  }
  private java.math.BigDecimal RB_EXP_CPR;
  public java.math.BigDecimal get_RB_EXP_CPR() {
    return RB_EXP_CPR;
  }
  public void set_RB_EXP_CPR(java.math.BigDecimal RB_EXP_CPR) {
    this.RB_EXP_CPR = RB_EXP_CPR;
  }
  public QueryResult with_RB_EXP_CPR(java.math.BigDecimal RB_EXP_CPR) {
    this.RB_EXP_CPR = RB_EXP_CPR;
    return this;
  }
  private java.math.BigDecimal RSK_PREM_CPR;
  public java.math.BigDecimal get_RSK_PREM_CPR() {
    return RSK_PREM_CPR;
  }
  public void set_RSK_PREM_CPR(java.math.BigDecimal RSK_PREM_CPR) {
    this.RSK_PREM_CPR = RSK_PREM_CPR;
  }
  public QueryResult with_RSK_PREM_CPR(java.math.BigDecimal RSK_PREM_CPR) {
    this.RSK_PREM_CPR = RSK_PREM_CPR;
    return this;
  }
  private java.math.BigDecimal ORIG_PREM_CPR;
  public java.math.BigDecimal get_ORIG_PREM_CPR() {
    return ORIG_PREM_CPR;
  }
  public void set_ORIG_PREM_CPR(java.math.BigDecimal ORIG_PREM_CPR) {
    this.ORIG_PREM_CPR = ORIG_PREM_CPR;
  }
  public QueryResult with_ORIG_PREM_CPR(java.math.BigDecimal ORIG_PREM_CPR) {
    this.ORIG_PREM_CPR = ORIG_PREM_CPR;
    return this;
  }
  private java.math.BigDecimal MKVL_CPR;
  public java.math.BigDecimal get_MKVL_CPR() {
    return MKVL_CPR;
  }
  public void set_MKVL_CPR(java.math.BigDecimal MKVL_CPR) {
    this.MKVL_CPR = MKVL_CPR;
  }
  public QueryResult with_MKVL_CPR(java.math.BigDecimal MKVL_CPR) {
    this.MKVL_CPR = MKVL_CPR;
    return this;
  }
  private java.math.BigDecimal EXPR_RFD_AMT_CPR;
  public java.math.BigDecimal get_EXPR_RFD_AMT_CPR() {
    return EXPR_RFD_AMT_CPR;
  }
  public void set_EXPR_RFD_AMT_CPR(java.math.BigDecimal EXPR_RFD_AMT_CPR) {
    this.EXPR_RFD_AMT_CPR = EXPR_RFD_AMT_CPR;
  }
  public QueryResult with_EXPR_RFD_AMT_CPR(java.math.BigDecimal EXPR_RFD_AMT_CPR) {
    this.EXPR_RFD_AMT_CPR = EXPR_RFD_AMT_CPR;
    return this;
  }
  private java.math.BigDecimal CLAT_CPR;
  public java.math.BigDecimal get_CLAT_CPR() {
    return CLAT_CPR;
  }
  public void set_CLAT_CPR(java.math.BigDecimal CLAT_CPR) {
    this.CLAT_CPR = CLAT_CPR;
  }
  public QueryResult with_CLAT_CPR(java.math.BigDecimal CLAT_CPR) {
    this.CLAT_CPR = CLAT_CPR;
    return this;
  }
  private java.math.BigDecimal SRVL_BNT_CPR;
  public java.math.BigDecimal get_SRVL_BNT_CPR() {
    return SRVL_BNT_CPR;
  }
  public void set_SRVL_BNT_CPR(java.math.BigDecimal SRVL_BNT_CPR) {
    this.SRVL_BNT_CPR = SRVL_BNT_CPR;
  }
  public QueryResult with_SRVL_BNT_CPR(java.math.BigDecimal SRVL_BNT_CPR) {
    this.SRVL_BNT_CPR = SRVL_BNT_CPR;
    return this;
  }
  private java.math.BigDecimal ANN_PAY_AMT_CPR;
  public java.math.BigDecimal get_ANN_PAY_AMT_CPR() {
    return ANN_PAY_AMT_CPR;
  }
  public void set_ANN_PAY_AMT_CPR(java.math.BigDecimal ANN_PAY_AMT_CPR) {
    this.ANN_PAY_AMT_CPR = ANN_PAY_AMT_CPR;
  }
  public QueryResult with_ANN_PAY_AMT_CPR(java.math.BigDecimal ANN_PAY_AMT_CPR) {
    this.ANN_PAY_AMT_CPR = ANN_PAY_AMT_CPR;
    return this;
  }
  private java.math.BigDecimal PO_ETPY_CPR;
  public java.math.BigDecimal get_PO_ETPY_CPR() {
    return PO_ETPY_CPR;
  }
  public void set_PO_ETPY_CPR(java.math.BigDecimal PO_ETPY_CPR) {
    this.PO_ETPY_CPR = PO_ETPY_CPR;
  }
  public QueryResult with_PO_ETPY_CPR(java.math.BigDecimal PO_ETPY_CPR) {
    this.PO_ETPY_CPR = PO_ETPY_CPR;
    return this;
  }
  private java.math.BigDecimal MNCL_FEE_CPR;
  public java.math.BigDecimal get_MNCL_FEE_CPR() {
    return MNCL_FEE_CPR;
  }
  public void set_MNCL_FEE_CPR(java.math.BigDecimal MNCL_FEE_CPR) {
    this.MNCL_FEE_CPR = MNCL_FEE_CPR;
  }
  public QueryResult with_MNCL_FEE_CPR(java.math.BigDecimal MNCL_FEE_CPR) {
    this.MNCL_FEE_CPR = MNCL_FEE_CPR;
    return this;
  }
  private java.math.BigDecimal SAV_PREM_CPR;
  public java.math.BigDecimal get_SAV_PREM_CPR() {
    return SAV_PREM_CPR;
  }
  public void set_SAV_PREM_CPR(java.math.BigDecimal SAV_PREM_CPR) {
    this.SAV_PREM_CPR = SAV_PREM_CPR;
  }
  public QueryResult with_SAV_PREM_CPR(java.math.BigDecimal SAV_PREM_CPR) {
    this.SAV_PREM_CPR = SAV_PREM_CPR;
    return this;
  }
  private java.math.BigDecimal XACQ_EXP_CPR;
  public java.math.BigDecimal get_XACQ_EXP_CPR() {
    return XACQ_EXP_CPR;
  }
  public void set_XACQ_EXP_CPR(java.math.BigDecimal XACQ_EXP_CPR) {
    this.XACQ_EXP_CPR = XACQ_EXP_CPR;
  }
  public QueryResult with_XACQ_EXP_CPR(java.math.BigDecimal XACQ_EXP_CPR) {
    this.XACQ_EXP_CPR = XACQ_EXP_CPR;
    return this;
  }
  private java.math.BigDecimal XPT_MTN_EXP_CPR;
  public java.math.BigDecimal get_XPT_MTN_EXP_CPR() {
    return XPT_MTN_EXP_CPR;
  }
  public void set_XPT_MTN_EXP_CPR(java.math.BigDecimal XPT_MTN_EXP_CPR) {
    this.XPT_MTN_EXP_CPR = XPT_MTN_EXP_CPR;
  }
  public QueryResult with_XPT_MTN_EXP_CPR(java.math.BigDecimal XPT_MTN_EXP_CPR) {
    this.XPT_MTN_EXP_CPR = XPT_MTN_EXP_CPR;
    return this;
  }
  private java.math.BigDecimal XPT_MNCL_EXP_CPR;
  public java.math.BigDecimal get_XPT_MNCL_EXP_CPR() {
    return XPT_MNCL_EXP_CPR;
  }
  public void set_XPT_MNCL_EXP_CPR(java.math.BigDecimal XPT_MNCL_EXP_CPR) {
    this.XPT_MNCL_EXP_CPR = XPT_MNCL_EXP_CPR;
  }
  public QueryResult with_XPT_MNCL_EXP_CPR(java.math.BigDecimal XPT_MNCL_EXP_CPR) {
    this.XPT_MNCL_EXP_CPR = XPT_MNCL_EXP_CPR;
    return this;
  }
  private java.math.BigDecimal INS_AMT_CPR;
  public java.math.BigDecimal get_INS_AMT_CPR() {
    return INS_AMT_CPR;
  }
  public void set_INS_AMT_CPR(java.math.BigDecimal INS_AMT_CPR) {
    this.INS_AMT_CPR = INS_AMT_CPR;
  }
  public QueryResult with_INS_AMT_CPR(java.math.BigDecimal INS_AMT_CPR) {
    this.INS_AMT_CPR = INS_AMT_CPR;
    return this;
  }
  private java.math.BigDecimal NPTPY_NW_CTR_RSLFE_CPR;
  public java.math.BigDecimal get_NPTPY_NW_CTR_RSLFE_CPR() {
    return NPTPY_NW_CTR_RSLFE_CPR;
  }
  public void set_NPTPY_NW_CTR_RSLFE_CPR(java.math.BigDecimal NPTPY_NW_CTR_RSLFE_CPR) {
    this.NPTPY_NW_CTR_RSLFE_CPR = NPTPY_NW_CTR_RSLFE_CPR;
  }
  public QueryResult with_NPTPY_NW_CTR_RSLFE_CPR(java.math.BigDecimal NPTPY_NW_CTR_RSLFE_CPR) {
    this.NPTPY_NW_CTR_RSLFE_CPR = NPTPY_NW_CTR_RSLFE_CPR;
    return this;
  }
  private java.math.BigDecimal NPTPY_ETC_NPO_CPR;
  public java.math.BigDecimal get_NPTPY_ETC_NPO_CPR() {
    return NPTPY_ETC_NPO_CPR;
  }
  public void set_NPTPY_ETC_NPO_CPR(java.math.BigDecimal NPTPY_ETC_NPO_CPR) {
    this.NPTPY_ETC_NPO_CPR = NPTPY_ETC_NPO_CPR;
  }
  public QueryResult with_NPTPY_ETC_NPO_CPR(java.math.BigDecimal NPTPY_ETC_NPO_CPR) {
    this.NPTPY_ETC_NPO_CPR = NPTPY_ETC_NPO_CPR;
    return this;
  }
  private java.math.BigDecimal TMN_MGI_CPR;
  public java.math.BigDecimal get_TMN_MGI_CPR() {
    return TMN_MGI_CPR;
  }
  public void set_TMN_MGI_CPR(java.math.BigDecimal TMN_MGI_CPR) {
    this.TMN_MGI_CPR = TMN_MGI_CPR;
  }
  public QueryResult with_TMN_MGI_CPR(java.math.BigDecimal TMN_MGI_CPR) {
    this.TMN_MGI_CPR = TMN_MGI_CPR;
    return this;
  }
  private java.math.BigDecimal ACD_ATTM_RDY_AMT_CPR;
  public java.math.BigDecimal get_ACD_ATTM_RDY_AMT_CPR() {
    return ACD_ATTM_RDY_AMT_CPR;
  }
  public void set_ACD_ATTM_RDY_AMT_CPR(java.math.BigDecimal ACD_ATTM_RDY_AMT_CPR) {
    this.ACD_ATTM_RDY_AMT_CPR = ACD_ATTM_RDY_AMT_CPR;
  }
  public QueryResult with_ACD_ATTM_RDY_AMT_CPR(java.math.BigDecimal ACD_ATTM_RDY_AMT_CPR) {
    this.ACD_ATTM_RDY_AMT_CPR = ACD_ATTM_RDY_AMT_CPR;
    return this;
  }
  private java.math.BigDecimal PY_EXEM_PREM_CPR;
  public java.math.BigDecimal get_PY_EXEM_PREM_CPR() {
    return PY_EXEM_PREM_CPR;
  }
  public void set_PY_EXEM_PREM_CPR(java.math.BigDecimal PY_EXEM_PREM_CPR) {
    this.PY_EXEM_PREM_CPR = PY_EXEM_PREM_CPR;
  }
  public QueryResult with_PY_EXEM_PREM_CPR(java.math.BigDecimal PY_EXEM_PREM_CPR) {
    this.PY_EXEM_PREM_CPR = PY_EXEM_PREM_CPR;
    return this;
  }
  private java.math.BigDecimal HFWY_WDR_CPR;
  public java.math.BigDecimal get_HFWY_WDR_CPR() {
    return HFWY_WDR_CPR;
  }
  public void set_HFWY_WDR_CPR(java.math.BigDecimal HFWY_WDR_CPR) {
    this.HFWY_WDR_CPR = HFWY_WDR_CPR;
  }
  public QueryResult with_HFWY_WDR_CPR(java.math.BigDecimal HFWY_WDR_CPR) {
    this.HFWY_WDR_CPR = HFWY_WDR_CPR;
    return this;
  }
  private java.math.BigDecimal TMN_RSK_PREM_CPR;
  public java.math.BigDecimal get_TMN_RSK_PREM_CPR() {
    return TMN_RSK_PREM_CPR;
  }
  public void set_TMN_RSK_PREM_CPR(java.math.BigDecimal TMN_RSK_PREM_CPR) {
    this.TMN_RSK_PREM_CPR = TMN_RSK_PREM_CPR;
  }
  public QueryResult with_TMN_RSK_PREM_CPR(java.math.BigDecimal TMN_RSK_PREM_CPR) {
    this.TMN_RSK_PREM_CPR = TMN_RSK_PREM_CPR;
    return this;
  }
  private java.math.BigDecimal LCAT_PD_CLAT_CPR;
  public java.math.BigDecimal get_LCAT_PD_CLAT_CPR() {
    return LCAT_PD_CLAT_CPR;
  }
  public void set_LCAT_PD_CLAT_CPR(java.math.BigDecimal LCAT_PD_CLAT_CPR) {
    this.LCAT_PD_CLAT_CPR = LCAT_PD_CLAT_CPR;
  }
  public QueryResult with_LCAT_PD_CLAT_CPR(java.math.BigDecimal LCAT_PD_CLAT_CPR) {
    this.LCAT_PD_CLAT_CPR = LCAT_PD_CLAT_CPR;
    return this;
  }
  private java.math.BigDecimal TMN_ATTM_RDY_AMT_CPR;
  public java.math.BigDecimal get_TMN_ATTM_RDY_AMT_CPR() {
    return TMN_ATTM_RDY_AMT_CPR;
  }
  public void set_TMN_ATTM_RDY_AMT_CPR(java.math.BigDecimal TMN_ATTM_RDY_AMT_CPR) {
    this.TMN_ATTM_RDY_AMT_CPR = TMN_ATTM_RDY_AMT_CPR;
  }
  public QueryResult with_TMN_ATTM_RDY_AMT_CPR(java.math.BigDecimal TMN_ATTM_RDY_AMT_CPR) {
    this.TMN_ATTM_RDY_AMT_CPR = TMN_ATTM_RDY_AMT_CPR;
    return this;
  }
  private java.math.BigDecimal DMN15_WTHN_SLZ_PREM;
  public java.math.BigDecimal get_DMN15_WTHN_SLZ_PREM() {
    return DMN15_WTHN_SLZ_PREM;
  }
  public void set_DMN15_WTHN_SLZ_PREM(java.math.BigDecimal DMN15_WTHN_SLZ_PREM) {
    this.DMN15_WTHN_SLZ_PREM = DMN15_WTHN_SLZ_PREM;
  }
  public QueryResult with_DMN15_WTHN_SLZ_PREM(java.math.BigDecimal DMN15_WTHN_SLZ_PREM) {
    this.DMN15_WTHN_SLZ_PREM = DMN15_WTHN_SLZ_PREM;
    return this;
  }
  private java.math.BigDecimal DMN15_TMTD_RDY_AMT;
  public java.math.BigDecimal get_DMN15_TMTD_RDY_AMT() {
    return DMN15_TMTD_RDY_AMT;
  }
  public void set_DMN15_TMTD_RDY_AMT(java.math.BigDecimal DMN15_TMTD_RDY_AMT) {
    this.DMN15_TMTD_RDY_AMT = DMN15_TMTD_RDY_AMT;
  }
  public QueryResult with_DMN15_TMTD_RDY_AMT(java.math.BigDecimal DMN15_TMTD_RDY_AMT) {
    this.DMN15_TMTD_RDY_AMT = DMN15_TMTD_RDY_AMT;
    return this;
  }
  private String OWN_CTR_YN;
  public String get_OWN_CTR_YN() {
    return OWN_CTR_YN;
  }
  public void set_OWN_CTR_YN(String OWN_CTR_YN) {
    this.OWN_CTR_YN = OWN_CTR_YN;
  }
  public QueryResult with_OWN_CTR_YN(String OWN_CTR_YN) {
    this.OWN_CTR_YN = OWN_CTR_YN;
    return this;
  }
  private String CTR_CONV_SIC_SBC_YN;
  public String get_CTR_CONV_SIC_SBC_YN() {
    return CTR_CONV_SIC_SBC_YN;
  }
  public void set_CTR_CONV_SIC_SBC_YN(String CTR_CONV_SIC_SBC_YN) {
    this.CTR_CONV_SIC_SBC_YN = CTR_CONV_SIC_SBC_YN;
  }
  public QueryResult with_CTR_CONV_SIC_SBC_YN(String CTR_CONV_SIC_SBC_YN) {
    this.CTR_CONV_SIC_SBC_YN = CTR_CONV_SIC_SBC_YN;
    return this;
  }
  private java.math.BigDecimal SBC_AMT;
  public java.math.BigDecimal get_SBC_AMT() {
    return SBC_AMT;
  }
  public void set_SBC_AMT(java.math.BigDecimal SBC_AMT) {
    this.SBC_AMT = SBC_AMT;
  }
  public QueryResult with_SBC_AMT(java.math.BigDecimal SBC_AMT) {
    this.SBC_AMT = SBC_AMT;
    return this;
  }
  private java.math.BigDecimal CRD_FEE_CPR;
  public java.math.BigDecimal get_CRD_FEE_CPR() {
    return CRD_FEE_CPR;
  }
  public void set_CRD_FEE_CPR(java.math.BigDecimal CRD_FEE_CPR) {
    this.CRD_FEE_CPR = CRD_FEE_CPR;
  }
  public QueryResult with_CRD_FEE_CPR(java.math.BigDecimal CRD_FEE_CPR) {
    this.CRD_FEE_CPR = CRD_FEE_CPR;
    return this;
  }
  private java.math.BigDecimal CUS_CNTRB_ERN_AMT;
  public java.math.BigDecimal get_CUS_CNTRB_ERN_AMT() {
    return CUS_CNTRB_ERN_AMT;
  }
  public void set_CUS_CNTRB_ERN_AMT(java.math.BigDecimal CUS_CNTRB_ERN_AMT) {
    this.CUS_CNTRB_ERN_AMT = CUS_CNTRB_ERN_AMT;
  }
  public QueryResult with_CUS_CNTRB_ERN_AMT(java.math.BigDecimal CUS_CNTRB_ERN_AMT) {
    this.CUS_CNTRB_ERN_AMT = CUS_CNTRB_ERN_AMT;
    return this;
  }
  private java.math.BigDecimal SUM_FEE_CPR;
  public java.math.BigDecimal get_SUM_FEE_CPR() {
    return SUM_FEE_CPR;
  }
  public void set_SUM_FEE_CPR(java.math.BigDecimal SUM_FEE_CPR) {
    this.SUM_FEE_CPR = SUM_FEE_CPR;
  }
  public QueryResult with_SUM_FEE_CPR(java.math.BigDecimal SUM_FEE_CPR) {
    this.SUM_FEE_CPR = SUM_FEE_CPR;
    return this;
  }
  private java.math.BigDecimal ITRT_RISK_AMT;
  public java.math.BigDecimal get_ITRT_RISK_AMT() {
    return ITRT_RISK_AMT;
  }
  public void set_ITRT_RISK_AMT(java.math.BigDecimal ITRT_RISK_AMT) {
    this.ITRT_RISK_AMT = ITRT_RISK_AMT;
  }
  public QueryResult with_ITRT_RISK_AMT(java.math.BigDecimal ITRT_RISK_AMT) {
    this.ITRT_RISK_AMT = ITRT_RISK_AMT;
    return this;
  }
  private java.math.BigDecimal KICS_MKVL_CPR;
  public java.math.BigDecimal get_KICS_MKVL_CPR() {
    return KICS_MKVL_CPR;
  }
  public void set_KICS_MKVL_CPR(java.math.BigDecimal KICS_MKVL_CPR) {
    this.KICS_MKVL_CPR = KICS_MKVL_CPR;
  }
  public QueryResult with_KICS_MKVL_CPR(java.math.BigDecimal KICS_MKVL_CPR) {
    this.KICS_MKVL_CPR = KICS_MKVL_CPR;
    return this;
  }
  private java.math.BigDecimal ITRT_DEPRC_MKVL_CPR;
  public java.math.BigDecimal get_ITRT_DEPRC_MKVL_CPR() {
    return ITRT_DEPRC_MKVL_CPR;
  }
  public void set_ITRT_DEPRC_MKVL_CPR(java.math.BigDecimal ITRT_DEPRC_MKVL_CPR) {
    this.ITRT_DEPRC_MKVL_CPR = ITRT_DEPRC_MKVL_CPR;
  }
  public QueryResult with_ITRT_DEPRC_MKVL_CPR(java.math.BigDecimal ITRT_DEPRC_MKVL_CPR) {
    this.ITRT_DEPRC_MKVL_CPR = ITRT_DEPRC_MKVL_CPR;
    return this;
  }
  private java.math.BigDecimal ITRT_ASCD_MKVL_CPR;
  public java.math.BigDecimal get_ITRT_ASCD_MKVL_CPR() {
    return ITRT_ASCD_MKVL_CPR;
  }
  public void set_ITRT_ASCD_MKVL_CPR(java.math.BigDecimal ITRT_ASCD_MKVL_CPR) {
    this.ITRT_ASCD_MKVL_CPR = ITRT_ASCD_MKVL_CPR;
  }
  public QueryResult with_ITRT_ASCD_MKVL_CPR(java.math.BigDecimal ITRT_ASCD_MKVL_CPR) {
    this.ITRT_ASCD_MKVL_CPR = ITRT_ASCD_MKVL_CPR;
    return this;
  }
  private String CTR_INS_PRD_TP_CD;
  public String get_CTR_INS_PRD_TP_CD() {
    return CTR_INS_PRD_TP_CD;
  }
  public void set_CTR_INS_PRD_TP_CD(String CTR_INS_PRD_TP_CD) {
    this.CTR_INS_PRD_TP_CD = CTR_INS_PRD_TP_CD;
  }
  public QueryResult with_CTR_INS_PRD_TP_CD(String CTR_INS_PRD_TP_CD) {
    this.CTR_INS_PRD_TP_CD = CTR_INS_PRD_TP_CD;
    return this;
  }
  private java.math.BigDecimal MMPY_CNVS_PREM;
  public java.math.BigDecimal get_MMPY_CNVS_PREM() {
    return MMPY_CNVS_PREM;
  }
  public void set_MMPY_CNVS_PREM(java.math.BigDecimal MMPY_CNVS_PREM) {
    this.MMPY_CNVS_PREM = MMPY_CNVS_PREM;
  }
  public QueryResult with_MMPY_CNVS_PREM(java.math.BigDecimal MMPY_CNVS_PREM) {
    this.MMPY_CNVS_PREM = MMPY_CNVS_PREM;
    return this;
  }
  private String PLAN_CD;
  public String get_PLAN_CD() {
    return PLAN_CD;
  }
  public void set_PLAN_CD(String PLAN_CD) {
    this.PLAN_CD = PLAN_CD;
  }
  public QueryResult with_PLAN_CD(String PLAN_CD) {
    this.PLAN_CD = PLAN_CD;
    return this;
  }
  private String COV_UNT_PD_CD;
  public String get_COV_UNT_PD_CD() {
    return COV_UNT_PD_CD;
  }
  public void set_COV_UNT_PD_CD(String COV_UNT_PD_CD) {
    this.COV_UNT_PD_CD = COV_UNT_PD_CD;
  }
  public QueryResult with_COV_UNT_PD_CD(String COV_UNT_PD_CD) {
    this.COV_UNT_PD_CD = COV_UNT_PD_CD;
    return this;
  }
  private java.math.BigDecimal CSS_PREM_CPR;
  public java.math.BigDecimal get_CSS_PREM_CPR() {
    return CSS_PREM_CPR;
  }
  public void set_CSS_PREM_CPR(java.math.BigDecimal CSS_PREM_CPR) {
    this.CSS_PREM_CPR = CSS_PREM_CPR;
  }
  public QueryResult with_CSS_PREM_CPR(java.math.BigDecimal CSS_PREM_CPR) {
    this.CSS_PREM_CPR = CSS_PREM_CPR;
    return this;
  }
  private java.math.BigDecimal CSS_INS_AMT_RFD_CPR;
  public java.math.BigDecimal get_CSS_INS_AMT_RFD_CPR() {
    return CSS_INS_AMT_RFD_CPR;
  }
  public void set_CSS_INS_AMT_RFD_CPR(java.math.BigDecimal CSS_INS_AMT_RFD_CPR) {
    this.CSS_INS_AMT_RFD_CPR = CSS_INS_AMT_RFD_CPR;
  }
  public QueryResult with_CSS_INS_AMT_RFD_CPR(java.math.BigDecimal CSS_INS_AMT_RFD_CPR) {
    this.CSS_INS_AMT_RFD_CPR = CSS_INS_AMT_RFD_CPR;
    return this;
  }
  private java.math.BigDecimal MKVL_BKPM_AMT_CPR;
  public java.math.BigDecimal get_MKVL_BKPM_AMT_CPR() {
    return MKVL_BKPM_AMT_CPR;
  }
  public void set_MKVL_BKPM_AMT_CPR(java.math.BigDecimal MKVL_BKPM_AMT_CPR) {
    this.MKVL_BKPM_AMT_CPR = MKVL_BKPM_AMT_CPR;
  }
  public QueryResult with_MKVL_BKPM_AMT_CPR(java.math.BigDecimal MKVL_BKPM_AMT_CPR) {
    this.MKVL_BKPM_AMT_CPR = MKVL_BKPM_AMT_CPR;
    return this;
  }
  private java.math.BigDecimal CSS_RT;
  public java.math.BigDecimal get_CSS_RT() {
    return CSS_RT;
  }
  public void set_CSS_RT(java.math.BigDecimal CSS_RT) {
    this.CSS_RT = CSS_RT;
  }
  public QueryResult with_CSS_RT(java.math.BigDecimal CSS_RT) {
    this.CSS_RT = CSS_RT;
    return this;
  }
  private String CLF_DIV_CD;
  public String get_CLF_DIV_CD() {
    return CLF_DIV_CD;
  }
  public void set_CLF_DIV_CD(String CLF_DIV_CD) {
    this.CLF_DIV_CD = CLF_DIV_CD;
  }
  public QueryResult with_CLF_DIV_CD(String CLF_DIV_CD) {
    this.CLF_DIV_CD = CLF_DIV_CD;
    return this;
  }
  private String INS_SBC_SH_CD;
  public String get_INS_SBC_SH_CD() {
    return INS_SBC_SH_CD;
  }
  public void set_INS_SBC_SH_CD(String INS_SBC_SH_CD) {
    this.INS_SBC_SH_CD = INS_SBC_SH_CD;
  }
  public QueryResult with_INS_SBC_SH_CD(String INS_SBC_SH_CD) {
    this.INS_SBC_SH_CD = INS_SBC_SH_CD;
    return this;
  }
  private String SBC_DSG_FEE_PAY_TP_CD;
  public String get_SBC_DSG_FEE_PAY_TP_CD() {
    return SBC_DSG_FEE_PAY_TP_CD;
  }
  public void set_SBC_DSG_FEE_PAY_TP_CD(String SBC_DSG_FEE_PAY_TP_CD) {
    this.SBC_DSG_FEE_PAY_TP_CD = SBC_DSG_FEE_PAY_TP_CD;
  }
  public QueryResult with_SBC_DSG_FEE_PAY_TP_CD(String SBC_DSG_FEE_PAY_TP_CD) {
    this.SBC_DSG_FEE_PAY_TP_CD = SBC_DSG_FEE_PAY_TP_CD;
    return this;
  }
  private java.math.BigDecimal SBC_DSG_IRTD_MVAT;
  public java.math.BigDecimal get_SBC_DSG_IRTD_MVAT() {
    return SBC_DSG_IRTD_MVAT;
  }
  public void set_SBC_DSG_IRTD_MVAT(java.math.BigDecimal SBC_DSG_IRTD_MVAT) {
    this.SBC_DSG_IRTD_MVAT = SBC_DSG_IRTD_MVAT;
  }
  public QueryResult with_SBC_DSG_IRTD_MVAT(java.math.BigDecimal SBC_DSG_IRTD_MVAT) {
    this.SBC_DSG_IRTD_MVAT = SBC_DSG_IRTD_MVAT;
    return this;
  }
  private java.math.BigDecimal SBC_DSG_BZEX_MVAT;
  public java.math.BigDecimal get_SBC_DSG_BZEX_MVAT() {
    return SBC_DSG_BZEX_MVAT;
  }
  public void set_SBC_DSG_BZEX_MVAT(java.math.BigDecimal SBC_DSG_BZEX_MVAT) {
    this.SBC_DSG_BZEX_MVAT = SBC_DSG_BZEX_MVAT;
  }
  public QueryResult with_SBC_DSG_BZEX_MVAT(java.math.BigDecimal SBC_DSG_BZEX_MVAT) {
    this.SBC_DSG_BZEX_MVAT = SBC_DSG_BZEX_MVAT;
    return this;
  }
  private java.math.BigDecimal SBC_DSG_RSKEX_MVAT;
  public java.math.BigDecimal get_SBC_DSG_RSKEX_MVAT() {
    return SBC_DSG_RSKEX_MVAT;
  }
  public void set_SBC_DSG_RSKEX_MVAT(java.math.BigDecimal SBC_DSG_RSKEX_MVAT) {
    this.SBC_DSG_RSKEX_MVAT = SBC_DSG_RSKEX_MVAT;
  }
  public QueryResult with_SBC_DSG_RSKEX_MVAT(java.math.BigDecimal SBC_DSG_RSKEX_MVAT) {
    this.SBC_DSG_RSKEX_MVAT = SBC_DSG_RSKEX_MVAT;
    return this;
  }
  private java.math.BigDecimal SBC_DSG_RB_EXP_CPR;
  public java.math.BigDecimal get_SBC_DSG_RB_EXP_CPR() {
    return SBC_DSG_RB_EXP_CPR;
  }
  public void set_SBC_DSG_RB_EXP_CPR(java.math.BigDecimal SBC_DSG_RB_EXP_CPR) {
    this.SBC_DSG_RB_EXP_CPR = SBC_DSG_RB_EXP_CPR;
  }
  public QueryResult with_SBC_DSG_RB_EXP_CPR(java.math.BigDecimal SBC_DSG_RB_EXP_CPR) {
    this.SBC_DSG_RB_EXP_CPR = SBC_DSG_RB_EXP_CPR;
    return this;
  }
  private java.math.BigDecimal SBC_DSG_RSK_PREM_CPR;
  public java.math.BigDecimal get_SBC_DSG_RSK_PREM_CPR() {
    return SBC_DSG_RSK_PREM_CPR;
  }
  public void set_SBC_DSG_RSK_PREM_CPR(java.math.BigDecimal SBC_DSG_RSK_PREM_CPR) {
    this.SBC_DSG_RSK_PREM_CPR = SBC_DSG_RSK_PREM_CPR;
  }
  public QueryResult with_SBC_DSG_RSK_PREM_CPR(java.math.BigDecimal SBC_DSG_RSK_PREM_CPR) {
    this.SBC_DSG_RSK_PREM_CPR = SBC_DSG_RSK_PREM_CPR;
    return this;
  }
  private java.math.BigDecimal SBC_DSG_ORIG_PREM_CPR;
  public java.math.BigDecimal get_SBC_DSG_ORIG_PREM_CPR() {
    return SBC_DSG_ORIG_PREM_CPR;
  }
  public void set_SBC_DSG_ORIG_PREM_CPR(java.math.BigDecimal SBC_DSG_ORIG_PREM_CPR) {
    this.SBC_DSG_ORIG_PREM_CPR = SBC_DSG_ORIG_PREM_CPR;
  }
  public QueryResult with_SBC_DSG_ORIG_PREM_CPR(java.math.BigDecimal SBC_DSG_ORIG_PREM_CPR) {
    this.SBC_DSG_ORIG_PREM_CPR = SBC_DSG_ORIG_PREM_CPR;
    return this;
  }
  private java.math.BigDecimal SBC_DSG_MKVL_CPR;
  public java.math.BigDecimal get_SBC_DSG_MKVL_CPR() {
    return SBC_DSG_MKVL_CPR;
  }
  public void set_SBC_DSG_MKVL_CPR(java.math.BigDecimal SBC_DSG_MKVL_CPR) {
    this.SBC_DSG_MKVL_CPR = SBC_DSG_MKVL_CPR;
  }
  public QueryResult with_SBC_DSG_MKVL_CPR(java.math.BigDecimal SBC_DSG_MKVL_CPR) {
    this.SBC_DSG_MKVL_CPR = SBC_DSG_MKVL_CPR;
    return this;
  }
  private String LWRT_TMN_RFD_TP_CD;
  public String get_LWRT_TMN_RFD_TP_CD() {
    return LWRT_TMN_RFD_TP_CD;
  }
  public void set_LWRT_TMN_RFD_TP_CD(String LWRT_TMN_RFD_TP_CD) {
    this.LWRT_TMN_RFD_TP_CD = LWRT_TMN_RFD_TP_CD;
  }
  public QueryResult with_LWRT_TMN_RFD_TP_CD(String LWRT_TMN_RFD_TP_CD) {
    this.LWRT_TMN_RFD_TP_CD = LWRT_TMN_RFD_TP_CD;
    return this;
  }
  private String LGTM_ITMS_DIV_CD;
  public String get_LGTM_ITMS_DIV_CD() {
    return LGTM_ITMS_DIV_CD;
  }
  public void set_LGTM_ITMS_DIV_CD(String LGTM_ITMS_DIV_CD) {
    this.LGTM_ITMS_DIV_CD = LGTM_ITMS_DIV_CD;
  }
  public QueryResult with_LGTM_ITMS_DIV_CD(String LGTM_ITMS_DIV_CD) {
    this.LGTM_ITMS_DIV_CD = LGTM_ITMS_DIV_CD;
    return this;
  }
  private java.math.BigDecimal ADVEXP;
  public java.math.BigDecimal get_ADVEXP() {
    return ADVEXP;
  }
  public void set_ADVEXP(java.math.BigDecimal ADVEXP) {
    this.ADVEXP = ADVEXP;
  }
  public QueryResult with_ADVEXP(java.math.BigDecimal ADVEXP) {
    this.ADVEXP = ADVEXP;
    return this;
  }
  private String TRTPE_TRFR_YN;
  public String get_TRTPE_TRFR_YN() {
    return TRTPE_TRFR_YN;
  }
  public void set_TRTPE_TRFR_YN(String TRTPE_TRFR_YN) {
    this.TRTPE_TRFR_YN = TRTPE_TRFR_YN;
  }
  public QueryResult with_TRTPE_TRFR_YN(String TRTPE_TRFR_YN) {
    this.TRTPE_TRFR_YN = TRTPE_TRFR_YN;
    return this;
  }
  private String DTBT_CTR_YN;
  public String get_DTBT_CTR_YN() {
    return DTBT_CTR_YN;
  }
  public void set_DTBT_CTR_YN(String DTBT_CTR_YN) {
    this.DTBT_CTR_YN = DTBT_CTR_YN;
  }
  public QueryResult with_DTBT_CTR_YN(String DTBT_CTR_YN) {
    this.DTBT_CTR_YN = DTBT_CTR_YN;
    return this;
  }
  private String INSPE_GRDE_VAL;
  public String get_INSPE_GRDE_VAL() {
    return INSPE_GRDE_VAL;
  }
  public void set_INSPE_GRDE_VAL(String INSPE_GRDE_VAL) {
    this.INSPE_GRDE_VAL = INSPE_GRDE_VAL;
  }
  public QueryResult with_INSPE_GRDE_VAL(String INSPE_GRDE_VAL) {
    this.INSPE_GRDE_VAL = INSPE_GRDE_VAL;
    return this;
  }
  private String PY_EXEM_TP_CD;
  public String get_PY_EXEM_TP_CD() {
    return PY_EXEM_TP_CD;
  }
  public void set_PY_EXEM_TP_CD(String PY_EXEM_TP_CD) {
    this.PY_EXEM_TP_CD = PY_EXEM_TP_CD;
  }
  public QueryResult with_PY_EXEM_TP_CD(String PY_EXEM_TP_CD) {
    this.PY_EXEM_TP_CD = PY_EXEM_TP_CD;
    return this;
  }
  private String AMBA_CHN_DIV_CD;
  public String get_AMBA_CHN_DIV_CD() {
    return AMBA_CHN_DIV_CD;
  }
  public void set_AMBA_CHN_DIV_CD(String AMBA_CHN_DIV_CD) {
    this.AMBA_CHN_DIV_CD = AMBA_CHN_DIV_CD;
  }
  public QueryResult with_AMBA_CHN_DIV_CD(String AMBA_CHN_DIV_CD) {
    this.AMBA_CHN_DIV_CD = AMBA_CHN_DIV_CD;
    return this;
  }
  private java.math.BigDecimal PSINS_CRD_ETC_FEE;
  public java.math.BigDecimal get_PSINS_CRD_ETC_FEE() {
    return PSINS_CRD_ETC_FEE;
  }
  public void set_PSINS_CRD_ETC_FEE(java.math.BigDecimal PSINS_CRD_ETC_FEE) {
    this.PSINS_CRD_ETC_FEE = PSINS_CRD_ETC_FEE;
  }
  public QueryResult with_PSINS_CRD_ETC_FEE(java.math.BigDecimal PSINS_CRD_ETC_FEE) {
    this.PSINS_CRD_ETC_FEE = PSINS_CRD_ETC_FEE;
    return this;
  }
  private java.math.BigDecimal PSINS_AT_TRS_ETC_FEE;
  public java.math.BigDecimal get_PSINS_AT_TRS_ETC_FEE() {
    return PSINS_AT_TRS_ETC_FEE;
  }
  public void set_PSINS_AT_TRS_ETC_FEE(java.math.BigDecimal PSINS_AT_TRS_ETC_FEE) {
    this.PSINS_AT_TRS_ETC_FEE = PSINS_AT_TRS_ETC_FEE;
  }
  public QueryResult with_PSINS_AT_TRS_ETC_FEE(java.math.BigDecimal PSINS_AT_TRS_ETC_FEE) {
    this.PSINS_AT_TRS_ETC_FEE = PSINS_AT_TRS_ETC_FEE;
    return this;
  }
  private java.math.BigDecimal PSINS_COMS_ETC_FEE;
  public java.math.BigDecimal get_PSINS_COMS_ETC_FEE() {
    return PSINS_COMS_ETC_FEE;
  }
  public void set_PSINS_COMS_ETC_FEE(java.math.BigDecimal PSINS_COMS_ETC_FEE) {
    this.PSINS_COMS_ETC_FEE = PSINS_COMS_ETC_FEE;
  }
  public QueryResult with_PSINS_COMS_ETC_FEE(java.math.BigDecimal PSINS_COMS_ETC_FEE) {
    this.PSINS_COMS_ETC_FEE = PSINS_COMS_ETC_FEE;
    return this;
  }
  private java.math.BigDecimal LGTM_CHGE_EXP;
  public java.math.BigDecimal get_LGTM_CHGE_EXP() {
    return LGTM_CHGE_EXP;
  }
  public void set_LGTM_CHGE_EXP(java.math.BigDecimal LGTM_CHGE_EXP) {
    this.LGTM_CHGE_EXP = LGTM_CHGE_EXP;
  }
  public QueryResult with_LGTM_CHGE_EXP(java.math.BigDecimal LGTM_CHGE_EXP) {
    this.LGTM_CHGE_EXP = LGTM_CHGE_EXP;
    return this;
  }
  private java.math.BigDecimal LGTM_FIXT_EXP;
  public java.math.BigDecimal get_LGTM_FIXT_EXP() {
    return LGTM_FIXT_EXP;
  }
  public void set_LGTM_FIXT_EXP(java.math.BigDecimal LGTM_FIXT_EXP) {
    this.LGTM_FIXT_EXP = LGTM_FIXT_EXP;
  }
  public QueryResult with_LGTM_FIXT_EXP(java.math.BigDecimal LGTM_FIXT_EXP) {
    this.LGTM_FIXT_EXP = LGTM_FIXT_EXP;
    return this;
  }
  private java.math.BigDecimal PSINS_ATNS_MKVL_AMT;
  public java.math.BigDecimal get_PSINS_ATNS_MKVL_AMT() {
    return PSINS_ATNS_MKVL_AMT;
  }
  public void set_PSINS_ATNS_MKVL_AMT(java.math.BigDecimal PSINS_ATNS_MKVL_AMT) {
    this.PSINS_ATNS_MKVL_AMT = PSINS_ATNS_MKVL_AMT;
  }
  public QueryResult with_PSINS_ATNS_MKVL_AMT(java.math.BigDecimal PSINS_ATNS_MKVL_AMT) {
    this.PSINS_ATNS_MKVL_AMT = PSINS_ATNS_MKVL_AMT;
    return this;
  }
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (!(o instanceof QueryResult)) {
      return false;
    }
    QueryResult that = (QueryResult) o;
    boolean equal = true;
    equal = equal && (this.CLOG_YYMM == null ? that.CLOG_YYMM == null : this.CLOG_YYMM.equals(that.CLOG_YYMM));
    equal = equal && (this.STD_DT == null ? that.STD_DT == null : this.STD_DT.equals(that.STD_DT));
    equal = equal && (this.CTR_CHNG_STAT_CD == null ? that.CTR_CHNG_STAT_CD == null : this.CTR_CHNG_STAT_CD.equals(that.CTR_CHNG_STAT_CD));
    equal = equal && (this.POL_NO == null ? that.POL_NO == null : this.POL_NO.equals(that.POL_NO));
    equal = equal && (this.COV_CD == null ? that.COV_CD == null : this.COV_CD.equals(that.COV_CD));
    equal = equal && (this.CTR_COV_ID == null ? that.CTR_COV_ID == null : this.CTR_COV_ID.equals(that.CTR_COV_ID));
    equal = equal && (this.ENDR_NO == null ? that.ENDR_NO == null : this.ENDR_NO.equals(that.ENDR_NO));
    equal = equal && (this.UNT_PD_CD == null ? that.UNT_PD_CD == null : this.UNT_PD_CD.equals(that.UNT_PD_CD));
    equal = equal && (this.SBCP_YYMM == null ? that.SBCP_YYMM == null : this.SBCP_YYMM.equals(that.SBCP_YYMM));
    equal = equal && (this.FEE_PAY_TP_CD == null ? that.FEE_PAY_TP_CD == null : this.FEE_PAY_TP_CD.equals(that.FEE_PAY_TP_CD));
    equal = equal && (this.SBCP_DT == null ? that.SBCP_DT == null : this.SBCP_DT.equals(that.SBCP_DT));
    equal = equal && (this.ENDR_DT == null ? that.ENDR_DT == null : this.ENDR_DT.equals(that.ENDR_DT));
    equal = equal && (this.DMG_RT_COV_DCTG_CD == null ? that.DMG_RT_COV_DCTG_CD == null : this.DMG_RT_COV_DCTG_CD.equals(that.DMG_RT_COV_DCTG_CD));
    equal = equal && (this.INS_PRD_TP_CD == null ? that.INS_PRD_TP_CD == null : this.INS_PRD_TP_CD.equals(that.INS_PRD_TP_CD));
    equal = equal && (this.INS_PRD == null ? that.INS_PRD == null : this.INS_PRD.equals(that.INS_PRD));
    equal = equal && (this.PY_PRD_TP_CD == null ? that.PY_PRD_TP_CD == null : this.PY_PRD_TP_CD.equals(that.PY_PRD_TP_CD));
    equal = equal && (this.PY_PRD == null ? that.PY_PRD == null : this.PY_PRD.equals(that.PY_PRD));
    equal = equal && (this.PY_CYC_CD == null ? that.PY_CYC_CD == null : this.PY_CYC_CD.equals(that.PY_CYC_CD));
    equal = equal && (this.SBC_AGE == null ? that.SBC_AGE == null : this.SBC_AGE.equals(that.SBC_AGE));
    equal = equal && (this.GNDR_CD == null ? that.GNDR_CD == null : this.GNDR_CD.equals(that.GNDR_CD));
    equal = equal && (this.INJR_GR_NUM == null ? that.INJR_GR_NUM == null : this.INJR_GR_NUM.equals(that.INJR_GR_NUM));
    equal = equal && (this.LAST_PY_YYMM == null ? that.LAST_PY_YYMM == null : this.LAST_PY_YYMM.equals(that.LAST_PY_YYMM));
    equal = equal && (this.LAST_PY_TMS == null ? that.LAST_PY_TMS == null : this.LAST_PY_TMS.equals(that.LAST_PY_TMS));
    equal = equal && (this.RCRT_HDQT_ORG_CD == null ? that.RCRT_HDQT_ORG_CD == null : this.RCRT_HDQT_ORG_CD.equals(that.RCRT_HDQT_ORG_CD));
    equal = equal && (this.RCRT_BRCH_ORG_CD == null ? that.RCRT_BRCH_ORG_CD == null : this.RCRT_BRCH_ORG_CD.equals(that.RCRT_BRCH_ORG_CD));
    equal = equal && (this.RCRT_BCH_ORG_CD == null ? that.RCRT_BCH_ORG_CD == null : this.RCRT_BCH_ORG_CD.equals(that.RCRT_BCH_ORG_CD));
    equal = equal && (this.RCRT_TRTPE_ORG_CD == null ? that.RCRT_TRTPE_ORG_CD == null : this.RCRT_TRTPE_ORG_CD.equals(that.RCRT_TRTPE_ORG_CD));
    equal = equal && (this.RCRT_AGC_PLNR_CD == null ? that.RCRT_AGC_PLNR_CD == null : this.RCRT_AGC_PLNR_CD.equals(that.RCRT_AGC_PLNR_CD));
    equal = equal && (this.TRT_HDQT_ORG_CD == null ? that.TRT_HDQT_ORG_CD == null : this.TRT_HDQT_ORG_CD.equals(that.TRT_HDQT_ORG_CD));
    equal = equal && (this.TRT_BRCH_ORG_CD == null ? that.TRT_BRCH_ORG_CD == null : this.TRT_BRCH_ORG_CD.equals(that.TRT_BRCH_ORG_CD));
    equal = equal && (this.TRT_BCH_ORG_CD == null ? that.TRT_BCH_ORG_CD == null : this.TRT_BCH_ORG_CD.equals(that.TRT_BCH_ORG_CD));
    equal = equal && (this.TRTPE_ORG_CD == null ? that.TRTPE_ORG_CD == null : this.TRTPE_ORG_CD.equals(that.TRTPE_ORG_CD));
    equal = equal && (this.AGC_PLNR_CD == null ? that.AGC_PLNR_CD == null : this.AGC_PLNR_CD.equals(that.AGC_PLNR_CD));
    equal = equal && (this.HDQT_OPPN_DG_CF == null ? that.HDQT_OPPN_DG_CF == null : this.HDQT_OPPN_DG_CF.equals(that.HDQT_OPPN_DG_CF));
    equal = equal && (this.SLZ_PREM == null ? that.SLZ_PREM == null : this.SLZ_PREM.equals(that.SLZ_PREM));
    equal = equal && (this.IRTD_MKVL_AMT == null ? that.IRTD_MKVL_AMT == null : this.IRTD_MKVL_AMT.equals(that.IRTD_MKVL_AMT));
    equal = equal && (this.BZEX_MKVL_AMT == null ? that.BZEX_MKVL_AMT == null : this.BZEX_MKVL_AMT.equals(that.BZEX_MKVL_AMT));
    equal = equal && (this.RSKEX_MKVL_AMT == null ? that.RSKEX_MKVL_AMT == null : this.RSKEX_MKVL_AMT.equals(that.RSKEX_MKVL_AMT));
    equal = equal && (this.EIH_LDG_DTM == null ? that.EIH_LDG_DTM == null : this.EIH_LDG_DTM.equals(that.EIH_LDG_DTM));
    equal = equal && (this.RB_EXP_CPR == null ? that.RB_EXP_CPR == null : this.RB_EXP_CPR.equals(that.RB_EXP_CPR));
    equal = equal && (this.RSK_PREM_CPR == null ? that.RSK_PREM_CPR == null : this.RSK_PREM_CPR.equals(that.RSK_PREM_CPR));
    equal = equal && (this.ORIG_PREM_CPR == null ? that.ORIG_PREM_CPR == null : this.ORIG_PREM_CPR.equals(that.ORIG_PREM_CPR));
    equal = equal && (this.MKVL_CPR == null ? that.MKVL_CPR == null : this.MKVL_CPR.equals(that.MKVL_CPR));
    equal = equal && (this.EXPR_RFD_AMT_CPR == null ? that.EXPR_RFD_AMT_CPR == null : this.EXPR_RFD_AMT_CPR.equals(that.EXPR_RFD_AMT_CPR));
    equal = equal && (this.CLAT_CPR == null ? that.CLAT_CPR == null : this.CLAT_CPR.equals(that.CLAT_CPR));
    equal = equal && (this.SRVL_BNT_CPR == null ? that.SRVL_BNT_CPR == null : this.SRVL_BNT_CPR.equals(that.SRVL_BNT_CPR));
    equal = equal && (this.ANN_PAY_AMT_CPR == null ? that.ANN_PAY_AMT_CPR == null : this.ANN_PAY_AMT_CPR.equals(that.ANN_PAY_AMT_CPR));
    equal = equal && (this.PO_ETPY_CPR == null ? that.PO_ETPY_CPR == null : this.PO_ETPY_CPR.equals(that.PO_ETPY_CPR));
    equal = equal && (this.MNCL_FEE_CPR == null ? that.MNCL_FEE_CPR == null : this.MNCL_FEE_CPR.equals(that.MNCL_FEE_CPR));
    equal = equal && (this.SAV_PREM_CPR == null ? that.SAV_PREM_CPR == null : this.SAV_PREM_CPR.equals(that.SAV_PREM_CPR));
    equal = equal && (this.XACQ_EXP_CPR == null ? that.XACQ_EXP_CPR == null : this.XACQ_EXP_CPR.equals(that.XACQ_EXP_CPR));
    equal = equal && (this.XPT_MTN_EXP_CPR == null ? that.XPT_MTN_EXP_CPR == null : this.XPT_MTN_EXP_CPR.equals(that.XPT_MTN_EXP_CPR));
    equal = equal && (this.XPT_MNCL_EXP_CPR == null ? that.XPT_MNCL_EXP_CPR == null : this.XPT_MNCL_EXP_CPR.equals(that.XPT_MNCL_EXP_CPR));
    equal = equal && (this.INS_AMT_CPR == null ? that.INS_AMT_CPR == null : this.INS_AMT_CPR.equals(that.INS_AMT_CPR));
    equal = equal && (this.NPTPY_NW_CTR_RSLFE_CPR == null ? that.NPTPY_NW_CTR_RSLFE_CPR == null : this.NPTPY_NW_CTR_RSLFE_CPR.equals(that.NPTPY_NW_CTR_RSLFE_CPR));
    equal = equal && (this.NPTPY_ETC_NPO_CPR == null ? that.NPTPY_ETC_NPO_CPR == null : this.NPTPY_ETC_NPO_CPR.equals(that.NPTPY_ETC_NPO_CPR));
    equal = equal && (this.TMN_MGI_CPR == null ? that.TMN_MGI_CPR == null : this.TMN_MGI_CPR.equals(that.TMN_MGI_CPR));
    equal = equal && (this.ACD_ATTM_RDY_AMT_CPR == null ? that.ACD_ATTM_RDY_AMT_CPR == null : this.ACD_ATTM_RDY_AMT_CPR.equals(that.ACD_ATTM_RDY_AMT_CPR));
    equal = equal && (this.PY_EXEM_PREM_CPR == null ? that.PY_EXEM_PREM_CPR == null : this.PY_EXEM_PREM_CPR.equals(that.PY_EXEM_PREM_CPR));
    equal = equal && (this.HFWY_WDR_CPR == null ? that.HFWY_WDR_CPR == null : this.HFWY_WDR_CPR.equals(that.HFWY_WDR_CPR));
    equal = equal && (this.TMN_RSK_PREM_CPR == null ? that.TMN_RSK_PREM_CPR == null : this.TMN_RSK_PREM_CPR.equals(that.TMN_RSK_PREM_CPR));
    equal = equal && (this.LCAT_PD_CLAT_CPR == null ? that.LCAT_PD_CLAT_CPR == null : this.LCAT_PD_CLAT_CPR.equals(that.LCAT_PD_CLAT_CPR));
    equal = equal && (this.TMN_ATTM_RDY_AMT_CPR == null ? that.TMN_ATTM_RDY_AMT_CPR == null : this.TMN_ATTM_RDY_AMT_CPR.equals(that.TMN_ATTM_RDY_AMT_CPR));
    equal = equal && (this.DMN15_WTHN_SLZ_PREM == null ? that.DMN15_WTHN_SLZ_PREM == null : this.DMN15_WTHN_SLZ_PREM.equals(that.DMN15_WTHN_SLZ_PREM));
    equal = equal && (this.DMN15_TMTD_RDY_AMT == null ? that.DMN15_TMTD_RDY_AMT == null : this.DMN15_TMTD_RDY_AMT.equals(that.DMN15_TMTD_RDY_AMT));
    equal = equal && (this.OWN_CTR_YN == null ? that.OWN_CTR_YN == null : this.OWN_CTR_YN.equals(that.OWN_CTR_YN));
    equal = equal && (this.CTR_CONV_SIC_SBC_YN == null ? that.CTR_CONV_SIC_SBC_YN == null : this.CTR_CONV_SIC_SBC_YN.equals(that.CTR_CONV_SIC_SBC_YN));
    equal = equal && (this.SBC_AMT == null ? that.SBC_AMT == null : this.SBC_AMT.equals(that.SBC_AMT));
    equal = equal && (this.CRD_FEE_CPR == null ? that.CRD_FEE_CPR == null : this.CRD_FEE_CPR.equals(that.CRD_FEE_CPR));
    equal = equal && (this.CUS_CNTRB_ERN_AMT == null ? that.CUS_CNTRB_ERN_AMT == null : this.CUS_CNTRB_ERN_AMT.equals(that.CUS_CNTRB_ERN_AMT));
    equal = equal && (this.SUM_FEE_CPR == null ? that.SUM_FEE_CPR == null : this.SUM_FEE_CPR.equals(that.SUM_FEE_CPR));
    equal = equal && (this.ITRT_RISK_AMT == null ? that.ITRT_RISK_AMT == null : this.ITRT_RISK_AMT.equals(that.ITRT_RISK_AMT));
    equal = equal && (this.KICS_MKVL_CPR == null ? that.KICS_MKVL_CPR == null : this.KICS_MKVL_CPR.equals(that.KICS_MKVL_CPR));
    equal = equal && (this.ITRT_DEPRC_MKVL_CPR == null ? that.ITRT_DEPRC_MKVL_CPR == null : this.ITRT_DEPRC_MKVL_CPR.equals(that.ITRT_DEPRC_MKVL_CPR));
    equal = equal && (this.ITRT_ASCD_MKVL_CPR == null ? that.ITRT_ASCD_MKVL_CPR == null : this.ITRT_ASCD_MKVL_CPR.equals(that.ITRT_ASCD_MKVL_CPR));
    equal = equal && (this.CTR_INS_PRD_TP_CD == null ? that.CTR_INS_PRD_TP_CD == null : this.CTR_INS_PRD_TP_CD.equals(that.CTR_INS_PRD_TP_CD));
    equal = equal && (this.MMPY_CNVS_PREM == null ? that.MMPY_CNVS_PREM == null : this.MMPY_CNVS_PREM.equals(that.MMPY_CNVS_PREM));
    equal = equal && (this.PLAN_CD == null ? that.PLAN_CD == null : this.PLAN_CD.equals(that.PLAN_CD));
    equal = equal && (this.COV_UNT_PD_CD == null ? that.COV_UNT_PD_CD == null : this.COV_UNT_PD_CD.equals(that.COV_UNT_PD_CD));
    equal = equal && (this.CSS_PREM_CPR == null ? that.CSS_PREM_CPR == null : this.CSS_PREM_CPR.equals(that.CSS_PREM_CPR));
    equal = equal && (this.CSS_INS_AMT_RFD_CPR == null ? that.CSS_INS_AMT_RFD_CPR == null : this.CSS_INS_AMT_RFD_CPR.equals(that.CSS_INS_AMT_RFD_CPR));
    equal = equal && (this.MKVL_BKPM_AMT_CPR == null ? that.MKVL_BKPM_AMT_CPR == null : this.MKVL_BKPM_AMT_CPR.equals(that.MKVL_BKPM_AMT_CPR));
    equal = equal && (this.CSS_RT == null ? that.CSS_RT == null : this.CSS_RT.equals(that.CSS_RT));
    equal = equal && (this.CLF_DIV_CD == null ? that.CLF_DIV_CD == null : this.CLF_DIV_CD.equals(that.CLF_DIV_CD));
    equal = equal && (this.INS_SBC_SH_CD == null ? that.INS_SBC_SH_CD == null : this.INS_SBC_SH_CD.equals(that.INS_SBC_SH_CD));
    equal = equal && (this.SBC_DSG_FEE_PAY_TP_CD == null ? that.SBC_DSG_FEE_PAY_TP_CD == null : this.SBC_DSG_FEE_PAY_TP_CD.equals(that.SBC_DSG_FEE_PAY_TP_CD));
    equal = equal && (this.SBC_DSG_IRTD_MVAT == null ? that.SBC_DSG_IRTD_MVAT == null : this.SBC_DSG_IRTD_MVAT.equals(that.SBC_DSG_IRTD_MVAT));
    equal = equal && (this.SBC_DSG_BZEX_MVAT == null ? that.SBC_DSG_BZEX_MVAT == null : this.SBC_DSG_BZEX_MVAT.equals(that.SBC_DSG_BZEX_MVAT));
    equal = equal && (this.SBC_DSG_RSKEX_MVAT == null ? that.SBC_DSG_RSKEX_MVAT == null : this.SBC_DSG_RSKEX_MVAT.equals(that.SBC_DSG_RSKEX_MVAT));
    equal = equal && (this.SBC_DSG_RB_EXP_CPR == null ? that.SBC_DSG_RB_EXP_CPR == null : this.SBC_DSG_RB_EXP_CPR.equals(that.SBC_DSG_RB_EXP_CPR));
    equal = equal && (this.SBC_DSG_RSK_PREM_CPR == null ? that.SBC_DSG_RSK_PREM_CPR == null : this.SBC_DSG_RSK_PREM_CPR.equals(that.SBC_DSG_RSK_PREM_CPR));
    equal = equal && (this.SBC_DSG_ORIG_PREM_CPR == null ? that.SBC_DSG_ORIG_PREM_CPR == null : this.SBC_DSG_ORIG_PREM_CPR.equals(that.SBC_DSG_ORIG_PREM_CPR));
    equal = equal && (this.SBC_DSG_MKVL_CPR == null ? that.SBC_DSG_MKVL_CPR == null : this.SBC_DSG_MKVL_CPR.equals(that.SBC_DSG_MKVL_CPR));
    equal = equal && (this.LWRT_TMN_RFD_TP_CD == null ? that.LWRT_TMN_RFD_TP_CD == null : this.LWRT_TMN_RFD_TP_CD.equals(that.LWRT_TMN_RFD_TP_CD));
    equal = equal && (this.LGTM_ITMS_DIV_CD == null ? that.LGTM_ITMS_DIV_CD == null : this.LGTM_ITMS_DIV_CD.equals(that.LGTM_ITMS_DIV_CD));
    equal = equal && (this.ADVEXP == null ? that.ADVEXP == null : this.ADVEXP.equals(that.ADVEXP));
    equal = equal && (this.TRTPE_TRFR_YN == null ? that.TRTPE_TRFR_YN == null : this.TRTPE_TRFR_YN.equals(that.TRTPE_TRFR_YN));
    equal = equal && (this.DTBT_CTR_YN == null ? that.DTBT_CTR_YN == null : this.DTBT_CTR_YN.equals(that.DTBT_CTR_YN));
    equal = equal && (this.INSPE_GRDE_VAL == null ? that.INSPE_GRDE_VAL == null : this.INSPE_GRDE_VAL.equals(that.INSPE_GRDE_VAL));
    equal = equal && (this.PY_EXEM_TP_CD == null ? that.PY_EXEM_TP_CD == null : this.PY_EXEM_TP_CD.equals(that.PY_EXEM_TP_CD));
    equal = equal && (this.AMBA_CHN_DIV_CD == null ? that.AMBA_CHN_DIV_CD == null : this.AMBA_CHN_DIV_CD.equals(that.AMBA_CHN_DIV_CD));
    equal = equal && (this.PSINS_CRD_ETC_FEE == null ? that.PSINS_CRD_ETC_FEE == null : this.PSINS_CRD_ETC_FEE.equals(that.PSINS_CRD_ETC_FEE));
    equal = equal && (this.PSINS_AT_TRS_ETC_FEE == null ? that.PSINS_AT_TRS_ETC_FEE == null : this.PSINS_AT_TRS_ETC_FEE.equals(that.PSINS_AT_TRS_ETC_FEE));
    equal = equal && (this.PSINS_COMS_ETC_FEE == null ? that.PSINS_COMS_ETC_FEE == null : this.PSINS_COMS_ETC_FEE.equals(that.PSINS_COMS_ETC_FEE));
    equal = equal && (this.LGTM_CHGE_EXP == null ? that.LGTM_CHGE_EXP == null : this.LGTM_CHGE_EXP.equals(that.LGTM_CHGE_EXP));
    equal = equal && (this.LGTM_FIXT_EXP == null ? that.LGTM_FIXT_EXP == null : this.LGTM_FIXT_EXP.equals(that.LGTM_FIXT_EXP));
    equal = equal && (this.PSINS_ATNS_MKVL_AMT == null ? that.PSINS_ATNS_MKVL_AMT == null : this.PSINS_ATNS_MKVL_AMT.equals(that.PSINS_ATNS_MKVL_AMT));
    return equal;
  }
  public boolean equals0(Object o) {
    if (this == o) {
      return true;
    }
    if (!(o instanceof QueryResult)) {
      return false;
    }
    QueryResult that = (QueryResult) o;
    boolean equal = true;
    equal = equal && (this.CLOG_YYMM == null ? that.CLOG_YYMM == null : this.CLOG_YYMM.equals(that.CLOG_YYMM));
    equal = equal && (this.STD_DT == null ? that.STD_DT == null : this.STD_DT.equals(that.STD_DT));
    equal = equal && (this.CTR_CHNG_STAT_CD == null ? that.CTR_CHNG_STAT_CD == null : this.CTR_CHNG_STAT_CD.equals(that.CTR_CHNG_STAT_CD));
    equal = equal && (this.POL_NO == null ? that.POL_NO == null : this.POL_NO.equals(that.POL_NO));
    equal = equal && (this.COV_CD == null ? that.COV_CD == null : this.COV_CD.equals(that.COV_CD));
    equal = equal && (this.CTR_COV_ID == null ? that.CTR_COV_ID == null : this.CTR_COV_ID.equals(that.CTR_COV_ID));
    equal = equal && (this.ENDR_NO == null ? that.ENDR_NO == null : this.ENDR_NO.equals(that.ENDR_NO));
    equal = equal && (this.UNT_PD_CD == null ? that.UNT_PD_CD == null : this.UNT_PD_CD.equals(that.UNT_PD_CD));
    equal = equal && (this.SBCP_YYMM == null ? that.SBCP_YYMM == null : this.SBCP_YYMM.equals(that.SBCP_YYMM));
    equal = equal && (this.FEE_PAY_TP_CD == null ? that.FEE_PAY_TP_CD == null : this.FEE_PAY_TP_CD.equals(that.FEE_PAY_TP_CD));
    equal = equal && (this.SBCP_DT == null ? that.SBCP_DT == null : this.SBCP_DT.equals(that.SBCP_DT));
    equal = equal && (this.ENDR_DT == null ? that.ENDR_DT == null : this.ENDR_DT.equals(that.ENDR_DT));
    equal = equal && (this.DMG_RT_COV_DCTG_CD == null ? that.DMG_RT_COV_DCTG_CD == null : this.DMG_RT_COV_DCTG_CD.equals(that.DMG_RT_COV_DCTG_CD));
    equal = equal && (this.INS_PRD_TP_CD == null ? that.INS_PRD_TP_CD == null : this.INS_PRD_TP_CD.equals(that.INS_PRD_TP_CD));
    equal = equal && (this.INS_PRD == null ? that.INS_PRD == null : this.INS_PRD.equals(that.INS_PRD));
    equal = equal && (this.PY_PRD_TP_CD == null ? that.PY_PRD_TP_CD == null : this.PY_PRD_TP_CD.equals(that.PY_PRD_TP_CD));
    equal = equal && (this.PY_PRD == null ? that.PY_PRD == null : this.PY_PRD.equals(that.PY_PRD));
    equal = equal && (this.PY_CYC_CD == null ? that.PY_CYC_CD == null : this.PY_CYC_CD.equals(that.PY_CYC_CD));
    equal = equal && (this.SBC_AGE == null ? that.SBC_AGE == null : this.SBC_AGE.equals(that.SBC_AGE));
    equal = equal && (this.GNDR_CD == null ? that.GNDR_CD == null : this.GNDR_CD.equals(that.GNDR_CD));
    equal = equal && (this.INJR_GR_NUM == null ? that.INJR_GR_NUM == null : this.INJR_GR_NUM.equals(that.INJR_GR_NUM));
    equal = equal && (this.LAST_PY_YYMM == null ? that.LAST_PY_YYMM == null : this.LAST_PY_YYMM.equals(that.LAST_PY_YYMM));
    equal = equal && (this.LAST_PY_TMS == null ? that.LAST_PY_TMS == null : this.LAST_PY_TMS.equals(that.LAST_PY_TMS));
    equal = equal && (this.RCRT_HDQT_ORG_CD == null ? that.RCRT_HDQT_ORG_CD == null : this.RCRT_HDQT_ORG_CD.equals(that.RCRT_HDQT_ORG_CD));
    equal = equal && (this.RCRT_BRCH_ORG_CD == null ? that.RCRT_BRCH_ORG_CD == null : this.RCRT_BRCH_ORG_CD.equals(that.RCRT_BRCH_ORG_CD));
    equal = equal && (this.RCRT_BCH_ORG_CD == null ? that.RCRT_BCH_ORG_CD == null : this.RCRT_BCH_ORG_CD.equals(that.RCRT_BCH_ORG_CD));
    equal = equal && (this.RCRT_TRTPE_ORG_CD == null ? that.RCRT_TRTPE_ORG_CD == null : this.RCRT_TRTPE_ORG_CD.equals(that.RCRT_TRTPE_ORG_CD));
    equal = equal && (this.RCRT_AGC_PLNR_CD == null ? that.RCRT_AGC_PLNR_CD == null : this.RCRT_AGC_PLNR_CD.equals(that.RCRT_AGC_PLNR_CD));
    equal = equal && (this.TRT_HDQT_ORG_CD == null ? that.TRT_HDQT_ORG_CD == null : this.TRT_HDQT_ORG_CD.equals(that.TRT_HDQT_ORG_CD));
    equal = equal && (this.TRT_BRCH_ORG_CD == null ? that.TRT_BRCH_ORG_CD == null : this.TRT_BRCH_ORG_CD.equals(that.TRT_BRCH_ORG_CD));
    equal = equal && (this.TRT_BCH_ORG_CD == null ? that.TRT_BCH_ORG_CD == null : this.TRT_BCH_ORG_CD.equals(that.TRT_BCH_ORG_CD));
    equal = equal && (this.TRTPE_ORG_CD == null ? that.TRTPE_ORG_CD == null : this.TRTPE_ORG_CD.equals(that.TRTPE_ORG_CD));
    equal = equal && (this.AGC_PLNR_CD == null ? that.AGC_PLNR_CD == null : this.AGC_PLNR_CD.equals(that.AGC_PLNR_CD));
    equal = equal && (this.HDQT_OPPN_DG_CF == null ? that.HDQT_OPPN_DG_CF == null : this.HDQT_OPPN_DG_CF.equals(that.HDQT_OPPN_DG_CF));
    equal = equal && (this.SLZ_PREM == null ? that.SLZ_PREM == null : this.SLZ_PREM.equals(that.SLZ_PREM));
    equal = equal && (this.IRTD_MKVL_AMT == null ? that.IRTD_MKVL_AMT == null : this.IRTD_MKVL_AMT.equals(that.IRTD_MKVL_AMT));
    equal = equal && (this.BZEX_MKVL_AMT == null ? that.BZEX_MKVL_AMT == null : this.BZEX_MKVL_AMT.equals(that.BZEX_MKVL_AMT));
    equal = equal && (this.RSKEX_MKVL_AMT == null ? that.RSKEX_MKVL_AMT == null : this.RSKEX_MKVL_AMT.equals(that.RSKEX_MKVL_AMT));
    equal = equal && (this.EIH_LDG_DTM == null ? that.EIH_LDG_DTM == null : this.EIH_LDG_DTM.equals(that.EIH_LDG_DTM));
    equal = equal && (this.RB_EXP_CPR == null ? that.RB_EXP_CPR == null : this.RB_EXP_CPR.equals(that.RB_EXP_CPR));
    equal = equal && (this.RSK_PREM_CPR == null ? that.RSK_PREM_CPR == null : this.RSK_PREM_CPR.equals(that.RSK_PREM_CPR));
    equal = equal && (this.ORIG_PREM_CPR == null ? that.ORIG_PREM_CPR == null : this.ORIG_PREM_CPR.equals(that.ORIG_PREM_CPR));
    equal = equal && (this.MKVL_CPR == null ? that.MKVL_CPR == null : this.MKVL_CPR.equals(that.MKVL_CPR));
    equal = equal && (this.EXPR_RFD_AMT_CPR == null ? that.EXPR_RFD_AMT_CPR == null : this.EXPR_RFD_AMT_CPR.equals(that.EXPR_RFD_AMT_CPR));
    equal = equal && (this.CLAT_CPR == null ? that.CLAT_CPR == null : this.CLAT_CPR.equals(that.CLAT_CPR));
    equal = equal && (this.SRVL_BNT_CPR == null ? that.SRVL_BNT_CPR == null : this.SRVL_BNT_CPR.equals(that.SRVL_BNT_CPR));
    equal = equal && (this.ANN_PAY_AMT_CPR == null ? that.ANN_PAY_AMT_CPR == null : this.ANN_PAY_AMT_CPR.equals(that.ANN_PAY_AMT_CPR));
    equal = equal && (this.PO_ETPY_CPR == null ? that.PO_ETPY_CPR == null : this.PO_ETPY_CPR.equals(that.PO_ETPY_CPR));
    equal = equal && (this.MNCL_FEE_CPR == null ? that.MNCL_FEE_CPR == null : this.MNCL_FEE_CPR.equals(that.MNCL_FEE_CPR));
    equal = equal && (this.SAV_PREM_CPR == null ? that.SAV_PREM_CPR == null : this.SAV_PREM_CPR.equals(that.SAV_PREM_CPR));
    equal = equal && (this.XACQ_EXP_CPR == null ? that.XACQ_EXP_CPR == null : this.XACQ_EXP_CPR.equals(that.XACQ_EXP_CPR));
    equal = equal && (this.XPT_MTN_EXP_CPR == null ? that.XPT_MTN_EXP_CPR == null : this.XPT_MTN_EXP_CPR.equals(that.XPT_MTN_EXP_CPR));
    equal = equal && (this.XPT_MNCL_EXP_CPR == null ? that.XPT_MNCL_EXP_CPR == null : this.XPT_MNCL_EXP_CPR.equals(that.XPT_MNCL_EXP_CPR));
    equal = equal && (this.INS_AMT_CPR == null ? that.INS_AMT_CPR == null : this.INS_AMT_CPR.equals(that.INS_AMT_CPR));
    equal = equal && (this.NPTPY_NW_CTR_RSLFE_CPR == null ? that.NPTPY_NW_CTR_RSLFE_CPR == null : this.NPTPY_NW_CTR_RSLFE_CPR.equals(that.NPTPY_NW_CTR_RSLFE_CPR));
    equal = equal && (this.NPTPY_ETC_NPO_CPR == null ? that.NPTPY_ETC_NPO_CPR == null : this.NPTPY_ETC_NPO_CPR.equals(that.NPTPY_ETC_NPO_CPR));
    equal = equal && (this.TMN_MGI_CPR == null ? that.TMN_MGI_CPR == null : this.TMN_MGI_CPR.equals(that.TMN_MGI_CPR));
    equal = equal && (this.ACD_ATTM_RDY_AMT_CPR == null ? that.ACD_ATTM_RDY_AMT_CPR == null : this.ACD_ATTM_RDY_AMT_CPR.equals(that.ACD_ATTM_RDY_AMT_CPR));
    equal = equal && (this.PY_EXEM_PREM_CPR == null ? that.PY_EXEM_PREM_CPR == null : this.PY_EXEM_PREM_CPR.equals(that.PY_EXEM_PREM_CPR));
    equal = equal && (this.HFWY_WDR_CPR == null ? that.HFWY_WDR_CPR == null : this.HFWY_WDR_CPR.equals(that.HFWY_WDR_CPR));
    equal = equal && (this.TMN_RSK_PREM_CPR == null ? that.TMN_RSK_PREM_CPR == null : this.TMN_RSK_PREM_CPR.equals(that.TMN_RSK_PREM_CPR));
    equal = equal && (this.LCAT_PD_CLAT_CPR == null ? that.LCAT_PD_CLAT_CPR == null : this.LCAT_PD_CLAT_CPR.equals(that.LCAT_PD_CLAT_CPR));
    equal = equal && (this.TMN_ATTM_RDY_AMT_CPR == null ? that.TMN_ATTM_RDY_AMT_CPR == null : this.TMN_ATTM_RDY_AMT_CPR.equals(that.TMN_ATTM_RDY_AMT_CPR));
    equal = equal && (this.DMN15_WTHN_SLZ_PREM == null ? that.DMN15_WTHN_SLZ_PREM == null : this.DMN15_WTHN_SLZ_PREM.equals(that.DMN15_WTHN_SLZ_PREM));
    equal = equal && (this.DMN15_TMTD_RDY_AMT == null ? that.DMN15_TMTD_RDY_AMT == null : this.DMN15_TMTD_RDY_AMT.equals(that.DMN15_TMTD_RDY_AMT));
    equal = equal && (this.OWN_CTR_YN == null ? that.OWN_CTR_YN == null : this.OWN_CTR_YN.equals(that.OWN_CTR_YN));
    equal = equal && (this.CTR_CONV_SIC_SBC_YN == null ? that.CTR_CONV_SIC_SBC_YN == null : this.CTR_CONV_SIC_SBC_YN.equals(that.CTR_CONV_SIC_SBC_YN));
    equal = equal && (this.SBC_AMT == null ? that.SBC_AMT == null : this.SBC_AMT.equals(that.SBC_AMT));
    equal = equal && (this.CRD_FEE_CPR == null ? that.CRD_FEE_CPR == null : this.CRD_FEE_CPR.equals(that.CRD_FEE_CPR));
    equal = equal && (this.CUS_CNTRB_ERN_AMT == null ? that.CUS_CNTRB_ERN_AMT == null : this.CUS_CNTRB_ERN_AMT.equals(that.CUS_CNTRB_ERN_AMT));
    equal = equal && (this.SUM_FEE_CPR == null ? that.SUM_FEE_CPR == null : this.SUM_FEE_CPR.equals(that.SUM_FEE_CPR));
    equal = equal && (this.ITRT_RISK_AMT == null ? that.ITRT_RISK_AMT == null : this.ITRT_RISK_AMT.equals(that.ITRT_RISK_AMT));
    equal = equal && (this.KICS_MKVL_CPR == null ? that.KICS_MKVL_CPR == null : this.KICS_MKVL_CPR.equals(that.KICS_MKVL_CPR));
    equal = equal && (this.ITRT_DEPRC_MKVL_CPR == null ? that.ITRT_DEPRC_MKVL_CPR == null : this.ITRT_DEPRC_MKVL_CPR.equals(that.ITRT_DEPRC_MKVL_CPR));
    equal = equal && (this.ITRT_ASCD_MKVL_CPR == null ? that.ITRT_ASCD_MKVL_CPR == null : this.ITRT_ASCD_MKVL_CPR.equals(that.ITRT_ASCD_MKVL_CPR));
    equal = equal && (this.CTR_INS_PRD_TP_CD == null ? that.CTR_INS_PRD_TP_CD == null : this.CTR_INS_PRD_TP_CD.equals(that.CTR_INS_PRD_TP_CD));
    equal = equal && (this.MMPY_CNVS_PREM == null ? that.MMPY_CNVS_PREM == null : this.MMPY_CNVS_PREM.equals(that.MMPY_CNVS_PREM));
    equal = equal && (this.PLAN_CD == null ? that.PLAN_CD == null : this.PLAN_CD.equals(that.PLAN_CD));
    equal = equal && (this.COV_UNT_PD_CD == null ? that.COV_UNT_PD_CD == null : this.COV_UNT_PD_CD.equals(that.COV_UNT_PD_CD));
    equal = equal && (this.CSS_PREM_CPR == null ? that.CSS_PREM_CPR == null : this.CSS_PREM_CPR.equals(that.CSS_PREM_CPR));
    equal = equal && (this.CSS_INS_AMT_RFD_CPR == null ? that.CSS_INS_AMT_RFD_CPR == null : this.CSS_INS_AMT_RFD_CPR.equals(that.CSS_INS_AMT_RFD_CPR));
    equal = equal && (this.MKVL_BKPM_AMT_CPR == null ? that.MKVL_BKPM_AMT_CPR == null : this.MKVL_BKPM_AMT_CPR.equals(that.MKVL_BKPM_AMT_CPR));
    equal = equal && (this.CSS_RT == null ? that.CSS_RT == null : this.CSS_RT.equals(that.CSS_RT));
    equal = equal && (this.CLF_DIV_CD == null ? that.CLF_DIV_CD == null : this.CLF_DIV_CD.equals(that.CLF_DIV_CD));
    equal = equal && (this.INS_SBC_SH_CD == null ? that.INS_SBC_SH_CD == null : this.INS_SBC_SH_CD.equals(that.INS_SBC_SH_CD));
    equal = equal && (this.SBC_DSG_FEE_PAY_TP_CD == null ? that.SBC_DSG_FEE_PAY_TP_CD == null : this.SBC_DSG_FEE_PAY_TP_CD.equals(that.SBC_DSG_FEE_PAY_TP_CD));
    equal = equal && (this.SBC_DSG_IRTD_MVAT == null ? that.SBC_DSG_IRTD_MVAT == null : this.SBC_DSG_IRTD_MVAT.equals(that.SBC_DSG_IRTD_MVAT));
    equal = equal && (this.SBC_DSG_BZEX_MVAT == null ? that.SBC_DSG_BZEX_MVAT == null : this.SBC_DSG_BZEX_MVAT.equals(that.SBC_DSG_BZEX_MVAT));
    equal = equal && (this.SBC_DSG_RSKEX_MVAT == null ? that.SBC_DSG_RSKEX_MVAT == null : this.SBC_DSG_RSKEX_MVAT.equals(that.SBC_DSG_RSKEX_MVAT));
    equal = equal && (this.SBC_DSG_RB_EXP_CPR == null ? that.SBC_DSG_RB_EXP_CPR == null : this.SBC_DSG_RB_EXP_CPR.equals(that.SBC_DSG_RB_EXP_CPR));
    equal = equal && (this.SBC_DSG_RSK_PREM_CPR == null ? that.SBC_DSG_RSK_PREM_CPR == null : this.SBC_DSG_RSK_PREM_CPR.equals(that.SBC_DSG_RSK_PREM_CPR));
    equal = equal && (this.SBC_DSG_ORIG_PREM_CPR == null ? that.SBC_DSG_ORIG_PREM_CPR == null : this.SBC_DSG_ORIG_PREM_CPR.equals(that.SBC_DSG_ORIG_PREM_CPR));
    equal = equal && (this.SBC_DSG_MKVL_CPR == null ? that.SBC_DSG_MKVL_CPR == null : this.SBC_DSG_MKVL_CPR.equals(that.SBC_DSG_MKVL_CPR));
    equal = equal && (this.LWRT_TMN_RFD_TP_CD == null ? that.LWRT_TMN_RFD_TP_CD == null : this.LWRT_TMN_RFD_TP_CD.equals(that.LWRT_TMN_RFD_TP_CD));
    equal = equal && (this.LGTM_ITMS_DIV_CD == null ? that.LGTM_ITMS_DIV_CD == null : this.LGTM_ITMS_DIV_CD.equals(that.LGTM_ITMS_DIV_CD));
    equal = equal && (this.ADVEXP == null ? that.ADVEXP == null : this.ADVEXP.equals(that.ADVEXP));
    equal = equal && (this.TRTPE_TRFR_YN == null ? that.TRTPE_TRFR_YN == null : this.TRTPE_TRFR_YN.equals(that.TRTPE_TRFR_YN));
    equal = equal && (this.DTBT_CTR_YN == null ? that.DTBT_CTR_YN == null : this.DTBT_CTR_YN.equals(that.DTBT_CTR_YN));
    equal = equal && (this.INSPE_GRDE_VAL == null ? that.INSPE_GRDE_VAL == null : this.INSPE_GRDE_VAL.equals(that.INSPE_GRDE_VAL));
    equal = equal && (this.PY_EXEM_TP_CD == null ? that.PY_EXEM_TP_CD == null : this.PY_EXEM_TP_CD.equals(that.PY_EXEM_TP_CD));
    equal = equal && (this.AMBA_CHN_DIV_CD == null ? that.AMBA_CHN_DIV_CD == null : this.AMBA_CHN_DIV_CD.equals(that.AMBA_CHN_DIV_CD));
    equal = equal && (this.PSINS_CRD_ETC_FEE == null ? that.PSINS_CRD_ETC_FEE == null : this.PSINS_CRD_ETC_FEE.equals(that.PSINS_CRD_ETC_FEE));
    equal = equal && (this.PSINS_AT_TRS_ETC_FEE == null ? that.PSINS_AT_TRS_ETC_FEE == null : this.PSINS_AT_TRS_ETC_FEE.equals(that.PSINS_AT_TRS_ETC_FEE));
    equal = equal && (this.PSINS_COMS_ETC_FEE == null ? that.PSINS_COMS_ETC_FEE == null : this.PSINS_COMS_ETC_FEE.equals(that.PSINS_COMS_ETC_FEE));
    equal = equal && (this.LGTM_CHGE_EXP == null ? that.LGTM_CHGE_EXP == null : this.LGTM_CHGE_EXP.equals(that.LGTM_CHGE_EXP));
    equal = equal && (this.LGTM_FIXT_EXP == null ? that.LGTM_FIXT_EXP == null : this.LGTM_FIXT_EXP.equals(that.LGTM_FIXT_EXP));
    equal = equal && (this.PSINS_ATNS_MKVL_AMT == null ? that.PSINS_ATNS_MKVL_AMT == null : this.PSINS_ATNS_MKVL_AMT.equals(that.PSINS_ATNS_MKVL_AMT));
    return equal;
  }
  public void readFields(ResultSet __dbResults) throws SQLException {
    this.__cur_result_set = __dbResults;
    this.CLOG_YYMM = JdbcWritableBridge.readString(1, __dbResults);
    this.STD_DT = JdbcWritableBridge.readTimestamp(2, __dbResults);
    this.CTR_CHNG_STAT_CD = JdbcWritableBridge.readString(3, __dbResults);
    this.POL_NO = JdbcWritableBridge.readString(4, __dbResults);
    this.COV_CD = JdbcWritableBridge.readString(5, __dbResults);
    this.CTR_COV_ID = JdbcWritableBridge.readString(6, __dbResults);
    this.ENDR_NO = JdbcWritableBridge.readBigDecimal(7, __dbResults);
    this.UNT_PD_CD = JdbcWritableBridge.readString(8, __dbResults);
    this.SBCP_YYMM = JdbcWritableBridge.readString(9, __dbResults);
    this.FEE_PAY_TP_CD = JdbcWritableBridge.readString(10, __dbResults);
    this.SBCP_DT = JdbcWritableBridge.readTimestamp(11, __dbResults);
    this.ENDR_DT = JdbcWritableBridge.readTimestamp(12, __dbResults);
    this.DMG_RT_COV_DCTG_CD = JdbcWritableBridge.readString(13, __dbResults);
    this.INS_PRD_TP_CD = JdbcWritableBridge.readString(14, __dbResults);
    this.INS_PRD = JdbcWritableBridge.readBigDecimal(15, __dbResults);
    this.PY_PRD_TP_CD = JdbcWritableBridge.readString(16, __dbResults);
    this.PY_PRD = JdbcWritableBridge.readBigDecimal(17, __dbResults);
    this.PY_CYC_CD = JdbcWritableBridge.readString(18, __dbResults);
    this.SBC_AGE = JdbcWritableBridge.readBigDecimal(19, __dbResults);
    this.GNDR_CD = JdbcWritableBridge.readString(20, __dbResults);
    this.INJR_GR_NUM = JdbcWritableBridge.readBigDecimal(21, __dbResults);
    this.LAST_PY_YYMM = JdbcWritableBridge.readString(22, __dbResults);
    this.LAST_PY_TMS = JdbcWritableBridge.readBigDecimal(23, __dbResults);
    this.RCRT_HDQT_ORG_CD = JdbcWritableBridge.readString(24, __dbResults);
    this.RCRT_BRCH_ORG_CD = JdbcWritableBridge.readString(25, __dbResults);
    this.RCRT_BCH_ORG_CD = JdbcWritableBridge.readString(26, __dbResults);
    this.RCRT_TRTPE_ORG_CD = JdbcWritableBridge.readString(27, __dbResults);
    this.RCRT_AGC_PLNR_CD = JdbcWritableBridge.readString(28, __dbResults);
    this.TRT_HDQT_ORG_CD = JdbcWritableBridge.readString(29, __dbResults);
    this.TRT_BRCH_ORG_CD = JdbcWritableBridge.readString(30, __dbResults);
    this.TRT_BCH_ORG_CD = JdbcWritableBridge.readString(31, __dbResults);
    this.TRTPE_ORG_CD = JdbcWritableBridge.readString(32, __dbResults);
    this.AGC_PLNR_CD = JdbcWritableBridge.readString(33, __dbResults);
    this.HDQT_OPPN_DG_CF = JdbcWritableBridge.readBigDecimal(34, __dbResults);
    this.SLZ_PREM = JdbcWritableBridge.readBigDecimal(35, __dbResults);
    this.IRTD_MKVL_AMT = JdbcWritableBridge.readBigDecimal(36, __dbResults);
    this.BZEX_MKVL_AMT = JdbcWritableBridge.readBigDecimal(37, __dbResults);
    this.RSKEX_MKVL_AMT = JdbcWritableBridge.readBigDecimal(38, __dbResults);
    this.EIH_LDG_DTM = JdbcWritableBridge.readTimestamp(39, __dbResults);
    this.RB_EXP_CPR = JdbcWritableBridge.readBigDecimal(40, __dbResults);
    this.RSK_PREM_CPR = JdbcWritableBridge.readBigDecimal(41, __dbResults);
    this.ORIG_PREM_CPR = JdbcWritableBridge.readBigDecimal(42, __dbResults);
    this.MKVL_CPR = JdbcWritableBridge.readBigDecimal(43, __dbResults);
    this.EXPR_RFD_AMT_CPR = JdbcWritableBridge.readBigDecimal(44, __dbResults);
    this.CLAT_CPR = JdbcWritableBridge.readBigDecimal(45, __dbResults);
    this.SRVL_BNT_CPR = JdbcWritableBridge.readBigDecimal(46, __dbResults);
    this.ANN_PAY_AMT_CPR = JdbcWritableBridge.readBigDecimal(47, __dbResults);
    this.PO_ETPY_CPR = JdbcWritableBridge.readBigDecimal(48, __dbResults);
    this.MNCL_FEE_CPR = JdbcWritableBridge.readBigDecimal(49, __dbResults);
    this.SAV_PREM_CPR = JdbcWritableBridge.readBigDecimal(50, __dbResults);
    this.XACQ_EXP_CPR = JdbcWritableBridge.readBigDecimal(51, __dbResults);
    this.XPT_MTN_EXP_CPR = JdbcWritableBridge.readBigDecimal(52, __dbResults);
    this.XPT_MNCL_EXP_CPR = JdbcWritableBridge.readBigDecimal(53, __dbResults);
    this.INS_AMT_CPR = JdbcWritableBridge.readBigDecimal(54, __dbResults);
    this.NPTPY_NW_CTR_RSLFE_CPR = JdbcWritableBridge.readBigDecimal(55, __dbResults);
    this.NPTPY_ETC_NPO_CPR = JdbcWritableBridge.readBigDecimal(56, __dbResults);
    this.TMN_MGI_CPR = JdbcWritableBridge.readBigDecimal(57, __dbResults);
    this.ACD_ATTM_RDY_AMT_CPR = JdbcWritableBridge.readBigDecimal(58, __dbResults);
    this.PY_EXEM_PREM_CPR = JdbcWritableBridge.readBigDecimal(59, __dbResults);
    this.HFWY_WDR_CPR = JdbcWritableBridge.readBigDecimal(60, __dbResults);
    this.TMN_RSK_PREM_CPR = JdbcWritableBridge.readBigDecimal(61, __dbResults);
    this.LCAT_PD_CLAT_CPR = JdbcWritableBridge.readBigDecimal(62, __dbResults);
    this.TMN_ATTM_RDY_AMT_CPR = JdbcWritableBridge.readBigDecimal(63, __dbResults);
    this.DMN15_WTHN_SLZ_PREM = JdbcWritableBridge.readBigDecimal(64, __dbResults);
    this.DMN15_TMTD_RDY_AMT = JdbcWritableBridge.readBigDecimal(65, __dbResults);
    this.OWN_CTR_YN = JdbcWritableBridge.readString(66, __dbResults);
    this.CTR_CONV_SIC_SBC_YN = JdbcWritableBridge.readString(67, __dbResults);
    this.SBC_AMT = JdbcWritableBridge.readBigDecimal(68, __dbResults);
    this.CRD_FEE_CPR = JdbcWritableBridge.readBigDecimal(69, __dbResults);
    this.CUS_CNTRB_ERN_AMT = JdbcWritableBridge.readBigDecimal(70, __dbResults);
    this.SUM_FEE_CPR = JdbcWritableBridge.readBigDecimal(71, __dbResults);
    this.ITRT_RISK_AMT = JdbcWritableBridge.readBigDecimal(72, __dbResults);
    this.KICS_MKVL_CPR = JdbcWritableBridge.readBigDecimal(73, __dbResults);
    this.ITRT_DEPRC_MKVL_CPR = JdbcWritableBridge.readBigDecimal(74, __dbResults);
    this.ITRT_ASCD_MKVL_CPR = JdbcWritableBridge.readBigDecimal(75, __dbResults);
    this.CTR_INS_PRD_TP_CD = JdbcWritableBridge.readString(76, __dbResults);
    this.MMPY_CNVS_PREM = JdbcWritableBridge.readBigDecimal(77, __dbResults);
    this.PLAN_CD = JdbcWritableBridge.readString(78, __dbResults);
    this.COV_UNT_PD_CD = JdbcWritableBridge.readString(79, __dbResults);
    this.CSS_PREM_CPR = JdbcWritableBridge.readBigDecimal(80, __dbResults);
    this.CSS_INS_AMT_RFD_CPR = JdbcWritableBridge.readBigDecimal(81, __dbResults);
    this.MKVL_BKPM_AMT_CPR = JdbcWritableBridge.readBigDecimal(82, __dbResults);
    this.CSS_RT = JdbcWritableBridge.readBigDecimal(83, __dbResults);
    this.CLF_DIV_CD = JdbcWritableBridge.readString(84, __dbResults);
    this.INS_SBC_SH_CD = JdbcWritableBridge.readString(85, __dbResults);
    this.SBC_DSG_FEE_PAY_TP_CD = JdbcWritableBridge.readString(86, __dbResults);
    this.SBC_DSG_IRTD_MVAT = JdbcWritableBridge.readBigDecimal(87, __dbResults);
    this.SBC_DSG_BZEX_MVAT = JdbcWritableBridge.readBigDecimal(88, __dbResults);
    this.SBC_DSG_RSKEX_MVAT = JdbcWritableBridge.readBigDecimal(89, __dbResults);
    this.SBC_DSG_RB_EXP_CPR = JdbcWritableBridge.readBigDecimal(90, __dbResults);
    this.SBC_DSG_RSK_PREM_CPR = JdbcWritableBridge.readBigDecimal(91, __dbResults);
    this.SBC_DSG_ORIG_PREM_CPR = JdbcWritableBridge.readBigDecimal(92, __dbResults);
    this.SBC_DSG_MKVL_CPR = JdbcWritableBridge.readBigDecimal(93, __dbResults);
    this.LWRT_TMN_RFD_TP_CD = JdbcWritableBridge.readString(94, __dbResults);
    this.LGTM_ITMS_DIV_CD = JdbcWritableBridge.readString(95, __dbResults);
    this.ADVEXP = JdbcWritableBridge.readBigDecimal(96, __dbResults);
    this.TRTPE_TRFR_YN = JdbcWritableBridge.readString(97, __dbResults);
    this.DTBT_CTR_YN = JdbcWritableBridge.readString(98, __dbResults);
    this.INSPE_GRDE_VAL = JdbcWritableBridge.readString(99, __dbResults);
    this.PY_EXEM_TP_CD = JdbcWritableBridge.readString(100, __dbResults);
    this.AMBA_CHN_DIV_CD = JdbcWritableBridge.readString(101, __dbResults);
    this.PSINS_CRD_ETC_FEE = JdbcWritableBridge.readBigDecimal(102, __dbResults);
    this.PSINS_AT_TRS_ETC_FEE = JdbcWritableBridge.readBigDecimal(103, __dbResults);
    this.PSINS_COMS_ETC_FEE = JdbcWritableBridge.readBigDecimal(104, __dbResults);
    this.LGTM_CHGE_EXP = JdbcWritableBridge.readBigDecimal(105, __dbResults);
    this.LGTM_FIXT_EXP = JdbcWritableBridge.readBigDecimal(106, __dbResults);
    this.PSINS_ATNS_MKVL_AMT = JdbcWritableBridge.readBigDecimal(107, __dbResults);
  }
  public void readFields0(ResultSet __dbResults) throws SQLException {
    this.CLOG_YYMM = JdbcWritableBridge.readString(1, __dbResults);
    this.STD_DT = JdbcWritableBridge.readTimestamp(2, __dbResults);
    this.CTR_CHNG_STAT_CD = JdbcWritableBridge.readString(3, __dbResults);
    this.POL_NO = JdbcWritableBridge.readString(4, __dbResults);
    this.COV_CD = JdbcWritableBridge.readString(5, __dbResults);
    this.CTR_COV_ID = JdbcWritableBridge.readString(6, __dbResults);
    this.ENDR_NO = JdbcWritableBridge.readBigDecimal(7, __dbResults);
    this.UNT_PD_CD = JdbcWritableBridge.readString(8, __dbResults);
    this.SBCP_YYMM = JdbcWritableBridge.readString(9, __dbResults);
    this.FEE_PAY_TP_CD = JdbcWritableBridge.readString(10, __dbResults);
    this.SBCP_DT = JdbcWritableBridge.readTimestamp(11, __dbResults);
    this.ENDR_DT = JdbcWritableBridge.readTimestamp(12, __dbResults);
    this.DMG_RT_COV_DCTG_CD = JdbcWritableBridge.readString(13, __dbResults);
    this.INS_PRD_TP_CD = JdbcWritableBridge.readString(14, __dbResults);
    this.INS_PRD = JdbcWritableBridge.readBigDecimal(15, __dbResults);
    this.PY_PRD_TP_CD = JdbcWritableBridge.readString(16, __dbResults);
    this.PY_PRD = JdbcWritableBridge.readBigDecimal(17, __dbResults);
    this.PY_CYC_CD = JdbcWritableBridge.readString(18, __dbResults);
    this.SBC_AGE = JdbcWritableBridge.readBigDecimal(19, __dbResults);
    this.GNDR_CD = JdbcWritableBridge.readString(20, __dbResults);
    this.INJR_GR_NUM = JdbcWritableBridge.readBigDecimal(21, __dbResults);
    this.LAST_PY_YYMM = JdbcWritableBridge.readString(22, __dbResults);
    this.LAST_PY_TMS = JdbcWritableBridge.readBigDecimal(23, __dbResults);
    this.RCRT_HDQT_ORG_CD = JdbcWritableBridge.readString(24, __dbResults);
    this.RCRT_BRCH_ORG_CD = JdbcWritableBridge.readString(25, __dbResults);
    this.RCRT_BCH_ORG_CD = JdbcWritableBridge.readString(26, __dbResults);
    this.RCRT_TRTPE_ORG_CD = JdbcWritableBridge.readString(27, __dbResults);
    this.RCRT_AGC_PLNR_CD = JdbcWritableBridge.readString(28, __dbResults);
    this.TRT_HDQT_ORG_CD = JdbcWritableBridge.readString(29, __dbResults);
    this.TRT_BRCH_ORG_CD = JdbcWritableBridge.readString(30, __dbResults);
    this.TRT_BCH_ORG_CD = JdbcWritableBridge.readString(31, __dbResults);
    this.TRTPE_ORG_CD = JdbcWritableBridge.readString(32, __dbResults);
    this.AGC_PLNR_CD = JdbcWritableBridge.readString(33, __dbResults);
    this.HDQT_OPPN_DG_CF = JdbcWritableBridge.readBigDecimal(34, __dbResults);
    this.SLZ_PREM = JdbcWritableBridge.readBigDecimal(35, __dbResults);
    this.IRTD_MKVL_AMT = JdbcWritableBridge.readBigDecimal(36, __dbResults);
    this.BZEX_MKVL_AMT = JdbcWritableBridge.readBigDecimal(37, __dbResults);
    this.RSKEX_MKVL_AMT = JdbcWritableBridge.readBigDecimal(38, __dbResults);
    this.EIH_LDG_DTM = JdbcWritableBridge.readTimestamp(39, __dbResults);
    this.RB_EXP_CPR = JdbcWritableBridge.readBigDecimal(40, __dbResults);
    this.RSK_PREM_CPR = JdbcWritableBridge.readBigDecimal(41, __dbResults);
    this.ORIG_PREM_CPR = JdbcWritableBridge.readBigDecimal(42, __dbResults);
    this.MKVL_CPR = JdbcWritableBridge.readBigDecimal(43, __dbResults);
    this.EXPR_RFD_AMT_CPR = JdbcWritableBridge.readBigDecimal(44, __dbResults);
    this.CLAT_CPR = JdbcWritableBridge.readBigDecimal(45, __dbResults);
    this.SRVL_BNT_CPR = JdbcWritableBridge.readBigDecimal(46, __dbResults);
    this.ANN_PAY_AMT_CPR = JdbcWritableBridge.readBigDecimal(47, __dbResults);
    this.PO_ETPY_CPR = JdbcWritableBridge.readBigDecimal(48, __dbResults);
    this.MNCL_FEE_CPR = JdbcWritableBridge.readBigDecimal(49, __dbResults);
    this.SAV_PREM_CPR = JdbcWritableBridge.readBigDecimal(50, __dbResults);
    this.XACQ_EXP_CPR = JdbcWritableBridge.readBigDecimal(51, __dbResults);
    this.XPT_MTN_EXP_CPR = JdbcWritableBridge.readBigDecimal(52, __dbResults);
    this.XPT_MNCL_EXP_CPR = JdbcWritableBridge.readBigDecimal(53, __dbResults);
    this.INS_AMT_CPR = JdbcWritableBridge.readBigDecimal(54, __dbResults);
    this.NPTPY_NW_CTR_RSLFE_CPR = JdbcWritableBridge.readBigDecimal(55, __dbResults);
    this.NPTPY_ETC_NPO_CPR = JdbcWritableBridge.readBigDecimal(56, __dbResults);
    this.TMN_MGI_CPR = JdbcWritableBridge.readBigDecimal(57, __dbResults);
    this.ACD_ATTM_RDY_AMT_CPR = JdbcWritableBridge.readBigDecimal(58, __dbResults);
    this.PY_EXEM_PREM_CPR = JdbcWritableBridge.readBigDecimal(59, __dbResults);
    this.HFWY_WDR_CPR = JdbcWritableBridge.readBigDecimal(60, __dbResults);
    this.TMN_RSK_PREM_CPR = JdbcWritableBridge.readBigDecimal(61, __dbResults);
    this.LCAT_PD_CLAT_CPR = JdbcWritableBridge.readBigDecimal(62, __dbResults);
    this.TMN_ATTM_RDY_AMT_CPR = JdbcWritableBridge.readBigDecimal(63, __dbResults);
    this.DMN15_WTHN_SLZ_PREM = JdbcWritableBridge.readBigDecimal(64, __dbResults);
    this.DMN15_TMTD_RDY_AMT = JdbcWritableBridge.readBigDecimal(65, __dbResults);
    this.OWN_CTR_YN = JdbcWritableBridge.readString(66, __dbResults);
    this.CTR_CONV_SIC_SBC_YN = JdbcWritableBridge.readString(67, __dbResults);
    this.SBC_AMT = JdbcWritableBridge.readBigDecimal(68, __dbResults);
    this.CRD_FEE_CPR = JdbcWritableBridge.readBigDecimal(69, __dbResults);
    this.CUS_CNTRB_ERN_AMT = JdbcWritableBridge.readBigDecimal(70, __dbResults);
    this.SUM_FEE_CPR = JdbcWritableBridge.readBigDecimal(71, __dbResults);
    this.ITRT_RISK_AMT = JdbcWritableBridge.readBigDecimal(72, __dbResults);
    this.KICS_MKVL_CPR = JdbcWritableBridge.readBigDecimal(73, __dbResults);
    this.ITRT_DEPRC_MKVL_CPR = JdbcWritableBridge.readBigDecimal(74, __dbResults);
    this.ITRT_ASCD_MKVL_CPR = JdbcWritableBridge.readBigDecimal(75, __dbResults);
    this.CTR_INS_PRD_TP_CD = JdbcWritableBridge.readString(76, __dbResults);
    this.MMPY_CNVS_PREM = JdbcWritableBridge.readBigDecimal(77, __dbResults);
    this.PLAN_CD = JdbcWritableBridge.readString(78, __dbResults);
    this.COV_UNT_PD_CD = JdbcWritableBridge.readString(79, __dbResults);
    this.CSS_PREM_CPR = JdbcWritableBridge.readBigDecimal(80, __dbResults);
    this.CSS_INS_AMT_RFD_CPR = JdbcWritableBridge.readBigDecimal(81, __dbResults);
    this.MKVL_BKPM_AMT_CPR = JdbcWritableBridge.readBigDecimal(82, __dbResults);
    this.CSS_RT = JdbcWritableBridge.readBigDecimal(83, __dbResults);
    this.CLF_DIV_CD = JdbcWritableBridge.readString(84, __dbResults);
    this.INS_SBC_SH_CD = JdbcWritableBridge.readString(85, __dbResults);
    this.SBC_DSG_FEE_PAY_TP_CD = JdbcWritableBridge.readString(86, __dbResults);
    this.SBC_DSG_IRTD_MVAT = JdbcWritableBridge.readBigDecimal(87, __dbResults);
    this.SBC_DSG_BZEX_MVAT = JdbcWritableBridge.readBigDecimal(88, __dbResults);
    this.SBC_DSG_RSKEX_MVAT = JdbcWritableBridge.readBigDecimal(89, __dbResults);
    this.SBC_DSG_RB_EXP_CPR = JdbcWritableBridge.readBigDecimal(90, __dbResults);
    this.SBC_DSG_RSK_PREM_CPR = JdbcWritableBridge.readBigDecimal(91, __dbResults);
    this.SBC_DSG_ORIG_PREM_CPR = JdbcWritableBridge.readBigDecimal(92, __dbResults);
    this.SBC_DSG_MKVL_CPR = JdbcWritableBridge.readBigDecimal(93, __dbResults);
    this.LWRT_TMN_RFD_TP_CD = JdbcWritableBridge.readString(94, __dbResults);
    this.LGTM_ITMS_DIV_CD = JdbcWritableBridge.readString(95, __dbResults);
    this.ADVEXP = JdbcWritableBridge.readBigDecimal(96, __dbResults);
    this.TRTPE_TRFR_YN = JdbcWritableBridge.readString(97, __dbResults);
    this.DTBT_CTR_YN = JdbcWritableBridge.readString(98, __dbResults);
    this.INSPE_GRDE_VAL = JdbcWritableBridge.readString(99, __dbResults);
    this.PY_EXEM_TP_CD = JdbcWritableBridge.readString(100, __dbResults);
    this.AMBA_CHN_DIV_CD = JdbcWritableBridge.readString(101, __dbResults);
    this.PSINS_CRD_ETC_FEE = JdbcWritableBridge.readBigDecimal(102, __dbResults);
    this.PSINS_AT_TRS_ETC_FEE = JdbcWritableBridge.readBigDecimal(103, __dbResults);
    this.PSINS_COMS_ETC_FEE = JdbcWritableBridge.readBigDecimal(104, __dbResults);
    this.LGTM_CHGE_EXP = JdbcWritableBridge.readBigDecimal(105, __dbResults);
    this.LGTM_FIXT_EXP = JdbcWritableBridge.readBigDecimal(106, __dbResults);
    this.PSINS_ATNS_MKVL_AMT = JdbcWritableBridge.readBigDecimal(107, __dbResults);
  }
  public void loadLargeObjects(LargeObjectLoader __loader)
      throws SQLException, IOException, InterruptedException {
  }
  public void loadLargeObjects0(LargeObjectLoader __loader)
      throws SQLException, IOException, InterruptedException {
  }
  public void write(PreparedStatement __dbStmt) throws SQLException {
    write(__dbStmt, 0);
  }

  public int write(PreparedStatement __dbStmt, int __off) throws SQLException {
    JdbcWritableBridge.writeString(CLOG_YYMM, 1 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeTimestamp(STD_DT, 2 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeString(CTR_CHNG_STAT_CD, 3 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(POL_NO, 4 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(COV_CD, 5 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(CTR_COV_ID, 6 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(ENDR_NO, 7 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(UNT_PD_CD, 8 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(SBCP_YYMM, 9 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(FEE_PAY_TP_CD, 10 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeTimestamp(SBCP_DT, 11 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeTimestamp(ENDR_DT, 12 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeString(DMG_RT_COV_DCTG_CD, 13 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(INS_PRD_TP_CD, 14 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(INS_PRD, 15 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(PY_PRD_TP_CD, 16 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(PY_PRD, 17 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(PY_CYC_CD, 18 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(SBC_AGE, 19 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(GNDR_CD, 20 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(INJR_GR_NUM, 21 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(LAST_PY_YYMM, 22 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(LAST_PY_TMS, 23 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(RCRT_HDQT_ORG_CD, 24 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(RCRT_BRCH_ORG_CD, 25 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(RCRT_BCH_ORG_CD, 26 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(RCRT_TRTPE_ORG_CD, 27 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(RCRT_AGC_PLNR_CD, 28 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(TRT_HDQT_ORG_CD, 29 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(TRT_BRCH_ORG_CD, 30 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(TRT_BCH_ORG_CD, 31 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(TRTPE_ORG_CD, 32 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(AGC_PLNR_CD, 33 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(HDQT_OPPN_DG_CF, 34 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(SLZ_PREM, 35 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(IRTD_MKVL_AMT, 36 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(BZEX_MKVL_AMT, 37 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(RSKEX_MKVL_AMT, 38 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeTimestamp(EIH_LDG_DTM, 39 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(RB_EXP_CPR, 40 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(RSK_PREM_CPR, 41 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(ORIG_PREM_CPR, 42 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(MKVL_CPR, 43 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(EXPR_RFD_AMT_CPR, 44 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(CLAT_CPR, 45 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(SRVL_BNT_CPR, 46 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(ANN_PAY_AMT_CPR, 47 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(PO_ETPY_CPR, 48 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(MNCL_FEE_CPR, 49 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(SAV_PREM_CPR, 50 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(XACQ_EXP_CPR, 51 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(XPT_MTN_EXP_CPR, 52 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(XPT_MNCL_EXP_CPR, 53 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(INS_AMT_CPR, 54 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(NPTPY_NW_CTR_RSLFE_CPR, 55 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(NPTPY_ETC_NPO_CPR, 56 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(TMN_MGI_CPR, 57 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(ACD_ATTM_RDY_AMT_CPR, 58 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(PY_EXEM_PREM_CPR, 59 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(HFWY_WDR_CPR, 60 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(TMN_RSK_PREM_CPR, 61 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(LCAT_PD_CLAT_CPR, 62 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(TMN_ATTM_RDY_AMT_CPR, 63 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(DMN15_WTHN_SLZ_PREM, 64 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(DMN15_TMTD_RDY_AMT, 65 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(OWN_CTR_YN, 66 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(CTR_CONV_SIC_SBC_YN, 67 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(SBC_AMT, 68 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(CRD_FEE_CPR, 69 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(CUS_CNTRB_ERN_AMT, 70 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(SUM_FEE_CPR, 71 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(ITRT_RISK_AMT, 72 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(KICS_MKVL_CPR, 73 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(ITRT_DEPRC_MKVL_CPR, 74 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(ITRT_ASCD_MKVL_CPR, 75 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(CTR_INS_PRD_TP_CD, 76 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(MMPY_CNVS_PREM, 77 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(PLAN_CD, 78 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(COV_UNT_PD_CD, 79 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(CSS_PREM_CPR, 80 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(CSS_INS_AMT_RFD_CPR, 81 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(MKVL_BKPM_AMT_CPR, 82 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(CSS_RT, 83 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(CLF_DIV_CD, 84 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(INS_SBC_SH_CD, 85 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(SBC_DSG_FEE_PAY_TP_CD, 86 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(SBC_DSG_IRTD_MVAT, 87 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(SBC_DSG_BZEX_MVAT, 88 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(SBC_DSG_RSKEX_MVAT, 89 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(SBC_DSG_RB_EXP_CPR, 90 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(SBC_DSG_RSK_PREM_CPR, 91 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(SBC_DSG_ORIG_PREM_CPR, 92 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(SBC_DSG_MKVL_CPR, 93 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(LWRT_TMN_RFD_TP_CD, 94 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(LGTM_ITMS_DIV_CD, 95 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(ADVEXP, 96 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(TRTPE_TRFR_YN, 97 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(DTBT_CTR_YN, 98 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(INSPE_GRDE_VAL, 99 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(PY_EXEM_TP_CD, 100 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(AMBA_CHN_DIV_CD, 101 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(PSINS_CRD_ETC_FEE, 102 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(PSINS_AT_TRS_ETC_FEE, 103 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(PSINS_COMS_ETC_FEE, 104 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(LGTM_CHGE_EXP, 105 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(LGTM_FIXT_EXP, 106 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(PSINS_ATNS_MKVL_AMT, 107 + __off, 2, __dbStmt);
    return 107;
  }
  public void write0(PreparedStatement __dbStmt, int __off) throws SQLException {
    JdbcWritableBridge.writeString(CLOG_YYMM, 1 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeTimestamp(STD_DT, 2 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeString(CTR_CHNG_STAT_CD, 3 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(POL_NO, 4 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(COV_CD, 5 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(CTR_COV_ID, 6 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(ENDR_NO, 7 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(UNT_PD_CD, 8 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(SBCP_YYMM, 9 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(FEE_PAY_TP_CD, 10 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeTimestamp(SBCP_DT, 11 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeTimestamp(ENDR_DT, 12 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeString(DMG_RT_COV_DCTG_CD, 13 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(INS_PRD_TP_CD, 14 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(INS_PRD, 15 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(PY_PRD_TP_CD, 16 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(PY_PRD, 17 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(PY_CYC_CD, 18 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(SBC_AGE, 19 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(GNDR_CD, 20 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(INJR_GR_NUM, 21 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(LAST_PY_YYMM, 22 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(LAST_PY_TMS, 23 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(RCRT_HDQT_ORG_CD, 24 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(RCRT_BRCH_ORG_CD, 25 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(RCRT_BCH_ORG_CD, 26 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(RCRT_TRTPE_ORG_CD, 27 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(RCRT_AGC_PLNR_CD, 28 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(TRT_HDQT_ORG_CD, 29 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(TRT_BRCH_ORG_CD, 30 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(TRT_BCH_ORG_CD, 31 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(TRTPE_ORG_CD, 32 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(AGC_PLNR_CD, 33 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(HDQT_OPPN_DG_CF, 34 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(SLZ_PREM, 35 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(IRTD_MKVL_AMT, 36 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(BZEX_MKVL_AMT, 37 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(RSKEX_MKVL_AMT, 38 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeTimestamp(EIH_LDG_DTM, 39 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(RB_EXP_CPR, 40 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(RSK_PREM_CPR, 41 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(ORIG_PREM_CPR, 42 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(MKVL_CPR, 43 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(EXPR_RFD_AMT_CPR, 44 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(CLAT_CPR, 45 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(SRVL_BNT_CPR, 46 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(ANN_PAY_AMT_CPR, 47 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(PO_ETPY_CPR, 48 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(MNCL_FEE_CPR, 49 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(SAV_PREM_CPR, 50 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(XACQ_EXP_CPR, 51 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(XPT_MTN_EXP_CPR, 52 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(XPT_MNCL_EXP_CPR, 53 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(INS_AMT_CPR, 54 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(NPTPY_NW_CTR_RSLFE_CPR, 55 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(NPTPY_ETC_NPO_CPR, 56 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(TMN_MGI_CPR, 57 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(ACD_ATTM_RDY_AMT_CPR, 58 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(PY_EXEM_PREM_CPR, 59 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(HFWY_WDR_CPR, 60 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(TMN_RSK_PREM_CPR, 61 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(LCAT_PD_CLAT_CPR, 62 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(TMN_ATTM_RDY_AMT_CPR, 63 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(DMN15_WTHN_SLZ_PREM, 64 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(DMN15_TMTD_RDY_AMT, 65 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(OWN_CTR_YN, 66 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(CTR_CONV_SIC_SBC_YN, 67 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(SBC_AMT, 68 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(CRD_FEE_CPR, 69 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(CUS_CNTRB_ERN_AMT, 70 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(SUM_FEE_CPR, 71 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(ITRT_RISK_AMT, 72 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(KICS_MKVL_CPR, 73 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(ITRT_DEPRC_MKVL_CPR, 74 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(ITRT_ASCD_MKVL_CPR, 75 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(CTR_INS_PRD_TP_CD, 76 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(MMPY_CNVS_PREM, 77 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(PLAN_CD, 78 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(COV_UNT_PD_CD, 79 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(CSS_PREM_CPR, 80 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(CSS_INS_AMT_RFD_CPR, 81 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(MKVL_BKPM_AMT_CPR, 82 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(CSS_RT, 83 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(CLF_DIV_CD, 84 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(INS_SBC_SH_CD, 85 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(SBC_DSG_FEE_PAY_TP_CD, 86 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(SBC_DSG_IRTD_MVAT, 87 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(SBC_DSG_BZEX_MVAT, 88 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(SBC_DSG_RSKEX_MVAT, 89 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(SBC_DSG_RB_EXP_CPR, 90 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(SBC_DSG_RSK_PREM_CPR, 91 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(SBC_DSG_ORIG_PREM_CPR, 92 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(SBC_DSG_MKVL_CPR, 93 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(LWRT_TMN_RFD_TP_CD, 94 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(LGTM_ITMS_DIV_CD, 95 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(ADVEXP, 96 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(TRTPE_TRFR_YN, 97 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(DTBT_CTR_YN, 98 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(INSPE_GRDE_VAL, 99 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(PY_EXEM_TP_CD, 100 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(AMBA_CHN_DIV_CD, 101 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(PSINS_CRD_ETC_FEE, 102 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(PSINS_AT_TRS_ETC_FEE, 103 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(PSINS_COMS_ETC_FEE, 104 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(LGTM_CHGE_EXP, 105 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(LGTM_FIXT_EXP, 106 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(PSINS_ATNS_MKVL_AMT, 107 + __off, 2, __dbStmt);
  }
  public void readFields(DataInput __dataIn) throws IOException {
this.readFields0(__dataIn);  }
  public void readFields0(DataInput __dataIn) throws IOException {
    if (__dataIn.readBoolean()) { 
        this.CLOG_YYMM = null;
    } else {
    this.CLOG_YYMM = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.STD_DT = null;
    } else {
    this.STD_DT = new Timestamp(__dataIn.readLong());
    this.STD_DT.setNanos(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.CTR_CHNG_STAT_CD = null;
    } else {
    this.CTR_CHNG_STAT_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.POL_NO = null;
    } else {
    this.POL_NO = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.COV_CD = null;
    } else {
    this.COV_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.CTR_COV_ID = null;
    } else {
    this.CTR_COV_ID = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.ENDR_NO = null;
    } else {
    this.ENDR_NO = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.UNT_PD_CD = null;
    } else {
    this.UNT_PD_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.SBCP_YYMM = null;
    } else {
    this.SBCP_YYMM = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.FEE_PAY_TP_CD = null;
    } else {
    this.FEE_PAY_TP_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.SBCP_DT = null;
    } else {
    this.SBCP_DT = new Timestamp(__dataIn.readLong());
    this.SBCP_DT.setNanos(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.ENDR_DT = null;
    } else {
    this.ENDR_DT = new Timestamp(__dataIn.readLong());
    this.ENDR_DT.setNanos(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.DMG_RT_COV_DCTG_CD = null;
    } else {
    this.DMG_RT_COV_DCTG_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.INS_PRD_TP_CD = null;
    } else {
    this.INS_PRD_TP_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.INS_PRD = null;
    } else {
    this.INS_PRD = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.PY_PRD_TP_CD = null;
    } else {
    this.PY_PRD_TP_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.PY_PRD = null;
    } else {
    this.PY_PRD = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.PY_CYC_CD = null;
    } else {
    this.PY_CYC_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.SBC_AGE = null;
    } else {
    this.SBC_AGE = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.GNDR_CD = null;
    } else {
    this.GNDR_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.INJR_GR_NUM = null;
    } else {
    this.INJR_GR_NUM = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.LAST_PY_YYMM = null;
    } else {
    this.LAST_PY_YYMM = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.LAST_PY_TMS = null;
    } else {
    this.LAST_PY_TMS = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RCRT_HDQT_ORG_CD = null;
    } else {
    this.RCRT_HDQT_ORG_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RCRT_BRCH_ORG_CD = null;
    } else {
    this.RCRT_BRCH_ORG_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RCRT_BCH_ORG_CD = null;
    } else {
    this.RCRT_BCH_ORG_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RCRT_TRTPE_ORG_CD = null;
    } else {
    this.RCRT_TRTPE_ORG_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RCRT_AGC_PLNR_CD = null;
    } else {
    this.RCRT_AGC_PLNR_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.TRT_HDQT_ORG_CD = null;
    } else {
    this.TRT_HDQT_ORG_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.TRT_BRCH_ORG_CD = null;
    } else {
    this.TRT_BRCH_ORG_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.TRT_BCH_ORG_CD = null;
    } else {
    this.TRT_BCH_ORG_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.TRTPE_ORG_CD = null;
    } else {
    this.TRTPE_ORG_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.AGC_PLNR_CD = null;
    } else {
    this.AGC_PLNR_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.HDQT_OPPN_DG_CF = null;
    } else {
    this.HDQT_OPPN_DG_CF = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.SLZ_PREM = null;
    } else {
    this.SLZ_PREM = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.IRTD_MKVL_AMT = null;
    } else {
    this.IRTD_MKVL_AMT = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.BZEX_MKVL_AMT = null;
    } else {
    this.BZEX_MKVL_AMT = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RSKEX_MKVL_AMT = null;
    } else {
    this.RSKEX_MKVL_AMT = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.EIH_LDG_DTM = null;
    } else {
    this.EIH_LDG_DTM = new Timestamp(__dataIn.readLong());
    this.EIH_LDG_DTM.setNanos(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.RB_EXP_CPR = null;
    } else {
    this.RB_EXP_CPR = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RSK_PREM_CPR = null;
    } else {
    this.RSK_PREM_CPR = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.ORIG_PREM_CPR = null;
    } else {
    this.ORIG_PREM_CPR = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.MKVL_CPR = null;
    } else {
    this.MKVL_CPR = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.EXPR_RFD_AMT_CPR = null;
    } else {
    this.EXPR_RFD_AMT_CPR = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.CLAT_CPR = null;
    } else {
    this.CLAT_CPR = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.SRVL_BNT_CPR = null;
    } else {
    this.SRVL_BNT_CPR = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.ANN_PAY_AMT_CPR = null;
    } else {
    this.ANN_PAY_AMT_CPR = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.PO_ETPY_CPR = null;
    } else {
    this.PO_ETPY_CPR = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.MNCL_FEE_CPR = null;
    } else {
    this.MNCL_FEE_CPR = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.SAV_PREM_CPR = null;
    } else {
    this.SAV_PREM_CPR = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.XACQ_EXP_CPR = null;
    } else {
    this.XACQ_EXP_CPR = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.XPT_MTN_EXP_CPR = null;
    } else {
    this.XPT_MTN_EXP_CPR = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.XPT_MNCL_EXP_CPR = null;
    } else {
    this.XPT_MNCL_EXP_CPR = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.INS_AMT_CPR = null;
    } else {
    this.INS_AMT_CPR = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.NPTPY_NW_CTR_RSLFE_CPR = null;
    } else {
    this.NPTPY_NW_CTR_RSLFE_CPR = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.NPTPY_ETC_NPO_CPR = null;
    } else {
    this.NPTPY_ETC_NPO_CPR = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.TMN_MGI_CPR = null;
    } else {
    this.TMN_MGI_CPR = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.ACD_ATTM_RDY_AMT_CPR = null;
    } else {
    this.ACD_ATTM_RDY_AMT_CPR = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.PY_EXEM_PREM_CPR = null;
    } else {
    this.PY_EXEM_PREM_CPR = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.HFWY_WDR_CPR = null;
    } else {
    this.HFWY_WDR_CPR = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.TMN_RSK_PREM_CPR = null;
    } else {
    this.TMN_RSK_PREM_CPR = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.LCAT_PD_CLAT_CPR = null;
    } else {
    this.LCAT_PD_CLAT_CPR = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.TMN_ATTM_RDY_AMT_CPR = null;
    } else {
    this.TMN_ATTM_RDY_AMT_CPR = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.DMN15_WTHN_SLZ_PREM = null;
    } else {
    this.DMN15_WTHN_SLZ_PREM = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.DMN15_TMTD_RDY_AMT = null;
    } else {
    this.DMN15_TMTD_RDY_AMT = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.OWN_CTR_YN = null;
    } else {
    this.OWN_CTR_YN = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.CTR_CONV_SIC_SBC_YN = null;
    } else {
    this.CTR_CONV_SIC_SBC_YN = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.SBC_AMT = null;
    } else {
    this.SBC_AMT = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.CRD_FEE_CPR = null;
    } else {
    this.CRD_FEE_CPR = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.CUS_CNTRB_ERN_AMT = null;
    } else {
    this.CUS_CNTRB_ERN_AMT = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.SUM_FEE_CPR = null;
    } else {
    this.SUM_FEE_CPR = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.ITRT_RISK_AMT = null;
    } else {
    this.ITRT_RISK_AMT = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.KICS_MKVL_CPR = null;
    } else {
    this.KICS_MKVL_CPR = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.ITRT_DEPRC_MKVL_CPR = null;
    } else {
    this.ITRT_DEPRC_MKVL_CPR = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.ITRT_ASCD_MKVL_CPR = null;
    } else {
    this.ITRT_ASCD_MKVL_CPR = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.CTR_INS_PRD_TP_CD = null;
    } else {
    this.CTR_INS_PRD_TP_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.MMPY_CNVS_PREM = null;
    } else {
    this.MMPY_CNVS_PREM = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.PLAN_CD = null;
    } else {
    this.PLAN_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.COV_UNT_PD_CD = null;
    } else {
    this.COV_UNT_PD_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.CSS_PREM_CPR = null;
    } else {
    this.CSS_PREM_CPR = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.CSS_INS_AMT_RFD_CPR = null;
    } else {
    this.CSS_INS_AMT_RFD_CPR = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.MKVL_BKPM_AMT_CPR = null;
    } else {
    this.MKVL_BKPM_AMT_CPR = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.CSS_RT = null;
    } else {
    this.CSS_RT = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.CLF_DIV_CD = null;
    } else {
    this.CLF_DIV_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.INS_SBC_SH_CD = null;
    } else {
    this.INS_SBC_SH_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.SBC_DSG_FEE_PAY_TP_CD = null;
    } else {
    this.SBC_DSG_FEE_PAY_TP_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.SBC_DSG_IRTD_MVAT = null;
    } else {
    this.SBC_DSG_IRTD_MVAT = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.SBC_DSG_BZEX_MVAT = null;
    } else {
    this.SBC_DSG_BZEX_MVAT = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.SBC_DSG_RSKEX_MVAT = null;
    } else {
    this.SBC_DSG_RSKEX_MVAT = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.SBC_DSG_RB_EXP_CPR = null;
    } else {
    this.SBC_DSG_RB_EXP_CPR = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.SBC_DSG_RSK_PREM_CPR = null;
    } else {
    this.SBC_DSG_RSK_PREM_CPR = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.SBC_DSG_ORIG_PREM_CPR = null;
    } else {
    this.SBC_DSG_ORIG_PREM_CPR = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.SBC_DSG_MKVL_CPR = null;
    } else {
    this.SBC_DSG_MKVL_CPR = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.LWRT_TMN_RFD_TP_CD = null;
    } else {
    this.LWRT_TMN_RFD_TP_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.LGTM_ITMS_DIV_CD = null;
    } else {
    this.LGTM_ITMS_DIV_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.ADVEXP = null;
    } else {
    this.ADVEXP = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.TRTPE_TRFR_YN = null;
    } else {
    this.TRTPE_TRFR_YN = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.DTBT_CTR_YN = null;
    } else {
    this.DTBT_CTR_YN = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.INSPE_GRDE_VAL = null;
    } else {
    this.INSPE_GRDE_VAL = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.PY_EXEM_TP_CD = null;
    } else {
    this.PY_EXEM_TP_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.AMBA_CHN_DIV_CD = null;
    } else {
    this.AMBA_CHN_DIV_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.PSINS_CRD_ETC_FEE = null;
    } else {
    this.PSINS_CRD_ETC_FEE = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.PSINS_AT_TRS_ETC_FEE = null;
    } else {
    this.PSINS_AT_TRS_ETC_FEE = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.PSINS_COMS_ETC_FEE = null;
    } else {
    this.PSINS_COMS_ETC_FEE = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.LGTM_CHGE_EXP = null;
    } else {
    this.LGTM_CHGE_EXP = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.LGTM_FIXT_EXP = null;
    } else {
    this.LGTM_FIXT_EXP = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.PSINS_ATNS_MKVL_AMT = null;
    } else {
    this.PSINS_ATNS_MKVL_AMT = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
  }
  public void write(DataOutput __dataOut) throws IOException {
    if (null == this.CLOG_YYMM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CLOG_YYMM);
    }
    if (null == this.STD_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.STD_DT.getTime());
    __dataOut.writeInt(this.STD_DT.getNanos());
    }
    if (null == this.CTR_CHNG_STAT_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CTR_CHNG_STAT_CD);
    }
    if (null == this.POL_NO) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, POL_NO);
    }
    if (null == this.COV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, COV_CD);
    }
    if (null == this.CTR_COV_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CTR_COV_ID);
    }
    if (null == this.ENDR_NO) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.ENDR_NO, __dataOut);
    }
    if (null == this.UNT_PD_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, UNT_PD_CD);
    }
    if (null == this.SBCP_YYMM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, SBCP_YYMM);
    }
    if (null == this.FEE_PAY_TP_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, FEE_PAY_TP_CD);
    }
    if (null == this.SBCP_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.SBCP_DT.getTime());
    __dataOut.writeInt(this.SBCP_DT.getNanos());
    }
    if (null == this.ENDR_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.ENDR_DT.getTime());
    __dataOut.writeInt(this.ENDR_DT.getNanos());
    }
    if (null == this.DMG_RT_COV_DCTG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, DMG_RT_COV_DCTG_CD);
    }
    if (null == this.INS_PRD_TP_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, INS_PRD_TP_CD);
    }
    if (null == this.INS_PRD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.INS_PRD, __dataOut);
    }
    if (null == this.PY_PRD_TP_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, PY_PRD_TP_CD);
    }
    if (null == this.PY_PRD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.PY_PRD, __dataOut);
    }
    if (null == this.PY_CYC_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, PY_CYC_CD);
    }
    if (null == this.SBC_AGE) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.SBC_AGE, __dataOut);
    }
    if (null == this.GNDR_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, GNDR_CD);
    }
    if (null == this.INJR_GR_NUM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.INJR_GR_NUM, __dataOut);
    }
    if (null == this.LAST_PY_YYMM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, LAST_PY_YYMM);
    }
    if (null == this.LAST_PY_TMS) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.LAST_PY_TMS, __dataOut);
    }
    if (null == this.RCRT_HDQT_ORG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RCRT_HDQT_ORG_CD);
    }
    if (null == this.RCRT_BRCH_ORG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RCRT_BRCH_ORG_CD);
    }
    if (null == this.RCRT_BCH_ORG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RCRT_BCH_ORG_CD);
    }
    if (null == this.RCRT_TRTPE_ORG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RCRT_TRTPE_ORG_CD);
    }
    if (null == this.RCRT_AGC_PLNR_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RCRT_AGC_PLNR_CD);
    }
    if (null == this.TRT_HDQT_ORG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, TRT_HDQT_ORG_CD);
    }
    if (null == this.TRT_BRCH_ORG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, TRT_BRCH_ORG_CD);
    }
    if (null == this.TRT_BCH_ORG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, TRT_BCH_ORG_CD);
    }
    if (null == this.TRTPE_ORG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, TRTPE_ORG_CD);
    }
    if (null == this.AGC_PLNR_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, AGC_PLNR_CD);
    }
    if (null == this.HDQT_OPPN_DG_CF) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.HDQT_OPPN_DG_CF, __dataOut);
    }
    if (null == this.SLZ_PREM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.SLZ_PREM, __dataOut);
    }
    if (null == this.IRTD_MKVL_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.IRTD_MKVL_AMT, __dataOut);
    }
    if (null == this.BZEX_MKVL_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.BZEX_MKVL_AMT, __dataOut);
    }
    if (null == this.RSKEX_MKVL_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.RSKEX_MKVL_AMT, __dataOut);
    }
    if (null == this.EIH_LDG_DTM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.EIH_LDG_DTM.getTime());
    __dataOut.writeInt(this.EIH_LDG_DTM.getNanos());
    }
    if (null == this.RB_EXP_CPR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.RB_EXP_CPR, __dataOut);
    }
    if (null == this.RSK_PREM_CPR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.RSK_PREM_CPR, __dataOut);
    }
    if (null == this.ORIG_PREM_CPR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.ORIG_PREM_CPR, __dataOut);
    }
    if (null == this.MKVL_CPR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.MKVL_CPR, __dataOut);
    }
    if (null == this.EXPR_RFD_AMT_CPR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.EXPR_RFD_AMT_CPR, __dataOut);
    }
    if (null == this.CLAT_CPR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.CLAT_CPR, __dataOut);
    }
    if (null == this.SRVL_BNT_CPR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.SRVL_BNT_CPR, __dataOut);
    }
    if (null == this.ANN_PAY_AMT_CPR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.ANN_PAY_AMT_CPR, __dataOut);
    }
    if (null == this.PO_ETPY_CPR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.PO_ETPY_CPR, __dataOut);
    }
    if (null == this.MNCL_FEE_CPR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.MNCL_FEE_CPR, __dataOut);
    }
    if (null == this.SAV_PREM_CPR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.SAV_PREM_CPR, __dataOut);
    }
    if (null == this.XACQ_EXP_CPR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.XACQ_EXP_CPR, __dataOut);
    }
    if (null == this.XPT_MTN_EXP_CPR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.XPT_MTN_EXP_CPR, __dataOut);
    }
    if (null == this.XPT_MNCL_EXP_CPR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.XPT_MNCL_EXP_CPR, __dataOut);
    }
    if (null == this.INS_AMT_CPR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.INS_AMT_CPR, __dataOut);
    }
    if (null == this.NPTPY_NW_CTR_RSLFE_CPR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.NPTPY_NW_CTR_RSLFE_CPR, __dataOut);
    }
    if (null == this.NPTPY_ETC_NPO_CPR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.NPTPY_ETC_NPO_CPR, __dataOut);
    }
    if (null == this.TMN_MGI_CPR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.TMN_MGI_CPR, __dataOut);
    }
    if (null == this.ACD_ATTM_RDY_AMT_CPR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.ACD_ATTM_RDY_AMT_CPR, __dataOut);
    }
    if (null == this.PY_EXEM_PREM_CPR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.PY_EXEM_PREM_CPR, __dataOut);
    }
    if (null == this.HFWY_WDR_CPR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.HFWY_WDR_CPR, __dataOut);
    }
    if (null == this.TMN_RSK_PREM_CPR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.TMN_RSK_PREM_CPR, __dataOut);
    }
    if (null == this.LCAT_PD_CLAT_CPR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.LCAT_PD_CLAT_CPR, __dataOut);
    }
    if (null == this.TMN_ATTM_RDY_AMT_CPR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.TMN_ATTM_RDY_AMT_CPR, __dataOut);
    }
    if (null == this.DMN15_WTHN_SLZ_PREM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.DMN15_WTHN_SLZ_PREM, __dataOut);
    }
    if (null == this.DMN15_TMTD_RDY_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.DMN15_TMTD_RDY_AMT, __dataOut);
    }
    if (null == this.OWN_CTR_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, OWN_CTR_YN);
    }
    if (null == this.CTR_CONV_SIC_SBC_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CTR_CONV_SIC_SBC_YN);
    }
    if (null == this.SBC_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.SBC_AMT, __dataOut);
    }
    if (null == this.CRD_FEE_CPR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.CRD_FEE_CPR, __dataOut);
    }
    if (null == this.CUS_CNTRB_ERN_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.CUS_CNTRB_ERN_AMT, __dataOut);
    }
    if (null == this.SUM_FEE_CPR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.SUM_FEE_CPR, __dataOut);
    }
    if (null == this.ITRT_RISK_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.ITRT_RISK_AMT, __dataOut);
    }
    if (null == this.KICS_MKVL_CPR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.KICS_MKVL_CPR, __dataOut);
    }
    if (null == this.ITRT_DEPRC_MKVL_CPR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.ITRT_DEPRC_MKVL_CPR, __dataOut);
    }
    if (null == this.ITRT_ASCD_MKVL_CPR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.ITRT_ASCD_MKVL_CPR, __dataOut);
    }
    if (null == this.CTR_INS_PRD_TP_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CTR_INS_PRD_TP_CD);
    }
    if (null == this.MMPY_CNVS_PREM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.MMPY_CNVS_PREM, __dataOut);
    }
    if (null == this.PLAN_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, PLAN_CD);
    }
    if (null == this.COV_UNT_PD_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, COV_UNT_PD_CD);
    }
    if (null == this.CSS_PREM_CPR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.CSS_PREM_CPR, __dataOut);
    }
    if (null == this.CSS_INS_AMT_RFD_CPR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.CSS_INS_AMT_RFD_CPR, __dataOut);
    }
    if (null == this.MKVL_BKPM_AMT_CPR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.MKVL_BKPM_AMT_CPR, __dataOut);
    }
    if (null == this.CSS_RT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.CSS_RT, __dataOut);
    }
    if (null == this.CLF_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CLF_DIV_CD);
    }
    if (null == this.INS_SBC_SH_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, INS_SBC_SH_CD);
    }
    if (null == this.SBC_DSG_FEE_PAY_TP_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, SBC_DSG_FEE_PAY_TP_CD);
    }
    if (null == this.SBC_DSG_IRTD_MVAT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.SBC_DSG_IRTD_MVAT, __dataOut);
    }
    if (null == this.SBC_DSG_BZEX_MVAT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.SBC_DSG_BZEX_MVAT, __dataOut);
    }
    if (null == this.SBC_DSG_RSKEX_MVAT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.SBC_DSG_RSKEX_MVAT, __dataOut);
    }
    if (null == this.SBC_DSG_RB_EXP_CPR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.SBC_DSG_RB_EXP_CPR, __dataOut);
    }
    if (null == this.SBC_DSG_RSK_PREM_CPR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.SBC_DSG_RSK_PREM_CPR, __dataOut);
    }
    if (null == this.SBC_DSG_ORIG_PREM_CPR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.SBC_DSG_ORIG_PREM_CPR, __dataOut);
    }
    if (null == this.SBC_DSG_MKVL_CPR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.SBC_DSG_MKVL_CPR, __dataOut);
    }
    if (null == this.LWRT_TMN_RFD_TP_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, LWRT_TMN_RFD_TP_CD);
    }
    if (null == this.LGTM_ITMS_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, LGTM_ITMS_DIV_CD);
    }
    if (null == this.ADVEXP) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.ADVEXP, __dataOut);
    }
    if (null == this.TRTPE_TRFR_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, TRTPE_TRFR_YN);
    }
    if (null == this.DTBT_CTR_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, DTBT_CTR_YN);
    }
    if (null == this.INSPE_GRDE_VAL) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, INSPE_GRDE_VAL);
    }
    if (null == this.PY_EXEM_TP_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, PY_EXEM_TP_CD);
    }
    if (null == this.AMBA_CHN_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, AMBA_CHN_DIV_CD);
    }
    if (null == this.PSINS_CRD_ETC_FEE) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.PSINS_CRD_ETC_FEE, __dataOut);
    }
    if (null == this.PSINS_AT_TRS_ETC_FEE) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.PSINS_AT_TRS_ETC_FEE, __dataOut);
    }
    if (null == this.PSINS_COMS_ETC_FEE) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.PSINS_COMS_ETC_FEE, __dataOut);
    }
    if (null == this.LGTM_CHGE_EXP) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.LGTM_CHGE_EXP, __dataOut);
    }
    if (null == this.LGTM_FIXT_EXP) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.LGTM_FIXT_EXP, __dataOut);
    }
    if (null == this.PSINS_ATNS_MKVL_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.PSINS_ATNS_MKVL_AMT, __dataOut);
    }
  }
  public void write0(DataOutput __dataOut) throws IOException {
    if (null == this.CLOG_YYMM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CLOG_YYMM);
    }
    if (null == this.STD_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.STD_DT.getTime());
    __dataOut.writeInt(this.STD_DT.getNanos());
    }
    if (null == this.CTR_CHNG_STAT_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CTR_CHNG_STAT_CD);
    }
    if (null == this.POL_NO) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, POL_NO);
    }
    if (null == this.COV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, COV_CD);
    }
    if (null == this.CTR_COV_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CTR_COV_ID);
    }
    if (null == this.ENDR_NO) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.ENDR_NO, __dataOut);
    }
    if (null == this.UNT_PD_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, UNT_PD_CD);
    }
    if (null == this.SBCP_YYMM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, SBCP_YYMM);
    }
    if (null == this.FEE_PAY_TP_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, FEE_PAY_TP_CD);
    }
    if (null == this.SBCP_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.SBCP_DT.getTime());
    __dataOut.writeInt(this.SBCP_DT.getNanos());
    }
    if (null == this.ENDR_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.ENDR_DT.getTime());
    __dataOut.writeInt(this.ENDR_DT.getNanos());
    }
    if (null == this.DMG_RT_COV_DCTG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, DMG_RT_COV_DCTG_CD);
    }
    if (null == this.INS_PRD_TP_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, INS_PRD_TP_CD);
    }
    if (null == this.INS_PRD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.INS_PRD, __dataOut);
    }
    if (null == this.PY_PRD_TP_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, PY_PRD_TP_CD);
    }
    if (null == this.PY_PRD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.PY_PRD, __dataOut);
    }
    if (null == this.PY_CYC_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, PY_CYC_CD);
    }
    if (null == this.SBC_AGE) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.SBC_AGE, __dataOut);
    }
    if (null == this.GNDR_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, GNDR_CD);
    }
    if (null == this.INJR_GR_NUM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.INJR_GR_NUM, __dataOut);
    }
    if (null == this.LAST_PY_YYMM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, LAST_PY_YYMM);
    }
    if (null == this.LAST_PY_TMS) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.LAST_PY_TMS, __dataOut);
    }
    if (null == this.RCRT_HDQT_ORG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RCRT_HDQT_ORG_CD);
    }
    if (null == this.RCRT_BRCH_ORG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RCRT_BRCH_ORG_CD);
    }
    if (null == this.RCRT_BCH_ORG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RCRT_BCH_ORG_CD);
    }
    if (null == this.RCRT_TRTPE_ORG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RCRT_TRTPE_ORG_CD);
    }
    if (null == this.RCRT_AGC_PLNR_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RCRT_AGC_PLNR_CD);
    }
    if (null == this.TRT_HDQT_ORG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, TRT_HDQT_ORG_CD);
    }
    if (null == this.TRT_BRCH_ORG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, TRT_BRCH_ORG_CD);
    }
    if (null == this.TRT_BCH_ORG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, TRT_BCH_ORG_CD);
    }
    if (null == this.TRTPE_ORG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, TRTPE_ORG_CD);
    }
    if (null == this.AGC_PLNR_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, AGC_PLNR_CD);
    }
    if (null == this.HDQT_OPPN_DG_CF) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.HDQT_OPPN_DG_CF, __dataOut);
    }
    if (null == this.SLZ_PREM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.SLZ_PREM, __dataOut);
    }
    if (null == this.IRTD_MKVL_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.IRTD_MKVL_AMT, __dataOut);
    }
    if (null == this.BZEX_MKVL_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.BZEX_MKVL_AMT, __dataOut);
    }
    if (null == this.RSKEX_MKVL_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.RSKEX_MKVL_AMT, __dataOut);
    }
    if (null == this.EIH_LDG_DTM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.EIH_LDG_DTM.getTime());
    __dataOut.writeInt(this.EIH_LDG_DTM.getNanos());
    }
    if (null == this.RB_EXP_CPR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.RB_EXP_CPR, __dataOut);
    }
    if (null == this.RSK_PREM_CPR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.RSK_PREM_CPR, __dataOut);
    }
    if (null == this.ORIG_PREM_CPR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.ORIG_PREM_CPR, __dataOut);
    }
    if (null == this.MKVL_CPR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.MKVL_CPR, __dataOut);
    }
    if (null == this.EXPR_RFD_AMT_CPR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.EXPR_RFD_AMT_CPR, __dataOut);
    }
    if (null == this.CLAT_CPR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.CLAT_CPR, __dataOut);
    }
    if (null == this.SRVL_BNT_CPR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.SRVL_BNT_CPR, __dataOut);
    }
    if (null == this.ANN_PAY_AMT_CPR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.ANN_PAY_AMT_CPR, __dataOut);
    }
    if (null == this.PO_ETPY_CPR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.PO_ETPY_CPR, __dataOut);
    }
    if (null == this.MNCL_FEE_CPR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.MNCL_FEE_CPR, __dataOut);
    }
    if (null == this.SAV_PREM_CPR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.SAV_PREM_CPR, __dataOut);
    }
    if (null == this.XACQ_EXP_CPR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.XACQ_EXP_CPR, __dataOut);
    }
    if (null == this.XPT_MTN_EXP_CPR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.XPT_MTN_EXP_CPR, __dataOut);
    }
    if (null == this.XPT_MNCL_EXP_CPR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.XPT_MNCL_EXP_CPR, __dataOut);
    }
    if (null == this.INS_AMT_CPR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.INS_AMT_CPR, __dataOut);
    }
    if (null == this.NPTPY_NW_CTR_RSLFE_CPR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.NPTPY_NW_CTR_RSLFE_CPR, __dataOut);
    }
    if (null == this.NPTPY_ETC_NPO_CPR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.NPTPY_ETC_NPO_CPR, __dataOut);
    }
    if (null == this.TMN_MGI_CPR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.TMN_MGI_CPR, __dataOut);
    }
    if (null == this.ACD_ATTM_RDY_AMT_CPR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.ACD_ATTM_RDY_AMT_CPR, __dataOut);
    }
    if (null == this.PY_EXEM_PREM_CPR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.PY_EXEM_PREM_CPR, __dataOut);
    }
    if (null == this.HFWY_WDR_CPR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.HFWY_WDR_CPR, __dataOut);
    }
    if (null == this.TMN_RSK_PREM_CPR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.TMN_RSK_PREM_CPR, __dataOut);
    }
    if (null == this.LCAT_PD_CLAT_CPR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.LCAT_PD_CLAT_CPR, __dataOut);
    }
    if (null == this.TMN_ATTM_RDY_AMT_CPR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.TMN_ATTM_RDY_AMT_CPR, __dataOut);
    }
    if (null == this.DMN15_WTHN_SLZ_PREM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.DMN15_WTHN_SLZ_PREM, __dataOut);
    }
    if (null == this.DMN15_TMTD_RDY_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.DMN15_TMTD_RDY_AMT, __dataOut);
    }
    if (null == this.OWN_CTR_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, OWN_CTR_YN);
    }
    if (null == this.CTR_CONV_SIC_SBC_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CTR_CONV_SIC_SBC_YN);
    }
    if (null == this.SBC_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.SBC_AMT, __dataOut);
    }
    if (null == this.CRD_FEE_CPR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.CRD_FEE_CPR, __dataOut);
    }
    if (null == this.CUS_CNTRB_ERN_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.CUS_CNTRB_ERN_AMT, __dataOut);
    }
    if (null == this.SUM_FEE_CPR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.SUM_FEE_CPR, __dataOut);
    }
    if (null == this.ITRT_RISK_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.ITRT_RISK_AMT, __dataOut);
    }
    if (null == this.KICS_MKVL_CPR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.KICS_MKVL_CPR, __dataOut);
    }
    if (null == this.ITRT_DEPRC_MKVL_CPR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.ITRT_DEPRC_MKVL_CPR, __dataOut);
    }
    if (null == this.ITRT_ASCD_MKVL_CPR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.ITRT_ASCD_MKVL_CPR, __dataOut);
    }
    if (null == this.CTR_INS_PRD_TP_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CTR_INS_PRD_TP_CD);
    }
    if (null == this.MMPY_CNVS_PREM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.MMPY_CNVS_PREM, __dataOut);
    }
    if (null == this.PLAN_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, PLAN_CD);
    }
    if (null == this.COV_UNT_PD_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, COV_UNT_PD_CD);
    }
    if (null == this.CSS_PREM_CPR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.CSS_PREM_CPR, __dataOut);
    }
    if (null == this.CSS_INS_AMT_RFD_CPR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.CSS_INS_AMT_RFD_CPR, __dataOut);
    }
    if (null == this.MKVL_BKPM_AMT_CPR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.MKVL_BKPM_AMT_CPR, __dataOut);
    }
    if (null == this.CSS_RT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.CSS_RT, __dataOut);
    }
    if (null == this.CLF_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CLF_DIV_CD);
    }
    if (null == this.INS_SBC_SH_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, INS_SBC_SH_CD);
    }
    if (null == this.SBC_DSG_FEE_PAY_TP_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, SBC_DSG_FEE_PAY_TP_CD);
    }
    if (null == this.SBC_DSG_IRTD_MVAT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.SBC_DSG_IRTD_MVAT, __dataOut);
    }
    if (null == this.SBC_DSG_BZEX_MVAT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.SBC_DSG_BZEX_MVAT, __dataOut);
    }
    if (null == this.SBC_DSG_RSKEX_MVAT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.SBC_DSG_RSKEX_MVAT, __dataOut);
    }
    if (null == this.SBC_DSG_RB_EXP_CPR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.SBC_DSG_RB_EXP_CPR, __dataOut);
    }
    if (null == this.SBC_DSG_RSK_PREM_CPR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.SBC_DSG_RSK_PREM_CPR, __dataOut);
    }
    if (null == this.SBC_DSG_ORIG_PREM_CPR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.SBC_DSG_ORIG_PREM_CPR, __dataOut);
    }
    if (null == this.SBC_DSG_MKVL_CPR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.SBC_DSG_MKVL_CPR, __dataOut);
    }
    if (null == this.LWRT_TMN_RFD_TP_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, LWRT_TMN_RFD_TP_CD);
    }
    if (null == this.LGTM_ITMS_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, LGTM_ITMS_DIV_CD);
    }
    if (null == this.ADVEXP) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.ADVEXP, __dataOut);
    }
    if (null == this.TRTPE_TRFR_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, TRTPE_TRFR_YN);
    }
    if (null == this.DTBT_CTR_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, DTBT_CTR_YN);
    }
    if (null == this.INSPE_GRDE_VAL) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, INSPE_GRDE_VAL);
    }
    if (null == this.PY_EXEM_TP_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, PY_EXEM_TP_CD);
    }
    if (null == this.AMBA_CHN_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, AMBA_CHN_DIV_CD);
    }
    if (null == this.PSINS_CRD_ETC_FEE) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.PSINS_CRD_ETC_FEE, __dataOut);
    }
    if (null == this.PSINS_AT_TRS_ETC_FEE) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.PSINS_AT_TRS_ETC_FEE, __dataOut);
    }
    if (null == this.PSINS_COMS_ETC_FEE) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.PSINS_COMS_ETC_FEE, __dataOut);
    }
    if (null == this.LGTM_CHGE_EXP) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.LGTM_CHGE_EXP, __dataOut);
    }
    if (null == this.LGTM_FIXT_EXP) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.LGTM_FIXT_EXP, __dataOut);
    }
    if (null == this.PSINS_ATNS_MKVL_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.PSINS_ATNS_MKVL_AMT, __dataOut);
    }
  }
  private static final DelimiterSet __outputDelimiters = new DelimiterSet((char) 1, (char) 10, (char) 0, (char) 0, false);
  public String toString() {
    return toString(__outputDelimiters, true);
  }
  public String toString(DelimiterSet delimiters) {
    return toString(delimiters, true);
  }
  public String toString(boolean useRecordDelim) {
    return toString(__outputDelimiters, useRecordDelim);
  }
  public String toString(DelimiterSet delimiters, boolean useRecordDelim) {
    StringBuilder __sb = new StringBuilder();
    char fieldDelim = delimiters.getFieldsTerminatedBy();
    __sb.append(FieldFormatter.escapeAndEnclose(CLOG_YYMM==null?"null":CLOG_YYMM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(STD_DT==null?"null":"" + STD_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CTR_CHNG_STAT_CD==null?"null":CTR_CHNG_STAT_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(POL_NO==null?"null":POL_NO, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(COV_CD==null?"null":COV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CTR_COV_ID==null?"null":CTR_COV_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ENDR_NO==null?"null":ENDR_NO.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(UNT_PD_CD==null?"null":UNT_PD_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SBCP_YYMM==null?"null":SBCP_YYMM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(FEE_PAY_TP_CD==null?"null":FEE_PAY_TP_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SBCP_DT==null?"null":"" + SBCP_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ENDR_DT==null?"null":"" + ENDR_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DMG_RT_COV_DCTG_CD==null?"null":DMG_RT_COV_DCTG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(INS_PRD_TP_CD==null?"null":INS_PRD_TP_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(INS_PRD==null?"null":INS_PRD.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PY_PRD_TP_CD==null?"null":PY_PRD_TP_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PY_PRD==null?"null":PY_PRD.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PY_CYC_CD==null?"null":PY_CYC_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SBC_AGE==null?"null":SBC_AGE.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(GNDR_CD==null?"null":GNDR_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(INJR_GR_NUM==null?"null":INJR_GR_NUM.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(LAST_PY_YYMM==null?"null":LAST_PY_YYMM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(LAST_PY_TMS==null?"null":LAST_PY_TMS.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RCRT_HDQT_ORG_CD==null?"null":RCRT_HDQT_ORG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RCRT_BRCH_ORG_CD==null?"null":RCRT_BRCH_ORG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RCRT_BCH_ORG_CD==null?"null":RCRT_BCH_ORG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RCRT_TRTPE_ORG_CD==null?"null":RCRT_TRTPE_ORG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RCRT_AGC_PLNR_CD==null?"null":RCRT_AGC_PLNR_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(TRT_HDQT_ORG_CD==null?"null":TRT_HDQT_ORG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(TRT_BRCH_ORG_CD==null?"null":TRT_BRCH_ORG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(TRT_BCH_ORG_CD==null?"null":TRT_BCH_ORG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(TRTPE_ORG_CD==null?"null":TRTPE_ORG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(AGC_PLNR_CD==null?"null":AGC_PLNR_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(HDQT_OPPN_DG_CF==null?"null":HDQT_OPPN_DG_CF.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SLZ_PREM==null?"null":SLZ_PREM.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(IRTD_MKVL_AMT==null?"null":IRTD_MKVL_AMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(BZEX_MKVL_AMT==null?"null":BZEX_MKVL_AMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RSKEX_MKVL_AMT==null?"null":RSKEX_MKVL_AMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(EIH_LDG_DTM==null?"null":"" + EIH_LDG_DTM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RB_EXP_CPR==null?"null":RB_EXP_CPR.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RSK_PREM_CPR==null?"null":RSK_PREM_CPR.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ORIG_PREM_CPR==null?"null":ORIG_PREM_CPR.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(MKVL_CPR==null?"null":MKVL_CPR.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(EXPR_RFD_AMT_CPR==null?"null":EXPR_RFD_AMT_CPR.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CLAT_CPR==null?"null":CLAT_CPR.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SRVL_BNT_CPR==null?"null":SRVL_BNT_CPR.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ANN_PAY_AMT_CPR==null?"null":ANN_PAY_AMT_CPR.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PO_ETPY_CPR==null?"null":PO_ETPY_CPR.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(MNCL_FEE_CPR==null?"null":MNCL_FEE_CPR.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SAV_PREM_CPR==null?"null":SAV_PREM_CPR.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(XACQ_EXP_CPR==null?"null":XACQ_EXP_CPR.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(XPT_MTN_EXP_CPR==null?"null":XPT_MTN_EXP_CPR.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(XPT_MNCL_EXP_CPR==null?"null":XPT_MNCL_EXP_CPR.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(INS_AMT_CPR==null?"null":INS_AMT_CPR.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(NPTPY_NW_CTR_RSLFE_CPR==null?"null":NPTPY_NW_CTR_RSLFE_CPR.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(NPTPY_ETC_NPO_CPR==null?"null":NPTPY_ETC_NPO_CPR.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(TMN_MGI_CPR==null?"null":TMN_MGI_CPR.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ACD_ATTM_RDY_AMT_CPR==null?"null":ACD_ATTM_RDY_AMT_CPR.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PY_EXEM_PREM_CPR==null?"null":PY_EXEM_PREM_CPR.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(HFWY_WDR_CPR==null?"null":HFWY_WDR_CPR.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(TMN_RSK_PREM_CPR==null?"null":TMN_RSK_PREM_CPR.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(LCAT_PD_CLAT_CPR==null?"null":LCAT_PD_CLAT_CPR.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(TMN_ATTM_RDY_AMT_CPR==null?"null":TMN_ATTM_RDY_AMT_CPR.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DMN15_WTHN_SLZ_PREM==null?"null":DMN15_WTHN_SLZ_PREM.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DMN15_TMTD_RDY_AMT==null?"null":DMN15_TMTD_RDY_AMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(OWN_CTR_YN==null?"null":OWN_CTR_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CTR_CONV_SIC_SBC_YN==null?"null":CTR_CONV_SIC_SBC_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SBC_AMT==null?"null":SBC_AMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CRD_FEE_CPR==null?"null":CRD_FEE_CPR.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CUS_CNTRB_ERN_AMT==null?"null":CUS_CNTRB_ERN_AMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SUM_FEE_CPR==null?"null":SUM_FEE_CPR.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ITRT_RISK_AMT==null?"null":ITRT_RISK_AMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(KICS_MKVL_CPR==null?"null":KICS_MKVL_CPR.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ITRT_DEPRC_MKVL_CPR==null?"null":ITRT_DEPRC_MKVL_CPR.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ITRT_ASCD_MKVL_CPR==null?"null":ITRT_ASCD_MKVL_CPR.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CTR_INS_PRD_TP_CD==null?"null":CTR_INS_PRD_TP_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(MMPY_CNVS_PREM==null?"null":MMPY_CNVS_PREM.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PLAN_CD==null?"null":PLAN_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(COV_UNT_PD_CD==null?"null":COV_UNT_PD_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CSS_PREM_CPR==null?"null":CSS_PREM_CPR.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CSS_INS_AMT_RFD_CPR==null?"null":CSS_INS_AMT_RFD_CPR.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(MKVL_BKPM_AMT_CPR==null?"null":MKVL_BKPM_AMT_CPR.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CSS_RT==null?"null":CSS_RT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CLF_DIV_CD==null?"null":CLF_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(INS_SBC_SH_CD==null?"null":INS_SBC_SH_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SBC_DSG_FEE_PAY_TP_CD==null?"null":SBC_DSG_FEE_PAY_TP_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SBC_DSG_IRTD_MVAT==null?"null":SBC_DSG_IRTD_MVAT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SBC_DSG_BZEX_MVAT==null?"null":SBC_DSG_BZEX_MVAT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SBC_DSG_RSKEX_MVAT==null?"null":SBC_DSG_RSKEX_MVAT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SBC_DSG_RB_EXP_CPR==null?"null":SBC_DSG_RB_EXP_CPR.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SBC_DSG_RSK_PREM_CPR==null?"null":SBC_DSG_RSK_PREM_CPR.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SBC_DSG_ORIG_PREM_CPR==null?"null":SBC_DSG_ORIG_PREM_CPR.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SBC_DSG_MKVL_CPR==null?"null":SBC_DSG_MKVL_CPR.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(LWRT_TMN_RFD_TP_CD==null?"null":LWRT_TMN_RFD_TP_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(LGTM_ITMS_DIV_CD==null?"null":LGTM_ITMS_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ADVEXP==null?"null":ADVEXP.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(TRTPE_TRFR_YN==null?"null":TRTPE_TRFR_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DTBT_CTR_YN==null?"null":DTBT_CTR_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(INSPE_GRDE_VAL==null?"null":INSPE_GRDE_VAL, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PY_EXEM_TP_CD==null?"null":PY_EXEM_TP_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(AMBA_CHN_DIV_CD==null?"null":AMBA_CHN_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PSINS_CRD_ETC_FEE==null?"null":PSINS_CRD_ETC_FEE.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PSINS_AT_TRS_ETC_FEE==null?"null":PSINS_AT_TRS_ETC_FEE.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PSINS_COMS_ETC_FEE==null?"null":PSINS_COMS_ETC_FEE.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(LGTM_CHGE_EXP==null?"null":LGTM_CHGE_EXP.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(LGTM_FIXT_EXP==null?"null":LGTM_FIXT_EXP.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PSINS_ATNS_MKVL_AMT==null?"null":PSINS_ATNS_MKVL_AMT.toPlainString(), delimiters));
    if (useRecordDelim) {
      __sb.append(delimiters.getLinesTerminatedBy());
    }
    return __sb.toString();
  }
  public void toString0(DelimiterSet delimiters, StringBuilder __sb, char fieldDelim) {
    __sb.append(FieldFormatter.escapeAndEnclose(CLOG_YYMM==null?"null":CLOG_YYMM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(STD_DT==null?"null":"" + STD_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CTR_CHNG_STAT_CD==null?"null":CTR_CHNG_STAT_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(POL_NO==null?"null":POL_NO, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(COV_CD==null?"null":COV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CTR_COV_ID==null?"null":CTR_COV_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ENDR_NO==null?"null":ENDR_NO.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(UNT_PD_CD==null?"null":UNT_PD_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SBCP_YYMM==null?"null":SBCP_YYMM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(FEE_PAY_TP_CD==null?"null":FEE_PAY_TP_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SBCP_DT==null?"null":"" + SBCP_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ENDR_DT==null?"null":"" + ENDR_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DMG_RT_COV_DCTG_CD==null?"null":DMG_RT_COV_DCTG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(INS_PRD_TP_CD==null?"null":INS_PRD_TP_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(INS_PRD==null?"null":INS_PRD.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PY_PRD_TP_CD==null?"null":PY_PRD_TP_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PY_PRD==null?"null":PY_PRD.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PY_CYC_CD==null?"null":PY_CYC_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SBC_AGE==null?"null":SBC_AGE.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(GNDR_CD==null?"null":GNDR_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(INJR_GR_NUM==null?"null":INJR_GR_NUM.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(LAST_PY_YYMM==null?"null":LAST_PY_YYMM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(LAST_PY_TMS==null?"null":LAST_PY_TMS.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RCRT_HDQT_ORG_CD==null?"null":RCRT_HDQT_ORG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RCRT_BRCH_ORG_CD==null?"null":RCRT_BRCH_ORG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RCRT_BCH_ORG_CD==null?"null":RCRT_BCH_ORG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RCRT_TRTPE_ORG_CD==null?"null":RCRT_TRTPE_ORG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RCRT_AGC_PLNR_CD==null?"null":RCRT_AGC_PLNR_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(TRT_HDQT_ORG_CD==null?"null":TRT_HDQT_ORG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(TRT_BRCH_ORG_CD==null?"null":TRT_BRCH_ORG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(TRT_BCH_ORG_CD==null?"null":TRT_BCH_ORG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(TRTPE_ORG_CD==null?"null":TRTPE_ORG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(AGC_PLNR_CD==null?"null":AGC_PLNR_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(HDQT_OPPN_DG_CF==null?"null":HDQT_OPPN_DG_CF.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SLZ_PREM==null?"null":SLZ_PREM.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(IRTD_MKVL_AMT==null?"null":IRTD_MKVL_AMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(BZEX_MKVL_AMT==null?"null":BZEX_MKVL_AMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RSKEX_MKVL_AMT==null?"null":RSKEX_MKVL_AMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(EIH_LDG_DTM==null?"null":"" + EIH_LDG_DTM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RB_EXP_CPR==null?"null":RB_EXP_CPR.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RSK_PREM_CPR==null?"null":RSK_PREM_CPR.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ORIG_PREM_CPR==null?"null":ORIG_PREM_CPR.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(MKVL_CPR==null?"null":MKVL_CPR.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(EXPR_RFD_AMT_CPR==null?"null":EXPR_RFD_AMT_CPR.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CLAT_CPR==null?"null":CLAT_CPR.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SRVL_BNT_CPR==null?"null":SRVL_BNT_CPR.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ANN_PAY_AMT_CPR==null?"null":ANN_PAY_AMT_CPR.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PO_ETPY_CPR==null?"null":PO_ETPY_CPR.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(MNCL_FEE_CPR==null?"null":MNCL_FEE_CPR.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SAV_PREM_CPR==null?"null":SAV_PREM_CPR.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(XACQ_EXP_CPR==null?"null":XACQ_EXP_CPR.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(XPT_MTN_EXP_CPR==null?"null":XPT_MTN_EXP_CPR.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(XPT_MNCL_EXP_CPR==null?"null":XPT_MNCL_EXP_CPR.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(INS_AMT_CPR==null?"null":INS_AMT_CPR.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(NPTPY_NW_CTR_RSLFE_CPR==null?"null":NPTPY_NW_CTR_RSLFE_CPR.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(NPTPY_ETC_NPO_CPR==null?"null":NPTPY_ETC_NPO_CPR.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(TMN_MGI_CPR==null?"null":TMN_MGI_CPR.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ACD_ATTM_RDY_AMT_CPR==null?"null":ACD_ATTM_RDY_AMT_CPR.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PY_EXEM_PREM_CPR==null?"null":PY_EXEM_PREM_CPR.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(HFWY_WDR_CPR==null?"null":HFWY_WDR_CPR.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(TMN_RSK_PREM_CPR==null?"null":TMN_RSK_PREM_CPR.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(LCAT_PD_CLAT_CPR==null?"null":LCAT_PD_CLAT_CPR.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(TMN_ATTM_RDY_AMT_CPR==null?"null":TMN_ATTM_RDY_AMT_CPR.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DMN15_WTHN_SLZ_PREM==null?"null":DMN15_WTHN_SLZ_PREM.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DMN15_TMTD_RDY_AMT==null?"null":DMN15_TMTD_RDY_AMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(OWN_CTR_YN==null?"null":OWN_CTR_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CTR_CONV_SIC_SBC_YN==null?"null":CTR_CONV_SIC_SBC_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SBC_AMT==null?"null":SBC_AMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CRD_FEE_CPR==null?"null":CRD_FEE_CPR.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CUS_CNTRB_ERN_AMT==null?"null":CUS_CNTRB_ERN_AMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SUM_FEE_CPR==null?"null":SUM_FEE_CPR.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ITRT_RISK_AMT==null?"null":ITRT_RISK_AMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(KICS_MKVL_CPR==null?"null":KICS_MKVL_CPR.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ITRT_DEPRC_MKVL_CPR==null?"null":ITRT_DEPRC_MKVL_CPR.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ITRT_ASCD_MKVL_CPR==null?"null":ITRT_ASCD_MKVL_CPR.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CTR_INS_PRD_TP_CD==null?"null":CTR_INS_PRD_TP_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(MMPY_CNVS_PREM==null?"null":MMPY_CNVS_PREM.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PLAN_CD==null?"null":PLAN_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(COV_UNT_PD_CD==null?"null":COV_UNT_PD_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CSS_PREM_CPR==null?"null":CSS_PREM_CPR.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CSS_INS_AMT_RFD_CPR==null?"null":CSS_INS_AMT_RFD_CPR.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(MKVL_BKPM_AMT_CPR==null?"null":MKVL_BKPM_AMT_CPR.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CSS_RT==null?"null":CSS_RT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CLF_DIV_CD==null?"null":CLF_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(INS_SBC_SH_CD==null?"null":INS_SBC_SH_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SBC_DSG_FEE_PAY_TP_CD==null?"null":SBC_DSG_FEE_PAY_TP_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SBC_DSG_IRTD_MVAT==null?"null":SBC_DSG_IRTD_MVAT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SBC_DSG_BZEX_MVAT==null?"null":SBC_DSG_BZEX_MVAT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SBC_DSG_RSKEX_MVAT==null?"null":SBC_DSG_RSKEX_MVAT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SBC_DSG_RB_EXP_CPR==null?"null":SBC_DSG_RB_EXP_CPR.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SBC_DSG_RSK_PREM_CPR==null?"null":SBC_DSG_RSK_PREM_CPR.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SBC_DSG_ORIG_PREM_CPR==null?"null":SBC_DSG_ORIG_PREM_CPR.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SBC_DSG_MKVL_CPR==null?"null":SBC_DSG_MKVL_CPR.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(LWRT_TMN_RFD_TP_CD==null?"null":LWRT_TMN_RFD_TP_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(LGTM_ITMS_DIV_CD==null?"null":LGTM_ITMS_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ADVEXP==null?"null":ADVEXP.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(TRTPE_TRFR_YN==null?"null":TRTPE_TRFR_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DTBT_CTR_YN==null?"null":DTBT_CTR_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(INSPE_GRDE_VAL==null?"null":INSPE_GRDE_VAL, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PY_EXEM_TP_CD==null?"null":PY_EXEM_TP_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(AMBA_CHN_DIV_CD==null?"null":AMBA_CHN_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PSINS_CRD_ETC_FEE==null?"null":PSINS_CRD_ETC_FEE.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PSINS_AT_TRS_ETC_FEE==null?"null":PSINS_AT_TRS_ETC_FEE.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PSINS_COMS_ETC_FEE==null?"null":PSINS_COMS_ETC_FEE.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(LGTM_CHGE_EXP==null?"null":LGTM_CHGE_EXP.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(LGTM_FIXT_EXP==null?"null":LGTM_FIXT_EXP.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PSINS_ATNS_MKVL_AMT==null?"null":PSINS_ATNS_MKVL_AMT.toPlainString(), delimiters));
  }
  private static final DelimiterSet __inputDelimiters = new DelimiterSet((char) 1, (char) 10, (char) 0, (char) 0, false);
  private RecordParser __parser;
  public void parse(Text __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(CharSequence __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(byte [] __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(char [] __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(ByteBuffer __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(CharBuffer __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  private void __loadFromFields(List<String> fields) {
    Iterator<String> __it = fields.listIterator();
    String __cur_str = null;
    try {
    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CLOG_YYMM = null; } else {
      this.CLOG_YYMM = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.STD_DT = null; } else {
      this.STD_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CTR_CHNG_STAT_CD = null; } else {
      this.CTR_CHNG_STAT_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.POL_NO = null; } else {
      this.POL_NO = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.COV_CD = null; } else {
      this.COV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CTR_COV_ID = null; } else {
      this.CTR_COV_ID = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.ENDR_NO = null; } else {
      this.ENDR_NO = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.UNT_PD_CD = null; } else {
      this.UNT_PD_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.SBCP_YYMM = null; } else {
      this.SBCP_YYMM = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.FEE_PAY_TP_CD = null; } else {
      this.FEE_PAY_TP_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.SBCP_DT = null; } else {
      this.SBCP_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.ENDR_DT = null; } else {
      this.ENDR_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.DMG_RT_COV_DCTG_CD = null; } else {
      this.DMG_RT_COV_DCTG_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.INS_PRD_TP_CD = null; } else {
      this.INS_PRD_TP_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.INS_PRD = null; } else {
      this.INS_PRD = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.PY_PRD_TP_CD = null; } else {
      this.PY_PRD_TP_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.PY_PRD = null; } else {
      this.PY_PRD = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.PY_CYC_CD = null; } else {
      this.PY_CYC_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.SBC_AGE = null; } else {
      this.SBC_AGE = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.GNDR_CD = null; } else {
      this.GNDR_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.INJR_GR_NUM = null; } else {
      this.INJR_GR_NUM = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.LAST_PY_YYMM = null; } else {
      this.LAST_PY_YYMM = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.LAST_PY_TMS = null; } else {
      this.LAST_PY_TMS = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.RCRT_HDQT_ORG_CD = null; } else {
      this.RCRT_HDQT_ORG_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.RCRT_BRCH_ORG_CD = null; } else {
      this.RCRT_BRCH_ORG_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.RCRT_BCH_ORG_CD = null; } else {
      this.RCRT_BCH_ORG_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.RCRT_TRTPE_ORG_CD = null; } else {
      this.RCRT_TRTPE_ORG_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.RCRT_AGC_PLNR_CD = null; } else {
      this.RCRT_AGC_PLNR_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.TRT_HDQT_ORG_CD = null; } else {
      this.TRT_HDQT_ORG_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.TRT_BRCH_ORG_CD = null; } else {
      this.TRT_BRCH_ORG_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.TRT_BCH_ORG_CD = null; } else {
      this.TRT_BCH_ORG_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.TRTPE_ORG_CD = null; } else {
      this.TRTPE_ORG_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.AGC_PLNR_CD = null; } else {
      this.AGC_PLNR_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.HDQT_OPPN_DG_CF = null; } else {
      this.HDQT_OPPN_DG_CF = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.SLZ_PREM = null; } else {
      this.SLZ_PREM = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.IRTD_MKVL_AMT = null; } else {
      this.IRTD_MKVL_AMT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.BZEX_MKVL_AMT = null; } else {
      this.BZEX_MKVL_AMT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RSKEX_MKVL_AMT = null; } else {
      this.RSKEX_MKVL_AMT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.EIH_LDG_DTM = null; } else {
      this.EIH_LDG_DTM = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RB_EXP_CPR = null; } else {
      this.RB_EXP_CPR = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RSK_PREM_CPR = null; } else {
      this.RSK_PREM_CPR = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.ORIG_PREM_CPR = null; } else {
      this.ORIG_PREM_CPR = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.MKVL_CPR = null; } else {
      this.MKVL_CPR = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.EXPR_RFD_AMT_CPR = null; } else {
      this.EXPR_RFD_AMT_CPR = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.CLAT_CPR = null; } else {
      this.CLAT_CPR = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.SRVL_BNT_CPR = null; } else {
      this.SRVL_BNT_CPR = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.ANN_PAY_AMT_CPR = null; } else {
      this.ANN_PAY_AMT_CPR = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.PO_ETPY_CPR = null; } else {
      this.PO_ETPY_CPR = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.MNCL_FEE_CPR = null; } else {
      this.MNCL_FEE_CPR = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.SAV_PREM_CPR = null; } else {
      this.SAV_PREM_CPR = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.XACQ_EXP_CPR = null; } else {
      this.XACQ_EXP_CPR = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.XPT_MTN_EXP_CPR = null; } else {
      this.XPT_MTN_EXP_CPR = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.XPT_MNCL_EXP_CPR = null; } else {
      this.XPT_MNCL_EXP_CPR = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.INS_AMT_CPR = null; } else {
      this.INS_AMT_CPR = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.NPTPY_NW_CTR_RSLFE_CPR = null; } else {
      this.NPTPY_NW_CTR_RSLFE_CPR = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.NPTPY_ETC_NPO_CPR = null; } else {
      this.NPTPY_ETC_NPO_CPR = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.TMN_MGI_CPR = null; } else {
      this.TMN_MGI_CPR = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.ACD_ATTM_RDY_AMT_CPR = null; } else {
      this.ACD_ATTM_RDY_AMT_CPR = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.PY_EXEM_PREM_CPR = null; } else {
      this.PY_EXEM_PREM_CPR = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.HFWY_WDR_CPR = null; } else {
      this.HFWY_WDR_CPR = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.TMN_RSK_PREM_CPR = null; } else {
      this.TMN_RSK_PREM_CPR = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.LCAT_PD_CLAT_CPR = null; } else {
      this.LCAT_PD_CLAT_CPR = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.TMN_ATTM_RDY_AMT_CPR = null; } else {
      this.TMN_ATTM_RDY_AMT_CPR = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.DMN15_WTHN_SLZ_PREM = null; } else {
      this.DMN15_WTHN_SLZ_PREM = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.DMN15_TMTD_RDY_AMT = null; } else {
      this.DMN15_TMTD_RDY_AMT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.OWN_CTR_YN = null; } else {
      this.OWN_CTR_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CTR_CONV_SIC_SBC_YN = null; } else {
      this.CTR_CONV_SIC_SBC_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.SBC_AMT = null; } else {
      this.SBC_AMT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.CRD_FEE_CPR = null; } else {
      this.CRD_FEE_CPR = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.CUS_CNTRB_ERN_AMT = null; } else {
      this.CUS_CNTRB_ERN_AMT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.SUM_FEE_CPR = null; } else {
      this.SUM_FEE_CPR = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.ITRT_RISK_AMT = null; } else {
      this.ITRT_RISK_AMT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.KICS_MKVL_CPR = null; } else {
      this.KICS_MKVL_CPR = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.ITRT_DEPRC_MKVL_CPR = null; } else {
      this.ITRT_DEPRC_MKVL_CPR = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.ITRT_ASCD_MKVL_CPR = null; } else {
      this.ITRT_ASCD_MKVL_CPR = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CTR_INS_PRD_TP_CD = null; } else {
      this.CTR_INS_PRD_TP_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.MMPY_CNVS_PREM = null; } else {
      this.MMPY_CNVS_PREM = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.PLAN_CD = null; } else {
      this.PLAN_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.COV_UNT_PD_CD = null; } else {
      this.COV_UNT_PD_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.CSS_PREM_CPR = null; } else {
      this.CSS_PREM_CPR = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.CSS_INS_AMT_RFD_CPR = null; } else {
      this.CSS_INS_AMT_RFD_CPR = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.MKVL_BKPM_AMT_CPR = null; } else {
      this.MKVL_BKPM_AMT_CPR = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.CSS_RT = null; } else {
      this.CSS_RT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CLF_DIV_CD = null; } else {
      this.CLF_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.INS_SBC_SH_CD = null; } else {
      this.INS_SBC_SH_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.SBC_DSG_FEE_PAY_TP_CD = null; } else {
      this.SBC_DSG_FEE_PAY_TP_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.SBC_DSG_IRTD_MVAT = null; } else {
      this.SBC_DSG_IRTD_MVAT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.SBC_DSG_BZEX_MVAT = null; } else {
      this.SBC_DSG_BZEX_MVAT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.SBC_DSG_RSKEX_MVAT = null; } else {
      this.SBC_DSG_RSKEX_MVAT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.SBC_DSG_RB_EXP_CPR = null; } else {
      this.SBC_DSG_RB_EXP_CPR = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.SBC_DSG_RSK_PREM_CPR = null; } else {
      this.SBC_DSG_RSK_PREM_CPR = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.SBC_DSG_ORIG_PREM_CPR = null; } else {
      this.SBC_DSG_ORIG_PREM_CPR = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.SBC_DSG_MKVL_CPR = null; } else {
      this.SBC_DSG_MKVL_CPR = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.LWRT_TMN_RFD_TP_CD = null; } else {
      this.LWRT_TMN_RFD_TP_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.LGTM_ITMS_DIV_CD = null; } else {
      this.LGTM_ITMS_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.ADVEXP = null; } else {
      this.ADVEXP = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.TRTPE_TRFR_YN = null; } else {
      this.TRTPE_TRFR_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.DTBT_CTR_YN = null; } else {
      this.DTBT_CTR_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.INSPE_GRDE_VAL = null; } else {
      this.INSPE_GRDE_VAL = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.PY_EXEM_TP_CD = null; } else {
      this.PY_EXEM_TP_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.AMBA_CHN_DIV_CD = null; } else {
      this.AMBA_CHN_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.PSINS_CRD_ETC_FEE = null; } else {
      this.PSINS_CRD_ETC_FEE = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.PSINS_AT_TRS_ETC_FEE = null; } else {
      this.PSINS_AT_TRS_ETC_FEE = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.PSINS_COMS_ETC_FEE = null; } else {
      this.PSINS_COMS_ETC_FEE = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.LGTM_CHGE_EXP = null; } else {
      this.LGTM_CHGE_EXP = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.LGTM_FIXT_EXP = null; } else {
      this.LGTM_FIXT_EXP = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.PSINS_ATNS_MKVL_AMT = null; } else {
      this.PSINS_ATNS_MKVL_AMT = new java.math.BigDecimal(__cur_str);
    }

    } catch (RuntimeException e) {    throw new RuntimeException("Can't parse input data: '" + __cur_str + "'", e);    }  }

  private void __loadFromFields0(Iterator<String> __it) {
    String __cur_str = null;
    try {
    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CLOG_YYMM = null; } else {
      this.CLOG_YYMM = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.STD_DT = null; } else {
      this.STD_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CTR_CHNG_STAT_CD = null; } else {
      this.CTR_CHNG_STAT_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.POL_NO = null; } else {
      this.POL_NO = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.COV_CD = null; } else {
      this.COV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CTR_COV_ID = null; } else {
      this.CTR_COV_ID = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.ENDR_NO = null; } else {
      this.ENDR_NO = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.UNT_PD_CD = null; } else {
      this.UNT_PD_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.SBCP_YYMM = null; } else {
      this.SBCP_YYMM = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.FEE_PAY_TP_CD = null; } else {
      this.FEE_PAY_TP_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.SBCP_DT = null; } else {
      this.SBCP_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.ENDR_DT = null; } else {
      this.ENDR_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.DMG_RT_COV_DCTG_CD = null; } else {
      this.DMG_RT_COV_DCTG_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.INS_PRD_TP_CD = null; } else {
      this.INS_PRD_TP_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.INS_PRD = null; } else {
      this.INS_PRD = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.PY_PRD_TP_CD = null; } else {
      this.PY_PRD_TP_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.PY_PRD = null; } else {
      this.PY_PRD = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.PY_CYC_CD = null; } else {
      this.PY_CYC_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.SBC_AGE = null; } else {
      this.SBC_AGE = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.GNDR_CD = null; } else {
      this.GNDR_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.INJR_GR_NUM = null; } else {
      this.INJR_GR_NUM = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.LAST_PY_YYMM = null; } else {
      this.LAST_PY_YYMM = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.LAST_PY_TMS = null; } else {
      this.LAST_PY_TMS = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.RCRT_HDQT_ORG_CD = null; } else {
      this.RCRT_HDQT_ORG_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.RCRT_BRCH_ORG_CD = null; } else {
      this.RCRT_BRCH_ORG_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.RCRT_BCH_ORG_CD = null; } else {
      this.RCRT_BCH_ORG_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.RCRT_TRTPE_ORG_CD = null; } else {
      this.RCRT_TRTPE_ORG_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.RCRT_AGC_PLNR_CD = null; } else {
      this.RCRT_AGC_PLNR_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.TRT_HDQT_ORG_CD = null; } else {
      this.TRT_HDQT_ORG_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.TRT_BRCH_ORG_CD = null; } else {
      this.TRT_BRCH_ORG_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.TRT_BCH_ORG_CD = null; } else {
      this.TRT_BCH_ORG_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.TRTPE_ORG_CD = null; } else {
      this.TRTPE_ORG_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.AGC_PLNR_CD = null; } else {
      this.AGC_PLNR_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.HDQT_OPPN_DG_CF = null; } else {
      this.HDQT_OPPN_DG_CF = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.SLZ_PREM = null; } else {
      this.SLZ_PREM = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.IRTD_MKVL_AMT = null; } else {
      this.IRTD_MKVL_AMT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.BZEX_MKVL_AMT = null; } else {
      this.BZEX_MKVL_AMT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RSKEX_MKVL_AMT = null; } else {
      this.RSKEX_MKVL_AMT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.EIH_LDG_DTM = null; } else {
      this.EIH_LDG_DTM = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RB_EXP_CPR = null; } else {
      this.RB_EXP_CPR = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RSK_PREM_CPR = null; } else {
      this.RSK_PREM_CPR = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.ORIG_PREM_CPR = null; } else {
      this.ORIG_PREM_CPR = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.MKVL_CPR = null; } else {
      this.MKVL_CPR = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.EXPR_RFD_AMT_CPR = null; } else {
      this.EXPR_RFD_AMT_CPR = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.CLAT_CPR = null; } else {
      this.CLAT_CPR = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.SRVL_BNT_CPR = null; } else {
      this.SRVL_BNT_CPR = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.ANN_PAY_AMT_CPR = null; } else {
      this.ANN_PAY_AMT_CPR = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.PO_ETPY_CPR = null; } else {
      this.PO_ETPY_CPR = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.MNCL_FEE_CPR = null; } else {
      this.MNCL_FEE_CPR = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.SAV_PREM_CPR = null; } else {
      this.SAV_PREM_CPR = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.XACQ_EXP_CPR = null; } else {
      this.XACQ_EXP_CPR = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.XPT_MTN_EXP_CPR = null; } else {
      this.XPT_MTN_EXP_CPR = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.XPT_MNCL_EXP_CPR = null; } else {
      this.XPT_MNCL_EXP_CPR = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.INS_AMT_CPR = null; } else {
      this.INS_AMT_CPR = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.NPTPY_NW_CTR_RSLFE_CPR = null; } else {
      this.NPTPY_NW_CTR_RSLFE_CPR = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.NPTPY_ETC_NPO_CPR = null; } else {
      this.NPTPY_ETC_NPO_CPR = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.TMN_MGI_CPR = null; } else {
      this.TMN_MGI_CPR = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.ACD_ATTM_RDY_AMT_CPR = null; } else {
      this.ACD_ATTM_RDY_AMT_CPR = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.PY_EXEM_PREM_CPR = null; } else {
      this.PY_EXEM_PREM_CPR = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.HFWY_WDR_CPR = null; } else {
      this.HFWY_WDR_CPR = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.TMN_RSK_PREM_CPR = null; } else {
      this.TMN_RSK_PREM_CPR = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.LCAT_PD_CLAT_CPR = null; } else {
      this.LCAT_PD_CLAT_CPR = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.TMN_ATTM_RDY_AMT_CPR = null; } else {
      this.TMN_ATTM_RDY_AMT_CPR = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.DMN15_WTHN_SLZ_PREM = null; } else {
      this.DMN15_WTHN_SLZ_PREM = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.DMN15_TMTD_RDY_AMT = null; } else {
      this.DMN15_TMTD_RDY_AMT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.OWN_CTR_YN = null; } else {
      this.OWN_CTR_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CTR_CONV_SIC_SBC_YN = null; } else {
      this.CTR_CONV_SIC_SBC_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.SBC_AMT = null; } else {
      this.SBC_AMT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.CRD_FEE_CPR = null; } else {
      this.CRD_FEE_CPR = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.CUS_CNTRB_ERN_AMT = null; } else {
      this.CUS_CNTRB_ERN_AMT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.SUM_FEE_CPR = null; } else {
      this.SUM_FEE_CPR = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.ITRT_RISK_AMT = null; } else {
      this.ITRT_RISK_AMT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.KICS_MKVL_CPR = null; } else {
      this.KICS_MKVL_CPR = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.ITRT_DEPRC_MKVL_CPR = null; } else {
      this.ITRT_DEPRC_MKVL_CPR = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.ITRT_ASCD_MKVL_CPR = null; } else {
      this.ITRT_ASCD_MKVL_CPR = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CTR_INS_PRD_TP_CD = null; } else {
      this.CTR_INS_PRD_TP_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.MMPY_CNVS_PREM = null; } else {
      this.MMPY_CNVS_PREM = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.PLAN_CD = null; } else {
      this.PLAN_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.COV_UNT_PD_CD = null; } else {
      this.COV_UNT_PD_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.CSS_PREM_CPR = null; } else {
      this.CSS_PREM_CPR = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.CSS_INS_AMT_RFD_CPR = null; } else {
      this.CSS_INS_AMT_RFD_CPR = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.MKVL_BKPM_AMT_CPR = null; } else {
      this.MKVL_BKPM_AMT_CPR = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.CSS_RT = null; } else {
      this.CSS_RT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CLF_DIV_CD = null; } else {
      this.CLF_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.INS_SBC_SH_CD = null; } else {
      this.INS_SBC_SH_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.SBC_DSG_FEE_PAY_TP_CD = null; } else {
      this.SBC_DSG_FEE_PAY_TP_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.SBC_DSG_IRTD_MVAT = null; } else {
      this.SBC_DSG_IRTD_MVAT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.SBC_DSG_BZEX_MVAT = null; } else {
      this.SBC_DSG_BZEX_MVAT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.SBC_DSG_RSKEX_MVAT = null; } else {
      this.SBC_DSG_RSKEX_MVAT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.SBC_DSG_RB_EXP_CPR = null; } else {
      this.SBC_DSG_RB_EXP_CPR = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.SBC_DSG_RSK_PREM_CPR = null; } else {
      this.SBC_DSG_RSK_PREM_CPR = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.SBC_DSG_ORIG_PREM_CPR = null; } else {
      this.SBC_DSG_ORIG_PREM_CPR = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.SBC_DSG_MKVL_CPR = null; } else {
      this.SBC_DSG_MKVL_CPR = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.LWRT_TMN_RFD_TP_CD = null; } else {
      this.LWRT_TMN_RFD_TP_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.LGTM_ITMS_DIV_CD = null; } else {
      this.LGTM_ITMS_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.ADVEXP = null; } else {
      this.ADVEXP = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.TRTPE_TRFR_YN = null; } else {
      this.TRTPE_TRFR_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.DTBT_CTR_YN = null; } else {
      this.DTBT_CTR_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.INSPE_GRDE_VAL = null; } else {
      this.INSPE_GRDE_VAL = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.PY_EXEM_TP_CD = null; } else {
      this.PY_EXEM_TP_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.AMBA_CHN_DIV_CD = null; } else {
      this.AMBA_CHN_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.PSINS_CRD_ETC_FEE = null; } else {
      this.PSINS_CRD_ETC_FEE = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.PSINS_AT_TRS_ETC_FEE = null; } else {
      this.PSINS_AT_TRS_ETC_FEE = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.PSINS_COMS_ETC_FEE = null; } else {
      this.PSINS_COMS_ETC_FEE = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.LGTM_CHGE_EXP = null; } else {
      this.LGTM_CHGE_EXP = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.LGTM_FIXT_EXP = null; } else {
      this.LGTM_FIXT_EXP = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.PSINS_ATNS_MKVL_AMT = null; } else {
      this.PSINS_ATNS_MKVL_AMT = new java.math.BigDecimal(__cur_str);
    }

    } catch (RuntimeException e) {    throw new RuntimeException("Can't parse input data: '" + __cur_str + "'", e);    }  }

  public Object clone() throws CloneNotSupportedException {
    QueryResult o = (QueryResult) super.clone();
    o.STD_DT = (o.STD_DT != null) ? (java.sql.Timestamp) o.STD_DT.clone() : null;
    o.SBCP_DT = (o.SBCP_DT != null) ? (java.sql.Timestamp) o.SBCP_DT.clone() : null;
    o.ENDR_DT = (o.ENDR_DT != null) ? (java.sql.Timestamp) o.ENDR_DT.clone() : null;
    o.EIH_LDG_DTM = (o.EIH_LDG_DTM != null) ? (java.sql.Timestamp) o.EIH_LDG_DTM.clone() : null;
    return o;
  }

  public void clone0(QueryResult o) throws CloneNotSupportedException {
    o.STD_DT = (o.STD_DT != null) ? (java.sql.Timestamp) o.STD_DT.clone() : null;
    o.SBCP_DT = (o.SBCP_DT != null) ? (java.sql.Timestamp) o.SBCP_DT.clone() : null;
    o.ENDR_DT = (o.ENDR_DT != null) ? (java.sql.Timestamp) o.ENDR_DT.clone() : null;
    o.EIH_LDG_DTM = (o.EIH_LDG_DTM != null) ? (java.sql.Timestamp) o.EIH_LDG_DTM.clone() : null;
  }

  public Map<String, Object> getFieldMap() {
    Map<String, Object> __sqoop$field_map = new HashMap<String, Object>();
    __sqoop$field_map.put("CLOG_YYMM", this.CLOG_YYMM);
    __sqoop$field_map.put("STD_DT", this.STD_DT);
    __sqoop$field_map.put("CTR_CHNG_STAT_CD", this.CTR_CHNG_STAT_CD);
    __sqoop$field_map.put("POL_NO", this.POL_NO);
    __sqoop$field_map.put("COV_CD", this.COV_CD);
    __sqoop$field_map.put("CTR_COV_ID", this.CTR_COV_ID);
    __sqoop$field_map.put("ENDR_NO", this.ENDR_NO);
    __sqoop$field_map.put("UNT_PD_CD", this.UNT_PD_CD);
    __sqoop$field_map.put("SBCP_YYMM", this.SBCP_YYMM);
    __sqoop$field_map.put("FEE_PAY_TP_CD", this.FEE_PAY_TP_CD);
    __sqoop$field_map.put("SBCP_DT", this.SBCP_DT);
    __sqoop$field_map.put("ENDR_DT", this.ENDR_DT);
    __sqoop$field_map.put("DMG_RT_COV_DCTG_CD", this.DMG_RT_COV_DCTG_CD);
    __sqoop$field_map.put("INS_PRD_TP_CD", this.INS_PRD_TP_CD);
    __sqoop$field_map.put("INS_PRD", this.INS_PRD);
    __sqoop$field_map.put("PY_PRD_TP_CD", this.PY_PRD_TP_CD);
    __sqoop$field_map.put("PY_PRD", this.PY_PRD);
    __sqoop$field_map.put("PY_CYC_CD", this.PY_CYC_CD);
    __sqoop$field_map.put("SBC_AGE", this.SBC_AGE);
    __sqoop$field_map.put("GNDR_CD", this.GNDR_CD);
    __sqoop$field_map.put("INJR_GR_NUM", this.INJR_GR_NUM);
    __sqoop$field_map.put("LAST_PY_YYMM", this.LAST_PY_YYMM);
    __sqoop$field_map.put("LAST_PY_TMS", this.LAST_PY_TMS);
    __sqoop$field_map.put("RCRT_HDQT_ORG_CD", this.RCRT_HDQT_ORG_CD);
    __sqoop$field_map.put("RCRT_BRCH_ORG_CD", this.RCRT_BRCH_ORG_CD);
    __sqoop$field_map.put("RCRT_BCH_ORG_CD", this.RCRT_BCH_ORG_CD);
    __sqoop$field_map.put("RCRT_TRTPE_ORG_CD", this.RCRT_TRTPE_ORG_CD);
    __sqoop$field_map.put("RCRT_AGC_PLNR_CD", this.RCRT_AGC_PLNR_CD);
    __sqoop$field_map.put("TRT_HDQT_ORG_CD", this.TRT_HDQT_ORG_CD);
    __sqoop$field_map.put("TRT_BRCH_ORG_CD", this.TRT_BRCH_ORG_CD);
    __sqoop$field_map.put("TRT_BCH_ORG_CD", this.TRT_BCH_ORG_CD);
    __sqoop$field_map.put("TRTPE_ORG_CD", this.TRTPE_ORG_CD);
    __sqoop$field_map.put("AGC_PLNR_CD", this.AGC_PLNR_CD);
    __sqoop$field_map.put("HDQT_OPPN_DG_CF", this.HDQT_OPPN_DG_CF);
    __sqoop$field_map.put("SLZ_PREM", this.SLZ_PREM);
    __sqoop$field_map.put("IRTD_MKVL_AMT", this.IRTD_MKVL_AMT);
    __sqoop$field_map.put("BZEX_MKVL_AMT", this.BZEX_MKVL_AMT);
    __sqoop$field_map.put("RSKEX_MKVL_AMT", this.RSKEX_MKVL_AMT);
    __sqoop$field_map.put("EIH_LDG_DTM", this.EIH_LDG_DTM);
    __sqoop$field_map.put("RB_EXP_CPR", this.RB_EXP_CPR);
    __sqoop$field_map.put("RSK_PREM_CPR", this.RSK_PREM_CPR);
    __sqoop$field_map.put("ORIG_PREM_CPR", this.ORIG_PREM_CPR);
    __sqoop$field_map.put("MKVL_CPR", this.MKVL_CPR);
    __sqoop$field_map.put("EXPR_RFD_AMT_CPR", this.EXPR_RFD_AMT_CPR);
    __sqoop$field_map.put("CLAT_CPR", this.CLAT_CPR);
    __sqoop$field_map.put("SRVL_BNT_CPR", this.SRVL_BNT_CPR);
    __sqoop$field_map.put("ANN_PAY_AMT_CPR", this.ANN_PAY_AMT_CPR);
    __sqoop$field_map.put("PO_ETPY_CPR", this.PO_ETPY_CPR);
    __sqoop$field_map.put("MNCL_FEE_CPR", this.MNCL_FEE_CPR);
    __sqoop$field_map.put("SAV_PREM_CPR", this.SAV_PREM_CPR);
    __sqoop$field_map.put("XACQ_EXP_CPR", this.XACQ_EXP_CPR);
    __sqoop$field_map.put("XPT_MTN_EXP_CPR", this.XPT_MTN_EXP_CPR);
    __sqoop$field_map.put("XPT_MNCL_EXP_CPR", this.XPT_MNCL_EXP_CPR);
    __sqoop$field_map.put("INS_AMT_CPR", this.INS_AMT_CPR);
    __sqoop$field_map.put("NPTPY_NW_CTR_RSLFE_CPR", this.NPTPY_NW_CTR_RSLFE_CPR);
    __sqoop$field_map.put("NPTPY_ETC_NPO_CPR", this.NPTPY_ETC_NPO_CPR);
    __sqoop$field_map.put("TMN_MGI_CPR", this.TMN_MGI_CPR);
    __sqoop$field_map.put("ACD_ATTM_RDY_AMT_CPR", this.ACD_ATTM_RDY_AMT_CPR);
    __sqoop$field_map.put("PY_EXEM_PREM_CPR", this.PY_EXEM_PREM_CPR);
    __sqoop$field_map.put("HFWY_WDR_CPR", this.HFWY_WDR_CPR);
    __sqoop$field_map.put("TMN_RSK_PREM_CPR", this.TMN_RSK_PREM_CPR);
    __sqoop$field_map.put("LCAT_PD_CLAT_CPR", this.LCAT_PD_CLAT_CPR);
    __sqoop$field_map.put("TMN_ATTM_RDY_AMT_CPR", this.TMN_ATTM_RDY_AMT_CPR);
    __sqoop$field_map.put("DMN15_WTHN_SLZ_PREM", this.DMN15_WTHN_SLZ_PREM);
    __sqoop$field_map.put("DMN15_TMTD_RDY_AMT", this.DMN15_TMTD_RDY_AMT);
    __sqoop$field_map.put("OWN_CTR_YN", this.OWN_CTR_YN);
    __sqoop$field_map.put("CTR_CONV_SIC_SBC_YN", this.CTR_CONV_SIC_SBC_YN);
    __sqoop$field_map.put("SBC_AMT", this.SBC_AMT);
    __sqoop$field_map.put("CRD_FEE_CPR", this.CRD_FEE_CPR);
    __sqoop$field_map.put("CUS_CNTRB_ERN_AMT", this.CUS_CNTRB_ERN_AMT);
    __sqoop$field_map.put("SUM_FEE_CPR", this.SUM_FEE_CPR);
    __sqoop$field_map.put("ITRT_RISK_AMT", this.ITRT_RISK_AMT);
    __sqoop$field_map.put("KICS_MKVL_CPR", this.KICS_MKVL_CPR);
    __sqoop$field_map.put("ITRT_DEPRC_MKVL_CPR", this.ITRT_DEPRC_MKVL_CPR);
    __sqoop$field_map.put("ITRT_ASCD_MKVL_CPR", this.ITRT_ASCD_MKVL_CPR);
    __sqoop$field_map.put("CTR_INS_PRD_TP_CD", this.CTR_INS_PRD_TP_CD);
    __sqoop$field_map.put("MMPY_CNVS_PREM", this.MMPY_CNVS_PREM);
    __sqoop$field_map.put("PLAN_CD", this.PLAN_CD);
    __sqoop$field_map.put("COV_UNT_PD_CD", this.COV_UNT_PD_CD);
    __sqoop$field_map.put("CSS_PREM_CPR", this.CSS_PREM_CPR);
    __sqoop$field_map.put("CSS_INS_AMT_RFD_CPR", this.CSS_INS_AMT_RFD_CPR);
    __sqoop$field_map.put("MKVL_BKPM_AMT_CPR", this.MKVL_BKPM_AMT_CPR);
    __sqoop$field_map.put("CSS_RT", this.CSS_RT);
    __sqoop$field_map.put("CLF_DIV_CD", this.CLF_DIV_CD);
    __sqoop$field_map.put("INS_SBC_SH_CD", this.INS_SBC_SH_CD);
    __sqoop$field_map.put("SBC_DSG_FEE_PAY_TP_CD", this.SBC_DSG_FEE_PAY_TP_CD);
    __sqoop$field_map.put("SBC_DSG_IRTD_MVAT", this.SBC_DSG_IRTD_MVAT);
    __sqoop$field_map.put("SBC_DSG_BZEX_MVAT", this.SBC_DSG_BZEX_MVAT);
    __sqoop$field_map.put("SBC_DSG_RSKEX_MVAT", this.SBC_DSG_RSKEX_MVAT);
    __sqoop$field_map.put("SBC_DSG_RB_EXP_CPR", this.SBC_DSG_RB_EXP_CPR);
    __sqoop$field_map.put("SBC_DSG_RSK_PREM_CPR", this.SBC_DSG_RSK_PREM_CPR);
    __sqoop$field_map.put("SBC_DSG_ORIG_PREM_CPR", this.SBC_DSG_ORIG_PREM_CPR);
    __sqoop$field_map.put("SBC_DSG_MKVL_CPR", this.SBC_DSG_MKVL_CPR);
    __sqoop$field_map.put("LWRT_TMN_RFD_TP_CD", this.LWRT_TMN_RFD_TP_CD);
    __sqoop$field_map.put("LGTM_ITMS_DIV_CD", this.LGTM_ITMS_DIV_CD);
    __sqoop$field_map.put("ADVEXP", this.ADVEXP);
    __sqoop$field_map.put("TRTPE_TRFR_YN", this.TRTPE_TRFR_YN);
    __sqoop$field_map.put("DTBT_CTR_YN", this.DTBT_CTR_YN);
    __sqoop$field_map.put("INSPE_GRDE_VAL", this.INSPE_GRDE_VAL);
    __sqoop$field_map.put("PY_EXEM_TP_CD", this.PY_EXEM_TP_CD);
    __sqoop$field_map.put("AMBA_CHN_DIV_CD", this.AMBA_CHN_DIV_CD);
    __sqoop$field_map.put("PSINS_CRD_ETC_FEE", this.PSINS_CRD_ETC_FEE);
    __sqoop$field_map.put("PSINS_AT_TRS_ETC_FEE", this.PSINS_AT_TRS_ETC_FEE);
    __sqoop$field_map.put("PSINS_COMS_ETC_FEE", this.PSINS_COMS_ETC_FEE);
    __sqoop$field_map.put("LGTM_CHGE_EXP", this.LGTM_CHGE_EXP);
    __sqoop$field_map.put("LGTM_FIXT_EXP", this.LGTM_FIXT_EXP);
    __sqoop$field_map.put("PSINS_ATNS_MKVL_AMT", this.PSINS_ATNS_MKVL_AMT);
    return __sqoop$field_map;
  }

  public void getFieldMap0(Map<String, Object> __sqoop$field_map) {
    __sqoop$field_map.put("CLOG_YYMM", this.CLOG_YYMM);
    __sqoop$field_map.put("STD_DT", this.STD_DT);
    __sqoop$field_map.put("CTR_CHNG_STAT_CD", this.CTR_CHNG_STAT_CD);
    __sqoop$field_map.put("POL_NO", this.POL_NO);
    __sqoop$field_map.put("COV_CD", this.COV_CD);
    __sqoop$field_map.put("CTR_COV_ID", this.CTR_COV_ID);
    __sqoop$field_map.put("ENDR_NO", this.ENDR_NO);
    __sqoop$field_map.put("UNT_PD_CD", this.UNT_PD_CD);
    __sqoop$field_map.put("SBCP_YYMM", this.SBCP_YYMM);
    __sqoop$field_map.put("FEE_PAY_TP_CD", this.FEE_PAY_TP_CD);
    __sqoop$field_map.put("SBCP_DT", this.SBCP_DT);
    __sqoop$field_map.put("ENDR_DT", this.ENDR_DT);
    __sqoop$field_map.put("DMG_RT_COV_DCTG_CD", this.DMG_RT_COV_DCTG_CD);
    __sqoop$field_map.put("INS_PRD_TP_CD", this.INS_PRD_TP_CD);
    __sqoop$field_map.put("INS_PRD", this.INS_PRD);
    __sqoop$field_map.put("PY_PRD_TP_CD", this.PY_PRD_TP_CD);
    __sqoop$field_map.put("PY_PRD", this.PY_PRD);
    __sqoop$field_map.put("PY_CYC_CD", this.PY_CYC_CD);
    __sqoop$field_map.put("SBC_AGE", this.SBC_AGE);
    __sqoop$field_map.put("GNDR_CD", this.GNDR_CD);
    __sqoop$field_map.put("INJR_GR_NUM", this.INJR_GR_NUM);
    __sqoop$field_map.put("LAST_PY_YYMM", this.LAST_PY_YYMM);
    __sqoop$field_map.put("LAST_PY_TMS", this.LAST_PY_TMS);
    __sqoop$field_map.put("RCRT_HDQT_ORG_CD", this.RCRT_HDQT_ORG_CD);
    __sqoop$field_map.put("RCRT_BRCH_ORG_CD", this.RCRT_BRCH_ORG_CD);
    __sqoop$field_map.put("RCRT_BCH_ORG_CD", this.RCRT_BCH_ORG_CD);
    __sqoop$field_map.put("RCRT_TRTPE_ORG_CD", this.RCRT_TRTPE_ORG_CD);
    __sqoop$field_map.put("RCRT_AGC_PLNR_CD", this.RCRT_AGC_PLNR_CD);
    __sqoop$field_map.put("TRT_HDQT_ORG_CD", this.TRT_HDQT_ORG_CD);
    __sqoop$field_map.put("TRT_BRCH_ORG_CD", this.TRT_BRCH_ORG_CD);
    __sqoop$field_map.put("TRT_BCH_ORG_CD", this.TRT_BCH_ORG_CD);
    __sqoop$field_map.put("TRTPE_ORG_CD", this.TRTPE_ORG_CD);
    __sqoop$field_map.put("AGC_PLNR_CD", this.AGC_PLNR_CD);
    __sqoop$field_map.put("HDQT_OPPN_DG_CF", this.HDQT_OPPN_DG_CF);
    __sqoop$field_map.put("SLZ_PREM", this.SLZ_PREM);
    __sqoop$field_map.put("IRTD_MKVL_AMT", this.IRTD_MKVL_AMT);
    __sqoop$field_map.put("BZEX_MKVL_AMT", this.BZEX_MKVL_AMT);
    __sqoop$field_map.put("RSKEX_MKVL_AMT", this.RSKEX_MKVL_AMT);
    __sqoop$field_map.put("EIH_LDG_DTM", this.EIH_LDG_DTM);
    __sqoop$field_map.put("RB_EXP_CPR", this.RB_EXP_CPR);
    __sqoop$field_map.put("RSK_PREM_CPR", this.RSK_PREM_CPR);
    __sqoop$field_map.put("ORIG_PREM_CPR", this.ORIG_PREM_CPR);
    __sqoop$field_map.put("MKVL_CPR", this.MKVL_CPR);
    __sqoop$field_map.put("EXPR_RFD_AMT_CPR", this.EXPR_RFD_AMT_CPR);
    __sqoop$field_map.put("CLAT_CPR", this.CLAT_CPR);
    __sqoop$field_map.put("SRVL_BNT_CPR", this.SRVL_BNT_CPR);
    __sqoop$field_map.put("ANN_PAY_AMT_CPR", this.ANN_PAY_AMT_CPR);
    __sqoop$field_map.put("PO_ETPY_CPR", this.PO_ETPY_CPR);
    __sqoop$field_map.put("MNCL_FEE_CPR", this.MNCL_FEE_CPR);
    __sqoop$field_map.put("SAV_PREM_CPR", this.SAV_PREM_CPR);
    __sqoop$field_map.put("XACQ_EXP_CPR", this.XACQ_EXP_CPR);
    __sqoop$field_map.put("XPT_MTN_EXP_CPR", this.XPT_MTN_EXP_CPR);
    __sqoop$field_map.put("XPT_MNCL_EXP_CPR", this.XPT_MNCL_EXP_CPR);
    __sqoop$field_map.put("INS_AMT_CPR", this.INS_AMT_CPR);
    __sqoop$field_map.put("NPTPY_NW_CTR_RSLFE_CPR", this.NPTPY_NW_CTR_RSLFE_CPR);
    __sqoop$field_map.put("NPTPY_ETC_NPO_CPR", this.NPTPY_ETC_NPO_CPR);
    __sqoop$field_map.put("TMN_MGI_CPR", this.TMN_MGI_CPR);
    __sqoop$field_map.put("ACD_ATTM_RDY_AMT_CPR", this.ACD_ATTM_RDY_AMT_CPR);
    __sqoop$field_map.put("PY_EXEM_PREM_CPR", this.PY_EXEM_PREM_CPR);
    __sqoop$field_map.put("HFWY_WDR_CPR", this.HFWY_WDR_CPR);
    __sqoop$field_map.put("TMN_RSK_PREM_CPR", this.TMN_RSK_PREM_CPR);
    __sqoop$field_map.put("LCAT_PD_CLAT_CPR", this.LCAT_PD_CLAT_CPR);
    __sqoop$field_map.put("TMN_ATTM_RDY_AMT_CPR", this.TMN_ATTM_RDY_AMT_CPR);
    __sqoop$field_map.put("DMN15_WTHN_SLZ_PREM", this.DMN15_WTHN_SLZ_PREM);
    __sqoop$field_map.put("DMN15_TMTD_RDY_AMT", this.DMN15_TMTD_RDY_AMT);
    __sqoop$field_map.put("OWN_CTR_YN", this.OWN_CTR_YN);
    __sqoop$field_map.put("CTR_CONV_SIC_SBC_YN", this.CTR_CONV_SIC_SBC_YN);
    __sqoop$field_map.put("SBC_AMT", this.SBC_AMT);
    __sqoop$field_map.put("CRD_FEE_CPR", this.CRD_FEE_CPR);
    __sqoop$field_map.put("CUS_CNTRB_ERN_AMT", this.CUS_CNTRB_ERN_AMT);
    __sqoop$field_map.put("SUM_FEE_CPR", this.SUM_FEE_CPR);
    __sqoop$field_map.put("ITRT_RISK_AMT", this.ITRT_RISK_AMT);
    __sqoop$field_map.put("KICS_MKVL_CPR", this.KICS_MKVL_CPR);
    __sqoop$field_map.put("ITRT_DEPRC_MKVL_CPR", this.ITRT_DEPRC_MKVL_CPR);
    __sqoop$field_map.put("ITRT_ASCD_MKVL_CPR", this.ITRT_ASCD_MKVL_CPR);
    __sqoop$field_map.put("CTR_INS_PRD_TP_CD", this.CTR_INS_PRD_TP_CD);
    __sqoop$field_map.put("MMPY_CNVS_PREM", this.MMPY_CNVS_PREM);
    __sqoop$field_map.put("PLAN_CD", this.PLAN_CD);
    __sqoop$field_map.put("COV_UNT_PD_CD", this.COV_UNT_PD_CD);
    __sqoop$field_map.put("CSS_PREM_CPR", this.CSS_PREM_CPR);
    __sqoop$field_map.put("CSS_INS_AMT_RFD_CPR", this.CSS_INS_AMT_RFD_CPR);
    __sqoop$field_map.put("MKVL_BKPM_AMT_CPR", this.MKVL_BKPM_AMT_CPR);
    __sqoop$field_map.put("CSS_RT", this.CSS_RT);
    __sqoop$field_map.put("CLF_DIV_CD", this.CLF_DIV_CD);
    __sqoop$field_map.put("INS_SBC_SH_CD", this.INS_SBC_SH_CD);
    __sqoop$field_map.put("SBC_DSG_FEE_PAY_TP_CD", this.SBC_DSG_FEE_PAY_TP_CD);
    __sqoop$field_map.put("SBC_DSG_IRTD_MVAT", this.SBC_DSG_IRTD_MVAT);
    __sqoop$field_map.put("SBC_DSG_BZEX_MVAT", this.SBC_DSG_BZEX_MVAT);
    __sqoop$field_map.put("SBC_DSG_RSKEX_MVAT", this.SBC_DSG_RSKEX_MVAT);
    __sqoop$field_map.put("SBC_DSG_RB_EXP_CPR", this.SBC_DSG_RB_EXP_CPR);
    __sqoop$field_map.put("SBC_DSG_RSK_PREM_CPR", this.SBC_DSG_RSK_PREM_CPR);
    __sqoop$field_map.put("SBC_DSG_ORIG_PREM_CPR", this.SBC_DSG_ORIG_PREM_CPR);
    __sqoop$field_map.put("SBC_DSG_MKVL_CPR", this.SBC_DSG_MKVL_CPR);
    __sqoop$field_map.put("LWRT_TMN_RFD_TP_CD", this.LWRT_TMN_RFD_TP_CD);
    __sqoop$field_map.put("LGTM_ITMS_DIV_CD", this.LGTM_ITMS_DIV_CD);
    __sqoop$field_map.put("ADVEXP", this.ADVEXP);
    __sqoop$field_map.put("TRTPE_TRFR_YN", this.TRTPE_TRFR_YN);
    __sqoop$field_map.put("DTBT_CTR_YN", this.DTBT_CTR_YN);
    __sqoop$field_map.put("INSPE_GRDE_VAL", this.INSPE_GRDE_VAL);
    __sqoop$field_map.put("PY_EXEM_TP_CD", this.PY_EXEM_TP_CD);
    __sqoop$field_map.put("AMBA_CHN_DIV_CD", this.AMBA_CHN_DIV_CD);
    __sqoop$field_map.put("PSINS_CRD_ETC_FEE", this.PSINS_CRD_ETC_FEE);
    __sqoop$field_map.put("PSINS_AT_TRS_ETC_FEE", this.PSINS_AT_TRS_ETC_FEE);
    __sqoop$field_map.put("PSINS_COMS_ETC_FEE", this.PSINS_COMS_ETC_FEE);
    __sqoop$field_map.put("LGTM_CHGE_EXP", this.LGTM_CHGE_EXP);
    __sqoop$field_map.put("LGTM_FIXT_EXP", this.LGTM_FIXT_EXP);
    __sqoop$field_map.put("PSINS_ATNS_MKVL_AMT", this.PSINS_ATNS_MKVL_AMT);
  }

  public void setField(String __fieldName, Object __fieldVal) {
    if (!setters.containsKey(__fieldName)) {
      throw new RuntimeException("No such field:"+__fieldName);
    }
    setters.get(__fieldName).setField(__fieldVal);
  }

}
