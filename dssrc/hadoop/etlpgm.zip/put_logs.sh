#!/bin/bash

YYMMDD=200118

hdfs dfs -put -f hive_time_hdfs.txt /tmp/sqoop_dir/hive_time_hdfs_$YYMMDD.txt
echo "hive_time_hdfs.txt uploaded"

hdfs dfs -put -f jdbc_time_hdfs.txt /tmp/sqoop_dir/jdbc_time_hdfs_$YYMMDD.txt
echo "jdbc_time_hdfs.txt uploaded"
