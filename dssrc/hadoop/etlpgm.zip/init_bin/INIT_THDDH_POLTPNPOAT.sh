#!/bin/bash

if [ $# -eq 0 ]
then           
    ARGS=N    
else           
    ARGS=$1
fi             

NOW=$(date +"+%Y-%m-%d_%T")
SHLOG_DIR=/sqoopbin/scripts/etlpgm/cur_log
HISLOG_DIR=/sqoopbin/scripts/etlpgm/his_log

export HADOOP_OPTS=-Djava.security.egd=file:/dev/../dev/urandom
export ORACLE_BASE=/sw/oracle
export ORACLE_HOME=/sw/oracle/product/11.2.0.4/client_1
export LD_LIBRARY_PATH=/sw/oracle/product/11.2.0.4/client_1/lib:/sw/oracle/product/11.2.0.4/client_1/lib:
export PATH=/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/usr/lib64/qt-3.3/bin:/var/opt/node/bin/:/usr/hdp/3.0.0.0-1634/spark2/bin/:/opt/maven/bin:/usr/local/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/home/hdpapp/.local/bin:/home/hdpapp/bin
export TNS_ADMIN=/sw/oracle/product/11.2.0.4/client_1/network/admin
export ORACLE_SID=DBEDWP2
export NLS_LANG=American_America.KO16MSWIN949

#----------------------------------------------------#
# 작업내용 : THDDH_POLTPNPOAT 테이블 sqoop 복제 작업
# 작업주기 : D 
#----------------------------------------------------#

    echo " "
    echo "*-----------[ INIT_THDDH_POLTPNPOAT.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ INIT_THDDH_POLTPNPOAT.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`  >  ${SHLOG_DIR}/INIT_THDDH_POLTPNPOAT.shlog

#----------------------------------------------------#
# 테이블별 전체 데이터를 받아 오는 부분
#----------------------------------------------------#
    /usr/bin/hadoop fs -rm -r -f  /tmp2/INIT_THDDH_POLTPNPOAT  >> ${SHLOG_DIR}/INIT_THDDH_POLTPNPOAT.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.INIT_THDDH_POLTPNPOAT ; " >> ${SHLOG_DIR}/INIT_THDDH_POLTPNPOAT.shlog 2>&1 &&
    /usr/hdp/3.0.0.0-1634/sqoop/bin/sqoop import -D mapred.child.java.opts="-Djava.security.egd=file:/dev/../dev/urandom" \
    --connect jdbc:oracle:thin:EDWHADOOP/wjdqhrP\!23@10.91.41.172:12560:DBEDWP2 \
    --username  EDWHADOOP \
    --password wjdqhrP\!23 \
    --query "SELECT REPLACE(REPLACE(CLOG_YYMM,CHR(13),''),CHR(10),'') CLOG_YYMM
, REPLACE(REPLACE(POL_NO,CHR(13),''),CHR(10),'') POL_NO
, REPLACE(REPLACE(POL_NO2,CHR(13),''),CHR(10),'') POL_NO2
, REPLACE(REPLACE(BZ_EXP_ACTL_CD,CHR(13),''),CHR(10),'') BZ_EXP_ACTL_CD
, REPLACE(REPLACE(NPO_DIV_CD,CHR(13),''),CHR(10),'') NPO_DIV_CD
, REPLACE(REPLACE(DPT_ORG_CD1,CHR(13),''),CHR(10),'') DPT_ORG_CD1
, REPLACE(REPLACE(DPT_ORG_CD2,CHR(13),''),CHR(10),'') DPT_ORG_CD2
, REPLACE(REPLACE(DPT_ORG_CD3,CHR(13),''),CHR(10),'') DPT_ORG_CD3
, REPLACE(REPLACE(TRTPE_ORG_CD1,CHR(13),''),CHR(10),'') TRTPE_ORG_CD1
, REPLACE(REPLACE(TRTPE_ORG_CD2,CHR(13),''),CHR(10),'') TRTPE_ORG_CD2
, REPLACE(REPLACE(INCM_TRM_EMT_CD,CHR(13),''),CHR(10),'') INCM_TRM_EMT_CD
, REPLACE(REPLACE(CEXP_CD,CHR(13),''),CHR(10),'') CEXP_CD
, REPLACE(REPLACE(PD_CD,CHR(13),''),CHR(10),'') PD_CD
, REPLACE(REPLACE(SZEPID_DIV_CD,CHR(13),''),CHR(10),'') SZEPID_DIV_CD
, REPLACE(REPLACE(BZ_EXP_SAL_CHN_CD,CHR(13),''),CHR(10),'') BZ_EXP_SAL_CHN_CD
, REPLACE(REPLACE(TPT_DIV_NM,CHR(13),''),CHR(10),'') TPT_DIV_NM
, GRTY_SEQ
, BZ_EXP
, SNGL_ACRSL_AMT
, SUM_ACRSL_AMT
, ACRSL_RTO
, APAMT
, EIH_LDG_DTM FROM THDDH_POLTPNPOAT
                       WHERE \$CONDITIONS
                         AND CLOG_YYMM BETWEEN '201809' AND '201907' "\
    --m 1 \
    --target-dir /tmp2/INIT_THDDH_POLTPNPOAT \
    --hive-import \
    --external-table-dir hdfs:///tmp2/temp_tbl/INIT_THDDH_POLTPNPOAT \
    --hive-overwrite \
    --hive-table DEFAULT.INIT_THDDH_POLTPNPOAT  >> ${SHLOG_DIR}/INIT_THDDH_POLTPNPOAT.shlog 2>&1 &&

#----------------------------------------------------#
# Hadoop 원본테이블에 변경분 최종 적용
#----------------------------------------------------#
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_POLTPNPOAT_ITMP ; " >> ${SHLOG_DIR}/INIT_THDDH_POLTPNPOAT.shlog 2>&1 &&
    /usr/bin/hive -e "CREATE EXTERNAL TABLE MERITZ.THDDH_POLTPNPOAT_ITMP STORED AS PARQUET TBLPROPERTIES ('PARQUET.COMPRESS'='SNAPPY') AS
                                SELECT *
                                FROM DEFAULT.INIT_THDDH_POLTPNPOAT
                                UNION ALL
                                SELECT * 
                                FROM MERITZ.THDDH_POLTPNPOAT ;" >> ${SHLOG_DIR}/INIT_THDDH_POLTPNPOAT.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.INIT_THDDH_POLTPNPOAT ;" >> ${SHLOG_DIR}/INIT_THDDH_POLTPNPOAT.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_POLTPNPOAT ;" >> ${SHLOG_DIR}/INIT_THDDH_POLTPNPOAT.shlog 2>&1 &&
    /usr/bin/hive -e "ALTER TABLE MERITZ.THDDH_POLTPNPOAT_ITMP RENAME TO MERITZ.THDDH_POLTPNPOAT ;" >> ${SHLOG_DIR}/INIT_THDDH_POLTPNPOAT.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_POLTPNPOAT_ITMP ;" >> ${SHLOG_DIR}/INIT_THDDH_POLTPNPOAT.shlog 2>&1 

if [ $? -ne 0 ]
then             
    echo "*-----------[ INIT_THDDH_POLTPNPOAT.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/INIT_THDDH_POLTPNPOAT.shlog"
    echo "*-----------[ INIT_THDDH_POLTPNPOAT.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/INIT_THDDH_POLTPNPOAT.shlog"  >>  ${SHLOG_DIR}/INIT_THDDH_POLTPNPOAT.shlog
    echo "*-----------[ INIT_THDDH_POLTPNPOAT.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ INIT_THDDH_POLTPNPOAT.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/INIT_THDDH_POLTPNPOAT.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/INIT_THDDH_POLTPNPOAT.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/INIT_THDDH_POLTPNPOAT.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/INIT_THDDH_POLTPNPOAT.shlog /sqoopbin/scripts/etlpgm/his_log/INIT_THDDH_POLTPNPOAT_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  INIT_THDDH_POLTPNPOAT.sh cmd command error !! ***
    fi               

    exit -1      

else             
    echo "*-----------[ INIT_THDDH_POLTPNPOAT.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ INIT_THDDH_POLTPNPOAT.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/INIT_THDDH_POLTPNPOAT.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/INIT_THDDH_POLTPNPOAT.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/INIT_THDDH_POLTPNPOAT.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/INIT_THDDH_POLTPNPOAT.shlog /sqoopbin/scripts/etlpgm/his_log/INIT_THDDH_POLTPNPOAT_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  INIT_THDDH_POLTPNPOAT.sh cmd command error !! ***
        exit -1      
    else             
        exit 0       
    fi               
fi               
