#!/bin/bash

if [ $# -eq 0 ]
then           
    ARGS=N    
else           
    ARGS=$1
fi             

NOW=$(date +"+%Y-%m-%d_%T")
SHLOG_DIR=/sqoopbin/scripts/etlpgm/cur_log
HISLOG_DIR=/sqoopbin/scripts/etlpgm/his_log

export HADOOP_OPTS=-Djava.security.egd=file:/dev/../dev/urandom
export ORACLE_BASE=/sw/oracle
export ORACLE_HOME=/sw/oracle/product/11.2.0.4/client_1
export LD_LIBRARY_PATH=/sw/oracle/product/11.2.0.4/client_1/lib:/sw/oracle/product/11.2.0.4/client_1/lib:
export PATH=/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/usr/lib64/qt-3.3/bin:/var/opt/node/bin/:/usr/hdp/3.0.0.0-1634/spark2/bin/:/opt/maven/bin:/usr/local/bin:/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/home/hdpapp/workspace/data-science-at-the-command-line/tools:/home/hdpapp/.local/bin:/home/hdpapp/bin
export TNS_ADMIN=/sw/oracle/product/11.2.0.4/client_1/network/admin
export ORACLE_SID=DBEDWP2
export NLS_LANG=American_America.KO16MSWIN949

#----------------------------------------------------#
# 작업내용 : THDDH_TCLDGN 테이블 sqoop 복제 작업
# 작업주기 : D 
#----------------------------------------------------#

    echo " "
    echo "*-----------[ INIT_THDDH_TCLDGN.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ INIT_THDDH_TCLDGN.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`  >  ${SHLOG_DIR}/INIT_THDDH_TCLDGN.shlog

#----------------------------------------------------#
# 테이블별 전체 데이터를 받아 오는 부분
#----------------------------------------------------#
    /usr/bin/hadoop fs -rm -r -f  /tmp2/INIT_THDDH_TCLDGN  >> ${SHLOG_DIR}/INIT_THDDH_TCLDGN.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.INIT_THDDH_TCLDGN ; " >> ${SHLOG_DIR}/INIT_THDDH_TCLDGN.shlog 2>&1 &&
    /usr/hdp/3.0.0.0-1634/sqoop/bin/sqoop import -D mapred.child.java.opts="-Djava.security.egd=file:/dev/../dev/urandom" \
    --connect jdbc:oracle:thin:EDWHADOOP/wjdqhrP\!23@10.91.41.172:12560:DBEDWP2 \
    --username  EDWHADOOP \
    --password wjdqhrP\!23 \
    --query "SELECT REPLACE(REPLACE(DGN_ID,CHR(13),''),CHR(10),'') DGN_ID
, HIS_SEQ
, REPLACE(REPLACE(COMS_BIZ_DIV_CD,CHR(13),''),CHR(10),'') COMS_BIZ_DIV_CD
, REPLACE(REPLACE(DMPE_ID,CHR(13),''),CHR(10),'') DMPE_ID
, REPLACE(REPLACE(DMG_SVY_OCDIV_CD,CHR(13),''),CHR(10),'') DMG_SVY_OCDIV_CD
, REPLACE(REPLACE(DMG_SVY_DATA_DIV_CD,CHR(13),''),CHR(10),'') DMG_SVY_DATA_DIV_CD
, REPLACE(REPLACE(DATA_ID,CHR(13),''),CHR(10),'') DATA_ID
, REPLACE(REPLACE(DGN_DIV_CD,CHR(13),''),CHR(10),'') DGN_DIV_CD
, REPLACE(REPLACE(CLM_ID,CHR(13),''),CHR(10),'') CLM_ID
, REPLACE(REPLACE(WND_GR_CD,CHR(13),''),CHR(10),'') WND_GR_CD
, REPLACE(REPLACE(WND_HAG_CD,CHR(13),''),CHR(10),'') WND_HAG_CD
, REPLACE(REPLACE(TTH_GR_CD,CHR(13),''),CHR(10),'') TTH_GR_CD
, REPLACE(REPLACE(TTH_HAG_CD,CHR(13),''),CHR(10),'') TTH_HAG_CD
, TTH_NUB
, TTH_UCT
, REPLACE(REPLACE(OBST_GR_CD,CHR(13),''),CHR(10),'') OBST_GR_CD
, REPLACE(REPLACE(OBST_HAG_CD,CHR(13),''),CHR(10),'') OBST_HAG_CD
, REPLACE(REPLACE(HOSP_BZAC_ID,CHR(13),''),CHR(10),'') HOSP_BZAC_ID
, REPLACE(REPLACE(DR_LCNS_NO,CHR(13),''),CHR(10),'') DR_LCNS_NO
, REPLACE(REPLACE(DR_NM,CHR(13),''),CHR(10),'') DR_NM
, REPLACE(REPLACE(DGN_HOSP_NM,CHR(13),''),CHR(10),'') DGN_HOSP_NM
, REPLACE(REPLACE(MET_SBJ_CD,CHR(13),''),CHR(10),'') MET_SBJ_CD
, REPLACE(REPLACE(OBST_EVL_STD_CD,CHR(13),''),CHR(10),'') OBST_EVL_STD_CD
, REPLACE(REPLACE(APL_STD_DT_CD,CHR(13),''),CHR(10),'') APL_STD_DT_CD
, APL_STD_DT
, REPLACE(REPLACE(MED_FLT_YN,CHR(13),''),CHR(10),'') MED_FLT_YN
, REPLACE(REPLACE(CSEF_REL_YN,CHR(13),''),CHR(10),'') CSEF_REL_YN
, ETRN_OBST_RT
, MMN_OBST_RT
, TT_OBST_RT
, ACD_PTDG
, ISS_DT
, DGN_DT
, DFCR_LEN
, REPLACE(REPLACE(CLNC_LAST_DIV_CD,CHR(13),''),CHR(10),'') CLNC_LAST_DIV_CD
, REPLACE(REPLACE(NATL_HNC_EVL_STD_CD,CHR(13),''),CHR(10),'') NATL_HNC_EVL_STD_CD
, REPLACE(REPLACE(ORN_DGN_ID,CHR(13),''),CHR(10),'') ORN_DGN_ID
, REPLACE(REPLACE(DUP_DOC_CNF_CD,CHR(13),''),CHR(10),'') DUP_DOC_CNF_CD
, INF_OBM_FIX_SEQ
, REPLACE(REPLACE(INF_OBM_DCM_NO,CHR(13),''),CHR(10),'') INF_OBM_DCM_NO
, REPLACE(REPLACE(COMS_CHRPE_DIV_CD,CHR(13),''),CHR(10),'') COMS_CHRPE_DIV_CD
, HIS_ST_DTM
, HIS_ED_DTM
, REPLACE(REPLACE(INPPE_ORG_ID,CHR(13),''),CHR(10),'') INPPE_ORG_ID
, SYS_OCC_DTM
, REPLACE(REPLACE(SYS_DEL_DIV_CD,CHR(13),''),CHR(10),'') SYS_DEL_DIV_CD
, REPLACE(REPLACE(OCC_IP,CHR(13),''),CHR(10),'') OCC_IP
, REPLACE(REPLACE(APP_ID,CHR(13),''),CHR(10),'') APP_ID
, DATA_CHNG_DTM
, EIH_LDG_DTM
, REPLACE(REPLACE(CHNG_BF_WND_GR_CD,CHR(13),''),CHR(10),'') CHNG_BF_WND_GR_CD
, REPLACE(REPLACE(CHNG_BF_WND_HAG_CD,CHR(13),''),CHR(10),'') CHNG_BF_WND_HAG_CD
, REPLACE(REPLACE(TRFR_TRG_YN,CHR(13),''),CHR(10),'') TRFR_TRG_YN
, REPLACE(REPLACE(TRFR_ACD_RCT_ID,CHR(13),''),CHR(10),'') TRFR_ACD_RCT_ID
, REPLACE(REPLACE(DATA_TRFR_YN,CHR(13),''),CHR(10),'') DATA_TRFR_YN
, REPLACE(REPLACE(IMG_TRFR_YN,CHR(13),''),CHR(10),'') IMG_TRFR_YN
, REPLACE(REPLACE(OTH_ACD_USE_DIV_CD,CHR(13),''),CHR(10),'') OTH_ACD_USE_DIV_CD
, REPLACE(REPLACE(OTH_ACD_PRIMARYKEY_ID,CHR(13),''),CHR(10),'') OTH_ACD_PRIMARYKEY_ID FROM THDDH_TCLDGN
                       WHERE \$CONDITIONS "\
    --m 1 \
    --target-dir /tmp2/INIT_THDDH_TCLDGN \
    --hive-import \
    --external-table-dir hdfs:///tmp2/temp_tbl/INIT_THDDH_TCLDGN \
    --hive-overwrite \
    --hive-table DEFAULT.INIT_THDDH_TCLDGN  >> ${SHLOG_DIR}/INIT_THDDH_TCLDGN.shlog 2>&1 &&

#----------------------------------------------------#
# Hadoop 원본테이블에 변경분 최종 적용
#----------------------------------------------------#
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TCLDGN_ITMP ; " >> ${SHLOG_DIR}/INIT_THDDH_TCLDGN.shlog 2>&1 &&
    /usr/bin/hive -e "CREATE EXTERNAL TABLE MERITZ.THDDH_TCLDGN_ITMP STORED AS PARQUET TBLPROPERTIES ('PARQUET.COMPRESS'='SNAPPY') AS
                                SELECT *
                                FROM DEFAULT.INIT_THDDH_TCLDGN ;" >> ${SHLOG_DIR}/INIT_THDDH_TCLDGN.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.INIT_THDDH_TCLDGN ;" >> ${SHLOG_DIR}/INIT_THDDH_TCLDGN.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TCLDGN ;" >> ${SHLOG_DIR}/INIT_THDDH_TCLDGN.shlog 2>&1 &&
    /usr/bin/hive -e "ALTER TABLE MERITZ.THDDH_TCLDGN_ITMP RENAME TO MERITZ.THDDH_TCLDGN ;" >> ${SHLOG_DIR}/INIT_THDDH_TCLDGN.shlog 2>&1 &&
# external table 이 alter문 동작 다른 문제로 아래 과정이 필요해짐 
    /usr/bin/hive -e "ALTER TABLE MERITZ.THDDH_TCLDGN SET LOCATION 'hdfs:///warehouse/tablespace/external/hive/meritz.db/thddh_tcldgn_tmp' ;" >> ${SHLOG_DIR}/THDDH_TCLDGN.shlog 2>&1 &&
    /usr/bin/hdfs dfs -mv /warehouse/tablespace/external/hive/meritz.db/thddh_tcldgn_itmp /warehouse/tablespace/external/hive/meritz.db/thddh_tcldgn_tmp >> ${SHLOG_DIR}/THDDH_TCLDGN.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TCLDGN_ITMP ;" >> ${SHLOG_DIR}/INIT_THDDH_TCLDGN.shlog 2>&1 

if [ $? -ne 0 ]
then             
    echo "*-----------[ INIT_THDDH_TCLDGN.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/INIT_THDDH_TCLDGN.shlog"
    echo "*-----------[ INIT_THDDH_TCLDGN.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/INIT_THDDH_TCLDGN.shlog"  >>  ${SHLOG_DIR}/INIT_THDDH_TCLDGN.shlog
    echo "*-----------[ INIT_THDDH_TCLDGN.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ INIT_THDDH_TCLDGN.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/INIT_THDDH_TCLDGN.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/INIT_THDDH_TCLDGN.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/INIT_THDDH_TCLDGN.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/INIT_THDDH_TCLDGN.shlog /sqoopbin/scripts/etlpgm/his_log/INIT_THDDH_TCLDGN_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  INIT_THDDH_TCLDGN.sh cmd command error !! ***
    fi               

    exit -1      

else             
    echo "*-----------[ INIT_THDDH_TCLDGN.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ INIT_THDDH_TCLDGN.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/INIT_THDDH_TCLDGN.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/INIT_THDDH_TCLDGN.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/INIT_THDDH_TCLDGN.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/INIT_THDDH_TCLDGN.shlog /sqoopbin/scripts/etlpgm/his_log/INIT_THDDH_TCLDGN_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  INIT_THDDH_TCLDGN.sh cmd command error !! ***
        exit -1      
    else             
        exit 0       
    fi               
fi               
