#!/bin/bash

if [ $# -eq 0 ]
then           
    ARGS=N    
else           
    ARGS=$1
fi             

NOW=$(date +"+%Y-%m-%d_%T")
SHLOG_DIR=/sqoopbin/scripts/etlpgm/cur_log
HISLOG_DIR=/sqoopbin/scripts/etlpgm/his_log

export HADOOP_OPTS=-Djava.security.egd=file:/dev/../dev/urandom

#----------------------------------------------------#
# 작업내용 : THDDH_BKBNBCHSTC 테이블 sqoop 복제 작업
# 작업주기 : D 
#----------------------------------------------------#

    echo " "
    echo "*-----------[ INIT_THDDH_BKBNBCHSTC.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ INIT_THDDH_BKBNBCHSTC.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`  >  ${SHLOG_DIR}/INIT_THDDH_BKBNBCHSTC.shlog

#----------------------------------------------------#
# 테이블별 전체 데이터를 받아 오는 부분
#----------------------------------------------------#
    /usr/bin/hadoop fs -rm -r -f  /tmp2/INIT_THDDH_BKBNBCHSTC  >> ${SHLOG_DIR}/INIT_THDDH_BKBNBCHSTC.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.INIT_THDDH_BKBNBCHSTC ; " >> ${SHLOG_DIR}/INIT_THDDH_BKBNBCHSTC.shlog 2>&1 &&
    /usr/hdp/2.6.1.0-129/sqoop/bin/sqoop import -D mapred.child.java.opts="-Djava.security.egd=file:/dev/../dev/urandom" \
    --connect jdbc:oracle:thin:EDWHADOOP/wjdqhrP\!23@10.91.41.139:12560:DBEDWP2 \
    --username  EDWHADOOP \
    --password wjdqhrP\!23 \
    --query "SELECT EXE_DT
, REPLACE(REPLACE(BAT_FFMT_INF_ID,CHR(13),''),CHR(10),'') BAT_FFMT_INF_ID
, REPLACE(REPLACE(BAT_SVC_INF_ID,CHR(13),''),CHR(10),'') BAT_SVC_INF_ID
, REPLACE(REPLACE(BAT_SVC_NM,CHR(13),''),CHR(10),'') BAT_SVC_NM
, REPLACE(REPLACE(BAT_EXE_CYC_CD,CHR(13),''),CHR(10),'') BAT_EXE_CYC_CD
, MIN_FFMT_HR
, MAX_FFMT_HR
, BAT_TT_FFMT_HR
, AVG_FFMT_HR
, BAT_EXE_CNT
, EIH_LDG_DTM FROM THDDH_BKBNBCHSTC
                       WHERE \$CONDITIONS "\
    --m 1 \
    --target-dir /tmp2/INIT_THDDH_BKBNBCHSTC \
    --hive-import \
    --hive-overwrite \
    --hive-table DEFAULT.INIT_THDDH_BKBNBCHSTC  >> ${SHLOG_DIR}/INIT_THDDH_BKBNBCHSTC.shlog 2>&1 &&

#----------------------------------------------------#
# Hadoop 원본테이블에 변경분 최종 적용
#----------------------------------------------------#
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_BKBNBCHSTC_ITMP ; " >> ${SHLOG_DIR}/INIT_THDDH_BKBNBCHSTC.shlog 2>&1 &&
    /usr/bin/hive -e "CREATE TABLE MERITZ.THDDH_BKBNBCHSTC_ITMP STORED AS PARQUET TBLPROPERTIES ('PARQUET.COMPRESS'='SNAPPY') AS
                                SELECT *
                                FROM DEFAULT.INIT_THDDH_BKBNBCHSTC ;" >> ${SHLOG_DIR}/INIT_THDDH_BKBNBCHSTC.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.INIT_THDDH_BKBNBCHSTC ;" >> ${SHLOG_DIR}/INIT_THDDH_BKBNBCHSTC.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_BKBNBCHSTC ;" >> ${SHLOG_DIR}/INIT_THDDH_BKBNBCHSTC.shlog 2>&1 &&
    /usr/bin/hive -e "ALTER TABLE MERITZ.THDDH_BKBNBCHSTC_ITMP RENAME TO MERITZ.THDDH_BKBNBCHSTC ;" >> ${SHLOG_DIR}/INIT_THDDH_BKBNBCHSTC.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_BKBNBCHSTC_ITMP ;" >> ${SHLOG_DIR}/INIT_THDDH_BKBNBCHSTC.shlog 2>&1 

if [ $? -ne 0 ]
then             
    echo "*-----------[ INIT_THDDH_BKBNBCHSTC.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/INIT_THDDH_BKBNBCHSTC.shlog"
    echo "*-----------[ INIT_THDDH_BKBNBCHSTC.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/INIT_THDDH_BKBNBCHSTC.shlog"  >>  ${SHLOG_DIR}/INIT_THDDH_BKBNBCHSTC.shlog
    echo "*-----------[ INIT_THDDH_BKBNBCHSTC.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ INIT_THDDH_BKBNBCHSTC.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/INIT_THDDH_BKBNBCHSTC.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/INIT_THDDH_BKBNBCHSTC.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/INIT_THDDH_BKBNBCHSTC.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/INIT_THDDH_BKBNBCHSTC.shlog /sqoopbin/scripts/etlpgm/his_log/INIT_THDDH_BKBNBCHSTC_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  INIT_THDDH_BKBNBCHSTC.sh cmd command error !! ***
    fi               

    exit -1      

else             
    echo "*-----------[ INIT_THDDH_BKBNBCHSTC.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ INIT_THDDH_BKBNBCHSTC.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/INIT_THDDH_BKBNBCHSTC.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/INIT_THDDH_BKBNBCHSTC.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/INIT_THDDH_BKBNBCHSTC.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/INIT_THDDH_BKBNBCHSTC.shlog /sqoopbin/scripts/etlpgm/his_log/INIT_THDDH_BKBNBCHSTC_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  INIT_THDDH_BKBNBCHSTC.sh cmd command error !! ***
        exit -1      
    else             
        exit 0       
    fi               
fi               
