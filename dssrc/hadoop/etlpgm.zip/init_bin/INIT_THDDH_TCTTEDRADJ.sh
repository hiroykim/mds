#!/bin/bash

if [ $# -eq 0 ]
then           
    ARGS=N    
else           
    ARGS=$1
fi             

NOW=$(date +"+%Y-%m-%d_%T")
SHLOG_DIR=/sqoopbin/scripts/etlpgm/cur_log
HISLOG_DIR=/sqoopbin/scripts/etlpgm/his_log

export HADOOP_OPTS=-Djava.security.egd=file:/dev/../dev/urandom
export ORACLE_BASE=/sw/oracle
export ORACLE_HOME=/sw/oracle/product/11.2.0.4/client_1
export LD_LIBRARY_PATH=/sw/oracle/product/11.2.0.4/client_1/lib:/sw/oracle/product/11.2.0.4/client_1/lib:
export PATH=/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/usr/lib64/qt-3.3/bin:/usr/hdp/3.0.0.0-1634/spark2/bin/:/var/opt/node/bin/:/opt/maven/bin:/usr/local/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/home/hdpapp/workspace/data-science-at-the-command-line/tools:/home/hdpapp/.local/bin:/home/hdpapp/bin
export TNS_ADMIN=/sw/oracle/product/11.2.0.4/client_1/network/admin
export ORACLE_SID=DBEDWP2
export NLS_LANG=American_America.KO16MSWIN949

#----------------------------------------------------#
# 작업내용 : THDDH_TCTTEDRADJ 테이블 sqoop 복제 작업
# 작업주기 : D 
#----------------------------------------------------#

    echo " "
    echo "*-----------[ INIT_THDDH_TCTTEDRADJ.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ INIT_THDDH_TCTTEDRADJ.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`  >  ${SHLOG_DIR}/INIT_THDDH_TCTTEDRADJ.shlog

#----------------------------------------------------#
# 테이블별 전체 데이터를 받아 오는 부분
#----------------------------------------------------#
    /usr/bin/hadoop fs -rm -r -f  /tmp2/INIT_THDDH_TCTTEDRADJ  >> ${SHLOG_DIR}/INIT_THDDH_TCTTEDRADJ.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.INIT_THDDH_TCTTEDRADJ ; " >> ${SHLOG_DIR}/INIT_THDDH_TCTTEDRADJ.shlog 2>&1 &&
    /usr/hdp/3.0.0.0-1634/sqoop/bin/sqoop import -D mapred.child.java.opts="-Djava.security.egd=file:/dev/../dev/urandom" \
    --connect jdbc:oracle:thin:EDWHADOOP/wjdqhrP\!23@10.91.41.172:12560:DBEDWP2 \
    --username  EDWHADOOP \
    --password wjdqhrP\!23 \
    --query "SELECT REPLACE(REPLACE(ENDR_ID,CHR(13),''),CHR(10),'') ENDR_ID
, ADJT_DETL_SEQ
, REPLACE(REPLACE(ENDR_ADJT_DIV_CD,CHR(13),''),CHR(10),'') ENDR_ADJT_DIV_CD
, REPLACE(REPLACE(CTR_COV_ID,CHR(13),''),CHR(10),'') CTR_COV_ID
, ADJT_TMS
, ENDR_BF_PREM
, ENDR_AF_PREM
, ENDR_BF_NPTD_RDY_AMT
, ENDR_AF_NPTD_RDY_AMT
, ENDR_BF_CNTD_RDY_AMT
, ENDR_AF_CNTD_RDY_AMT
, ENDR_BF_AED_AMT
, ENDR_AF_AED_AMT
, PREM_DAMT
, RDY_AMT_DAMT
, DLY_IAMT
, MIN_RPY_AMT
, ALTN_PSB_AMT
, EWPY_AMT
, ICLO_PRIN
, ICLO_IAMT
, ICLO_RPY_PRIN
, ICLO_RPY_IAMT
, REPLACE(REPLACE(INPPE_ORG_ID,CHR(13),''),CHR(10),'') INPPE_ORG_ID
, SYS_OCC_DTM
, REPLACE(REPLACE(SYS_DEL_DIV_CD,CHR(13),''),CHR(10),'') SYS_DEL_DIV_CD
, REPLACE(REPLACE(OCC_IP,CHR(13),''),CHR(10),'') OCC_IP
, REPLACE(REPLACE(APP_ID,CHR(13),''),CHR(10),'') APP_ID
, DATA_CHNG_DTM
, EIH_LDG_DTM
, ENDR_BF_TMTD_RDY_AMT
, ENDR_AF_TMTD_RDY_AMT
, ENDR_BF_RCPT_PREM
, ENDR_AF_RCPT_PREM
, RCPT_PREM_DAMT FROM THDDH_TCTTEDRADJ
                       WHERE \$CONDITIONS "\
    --m 1 \
    --target-dir /tmp2/INIT_THDDH_TCTTEDRADJ \
    --hive-import \
    --external-table-dir hdfs:///tmp2/temp_tbl/INIT_THDDH_TCTTEDRADJ \
    --hive-overwrite \
    --hive-table DEFAULT.INIT_THDDH_TCTTEDRADJ  >> ${SHLOG_DIR}/INIT_THDDH_TCTTEDRADJ.shlog 2>&1 &&

#----------------------------------------------------#
# Hadoop 원본테이블에 변경분 최종 적용
#----------------------------------------------------#
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TCTTEDRADJ_ITMP ; " >> ${SHLOG_DIR}/INIT_THDDH_TCTTEDRADJ.shlog 2>&1 &&
    /usr/bin/hive -e "CREATE EXTERNAL TABLE MERITZ.THDDH_TCTTEDRADJ_ITMP STORED AS PARQUET TBLPROPERTIES ('PARQUET.COMPRESS'='SNAPPY') AS
                                SELECT *
                                FROM DEFAULT.INIT_THDDH_TCTTEDRADJ ;" >> ${SHLOG_DIR}/INIT_THDDH_TCTTEDRADJ.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.INIT_THDDH_TCTTEDRADJ ;" >> ${SHLOG_DIR}/INIT_THDDH_TCTTEDRADJ.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TCTTEDRADJ ;" >> ${SHLOG_DIR}/INIT_THDDH_TCTTEDRADJ.shlog 2>&1 &&
    /usr/bin/hive -e "ALTER TABLE MERITZ.THDDH_TCTTEDRADJ_ITMP RENAME TO MERITZ.THDDH_TCTTEDRADJ ;" >> ${SHLOG_DIR}/INIT_THDDH_TCTTEDRADJ.shlog 2>&1 &&
# external table 이 alter문 동작 다른 문제로 아래 과정이 필요해짐 
    /usr/bin/hive -e "ALTER TABLE MERITZ.THDDH_TCTTEDRADJ SET LOCATION 'hdfs:///warehouse/tablespace/external/hive/meritz.db/thddh_tcttedradj_tmp' ;" >> ${SHLOG_DIR}/THDDH_TCTTEDRADJ.shlog 2>&1 &&
    /usr/bin/hdfs dfs -mv /warehouse/tablespace/external/hive/meritz.db/thddh_tcttedradj_itmp /warehouse/tablespace/external/hive/meritz.db/thddh_tcttedradj_tmp >> ${SHLOG_DIR}/THDDH_TCTTEDRADJ.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TCTTEDRADJ_ITMP ;" >> ${SHLOG_DIR}/INIT_THDDH_TCTTEDRADJ.shlog 2>&1 

if [ $? -ne 0 ]
then             
    echo "*-----------[ INIT_THDDH_TCTTEDRADJ.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/INIT_THDDH_TCTTEDRADJ.shlog"
    echo "*-----------[ INIT_THDDH_TCTTEDRADJ.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/INIT_THDDH_TCTTEDRADJ.shlog"  >>  ${SHLOG_DIR}/INIT_THDDH_TCTTEDRADJ.shlog
    echo "*-----------[ INIT_THDDH_TCTTEDRADJ.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ INIT_THDDH_TCTTEDRADJ.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/INIT_THDDH_TCTTEDRADJ.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/INIT_THDDH_TCTTEDRADJ.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/INIT_THDDH_TCTTEDRADJ.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/INIT_THDDH_TCTTEDRADJ.shlog /sqoopbin/scripts/etlpgm/his_log/INIT_THDDH_TCTTEDRADJ_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  INIT_THDDH_TCTTEDRADJ.sh cmd command error !! ***
    fi               

    exit -1      

else             
    echo "*-----------[ INIT_THDDH_TCTTEDRADJ.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ INIT_THDDH_TCTTEDRADJ.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/INIT_THDDH_TCTTEDRADJ.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/INIT_THDDH_TCTTEDRADJ.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/INIT_THDDH_TCTTEDRADJ.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/INIT_THDDH_TCTTEDRADJ.shlog /sqoopbin/scripts/etlpgm/his_log/INIT_THDDH_TCTTEDRADJ_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  INIT_THDDH_TCTTEDRADJ.sh cmd command error !! ***
        exit -1      
    else             
        exit 0       
    fi               
fi               
