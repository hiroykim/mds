#!/bin/bash

if [ $# -eq 0 ]
then           
    ARGS=N    
else           
    ARGS=$1
fi             

NOW=$(date +"+%Y-%m-%d_%T")
SHLOG_DIR=/sqoopbin/scripts/etlpgm/cur_log
HISLOG_DIR=/sqoopbin/scripts/etlpgm/his_log

export HADOOP_OPTS=-Djava.security.egd=file:/dev/../dev/urandom
export ORACLE_BASE=/sw/oracle
export ORACLE_HOME=/sw/oracle/product/11.2.0.4/client_1
export LD_LIBRARY_PATH=/sw/oracle/product/11.2.0.4/client_1/lib:/sw/oracle/product/11.2.0.4/client_1/lib:
export PATH=/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/usr/lib64/qt-3.3/bin:/var/opt/node/bin/:/usr/hdp/2.6.1.0-129/spark2/bin/:/opt/maven/bin:/usr/local/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/home/hdpapp/.local/bin:/home/hdpapp/bin
export TNS_ADMIN=/sw/oracle/product/11.2.0.4/client_1/network/admin
export ORACLE_SID=DBEDWP2
export NLS_LANG=American_America.KO16MSWIN949

#----------------------------------------------------#
# 작업내용 : THDDH_TCLHOSP 테이블 sqoop 복제 작업
# 작업주기 : D 
#----------------------------------------------------#

    echo " "
    echo "*-----------[ INIT_THDDH_TCLHOSP.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ INIT_THDDH_TCLHOSP.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`  >  ${SHLOG_DIR}/INIT_THDDH_TCLHOSP.shlog

#----------------------------------------------------#
# 테이블별 전체 데이터를 받아 오는 부분
#----------------------------------------------------#
    /usr/bin/hadoop fs -rm -r -f  /tmp2/INIT_THDDH_TCLHOSP  >> ${SHLOG_DIR}/INIT_THDDH_TCLHOSP.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.INIT_THDDH_TCLHOSP ; " >> ${SHLOG_DIR}/INIT_THDDH_TCLHOSP.shlog 2>&1 &&
    /usr/hdp/2.6.1.0-129/sqoop/bin/sqoop import -D mapred.child.java.opts="-Djava.security.egd=file:/dev/../dev/urandom" \
    --connect jdbc:oracle:thin:EDWHADOOP/wjdqhrP\!23@10.91.41.139:12560:DBEDWP2 \
    --username  EDWHADOOP \
    --password wjdqhrP\!23 \
    --query "SELECT REPLACE(REPLACE(HSP_GHR_HOSP_ID,CHR(13),''),CHR(10),'') HSP_GHR_HOSP_ID
, HIS_SEQ
, REPLACE(REPLACE(COMS_BIZ_DIV_CD,CHR(13),''),CHR(10),'') COMS_BIZ_DIV_CD
, REPLACE(REPLACE(DMPE_ID,CHR(13),''),CHR(10),'') DMPE_ID
, REPLACE(REPLACE(DMG_SVY_OCDIV_CD,CHR(13),''),CHR(10),'') DMG_SVY_OCDIV_CD
, REPLACE(REPLACE(DMG_SVY_DATA_DIV_CD,CHR(13),''),CHR(10),'') DMG_SVY_DATA_DIV_CD
, REPLACE(REPLACE(DATA_ID,CHR(13),''),CHR(10),'') DATA_ID
, REPLACE(REPLACE(HSP_GHR_DIV_CD,CHR(13),''),CHR(10),'') HSP_GHR_DIV_CD
, REPLACE(REPLACE(MET_TP_CD,CHR(13),''),CHR(10),'') MET_TP_CD
, MET_ST_DT
, MET_ED_DT
, REPLACE(REPLACE(HOSP_BZAC_ID,CHR(13),''),CHR(10),'') HOSP_BZAC_ID
, REPLACE(REPLACE(CLM_ID,CHR(13),''),CHR(10),'') CLM_ID
, MET_DD_NUM
, HSP_NCNT
, REPLACE(REPLACE(HOSP_NM,CHR(13),''),CHR(10),'') HOSP_NM
, REPLACE(REPLACE(SKRM_GRDE_CD,CHR(13),''),CHR(10),'') SKRM_GRDE_CD
, SKRM_DAMT_AMT
, SKRM_STD_AMT
, REPLACE(REPLACE(DGN_SH_CD,CHR(13),''),CHR(10),'') DGN_SH_CD
, OFFDC_SND_DT
, REPLACE(REPLACE(PSBLL_ID,CHR(13),''),CHR(10),'') PSBLL_ID
, REPLACE(REPLACE(MEAL_OFR_YN,CHR(13),''),CHR(10),'') MEAL_OFR_YN
, REPLACE(REPLACE(RMK_CON,CHR(13),''),CHR(10),'') RMK_CON
, REPLACE(REPLACE(ORN_HSP_GHR_HOSP_ID,CHR(13),''),CHR(10),'') ORN_HSP_GHR_HOSP_ID
, REPLACE(REPLACE(DUP_DOC_CNF_CD,CHR(13),''),CHR(10),'') DUP_DOC_CNF_CD
, INF_OBM_FIX_SEQ
, REPLACE(REPLACE(INF_OBM_DCM_NO,CHR(13),''),CHR(10),'') INF_OBM_DCM_NO
, REPLACE(REPLACE(COMS_CHRPE_DIV_CD,CHR(13),''),CHR(10),'') COMS_CHRPE_DIV_CD
, HIS_ST_DTM
, HIS_ED_DTM
, REPLACE(REPLACE(INPPE_ORG_ID,CHR(13),''),CHR(10),'') INPPE_ORG_ID
, SYS_OCC_DTM
, REPLACE(REPLACE(SYS_DEL_DIV_CD,CHR(13),''),CHR(10),'') SYS_DEL_DIV_CD
, REPLACE(REPLACE(OCC_IP,CHR(13),''),CHR(10),'') OCC_IP
, REPLACE(REPLACE(APP_ID,CHR(13),''),CHR(10),'') APP_ID
, DATA_CHNG_DTM
, EIH_LDG_DTM
, REPLACE(REPLACE(MDF_CHRPE_ORG_ID,CHR(13),''),CHR(10),'') MDF_CHRPE_ORG_ID
, REPLACE(REPLACE(CHRPE_MDF_RSN_CD,CHR(13),''),CHR(10),'') CHRPE_MDF_RSN_CD
, CHRPE_MDF_DTM
, ACKN_MET_DD_NUM
, REPLACE(REPLACE(HOSP_RCP_DIV_CD,CHR(13),''),CHR(10),'') HOSP_RCP_DIV_CD FROM THDDH_TCLHOSP
                       WHERE \$CONDITIONS "\
    --m 1 \
    --target-dir /tmp2/INIT_THDDH_TCLHOSP \
    --hive-import \
    --hive-overwrite \
    --hive-table DEFAULT.INIT_THDDH_TCLHOSP  >> ${SHLOG_DIR}/INIT_THDDH_TCLHOSP.shlog 2>&1 &&

#----------------------------------------------------#
# Hadoop 원본테이블에 변경분 최종 적용
#----------------------------------------------------#
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TCLHOSP_ITMP ; " >> ${SHLOG_DIR}/INIT_THDDH_TCLHOSP.shlog 2>&1 &&
    /usr/bin/hive -e "CREATE TABLE MERITZ.THDDH_TCLHOSP_ITMP STORED AS PARQUET TBLPROPERTIES ('PARQUET.COMPRESS'='SNAPPY') AS
                                SELECT *
                                FROM DEFAULT.INIT_THDDH_TCLHOSP ;" >> ${SHLOG_DIR}/INIT_THDDH_TCLHOSP.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.INIT_THDDH_TCLHOSP ;" >> ${SHLOG_DIR}/INIT_THDDH_TCLHOSP.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TCLHOSP ;" >> ${SHLOG_DIR}/INIT_THDDH_TCLHOSP.shlog 2>&1 &&
    /usr/bin/hive -e "ALTER TABLE MERITZ.THDDH_TCLHOSP_ITMP RENAME TO MERITZ.THDDH_TCLHOSP ;" >> ${SHLOG_DIR}/INIT_THDDH_TCLHOSP.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TCLHOSP_ITMP ;" >> ${SHLOG_DIR}/INIT_THDDH_TCLHOSP.shlog 2>&1 

if [ $? -ne 0 ]
then             
    echo "*-----------[ INIT_THDDH_TCLHOSP.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/INIT_THDDH_TCLHOSP.shlog"
    echo "*-----------[ INIT_THDDH_TCLHOSP.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/INIT_THDDH_TCLHOSP.shlog"  >>  ${SHLOG_DIR}/INIT_THDDH_TCLHOSP.shlog
    echo "*-----------[ INIT_THDDH_TCLHOSP.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ INIT_THDDH_TCLHOSP.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/INIT_THDDH_TCLHOSP.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/INIT_THDDH_TCLHOSP.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/INIT_THDDH_TCLHOSP.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/INIT_THDDH_TCLHOSP.shlog /sqoopbin/scripts/etlpgm/his_log/INIT_THDDH_TCLHOSP_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  INIT_THDDH_TCLHOSP.sh cmd command error !! ***
    fi               

    exit -1      

else             
    echo "*-----------[ INIT_THDDH_TCLHOSP.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ INIT_THDDH_TCLHOSP.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/INIT_THDDH_TCLHOSP.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/INIT_THDDH_TCLHOSP.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/INIT_THDDH_TCLHOSP.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/INIT_THDDH_TCLHOSP.shlog /sqoopbin/scripts/etlpgm/his_log/INIT_THDDH_TCLHOSP_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  INIT_THDDH_TCLHOSP.sh cmd command error !! ***
        exit -1      
    else             
        exit 0       
    fi               
fi               
