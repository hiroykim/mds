#!/bin/bash

if [ $# -eq 0 ]
then           
    ARGS=N    
else           
    ARGS=$1
fi             

NOW=$(date +"+%Y-%m-%d_%T")
SHLOG_DIR=/sqoopbin/scripts/etlpgm/cur_log
HISLOG_DIR=/sqoopbin/scripts/etlpgm/his_log

export HADOOP_OPTS=-Djava.security.egd=file:/dev/../dev/urandom
export ORACLE_BASE=/sw/oracle
export ORACLE_HOME=/sw/oracle/product/11.2.0.4/client_1
export LD_LIBRARY_PATH=/sw/oracle/product/11.2.0.4/client_1/lib:/sw/oracle/product/11.2.0.4/client_1/lib:
export PATH=/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/usr/lib64/qt-3.3/bin:/var/opt/node/bin/:/usr/hdp/3.0.0.0-1634/spark2/bin/:/opt/maven/bin:/usr/local/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/home/hdpapp/.local/bin:/home/hdpapp/bin
export TNS_ADMIN=/sw/oracle/product/11.2.0.4/client_1/network/admin
export ORACLE_SID=DBEDWP2
export NLS_LANG=American_America.KO16MSWIN949

#----------------------------------------------------#
# 작업내용 : TMLMB_MLONCTRCLG 테이블 sqoop 복제 작업
# 작업주기 : D 
#----------------------------------------------------#

    echo " "
    echo "*-----------[ INIT_TMLMB_MLONCTRCLG.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ INIT_TMLMB_MLONCTRCLG.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`  >  ${SHLOG_DIR}/INIT_TMLMB_MLONCTRCLG.shlog

#----------------------------------------------------#
# 테이블별 전체 데이터를 받아 오는 부분
#----------------------------------------------------#
    /usr/bin/hadoop fs -rm -r -f  /tmp2/INIT_TMLMB_MLONCTRCLG  >> ${SHLOG_DIR}/INIT_TMLMB_MLONCTRCLG.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.INIT_TMLMB_MLONCTRCLG ; " >> ${SHLOG_DIR}/INIT_TMLMB_MLONCTRCLG.shlog 2>&1 &&
    /usr/hdp/3.0.0.0-1634/sqoop/bin/sqoop import -D mapred.child.java.opts="-Djava.security.egd=file:/dev/../dev/urandom" \
    --connect jdbc:oracle:thin:EDWHADOOP/wjdqhrP\!23@10.91.41.172:12560:DBEDWP2 \
    --username  EDWHADOOP \
    --password wjdqhrP\!23 \
    --query "SELECT REPLACE(REPLACE(STD_YYMM,CHR(13),''),CHR(10),'') STD_YYMM
, REPLACE(REPLACE(CTR_ID,CHR(13),''),CHR(10),'') CTR_ID
, REPLACE(REPLACE(ENDR_ID,CHR(13),''),CHR(10),'') ENDR_ID
, LAST_ENDR_DT
, LAST_ENDR_STD_DT
, LAST_ENDR_SUMUP_DT
, LAST_ENDR_HIS_STD_DT
, LAST_ENDR_HIS_STD_NO
, STAT_CHNG_DT
, REPLACE(REPLACE(POL_NO,CHR(13),''),CHR(10),'') POL_NO
, SBCP_DT
, REPLACE(REPLACE(CTR_STAT_CD,CHR(13),''),CHR(10),'') CTR_STAT_CD
, REPLACE(REPLACE(CTR_STAT_DTL_CD,CHR(13),''),CHR(10),'') CTR_STAT_DTL_CD
, REPLACE(REPLACE(SAL_PD_CD,CHR(13),''),CHR(10),'') SAL_PD_CD
, REPLACE(REPLACE(UNT_PD_CD,CHR(13),''),CHR(10),'') UNT_PD_CD
, INS_BGN_DT
, INS_ED_DT
, REPLACE(REPLACE(RPS_PD_CD,CHR(13),''),CHR(10),'') RPS_PD_CD
, REPLACE(REPLACE(OD_STIC_PD_CTG_CD,CHR(13),''),CHR(10),'') OD_STIC_PD_CTG_CD
, REPLACE(REPLACE(NW_STIC_PD_CTG_CD,CHR(13),''),CHR(10),'') NW_STIC_PD_CTG_CD
, REPLACE(REPLACE(GURT_SAV_DIV_CD,CHR(13),''),CHR(10),'') GURT_SAV_DIV_CD
, REPLACE(REPLACE(PY_CYC_CD,CHR(13),''),CHR(10),'') PY_CYC_CD
, REPLACE(REPLACE(INS_PRD_TP_CD,CHR(13),''),CHR(10),'') INS_PRD_TP_CD
, REPLACE(REPLACE(PY_PRD_TP_CD,CHR(13),''),CHR(10),'') PY_PRD_TP_CD
, INS_PRD
, PY_PRD
, INS_ED_AGE
, PY_ED_AGE
, REPLACE(REPLACE(MNCL_MD_CD,CHR(13),''),CHR(10),'') MNCL_MD_CD
, REPLACE(REPLACE(CLF_DIV_CD,CHR(13),''),CHR(10),'') CLF_DIV_CD
, REPLACE(REPLACE(INS_SBC_SH_CD,CHR(13),''),CHR(10),'') INS_SBC_SH_CD
, REPLACE(REPLACE(INS_SBC_TP_CD,CHR(13),''),CHR(10),'') INS_SBC_TP_CD
, REPLACE(REPLACE(SBCP_CHN_DIV_CD,CHR(13),''),CHR(10),'') SBCP_CHN_DIV_CD
, REPLACE(REPLACE(POLHD_CUS_ID,CHR(13),''),CHR(10),'') POLHD_CUS_ID
, REPLACE(REPLACE(POLHD_CUS_NO,CHR(13),''),CHR(10),'') POLHD_CUS_NO
, REPLACE(REPLACE(LAST_PY_YYMM,CHR(13),''),CHR(10),'') LAST_PY_YYMM
, LAST_PY_TMS
, REPLACE(REPLACE(TRTPE_ORG_ID,CHR(13),''),CHR(10),'') TRTPE_ORG_ID
, REPLACE(REPLACE(TRTPE_ORG_CD,CHR(13),''),CHR(10),'') TRTPE_ORG_CD
, REPLACE(REPLACE(TRT_AGPLR_ORG_ID,CHR(13),''),CHR(10),'') TRT_AGPLR_ORG_ID
, REPLACE(REPLACE(TRT_AGPLR_ORG_CD,CHR(13),''),CHR(10),'') TRT_AGPLR_ORG_CD
, REPLACE(REPLACE(CHN_DIV_CD,CHR(13),''),CHR(10),'') CHN_DIV_CD
, REPLACE(REPLACE(SALPE_ORG_DIV_CD,CHR(13),''),CHR(10),'') SALPE_ORG_DIV_CD
, REPLACE(REPLACE(CLLPE_ORG_ID,CHR(13),''),CHR(10),'') CLLPE_ORG_ID
, REPLACE(REPLACE(CLLPE_ORG_CD,CHR(13),''),CHR(10),'') CLLPE_ORG_CD
, REPLACE(REPLACE(RCRT_AGPLR_ORG_ID,CHR(13),''),CHR(10),'') RCRT_AGPLR_ORG_ID
, REPLACE(REPLACE(RCRT_AGPLR_ORG_CD,CHR(13),''),CHR(10),'') RCRT_AGPLR_ORG_CD
, CLLPE_FRD_DT
, REPLACE(REPLACE(SCPOS_CONV_CD,CHR(13),''),CHR(10),'') SCPOS_CONV_CD
, REPLACE(REPLACE(NW_CTR_YN,CHR(13),''),CHR(10),'') NW_CTR_YN
, REPLACE(REPLACE(OWN_CTR_YN,CHR(13),''),CHR(10),'') OWN_CTR_YN
, REPLACE(REPLACE(TRTPE_TRFR_YN,CHR(13),''),CHR(10),'') TRTPE_TRFR_YN
, BAS_PREM
, GURT_PREM
, ACU_PREM
, APL_PREM
, SLZ_PREM
, RCPT_PREM
, ORIG_RSK_PREM
, MMPY_CNVS_SLZ_PREM
, MMPY_CNVS_RCPT_PREM
, EIH_LDG_DTM
, REPLACE(REPLACE(CLLPE_SELF_CUS_ID,CHR(13),''),CHR(10),'') CLLPE_SELF_CUS_ID
, REPLACE(REPLACE(RCRT_AGPLR_SELF_CUS_ID,CHR(13),''),CHR(10),'') RCRT_AGPLR_SELF_CUS_ID
, REPLACE(REPLACE(CLF_DIV_NM,CHR(13),''),CHR(10),'') CLF_DIV_NM
, REPLACE(REPLACE(INS_SBC_SH_NM,CHR(13),''),CHR(10),'') INS_SBC_SH_NM FROM TMLMB_MLONCTRCLG
                       WHERE \$CONDITIONS 
                         AND STD_YYMM BETWEEN '201810' AND '201908' "\
    --m 1 \
    --target-dir /tmp2/INIT_TMLMB_MLONCTRCLG \
    --hive-import \
    --external-table-dir hdfs:///tmp2/temp_tbl/INIT_TMLMB_MLONCTRCLG \
    --hive-overwrite \
    --hive-table DEFAULT.INIT_TMLMB_MLONCTRCLG  >> ${SHLOG_DIR}/INIT_TMLMB_MLONCTRCLG.shlog 2>&1 &&

#----------------------------------------------------#
# Hadoop 원본테이블에 변경분 최종 적용
#----------------------------------------------------#
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.TMLMB_MLONCTRCLG_ITMP ; " >> ${SHLOG_DIR}/INIT_TMLMB_MLONCTRCLG.shlog 2>&1 &&
    /usr/bin/hive -e "CREATE EXTERNAL TABLE MERITZ.TMLMB_MLONCTRCLG_ITMP STORED AS PARQUET TBLPROPERTIES ('PARQUET.COMPRESS'='SNAPPY') AS
                                SELECT *
                                FROM DEFAULT.INIT_TMLMB_MLONCTRCLG
                                UNION ALL
                                SELECT * 
                                FROM MERITZ.TMLMB_MLONCTRCLG ;" >> ${SHLOG_DIR}/INIT_TMLMB_MLONCTRCLG.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.INIT_TMLMB_MLONCTRCLG ;" >> ${SHLOG_DIR}/INIT_TMLMB_MLONCTRCLG.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.TMLMB_MLONCTRCLG ;" >> ${SHLOG_DIR}/INIT_TMLMB_MLONCTRCLG.shlog 2>&1 &&
    /usr/bin/hive -e "ALTER TABLE MERITZ.TMLMB_MLONCTRCLG_ITMP RENAME TO MERITZ.TMLMB_MLONCTRCLG ;" >> ${SHLOG_DIR}/INIT_TMLMB_MLONCTRCLG.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.TMLMB_MLONCTRCLG_ITMP ;" >> ${SHLOG_DIR}/INIT_TMLMB_MLONCTRCLG.shlog 2>&1 

if [ $? -ne 0 ]
then             
    echo "*-----------[ INIT_TMLMB_MLONCTRCLG.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/INIT_TMLMB_MLONCTRCLG.shlog"
    echo "*-----------[ INIT_TMLMB_MLONCTRCLG.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/INIT_TMLMB_MLONCTRCLG.shlog"  >>  ${SHLOG_DIR}/INIT_TMLMB_MLONCTRCLG.shlog
    echo "*-----------[ INIT_TMLMB_MLONCTRCLG.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ INIT_TMLMB_MLONCTRCLG.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/INIT_TMLMB_MLONCTRCLG.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/INIT_TMLMB_MLONCTRCLG.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/INIT_TMLMB_MLONCTRCLG.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/INIT_TMLMB_MLONCTRCLG.shlog /sqoopbin/scripts/etlpgm/his_log/INIT_TMLMB_MLONCTRCLG_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  INIT_TMLMB_MLONCTRCLG.sh cmd command error !! ***
    fi               

    exit -1      

else             
    echo "*-----------[ INIT_TMLMB_MLONCTRCLG.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ INIT_TMLMB_MLONCTRCLG.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/INIT_TMLMB_MLONCTRCLG.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/INIT_TMLMB_MLONCTRCLG.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/INIT_TMLMB_MLONCTRCLG.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/INIT_TMLMB_MLONCTRCLG.shlog /sqoopbin/scripts/etlpgm/his_log/INIT_TMLMB_MLONCTRCLG_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  INIT_TMLMB_MLONCTRCLG.sh cmd command error !! ***
        exit -1      
    else             
        exit 0       
    fi               
fi               
