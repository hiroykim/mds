#!/bin/bash

if [ $# -eq 0 ]
then           
    ARGS=N    
else           
    ARGS=$1
fi             

NOW=$(date +"+%Y-%m-%d_%T")
SHLOG_DIR=/sqoopbin/scripts/etlpgm/cur_log
HISLOG_DIR=/sqoopbin/scripts/etlpgm/his_log

export HADOOP_OPTS=-Djava.security.egd=file:/dev/../dev/urandom
export ORACLE_BASE=/sw/oracle
export ORACLE_HOME=/sw/oracle/product/11.2.0.4/client_1
export LD_LIBRARY_PATH=/sw/oracle/product/11.2.0.4/client_1/lib:/sw/oracle/product/11.2.0.4/client_1/lib:
export PATH=/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/usr/lib64/qt-3.3/bin:/var/opt/node/bin/:/usr/hdp/3.0.0.0-1634/spark2/bin/:/opt/maven/bin:/usr/local/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/home/hdpapp/.local/bin:/home/hdpapp/bin
export TNS_ADMIN=/sw/oracle/product/11.2.0.4/client_1/network/admin
export ORACLE_SID=DBEDWP2
export NLS_LANG=American_America.KO16MSWIN949

#----------------------------------------------------#
# 작업내용 : THDDH_TCTLCOTL1 테이블 sqoop 복제 작업
# 작업주기 : D 
#----------------------------------------------------#

    echo " "
    echo "*-----------[ INIT_THDDH_TCTLCOTL1.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ INIT_THDDH_TCTLCOTL1.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`  >  ${SHLOG_DIR}/INIT_THDDH_TCTLCOTL1.shlog

#----------------------------------------------------#
# 테이블별 전체 데이터를 받아 오는 부분
#----------------------------------------------------#
    /usr/bin/hadoop fs -rm -r -f  /tmp2/INIT_THDDH_TCTLCOTL1  >> ${SHLOG_DIR}/INIT_THDDH_TCTLCOTL1.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.INIT_THDDH_TCTLCOTL1 ; " >> ${SHLOG_DIR}/INIT_THDDH_TCTLCOTL1.shlog 2>&1 &&
    /usr/hdp/3.0.0.0-1634/sqoop/bin/sqoop import -D mapred.child.java.opts="-Djava.security.egd=file:/dev/../dev/urandom" \
    --connect jdbc:oracle:thin:EDWHADOOP/wjdqhrP\!23@10.91.41.172:12560:DBEDWP2 \
    --username  EDWHADOOP \
    --password wjdqhrP\!23 \
    --query "SELECT REPLACE(REPLACE(CTR_ID,CHR(13),''),CHR(10),'') CTR_ID
, REPLACE(REPLACE(CLOG_ST_YYMM,CHR(13),''),CHR(10),'') CLOG_ST_YYMM
, REPLACE(REPLACE(CLOG_ED_YYMM,CHR(13),''),CHR(10),'') CLOG_ED_YYMM
, WRK_STD_ST_DT
, WRK_STD_ED_DT
, REPLACE(REPLACE(POL_NO,CHR(13),''),CHR(10),'') POL_NO
, REPLACE(REPLACE(PD_CD,CHR(13),''),CHR(10),'') PD_CD
, REPLACE(REPLACE(PD_NM,CHR(13),''),CHR(10),'') PD_NM
, SBCP_DT
, INS_BGN_DT
, INS_ED_DT
, REPLACE(REPLACE(CTR_STAT_CD,CHR(13),''),CHR(10),'') CTR_STAT_CD
, REPLACE(REPLACE(CTR_STAT_DTL_CD,CHR(13),''),CHR(10),'') CTR_STAT_DTL_CD
, REPLACE(REPLACE(CTR_STAT_CD2,CHR(13),''),CHR(10),'') CTR_STAT_CD2
, REPLACE(REPLACE(CTR_STAT_DTL_CD2,CHR(13),''),CHR(10),'') CTR_STAT_DTL_CD2
, SLZ_PREM
, REPLACE(REPLACE(POLHD_CUS_ID,CHR(13),''),CHR(10),'') POLHD_CUS_ID
, REPLACE(REPLACE(POLHD_NM,CHR(13),''),CHR(10),'') POLHD_NM
, REPLACE(REPLACE(TRTPE_ORG_ID,CHR(13),''),CHR(10),'') TRTPE_ORG_ID
, REPLACE(REPLACE(AGPLR_ORG_ID,CHR(13),''),CHR(10),'') AGPLR_ORG_ID
, SUMUP_DT
, REPLACE(REPLACE(LAST_PY_YYMM,CHR(13),''),CHR(10),'') LAST_PY_YYMM
, LAST_PY_TMS
, REPLACE(REPLACE(PY_CYC_CD,CHR(13),''),CHR(10),'') PY_CYC_CD
, LPS_DT
, REVV_DT
, EXTNC_DT
, EXTNC_CNC_DT
, REPLACE(REPLACE(DIVD_PD_YN,CHR(13),''),CHR(10),'') DIVD_PD_YN
, INP_DT
, ENDR_HIS_STD_NO
, REPLACE(REPLACE(INPPE_ORG_ID,CHR(13),''),CHR(10),'') INPPE_ORG_ID
, SYS_OCC_DTM
, REPLACE(REPLACE(SYS_DEL_DIV_CD,CHR(13),''),CHR(10),'') SYS_DEL_DIV_CD
, REPLACE(REPLACE(OCC_IP,CHR(13),''),CHR(10),'') OCC_IP
, REPLACE(REPLACE(APP_ID,CHR(13),''),CHR(10),'') APP_ID
, DATA_CHNG_DTM
, EIH_LDG_DTM
, REPLACE(REPLACE(ACQ_EXP_AMTZ_YN,CHR(13),''),CHR(10),'') ACQ_EXP_AMTZ_YN
, REPLACE(REPLACE(ICDC_NOCC_YN,CHR(13),''),CHR(10),'') ICDC_NOCC_YN
, PPAT_APL_PREM
, PPAT_SLZ_PREM
, REPLACE(REPLACE(CLLPE_ORG_ID,CHR(13),''),CHR(10),'') CLLPE_ORG_ID
, REPLACE(REPLACE(RCRT_AGPLR_ORG_ID,CHR(13),''),CHR(10),'') RCRT_AGPLR_ORG_ID
, REPLACE(REPLACE(PPAT_LAST_PY_YYMM,CHR(13),''),CHR(10),'') PPAT_LAST_PY_YYMM
, PPAT_LAST_PY_TMS
, PPAT_PY_ST_DT
, PPAT_PY_ED_DT FROM THDDH_TCTLCOTL1
                       WHERE \$CONDITIONS "\
    --m 1 \
    --target-dir /tmp2/INIT_THDDH_TCTLCOTL1 \
    --hive-import \
    --external-table-dir hdfs:///tmp2/temp_tbl/INIT_THDDH_TCTLCOTL1 \
    --hive-overwrite \
    --hive-table DEFAULT.INIT_THDDH_TCTLCOTL1  >> ${SHLOG_DIR}/INIT_THDDH_TCTLCOTL1.shlog 2>&1 &&

#----------------------------------------------------#
# Hadoop 원본테이블에 변경분 최종 적용
#----------------------------------------------------#
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TCTLCOTL1_ITMP ; " >> ${SHLOG_DIR}/INIT_THDDH_TCTLCOTL1.shlog 2>&1 &&
    /usr/bin/hive -e "CREATE EXTERNAL TABLE MERITZ.THDDH_TCTLCOTL1_ITMP STORED AS PARQUET TBLPROPERTIES ('PARQUET.COMPRESS'='SNAPPY') AS
                                SELECT *
                                FROM DEFAULT.INIT_THDDH_TCTLCOTL1 ;" >> ${SHLOG_DIR}/INIT_THDDH_TCTLCOTL1.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.INIT_THDDH_TCTLCOTL1 ;" >> ${SHLOG_DIR}/INIT_THDDH_TCTLCOTL1.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TCTLCOTL1 ;" >> ${SHLOG_DIR}/INIT_THDDH_TCTLCOTL1.shlog 2>&1 &&
    /usr/bin/hive -e "ALTER TABLE MERITZ.THDDH_TCTLCOTL1_ITMP RENAME TO MERITZ.THDDH_TCTLCOTL1 ;" >> ${SHLOG_DIR}/INIT_THDDH_TCTLCOTL1.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TCTLCOTL1_ITMP ;" >> ${SHLOG_DIR}/INIT_THDDH_TCTLCOTL1.shlog 2>&1 

if [ $? -ne 0 ]
then             
    echo "*-----------[ INIT_THDDH_TCTLCOTL1.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/INIT_THDDH_TCTLCOTL1.shlog"
    echo "*-----------[ INIT_THDDH_TCTLCOTL1.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/INIT_THDDH_TCTLCOTL1.shlog"  >>  ${SHLOG_DIR}/INIT_THDDH_TCTLCOTL1.shlog
    echo "*-----------[ INIT_THDDH_TCTLCOTL1.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ INIT_THDDH_TCTLCOTL1.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/INIT_THDDH_TCTLCOTL1.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/INIT_THDDH_TCTLCOTL1.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/INIT_THDDH_TCTLCOTL1.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/INIT_THDDH_TCTLCOTL1.shlog /sqoopbin/scripts/etlpgm/his_log/INIT_THDDH_TCTLCOTL1_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  INIT_THDDH_TCTLCOTL1.sh cmd command error !! ***
    fi               

    exit -1      

else             
    echo "*-----------[ INIT_THDDH_TCTLCOTL1.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ INIT_THDDH_TCTLCOTL1.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/INIT_THDDH_TCTLCOTL1.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/INIT_THDDH_TCTLCOTL1.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/INIT_THDDH_TCTLCOTL1.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/INIT_THDDH_TCTLCOTL1.shlog /sqoopbin/scripts/etlpgm/his_log/INIT_THDDH_TCTLCOTL1_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  INIT_THDDH_TCTLCOTL1.sh cmd command error !! ***
        exit -1      
    else             
        exit 0       
    fi               
fi               
