#!/bin/bash

if [ $# -eq 0 ]
then           
    ARGS=N    
else           
    ARGS=$1
fi             

NOW=$(date +"+%Y-%m-%d_%T")
SHLOG_DIR=/sqoopbin/scripts/etlpgm/cur_log
HISLOG_DIR=/sqoopbin/scripts/etlpgm/his_log

export HADOOP_OPTS=-Djava.security.egd=file:/dev/../dev/urandom
export ORACLE_BASE=/sw/oracle
export ORACLE_HOME=/sw/oracle/product/11.2.0.4/client_1
export LD_LIBRARY_PATH=/sw/oracle/product/11.2.0.4/client_1/lib:/sw/oracle/product/11.2.0.4/client_1/lib:
export PATH=/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/usr/lib64/qt-3.3/bin:/usr/hdp/3.0.0.0-1634/spark2/bin/:/var/opt/node/bin/:/opt/maven/bin:/usr/local/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/home/hdpapp/workspace/data-science-at-the-command-line/tools:/home/hdpapp/.local/bin:/home/hdpapp/bin
export TNS_ADMIN=/sw/oracle/product/11.2.0.4/client_1/network/admin
export ORACLE_SID=DBEDWP2
export NLS_LANG=American_America.KO16MSWIN949

#----------------------------------------------------#
# 작업내용 : THDDH_TCTDRUPCLG 테이블 sqoop 복제 작업
# 작업주기 : D 
#----------------------------------------------------#

    echo " "
    echo "*-----------[ INIT_THDDH_TCTDRUPCLG.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ INIT_THDDH_TCTDRUPCLG.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`  >  ${SHLOG_DIR}/INIT_THDDH_TCTDRUPCLG.shlog

#----------------------------------------------------#
# 테이블별 전체 데이터를 받아 오는 부분
#----------------------------------------------------#
    /usr/bin/hadoop fs -rm -r -f  /tmp2/INIT_THDDH_TCTDRUPCLG  >> ${SHLOG_DIR}/INIT_THDDH_TCTDRUPCLG.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.INIT_THDDH_TCTDRUPCLG ; " >> ${SHLOG_DIR}/INIT_THDDH_TCTDRUPCLG.shlog 2>&1 &&
    /usr/hdp/3.0.0.0-1634/sqoop/bin/sqoop import -D mapred.child.java.opts="-Djava.security.egd=file:/dev/../dev/urandom" \
    --connect jdbc:oracle:thin:EDWHADOOP/wjdqhrP\!23@10.91.41.172:12560:DBEDWP2 \
    --username  EDWHADOOP \
    --password wjdqhrP\!23 \
    --query "SELECT REPLACE(REPLACE(UNPY_DRI_AMT_CLOG_ID,CHR(13),''),CHR(10),'') UNPY_DRI_AMT_CLOG_ID
, REPLACE(REPLACE(CLOG_DIV_CD,CHR(13),''),CHR(10),'') CLOG_DIV_CD
, CLOG_DT
, REPLACE(REPLACE(DRI_AMT_CLOG_DIV_CD,CHR(13),''),CHR(10),'') DRI_AMT_CLOG_DIV_CD
, REPLACE(REPLACE(UNPY_AMT_DIV_CD,CHR(13),''),CHR(10),'') UNPY_AMT_DIV_CD
, REPLACE(REPLACE(UNPY_AMT_LCTG_CD,CHR(13),''),CHR(10),'') UNPY_AMT_LCTG_CD
, REPLACE(REPLACE(UNPY_AMT_DCTG_CD_VAL,CHR(13),''),CHR(10),'') UNPY_AMT_DCTG_CD_VAL
, REPLACE(REPLACE(CTR_ID,CHR(13),''),CHR(10),'') CTR_ID
, REPLACE(REPLACE(POL_NO,CHR(13),''),CHR(10),'') POL_NO
, REPLACE(REPLACE(UNT_PD_CD,CHR(13),''),CHR(10),'') UNT_PD_CD
, OCC_DT
, DRMC_CONV_DT
, PRIN
, IAMT
, SUM_AMT
, REPLACE(REPLACE(POLHD_INDV_CRP_DIV_CD,CHR(13),''),CHR(10),'') POLHD_INDV_CRP_DIV_CD
, LAST_PY_TMS
, REPLACE(REPLACE(LAST_PY_YYMM,CHR(13),''),CHR(10),'') LAST_PY_YYMM
, REPLACE(REPLACE(INSPE_CUS_ID,CHR(13),''),CHR(10),'') INSPE_CUS_ID
, REPLACE(REPLACE(NW_STIC_PD_CTG_CD,CHR(13),''),CHR(10),'') NW_STIC_PD_CTG_CD
, REPLACE(REPLACE(BND_PVSZUR_YN,CHR(13),''),CHR(10),'') BND_PVSZUR_YN
, REPLACE(REPLACE(PLR_YN,CHR(13),''),CHR(10),'') PLR_YN
, REPLACE(REPLACE(PAY_PRHBT_YN,CHR(13),''),CHR(10),'') PAY_PRHBT_YN
, REPLACE(REPLACE(ASSO_DPC_TRG_YN,CHR(13),''),CHR(10),'') ASSO_DPC_TRG_YN
, REPLACE(REPLACE(ACC_CLOG_INCL_YN,CHR(13),''),CHR(10),'') ACC_CLOG_INCL_YN
, REPLACE(REPLACE(HDQT_ORG_ID,CHR(13),''),CHR(10),'') HDQT_ORG_ID
, REPLACE(REPLACE(BRCH_ORG_ID,CHR(13),''),CHR(10),'') BRCH_ORG_ID
, REPLACE(REPLACE(BCH_ORG_ID,CHR(13),''),CHR(10),'') BCH_ORG_ID
, REPLACE(REPLACE(TRTPE_ORG_ID,CHR(13),''),CHR(10),'') TRTPE_ORG_ID
, REPLACE(REPLACE(AGPLR_ORG_ID,CHR(13),''),CHR(10),'') AGPLR_ORG_ID
, REPLACE(REPLACE(AGC_BROF_ORG_ID,CHR(13),''),CHR(10),'') AGC_BROF_ORG_ID
, REPLACE(REPLACE(POLHD_CUS_ID,CHR(13),''),CHR(10),'') POLHD_CUS_ID
, REPLACE(REPLACE(POLHD_NM,CHR(13),''),CHR(10),'') POLHD_NM
, REPLACE(REPLACE(PDGP_CD,CHR(13),''),CHR(10),'') PDGP_CD
, REPLACE(REPLACE(OD_STIC_PD_CTG_CD,CHR(13),''),CHR(10),'') OD_STIC_PD_CTG_CD
, REPLACE(REPLACE(CTR_STAT_DTL_CD,CHR(13),''),CHR(10),'') CTR_STAT_DTL_CD
, PY_PRD
, REPLACE(REPLACE(PY_PRD_TP_CD,CHR(13),''),CHR(10),'') PY_PRD_TP_CD
, REPLACE(REPLACE(INS_PRD_TP_CD,CHR(13),''),CHR(10),'') INS_PRD_TP_CD
, REPLACE(REPLACE(CLF_DIV_CD,CHR(13),''),CHR(10),'') CLF_DIV_CD
, REPLACE(REPLACE(INS_SBC_SH_CD,CHR(13),''),CHR(10),'') INS_SBC_SH_CD
, REPLACE(REPLACE(INS_SBC_TP_CD,CHR(13),''),CHR(10),'') INS_SBC_TP_CD
, INSD_AMT
, REPLACE(REPLACE(RCRT_SH_CD,CHR(13),''),CHR(10),'') RCRT_SH_CD
, PY_ST_DT
, PY_ED_DT
, INS_ST_DT
, INS_ED_DT
, INS_PRD
, SLZ_PREM
, MMPY_CNVS_PREM
, SBCP_DT
, REPLACE(REPLACE(SBCP_CHN_DIV_CD,CHR(13),''),CHR(10),'') SBCP_CHN_DIV_CD
, REPLACE(REPLACE(CLLPE_ORG_ID,CHR(13),''),CHR(10),'') CLLPE_ORG_ID
, REPLACE(REPLACE(INDV_CRP_DIV_CD,CHR(13),''),CHR(10),'') INDV_CRP_DIV_CD
, REPLACE(REPLACE(SAL_CHN_DIV_CD,CHR(13),''),CHR(10),'') SAL_CHN_DIV_CD
, REPLACE(REPLACE(MNCL_MD_CD,CHR(13),''),CHR(10),'') MNCL_MD_CD
, REPLACE(REPLACE(PY_CYC_CD,CHR(13),''),CHR(10),'') PY_CYC_CD
, REPLACE(REPLACE(CTR_STAT_CD,CHR(13),''),CHR(10),'') CTR_STAT_CD
, REPLACE(REPLACE(DRI_AMT_PCS_DIV_CD,CHR(13),''),CHR(10),'') DRI_AMT_PCS_DIV_CD
, PCS_DT
, REPLACE(REPLACE(INPPE_ORG_ID,CHR(13),''),CHR(10),'') INPPE_ORG_ID
, SYS_OCC_DTM
, REPLACE(REPLACE(SYS_DEL_DIV_CD,CHR(13),''),CHR(10),'') SYS_DEL_DIV_CD
, REPLACE(REPLACE(OCC_IP,CHR(13),''),CHR(10),'') OCC_IP
, REPLACE(REPLACE(APP_ID,CHR(13),''),CHR(10),'') APP_ID
, DATA_CHNG_DTM
, EIH_LDG_DTM FROM THDDH_TCTDRUPCLG
                       WHERE \$CONDITIONS "\
    --m 1 \
    --target-dir /tmp2/INIT_THDDH_TCTDRUPCLG \
    --hive-import \
    --external-table-dir hdfs:///tmp2/temp_tbl/INIT_THDDH_TCTDRUPCLG \
    --hive-overwrite \
    --hive-table DEFAULT.INIT_THDDH_TCTDRUPCLG  >> ${SHLOG_DIR}/INIT_THDDH_TCTDRUPCLG.shlog 2>&1 &&

#----------------------------------------------------#
# Hadoop 원본테이블에 변경분 최종 적용
#----------------------------------------------------#
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TCTDRUPCLG_ITMP ; " >> ${SHLOG_DIR}/INIT_THDDH_TCTDRUPCLG.shlog 2>&1 &&
    /usr/bin/hive -e "CREATE EXTERNAL TABLE MERITZ.THDDH_TCTDRUPCLG_ITMP STORED AS PARQUET TBLPROPERTIES ('PARQUET.COMPRESS'='SNAPPY') AS
                                SELECT *
                                FROM DEFAULT.INIT_THDDH_TCTDRUPCLG ;" >> ${SHLOG_DIR}/INIT_THDDH_TCTDRUPCLG.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.INIT_THDDH_TCTDRUPCLG ;" >> ${SHLOG_DIR}/INIT_THDDH_TCTDRUPCLG.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TCTDRUPCLG ;" >> ${SHLOG_DIR}/INIT_THDDH_TCTDRUPCLG.shlog 2>&1 &&
    /usr/bin/hive -e "ALTER TABLE MERITZ.THDDH_TCTDRUPCLG_ITMP RENAME TO MERITZ.THDDH_TCTDRUPCLG ;" >> ${SHLOG_DIR}/INIT_THDDH_TCTDRUPCLG.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TCTDRUPCLG_ITMP ;" >> ${SHLOG_DIR}/INIT_THDDH_TCTDRUPCLG.shlog 2>&1 

if [ $? -ne 0 ]
then             
    echo "*-----------[ INIT_THDDH_TCTDRUPCLG.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/INIT_THDDH_TCTDRUPCLG.shlog"
    echo "*-----------[ INIT_THDDH_TCTDRUPCLG.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/INIT_THDDH_TCTDRUPCLG.shlog"  >>  ${SHLOG_DIR}/INIT_THDDH_TCTDRUPCLG.shlog
    echo "*-----------[ INIT_THDDH_TCTDRUPCLG.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ INIT_THDDH_TCTDRUPCLG.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/INIT_THDDH_TCTDRUPCLG.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/INIT_THDDH_TCTDRUPCLG.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/INIT_THDDH_TCTDRUPCLG.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/INIT_THDDH_TCTDRUPCLG.shlog /sqoopbin/scripts/etlpgm/his_log/INIT_THDDH_TCTDRUPCLG_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  INIT_THDDH_TCTDRUPCLG.sh cmd command error !! ***
    fi               

    exit -1      

else             
    echo "*-----------[ INIT_THDDH_TCTDRUPCLG.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ INIT_THDDH_TCTDRUPCLG.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/INIT_THDDH_TCTDRUPCLG.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/INIT_THDDH_TCTDRUPCLG.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/INIT_THDDH_TCTDRUPCLG.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/INIT_THDDH_TCTDRUPCLG.shlog /sqoopbin/scripts/etlpgm/his_log/INIT_THDDH_TCTDRUPCLG_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  INIT_THDDH_TCTDRUPCLG.sh cmd command error !! ***
        exit -1      
    else             
        exit 0       
    fi               
fi               
