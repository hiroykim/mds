// ORM class for table 'null'
// WARNING: This class is AUTO-GENERATED. Modify at your own risk.
//
// Debug information:
// Generated date: Tue Nov 21 10:57:23 KST 2017
// For connector: org.apache.sqoop.manager.OracleManager
import org.apache.hadoop.io.BytesWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.mapred.lib.db.DBWritable;
import com.cloudera.sqoop.lib.JdbcWritableBridge;
import com.cloudera.sqoop.lib.DelimiterSet;
import com.cloudera.sqoop.lib.FieldFormatter;
import com.cloudera.sqoop.lib.RecordParser;
import com.cloudera.sqoop.lib.BooleanParser;
import com.cloudera.sqoop.lib.BlobRef;
import com.cloudera.sqoop.lib.ClobRef;
import com.cloudera.sqoop.lib.LargeObjectLoader;
import com.cloudera.sqoop.lib.SqoopRecord;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.sql.Date;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

public class QueryResult extends SqoopRecord  implements DBWritable, Writable {
  private final int PROTOCOL_VERSION = 3;
  public int getClassFormatVersion() { return PROTOCOL_VERSION; }
  public static interface FieldSetterCommand {    void setField(Object value);  }  protected ResultSet __cur_result_set;
  private Map<String, FieldSetterCommand> setters = new HashMap<String, FieldSetterCommand>();
  private void init0() {
    setters.put("EXE_DT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        EXE_DT = (java.sql.Timestamp)value;
      }
    });
    setters.put("BAT_FFMT_INF_ID", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        BAT_FFMT_INF_ID = (String)value;
      }
    });
    setters.put("BAT_SVC_INF_ID", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        BAT_SVC_INF_ID = (String)value;
      }
    });
    setters.put("BAT_SVC_NM", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        BAT_SVC_NM = (String)value;
      }
    });
    setters.put("BAT_EXE_CYC_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        BAT_EXE_CYC_CD = (String)value;
      }
    });
    setters.put("MIN_FFMT_HR", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        MIN_FFMT_HR = (java.math.BigDecimal)value;
      }
    });
    setters.put("MAX_FFMT_HR", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        MAX_FFMT_HR = (java.math.BigDecimal)value;
      }
    });
    setters.put("BAT_TT_FFMT_HR", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        BAT_TT_FFMT_HR = (java.math.BigDecimal)value;
      }
    });
    setters.put("AVG_FFMT_HR", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        AVG_FFMT_HR = (java.math.BigDecimal)value;
      }
    });
    setters.put("BAT_EXE_CNT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        BAT_EXE_CNT = (java.math.BigDecimal)value;
      }
    });
    setters.put("EIH_LDG_DTM", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        EIH_LDG_DTM = (java.sql.Timestamp)value;
      }
    });
  }
  public QueryResult() {
    init0();
  }
  private java.sql.Timestamp EXE_DT;
  public java.sql.Timestamp get_EXE_DT() {
    return EXE_DT;
  }
  public void set_EXE_DT(java.sql.Timestamp EXE_DT) {
    this.EXE_DT = EXE_DT;
  }
  public QueryResult with_EXE_DT(java.sql.Timestamp EXE_DT) {
    this.EXE_DT = EXE_DT;
    return this;
  }
  private String BAT_FFMT_INF_ID;
  public String get_BAT_FFMT_INF_ID() {
    return BAT_FFMT_INF_ID;
  }
  public void set_BAT_FFMT_INF_ID(String BAT_FFMT_INF_ID) {
    this.BAT_FFMT_INF_ID = BAT_FFMT_INF_ID;
  }
  public QueryResult with_BAT_FFMT_INF_ID(String BAT_FFMT_INF_ID) {
    this.BAT_FFMT_INF_ID = BAT_FFMT_INF_ID;
    return this;
  }
  private String BAT_SVC_INF_ID;
  public String get_BAT_SVC_INF_ID() {
    return BAT_SVC_INF_ID;
  }
  public void set_BAT_SVC_INF_ID(String BAT_SVC_INF_ID) {
    this.BAT_SVC_INF_ID = BAT_SVC_INF_ID;
  }
  public QueryResult with_BAT_SVC_INF_ID(String BAT_SVC_INF_ID) {
    this.BAT_SVC_INF_ID = BAT_SVC_INF_ID;
    return this;
  }
  private String BAT_SVC_NM;
  public String get_BAT_SVC_NM() {
    return BAT_SVC_NM;
  }
  public void set_BAT_SVC_NM(String BAT_SVC_NM) {
    this.BAT_SVC_NM = BAT_SVC_NM;
  }
  public QueryResult with_BAT_SVC_NM(String BAT_SVC_NM) {
    this.BAT_SVC_NM = BAT_SVC_NM;
    return this;
  }
  private String BAT_EXE_CYC_CD;
  public String get_BAT_EXE_CYC_CD() {
    return BAT_EXE_CYC_CD;
  }
  public void set_BAT_EXE_CYC_CD(String BAT_EXE_CYC_CD) {
    this.BAT_EXE_CYC_CD = BAT_EXE_CYC_CD;
  }
  public QueryResult with_BAT_EXE_CYC_CD(String BAT_EXE_CYC_CD) {
    this.BAT_EXE_CYC_CD = BAT_EXE_CYC_CD;
    return this;
  }
  private java.math.BigDecimal MIN_FFMT_HR;
  public java.math.BigDecimal get_MIN_FFMT_HR() {
    return MIN_FFMT_HR;
  }
  public void set_MIN_FFMT_HR(java.math.BigDecimal MIN_FFMT_HR) {
    this.MIN_FFMT_HR = MIN_FFMT_HR;
  }
  public QueryResult with_MIN_FFMT_HR(java.math.BigDecimal MIN_FFMT_HR) {
    this.MIN_FFMT_HR = MIN_FFMT_HR;
    return this;
  }
  private java.math.BigDecimal MAX_FFMT_HR;
  public java.math.BigDecimal get_MAX_FFMT_HR() {
    return MAX_FFMT_HR;
  }
  public void set_MAX_FFMT_HR(java.math.BigDecimal MAX_FFMT_HR) {
    this.MAX_FFMT_HR = MAX_FFMT_HR;
  }
  public QueryResult with_MAX_FFMT_HR(java.math.BigDecimal MAX_FFMT_HR) {
    this.MAX_FFMT_HR = MAX_FFMT_HR;
    return this;
  }
  private java.math.BigDecimal BAT_TT_FFMT_HR;
  public java.math.BigDecimal get_BAT_TT_FFMT_HR() {
    return BAT_TT_FFMT_HR;
  }
  public void set_BAT_TT_FFMT_HR(java.math.BigDecimal BAT_TT_FFMT_HR) {
    this.BAT_TT_FFMT_HR = BAT_TT_FFMT_HR;
  }
  public QueryResult with_BAT_TT_FFMT_HR(java.math.BigDecimal BAT_TT_FFMT_HR) {
    this.BAT_TT_FFMT_HR = BAT_TT_FFMT_HR;
    return this;
  }
  private java.math.BigDecimal AVG_FFMT_HR;
  public java.math.BigDecimal get_AVG_FFMT_HR() {
    return AVG_FFMT_HR;
  }
  public void set_AVG_FFMT_HR(java.math.BigDecimal AVG_FFMT_HR) {
    this.AVG_FFMT_HR = AVG_FFMT_HR;
  }
  public QueryResult with_AVG_FFMT_HR(java.math.BigDecimal AVG_FFMT_HR) {
    this.AVG_FFMT_HR = AVG_FFMT_HR;
    return this;
  }
  private java.math.BigDecimal BAT_EXE_CNT;
  public java.math.BigDecimal get_BAT_EXE_CNT() {
    return BAT_EXE_CNT;
  }
  public void set_BAT_EXE_CNT(java.math.BigDecimal BAT_EXE_CNT) {
    this.BAT_EXE_CNT = BAT_EXE_CNT;
  }
  public QueryResult with_BAT_EXE_CNT(java.math.BigDecimal BAT_EXE_CNT) {
    this.BAT_EXE_CNT = BAT_EXE_CNT;
    return this;
  }
  private java.sql.Timestamp EIH_LDG_DTM;
  public java.sql.Timestamp get_EIH_LDG_DTM() {
    return EIH_LDG_DTM;
  }
  public void set_EIH_LDG_DTM(java.sql.Timestamp EIH_LDG_DTM) {
    this.EIH_LDG_DTM = EIH_LDG_DTM;
  }
  public QueryResult with_EIH_LDG_DTM(java.sql.Timestamp EIH_LDG_DTM) {
    this.EIH_LDG_DTM = EIH_LDG_DTM;
    return this;
  }
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (!(o instanceof QueryResult)) {
      return false;
    }
    QueryResult that = (QueryResult) o;
    boolean equal = true;
    equal = equal && (this.EXE_DT == null ? that.EXE_DT == null : this.EXE_DT.equals(that.EXE_DT));
    equal = equal && (this.BAT_FFMT_INF_ID == null ? that.BAT_FFMT_INF_ID == null : this.BAT_FFMT_INF_ID.equals(that.BAT_FFMT_INF_ID));
    equal = equal && (this.BAT_SVC_INF_ID == null ? that.BAT_SVC_INF_ID == null : this.BAT_SVC_INF_ID.equals(that.BAT_SVC_INF_ID));
    equal = equal && (this.BAT_SVC_NM == null ? that.BAT_SVC_NM == null : this.BAT_SVC_NM.equals(that.BAT_SVC_NM));
    equal = equal && (this.BAT_EXE_CYC_CD == null ? that.BAT_EXE_CYC_CD == null : this.BAT_EXE_CYC_CD.equals(that.BAT_EXE_CYC_CD));
    equal = equal && (this.MIN_FFMT_HR == null ? that.MIN_FFMT_HR == null : this.MIN_FFMT_HR.equals(that.MIN_FFMT_HR));
    equal = equal && (this.MAX_FFMT_HR == null ? that.MAX_FFMT_HR == null : this.MAX_FFMT_HR.equals(that.MAX_FFMT_HR));
    equal = equal && (this.BAT_TT_FFMT_HR == null ? that.BAT_TT_FFMT_HR == null : this.BAT_TT_FFMT_HR.equals(that.BAT_TT_FFMT_HR));
    equal = equal && (this.AVG_FFMT_HR == null ? that.AVG_FFMT_HR == null : this.AVG_FFMT_HR.equals(that.AVG_FFMT_HR));
    equal = equal && (this.BAT_EXE_CNT == null ? that.BAT_EXE_CNT == null : this.BAT_EXE_CNT.equals(that.BAT_EXE_CNT));
    equal = equal && (this.EIH_LDG_DTM == null ? that.EIH_LDG_DTM == null : this.EIH_LDG_DTM.equals(that.EIH_LDG_DTM));
    return equal;
  }
  public boolean equals0(Object o) {
    if (this == o) {
      return true;
    }
    if (!(o instanceof QueryResult)) {
      return false;
    }
    QueryResult that = (QueryResult) o;
    boolean equal = true;
    equal = equal && (this.EXE_DT == null ? that.EXE_DT == null : this.EXE_DT.equals(that.EXE_DT));
    equal = equal && (this.BAT_FFMT_INF_ID == null ? that.BAT_FFMT_INF_ID == null : this.BAT_FFMT_INF_ID.equals(that.BAT_FFMT_INF_ID));
    equal = equal && (this.BAT_SVC_INF_ID == null ? that.BAT_SVC_INF_ID == null : this.BAT_SVC_INF_ID.equals(that.BAT_SVC_INF_ID));
    equal = equal && (this.BAT_SVC_NM == null ? that.BAT_SVC_NM == null : this.BAT_SVC_NM.equals(that.BAT_SVC_NM));
    equal = equal && (this.BAT_EXE_CYC_CD == null ? that.BAT_EXE_CYC_CD == null : this.BAT_EXE_CYC_CD.equals(that.BAT_EXE_CYC_CD));
    equal = equal && (this.MIN_FFMT_HR == null ? that.MIN_FFMT_HR == null : this.MIN_FFMT_HR.equals(that.MIN_FFMT_HR));
    equal = equal && (this.MAX_FFMT_HR == null ? that.MAX_FFMT_HR == null : this.MAX_FFMT_HR.equals(that.MAX_FFMT_HR));
    equal = equal && (this.BAT_TT_FFMT_HR == null ? that.BAT_TT_FFMT_HR == null : this.BAT_TT_FFMT_HR.equals(that.BAT_TT_FFMT_HR));
    equal = equal && (this.AVG_FFMT_HR == null ? that.AVG_FFMT_HR == null : this.AVG_FFMT_HR.equals(that.AVG_FFMT_HR));
    equal = equal && (this.BAT_EXE_CNT == null ? that.BAT_EXE_CNT == null : this.BAT_EXE_CNT.equals(that.BAT_EXE_CNT));
    equal = equal && (this.EIH_LDG_DTM == null ? that.EIH_LDG_DTM == null : this.EIH_LDG_DTM.equals(that.EIH_LDG_DTM));
    return equal;
  }
  public void readFields(ResultSet __dbResults) throws SQLException {
    this.__cur_result_set = __dbResults;
    this.EXE_DT = JdbcWritableBridge.readTimestamp(1, __dbResults);
    this.BAT_FFMT_INF_ID = JdbcWritableBridge.readString(2, __dbResults);
    this.BAT_SVC_INF_ID = JdbcWritableBridge.readString(3, __dbResults);
    this.BAT_SVC_NM = JdbcWritableBridge.readString(4, __dbResults);
    this.BAT_EXE_CYC_CD = JdbcWritableBridge.readString(5, __dbResults);
    this.MIN_FFMT_HR = JdbcWritableBridge.readBigDecimal(6, __dbResults);
    this.MAX_FFMT_HR = JdbcWritableBridge.readBigDecimal(7, __dbResults);
    this.BAT_TT_FFMT_HR = JdbcWritableBridge.readBigDecimal(8, __dbResults);
    this.AVG_FFMT_HR = JdbcWritableBridge.readBigDecimal(9, __dbResults);
    this.BAT_EXE_CNT = JdbcWritableBridge.readBigDecimal(10, __dbResults);
    this.EIH_LDG_DTM = JdbcWritableBridge.readTimestamp(11, __dbResults);
  }
  public void readFields0(ResultSet __dbResults) throws SQLException {
    this.EXE_DT = JdbcWritableBridge.readTimestamp(1, __dbResults);
    this.BAT_FFMT_INF_ID = JdbcWritableBridge.readString(2, __dbResults);
    this.BAT_SVC_INF_ID = JdbcWritableBridge.readString(3, __dbResults);
    this.BAT_SVC_NM = JdbcWritableBridge.readString(4, __dbResults);
    this.BAT_EXE_CYC_CD = JdbcWritableBridge.readString(5, __dbResults);
    this.MIN_FFMT_HR = JdbcWritableBridge.readBigDecimal(6, __dbResults);
    this.MAX_FFMT_HR = JdbcWritableBridge.readBigDecimal(7, __dbResults);
    this.BAT_TT_FFMT_HR = JdbcWritableBridge.readBigDecimal(8, __dbResults);
    this.AVG_FFMT_HR = JdbcWritableBridge.readBigDecimal(9, __dbResults);
    this.BAT_EXE_CNT = JdbcWritableBridge.readBigDecimal(10, __dbResults);
    this.EIH_LDG_DTM = JdbcWritableBridge.readTimestamp(11, __dbResults);
  }
  public void loadLargeObjects(LargeObjectLoader __loader)
      throws SQLException, IOException, InterruptedException {
  }
  public void loadLargeObjects0(LargeObjectLoader __loader)
      throws SQLException, IOException, InterruptedException {
  }
  public void write(PreparedStatement __dbStmt) throws SQLException {
    write(__dbStmt, 0);
  }

  public int write(PreparedStatement __dbStmt, int __off) throws SQLException {
    JdbcWritableBridge.writeTimestamp(EXE_DT, 1 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeString(BAT_FFMT_INF_ID, 2 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(BAT_SVC_INF_ID, 3 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(BAT_SVC_NM, 4 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(BAT_EXE_CYC_CD, 5 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(MIN_FFMT_HR, 6 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(MAX_FFMT_HR, 7 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(BAT_TT_FFMT_HR, 8 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(AVG_FFMT_HR, 9 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(BAT_EXE_CNT, 10 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeTimestamp(EIH_LDG_DTM, 11 + __off, 93, __dbStmt);
    return 11;
  }
  public void write0(PreparedStatement __dbStmt, int __off) throws SQLException {
    JdbcWritableBridge.writeTimestamp(EXE_DT, 1 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeString(BAT_FFMT_INF_ID, 2 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(BAT_SVC_INF_ID, 3 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(BAT_SVC_NM, 4 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(BAT_EXE_CYC_CD, 5 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(MIN_FFMT_HR, 6 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(MAX_FFMT_HR, 7 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(BAT_TT_FFMT_HR, 8 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(AVG_FFMT_HR, 9 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(BAT_EXE_CNT, 10 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeTimestamp(EIH_LDG_DTM, 11 + __off, 93, __dbStmt);
  }
  public void readFields(DataInput __dataIn) throws IOException {
this.readFields0(__dataIn);  }
  public void readFields0(DataInput __dataIn) throws IOException {
    if (__dataIn.readBoolean()) { 
        this.EXE_DT = null;
    } else {
    this.EXE_DT = new Timestamp(__dataIn.readLong());
    this.EXE_DT.setNanos(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.BAT_FFMT_INF_ID = null;
    } else {
    this.BAT_FFMT_INF_ID = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.BAT_SVC_INF_ID = null;
    } else {
    this.BAT_SVC_INF_ID = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.BAT_SVC_NM = null;
    } else {
    this.BAT_SVC_NM = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.BAT_EXE_CYC_CD = null;
    } else {
    this.BAT_EXE_CYC_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.MIN_FFMT_HR = null;
    } else {
    this.MIN_FFMT_HR = com.cloudera.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.MAX_FFMT_HR = null;
    } else {
    this.MAX_FFMT_HR = com.cloudera.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.BAT_TT_FFMT_HR = null;
    } else {
    this.BAT_TT_FFMT_HR = com.cloudera.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.AVG_FFMT_HR = null;
    } else {
    this.AVG_FFMT_HR = com.cloudera.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.BAT_EXE_CNT = null;
    } else {
    this.BAT_EXE_CNT = com.cloudera.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.EIH_LDG_DTM = null;
    } else {
    this.EIH_LDG_DTM = new Timestamp(__dataIn.readLong());
    this.EIH_LDG_DTM.setNanos(__dataIn.readInt());
    }
  }
  public void write(DataOutput __dataOut) throws IOException {
    if (null == this.EXE_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.EXE_DT.getTime());
    __dataOut.writeInt(this.EXE_DT.getNanos());
    }
    if (null == this.BAT_FFMT_INF_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, BAT_FFMT_INF_ID);
    }
    if (null == this.BAT_SVC_INF_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, BAT_SVC_INF_ID);
    }
    if (null == this.BAT_SVC_NM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, BAT_SVC_NM);
    }
    if (null == this.BAT_EXE_CYC_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, BAT_EXE_CYC_CD);
    }
    if (null == this.MIN_FFMT_HR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.MIN_FFMT_HR, __dataOut);
    }
    if (null == this.MAX_FFMT_HR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.MAX_FFMT_HR, __dataOut);
    }
    if (null == this.BAT_TT_FFMT_HR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.BAT_TT_FFMT_HR, __dataOut);
    }
    if (null == this.AVG_FFMT_HR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.AVG_FFMT_HR, __dataOut);
    }
    if (null == this.BAT_EXE_CNT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.BAT_EXE_CNT, __dataOut);
    }
    if (null == this.EIH_LDG_DTM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.EIH_LDG_DTM.getTime());
    __dataOut.writeInt(this.EIH_LDG_DTM.getNanos());
    }
  }
  public void write0(DataOutput __dataOut) throws IOException {
    if (null == this.EXE_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.EXE_DT.getTime());
    __dataOut.writeInt(this.EXE_DT.getNanos());
    }
    if (null == this.BAT_FFMT_INF_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, BAT_FFMT_INF_ID);
    }
    if (null == this.BAT_SVC_INF_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, BAT_SVC_INF_ID);
    }
    if (null == this.BAT_SVC_NM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, BAT_SVC_NM);
    }
    if (null == this.BAT_EXE_CYC_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, BAT_EXE_CYC_CD);
    }
    if (null == this.MIN_FFMT_HR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.MIN_FFMT_HR, __dataOut);
    }
    if (null == this.MAX_FFMT_HR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.MAX_FFMT_HR, __dataOut);
    }
    if (null == this.BAT_TT_FFMT_HR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.BAT_TT_FFMT_HR, __dataOut);
    }
    if (null == this.AVG_FFMT_HR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.AVG_FFMT_HR, __dataOut);
    }
    if (null == this.BAT_EXE_CNT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.BAT_EXE_CNT, __dataOut);
    }
    if (null == this.EIH_LDG_DTM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.EIH_LDG_DTM.getTime());
    __dataOut.writeInt(this.EIH_LDG_DTM.getNanos());
    }
  }
  private static final DelimiterSet __outputDelimiters = new DelimiterSet((char) 1, (char) 10, (char) 0, (char) 0, false);
  public String toString() {
    return toString(__outputDelimiters, true);
  }
  public String toString(DelimiterSet delimiters) {
    return toString(delimiters, true);
  }
  public String toString(boolean useRecordDelim) {
    return toString(__outputDelimiters, useRecordDelim);
  }
  public String toString(DelimiterSet delimiters, boolean useRecordDelim) {
    StringBuilder __sb = new StringBuilder();
    char fieldDelim = delimiters.getFieldsTerminatedBy();
    __sb.append(FieldFormatter.escapeAndEnclose(EXE_DT==null?"null":"" + EXE_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(BAT_FFMT_INF_ID==null?"null":BAT_FFMT_INF_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(BAT_SVC_INF_ID==null?"null":BAT_SVC_INF_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(BAT_SVC_NM==null?"null":BAT_SVC_NM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(BAT_EXE_CYC_CD==null?"null":BAT_EXE_CYC_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(MIN_FFMT_HR==null?"null":MIN_FFMT_HR.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(MAX_FFMT_HR==null?"null":MAX_FFMT_HR.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(BAT_TT_FFMT_HR==null?"null":BAT_TT_FFMT_HR.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(AVG_FFMT_HR==null?"null":AVG_FFMT_HR.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(BAT_EXE_CNT==null?"null":BAT_EXE_CNT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(EIH_LDG_DTM==null?"null":"" + EIH_LDG_DTM, delimiters));
    if (useRecordDelim) {
      __sb.append(delimiters.getLinesTerminatedBy());
    }
    return __sb.toString();
  }
  public void toString0(DelimiterSet delimiters, StringBuilder __sb, char fieldDelim) {
    __sb.append(FieldFormatter.escapeAndEnclose(EXE_DT==null?"null":"" + EXE_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(BAT_FFMT_INF_ID==null?"null":BAT_FFMT_INF_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(BAT_SVC_INF_ID==null?"null":BAT_SVC_INF_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(BAT_SVC_NM==null?"null":BAT_SVC_NM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(BAT_EXE_CYC_CD==null?"null":BAT_EXE_CYC_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(MIN_FFMT_HR==null?"null":MIN_FFMT_HR.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(MAX_FFMT_HR==null?"null":MAX_FFMT_HR.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(BAT_TT_FFMT_HR==null?"null":BAT_TT_FFMT_HR.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(AVG_FFMT_HR==null?"null":AVG_FFMT_HR.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(BAT_EXE_CNT==null?"null":BAT_EXE_CNT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(EIH_LDG_DTM==null?"null":"" + EIH_LDG_DTM, delimiters));
  }
  private static final DelimiterSet __inputDelimiters = new DelimiterSet((char) 1, (char) 10, (char) 0, (char) 0, false);
  private RecordParser __parser;
  public void parse(Text __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(CharSequence __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(byte [] __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(char [] __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(ByteBuffer __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(CharBuffer __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  private void __loadFromFields(List<String> fields) {
    Iterator<String> __it = fields.listIterator();
    String __cur_str = null;
    try {
    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.EXE_DT = null; } else {
      this.EXE_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.BAT_FFMT_INF_ID = null; } else {
      this.BAT_FFMT_INF_ID = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.BAT_SVC_INF_ID = null; } else {
      this.BAT_SVC_INF_ID = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.BAT_SVC_NM = null; } else {
      this.BAT_SVC_NM = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.BAT_EXE_CYC_CD = null; } else {
      this.BAT_EXE_CYC_CD = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.MIN_FFMT_HR = null; } else {
      this.MIN_FFMT_HR = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.MAX_FFMT_HR = null; } else {
      this.MAX_FFMT_HR = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.BAT_TT_FFMT_HR = null; } else {
      this.BAT_TT_FFMT_HR = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.AVG_FFMT_HR = null; } else {
      this.AVG_FFMT_HR = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.BAT_EXE_CNT = null; } else {
      this.BAT_EXE_CNT = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.EIH_LDG_DTM = null; } else {
      this.EIH_LDG_DTM = java.sql.Timestamp.valueOf(__cur_str);
    }

    } catch (RuntimeException e) {    throw new RuntimeException("Can't parse input data: '" + __cur_str + "'", e);    }  }

  private void __loadFromFields0(Iterator<String> __it) {
    String __cur_str = null;
    try {
    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.EXE_DT = null; } else {
      this.EXE_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.BAT_FFMT_INF_ID = null; } else {
      this.BAT_FFMT_INF_ID = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.BAT_SVC_INF_ID = null; } else {
      this.BAT_SVC_INF_ID = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.BAT_SVC_NM = null; } else {
      this.BAT_SVC_NM = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.BAT_EXE_CYC_CD = null; } else {
      this.BAT_EXE_CYC_CD = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.MIN_FFMT_HR = null; } else {
      this.MIN_FFMT_HR = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.MAX_FFMT_HR = null; } else {
      this.MAX_FFMT_HR = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.BAT_TT_FFMT_HR = null; } else {
      this.BAT_TT_FFMT_HR = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.AVG_FFMT_HR = null; } else {
      this.AVG_FFMT_HR = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.BAT_EXE_CNT = null; } else {
      this.BAT_EXE_CNT = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.EIH_LDG_DTM = null; } else {
      this.EIH_LDG_DTM = java.sql.Timestamp.valueOf(__cur_str);
    }

    } catch (RuntimeException e) {    throw new RuntimeException("Can't parse input data: '" + __cur_str + "'", e);    }  }

  public Object clone() throws CloneNotSupportedException {
    QueryResult o = (QueryResult) super.clone();
    o.EXE_DT = (o.EXE_DT != null) ? (java.sql.Timestamp) o.EXE_DT.clone() : null;
    o.EIH_LDG_DTM = (o.EIH_LDG_DTM != null) ? (java.sql.Timestamp) o.EIH_LDG_DTM.clone() : null;
    return o;
  }

  public void clone0(QueryResult o) throws CloneNotSupportedException {
    o.EXE_DT = (o.EXE_DT != null) ? (java.sql.Timestamp) o.EXE_DT.clone() : null;
    o.EIH_LDG_DTM = (o.EIH_LDG_DTM != null) ? (java.sql.Timestamp) o.EIH_LDG_DTM.clone() : null;
  }

  public Map<String, Object> getFieldMap() {
    Map<String, Object> __sqoop$field_map = new HashMap<String, Object>();
    __sqoop$field_map.put("EXE_DT", this.EXE_DT);
    __sqoop$field_map.put("BAT_FFMT_INF_ID", this.BAT_FFMT_INF_ID);
    __sqoop$field_map.put("BAT_SVC_INF_ID", this.BAT_SVC_INF_ID);
    __sqoop$field_map.put("BAT_SVC_NM", this.BAT_SVC_NM);
    __sqoop$field_map.put("BAT_EXE_CYC_CD", this.BAT_EXE_CYC_CD);
    __sqoop$field_map.put("MIN_FFMT_HR", this.MIN_FFMT_HR);
    __sqoop$field_map.put("MAX_FFMT_HR", this.MAX_FFMT_HR);
    __sqoop$field_map.put("BAT_TT_FFMT_HR", this.BAT_TT_FFMT_HR);
    __sqoop$field_map.put("AVG_FFMT_HR", this.AVG_FFMT_HR);
    __sqoop$field_map.put("BAT_EXE_CNT", this.BAT_EXE_CNT);
    __sqoop$field_map.put("EIH_LDG_DTM", this.EIH_LDG_DTM);
    return __sqoop$field_map;
  }

  public void getFieldMap0(Map<String, Object> __sqoop$field_map) {
    __sqoop$field_map.put("EXE_DT", this.EXE_DT);
    __sqoop$field_map.put("BAT_FFMT_INF_ID", this.BAT_FFMT_INF_ID);
    __sqoop$field_map.put("BAT_SVC_INF_ID", this.BAT_SVC_INF_ID);
    __sqoop$field_map.put("BAT_SVC_NM", this.BAT_SVC_NM);
    __sqoop$field_map.put("BAT_EXE_CYC_CD", this.BAT_EXE_CYC_CD);
    __sqoop$field_map.put("MIN_FFMT_HR", this.MIN_FFMT_HR);
    __sqoop$field_map.put("MAX_FFMT_HR", this.MAX_FFMT_HR);
    __sqoop$field_map.put("BAT_TT_FFMT_HR", this.BAT_TT_FFMT_HR);
    __sqoop$field_map.put("AVG_FFMT_HR", this.AVG_FFMT_HR);
    __sqoop$field_map.put("BAT_EXE_CNT", this.BAT_EXE_CNT);
    __sqoop$field_map.put("EIH_LDG_DTM", this.EIH_LDG_DTM);
  }

  public void setField(String __fieldName, Object __fieldVal) {
    if (!setters.containsKey(__fieldName)) {
      throw new RuntimeException("No such field:"+__fieldName);
    }
    setters.get(__fieldName).setField(__fieldVal);
  }

}
