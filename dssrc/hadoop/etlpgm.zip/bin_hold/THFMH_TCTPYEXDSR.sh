#!/bin/bash

if [ $# -eq 0 ]
then           
    ARGS=N    
else           
    ARGS=$1
fi             

NOW=$(date +"+%Y-%m-%d_%T")
SHLOG_DIR=/sqoopbin/scripts/etlpgm/cur_log
HISLOG_DIR=/sqoopbin/scripts/etlpgm/his_log

export HADOOP_OPTS=-Djava.security.egd=file:/dev/../dev/urandom
export ORACLE_BASE=/sw/oracle
export ORACLE_HOME=/sw/oracle/product/11.2.0.4/client_1
export LD_LIBRARY_PATH=/sw/oracle/product/11.2.0.4/client_1/lib:/sw/oracle/product/11.2.0.4/client_1/lib:
export PATH=/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/usr/lib64/qt-3.3/bin:/usr/hdp/3.0.0.0-1634/spark2/bin/:/var/opt/node/bin/:/opt/maven/bin:/usr/local/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/home/hdpapp/workspace/data-science-at-the-command-line/tools:/home/hdpapp/.local/bin:/home/hdpapp/bin
export TNS_ADMIN=/sw/oracle/product/11.2.0.4/client_1/network/admin
export ORACLE_SID=DBEDWP2
export NLS_LANG=American_America.KO16MSWIN949

#----------------------------------------------------#
# 작업내용 : THFMH_TCTPYEXDSR 테이블 sqoop 복제 작업
# 작업주기 :  
#----------------------------------------------------#

    echo " "
    echo "*-----------[ THFMH_TCTPYEXDSR.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THFMH_TCTPYEXDSR.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`  >  ${SHLOG_DIR}/THFMH_TCTPYEXDSR.shlog

#----------------------------------------------------#
# 테이블별 전체 데이터를 받아 오는 부분
#----------------------------------------------------#
    /usr/bin/hadoop fs -rm -r -f  /tmp2/LAST_THFMH_TCTPYEXDSR  >> ${SHLOG_DIR}/THFMH_TCTPYEXDSR.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.LAST_THFMH_TCTPYEXDSR ; " >> ${SHLOG_DIR}/THFMH_TCTPYEXDSR.shlog 2>&1 &&
    /usr/hdp/3.0.0.0-1634/sqoop/bin/sqoop import -D mapred.child.java.opts="-Djava.security.egd=file:/dev/../dev/urandom" \
    --connect jdbc:oracle:thin:EDWHADOOP/wjdqhrP\!23@10.91.41.172:12560:DBEDWP2 \
    --username  EDWHADOOP \
    --password wjdqhrP\!23 \
    --query "SELECT /*+ FULL(THFMH_TCTPYEXDSR) */ REPLACE(REPLACE(CLOG_YYMM,CHR(13),''),CHR(10),'') CLOG_YYMM
, REPLACE(REPLACE(COVTP_PREM_DIS_ID,CHR(13),''),CHR(10),'') COVTP_PREM_DIS_ID
, REPLACE(REPLACE(CTR_COV_ID,CHR(13),''),CHR(10),'') CTR_COV_ID
, REPLACE(REPLACE(PREM_DIS_ID,CHR(13),''),CHR(10),'') PREM_DIS_ID
, REPLACE(REPLACE(POL_NO,CHR(13),''),CHR(10),'') POL_NO
, REPLACE(REPLACE(UNT_PD_CD,CHR(13),''),CHR(10),'') UNT_PD_CD
, REPLACE(REPLACE(PD_CD,CHR(13),''),CHR(10),'') PD_CD
, REPLACE(REPLACE(COV_CD,CHR(13),''),CHR(10),'') COV_CD
, REPLACE(REPLACE(CTR_OBJ_ID,CHR(13),''),CHR(10),'') CTR_OBJ_ID
, SBCP_DT
, REPLACE(REPLACE(PY_EXEM_KND_TYP_DIV_CD,CHR(13),''),CHR(10),'') PY_EXEM_KND_TYP_DIV_CD
, REPLACE(REPLACE(PY_EXEM_DIV_VAL,CHR(13),''),CHR(10),'') PY_EXEM_DIV_VAL
, REPLACE(REPLACE(CLF_DIV_CD,CHR(13),''),CHR(10),'') CLF_DIV_CD
, REPLACE(REPLACE(INS_SBC_SH_CD,CHR(13),''),CHR(10),'') INS_SBC_SH_CD
, REPLACE(REPLACE(INDP_SCYN,CHR(13),''),CHR(10),'') INDP_SCYN
, RCPT_PREM
, DIS_TRG_PREM
, DIS_PREM
, REPLACE(REPLACE(DIS_DIV_CD,CHR(13),''),CHR(10),'') DIS_DIV_CD
, REPLACE(REPLACE(NTLY_DIV_CD,CHR(13),''),CHR(10),'') NTLY_DIV_CD
, SBC_AMT_MLTP
, DC_XCHG_CF
, XPT_INTR
, REPLACE(REPLACE(PY_CYC_CD,CHR(13),''),CHR(10),'') PY_CYC_CD
, REPLACE(REPLACE(RKEY_CNFG_CHT_VAL,CHR(13),''),CHR(10),'') RKEY_CNFG_CHT_VAL
, PREM_CMPT_NET_PREM
, SOT_RDY_AMT
, EOT_RDY_AMT
, REPLACE(REPLACE(STY_RKEY_CNFG_CHT_VAL,CHR(13),''),CHR(10),'') STY_RKEY_CNFG_CHT_VAL
, STY_NET_PREM
, STY_SOT_RDY_AMT
, STY_EOT_RDY_AMT
, RSK_PREM
, PY_EXEM_NAPL_RSK_PREM
, REPLACE(REPLACE(SYS_DEL_DIV_CD,CHR(13),''),CHR(10),'') SYS_DEL_DIV_CD
, EIH_LDG_DTM
, REPLACE(REPLACE(PREM_CMPT_DIV_CD,CHR(13),''),CHR(10),'') PREM_CMPT_DIV_CD
, MTPE_NET_PREM
, MTPE_SOT_RDY_AMT
, MTPE_EOT_RDY_AMT
, MTPE_PY_EXEM_APL_RPM
, REPLACE(REPLACE(PYAF_BZ_EXP_RLT_PD_YN,CHR(13),''),CHR(10),'') PYAF_BZ_EXP_RLT_PD_YN
, REPLACE(REPLACE(MTPE_STD_CMPT_DIV_CD,CHR(13),''),CHR(10),'') MTPE_STD_CMPT_DIV_CD FROM THFMH_TCTPYEXDSR
                       WHERE \$CONDITIONS "\
    --m 8 \
    --boundary-query "SELECT 0, 7 FROM DUAL"\
    --split-by "ORA_HASH(COVTP_PREM_DIS_ID, 7)"\
    --target-dir /tmp2/LAST_THFMH_TCTPYEXDSR \
    --hive-import \
    --external-table-dir hdfs:///tmp2/temp_tbl/LAST_THFMH_TCTPYEXDSR \
    --hive-overwrite \
    --hive-table DEFAULT.LAST_THFMH_TCTPYEXDSR  >> ${SHLOG_DIR}/THFMH_TCTPYEXDSR.shlog 2>&1 &&

#----------------------------------------------------#
# Hadoop 원본테이블에 변경분 최종 적용
#----------------------------------------------------#
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THFMH_TCTPYEXDSR_TMP ; " >> ${SHLOG_DIR}/THFMH_TCTPYEXDSR.shlog 2>&1 &&
    /usr/bin/hive -e "CREATE EXTERNAL TABLE MERITZ.THFMH_TCTPYEXDSR_TMP STORED AS PARQUET TBLPROPERTIES ('PARQUET.COMPRESS'='SNAPPY') AS
                                SELECT *
                                FROM DEFAULT.LAST_THFMH_TCTPYEXDSR ;" >> ${SHLOG_DIR}/THFMH_TCTPYEXDSR.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.LAST_THFMH_TCTPYEXDSR ;" >> ${SHLOG_DIR}/THFMH_TCTPYEXDSR.shlog 2>&1 &&
    /usr/bin/hdfs dfs -rm -r -f -skipTrash /tmp2/temp_tbl/LAST_THFMH_TCTPYEXDSR >> ${SHLOG_DIR}/THFMH_TCTPYEXDSR.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THFMH_TCTPYEXDSR ;" >> ${SHLOG_DIR}/THFMH_TCTPYEXDSR.shlog 2>&1 &&
    /usr/bin/hive -e "ALTER TABLE MERITZ.THFMH_TCTPYEXDSR_TMP RENAME TO MERITZ.THFMH_TCTPYEXDSR ;" >> ${SHLOG_DIR}/THFMH_TCTPYEXDSR.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THFMH_TCTPYEXDSR_TMP ;" >> ${SHLOG_DIR}/THFMH_TCTPYEXDSR.shlog 2>&1 

if [ $? -ne 0 ]
then             
    echo "*-----------[ THFMH_TCTPYEXDSR.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/THFMH_TCTPYEXDSR.shlog"
    echo "*-----------[ THFMH_TCTPYEXDSR.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/THFMH_TCTPYEXDSR.shlog"  >>  ${SHLOG_DIR}/THFMH_TCTPYEXDSR.shlog
    echo "*-----------[ THFMH_TCTPYEXDSR.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THFMH_TCTPYEXDSR.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/THFMH_TCTPYEXDSR.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/THFMH_TCTPYEXDSR.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/THFMH_TCTPYEXDSR.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/THFMH_TCTPYEXDSR.shlog /sqoopbin/scripts/etlpgm/his_log/THFMH_TCTPYEXDSR_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  THFMH_TCTPYEXDSR.sh cmd command error !! ***
    fi               

    exit -1      

else             
    echo "*-----------[ THFMH_TCTPYEXDSR.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THFMH_TCTPYEXDSR.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/THFMH_TCTPYEXDSR.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/THFMH_TCTPYEXDSR.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/THFMH_TCTPYEXDSR.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/THFMH_TCTPYEXDSR.shlog /sqoopbin/scripts/etlpgm/his_log/THFMH_TCTPYEXDSR_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  THFMH_TCTPYEXDSR.sh cmd command error !! ***
        exit -1      
    else             
        exit 0       
    fi               
fi               
