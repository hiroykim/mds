#!/bin/bash

if [ $# -eq 0 ]
then           
    ARGS=N    
else           
    ARGS=$1
fi             

NOW=$(date +"+%Y-%m-%d_%T")
SHLOG_DIR=/sqoopbin/scripts/etlpgm/cur_log
HISLOG_DIR=/sqoopbin/scripts/etlpgm/his_log

export HADOOP_OPTS=-Djava.security.egd=file:/dev/../dev/urandom
export ORACLE_BASE=/sw/oracle
export ORACLE_HOME=/sw/oracle/product/11.2.0.4/client_1
export LD_LIBRARY_PATH=/sw/oracle/product/11.2.0.4/client_1/lib:/sw/oracle/product/11.2.0.4/client_1/lib:
export PATH=/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/usr/lib64/qt-3.3/bin:/usr/hdp/3.0.0.0-1634/spark2/bin/:/var/opt/node/bin/:/opt/maven/bin:/usr/local/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/home/hdpapp/workspace/data-science-at-the-command-line/tools:/home/hdpapp/.local/bin:/home/hdpapp/bin
export TNS_ADMIN=/sw/oracle/product/11.2.0.4/client_1/network/admin
export ORACLE_SID=DBEDWP2
export NLS_LANG=American_America.KO16MSWIN949

#----------------------------------------------------#
# 작업내용 : THDDH_TCTPCVMPBA 테이블 sqoop 복제 작업
# 작업주기 :  
#----------------------------------------------------#

    echo " "
    echo "*-----------[ THDDH_TCTPCVMPBA.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TCTPCVMPBA.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`  >  ${SHLOG_DIR}/THDDH_TCTPCVMPBA.shlog

#----------------------------------------------------#
# 테이블별 전체 데이터를 받아 오는 부분
#----------------------------------------------------#
    /usr/bin/hadoop fs -rm -r -f  /tmp2/LAST_THDDH_TCTPCVMPBA  >> ${SHLOG_DIR}/THDDH_TCTPCVMPBA.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.LAST_THDDH_TCTPCVMPBA ; " >> ${SHLOG_DIR}/THDDH_TCTPCVMPBA.shlog 2>&1 &&
    /usr/hdp/3.0.0.0-1634/sqoop/bin/sqoop import -D mapred.child.java.opts="-Djava.security.egd=file:/dev/../dev/urandom" \
    --connect jdbc:oracle:thin:EDWHADOOP/wjdqhrP\!23@10.91.41.172:12560:DBEDWP2 \
    --username  EDWHADOOP \
    --password wjdqhrP\!23 \
    --query "SELECT /*+ FULL(THDDH_TCTPCVMPBA) */ REPLACE(REPLACE(CTR_COV_ID,CHR(13),''),CHR(10),'') CTR_COV_ID
, REPLACE(REPLACE(PRCTR_NO,CHR(13),''),CHR(10),'') PRCTR_NO
, SBCP_DT
, REPLACE(REPLACE(UNT_PD_CD,CHR(13),''),CHR(10),'') UNT_PD_CD
, REPLACE(REPLACE(COV_CD,CHR(13),''),CHR(10),'') COV_CD
, REPLACE(REPLACE(CLF_DIV_CD,CHR(13),''),CHR(10),'') CLF_DIV_CD
, REPLACE(REPLACE(INS_SBC_SH_CD,CHR(13),''),CHR(10),'') INS_SBC_SH_CD
, REPLACE(REPLACE(TRTPE_ORG_CD,CHR(13),''),CHR(10),'') TRTPE_ORG_CD
, REPLACE(REPLACE(HDQT_ORG_CD,CHR(13),''),CHR(10),'') HDQT_ORG_CD
, REPLACE(REPLACE(BCH_ORG_CD,CHR(13),''),CHR(10),'') BCH_ORG_CD
, REPLACE(REPLACE(CHN_DIV_CD,CHR(13),''),CHR(10),'') CHN_DIV_CD
, REPLACE(REPLACE(FEE_PAY_TP_CD,CHR(13),''),CHR(10),'') FEE_PAY_TP_CD
, REPLACE(REPLACE(OWN_CTR_YN,CHR(13),''),CHR(10),'') OWN_CTR_YN
, REPLACE(REPLACE(JOB_GRD_CD,CHR(13),''),CHR(10),'') JOB_GRD_CD
, REPLACE(REPLACE(MNCL_MD_CD,CHR(13),''),CHR(10),'') MNCL_MD_CD
, REPLACE(REPLACE(BAS_SIC_DIV_CD,CHR(13),''),CHR(10),'') BAS_SIC_DIV_CD
, INS_AGE
, COV_FRS_SBC_AGE
, REPLACE(REPLACE(GNDR_CD,CHR(13),''),CHR(10),'') GNDR_CD
, REPLACE(REPLACE(COV_INS_PRD_TP_CD,CHR(13),''),CHR(10),'') COV_INS_PRD_TP_CD
, COV_INS_PRD
, REPLACE(REPLACE(COV_PY_PRD_TP_CD,CHR(13),''),CHR(10),'') COV_PY_PRD_TP_CD
, COV_PY_PRD
, BAS_PREM
, SLZ_PREM
, YYPY_CNVS_BAS_PREM
, YYPY_CNVS_SLZ_PREM
, REPLACE(REPLACE(PY_CYC_CD,CHR(13),''),CHR(10),'') PY_CYC_CD
, INSD_AMT
, STD_SBC_AMT
, COV_INS_BGN_DT
, REPLACE(REPLACE(RKEY_CNFG_CHT_VAL,CHR(13),''),CHR(10),'') RKEY_CNFG_CHT_VAL
, REPLACE(REPLACE(RDY_AMT_TRM_VAL1,CHR(13),''),CHR(10),'') RDY_AMT_TRM_VAL1
, REPLACE(REPLACE(RDY_AMT_TRM_VAL2,CHR(13),''),CHR(10),'') RDY_AMT_TRM_VAL2
, REPLACE(REPLACE(RDY_AMT_TRM_VAL3,CHR(13),''),CHR(10),'') RDY_AMT_TRM_VAL3
, REPLACE(REPLACE(RDY_AMT_TRM_VAL4,CHR(13),''),CHR(10),'') RDY_AMT_TRM_VAL4
, REPLACE(REPLACE(RDY_AMT_TRM_VAL5,CHR(13),''),CHR(10),'') RDY_AMT_TRM_VAL5
, REPLACE(REPLACE(RDY_AMT_TRM_VAL6,CHR(13),''),CHR(10),'') RDY_AMT_TRM_VAL6
, REPLACE(REPLACE(RDY_AMT_TRM_VAL7,CHR(13),''),CHR(10),'') RDY_AMT_TRM_VAL7
, REPLACE(REPLACE(RDY_AMT_TRM_VAL8,CHR(13),''),CHR(10),'') RDY_AMT_TRM_VAL8
, REPLACE(REPLACE(RDY_AMT_TRM_VAL9,CHR(13),''),CHR(10),'') RDY_AMT_TRM_VAL9
, REPLACE(REPLACE(RDY_AMT_TRM_VAL10,CHR(13),''),CHR(10),'') RDY_AMT_TRM_VAL10
, REPLACE(REPLACE(RDY_AMT_TRM_VAL11,CHR(13),''),CHR(10),'') RDY_AMT_TRM_VAL11
, REPLACE(REPLACE(RDY_AMT_TRM_VAL12,CHR(13),''),CHR(10),'') RDY_AMT_TRM_VAL12
, REPLACE(REPLACE(RDY_AMT_TRM_VAL13,CHR(13),''),CHR(10),'') RDY_AMT_TRM_VAL13
, REPLACE(REPLACE(RDY_AMT_TRM_VAL14,CHR(13),''),CHR(10),'') RDY_AMT_TRM_VAL14
, REPLACE(REPLACE(RDY_AMT_TRM_VAL15,CHR(13),''),CHR(10),'') RDY_AMT_TRM_VAL15
, REPLACE(REPLACE(DIVD_YN,CHR(13),''),CHR(10),'') DIVD_YN
, REPLACE(REPLACE(ANN_PAY_CYC_CD,CHR(13),''),CHR(10),'') ANN_PAY_CYC_CD
, REPLACE(REPLACE(ANN_PAY_PRD_CD,CHR(13),''),CHR(10),'') ANN_PAY_PRD_CD
, REPLACE(REPLACE(ANN_PAY_SH_CD,CHR(13),''),CHR(10),'') ANN_PAY_SH_CD
, ANN_PAY_ST_AGE
, REPLACE(REPLACE(GURT_ACU_DIV_CD,CHR(13),''),CHR(10),'') GURT_ACU_DIV_CD
, REPLACE(REPLACE(NEGA_GRP_CD,CHR(13),''),CHR(10),'') NEGA_GRP_CD
, REPLACE(REPLACE(COV_SMT_CTG_CD,CHR(13),''),CHR(10),'') COV_SMT_CTG_CD
, XCHG_INDX
, DC_XCHG_CF
, REPLACE(REPLACE(RNWL_COV_CYC_CD,CHR(13),''),CHR(10),'') RNWL_COV_CYC_CD
, RNWL_ED_AGE
, RNWL_ED_DT
, REPLACE(REPLACE(RNWL_ED_PRD_DIV_CD,CHR(13),''),CHR(10),'') RNWL_ED_PRD_DIV_CD
, RNWL_ED_PRD
, REPLACE(REPLACE(POLHD_CONV_SIC_SBC_YN,CHR(13),''),CHR(10),'') POLHD_CONV_SIC_SBC_YN
, REPLACE(REPLACE(PLAN_CD,CHR(13),''),CHR(10),'') PLAN_CD
, INS_BGN_DT
, REPLACE(REPLACE(SBCP_CHN_DIV_CD,CHR(13),''),CHR(10),'') SBCP_CHN_DIV_CD
, INS_PRD
, PY_PRD
, REPLACE(REPLACE(SETL_PD_DIV_CD,CHR(13),''),CHR(10),'') SETL_PD_DIV_CD
, TRNS_DTM
, REPLACE(REPLACE(INPPE_ORG_ID,CHR(13),''),CHR(10),'') INPPE_ORG_ID
, SYS_OCC_DTM
, REPLACE(REPLACE(SYS_DEL_DIV_CD,CHR(13),''),CHR(10),'') SYS_DEL_DIV_CD
, REPLACE(REPLACE(OCC_IP,CHR(13),''),CHR(10),'') OCC_IP
, REPLACE(REPLACE(APP_ID,CHR(13),''),CHR(10),'') APP_ID
, DATA_CHNG_DTM
, REPLACE(REPLACE(DMG_RT_COV_DCTG_CD,CHR(13),''),CHR(10),'') DMG_RT_COV_DCTG_CD
, REPLACE(REPLACE(CTR_OBJ_ID,CHR(13),''),CHR(10),'') CTR_OBJ_ID
, REPLACE(REPLACE(XCHG_YN,CHR(13),''),CHR(10),'') XCHG_YN
, REPLACE(REPLACE(NOCV_YN,CHR(13),''),CHR(10),'') NOCV_YN
, REPLACE(REPLACE(INSPE_GRDE_VAL,CHR(13),''),CHR(10),'') INSPE_GRDE_VAL
, EIH_LDG_DTM
, REPLACE(REPLACE(MOM_COV_CD,CHR(13),''),CHR(10),'') MOM_COV_CD
, REPLACE(REPLACE(ACCM_COV_CD,CHR(13),''),CHR(10),'') ACCM_COV_CD
, REPLACE(REPLACE(BTH_AF_COV_CD,CHR(13),''),CHR(10),'') BTH_AF_COV_CD
, COV_SBC_AMT
, ACCM_SBC_AMT FROM THDDH_TCTPCVMPBA
                       WHERE \$CONDITIONS "\
    --m 8 \
    --boundary-query "SELECT 0, 7 FROM DUAL"\
    --split-by "ORA_HASH(CTR_COV_ID, 7)"\
    --target-dir /tmp2/LAST_THDDH_TCTPCVMPBA \
    --hive-import \
    --external-table-dir hdfs:///tmp2/temp_tbl/LAST_THDDH_TCTPCVMPBA \
    --hive-overwrite \
    --hive-table DEFAULT.LAST_THDDH_TCTPCVMPBA  >> ${SHLOG_DIR}/THDDH_TCTPCVMPBA.shlog 2>&1 &&

#----------------------------------------------------#
# Hadoop 원본테이블에 변경분 최종 적용
#----------------------------------------------------#
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TCTPCVMPBA_TMP ; " >> ${SHLOG_DIR}/THDDH_TCTPCVMPBA.shlog 2>&1 &&
    /usr/bin/hive -e "CREATE EXTERNAL TABLE MERITZ.THDDH_TCTPCVMPBA_TMP STORED AS PARQUET TBLPROPERTIES ('PARQUET.COMPRESS'='SNAPPY') AS
                                SELECT *
                                FROM DEFAULT.LAST_THDDH_TCTPCVMPBA ;" >> ${SHLOG_DIR}/THDDH_TCTPCVMPBA.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.LAST_THDDH_TCTPCVMPBA ;" >> ${SHLOG_DIR}/THDDH_TCTPCVMPBA.shlog 2>&1 &&
    /usr/bin/hdfs dfs -rm -r -f -skipTrash /tmp2/temp_tbl/LAST_THDDH_TCTPCVMPBA >> ${SHLOG_DIR}/THDDH_TCTPCVMPBA.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TCTPCVMPBA ;" >> ${SHLOG_DIR}/THDDH_TCTPCVMPBA.shlog 2>&1 &&
    /usr/bin/hive -e "ALTER TABLE MERITZ.THDDH_TCTPCVMPBA_TMP RENAME TO MERITZ.THDDH_TCTPCVMPBA ;" >> ${SHLOG_DIR}/THDDH_TCTPCVMPBA.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TCTPCVMPBA_TMP ;" >> ${SHLOG_DIR}/THDDH_TCTPCVMPBA.shlog 2>&1 

if [ $? -ne 0 ]
then             
    echo "*-----------[ THDDH_TCTPCVMPBA.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/THDDH_TCTPCVMPBA.shlog"
    echo "*-----------[ THDDH_TCTPCVMPBA.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/THDDH_TCTPCVMPBA.shlog"  >>  ${SHLOG_DIR}/THDDH_TCTPCVMPBA.shlog
    echo "*-----------[ THDDH_TCTPCVMPBA.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TCTPCVMPBA.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/THDDH_TCTPCVMPBA.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/THDDH_TCTPCVMPBA.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCTPCVMPBA.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCTPCVMPBA.shlog /sqoopbin/scripts/etlpgm/his_log/THDDH_TCTPCVMPBA_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  THDDH_TCTPCVMPBA.sh cmd command error !! ***
    fi               

    exit -1      

else             
    echo "*-----------[ THDDH_TCTPCVMPBA.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TCTPCVMPBA.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/THDDH_TCTPCVMPBA.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/THDDH_TCTPCVMPBA.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCTPCVMPBA.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCTPCVMPBA.shlog /sqoopbin/scripts/etlpgm/his_log/THDDH_TCTPCVMPBA_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  THDDH_TCTPCVMPBA.sh cmd command error !! ***
        exit -1      
    else             
        exit 0       
    fi               
fi               
