// ORM class for table 'null'
// WARNING: This class is AUTO-GENERATED. Modify at your own risk.
//
// Debug information:
// Generated date: Wed Aug 25 00:12:44 GMT 2021
// For connector: org.apache.sqoop.manager.OracleManager
import org.apache.hadoop.io.BytesWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.mapred.lib.db.DBWritable;
import org.apache.sqoop.lib.JdbcWritableBridge;
import org.apache.sqoop.lib.DelimiterSet;
import org.apache.sqoop.lib.FieldFormatter;
import org.apache.sqoop.lib.RecordParser;
import org.apache.sqoop.lib.BooleanParser;
import org.apache.sqoop.lib.BlobRef;
import org.apache.sqoop.lib.ClobRef;
import org.apache.sqoop.lib.LargeObjectLoader;
import org.apache.sqoop.lib.SqoopRecord;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.sql.Date;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

public class QueryResult extends SqoopRecord  implements DBWritable, Writable {
  private final int PROTOCOL_VERSION = 3;
  public int getClassFormatVersion() { return PROTOCOL_VERSION; }
  public static interface FieldSetterCommand {    void setField(Object value);  }  protected ResultSet __cur_result_set;
  private Map<String, FieldSetterCommand> setters = new HashMap<String, FieldSetterCommand>();
  private void init0() {
    setters.put("CTR_COV_ID", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.CTR_COV_ID = (String)value;
      }
    });
    setters.put("PRCTR_NO", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.PRCTR_NO = (String)value;
      }
    });
    setters.put("SBCP_DT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.SBCP_DT = (java.sql.Timestamp)value;
      }
    });
    setters.put("UNT_PD_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.UNT_PD_CD = (String)value;
      }
    });
    setters.put("COV_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.COV_CD = (String)value;
      }
    });
    setters.put("CLF_DIV_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.CLF_DIV_CD = (String)value;
      }
    });
    setters.put("INS_SBC_SH_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.INS_SBC_SH_CD = (String)value;
      }
    });
    setters.put("TRTPE_ORG_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.TRTPE_ORG_CD = (String)value;
      }
    });
    setters.put("HDQT_ORG_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.HDQT_ORG_CD = (String)value;
      }
    });
    setters.put("BCH_ORG_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.BCH_ORG_CD = (String)value;
      }
    });
    setters.put("CHN_DIV_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.CHN_DIV_CD = (String)value;
      }
    });
    setters.put("FEE_PAY_TP_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.FEE_PAY_TP_CD = (String)value;
      }
    });
    setters.put("OWN_CTR_YN", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.OWN_CTR_YN = (String)value;
      }
    });
    setters.put("JOB_GRD_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.JOB_GRD_CD = (String)value;
      }
    });
    setters.put("MNCL_MD_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.MNCL_MD_CD = (String)value;
      }
    });
    setters.put("BAS_SIC_DIV_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.BAS_SIC_DIV_CD = (String)value;
      }
    });
    setters.put("INS_AGE", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.INS_AGE = (java.math.BigDecimal)value;
      }
    });
    setters.put("COV_FRS_SBC_AGE", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.COV_FRS_SBC_AGE = (java.math.BigDecimal)value;
      }
    });
    setters.put("GNDR_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.GNDR_CD = (String)value;
      }
    });
    setters.put("COV_INS_PRD_TP_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.COV_INS_PRD_TP_CD = (String)value;
      }
    });
    setters.put("COV_INS_PRD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.COV_INS_PRD = (java.math.BigDecimal)value;
      }
    });
    setters.put("COV_PY_PRD_TP_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.COV_PY_PRD_TP_CD = (String)value;
      }
    });
    setters.put("COV_PY_PRD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.COV_PY_PRD = (java.math.BigDecimal)value;
      }
    });
    setters.put("BAS_PREM", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.BAS_PREM = (java.math.BigDecimal)value;
      }
    });
    setters.put("SLZ_PREM", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.SLZ_PREM = (java.math.BigDecimal)value;
      }
    });
    setters.put("YYPY_CNVS_BAS_PREM", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.YYPY_CNVS_BAS_PREM = (java.math.BigDecimal)value;
      }
    });
    setters.put("YYPY_CNVS_SLZ_PREM", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.YYPY_CNVS_SLZ_PREM = (java.math.BigDecimal)value;
      }
    });
    setters.put("PY_CYC_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.PY_CYC_CD = (String)value;
      }
    });
    setters.put("INSD_AMT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.INSD_AMT = (java.math.BigDecimal)value;
      }
    });
    setters.put("STD_SBC_AMT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.STD_SBC_AMT = (java.math.BigDecimal)value;
      }
    });
    setters.put("COV_INS_BGN_DT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.COV_INS_BGN_DT = (java.sql.Timestamp)value;
      }
    });
    setters.put("RKEY_CNFG_CHT_VAL", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.RKEY_CNFG_CHT_VAL = (String)value;
      }
    });
    setters.put("RDY_AMT_TRM_VAL1", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.RDY_AMT_TRM_VAL1 = (String)value;
      }
    });
    setters.put("RDY_AMT_TRM_VAL2", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.RDY_AMT_TRM_VAL2 = (String)value;
      }
    });
    setters.put("RDY_AMT_TRM_VAL3", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.RDY_AMT_TRM_VAL3 = (String)value;
      }
    });
    setters.put("RDY_AMT_TRM_VAL4", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.RDY_AMT_TRM_VAL4 = (String)value;
      }
    });
    setters.put("RDY_AMT_TRM_VAL5", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.RDY_AMT_TRM_VAL5 = (String)value;
      }
    });
    setters.put("RDY_AMT_TRM_VAL6", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.RDY_AMT_TRM_VAL6 = (String)value;
      }
    });
    setters.put("RDY_AMT_TRM_VAL7", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.RDY_AMT_TRM_VAL7 = (String)value;
      }
    });
    setters.put("RDY_AMT_TRM_VAL8", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.RDY_AMT_TRM_VAL8 = (String)value;
      }
    });
    setters.put("RDY_AMT_TRM_VAL9", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.RDY_AMT_TRM_VAL9 = (String)value;
      }
    });
    setters.put("RDY_AMT_TRM_VAL10", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.RDY_AMT_TRM_VAL10 = (String)value;
      }
    });
    setters.put("RDY_AMT_TRM_VAL11", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.RDY_AMT_TRM_VAL11 = (String)value;
      }
    });
    setters.put("RDY_AMT_TRM_VAL12", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.RDY_AMT_TRM_VAL12 = (String)value;
      }
    });
    setters.put("RDY_AMT_TRM_VAL13", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.RDY_AMT_TRM_VAL13 = (String)value;
      }
    });
    setters.put("RDY_AMT_TRM_VAL14", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.RDY_AMT_TRM_VAL14 = (String)value;
      }
    });
    setters.put("RDY_AMT_TRM_VAL15", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.RDY_AMT_TRM_VAL15 = (String)value;
      }
    });
    setters.put("DIVD_YN", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.DIVD_YN = (String)value;
      }
    });
    setters.put("ANN_PAY_CYC_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.ANN_PAY_CYC_CD = (String)value;
      }
    });
    setters.put("ANN_PAY_PRD_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.ANN_PAY_PRD_CD = (String)value;
      }
    });
    setters.put("ANN_PAY_SH_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.ANN_PAY_SH_CD = (String)value;
      }
    });
    setters.put("ANN_PAY_ST_AGE", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.ANN_PAY_ST_AGE = (java.math.BigDecimal)value;
      }
    });
    setters.put("GURT_ACU_DIV_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.GURT_ACU_DIV_CD = (String)value;
      }
    });
    setters.put("NEGA_GRP_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.NEGA_GRP_CD = (String)value;
      }
    });
    setters.put("COV_SMT_CTG_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.COV_SMT_CTG_CD = (String)value;
      }
    });
    setters.put("XCHG_INDX", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.XCHG_INDX = (java.math.BigDecimal)value;
      }
    });
    setters.put("DC_XCHG_CF", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.DC_XCHG_CF = (java.math.BigDecimal)value;
      }
    });
    setters.put("RNWL_COV_CYC_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.RNWL_COV_CYC_CD = (String)value;
      }
    });
    setters.put("RNWL_ED_AGE", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.RNWL_ED_AGE = (java.math.BigDecimal)value;
      }
    });
    setters.put("RNWL_ED_DT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.RNWL_ED_DT = (java.sql.Timestamp)value;
      }
    });
    setters.put("RNWL_ED_PRD_DIV_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.RNWL_ED_PRD_DIV_CD = (String)value;
      }
    });
    setters.put("RNWL_ED_PRD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.RNWL_ED_PRD = (java.math.BigDecimal)value;
      }
    });
    setters.put("POLHD_CONV_SIC_SBC_YN", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.POLHD_CONV_SIC_SBC_YN = (String)value;
      }
    });
    setters.put("PLAN_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.PLAN_CD = (String)value;
      }
    });
    setters.put("INS_BGN_DT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.INS_BGN_DT = (java.sql.Timestamp)value;
      }
    });
    setters.put("SBCP_CHN_DIV_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.SBCP_CHN_DIV_CD = (String)value;
      }
    });
    setters.put("INS_PRD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.INS_PRD = (java.math.BigDecimal)value;
      }
    });
    setters.put("PY_PRD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.PY_PRD = (java.math.BigDecimal)value;
      }
    });
    setters.put("SETL_PD_DIV_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.SETL_PD_DIV_CD = (String)value;
      }
    });
    setters.put("TRNS_DTM", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.TRNS_DTM = (java.sql.Timestamp)value;
      }
    });
    setters.put("INPPE_ORG_ID", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.INPPE_ORG_ID = (String)value;
      }
    });
    setters.put("SYS_OCC_DTM", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.SYS_OCC_DTM = (java.sql.Timestamp)value;
      }
    });
    setters.put("SYS_DEL_DIV_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.SYS_DEL_DIV_CD = (String)value;
      }
    });
    setters.put("OCC_IP", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.OCC_IP = (String)value;
      }
    });
    setters.put("APP_ID", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.APP_ID = (String)value;
      }
    });
    setters.put("DATA_CHNG_DTM", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.DATA_CHNG_DTM = (java.sql.Timestamp)value;
      }
    });
    setters.put("DMG_RT_COV_DCTG_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.DMG_RT_COV_DCTG_CD = (String)value;
      }
    });
    setters.put("CTR_OBJ_ID", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.CTR_OBJ_ID = (String)value;
      }
    });
    setters.put("XCHG_YN", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.XCHG_YN = (String)value;
      }
    });
    setters.put("NOCV_YN", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.NOCV_YN = (String)value;
      }
    });
    setters.put("INSPE_GRDE_VAL", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.INSPE_GRDE_VAL = (String)value;
      }
    });
    setters.put("EIH_LDG_DTM", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.EIH_LDG_DTM = (java.sql.Timestamp)value;
      }
    });
    setters.put("MOM_COV_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.MOM_COV_CD = (String)value;
      }
    });
    setters.put("ACCM_COV_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.ACCM_COV_CD = (String)value;
      }
    });
    setters.put("BTH_AF_COV_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.BTH_AF_COV_CD = (String)value;
      }
    });
    setters.put("COV_SBC_AMT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.COV_SBC_AMT = (java.math.BigDecimal)value;
      }
    });
    setters.put("ACCM_SBC_AMT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.ACCM_SBC_AMT = (java.math.BigDecimal)value;
      }
    });
  }
  public QueryResult() {
    init0();
  }
  private String CTR_COV_ID;
  public String get_CTR_COV_ID() {
    return CTR_COV_ID;
  }
  public void set_CTR_COV_ID(String CTR_COV_ID) {
    this.CTR_COV_ID = CTR_COV_ID;
  }
  public QueryResult with_CTR_COV_ID(String CTR_COV_ID) {
    this.CTR_COV_ID = CTR_COV_ID;
    return this;
  }
  private String PRCTR_NO;
  public String get_PRCTR_NO() {
    return PRCTR_NO;
  }
  public void set_PRCTR_NO(String PRCTR_NO) {
    this.PRCTR_NO = PRCTR_NO;
  }
  public QueryResult with_PRCTR_NO(String PRCTR_NO) {
    this.PRCTR_NO = PRCTR_NO;
    return this;
  }
  private java.sql.Timestamp SBCP_DT;
  public java.sql.Timestamp get_SBCP_DT() {
    return SBCP_DT;
  }
  public void set_SBCP_DT(java.sql.Timestamp SBCP_DT) {
    this.SBCP_DT = SBCP_DT;
  }
  public QueryResult with_SBCP_DT(java.sql.Timestamp SBCP_DT) {
    this.SBCP_DT = SBCP_DT;
    return this;
  }
  private String UNT_PD_CD;
  public String get_UNT_PD_CD() {
    return UNT_PD_CD;
  }
  public void set_UNT_PD_CD(String UNT_PD_CD) {
    this.UNT_PD_CD = UNT_PD_CD;
  }
  public QueryResult with_UNT_PD_CD(String UNT_PD_CD) {
    this.UNT_PD_CD = UNT_PD_CD;
    return this;
  }
  private String COV_CD;
  public String get_COV_CD() {
    return COV_CD;
  }
  public void set_COV_CD(String COV_CD) {
    this.COV_CD = COV_CD;
  }
  public QueryResult with_COV_CD(String COV_CD) {
    this.COV_CD = COV_CD;
    return this;
  }
  private String CLF_DIV_CD;
  public String get_CLF_DIV_CD() {
    return CLF_DIV_CD;
  }
  public void set_CLF_DIV_CD(String CLF_DIV_CD) {
    this.CLF_DIV_CD = CLF_DIV_CD;
  }
  public QueryResult with_CLF_DIV_CD(String CLF_DIV_CD) {
    this.CLF_DIV_CD = CLF_DIV_CD;
    return this;
  }
  private String INS_SBC_SH_CD;
  public String get_INS_SBC_SH_CD() {
    return INS_SBC_SH_CD;
  }
  public void set_INS_SBC_SH_CD(String INS_SBC_SH_CD) {
    this.INS_SBC_SH_CD = INS_SBC_SH_CD;
  }
  public QueryResult with_INS_SBC_SH_CD(String INS_SBC_SH_CD) {
    this.INS_SBC_SH_CD = INS_SBC_SH_CD;
    return this;
  }
  private String TRTPE_ORG_CD;
  public String get_TRTPE_ORG_CD() {
    return TRTPE_ORG_CD;
  }
  public void set_TRTPE_ORG_CD(String TRTPE_ORG_CD) {
    this.TRTPE_ORG_CD = TRTPE_ORG_CD;
  }
  public QueryResult with_TRTPE_ORG_CD(String TRTPE_ORG_CD) {
    this.TRTPE_ORG_CD = TRTPE_ORG_CD;
    return this;
  }
  private String HDQT_ORG_CD;
  public String get_HDQT_ORG_CD() {
    return HDQT_ORG_CD;
  }
  public void set_HDQT_ORG_CD(String HDQT_ORG_CD) {
    this.HDQT_ORG_CD = HDQT_ORG_CD;
  }
  public QueryResult with_HDQT_ORG_CD(String HDQT_ORG_CD) {
    this.HDQT_ORG_CD = HDQT_ORG_CD;
    return this;
  }
  private String BCH_ORG_CD;
  public String get_BCH_ORG_CD() {
    return BCH_ORG_CD;
  }
  public void set_BCH_ORG_CD(String BCH_ORG_CD) {
    this.BCH_ORG_CD = BCH_ORG_CD;
  }
  public QueryResult with_BCH_ORG_CD(String BCH_ORG_CD) {
    this.BCH_ORG_CD = BCH_ORG_CD;
    return this;
  }
  private String CHN_DIV_CD;
  public String get_CHN_DIV_CD() {
    return CHN_DIV_CD;
  }
  public void set_CHN_DIV_CD(String CHN_DIV_CD) {
    this.CHN_DIV_CD = CHN_DIV_CD;
  }
  public QueryResult with_CHN_DIV_CD(String CHN_DIV_CD) {
    this.CHN_DIV_CD = CHN_DIV_CD;
    return this;
  }
  private String FEE_PAY_TP_CD;
  public String get_FEE_PAY_TP_CD() {
    return FEE_PAY_TP_CD;
  }
  public void set_FEE_PAY_TP_CD(String FEE_PAY_TP_CD) {
    this.FEE_PAY_TP_CD = FEE_PAY_TP_CD;
  }
  public QueryResult with_FEE_PAY_TP_CD(String FEE_PAY_TP_CD) {
    this.FEE_PAY_TP_CD = FEE_PAY_TP_CD;
    return this;
  }
  private String OWN_CTR_YN;
  public String get_OWN_CTR_YN() {
    return OWN_CTR_YN;
  }
  public void set_OWN_CTR_YN(String OWN_CTR_YN) {
    this.OWN_CTR_YN = OWN_CTR_YN;
  }
  public QueryResult with_OWN_CTR_YN(String OWN_CTR_YN) {
    this.OWN_CTR_YN = OWN_CTR_YN;
    return this;
  }
  private String JOB_GRD_CD;
  public String get_JOB_GRD_CD() {
    return JOB_GRD_CD;
  }
  public void set_JOB_GRD_CD(String JOB_GRD_CD) {
    this.JOB_GRD_CD = JOB_GRD_CD;
  }
  public QueryResult with_JOB_GRD_CD(String JOB_GRD_CD) {
    this.JOB_GRD_CD = JOB_GRD_CD;
    return this;
  }
  private String MNCL_MD_CD;
  public String get_MNCL_MD_CD() {
    return MNCL_MD_CD;
  }
  public void set_MNCL_MD_CD(String MNCL_MD_CD) {
    this.MNCL_MD_CD = MNCL_MD_CD;
  }
  public QueryResult with_MNCL_MD_CD(String MNCL_MD_CD) {
    this.MNCL_MD_CD = MNCL_MD_CD;
    return this;
  }
  private String BAS_SIC_DIV_CD;
  public String get_BAS_SIC_DIV_CD() {
    return BAS_SIC_DIV_CD;
  }
  public void set_BAS_SIC_DIV_CD(String BAS_SIC_DIV_CD) {
    this.BAS_SIC_DIV_CD = BAS_SIC_DIV_CD;
  }
  public QueryResult with_BAS_SIC_DIV_CD(String BAS_SIC_DIV_CD) {
    this.BAS_SIC_DIV_CD = BAS_SIC_DIV_CD;
    return this;
  }
  private java.math.BigDecimal INS_AGE;
  public java.math.BigDecimal get_INS_AGE() {
    return INS_AGE;
  }
  public void set_INS_AGE(java.math.BigDecimal INS_AGE) {
    this.INS_AGE = INS_AGE;
  }
  public QueryResult with_INS_AGE(java.math.BigDecimal INS_AGE) {
    this.INS_AGE = INS_AGE;
    return this;
  }
  private java.math.BigDecimal COV_FRS_SBC_AGE;
  public java.math.BigDecimal get_COV_FRS_SBC_AGE() {
    return COV_FRS_SBC_AGE;
  }
  public void set_COV_FRS_SBC_AGE(java.math.BigDecimal COV_FRS_SBC_AGE) {
    this.COV_FRS_SBC_AGE = COV_FRS_SBC_AGE;
  }
  public QueryResult with_COV_FRS_SBC_AGE(java.math.BigDecimal COV_FRS_SBC_AGE) {
    this.COV_FRS_SBC_AGE = COV_FRS_SBC_AGE;
    return this;
  }
  private String GNDR_CD;
  public String get_GNDR_CD() {
    return GNDR_CD;
  }
  public void set_GNDR_CD(String GNDR_CD) {
    this.GNDR_CD = GNDR_CD;
  }
  public QueryResult with_GNDR_CD(String GNDR_CD) {
    this.GNDR_CD = GNDR_CD;
    return this;
  }
  private String COV_INS_PRD_TP_CD;
  public String get_COV_INS_PRD_TP_CD() {
    return COV_INS_PRD_TP_CD;
  }
  public void set_COV_INS_PRD_TP_CD(String COV_INS_PRD_TP_CD) {
    this.COV_INS_PRD_TP_CD = COV_INS_PRD_TP_CD;
  }
  public QueryResult with_COV_INS_PRD_TP_CD(String COV_INS_PRD_TP_CD) {
    this.COV_INS_PRD_TP_CD = COV_INS_PRD_TP_CD;
    return this;
  }
  private java.math.BigDecimal COV_INS_PRD;
  public java.math.BigDecimal get_COV_INS_PRD() {
    return COV_INS_PRD;
  }
  public void set_COV_INS_PRD(java.math.BigDecimal COV_INS_PRD) {
    this.COV_INS_PRD = COV_INS_PRD;
  }
  public QueryResult with_COV_INS_PRD(java.math.BigDecimal COV_INS_PRD) {
    this.COV_INS_PRD = COV_INS_PRD;
    return this;
  }
  private String COV_PY_PRD_TP_CD;
  public String get_COV_PY_PRD_TP_CD() {
    return COV_PY_PRD_TP_CD;
  }
  public void set_COV_PY_PRD_TP_CD(String COV_PY_PRD_TP_CD) {
    this.COV_PY_PRD_TP_CD = COV_PY_PRD_TP_CD;
  }
  public QueryResult with_COV_PY_PRD_TP_CD(String COV_PY_PRD_TP_CD) {
    this.COV_PY_PRD_TP_CD = COV_PY_PRD_TP_CD;
    return this;
  }
  private java.math.BigDecimal COV_PY_PRD;
  public java.math.BigDecimal get_COV_PY_PRD() {
    return COV_PY_PRD;
  }
  public void set_COV_PY_PRD(java.math.BigDecimal COV_PY_PRD) {
    this.COV_PY_PRD = COV_PY_PRD;
  }
  public QueryResult with_COV_PY_PRD(java.math.BigDecimal COV_PY_PRD) {
    this.COV_PY_PRD = COV_PY_PRD;
    return this;
  }
  private java.math.BigDecimal BAS_PREM;
  public java.math.BigDecimal get_BAS_PREM() {
    return BAS_PREM;
  }
  public void set_BAS_PREM(java.math.BigDecimal BAS_PREM) {
    this.BAS_PREM = BAS_PREM;
  }
  public QueryResult with_BAS_PREM(java.math.BigDecimal BAS_PREM) {
    this.BAS_PREM = BAS_PREM;
    return this;
  }
  private java.math.BigDecimal SLZ_PREM;
  public java.math.BigDecimal get_SLZ_PREM() {
    return SLZ_PREM;
  }
  public void set_SLZ_PREM(java.math.BigDecimal SLZ_PREM) {
    this.SLZ_PREM = SLZ_PREM;
  }
  public QueryResult with_SLZ_PREM(java.math.BigDecimal SLZ_PREM) {
    this.SLZ_PREM = SLZ_PREM;
    return this;
  }
  private java.math.BigDecimal YYPY_CNVS_BAS_PREM;
  public java.math.BigDecimal get_YYPY_CNVS_BAS_PREM() {
    return YYPY_CNVS_BAS_PREM;
  }
  public void set_YYPY_CNVS_BAS_PREM(java.math.BigDecimal YYPY_CNVS_BAS_PREM) {
    this.YYPY_CNVS_BAS_PREM = YYPY_CNVS_BAS_PREM;
  }
  public QueryResult with_YYPY_CNVS_BAS_PREM(java.math.BigDecimal YYPY_CNVS_BAS_PREM) {
    this.YYPY_CNVS_BAS_PREM = YYPY_CNVS_BAS_PREM;
    return this;
  }
  private java.math.BigDecimal YYPY_CNVS_SLZ_PREM;
  public java.math.BigDecimal get_YYPY_CNVS_SLZ_PREM() {
    return YYPY_CNVS_SLZ_PREM;
  }
  public void set_YYPY_CNVS_SLZ_PREM(java.math.BigDecimal YYPY_CNVS_SLZ_PREM) {
    this.YYPY_CNVS_SLZ_PREM = YYPY_CNVS_SLZ_PREM;
  }
  public QueryResult with_YYPY_CNVS_SLZ_PREM(java.math.BigDecimal YYPY_CNVS_SLZ_PREM) {
    this.YYPY_CNVS_SLZ_PREM = YYPY_CNVS_SLZ_PREM;
    return this;
  }
  private String PY_CYC_CD;
  public String get_PY_CYC_CD() {
    return PY_CYC_CD;
  }
  public void set_PY_CYC_CD(String PY_CYC_CD) {
    this.PY_CYC_CD = PY_CYC_CD;
  }
  public QueryResult with_PY_CYC_CD(String PY_CYC_CD) {
    this.PY_CYC_CD = PY_CYC_CD;
    return this;
  }
  private java.math.BigDecimal INSD_AMT;
  public java.math.BigDecimal get_INSD_AMT() {
    return INSD_AMT;
  }
  public void set_INSD_AMT(java.math.BigDecimal INSD_AMT) {
    this.INSD_AMT = INSD_AMT;
  }
  public QueryResult with_INSD_AMT(java.math.BigDecimal INSD_AMT) {
    this.INSD_AMT = INSD_AMT;
    return this;
  }
  private java.math.BigDecimal STD_SBC_AMT;
  public java.math.BigDecimal get_STD_SBC_AMT() {
    return STD_SBC_AMT;
  }
  public void set_STD_SBC_AMT(java.math.BigDecimal STD_SBC_AMT) {
    this.STD_SBC_AMT = STD_SBC_AMT;
  }
  public QueryResult with_STD_SBC_AMT(java.math.BigDecimal STD_SBC_AMT) {
    this.STD_SBC_AMT = STD_SBC_AMT;
    return this;
  }
  private java.sql.Timestamp COV_INS_BGN_DT;
  public java.sql.Timestamp get_COV_INS_BGN_DT() {
    return COV_INS_BGN_DT;
  }
  public void set_COV_INS_BGN_DT(java.sql.Timestamp COV_INS_BGN_DT) {
    this.COV_INS_BGN_DT = COV_INS_BGN_DT;
  }
  public QueryResult with_COV_INS_BGN_DT(java.sql.Timestamp COV_INS_BGN_DT) {
    this.COV_INS_BGN_DT = COV_INS_BGN_DT;
    return this;
  }
  private String RKEY_CNFG_CHT_VAL;
  public String get_RKEY_CNFG_CHT_VAL() {
    return RKEY_CNFG_CHT_VAL;
  }
  public void set_RKEY_CNFG_CHT_VAL(String RKEY_CNFG_CHT_VAL) {
    this.RKEY_CNFG_CHT_VAL = RKEY_CNFG_CHT_VAL;
  }
  public QueryResult with_RKEY_CNFG_CHT_VAL(String RKEY_CNFG_CHT_VAL) {
    this.RKEY_CNFG_CHT_VAL = RKEY_CNFG_CHT_VAL;
    return this;
  }
  private String RDY_AMT_TRM_VAL1;
  public String get_RDY_AMT_TRM_VAL1() {
    return RDY_AMT_TRM_VAL1;
  }
  public void set_RDY_AMT_TRM_VAL1(String RDY_AMT_TRM_VAL1) {
    this.RDY_AMT_TRM_VAL1 = RDY_AMT_TRM_VAL1;
  }
  public QueryResult with_RDY_AMT_TRM_VAL1(String RDY_AMT_TRM_VAL1) {
    this.RDY_AMT_TRM_VAL1 = RDY_AMT_TRM_VAL1;
    return this;
  }
  private String RDY_AMT_TRM_VAL2;
  public String get_RDY_AMT_TRM_VAL2() {
    return RDY_AMT_TRM_VAL2;
  }
  public void set_RDY_AMT_TRM_VAL2(String RDY_AMT_TRM_VAL2) {
    this.RDY_AMT_TRM_VAL2 = RDY_AMT_TRM_VAL2;
  }
  public QueryResult with_RDY_AMT_TRM_VAL2(String RDY_AMT_TRM_VAL2) {
    this.RDY_AMT_TRM_VAL2 = RDY_AMT_TRM_VAL2;
    return this;
  }
  private String RDY_AMT_TRM_VAL3;
  public String get_RDY_AMT_TRM_VAL3() {
    return RDY_AMT_TRM_VAL3;
  }
  public void set_RDY_AMT_TRM_VAL3(String RDY_AMT_TRM_VAL3) {
    this.RDY_AMT_TRM_VAL3 = RDY_AMT_TRM_VAL3;
  }
  public QueryResult with_RDY_AMT_TRM_VAL3(String RDY_AMT_TRM_VAL3) {
    this.RDY_AMT_TRM_VAL3 = RDY_AMT_TRM_VAL3;
    return this;
  }
  private String RDY_AMT_TRM_VAL4;
  public String get_RDY_AMT_TRM_VAL4() {
    return RDY_AMT_TRM_VAL4;
  }
  public void set_RDY_AMT_TRM_VAL4(String RDY_AMT_TRM_VAL4) {
    this.RDY_AMT_TRM_VAL4 = RDY_AMT_TRM_VAL4;
  }
  public QueryResult with_RDY_AMT_TRM_VAL4(String RDY_AMT_TRM_VAL4) {
    this.RDY_AMT_TRM_VAL4 = RDY_AMT_TRM_VAL4;
    return this;
  }
  private String RDY_AMT_TRM_VAL5;
  public String get_RDY_AMT_TRM_VAL5() {
    return RDY_AMT_TRM_VAL5;
  }
  public void set_RDY_AMT_TRM_VAL5(String RDY_AMT_TRM_VAL5) {
    this.RDY_AMT_TRM_VAL5 = RDY_AMT_TRM_VAL5;
  }
  public QueryResult with_RDY_AMT_TRM_VAL5(String RDY_AMT_TRM_VAL5) {
    this.RDY_AMT_TRM_VAL5 = RDY_AMT_TRM_VAL5;
    return this;
  }
  private String RDY_AMT_TRM_VAL6;
  public String get_RDY_AMT_TRM_VAL6() {
    return RDY_AMT_TRM_VAL6;
  }
  public void set_RDY_AMT_TRM_VAL6(String RDY_AMT_TRM_VAL6) {
    this.RDY_AMT_TRM_VAL6 = RDY_AMT_TRM_VAL6;
  }
  public QueryResult with_RDY_AMT_TRM_VAL6(String RDY_AMT_TRM_VAL6) {
    this.RDY_AMT_TRM_VAL6 = RDY_AMT_TRM_VAL6;
    return this;
  }
  private String RDY_AMT_TRM_VAL7;
  public String get_RDY_AMT_TRM_VAL7() {
    return RDY_AMT_TRM_VAL7;
  }
  public void set_RDY_AMT_TRM_VAL7(String RDY_AMT_TRM_VAL7) {
    this.RDY_AMT_TRM_VAL7 = RDY_AMT_TRM_VAL7;
  }
  public QueryResult with_RDY_AMT_TRM_VAL7(String RDY_AMT_TRM_VAL7) {
    this.RDY_AMT_TRM_VAL7 = RDY_AMT_TRM_VAL7;
    return this;
  }
  private String RDY_AMT_TRM_VAL8;
  public String get_RDY_AMT_TRM_VAL8() {
    return RDY_AMT_TRM_VAL8;
  }
  public void set_RDY_AMT_TRM_VAL8(String RDY_AMT_TRM_VAL8) {
    this.RDY_AMT_TRM_VAL8 = RDY_AMT_TRM_VAL8;
  }
  public QueryResult with_RDY_AMT_TRM_VAL8(String RDY_AMT_TRM_VAL8) {
    this.RDY_AMT_TRM_VAL8 = RDY_AMT_TRM_VAL8;
    return this;
  }
  private String RDY_AMT_TRM_VAL9;
  public String get_RDY_AMT_TRM_VAL9() {
    return RDY_AMT_TRM_VAL9;
  }
  public void set_RDY_AMT_TRM_VAL9(String RDY_AMT_TRM_VAL9) {
    this.RDY_AMT_TRM_VAL9 = RDY_AMT_TRM_VAL9;
  }
  public QueryResult with_RDY_AMT_TRM_VAL9(String RDY_AMT_TRM_VAL9) {
    this.RDY_AMT_TRM_VAL9 = RDY_AMT_TRM_VAL9;
    return this;
  }
  private String RDY_AMT_TRM_VAL10;
  public String get_RDY_AMT_TRM_VAL10() {
    return RDY_AMT_TRM_VAL10;
  }
  public void set_RDY_AMT_TRM_VAL10(String RDY_AMT_TRM_VAL10) {
    this.RDY_AMT_TRM_VAL10 = RDY_AMT_TRM_VAL10;
  }
  public QueryResult with_RDY_AMT_TRM_VAL10(String RDY_AMT_TRM_VAL10) {
    this.RDY_AMT_TRM_VAL10 = RDY_AMT_TRM_VAL10;
    return this;
  }
  private String RDY_AMT_TRM_VAL11;
  public String get_RDY_AMT_TRM_VAL11() {
    return RDY_AMT_TRM_VAL11;
  }
  public void set_RDY_AMT_TRM_VAL11(String RDY_AMT_TRM_VAL11) {
    this.RDY_AMT_TRM_VAL11 = RDY_AMT_TRM_VAL11;
  }
  public QueryResult with_RDY_AMT_TRM_VAL11(String RDY_AMT_TRM_VAL11) {
    this.RDY_AMT_TRM_VAL11 = RDY_AMT_TRM_VAL11;
    return this;
  }
  private String RDY_AMT_TRM_VAL12;
  public String get_RDY_AMT_TRM_VAL12() {
    return RDY_AMT_TRM_VAL12;
  }
  public void set_RDY_AMT_TRM_VAL12(String RDY_AMT_TRM_VAL12) {
    this.RDY_AMT_TRM_VAL12 = RDY_AMT_TRM_VAL12;
  }
  public QueryResult with_RDY_AMT_TRM_VAL12(String RDY_AMT_TRM_VAL12) {
    this.RDY_AMT_TRM_VAL12 = RDY_AMT_TRM_VAL12;
    return this;
  }
  private String RDY_AMT_TRM_VAL13;
  public String get_RDY_AMT_TRM_VAL13() {
    return RDY_AMT_TRM_VAL13;
  }
  public void set_RDY_AMT_TRM_VAL13(String RDY_AMT_TRM_VAL13) {
    this.RDY_AMT_TRM_VAL13 = RDY_AMT_TRM_VAL13;
  }
  public QueryResult with_RDY_AMT_TRM_VAL13(String RDY_AMT_TRM_VAL13) {
    this.RDY_AMT_TRM_VAL13 = RDY_AMT_TRM_VAL13;
    return this;
  }
  private String RDY_AMT_TRM_VAL14;
  public String get_RDY_AMT_TRM_VAL14() {
    return RDY_AMT_TRM_VAL14;
  }
  public void set_RDY_AMT_TRM_VAL14(String RDY_AMT_TRM_VAL14) {
    this.RDY_AMT_TRM_VAL14 = RDY_AMT_TRM_VAL14;
  }
  public QueryResult with_RDY_AMT_TRM_VAL14(String RDY_AMT_TRM_VAL14) {
    this.RDY_AMT_TRM_VAL14 = RDY_AMT_TRM_VAL14;
    return this;
  }
  private String RDY_AMT_TRM_VAL15;
  public String get_RDY_AMT_TRM_VAL15() {
    return RDY_AMT_TRM_VAL15;
  }
  public void set_RDY_AMT_TRM_VAL15(String RDY_AMT_TRM_VAL15) {
    this.RDY_AMT_TRM_VAL15 = RDY_AMT_TRM_VAL15;
  }
  public QueryResult with_RDY_AMT_TRM_VAL15(String RDY_AMT_TRM_VAL15) {
    this.RDY_AMT_TRM_VAL15 = RDY_AMT_TRM_VAL15;
    return this;
  }
  private String DIVD_YN;
  public String get_DIVD_YN() {
    return DIVD_YN;
  }
  public void set_DIVD_YN(String DIVD_YN) {
    this.DIVD_YN = DIVD_YN;
  }
  public QueryResult with_DIVD_YN(String DIVD_YN) {
    this.DIVD_YN = DIVD_YN;
    return this;
  }
  private String ANN_PAY_CYC_CD;
  public String get_ANN_PAY_CYC_CD() {
    return ANN_PAY_CYC_CD;
  }
  public void set_ANN_PAY_CYC_CD(String ANN_PAY_CYC_CD) {
    this.ANN_PAY_CYC_CD = ANN_PAY_CYC_CD;
  }
  public QueryResult with_ANN_PAY_CYC_CD(String ANN_PAY_CYC_CD) {
    this.ANN_PAY_CYC_CD = ANN_PAY_CYC_CD;
    return this;
  }
  private String ANN_PAY_PRD_CD;
  public String get_ANN_PAY_PRD_CD() {
    return ANN_PAY_PRD_CD;
  }
  public void set_ANN_PAY_PRD_CD(String ANN_PAY_PRD_CD) {
    this.ANN_PAY_PRD_CD = ANN_PAY_PRD_CD;
  }
  public QueryResult with_ANN_PAY_PRD_CD(String ANN_PAY_PRD_CD) {
    this.ANN_PAY_PRD_CD = ANN_PAY_PRD_CD;
    return this;
  }
  private String ANN_PAY_SH_CD;
  public String get_ANN_PAY_SH_CD() {
    return ANN_PAY_SH_CD;
  }
  public void set_ANN_PAY_SH_CD(String ANN_PAY_SH_CD) {
    this.ANN_PAY_SH_CD = ANN_PAY_SH_CD;
  }
  public QueryResult with_ANN_PAY_SH_CD(String ANN_PAY_SH_CD) {
    this.ANN_PAY_SH_CD = ANN_PAY_SH_CD;
    return this;
  }
  private java.math.BigDecimal ANN_PAY_ST_AGE;
  public java.math.BigDecimal get_ANN_PAY_ST_AGE() {
    return ANN_PAY_ST_AGE;
  }
  public void set_ANN_PAY_ST_AGE(java.math.BigDecimal ANN_PAY_ST_AGE) {
    this.ANN_PAY_ST_AGE = ANN_PAY_ST_AGE;
  }
  public QueryResult with_ANN_PAY_ST_AGE(java.math.BigDecimal ANN_PAY_ST_AGE) {
    this.ANN_PAY_ST_AGE = ANN_PAY_ST_AGE;
    return this;
  }
  private String GURT_ACU_DIV_CD;
  public String get_GURT_ACU_DIV_CD() {
    return GURT_ACU_DIV_CD;
  }
  public void set_GURT_ACU_DIV_CD(String GURT_ACU_DIV_CD) {
    this.GURT_ACU_DIV_CD = GURT_ACU_DIV_CD;
  }
  public QueryResult with_GURT_ACU_DIV_CD(String GURT_ACU_DIV_CD) {
    this.GURT_ACU_DIV_CD = GURT_ACU_DIV_CD;
    return this;
  }
  private String NEGA_GRP_CD;
  public String get_NEGA_GRP_CD() {
    return NEGA_GRP_CD;
  }
  public void set_NEGA_GRP_CD(String NEGA_GRP_CD) {
    this.NEGA_GRP_CD = NEGA_GRP_CD;
  }
  public QueryResult with_NEGA_GRP_CD(String NEGA_GRP_CD) {
    this.NEGA_GRP_CD = NEGA_GRP_CD;
    return this;
  }
  private String COV_SMT_CTG_CD;
  public String get_COV_SMT_CTG_CD() {
    return COV_SMT_CTG_CD;
  }
  public void set_COV_SMT_CTG_CD(String COV_SMT_CTG_CD) {
    this.COV_SMT_CTG_CD = COV_SMT_CTG_CD;
  }
  public QueryResult with_COV_SMT_CTG_CD(String COV_SMT_CTG_CD) {
    this.COV_SMT_CTG_CD = COV_SMT_CTG_CD;
    return this;
  }
  private java.math.BigDecimal XCHG_INDX;
  public java.math.BigDecimal get_XCHG_INDX() {
    return XCHG_INDX;
  }
  public void set_XCHG_INDX(java.math.BigDecimal XCHG_INDX) {
    this.XCHG_INDX = XCHG_INDX;
  }
  public QueryResult with_XCHG_INDX(java.math.BigDecimal XCHG_INDX) {
    this.XCHG_INDX = XCHG_INDX;
    return this;
  }
  private java.math.BigDecimal DC_XCHG_CF;
  public java.math.BigDecimal get_DC_XCHG_CF() {
    return DC_XCHG_CF;
  }
  public void set_DC_XCHG_CF(java.math.BigDecimal DC_XCHG_CF) {
    this.DC_XCHG_CF = DC_XCHG_CF;
  }
  public QueryResult with_DC_XCHG_CF(java.math.BigDecimal DC_XCHG_CF) {
    this.DC_XCHG_CF = DC_XCHG_CF;
    return this;
  }
  private String RNWL_COV_CYC_CD;
  public String get_RNWL_COV_CYC_CD() {
    return RNWL_COV_CYC_CD;
  }
  public void set_RNWL_COV_CYC_CD(String RNWL_COV_CYC_CD) {
    this.RNWL_COV_CYC_CD = RNWL_COV_CYC_CD;
  }
  public QueryResult with_RNWL_COV_CYC_CD(String RNWL_COV_CYC_CD) {
    this.RNWL_COV_CYC_CD = RNWL_COV_CYC_CD;
    return this;
  }
  private java.math.BigDecimal RNWL_ED_AGE;
  public java.math.BigDecimal get_RNWL_ED_AGE() {
    return RNWL_ED_AGE;
  }
  public void set_RNWL_ED_AGE(java.math.BigDecimal RNWL_ED_AGE) {
    this.RNWL_ED_AGE = RNWL_ED_AGE;
  }
  public QueryResult with_RNWL_ED_AGE(java.math.BigDecimal RNWL_ED_AGE) {
    this.RNWL_ED_AGE = RNWL_ED_AGE;
    return this;
  }
  private java.sql.Timestamp RNWL_ED_DT;
  public java.sql.Timestamp get_RNWL_ED_DT() {
    return RNWL_ED_DT;
  }
  public void set_RNWL_ED_DT(java.sql.Timestamp RNWL_ED_DT) {
    this.RNWL_ED_DT = RNWL_ED_DT;
  }
  public QueryResult with_RNWL_ED_DT(java.sql.Timestamp RNWL_ED_DT) {
    this.RNWL_ED_DT = RNWL_ED_DT;
    return this;
  }
  private String RNWL_ED_PRD_DIV_CD;
  public String get_RNWL_ED_PRD_DIV_CD() {
    return RNWL_ED_PRD_DIV_CD;
  }
  public void set_RNWL_ED_PRD_DIV_CD(String RNWL_ED_PRD_DIV_CD) {
    this.RNWL_ED_PRD_DIV_CD = RNWL_ED_PRD_DIV_CD;
  }
  public QueryResult with_RNWL_ED_PRD_DIV_CD(String RNWL_ED_PRD_DIV_CD) {
    this.RNWL_ED_PRD_DIV_CD = RNWL_ED_PRD_DIV_CD;
    return this;
  }
  private java.math.BigDecimal RNWL_ED_PRD;
  public java.math.BigDecimal get_RNWL_ED_PRD() {
    return RNWL_ED_PRD;
  }
  public void set_RNWL_ED_PRD(java.math.BigDecimal RNWL_ED_PRD) {
    this.RNWL_ED_PRD = RNWL_ED_PRD;
  }
  public QueryResult with_RNWL_ED_PRD(java.math.BigDecimal RNWL_ED_PRD) {
    this.RNWL_ED_PRD = RNWL_ED_PRD;
    return this;
  }
  private String POLHD_CONV_SIC_SBC_YN;
  public String get_POLHD_CONV_SIC_SBC_YN() {
    return POLHD_CONV_SIC_SBC_YN;
  }
  public void set_POLHD_CONV_SIC_SBC_YN(String POLHD_CONV_SIC_SBC_YN) {
    this.POLHD_CONV_SIC_SBC_YN = POLHD_CONV_SIC_SBC_YN;
  }
  public QueryResult with_POLHD_CONV_SIC_SBC_YN(String POLHD_CONV_SIC_SBC_YN) {
    this.POLHD_CONV_SIC_SBC_YN = POLHD_CONV_SIC_SBC_YN;
    return this;
  }
  private String PLAN_CD;
  public String get_PLAN_CD() {
    return PLAN_CD;
  }
  public void set_PLAN_CD(String PLAN_CD) {
    this.PLAN_CD = PLAN_CD;
  }
  public QueryResult with_PLAN_CD(String PLAN_CD) {
    this.PLAN_CD = PLAN_CD;
    return this;
  }
  private java.sql.Timestamp INS_BGN_DT;
  public java.sql.Timestamp get_INS_BGN_DT() {
    return INS_BGN_DT;
  }
  public void set_INS_BGN_DT(java.sql.Timestamp INS_BGN_DT) {
    this.INS_BGN_DT = INS_BGN_DT;
  }
  public QueryResult with_INS_BGN_DT(java.sql.Timestamp INS_BGN_DT) {
    this.INS_BGN_DT = INS_BGN_DT;
    return this;
  }
  private String SBCP_CHN_DIV_CD;
  public String get_SBCP_CHN_DIV_CD() {
    return SBCP_CHN_DIV_CD;
  }
  public void set_SBCP_CHN_DIV_CD(String SBCP_CHN_DIV_CD) {
    this.SBCP_CHN_DIV_CD = SBCP_CHN_DIV_CD;
  }
  public QueryResult with_SBCP_CHN_DIV_CD(String SBCP_CHN_DIV_CD) {
    this.SBCP_CHN_DIV_CD = SBCP_CHN_DIV_CD;
    return this;
  }
  private java.math.BigDecimal INS_PRD;
  public java.math.BigDecimal get_INS_PRD() {
    return INS_PRD;
  }
  public void set_INS_PRD(java.math.BigDecimal INS_PRD) {
    this.INS_PRD = INS_PRD;
  }
  public QueryResult with_INS_PRD(java.math.BigDecimal INS_PRD) {
    this.INS_PRD = INS_PRD;
    return this;
  }
  private java.math.BigDecimal PY_PRD;
  public java.math.BigDecimal get_PY_PRD() {
    return PY_PRD;
  }
  public void set_PY_PRD(java.math.BigDecimal PY_PRD) {
    this.PY_PRD = PY_PRD;
  }
  public QueryResult with_PY_PRD(java.math.BigDecimal PY_PRD) {
    this.PY_PRD = PY_PRD;
    return this;
  }
  private String SETL_PD_DIV_CD;
  public String get_SETL_PD_DIV_CD() {
    return SETL_PD_DIV_CD;
  }
  public void set_SETL_PD_DIV_CD(String SETL_PD_DIV_CD) {
    this.SETL_PD_DIV_CD = SETL_PD_DIV_CD;
  }
  public QueryResult with_SETL_PD_DIV_CD(String SETL_PD_DIV_CD) {
    this.SETL_PD_DIV_CD = SETL_PD_DIV_CD;
    return this;
  }
  private java.sql.Timestamp TRNS_DTM;
  public java.sql.Timestamp get_TRNS_DTM() {
    return TRNS_DTM;
  }
  public void set_TRNS_DTM(java.sql.Timestamp TRNS_DTM) {
    this.TRNS_DTM = TRNS_DTM;
  }
  public QueryResult with_TRNS_DTM(java.sql.Timestamp TRNS_DTM) {
    this.TRNS_DTM = TRNS_DTM;
    return this;
  }
  private String INPPE_ORG_ID;
  public String get_INPPE_ORG_ID() {
    return INPPE_ORG_ID;
  }
  public void set_INPPE_ORG_ID(String INPPE_ORG_ID) {
    this.INPPE_ORG_ID = INPPE_ORG_ID;
  }
  public QueryResult with_INPPE_ORG_ID(String INPPE_ORG_ID) {
    this.INPPE_ORG_ID = INPPE_ORG_ID;
    return this;
  }
  private java.sql.Timestamp SYS_OCC_DTM;
  public java.sql.Timestamp get_SYS_OCC_DTM() {
    return SYS_OCC_DTM;
  }
  public void set_SYS_OCC_DTM(java.sql.Timestamp SYS_OCC_DTM) {
    this.SYS_OCC_DTM = SYS_OCC_DTM;
  }
  public QueryResult with_SYS_OCC_DTM(java.sql.Timestamp SYS_OCC_DTM) {
    this.SYS_OCC_DTM = SYS_OCC_DTM;
    return this;
  }
  private String SYS_DEL_DIV_CD;
  public String get_SYS_DEL_DIV_CD() {
    return SYS_DEL_DIV_CD;
  }
  public void set_SYS_DEL_DIV_CD(String SYS_DEL_DIV_CD) {
    this.SYS_DEL_DIV_CD = SYS_DEL_DIV_CD;
  }
  public QueryResult with_SYS_DEL_DIV_CD(String SYS_DEL_DIV_CD) {
    this.SYS_DEL_DIV_CD = SYS_DEL_DIV_CD;
    return this;
  }
  private String OCC_IP;
  public String get_OCC_IP() {
    return OCC_IP;
  }
  public void set_OCC_IP(String OCC_IP) {
    this.OCC_IP = OCC_IP;
  }
  public QueryResult with_OCC_IP(String OCC_IP) {
    this.OCC_IP = OCC_IP;
    return this;
  }
  private String APP_ID;
  public String get_APP_ID() {
    return APP_ID;
  }
  public void set_APP_ID(String APP_ID) {
    this.APP_ID = APP_ID;
  }
  public QueryResult with_APP_ID(String APP_ID) {
    this.APP_ID = APP_ID;
    return this;
  }
  private java.sql.Timestamp DATA_CHNG_DTM;
  public java.sql.Timestamp get_DATA_CHNG_DTM() {
    return DATA_CHNG_DTM;
  }
  public void set_DATA_CHNG_DTM(java.sql.Timestamp DATA_CHNG_DTM) {
    this.DATA_CHNG_DTM = DATA_CHNG_DTM;
  }
  public QueryResult with_DATA_CHNG_DTM(java.sql.Timestamp DATA_CHNG_DTM) {
    this.DATA_CHNG_DTM = DATA_CHNG_DTM;
    return this;
  }
  private String DMG_RT_COV_DCTG_CD;
  public String get_DMG_RT_COV_DCTG_CD() {
    return DMG_RT_COV_DCTG_CD;
  }
  public void set_DMG_RT_COV_DCTG_CD(String DMG_RT_COV_DCTG_CD) {
    this.DMG_RT_COV_DCTG_CD = DMG_RT_COV_DCTG_CD;
  }
  public QueryResult with_DMG_RT_COV_DCTG_CD(String DMG_RT_COV_DCTG_CD) {
    this.DMG_RT_COV_DCTG_CD = DMG_RT_COV_DCTG_CD;
    return this;
  }
  private String CTR_OBJ_ID;
  public String get_CTR_OBJ_ID() {
    return CTR_OBJ_ID;
  }
  public void set_CTR_OBJ_ID(String CTR_OBJ_ID) {
    this.CTR_OBJ_ID = CTR_OBJ_ID;
  }
  public QueryResult with_CTR_OBJ_ID(String CTR_OBJ_ID) {
    this.CTR_OBJ_ID = CTR_OBJ_ID;
    return this;
  }
  private String XCHG_YN;
  public String get_XCHG_YN() {
    return XCHG_YN;
  }
  public void set_XCHG_YN(String XCHG_YN) {
    this.XCHG_YN = XCHG_YN;
  }
  public QueryResult with_XCHG_YN(String XCHG_YN) {
    this.XCHG_YN = XCHG_YN;
    return this;
  }
  private String NOCV_YN;
  public String get_NOCV_YN() {
    return NOCV_YN;
  }
  public void set_NOCV_YN(String NOCV_YN) {
    this.NOCV_YN = NOCV_YN;
  }
  public QueryResult with_NOCV_YN(String NOCV_YN) {
    this.NOCV_YN = NOCV_YN;
    return this;
  }
  private String INSPE_GRDE_VAL;
  public String get_INSPE_GRDE_VAL() {
    return INSPE_GRDE_VAL;
  }
  public void set_INSPE_GRDE_VAL(String INSPE_GRDE_VAL) {
    this.INSPE_GRDE_VAL = INSPE_GRDE_VAL;
  }
  public QueryResult with_INSPE_GRDE_VAL(String INSPE_GRDE_VAL) {
    this.INSPE_GRDE_VAL = INSPE_GRDE_VAL;
    return this;
  }
  private java.sql.Timestamp EIH_LDG_DTM;
  public java.sql.Timestamp get_EIH_LDG_DTM() {
    return EIH_LDG_DTM;
  }
  public void set_EIH_LDG_DTM(java.sql.Timestamp EIH_LDG_DTM) {
    this.EIH_LDG_DTM = EIH_LDG_DTM;
  }
  public QueryResult with_EIH_LDG_DTM(java.sql.Timestamp EIH_LDG_DTM) {
    this.EIH_LDG_DTM = EIH_LDG_DTM;
    return this;
  }
  private String MOM_COV_CD;
  public String get_MOM_COV_CD() {
    return MOM_COV_CD;
  }
  public void set_MOM_COV_CD(String MOM_COV_CD) {
    this.MOM_COV_CD = MOM_COV_CD;
  }
  public QueryResult with_MOM_COV_CD(String MOM_COV_CD) {
    this.MOM_COV_CD = MOM_COV_CD;
    return this;
  }
  private String ACCM_COV_CD;
  public String get_ACCM_COV_CD() {
    return ACCM_COV_CD;
  }
  public void set_ACCM_COV_CD(String ACCM_COV_CD) {
    this.ACCM_COV_CD = ACCM_COV_CD;
  }
  public QueryResult with_ACCM_COV_CD(String ACCM_COV_CD) {
    this.ACCM_COV_CD = ACCM_COV_CD;
    return this;
  }
  private String BTH_AF_COV_CD;
  public String get_BTH_AF_COV_CD() {
    return BTH_AF_COV_CD;
  }
  public void set_BTH_AF_COV_CD(String BTH_AF_COV_CD) {
    this.BTH_AF_COV_CD = BTH_AF_COV_CD;
  }
  public QueryResult with_BTH_AF_COV_CD(String BTH_AF_COV_CD) {
    this.BTH_AF_COV_CD = BTH_AF_COV_CD;
    return this;
  }
  private java.math.BigDecimal COV_SBC_AMT;
  public java.math.BigDecimal get_COV_SBC_AMT() {
    return COV_SBC_AMT;
  }
  public void set_COV_SBC_AMT(java.math.BigDecimal COV_SBC_AMT) {
    this.COV_SBC_AMT = COV_SBC_AMT;
  }
  public QueryResult with_COV_SBC_AMT(java.math.BigDecimal COV_SBC_AMT) {
    this.COV_SBC_AMT = COV_SBC_AMT;
    return this;
  }
  private java.math.BigDecimal ACCM_SBC_AMT;
  public java.math.BigDecimal get_ACCM_SBC_AMT() {
    return ACCM_SBC_AMT;
  }
  public void set_ACCM_SBC_AMT(java.math.BigDecimal ACCM_SBC_AMT) {
    this.ACCM_SBC_AMT = ACCM_SBC_AMT;
  }
  public QueryResult with_ACCM_SBC_AMT(java.math.BigDecimal ACCM_SBC_AMT) {
    this.ACCM_SBC_AMT = ACCM_SBC_AMT;
    return this;
  }
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (!(o instanceof QueryResult)) {
      return false;
    }
    QueryResult that = (QueryResult) o;
    boolean equal = true;
    equal = equal && (this.CTR_COV_ID == null ? that.CTR_COV_ID == null : this.CTR_COV_ID.equals(that.CTR_COV_ID));
    equal = equal && (this.PRCTR_NO == null ? that.PRCTR_NO == null : this.PRCTR_NO.equals(that.PRCTR_NO));
    equal = equal && (this.SBCP_DT == null ? that.SBCP_DT == null : this.SBCP_DT.equals(that.SBCP_DT));
    equal = equal && (this.UNT_PD_CD == null ? that.UNT_PD_CD == null : this.UNT_PD_CD.equals(that.UNT_PD_CD));
    equal = equal && (this.COV_CD == null ? that.COV_CD == null : this.COV_CD.equals(that.COV_CD));
    equal = equal && (this.CLF_DIV_CD == null ? that.CLF_DIV_CD == null : this.CLF_DIV_CD.equals(that.CLF_DIV_CD));
    equal = equal && (this.INS_SBC_SH_CD == null ? that.INS_SBC_SH_CD == null : this.INS_SBC_SH_CD.equals(that.INS_SBC_SH_CD));
    equal = equal && (this.TRTPE_ORG_CD == null ? that.TRTPE_ORG_CD == null : this.TRTPE_ORG_CD.equals(that.TRTPE_ORG_CD));
    equal = equal && (this.HDQT_ORG_CD == null ? that.HDQT_ORG_CD == null : this.HDQT_ORG_CD.equals(that.HDQT_ORG_CD));
    equal = equal && (this.BCH_ORG_CD == null ? that.BCH_ORG_CD == null : this.BCH_ORG_CD.equals(that.BCH_ORG_CD));
    equal = equal && (this.CHN_DIV_CD == null ? that.CHN_DIV_CD == null : this.CHN_DIV_CD.equals(that.CHN_DIV_CD));
    equal = equal && (this.FEE_PAY_TP_CD == null ? that.FEE_PAY_TP_CD == null : this.FEE_PAY_TP_CD.equals(that.FEE_PAY_TP_CD));
    equal = equal && (this.OWN_CTR_YN == null ? that.OWN_CTR_YN == null : this.OWN_CTR_YN.equals(that.OWN_CTR_YN));
    equal = equal && (this.JOB_GRD_CD == null ? that.JOB_GRD_CD == null : this.JOB_GRD_CD.equals(that.JOB_GRD_CD));
    equal = equal && (this.MNCL_MD_CD == null ? that.MNCL_MD_CD == null : this.MNCL_MD_CD.equals(that.MNCL_MD_CD));
    equal = equal && (this.BAS_SIC_DIV_CD == null ? that.BAS_SIC_DIV_CD == null : this.BAS_SIC_DIV_CD.equals(that.BAS_SIC_DIV_CD));
    equal = equal && (this.INS_AGE == null ? that.INS_AGE == null : this.INS_AGE.equals(that.INS_AGE));
    equal = equal && (this.COV_FRS_SBC_AGE == null ? that.COV_FRS_SBC_AGE == null : this.COV_FRS_SBC_AGE.equals(that.COV_FRS_SBC_AGE));
    equal = equal && (this.GNDR_CD == null ? that.GNDR_CD == null : this.GNDR_CD.equals(that.GNDR_CD));
    equal = equal && (this.COV_INS_PRD_TP_CD == null ? that.COV_INS_PRD_TP_CD == null : this.COV_INS_PRD_TP_CD.equals(that.COV_INS_PRD_TP_CD));
    equal = equal && (this.COV_INS_PRD == null ? that.COV_INS_PRD == null : this.COV_INS_PRD.equals(that.COV_INS_PRD));
    equal = equal && (this.COV_PY_PRD_TP_CD == null ? that.COV_PY_PRD_TP_CD == null : this.COV_PY_PRD_TP_CD.equals(that.COV_PY_PRD_TP_CD));
    equal = equal && (this.COV_PY_PRD == null ? that.COV_PY_PRD == null : this.COV_PY_PRD.equals(that.COV_PY_PRD));
    equal = equal && (this.BAS_PREM == null ? that.BAS_PREM == null : this.BAS_PREM.equals(that.BAS_PREM));
    equal = equal && (this.SLZ_PREM == null ? that.SLZ_PREM == null : this.SLZ_PREM.equals(that.SLZ_PREM));
    equal = equal && (this.YYPY_CNVS_BAS_PREM == null ? that.YYPY_CNVS_BAS_PREM == null : this.YYPY_CNVS_BAS_PREM.equals(that.YYPY_CNVS_BAS_PREM));
    equal = equal && (this.YYPY_CNVS_SLZ_PREM == null ? that.YYPY_CNVS_SLZ_PREM == null : this.YYPY_CNVS_SLZ_PREM.equals(that.YYPY_CNVS_SLZ_PREM));
    equal = equal && (this.PY_CYC_CD == null ? that.PY_CYC_CD == null : this.PY_CYC_CD.equals(that.PY_CYC_CD));
    equal = equal && (this.INSD_AMT == null ? that.INSD_AMT == null : this.INSD_AMT.equals(that.INSD_AMT));
    equal = equal && (this.STD_SBC_AMT == null ? that.STD_SBC_AMT == null : this.STD_SBC_AMT.equals(that.STD_SBC_AMT));
    equal = equal && (this.COV_INS_BGN_DT == null ? that.COV_INS_BGN_DT == null : this.COV_INS_BGN_DT.equals(that.COV_INS_BGN_DT));
    equal = equal && (this.RKEY_CNFG_CHT_VAL == null ? that.RKEY_CNFG_CHT_VAL == null : this.RKEY_CNFG_CHT_VAL.equals(that.RKEY_CNFG_CHT_VAL));
    equal = equal && (this.RDY_AMT_TRM_VAL1 == null ? that.RDY_AMT_TRM_VAL1 == null : this.RDY_AMT_TRM_VAL1.equals(that.RDY_AMT_TRM_VAL1));
    equal = equal && (this.RDY_AMT_TRM_VAL2 == null ? that.RDY_AMT_TRM_VAL2 == null : this.RDY_AMT_TRM_VAL2.equals(that.RDY_AMT_TRM_VAL2));
    equal = equal && (this.RDY_AMT_TRM_VAL3 == null ? that.RDY_AMT_TRM_VAL3 == null : this.RDY_AMT_TRM_VAL3.equals(that.RDY_AMT_TRM_VAL3));
    equal = equal && (this.RDY_AMT_TRM_VAL4 == null ? that.RDY_AMT_TRM_VAL4 == null : this.RDY_AMT_TRM_VAL4.equals(that.RDY_AMT_TRM_VAL4));
    equal = equal && (this.RDY_AMT_TRM_VAL5 == null ? that.RDY_AMT_TRM_VAL5 == null : this.RDY_AMT_TRM_VAL5.equals(that.RDY_AMT_TRM_VAL5));
    equal = equal && (this.RDY_AMT_TRM_VAL6 == null ? that.RDY_AMT_TRM_VAL6 == null : this.RDY_AMT_TRM_VAL6.equals(that.RDY_AMT_TRM_VAL6));
    equal = equal && (this.RDY_AMT_TRM_VAL7 == null ? that.RDY_AMT_TRM_VAL7 == null : this.RDY_AMT_TRM_VAL7.equals(that.RDY_AMT_TRM_VAL7));
    equal = equal && (this.RDY_AMT_TRM_VAL8 == null ? that.RDY_AMT_TRM_VAL8 == null : this.RDY_AMT_TRM_VAL8.equals(that.RDY_AMT_TRM_VAL8));
    equal = equal && (this.RDY_AMT_TRM_VAL9 == null ? that.RDY_AMT_TRM_VAL9 == null : this.RDY_AMT_TRM_VAL9.equals(that.RDY_AMT_TRM_VAL9));
    equal = equal && (this.RDY_AMT_TRM_VAL10 == null ? that.RDY_AMT_TRM_VAL10 == null : this.RDY_AMT_TRM_VAL10.equals(that.RDY_AMT_TRM_VAL10));
    equal = equal && (this.RDY_AMT_TRM_VAL11 == null ? that.RDY_AMT_TRM_VAL11 == null : this.RDY_AMT_TRM_VAL11.equals(that.RDY_AMT_TRM_VAL11));
    equal = equal && (this.RDY_AMT_TRM_VAL12 == null ? that.RDY_AMT_TRM_VAL12 == null : this.RDY_AMT_TRM_VAL12.equals(that.RDY_AMT_TRM_VAL12));
    equal = equal && (this.RDY_AMT_TRM_VAL13 == null ? that.RDY_AMT_TRM_VAL13 == null : this.RDY_AMT_TRM_VAL13.equals(that.RDY_AMT_TRM_VAL13));
    equal = equal && (this.RDY_AMT_TRM_VAL14 == null ? that.RDY_AMT_TRM_VAL14 == null : this.RDY_AMT_TRM_VAL14.equals(that.RDY_AMT_TRM_VAL14));
    equal = equal && (this.RDY_AMT_TRM_VAL15 == null ? that.RDY_AMT_TRM_VAL15 == null : this.RDY_AMT_TRM_VAL15.equals(that.RDY_AMT_TRM_VAL15));
    equal = equal && (this.DIVD_YN == null ? that.DIVD_YN == null : this.DIVD_YN.equals(that.DIVD_YN));
    equal = equal && (this.ANN_PAY_CYC_CD == null ? that.ANN_PAY_CYC_CD == null : this.ANN_PAY_CYC_CD.equals(that.ANN_PAY_CYC_CD));
    equal = equal && (this.ANN_PAY_PRD_CD == null ? that.ANN_PAY_PRD_CD == null : this.ANN_PAY_PRD_CD.equals(that.ANN_PAY_PRD_CD));
    equal = equal && (this.ANN_PAY_SH_CD == null ? that.ANN_PAY_SH_CD == null : this.ANN_PAY_SH_CD.equals(that.ANN_PAY_SH_CD));
    equal = equal && (this.ANN_PAY_ST_AGE == null ? that.ANN_PAY_ST_AGE == null : this.ANN_PAY_ST_AGE.equals(that.ANN_PAY_ST_AGE));
    equal = equal && (this.GURT_ACU_DIV_CD == null ? that.GURT_ACU_DIV_CD == null : this.GURT_ACU_DIV_CD.equals(that.GURT_ACU_DIV_CD));
    equal = equal && (this.NEGA_GRP_CD == null ? that.NEGA_GRP_CD == null : this.NEGA_GRP_CD.equals(that.NEGA_GRP_CD));
    equal = equal && (this.COV_SMT_CTG_CD == null ? that.COV_SMT_CTG_CD == null : this.COV_SMT_CTG_CD.equals(that.COV_SMT_CTG_CD));
    equal = equal && (this.XCHG_INDX == null ? that.XCHG_INDX == null : this.XCHG_INDX.equals(that.XCHG_INDX));
    equal = equal && (this.DC_XCHG_CF == null ? that.DC_XCHG_CF == null : this.DC_XCHG_CF.equals(that.DC_XCHG_CF));
    equal = equal && (this.RNWL_COV_CYC_CD == null ? that.RNWL_COV_CYC_CD == null : this.RNWL_COV_CYC_CD.equals(that.RNWL_COV_CYC_CD));
    equal = equal && (this.RNWL_ED_AGE == null ? that.RNWL_ED_AGE == null : this.RNWL_ED_AGE.equals(that.RNWL_ED_AGE));
    equal = equal && (this.RNWL_ED_DT == null ? that.RNWL_ED_DT == null : this.RNWL_ED_DT.equals(that.RNWL_ED_DT));
    equal = equal && (this.RNWL_ED_PRD_DIV_CD == null ? that.RNWL_ED_PRD_DIV_CD == null : this.RNWL_ED_PRD_DIV_CD.equals(that.RNWL_ED_PRD_DIV_CD));
    equal = equal && (this.RNWL_ED_PRD == null ? that.RNWL_ED_PRD == null : this.RNWL_ED_PRD.equals(that.RNWL_ED_PRD));
    equal = equal && (this.POLHD_CONV_SIC_SBC_YN == null ? that.POLHD_CONV_SIC_SBC_YN == null : this.POLHD_CONV_SIC_SBC_YN.equals(that.POLHD_CONV_SIC_SBC_YN));
    equal = equal && (this.PLAN_CD == null ? that.PLAN_CD == null : this.PLAN_CD.equals(that.PLAN_CD));
    equal = equal && (this.INS_BGN_DT == null ? that.INS_BGN_DT == null : this.INS_BGN_DT.equals(that.INS_BGN_DT));
    equal = equal && (this.SBCP_CHN_DIV_CD == null ? that.SBCP_CHN_DIV_CD == null : this.SBCP_CHN_DIV_CD.equals(that.SBCP_CHN_DIV_CD));
    equal = equal && (this.INS_PRD == null ? that.INS_PRD == null : this.INS_PRD.equals(that.INS_PRD));
    equal = equal && (this.PY_PRD == null ? that.PY_PRD == null : this.PY_PRD.equals(that.PY_PRD));
    equal = equal && (this.SETL_PD_DIV_CD == null ? that.SETL_PD_DIV_CD == null : this.SETL_PD_DIV_CD.equals(that.SETL_PD_DIV_CD));
    equal = equal && (this.TRNS_DTM == null ? that.TRNS_DTM == null : this.TRNS_DTM.equals(that.TRNS_DTM));
    equal = equal && (this.INPPE_ORG_ID == null ? that.INPPE_ORG_ID == null : this.INPPE_ORG_ID.equals(that.INPPE_ORG_ID));
    equal = equal && (this.SYS_OCC_DTM == null ? that.SYS_OCC_DTM == null : this.SYS_OCC_DTM.equals(that.SYS_OCC_DTM));
    equal = equal && (this.SYS_DEL_DIV_CD == null ? that.SYS_DEL_DIV_CD == null : this.SYS_DEL_DIV_CD.equals(that.SYS_DEL_DIV_CD));
    equal = equal && (this.OCC_IP == null ? that.OCC_IP == null : this.OCC_IP.equals(that.OCC_IP));
    equal = equal && (this.APP_ID == null ? that.APP_ID == null : this.APP_ID.equals(that.APP_ID));
    equal = equal && (this.DATA_CHNG_DTM == null ? that.DATA_CHNG_DTM == null : this.DATA_CHNG_DTM.equals(that.DATA_CHNG_DTM));
    equal = equal && (this.DMG_RT_COV_DCTG_CD == null ? that.DMG_RT_COV_DCTG_CD == null : this.DMG_RT_COV_DCTG_CD.equals(that.DMG_RT_COV_DCTG_CD));
    equal = equal && (this.CTR_OBJ_ID == null ? that.CTR_OBJ_ID == null : this.CTR_OBJ_ID.equals(that.CTR_OBJ_ID));
    equal = equal && (this.XCHG_YN == null ? that.XCHG_YN == null : this.XCHG_YN.equals(that.XCHG_YN));
    equal = equal && (this.NOCV_YN == null ? that.NOCV_YN == null : this.NOCV_YN.equals(that.NOCV_YN));
    equal = equal && (this.INSPE_GRDE_VAL == null ? that.INSPE_GRDE_VAL == null : this.INSPE_GRDE_VAL.equals(that.INSPE_GRDE_VAL));
    equal = equal && (this.EIH_LDG_DTM == null ? that.EIH_LDG_DTM == null : this.EIH_LDG_DTM.equals(that.EIH_LDG_DTM));
    equal = equal && (this.MOM_COV_CD == null ? that.MOM_COV_CD == null : this.MOM_COV_CD.equals(that.MOM_COV_CD));
    equal = equal && (this.ACCM_COV_CD == null ? that.ACCM_COV_CD == null : this.ACCM_COV_CD.equals(that.ACCM_COV_CD));
    equal = equal && (this.BTH_AF_COV_CD == null ? that.BTH_AF_COV_CD == null : this.BTH_AF_COV_CD.equals(that.BTH_AF_COV_CD));
    equal = equal && (this.COV_SBC_AMT == null ? that.COV_SBC_AMT == null : this.COV_SBC_AMT.equals(that.COV_SBC_AMT));
    equal = equal && (this.ACCM_SBC_AMT == null ? that.ACCM_SBC_AMT == null : this.ACCM_SBC_AMT.equals(that.ACCM_SBC_AMT));
    return equal;
  }
  public boolean equals0(Object o) {
    if (this == o) {
      return true;
    }
    if (!(o instanceof QueryResult)) {
      return false;
    }
    QueryResult that = (QueryResult) o;
    boolean equal = true;
    equal = equal && (this.CTR_COV_ID == null ? that.CTR_COV_ID == null : this.CTR_COV_ID.equals(that.CTR_COV_ID));
    equal = equal && (this.PRCTR_NO == null ? that.PRCTR_NO == null : this.PRCTR_NO.equals(that.PRCTR_NO));
    equal = equal && (this.SBCP_DT == null ? that.SBCP_DT == null : this.SBCP_DT.equals(that.SBCP_DT));
    equal = equal && (this.UNT_PD_CD == null ? that.UNT_PD_CD == null : this.UNT_PD_CD.equals(that.UNT_PD_CD));
    equal = equal && (this.COV_CD == null ? that.COV_CD == null : this.COV_CD.equals(that.COV_CD));
    equal = equal && (this.CLF_DIV_CD == null ? that.CLF_DIV_CD == null : this.CLF_DIV_CD.equals(that.CLF_DIV_CD));
    equal = equal && (this.INS_SBC_SH_CD == null ? that.INS_SBC_SH_CD == null : this.INS_SBC_SH_CD.equals(that.INS_SBC_SH_CD));
    equal = equal && (this.TRTPE_ORG_CD == null ? that.TRTPE_ORG_CD == null : this.TRTPE_ORG_CD.equals(that.TRTPE_ORG_CD));
    equal = equal && (this.HDQT_ORG_CD == null ? that.HDQT_ORG_CD == null : this.HDQT_ORG_CD.equals(that.HDQT_ORG_CD));
    equal = equal && (this.BCH_ORG_CD == null ? that.BCH_ORG_CD == null : this.BCH_ORG_CD.equals(that.BCH_ORG_CD));
    equal = equal && (this.CHN_DIV_CD == null ? that.CHN_DIV_CD == null : this.CHN_DIV_CD.equals(that.CHN_DIV_CD));
    equal = equal && (this.FEE_PAY_TP_CD == null ? that.FEE_PAY_TP_CD == null : this.FEE_PAY_TP_CD.equals(that.FEE_PAY_TP_CD));
    equal = equal && (this.OWN_CTR_YN == null ? that.OWN_CTR_YN == null : this.OWN_CTR_YN.equals(that.OWN_CTR_YN));
    equal = equal && (this.JOB_GRD_CD == null ? that.JOB_GRD_CD == null : this.JOB_GRD_CD.equals(that.JOB_GRD_CD));
    equal = equal && (this.MNCL_MD_CD == null ? that.MNCL_MD_CD == null : this.MNCL_MD_CD.equals(that.MNCL_MD_CD));
    equal = equal && (this.BAS_SIC_DIV_CD == null ? that.BAS_SIC_DIV_CD == null : this.BAS_SIC_DIV_CD.equals(that.BAS_SIC_DIV_CD));
    equal = equal && (this.INS_AGE == null ? that.INS_AGE == null : this.INS_AGE.equals(that.INS_AGE));
    equal = equal && (this.COV_FRS_SBC_AGE == null ? that.COV_FRS_SBC_AGE == null : this.COV_FRS_SBC_AGE.equals(that.COV_FRS_SBC_AGE));
    equal = equal && (this.GNDR_CD == null ? that.GNDR_CD == null : this.GNDR_CD.equals(that.GNDR_CD));
    equal = equal && (this.COV_INS_PRD_TP_CD == null ? that.COV_INS_PRD_TP_CD == null : this.COV_INS_PRD_TP_CD.equals(that.COV_INS_PRD_TP_CD));
    equal = equal && (this.COV_INS_PRD == null ? that.COV_INS_PRD == null : this.COV_INS_PRD.equals(that.COV_INS_PRD));
    equal = equal && (this.COV_PY_PRD_TP_CD == null ? that.COV_PY_PRD_TP_CD == null : this.COV_PY_PRD_TP_CD.equals(that.COV_PY_PRD_TP_CD));
    equal = equal && (this.COV_PY_PRD == null ? that.COV_PY_PRD == null : this.COV_PY_PRD.equals(that.COV_PY_PRD));
    equal = equal && (this.BAS_PREM == null ? that.BAS_PREM == null : this.BAS_PREM.equals(that.BAS_PREM));
    equal = equal && (this.SLZ_PREM == null ? that.SLZ_PREM == null : this.SLZ_PREM.equals(that.SLZ_PREM));
    equal = equal && (this.YYPY_CNVS_BAS_PREM == null ? that.YYPY_CNVS_BAS_PREM == null : this.YYPY_CNVS_BAS_PREM.equals(that.YYPY_CNVS_BAS_PREM));
    equal = equal && (this.YYPY_CNVS_SLZ_PREM == null ? that.YYPY_CNVS_SLZ_PREM == null : this.YYPY_CNVS_SLZ_PREM.equals(that.YYPY_CNVS_SLZ_PREM));
    equal = equal && (this.PY_CYC_CD == null ? that.PY_CYC_CD == null : this.PY_CYC_CD.equals(that.PY_CYC_CD));
    equal = equal && (this.INSD_AMT == null ? that.INSD_AMT == null : this.INSD_AMT.equals(that.INSD_AMT));
    equal = equal && (this.STD_SBC_AMT == null ? that.STD_SBC_AMT == null : this.STD_SBC_AMT.equals(that.STD_SBC_AMT));
    equal = equal && (this.COV_INS_BGN_DT == null ? that.COV_INS_BGN_DT == null : this.COV_INS_BGN_DT.equals(that.COV_INS_BGN_DT));
    equal = equal && (this.RKEY_CNFG_CHT_VAL == null ? that.RKEY_CNFG_CHT_VAL == null : this.RKEY_CNFG_CHT_VAL.equals(that.RKEY_CNFG_CHT_VAL));
    equal = equal && (this.RDY_AMT_TRM_VAL1 == null ? that.RDY_AMT_TRM_VAL1 == null : this.RDY_AMT_TRM_VAL1.equals(that.RDY_AMT_TRM_VAL1));
    equal = equal && (this.RDY_AMT_TRM_VAL2 == null ? that.RDY_AMT_TRM_VAL2 == null : this.RDY_AMT_TRM_VAL2.equals(that.RDY_AMT_TRM_VAL2));
    equal = equal && (this.RDY_AMT_TRM_VAL3 == null ? that.RDY_AMT_TRM_VAL3 == null : this.RDY_AMT_TRM_VAL3.equals(that.RDY_AMT_TRM_VAL3));
    equal = equal && (this.RDY_AMT_TRM_VAL4 == null ? that.RDY_AMT_TRM_VAL4 == null : this.RDY_AMT_TRM_VAL4.equals(that.RDY_AMT_TRM_VAL4));
    equal = equal && (this.RDY_AMT_TRM_VAL5 == null ? that.RDY_AMT_TRM_VAL5 == null : this.RDY_AMT_TRM_VAL5.equals(that.RDY_AMT_TRM_VAL5));
    equal = equal && (this.RDY_AMT_TRM_VAL6 == null ? that.RDY_AMT_TRM_VAL6 == null : this.RDY_AMT_TRM_VAL6.equals(that.RDY_AMT_TRM_VAL6));
    equal = equal && (this.RDY_AMT_TRM_VAL7 == null ? that.RDY_AMT_TRM_VAL7 == null : this.RDY_AMT_TRM_VAL7.equals(that.RDY_AMT_TRM_VAL7));
    equal = equal && (this.RDY_AMT_TRM_VAL8 == null ? that.RDY_AMT_TRM_VAL8 == null : this.RDY_AMT_TRM_VAL8.equals(that.RDY_AMT_TRM_VAL8));
    equal = equal && (this.RDY_AMT_TRM_VAL9 == null ? that.RDY_AMT_TRM_VAL9 == null : this.RDY_AMT_TRM_VAL9.equals(that.RDY_AMT_TRM_VAL9));
    equal = equal && (this.RDY_AMT_TRM_VAL10 == null ? that.RDY_AMT_TRM_VAL10 == null : this.RDY_AMT_TRM_VAL10.equals(that.RDY_AMT_TRM_VAL10));
    equal = equal && (this.RDY_AMT_TRM_VAL11 == null ? that.RDY_AMT_TRM_VAL11 == null : this.RDY_AMT_TRM_VAL11.equals(that.RDY_AMT_TRM_VAL11));
    equal = equal && (this.RDY_AMT_TRM_VAL12 == null ? that.RDY_AMT_TRM_VAL12 == null : this.RDY_AMT_TRM_VAL12.equals(that.RDY_AMT_TRM_VAL12));
    equal = equal && (this.RDY_AMT_TRM_VAL13 == null ? that.RDY_AMT_TRM_VAL13 == null : this.RDY_AMT_TRM_VAL13.equals(that.RDY_AMT_TRM_VAL13));
    equal = equal && (this.RDY_AMT_TRM_VAL14 == null ? that.RDY_AMT_TRM_VAL14 == null : this.RDY_AMT_TRM_VAL14.equals(that.RDY_AMT_TRM_VAL14));
    equal = equal && (this.RDY_AMT_TRM_VAL15 == null ? that.RDY_AMT_TRM_VAL15 == null : this.RDY_AMT_TRM_VAL15.equals(that.RDY_AMT_TRM_VAL15));
    equal = equal && (this.DIVD_YN == null ? that.DIVD_YN == null : this.DIVD_YN.equals(that.DIVD_YN));
    equal = equal && (this.ANN_PAY_CYC_CD == null ? that.ANN_PAY_CYC_CD == null : this.ANN_PAY_CYC_CD.equals(that.ANN_PAY_CYC_CD));
    equal = equal && (this.ANN_PAY_PRD_CD == null ? that.ANN_PAY_PRD_CD == null : this.ANN_PAY_PRD_CD.equals(that.ANN_PAY_PRD_CD));
    equal = equal && (this.ANN_PAY_SH_CD == null ? that.ANN_PAY_SH_CD == null : this.ANN_PAY_SH_CD.equals(that.ANN_PAY_SH_CD));
    equal = equal && (this.ANN_PAY_ST_AGE == null ? that.ANN_PAY_ST_AGE == null : this.ANN_PAY_ST_AGE.equals(that.ANN_PAY_ST_AGE));
    equal = equal && (this.GURT_ACU_DIV_CD == null ? that.GURT_ACU_DIV_CD == null : this.GURT_ACU_DIV_CD.equals(that.GURT_ACU_DIV_CD));
    equal = equal && (this.NEGA_GRP_CD == null ? that.NEGA_GRP_CD == null : this.NEGA_GRP_CD.equals(that.NEGA_GRP_CD));
    equal = equal && (this.COV_SMT_CTG_CD == null ? that.COV_SMT_CTG_CD == null : this.COV_SMT_CTG_CD.equals(that.COV_SMT_CTG_CD));
    equal = equal && (this.XCHG_INDX == null ? that.XCHG_INDX == null : this.XCHG_INDX.equals(that.XCHG_INDX));
    equal = equal && (this.DC_XCHG_CF == null ? that.DC_XCHG_CF == null : this.DC_XCHG_CF.equals(that.DC_XCHG_CF));
    equal = equal && (this.RNWL_COV_CYC_CD == null ? that.RNWL_COV_CYC_CD == null : this.RNWL_COV_CYC_CD.equals(that.RNWL_COV_CYC_CD));
    equal = equal && (this.RNWL_ED_AGE == null ? that.RNWL_ED_AGE == null : this.RNWL_ED_AGE.equals(that.RNWL_ED_AGE));
    equal = equal && (this.RNWL_ED_DT == null ? that.RNWL_ED_DT == null : this.RNWL_ED_DT.equals(that.RNWL_ED_DT));
    equal = equal && (this.RNWL_ED_PRD_DIV_CD == null ? that.RNWL_ED_PRD_DIV_CD == null : this.RNWL_ED_PRD_DIV_CD.equals(that.RNWL_ED_PRD_DIV_CD));
    equal = equal && (this.RNWL_ED_PRD == null ? that.RNWL_ED_PRD == null : this.RNWL_ED_PRD.equals(that.RNWL_ED_PRD));
    equal = equal && (this.POLHD_CONV_SIC_SBC_YN == null ? that.POLHD_CONV_SIC_SBC_YN == null : this.POLHD_CONV_SIC_SBC_YN.equals(that.POLHD_CONV_SIC_SBC_YN));
    equal = equal && (this.PLAN_CD == null ? that.PLAN_CD == null : this.PLAN_CD.equals(that.PLAN_CD));
    equal = equal && (this.INS_BGN_DT == null ? that.INS_BGN_DT == null : this.INS_BGN_DT.equals(that.INS_BGN_DT));
    equal = equal && (this.SBCP_CHN_DIV_CD == null ? that.SBCP_CHN_DIV_CD == null : this.SBCP_CHN_DIV_CD.equals(that.SBCP_CHN_DIV_CD));
    equal = equal && (this.INS_PRD == null ? that.INS_PRD == null : this.INS_PRD.equals(that.INS_PRD));
    equal = equal && (this.PY_PRD == null ? that.PY_PRD == null : this.PY_PRD.equals(that.PY_PRD));
    equal = equal && (this.SETL_PD_DIV_CD == null ? that.SETL_PD_DIV_CD == null : this.SETL_PD_DIV_CD.equals(that.SETL_PD_DIV_CD));
    equal = equal && (this.TRNS_DTM == null ? that.TRNS_DTM == null : this.TRNS_DTM.equals(that.TRNS_DTM));
    equal = equal && (this.INPPE_ORG_ID == null ? that.INPPE_ORG_ID == null : this.INPPE_ORG_ID.equals(that.INPPE_ORG_ID));
    equal = equal && (this.SYS_OCC_DTM == null ? that.SYS_OCC_DTM == null : this.SYS_OCC_DTM.equals(that.SYS_OCC_DTM));
    equal = equal && (this.SYS_DEL_DIV_CD == null ? that.SYS_DEL_DIV_CD == null : this.SYS_DEL_DIV_CD.equals(that.SYS_DEL_DIV_CD));
    equal = equal && (this.OCC_IP == null ? that.OCC_IP == null : this.OCC_IP.equals(that.OCC_IP));
    equal = equal && (this.APP_ID == null ? that.APP_ID == null : this.APP_ID.equals(that.APP_ID));
    equal = equal && (this.DATA_CHNG_DTM == null ? that.DATA_CHNG_DTM == null : this.DATA_CHNG_DTM.equals(that.DATA_CHNG_DTM));
    equal = equal && (this.DMG_RT_COV_DCTG_CD == null ? that.DMG_RT_COV_DCTG_CD == null : this.DMG_RT_COV_DCTG_CD.equals(that.DMG_RT_COV_DCTG_CD));
    equal = equal && (this.CTR_OBJ_ID == null ? that.CTR_OBJ_ID == null : this.CTR_OBJ_ID.equals(that.CTR_OBJ_ID));
    equal = equal && (this.XCHG_YN == null ? that.XCHG_YN == null : this.XCHG_YN.equals(that.XCHG_YN));
    equal = equal && (this.NOCV_YN == null ? that.NOCV_YN == null : this.NOCV_YN.equals(that.NOCV_YN));
    equal = equal && (this.INSPE_GRDE_VAL == null ? that.INSPE_GRDE_VAL == null : this.INSPE_GRDE_VAL.equals(that.INSPE_GRDE_VAL));
    equal = equal && (this.EIH_LDG_DTM == null ? that.EIH_LDG_DTM == null : this.EIH_LDG_DTM.equals(that.EIH_LDG_DTM));
    equal = equal && (this.MOM_COV_CD == null ? that.MOM_COV_CD == null : this.MOM_COV_CD.equals(that.MOM_COV_CD));
    equal = equal && (this.ACCM_COV_CD == null ? that.ACCM_COV_CD == null : this.ACCM_COV_CD.equals(that.ACCM_COV_CD));
    equal = equal && (this.BTH_AF_COV_CD == null ? that.BTH_AF_COV_CD == null : this.BTH_AF_COV_CD.equals(that.BTH_AF_COV_CD));
    equal = equal && (this.COV_SBC_AMT == null ? that.COV_SBC_AMT == null : this.COV_SBC_AMT.equals(that.COV_SBC_AMT));
    equal = equal && (this.ACCM_SBC_AMT == null ? that.ACCM_SBC_AMT == null : this.ACCM_SBC_AMT.equals(that.ACCM_SBC_AMT));
    return equal;
  }
  public void readFields(ResultSet __dbResults) throws SQLException {
    this.__cur_result_set = __dbResults;
    this.CTR_COV_ID = JdbcWritableBridge.readString(1, __dbResults);
    this.PRCTR_NO = JdbcWritableBridge.readString(2, __dbResults);
    this.SBCP_DT = JdbcWritableBridge.readTimestamp(3, __dbResults);
    this.UNT_PD_CD = JdbcWritableBridge.readString(4, __dbResults);
    this.COV_CD = JdbcWritableBridge.readString(5, __dbResults);
    this.CLF_DIV_CD = JdbcWritableBridge.readString(6, __dbResults);
    this.INS_SBC_SH_CD = JdbcWritableBridge.readString(7, __dbResults);
    this.TRTPE_ORG_CD = JdbcWritableBridge.readString(8, __dbResults);
    this.HDQT_ORG_CD = JdbcWritableBridge.readString(9, __dbResults);
    this.BCH_ORG_CD = JdbcWritableBridge.readString(10, __dbResults);
    this.CHN_DIV_CD = JdbcWritableBridge.readString(11, __dbResults);
    this.FEE_PAY_TP_CD = JdbcWritableBridge.readString(12, __dbResults);
    this.OWN_CTR_YN = JdbcWritableBridge.readString(13, __dbResults);
    this.JOB_GRD_CD = JdbcWritableBridge.readString(14, __dbResults);
    this.MNCL_MD_CD = JdbcWritableBridge.readString(15, __dbResults);
    this.BAS_SIC_DIV_CD = JdbcWritableBridge.readString(16, __dbResults);
    this.INS_AGE = JdbcWritableBridge.readBigDecimal(17, __dbResults);
    this.COV_FRS_SBC_AGE = JdbcWritableBridge.readBigDecimal(18, __dbResults);
    this.GNDR_CD = JdbcWritableBridge.readString(19, __dbResults);
    this.COV_INS_PRD_TP_CD = JdbcWritableBridge.readString(20, __dbResults);
    this.COV_INS_PRD = JdbcWritableBridge.readBigDecimal(21, __dbResults);
    this.COV_PY_PRD_TP_CD = JdbcWritableBridge.readString(22, __dbResults);
    this.COV_PY_PRD = JdbcWritableBridge.readBigDecimal(23, __dbResults);
    this.BAS_PREM = JdbcWritableBridge.readBigDecimal(24, __dbResults);
    this.SLZ_PREM = JdbcWritableBridge.readBigDecimal(25, __dbResults);
    this.YYPY_CNVS_BAS_PREM = JdbcWritableBridge.readBigDecimal(26, __dbResults);
    this.YYPY_CNVS_SLZ_PREM = JdbcWritableBridge.readBigDecimal(27, __dbResults);
    this.PY_CYC_CD = JdbcWritableBridge.readString(28, __dbResults);
    this.INSD_AMT = JdbcWritableBridge.readBigDecimal(29, __dbResults);
    this.STD_SBC_AMT = JdbcWritableBridge.readBigDecimal(30, __dbResults);
    this.COV_INS_BGN_DT = JdbcWritableBridge.readTimestamp(31, __dbResults);
    this.RKEY_CNFG_CHT_VAL = JdbcWritableBridge.readString(32, __dbResults);
    this.RDY_AMT_TRM_VAL1 = JdbcWritableBridge.readString(33, __dbResults);
    this.RDY_AMT_TRM_VAL2 = JdbcWritableBridge.readString(34, __dbResults);
    this.RDY_AMT_TRM_VAL3 = JdbcWritableBridge.readString(35, __dbResults);
    this.RDY_AMT_TRM_VAL4 = JdbcWritableBridge.readString(36, __dbResults);
    this.RDY_AMT_TRM_VAL5 = JdbcWritableBridge.readString(37, __dbResults);
    this.RDY_AMT_TRM_VAL6 = JdbcWritableBridge.readString(38, __dbResults);
    this.RDY_AMT_TRM_VAL7 = JdbcWritableBridge.readString(39, __dbResults);
    this.RDY_AMT_TRM_VAL8 = JdbcWritableBridge.readString(40, __dbResults);
    this.RDY_AMT_TRM_VAL9 = JdbcWritableBridge.readString(41, __dbResults);
    this.RDY_AMT_TRM_VAL10 = JdbcWritableBridge.readString(42, __dbResults);
    this.RDY_AMT_TRM_VAL11 = JdbcWritableBridge.readString(43, __dbResults);
    this.RDY_AMT_TRM_VAL12 = JdbcWritableBridge.readString(44, __dbResults);
    this.RDY_AMT_TRM_VAL13 = JdbcWritableBridge.readString(45, __dbResults);
    this.RDY_AMT_TRM_VAL14 = JdbcWritableBridge.readString(46, __dbResults);
    this.RDY_AMT_TRM_VAL15 = JdbcWritableBridge.readString(47, __dbResults);
    this.DIVD_YN = JdbcWritableBridge.readString(48, __dbResults);
    this.ANN_PAY_CYC_CD = JdbcWritableBridge.readString(49, __dbResults);
    this.ANN_PAY_PRD_CD = JdbcWritableBridge.readString(50, __dbResults);
    this.ANN_PAY_SH_CD = JdbcWritableBridge.readString(51, __dbResults);
    this.ANN_PAY_ST_AGE = JdbcWritableBridge.readBigDecimal(52, __dbResults);
    this.GURT_ACU_DIV_CD = JdbcWritableBridge.readString(53, __dbResults);
    this.NEGA_GRP_CD = JdbcWritableBridge.readString(54, __dbResults);
    this.COV_SMT_CTG_CD = JdbcWritableBridge.readString(55, __dbResults);
    this.XCHG_INDX = JdbcWritableBridge.readBigDecimal(56, __dbResults);
    this.DC_XCHG_CF = JdbcWritableBridge.readBigDecimal(57, __dbResults);
    this.RNWL_COV_CYC_CD = JdbcWritableBridge.readString(58, __dbResults);
    this.RNWL_ED_AGE = JdbcWritableBridge.readBigDecimal(59, __dbResults);
    this.RNWL_ED_DT = JdbcWritableBridge.readTimestamp(60, __dbResults);
    this.RNWL_ED_PRD_DIV_CD = JdbcWritableBridge.readString(61, __dbResults);
    this.RNWL_ED_PRD = JdbcWritableBridge.readBigDecimal(62, __dbResults);
    this.POLHD_CONV_SIC_SBC_YN = JdbcWritableBridge.readString(63, __dbResults);
    this.PLAN_CD = JdbcWritableBridge.readString(64, __dbResults);
    this.INS_BGN_DT = JdbcWritableBridge.readTimestamp(65, __dbResults);
    this.SBCP_CHN_DIV_CD = JdbcWritableBridge.readString(66, __dbResults);
    this.INS_PRD = JdbcWritableBridge.readBigDecimal(67, __dbResults);
    this.PY_PRD = JdbcWritableBridge.readBigDecimal(68, __dbResults);
    this.SETL_PD_DIV_CD = JdbcWritableBridge.readString(69, __dbResults);
    this.TRNS_DTM = JdbcWritableBridge.readTimestamp(70, __dbResults);
    this.INPPE_ORG_ID = JdbcWritableBridge.readString(71, __dbResults);
    this.SYS_OCC_DTM = JdbcWritableBridge.readTimestamp(72, __dbResults);
    this.SYS_DEL_DIV_CD = JdbcWritableBridge.readString(73, __dbResults);
    this.OCC_IP = JdbcWritableBridge.readString(74, __dbResults);
    this.APP_ID = JdbcWritableBridge.readString(75, __dbResults);
    this.DATA_CHNG_DTM = JdbcWritableBridge.readTimestamp(76, __dbResults);
    this.DMG_RT_COV_DCTG_CD = JdbcWritableBridge.readString(77, __dbResults);
    this.CTR_OBJ_ID = JdbcWritableBridge.readString(78, __dbResults);
    this.XCHG_YN = JdbcWritableBridge.readString(79, __dbResults);
    this.NOCV_YN = JdbcWritableBridge.readString(80, __dbResults);
    this.INSPE_GRDE_VAL = JdbcWritableBridge.readString(81, __dbResults);
    this.EIH_LDG_DTM = JdbcWritableBridge.readTimestamp(82, __dbResults);
    this.MOM_COV_CD = JdbcWritableBridge.readString(83, __dbResults);
    this.ACCM_COV_CD = JdbcWritableBridge.readString(84, __dbResults);
    this.BTH_AF_COV_CD = JdbcWritableBridge.readString(85, __dbResults);
    this.COV_SBC_AMT = JdbcWritableBridge.readBigDecimal(86, __dbResults);
    this.ACCM_SBC_AMT = JdbcWritableBridge.readBigDecimal(87, __dbResults);
  }
  public void readFields0(ResultSet __dbResults) throws SQLException {
    this.CTR_COV_ID = JdbcWritableBridge.readString(1, __dbResults);
    this.PRCTR_NO = JdbcWritableBridge.readString(2, __dbResults);
    this.SBCP_DT = JdbcWritableBridge.readTimestamp(3, __dbResults);
    this.UNT_PD_CD = JdbcWritableBridge.readString(4, __dbResults);
    this.COV_CD = JdbcWritableBridge.readString(5, __dbResults);
    this.CLF_DIV_CD = JdbcWritableBridge.readString(6, __dbResults);
    this.INS_SBC_SH_CD = JdbcWritableBridge.readString(7, __dbResults);
    this.TRTPE_ORG_CD = JdbcWritableBridge.readString(8, __dbResults);
    this.HDQT_ORG_CD = JdbcWritableBridge.readString(9, __dbResults);
    this.BCH_ORG_CD = JdbcWritableBridge.readString(10, __dbResults);
    this.CHN_DIV_CD = JdbcWritableBridge.readString(11, __dbResults);
    this.FEE_PAY_TP_CD = JdbcWritableBridge.readString(12, __dbResults);
    this.OWN_CTR_YN = JdbcWritableBridge.readString(13, __dbResults);
    this.JOB_GRD_CD = JdbcWritableBridge.readString(14, __dbResults);
    this.MNCL_MD_CD = JdbcWritableBridge.readString(15, __dbResults);
    this.BAS_SIC_DIV_CD = JdbcWritableBridge.readString(16, __dbResults);
    this.INS_AGE = JdbcWritableBridge.readBigDecimal(17, __dbResults);
    this.COV_FRS_SBC_AGE = JdbcWritableBridge.readBigDecimal(18, __dbResults);
    this.GNDR_CD = JdbcWritableBridge.readString(19, __dbResults);
    this.COV_INS_PRD_TP_CD = JdbcWritableBridge.readString(20, __dbResults);
    this.COV_INS_PRD = JdbcWritableBridge.readBigDecimal(21, __dbResults);
    this.COV_PY_PRD_TP_CD = JdbcWritableBridge.readString(22, __dbResults);
    this.COV_PY_PRD = JdbcWritableBridge.readBigDecimal(23, __dbResults);
    this.BAS_PREM = JdbcWritableBridge.readBigDecimal(24, __dbResults);
    this.SLZ_PREM = JdbcWritableBridge.readBigDecimal(25, __dbResults);
    this.YYPY_CNVS_BAS_PREM = JdbcWritableBridge.readBigDecimal(26, __dbResults);
    this.YYPY_CNVS_SLZ_PREM = JdbcWritableBridge.readBigDecimal(27, __dbResults);
    this.PY_CYC_CD = JdbcWritableBridge.readString(28, __dbResults);
    this.INSD_AMT = JdbcWritableBridge.readBigDecimal(29, __dbResults);
    this.STD_SBC_AMT = JdbcWritableBridge.readBigDecimal(30, __dbResults);
    this.COV_INS_BGN_DT = JdbcWritableBridge.readTimestamp(31, __dbResults);
    this.RKEY_CNFG_CHT_VAL = JdbcWritableBridge.readString(32, __dbResults);
    this.RDY_AMT_TRM_VAL1 = JdbcWritableBridge.readString(33, __dbResults);
    this.RDY_AMT_TRM_VAL2 = JdbcWritableBridge.readString(34, __dbResults);
    this.RDY_AMT_TRM_VAL3 = JdbcWritableBridge.readString(35, __dbResults);
    this.RDY_AMT_TRM_VAL4 = JdbcWritableBridge.readString(36, __dbResults);
    this.RDY_AMT_TRM_VAL5 = JdbcWritableBridge.readString(37, __dbResults);
    this.RDY_AMT_TRM_VAL6 = JdbcWritableBridge.readString(38, __dbResults);
    this.RDY_AMT_TRM_VAL7 = JdbcWritableBridge.readString(39, __dbResults);
    this.RDY_AMT_TRM_VAL8 = JdbcWritableBridge.readString(40, __dbResults);
    this.RDY_AMT_TRM_VAL9 = JdbcWritableBridge.readString(41, __dbResults);
    this.RDY_AMT_TRM_VAL10 = JdbcWritableBridge.readString(42, __dbResults);
    this.RDY_AMT_TRM_VAL11 = JdbcWritableBridge.readString(43, __dbResults);
    this.RDY_AMT_TRM_VAL12 = JdbcWritableBridge.readString(44, __dbResults);
    this.RDY_AMT_TRM_VAL13 = JdbcWritableBridge.readString(45, __dbResults);
    this.RDY_AMT_TRM_VAL14 = JdbcWritableBridge.readString(46, __dbResults);
    this.RDY_AMT_TRM_VAL15 = JdbcWritableBridge.readString(47, __dbResults);
    this.DIVD_YN = JdbcWritableBridge.readString(48, __dbResults);
    this.ANN_PAY_CYC_CD = JdbcWritableBridge.readString(49, __dbResults);
    this.ANN_PAY_PRD_CD = JdbcWritableBridge.readString(50, __dbResults);
    this.ANN_PAY_SH_CD = JdbcWritableBridge.readString(51, __dbResults);
    this.ANN_PAY_ST_AGE = JdbcWritableBridge.readBigDecimal(52, __dbResults);
    this.GURT_ACU_DIV_CD = JdbcWritableBridge.readString(53, __dbResults);
    this.NEGA_GRP_CD = JdbcWritableBridge.readString(54, __dbResults);
    this.COV_SMT_CTG_CD = JdbcWritableBridge.readString(55, __dbResults);
    this.XCHG_INDX = JdbcWritableBridge.readBigDecimal(56, __dbResults);
    this.DC_XCHG_CF = JdbcWritableBridge.readBigDecimal(57, __dbResults);
    this.RNWL_COV_CYC_CD = JdbcWritableBridge.readString(58, __dbResults);
    this.RNWL_ED_AGE = JdbcWritableBridge.readBigDecimal(59, __dbResults);
    this.RNWL_ED_DT = JdbcWritableBridge.readTimestamp(60, __dbResults);
    this.RNWL_ED_PRD_DIV_CD = JdbcWritableBridge.readString(61, __dbResults);
    this.RNWL_ED_PRD = JdbcWritableBridge.readBigDecimal(62, __dbResults);
    this.POLHD_CONV_SIC_SBC_YN = JdbcWritableBridge.readString(63, __dbResults);
    this.PLAN_CD = JdbcWritableBridge.readString(64, __dbResults);
    this.INS_BGN_DT = JdbcWritableBridge.readTimestamp(65, __dbResults);
    this.SBCP_CHN_DIV_CD = JdbcWritableBridge.readString(66, __dbResults);
    this.INS_PRD = JdbcWritableBridge.readBigDecimal(67, __dbResults);
    this.PY_PRD = JdbcWritableBridge.readBigDecimal(68, __dbResults);
    this.SETL_PD_DIV_CD = JdbcWritableBridge.readString(69, __dbResults);
    this.TRNS_DTM = JdbcWritableBridge.readTimestamp(70, __dbResults);
    this.INPPE_ORG_ID = JdbcWritableBridge.readString(71, __dbResults);
    this.SYS_OCC_DTM = JdbcWritableBridge.readTimestamp(72, __dbResults);
    this.SYS_DEL_DIV_CD = JdbcWritableBridge.readString(73, __dbResults);
    this.OCC_IP = JdbcWritableBridge.readString(74, __dbResults);
    this.APP_ID = JdbcWritableBridge.readString(75, __dbResults);
    this.DATA_CHNG_DTM = JdbcWritableBridge.readTimestamp(76, __dbResults);
    this.DMG_RT_COV_DCTG_CD = JdbcWritableBridge.readString(77, __dbResults);
    this.CTR_OBJ_ID = JdbcWritableBridge.readString(78, __dbResults);
    this.XCHG_YN = JdbcWritableBridge.readString(79, __dbResults);
    this.NOCV_YN = JdbcWritableBridge.readString(80, __dbResults);
    this.INSPE_GRDE_VAL = JdbcWritableBridge.readString(81, __dbResults);
    this.EIH_LDG_DTM = JdbcWritableBridge.readTimestamp(82, __dbResults);
    this.MOM_COV_CD = JdbcWritableBridge.readString(83, __dbResults);
    this.ACCM_COV_CD = JdbcWritableBridge.readString(84, __dbResults);
    this.BTH_AF_COV_CD = JdbcWritableBridge.readString(85, __dbResults);
    this.COV_SBC_AMT = JdbcWritableBridge.readBigDecimal(86, __dbResults);
    this.ACCM_SBC_AMT = JdbcWritableBridge.readBigDecimal(87, __dbResults);
  }
  public void loadLargeObjects(LargeObjectLoader __loader)
      throws SQLException, IOException, InterruptedException {
  }
  public void loadLargeObjects0(LargeObjectLoader __loader)
      throws SQLException, IOException, InterruptedException {
  }
  public void write(PreparedStatement __dbStmt) throws SQLException {
    write(__dbStmt, 0);
  }

  public int write(PreparedStatement __dbStmt, int __off) throws SQLException {
    JdbcWritableBridge.writeString(CTR_COV_ID, 1 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(PRCTR_NO, 2 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeTimestamp(SBCP_DT, 3 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeString(UNT_PD_CD, 4 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(COV_CD, 5 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(CLF_DIV_CD, 6 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(INS_SBC_SH_CD, 7 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(TRTPE_ORG_CD, 8 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(HDQT_ORG_CD, 9 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(BCH_ORG_CD, 10 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(CHN_DIV_CD, 11 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(FEE_PAY_TP_CD, 12 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(OWN_CTR_YN, 13 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(JOB_GRD_CD, 14 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(MNCL_MD_CD, 15 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(BAS_SIC_DIV_CD, 16 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(INS_AGE, 17 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(COV_FRS_SBC_AGE, 18 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(GNDR_CD, 19 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(COV_INS_PRD_TP_CD, 20 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(COV_INS_PRD, 21 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(COV_PY_PRD_TP_CD, 22 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(COV_PY_PRD, 23 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(BAS_PREM, 24 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(SLZ_PREM, 25 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(YYPY_CNVS_BAS_PREM, 26 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(YYPY_CNVS_SLZ_PREM, 27 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(PY_CYC_CD, 28 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(INSD_AMT, 29 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(STD_SBC_AMT, 30 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeTimestamp(COV_INS_BGN_DT, 31 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeString(RKEY_CNFG_CHT_VAL, 32 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(RDY_AMT_TRM_VAL1, 33 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(RDY_AMT_TRM_VAL2, 34 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(RDY_AMT_TRM_VAL3, 35 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(RDY_AMT_TRM_VAL4, 36 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(RDY_AMT_TRM_VAL5, 37 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(RDY_AMT_TRM_VAL6, 38 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(RDY_AMT_TRM_VAL7, 39 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(RDY_AMT_TRM_VAL8, 40 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(RDY_AMT_TRM_VAL9, 41 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(RDY_AMT_TRM_VAL10, 42 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(RDY_AMT_TRM_VAL11, 43 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(RDY_AMT_TRM_VAL12, 44 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(RDY_AMT_TRM_VAL13, 45 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(RDY_AMT_TRM_VAL14, 46 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(RDY_AMT_TRM_VAL15, 47 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(DIVD_YN, 48 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(ANN_PAY_CYC_CD, 49 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(ANN_PAY_PRD_CD, 50 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(ANN_PAY_SH_CD, 51 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(ANN_PAY_ST_AGE, 52 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(GURT_ACU_DIV_CD, 53 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(NEGA_GRP_CD, 54 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(COV_SMT_CTG_CD, 55 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(XCHG_INDX, 56 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(DC_XCHG_CF, 57 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(RNWL_COV_CYC_CD, 58 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(RNWL_ED_AGE, 59 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeTimestamp(RNWL_ED_DT, 60 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeString(RNWL_ED_PRD_DIV_CD, 61 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(RNWL_ED_PRD, 62 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(POLHD_CONV_SIC_SBC_YN, 63 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(PLAN_CD, 64 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeTimestamp(INS_BGN_DT, 65 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeString(SBCP_CHN_DIV_CD, 66 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(INS_PRD, 67 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(PY_PRD, 68 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(SETL_PD_DIV_CD, 69 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeTimestamp(TRNS_DTM, 70 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeString(INPPE_ORG_ID, 71 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeTimestamp(SYS_OCC_DTM, 72 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeString(SYS_DEL_DIV_CD, 73 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(OCC_IP, 74 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(APP_ID, 75 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeTimestamp(DATA_CHNG_DTM, 76 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeString(DMG_RT_COV_DCTG_CD, 77 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(CTR_OBJ_ID, 78 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(XCHG_YN, 79 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(NOCV_YN, 80 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(INSPE_GRDE_VAL, 81 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeTimestamp(EIH_LDG_DTM, 82 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeString(MOM_COV_CD, 83 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(ACCM_COV_CD, 84 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(BTH_AF_COV_CD, 85 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(COV_SBC_AMT, 86 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(ACCM_SBC_AMT, 87 + __off, 2, __dbStmt);
    return 87;
  }
  public void write0(PreparedStatement __dbStmt, int __off) throws SQLException {
    JdbcWritableBridge.writeString(CTR_COV_ID, 1 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(PRCTR_NO, 2 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeTimestamp(SBCP_DT, 3 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeString(UNT_PD_CD, 4 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(COV_CD, 5 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(CLF_DIV_CD, 6 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(INS_SBC_SH_CD, 7 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(TRTPE_ORG_CD, 8 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(HDQT_ORG_CD, 9 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(BCH_ORG_CD, 10 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(CHN_DIV_CD, 11 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(FEE_PAY_TP_CD, 12 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(OWN_CTR_YN, 13 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(JOB_GRD_CD, 14 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(MNCL_MD_CD, 15 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(BAS_SIC_DIV_CD, 16 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(INS_AGE, 17 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(COV_FRS_SBC_AGE, 18 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(GNDR_CD, 19 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(COV_INS_PRD_TP_CD, 20 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(COV_INS_PRD, 21 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(COV_PY_PRD_TP_CD, 22 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(COV_PY_PRD, 23 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(BAS_PREM, 24 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(SLZ_PREM, 25 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(YYPY_CNVS_BAS_PREM, 26 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(YYPY_CNVS_SLZ_PREM, 27 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(PY_CYC_CD, 28 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(INSD_AMT, 29 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(STD_SBC_AMT, 30 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeTimestamp(COV_INS_BGN_DT, 31 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeString(RKEY_CNFG_CHT_VAL, 32 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(RDY_AMT_TRM_VAL1, 33 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(RDY_AMT_TRM_VAL2, 34 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(RDY_AMT_TRM_VAL3, 35 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(RDY_AMT_TRM_VAL4, 36 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(RDY_AMT_TRM_VAL5, 37 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(RDY_AMT_TRM_VAL6, 38 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(RDY_AMT_TRM_VAL7, 39 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(RDY_AMT_TRM_VAL8, 40 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(RDY_AMT_TRM_VAL9, 41 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(RDY_AMT_TRM_VAL10, 42 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(RDY_AMT_TRM_VAL11, 43 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(RDY_AMT_TRM_VAL12, 44 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(RDY_AMT_TRM_VAL13, 45 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(RDY_AMT_TRM_VAL14, 46 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(RDY_AMT_TRM_VAL15, 47 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(DIVD_YN, 48 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(ANN_PAY_CYC_CD, 49 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(ANN_PAY_PRD_CD, 50 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(ANN_PAY_SH_CD, 51 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(ANN_PAY_ST_AGE, 52 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(GURT_ACU_DIV_CD, 53 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(NEGA_GRP_CD, 54 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(COV_SMT_CTG_CD, 55 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(XCHG_INDX, 56 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(DC_XCHG_CF, 57 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(RNWL_COV_CYC_CD, 58 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(RNWL_ED_AGE, 59 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeTimestamp(RNWL_ED_DT, 60 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeString(RNWL_ED_PRD_DIV_CD, 61 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(RNWL_ED_PRD, 62 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(POLHD_CONV_SIC_SBC_YN, 63 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(PLAN_CD, 64 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeTimestamp(INS_BGN_DT, 65 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeString(SBCP_CHN_DIV_CD, 66 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(INS_PRD, 67 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(PY_PRD, 68 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(SETL_PD_DIV_CD, 69 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeTimestamp(TRNS_DTM, 70 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeString(INPPE_ORG_ID, 71 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeTimestamp(SYS_OCC_DTM, 72 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeString(SYS_DEL_DIV_CD, 73 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(OCC_IP, 74 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(APP_ID, 75 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeTimestamp(DATA_CHNG_DTM, 76 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeString(DMG_RT_COV_DCTG_CD, 77 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(CTR_OBJ_ID, 78 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(XCHG_YN, 79 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(NOCV_YN, 80 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(INSPE_GRDE_VAL, 81 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeTimestamp(EIH_LDG_DTM, 82 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeString(MOM_COV_CD, 83 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(ACCM_COV_CD, 84 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(BTH_AF_COV_CD, 85 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(COV_SBC_AMT, 86 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(ACCM_SBC_AMT, 87 + __off, 2, __dbStmt);
  }
  public void readFields(DataInput __dataIn) throws IOException {
this.readFields0(__dataIn);  }
  public void readFields0(DataInput __dataIn) throws IOException {
    if (__dataIn.readBoolean()) { 
        this.CTR_COV_ID = null;
    } else {
    this.CTR_COV_ID = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.PRCTR_NO = null;
    } else {
    this.PRCTR_NO = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.SBCP_DT = null;
    } else {
    this.SBCP_DT = new Timestamp(__dataIn.readLong());
    this.SBCP_DT.setNanos(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.UNT_PD_CD = null;
    } else {
    this.UNT_PD_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.COV_CD = null;
    } else {
    this.COV_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.CLF_DIV_CD = null;
    } else {
    this.CLF_DIV_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.INS_SBC_SH_CD = null;
    } else {
    this.INS_SBC_SH_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.TRTPE_ORG_CD = null;
    } else {
    this.TRTPE_ORG_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.HDQT_ORG_CD = null;
    } else {
    this.HDQT_ORG_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.BCH_ORG_CD = null;
    } else {
    this.BCH_ORG_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.CHN_DIV_CD = null;
    } else {
    this.CHN_DIV_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.FEE_PAY_TP_CD = null;
    } else {
    this.FEE_PAY_TP_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.OWN_CTR_YN = null;
    } else {
    this.OWN_CTR_YN = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.JOB_GRD_CD = null;
    } else {
    this.JOB_GRD_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.MNCL_MD_CD = null;
    } else {
    this.MNCL_MD_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.BAS_SIC_DIV_CD = null;
    } else {
    this.BAS_SIC_DIV_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.INS_AGE = null;
    } else {
    this.INS_AGE = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.COV_FRS_SBC_AGE = null;
    } else {
    this.COV_FRS_SBC_AGE = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.GNDR_CD = null;
    } else {
    this.GNDR_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.COV_INS_PRD_TP_CD = null;
    } else {
    this.COV_INS_PRD_TP_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.COV_INS_PRD = null;
    } else {
    this.COV_INS_PRD = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.COV_PY_PRD_TP_CD = null;
    } else {
    this.COV_PY_PRD_TP_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.COV_PY_PRD = null;
    } else {
    this.COV_PY_PRD = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.BAS_PREM = null;
    } else {
    this.BAS_PREM = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.SLZ_PREM = null;
    } else {
    this.SLZ_PREM = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.YYPY_CNVS_BAS_PREM = null;
    } else {
    this.YYPY_CNVS_BAS_PREM = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.YYPY_CNVS_SLZ_PREM = null;
    } else {
    this.YYPY_CNVS_SLZ_PREM = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.PY_CYC_CD = null;
    } else {
    this.PY_CYC_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.INSD_AMT = null;
    } else {
    this.INSD_AMT = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.STD_SBC_AMT = null;
    } else {
    this.STD_SBC_AMT = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.COV_INS_BGN_DT = null;
    } else {
    this.COV_INS_BGN_DT = new Timestamp(__dataIn.readLong());
    this.COV_INS_BGN_DT.setNanos(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.RKEY_CNFG_CHT_VAL = null;
    } else {
    this.RKEY_CNFG_CHT_VAL = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RDY_AMT_TRM_VAL1 = null;
    } else {
    this.RDY_AMT_TRM_VAL1 = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RDY_AMT_TRM_VAL2 = null;
    } else {
    this.RDY_AMT_TRM_VAL2 = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RDY_AMT_TRM_VAL3 = null;
    } else {
    this.RDY_AMT_TRM_VAL3 = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RDY_AMT_TRM_VAL4 = null;
    } else {
    this.RDY_AMT_TRM_VAL4 = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RDY_AMT_TRM_VAL5 = null;
    } else {
    this.RDY_AMT_TRM_VAL5 = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RDY_AMT_TRM_VAL6 = null;
    } else {
    this.RDY_AMT_TRM_VAL6 = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RDY_AMT_TRM_VAL7 = null;
    } else {
    this.RDY_AMT_TRM_VAL7 = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RDY_AMT_TRM_VAL8 = null;
    } else {
    this.RDY_AMT_TRM_VAL8 = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RDY_AMT_TRM_VAL9 = null;
    } else {
    this.RDY_AMT_TRM_VAL9 = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RDY_AMT_TRM_VAL10 = null;
    } else {
    this.RDY_AMT_TRM_VAL10 = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RDY_AMT_TRM_VAL11 = null;
    } else {
    this.RDY_AMT_TRM_VAL11 = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RDY_AMT_TRM_VAL12 = null;
    } else {
    this.RDY_AMT_TRM_VAL12 = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RDY_AMT_TRM_VAL13 = null;
    } else {
    this.RDY_AMT_TRM_VAL13 = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RDY_AMT_TRM_VAL14 = null;
    } else {
    this.RDY_AMT_TRM_VAL14 = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RDY_AMT_TRM_VAL15 = null;
    } else {
    this.RDY_AMT_TRM_VAL15 = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.DIVD_YN = null;
    } else {
    this.DIVD_YN = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.ANN_PAY_CYC_CD = null;
    } else {
    this.ANN_PAY_CYC_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.ANN_PAY_PRD_CD = null;
    } else {
    this.ANN_PAY_PRD_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.ANN_PAY_SH_CD = null;
    } else {
    this.ANN_PAY_SH_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.ANN_PAY_ST_AGE = null;
    } else {
    this.ANN_PAY_ST_AGE = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.GURT_ACU_DIV_CD = null;
    } else {
    this.GURT_ACU_DIV_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.NEGA_GRP_CD = null;
    } else {
    this.NEGA_GRP_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.COV_SMT_CTG_CD = null;
    } else {
    this.COV_SMT_CTG_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.XCHG_INDX = null;
    } else {
    this.XCHG_INDX = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.DC_XCHG_CF = null;
    } else {
    this.DC_XCHG_CF = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RNWL_COV_CYC_CD = null;
    } else {
    this.RNWL_COV_CYC_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RNWL_ED_AGE = null;
    } else {
    this.RNWL_ED_AGE = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RNWL_ED_DT = null;
    } else {
    this.RNWL_ED_DT = new Timestamp(__dataIn.readLong());
    this.RNWL_ED_DT.setNanos(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.RNWL_ED_PRD_DIV_CD = null;
    } else {
    this.RNWL_ED_PRD_DIV_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RNWL_ED_PRD = null;
    } else {
    this.RNWL_ED_PRD = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.POLHD_CONV_SIC_SBC_YN = null;
    } else {
    this.POLHD_CONV_SIC_SBC_YN = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.PLAN_CD = null;
    } else {
    this.PLAN_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.INS_BGN_DT = null;
    } else {
    this.INS_BGN_DT = new Timestamp(__dataIn.readLong());
    this.INS_BGN_DT.setNanos(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.SBCP_CHN_DIV_CD = null;
    } else {
    this.SBCP_CHN_DIV_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.INS_PRD = null;
    } else {
    this.INS_PRD = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.PY_PRD = null;
    } else {
    this.PY_PRD = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.SETL_PD_DIV_CD = null;
    } else {
    this.SETL_PD_DIV_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.TRNS_DTM = null;
    } else {
    this.TRNS_DTM = new Timestamp(__dataIn.readLong());
    this.TRNS_DTM.setNanos(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.INPPE_ORG_ID = null;
    } else {
    this.INPPE_ORG_ID = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.SYS_OCC_DTM = null;
    } else {
    this.SYS_OCC_DTM = new Timestamp(__dataIn.readLong());
    this.SYS_OCC_DTM.setNanos(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.SYS_DEL_DIV_CD = null;
    } else {
    this.SYS_DEL_DIV_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.OCC_IP = null;
    } else {
    this.OCC_IP = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.APP_ID = null;
    } else {
    this.APP_ID = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.DATA_CHNG_DTM = null;
    } else {
    this.DATA_CHNG_DTM = new Timestamp(__dataIn.readLong());
    this.DATA_CHNG_DTM.setNanos(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.DMG_RT_COV_DCTG_CD = null;
    } else {
    this.DMG_RT_COV_DCTG_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.CTR_OBJ_ID = null;
    } else {
    this.CTR_OBJ_ID = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.XCHG_YN = null;
    } else {
    this.XCHG_YN = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.NOCV_YN = null;
    } else {
    this.NOCV_YN = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.INSPE_GRDE_VAL = null;
    } else {
    this.INSPE_GRDE_VAL = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.EIH_LDG_DTM = null;
    } else {
    this.EIH_LDG_DTM = new Timestamp(__dataIn.readLong());
    this.EIH_LDG_DTM.setNanos(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.MOM_COV_CD = null;
    } else {
    this.MOM_COV_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.ACCM_COV_CD = null;
    } else {
    this.ACCM_COV_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.BTH_AF_COV_CD = null;
    } else {
    this.BTH_AF_COV_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.COV_SBC_AMT = null;
    } else {
    this.COV_SBC_AMT = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.ACCM_SBC_AMT = null;
    } else {
    this.ACCM_SBC_AMT = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
  }
  public void write(DataOutput __dataOut) throws IOException {
    if (null == this.CTR_COV_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CTR_COV_ID);
    }
    if (null == this.PRCTR_NO) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, PRCTR_NO);
    }
    if (null == this.SBCP_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.SBCP_DT.getTime());
    __dataOut.writeInt(this.SBCP_DT.getNanos());
    }
    if (null == this.UNT_PD_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, UNT_PD_CD);
    }
    if (null == this.COV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, COV_CD);
    }
    if (null == this.CLF_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CLF_DIV_CD);
    }
    if (null == this.INS_SBC_SH_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, INS_SBC_SH_CD);
    }
    if (null == this.TRTPE_ORG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, TRTPE_ORG_CD);
    }
    if (null == this.HDQT_ORG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, HDQT_ORG_CD);
    }
    if (null == this.BCH_ORG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, BCH_ORG_CD);
    }
    if (null == this.CHN_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CHN_DIV_CD);
    }
    if (null == this.FEE_PAY_TP_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, FEE_PAY_TP_CD);
    }
    if (null == this.OWN_CTR_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, OWN_CTR_YN);
    }
    if (null == this.JOB_GRD_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, JOB_GRD_CD);
    }
    if (null == this.MNCL_MD_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, MNCL_MD_CD);
    }
    if (null == this.BAS_SIC_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, BAS_SIC_DIV_CD);
    }
    if (null == this.INS_AGE) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.INS_AGE, __dataOut);
    }
    if (null == this.COV_FRS_SBC_AGE) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.COV_FRS_SBC_AGE, __dataOut);
    }
    if (null == this.GNDR_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, GNDR_CD);
    }
    if (null == this.COV_INS_PRD_TP_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, COV_INS_PRD_TP_CD);
    }
    if (null == this.COV_INS_PRD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.COV_INS_PRD, __dataOut);
    }
    if (null == this.COV_PY_PRD_TP_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, COV_PY_PRD_TP_CD);
    }
    if (null == this.COV_PY_PRD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.COV_PY_PRD, __dataOut);
    }
    if (null == this.BAS_PREM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.BAS_PREM, __dataOut);
    }
    if (null == this.SLZ_PREM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.SLZ_PREM, __dataOut);
    }
    if (null == this.YYPY_CNVS_BAS_PREM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.YYPY_CNVS_BAS_PREM, __dataOut);
    }
    if (null == this.YYPY_CNVS_SLZ_PREM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.YYPY_CNVS_SLZ_PREM, __dataOut);
    }
    if (null == this.PY_CYC_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, PY_CYC_CD);
    }
    if (null == this.INSD_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.INSD_AMT, __dataOut);
    }
    if (null == this.STD_SBC_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.STD_SBC_AMT, __dataOut);
    }
    if (null == this.COV_INS_BGN_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.COV_INS_BGN_DT.getTime());
    __dataOut.writeInt(this.COV_INS_BGN_DT.getNanos());
    }
    if (null == this.RKEY_CNFG_CHT_VAL) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RKEY_CNFG_CHT_VAL);
    }
    if (null == this.RDY_AMT_TRM_VAL1) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RDY_AMT_TRM_VAL1);
    }
    if (null == this.RDY_AMT_TRM_VAL2) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RDY_AMT_TRM_VAL2);
    }
    if (null == this.RDY_AMT_TRM_VAL3) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RDY_AMT_TRM_VAL3);
    }
    if (null == this.RDY_AMT_TRM_VAL4) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RDY_AMT_TRM_VAL4);
    }
    if (null == this.RDY_AMT_TRM_VAL5) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RDY_AMT_TRM_VAL5);
    }
    if (null == this.RDY_AMT_TRM_VAL6) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RDY_AMT_TRM_VAL6);
    }
    if (null == this.RDY_AMT_TRM_VAL7) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RDY_AMT_TRM_VAL7);
    }
    if (null == this.RDY_AMT_TRM_VAL8) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RDY_AMT_TRM_VAL8);
    }
    if (null == this.RDY_AMT_TRM_VAL9) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RDY_AMT_TRM_VAL9);
    }
    if (null == this.RDY_AMT_TRM_VAL10) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RDY_AMT_TRM_VAL10);
    }
    if (null == this.RDY_AMT_TRM_VAL11) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RDY_AMT_TRM_VAL11);
    }
    if (null == this.RDY_AMT_TRM_VAL12) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RDY_AMT_TRM_VAL12);
    }
    if (null == this.RDY_AMT_TRM_VAL13) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RDY_AMT_TRM_VAL13);
    }
    if (null == this.RDY_AMT_TRM_VAL14) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RDY_AMT_TRM_VAL14);
    }
    if (null == this.RDY_AMT_TRM_VAL15) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RDY_AMT_TRM_VAL15);
    }
    if (null == this.DIVD_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, DIVD_YN);
    }
    if (null == this.ANN_PAY_CYC_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ANN_PAY_CYC_CD);
    }
    if (null == this.ANN_PAY_PRD_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ANN_PAY_PRD_CD);
    }
    if (null == this.ANN_PAY_SH_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ANN_PAY_SH_CD);
    }
    if (null == this.ANN_PAY_ST_AGE) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.ANN_PAY_ST_AGE, __dataOut);
    }
    if (null == this.GURT_ACU_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, GURT_ACU_DIV_CD);
    }
    if (null == this.NEGA_GRP_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, NEGA_GRP_CD);
    }
    if (null == this.COV_SMT_CTG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, COV_SMT_CTG_CD);
    }
    if (null == this.XCHG_INDX) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.XCHG_INDX, __dataOut);
    }
    if (null == this.DC_XCHG_CF) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.DC_XCHG_CF, __dataOut);
    }
    if (null == this.RNWL_COV_CYC_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RNWL_COV_CYC_CD);
    }
    if (null == this.RNWL_ED_AGE) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.RNWL_ED_AGE, __dataOut);
    }
    if (null == this.RNWL_ED_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.RNWL_ED_DT.getTime());
    __dataOut.writeInt(this.RNWL_ED_DT.getNanos());
    }
    if (null == this.RNWL_ED_PRD_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RNWL_ED_PRD_DIV_CD);
    }
    if (null == this.RNWL_ED_PRD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.RNWL_ED_PRD, __dataOut);
    }
    if (null == this.POLHD_CONV_SIC_SBC_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, POLHD_CONV_SIC_SBC_YN);
    }
    if (null == this.PLAN_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, PLAN_CD);
    }
    if (null == this.INS_BGN_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.INS_BGN_DT.getTime());
    __dataOut.writeInt(this.INS_BGN_DT.getNanos());
    }
    if (null == this.SBCP_CHN_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, SBCP_CHN_DIV_CD);
    }
    if (null == this.INS_PRD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.INS_PRD, __dataOut);
    }
    if (null == this.PY_PRD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.PY_PRD, __dataOut);
    }
    if (null == this.SETL_PD_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, SETL_PD_DIV_CD);
    }
    if (null == this.TRNS_DTM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.TRNS_DTM.getTime());
    __dataOut.writeInt(this.TRNS_DTM.getNanos());
    }
    if (null == this.INPPE_ORG_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, INPPE_ORG_ID);
    }
    if (null == this.SYS_OCC_DTM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.SYS_OCC_DTM.getTime());
    __dataOut.writeInt(this.SYS_OCC_DTM.getNanos());
    }
    if (null == this.SYS_DEL_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, SYS_DEL_DIV_CD);
    }
    if (null == this.OCC_IP) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, OCC_IP);
    }
    if (null == this.APP_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, APP_ID);
    }
    if (null == this.DATA_CHNG_DTM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.DATA_CHNG_DTM.getTime());
    __dataOut.writeInt(this.DATA_CHNG_DTM.getNanos());
    }
    if (null == this.DMG_RT_COV_DCTG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, DMG_RT_COV_DCTG_CD);
    }
    if (null == this.CTR_OBJ_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CTR_OBJ_ID);
    }
    if (null == this.XCHG_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, XCHG_YN);
    }
    if (null == this.NOCV_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, NOCV_YN);
    }
    if (null == this.INSPE_GRDE_VAL) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, INSPE_GRDE_VAL);
    }
    if (null == this.EIH_LDG_DTM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.EIH_LDG_DTM.getTime());
    __dataOut.writeInt(this.EIH_LDG_DTM.getNanos());
    }
    if (null == this.MOM_COV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, MOM_COV_CD);
    }
    if (null == this.ACCM_COV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ACCM_COV_CD);
    }
    if (null == this.BTH_AF_COV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, BTH_AF_COV_CD);
    }
    if (null == this.COV_SBC_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.COV_SBC_AMT, __dataOut);
    }
    if (null == this.ACCM_SBC_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.ACCM_SBC_AMT, __dataOut);
    }
  }
  public void write0(DataOutput __dataOut) throws IOException {
    if (null == this.CTR_COV_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CTR_COV_ID);
    }
    if (null == this.PRCTR_NO) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, PRCTR_NO);
    }
    if (null == this.SBCP_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.SBCP_DT.getTime());
    __dataOut.writeInt(this.SBCP_DT.getNanos());
    }
    if (null == this.UNT_PD_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, UNT_PD_CD);
    }
    if (null == this.COV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, COV_CD);
    }
    if (null == this.CLF_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CLF_DIV_CD);
    }
    if (null == this.INS_SBC_SH_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, INS_SBC_SH_CD);
    }
    if (null == this.TRTPE_ORG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, TRTPE_ORG_CD);
    }
    if (null == this.HDQT_ORG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, HDQT_ORG_CD);
    }
    if (null == this.BCH_ORG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, BCH_ORG_CD);
    }
    if (null == this.CHN_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CHN_DIV_CD);
    }
    if (null == this.FEE_PAY_TP_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, FEE_PAY_TP_CD);
    }
    if (null == this.OWN_CTR_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, OWN_CTR_YN);
    }
    if (null == this.JOB_GRD_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, JOB_GRD_CD);
    }
    if (null == this.MNCL_MD_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, MNCL_MD_CD);
    }
    if (null == this.BAS_SIC_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, BAS_SIC_DIV_CD);
    }
    if (null == this.INS_AGE) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.INS_AGE, __dataOut);
    }
    if (null == this.COV_FRS_SBC_AGE) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.COV_FRS_SBC_AGE, __dataOut);
    }
    if (null == this.GNDR_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, GNDR_CD);
    }
    if (null == this.COV_INS_PRD_TP_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, COV_INS_PRD_TP_CD);
    }
    if (null == this.COV_INS_PRD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.COV_INS_PRD, __dataOut);
    }
    if (null == this.COV_PY_PRD_TP_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, COV_PY_PRD_TP_CD);
    }
    if (null == this.COV_PY_PRD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.COV_PY_PRD, __dataOut);
    }
    if (null == this.BAS_PREM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.BAS_PREM, __dataOut);
    }
    if (null == this.SLZ_PREM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.SLZ_PREM, __dataOut);
    }
    if (null == this.YYPY_CNVS_BAS_PREM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.YYPY_CNVS_BAS_PREM, __dataOut);
    }
    if (null == this.YYPY_CNVS_SLZ_PREM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.YYPY_CNVS_SLZ_PREM, __dataOut);
    }
    if (null == this.PY_CYC_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, PY_CYC_CD);
    }
    if (null == this.INSD_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.INSD_AMT, __dataOut);
    }
    if (null == this.STD_SBC_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.STD_SBC_AMT, __dataOut);
    }
    if (null == this.COV_INS_BGN_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.COV_INS_BGN_DT.getTime());
    __dataOut.writeInt(this.COV_INS_BGN_DT.getNanos());
    }
    if (null == this.RKEY_CNFG_CHT_VAL) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RKEY_CNFG_CHT_VAL);
    }
    if (null == this.RDY_AMT_TRM_VAL1) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RDY_AMT_TRM_VAL1);
    }
    if (null == this.RDY_AMT_TRM_VAL2) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RDY_AMT_TRM_VAL2);
    }
    if (null == this.RDY_AMT_TRM_VAL3) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RDY_AMT_TRM_VAL3);
    }
    if (null == this.RDY_AMT_TRM_VAL4) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RDY_AMT_TRM_VAL4);
    }
    if (null == this.RDY_AMT_TRM_VAL5) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RDY_AMT_TRM_VAL5);
    }
    if (null == this.RDY_AMT_TRM_VAL6) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RDY_AMT_TRM_VAL6);
    }
    if (null == this.RDY_AMT_TRM_VAL7) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RDY_AMT_TRM_VAL7);
    }
    if (null == this.RDY_AMT_TRM_VAL8) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RDY_AMT_TRM_VAL8);
    }
    if (null == this.RDY_AMT_TRM_VAL9) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RDY_AMT_TRM_VAL9);
    }
    if (null == this.RDY_AMT_TRM_VAL10) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RDY_AMT_TRM_VAL10);
    }
    if (null == this.RDY_AMT_TRM_VAL11) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RDY_AMT_TRM_VAL11);
    }
    if (null == this.RDY_AMT_TRM_VAL12) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RDY_AMT_TRM_VAL12);
    }
    if (null == this.RDY_AMT_TRM_VAL13) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RDY_AMT_TRM_VAL13);
    }
    if (null == this.RDY_AMT_TRM_VAL14) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RDY_AMT_TRM_VAL14);
    }
    if (null == this.RDY_AMT_TRM_VAL15) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RDY_AMT_TRM_VAL15);
    }
    if (null == this.DIVD_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, DIVD_YN);
    }
    if (null == this.ANN_PAY_CYC_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ANN_PAY_CYC_CD);
    }
    if (null == this.ANN_PAY_PRD_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ANN_PAY_PRD_CD);
    }
    if (null == this.ANN_PAY_SH_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ANN_PAY_SH_CD);
    }
    if (null == this.ANN_PAY_ST_AGE) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.ANN_PAY_ST_AGE, __dataOut);
    }
    if (null == this.GURT_ACU_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, GURT_ACU_DIV_CD);
    }
    if (null == this.NEGA_GRP_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, NEGA_GRP_CD);
    }
    if (null == this.COV_SMT_CTG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, COV_SMT_CTG_CD);
    }
    if (null == this.XCHG_INDX) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.XCHG_INDX, __dataOut);
    }
    if (null == this.DC_XCHG_CF) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.DC_XCHG_CF, __dataOut);
    }
    if (null == this.RNWL_COV_CYC_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RNWL_COV_CYC_CD);
    }
    if (null == this.RNWL_ED_AGE) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.RNWL_ED_AGE, __dataOut);
    }
    if (null == this.RNWL_ED_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.RNWL_ED_DT.getTime());
    __dataOut.writeInt(this.RNWL_ED_DT.getNanos());
    }
    if (null == this.RNWL_ED_PRD_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RNWL_ED_PRD_DIV_CD);
    }
    if (null == this.RNWL_ED_PRD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.RNWL_ED_PRD, __dataOut);
    }
    if (null == this.POLHD_CONV_SIC_SBC_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, POLHD_CONV_SIC_SBC_YN);
    }
    if (null == this.PLAN_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, PLAN_CD);
    }
    if (null == this.INS_BGN_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.INS_BGN_DT.getTime());
    __dataOut.writeInt(this.INS_BGN_DT.getNanos());
    }
    if (null == this.SBCP_CHN_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, SBCP_CHN_DIV_CD);
    }
    if (null == this.INS_PRD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.INS_PRD, __dataOut);
    }
    if (null == this.PY_PRD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.PY_PRD, __dataOut);
    }
    if (null == this.SETL_PD_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, SETL_PD_DIV_CD);
    }
    if (null == this.TRNS_DTM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.TRNS_DTM.getTime());
    __dataOut.writeInt(this.TRNS_DTM.getNanos());
    }
    if (null == this.INPPE_ORG_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, INPPE_ORG_ID);
    }
    if (null == this.SYS_OCC_DTM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.SYS_OCC_DTM.getTime());
    __dataOut.writeInt(this.SYS_OCC_DTM.getNanos());
    }
    if (null == this.SYS_DEL_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, SYS_DEL_DIV_CD);
    }
    if (null == this.OCC_IP) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, OCC_IP);
    }
    if (null == this.APP_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, APP_ID);
    }
    if (null == this.DATA_CHNG_DTM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.DATA_CHNG_DTM.getTime());
    __dataOut.writeInt(this.DATA_CHNG_DTM.getNanos());
    }
    if (null == this.DMG_RT_COV_DCTG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, DMG_RT_COV_DCTG_CD);
    }
    if (null == this.CTR_OBJ_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CTR_OBJ_ID);
    }
    if (null == this.XCHG_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, XCHG_YN);
    }
    if (null == this.NOCV_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, NOCV_YN);
    }
    if (null == this.INSPE_GRDE_VAL) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, INSPE_GRDE_VAL);
    }
    if (null == this.EIH_LDG_DTM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.EIH_LDG_DTM.getTime());
    __dataOut.writeInt(this.EIH_LDG_DTM.getNanos());
    }
    if (null == this.MOM_COV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, MOM_COV_CD);
    }
    if (null == this.ACCM_COV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ACCM_COV_CD);
    }
    if (null == this.BTH_AF_COV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, BTH_AF_COV_CD);
    }
    if (null == this.COV_SBC_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.COV_SBC_AMT, __dataOut);
    }
    if (null == this.ACCM_SBC_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.ACCM_SBC_AMT, __dataOut);
    }
  }
  private static final DelimiterSet __outputDelimiters = new DelimiterSet((char) 1, (char) 10, (char) 0, (char) 0, false);
  public String toString() {
    return toString(__outputDelimiters, true);
  }
  public String toString(DelimiterSet delimiters) {
    return toString(delimiters, true);
  }
  public String toString(boolean useRecordDelim) {
    return toString(__outputDelimiters, useRecordDelim);
  }
  public String toString(DelimiterSet delimiters, boolean useRecordDelim) {
    StringBuilder __sb = new StringBuilder();
    char fieldDelim = delimiters.getFieldsTerminatedBy();
    __sb.append(FieldFormatter.escapeAndEnclose(CTR_COV_ID==null?"null":CTR_COV_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PRCTR_NO==null?"null":PRCTR_NO, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SBCP_DT==null?"null":"" + SBCP_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(UNT_PD_CD==null?"null":UNT_PD_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(COV_CD==null?"null":COV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CLF_DIV_CD==null?"null":CLF_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(INS_SBC_SH_CD==null?"null":INS_SBC_SH_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(TRTPE_ORG_CD==null?"null":TRTPE_ORG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(HDQT_ORG_CD==null?"null":HDQT_ORG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(BCH_ORG_CD==null?"null":BCH_ORG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CHN_DIV_CD==null?"null":CHN_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(FEE_PAY_TP_CD==null?"null":FEE_PAY_TP_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(OWN_CTR_YN==null?"null":OWN_CTR_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(JOB_GRD_CD==null?"null":JOB_GRD_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(MNCL_MD_CD==null?"null":MNCL_MD_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(BAS_SIC_DIV_CD==null?"null":BAS_SIC_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(INS_AGE==null?"null":INS_AGE.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(COV_FRS_SBC_AGE==null?"null":COV_FRS_SBC_AGE.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(GNDR_CD==null?"null":GNDR_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(COV_INS_PRD_TP_CD==null?"null":COV_INS_PRD_TP_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(COV_INS_PRD==null?"null":COV_INS_PRD.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(COV_PY_PRD_TP_CD==null?"null":COV_PY_PRD_TP_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(COV_PY_PRD==null?"null":COV_PY_PRD.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(BAS_PREM==null?"null":BAS_PREM.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SLZ_PREM==null?"null":SLZ_PREM.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(YYPY_CNVS_BAS_PREM==null?"null":YYPY_CNVS_BAS_PREM.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(YYPY_CNVS_SLZ_PREM==null?"null":YYPY_CNVS_SLZ_PREM.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PY_CYC_CD==null?"null":PY_CYC_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(INSD_AMT==null?"null":INSD_AMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(STD_SBC_AMT==null?"null":STD_SBC_AMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(COV_INS_BGN_DT==null?"null":"" + COV_INS_BGN_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RKEY_CNFG_CHT_VAL==null?"null":RKEY_CNFG_CHT_VAL, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDY_AMT_TRM_VAL1==null?"null":RDY_AMT_TRM_VAL1, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDY_AMT_TRM_VAL2==null?"null":RDY_AMT_TRM_VAL2, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDY_AMT_TRM_VAL3==null?"null":RDY_AMT_TRM_VAL3, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDY_AMT_TRM_VAL4==null?"null":RDY_AMT_TRM_VAL4, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDY_AMT_TRM_VAL5==null?"null":RDY_AMT_TRM_VAL5, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDY_AMT_TRM_VAL6==null?"null":RDY_AMT_TRM_VAL6, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDY_AMT_TRM_VAL7==null?"null":RDY_AMT_TRM_VAL7, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDY_AMT_TRM_VAL8==null?"null":RDY_AMT_TRM_VAL8, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDY_AMT_TRM_VAL9==null?"null":RDY_AMT_TRM_VAL9, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDY_AMT_TRM_VAL10==null?"null":RDY_AMT_TRM_VAL10, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDY_AMT_TRM_VAL11==null?"null":RDY_AMT_TRM_VAL11, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDY_AMT_TRM_VAL12==null?"null":RDY_AMT_TRM_VAL12, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDY_AMT_TRM_VAL13==null?"null":RDY_AMT_TRM_VAL13, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDY_AMT_TRM_VAL14==null?"null":RDY_AMT_TRM_VAL14, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDY_AMT_TRM_VAL15==null?"null":RDY_AMT_TRM_VAL15, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DIVD_YN==null?"null":DIVD_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ANN_PAY_CYC_CD==null?"null":ANN_PAY_CYC_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ANN_PAY_PRD_CD==null?"null":ANN_PAY_PRD_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ANN_PAY_SH_CD==null?"null":ANN_PAY_SH_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ANN_PAY_ST_AGE==null?"null":ANN_PAY_ST_AGE.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(GURT_ACU_DIV_CD==null?"null":GURT_ACU_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(NEGA_GRP_CD==null?"null":NEGA_GRP_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(COV_SMT_CTG_CD==null?"null":COV_SMT_CTG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(XCHG_INDX==null?"null":XCHG_INDX.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DC_XCHG_CF==null?"null":DC_XCHG_CF.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RNWL_COV_CYC_CD==null?"null":RNWL_COV_CYC_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RNWL_ED_AGE==null?"null":RNWL_ED_AGE.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RNWL_ED_DT==null?"null":"" + RNWL_ED_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RNWL_ED_PRD_DIV_CD==null?"null":RNWL_ED_PRD_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RNWL_ED_PRD==null?"null":RNWL_ED_PRD.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(POLHD_CONV_SIC_SBC_YN==null?"null":POLHD_CONV_SIC_SBC_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PLAN_CD==null?"null":PLAN_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(INS_BGN_DT==null?"null":"" + INS_BGN_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SBCP_CHN_DIV_CD==null?"null":SBCP_CHN_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(INS_PRD==null?"null":INS_PRD.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PY_PRD==null?"null":PY_PRD.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SETL_PD_DIV_CD==null?"null":SETL_PD_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(TRNS_DTM==null?"null":"" + TRNS_DTM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(INPPE_ORG_ID==null?"null":INPPE_ORG_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SYS_OCC_DTM==null?"null":"" + SYS_OCC_DTM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SYS_DEL_DIV_CD==null?"null":SYS_DEL_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(OCC_IP==null?"null":OCC_IP, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(APP_ID==null?"null":APP_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DATA_CHNG_DTM==null?"null":"" + DATA_CHNG_DTM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DMG_RT_COV_DCTG_CD==null?"null":DMG_RT_COV_DCTG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CTR_OBJ_ID==null?"null":CTR_OBJ_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(XCHG_YN==null?"null":XCHG_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(NOCV_YN==null?"null":NOCV_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(INSPE_GRDE_VAL==null?"null":INSPE_GRDE_VAL, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(EIH_LDG_DTM==null?"null":"" + EIH_LDG_DTM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(MOM_COV_CD==null?"null":MOM_COV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ACCM_COV_CD==null?"null":ACCM_COV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(BTH_AF_COV_CD==null?"null":BTH_AF_COV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(COV_SBC_AMT==null?"null":COV_SBC_AMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ACCM_SBC_AMT==null?"null":ACCM_SBC_AMT.toPlainString(), delimiters));
    if (useRecordDelim) {
      __sb.append(delimiters.getLinesTerminatedBy());
    }
    return __sb.toString();
  }
  public void toString0(DelimiterSet delimiters, StringBuilder __sb, char fieldDelim) {
    __sb.append(FieldFormatter.escapeAndEnclose(CTR_COV_ID==null?"null":CTR_COV_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PRCTR_NO==null?"null":PRCTR_NO, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SBCP_DT==null?"null":"" + SBCP_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(UNT_PD_CD==null?"null":UNT_PD_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(COV_CD==null?"null":COV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CLF_DIV_CD==null?"null":CLF_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(INS_SBC_SH_CD==null?"null":INS_SBC_SH_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(TRTPE_ORG_CD==null?"null":TRTPE_ORG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(HDQT_ORG_CD==null?"null":HDQT_ORG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(BCH_ORG_CD==null?"null":BCH_ORG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CHN_DIV_CD==null?"null":CHN_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(FEE_PAY_TP_CD==null?"null":FEE_PAY_TP_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(OWN_CTR_YN==null?"null":OWN_CTR_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(JOB_GRD_CD==null?"null":JOB_GRD_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(MNCL_MD_CD==null?"null":MNCL_MD_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(BAS_SIC_DIV_CD==null?"null":BAS_SIC_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(INS_AGE==null?"null":INS_AGE.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(COV_FRS_SBC_AGE==null?"null":COV_FRS_SBC_AGE.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(GNDR_CD==null?"null":GNDR_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(COV_INS_PRD_TP_CD==null?"null":COV_INS_PRD_TP_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(COV_INS_PRD==null?"null":COV_INS_PRD.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(COV_PY_PRD_TP_CD==null?"null":COV_PY_PRD_TP_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(COV_PY_PRD==null?"null":COV_PY_PRD.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(BAS_PREM==null?"null":BAS_PREM.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SLZ_PREM==null?"null":SLZ_PREM.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(YYPY_CNVS_BAS_PREM==null?"null":YYPY_CNVS_BAS_PREM.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(YYPY_CNVS_SLZ_PREM==null?"null":YYPY_CNVS_SLZ_PREM.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PY_CYC_CD==null?"null":PY_CYC_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(INSD_AMT==null?"null":INSD_AMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(STD_SBC_AMT==null?"null":STD_SBC_AMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(COV_INS_BGN_DT==null?"null":"" + COV_INS_BGN_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RKEY_CNFG_CHT_VAL==null?"null":RKEY_CNFG_CHT_VAL, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDY_AMT_TRM_VAL1==null?"null":RDY_AMT_TRM_VAL1, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDY_AMT_TRM_VAL2==null?"null":RDY_AMT_TRM_VAL2, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDY_AMT_TRM_VAL3==null?"null":RDY_AMT_TRM_VAL3, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDY_AMT_TRM_VAL4==null?"null":RDY_AMT_TRM_VAL4, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDY_AMT_TRM_VAL5==null?"null":RDY_AMT_TRM_VAL5, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDY_AMT_TRM_VAL6==null?"null":RDY_AMT_TRM_VAL6, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDY_AMT_TRM_VAL7==null?"null":RDY_AMT_TRM_VAL7, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDY_AMT_TRM_VAL8==null?"null":RDY_AMT_TRM_VAL8, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDY_AMT_TRM_VAL9==null?"null":RDY_AMT_TRM_VAL9, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDY_AMT_TRM_VAL10==null?"null":RDY_AMT_TRM_VAL10, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDY_AMT_TRM_VAL11==null?"null":RDY_AMT_TRM_VAL11, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDY_AMT_TRM_VAL12==null?"null":RDY_AMT_TRM_VAL12, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDY_AMT_TRM_VAL13==null?"null":RDY_AMT_TRM_VAL13, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDY_AMT_TRM_VAL14==null?"null":RDY_AMT_TRM_VAL14, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RDY_AMT_TRM_VAL15==null?"null":RDY_AMT_TRM_VAL15, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DIVD_YN==null?"null":DIVD_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ANN_PAY_CYC_CD==null?"null":ANN_PAY_CYC_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ANN_PAY_PRD_CD==null?"null":ANN_PAY_PRD_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ANN_PAY_SH_CD==null?"null":ANN_PAY_SH_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ANN_PAY_ST_AGE==null?"null":ANN_PAY_ST_AGE.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(GURT_ACU_DIV_CD==null?"null":GURT_ACU_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(NEGA_GRP_CD==null?"null":NEGA_GRP_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(COV_SMT_CTG_CD==null?"null":COV_SMT_CTG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(XCHG_INDX==null?"null":XCHG_INDX.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DC_XCHG_CF==null?"null":DC_XCHG_CF.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RNWL_COV_CYC_CD==null?"null":RNWL_COV_CYC_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RNWL_ED_AGE==null?"null":RNWL_ED_AGE.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RNWL_ED_DT==null?"null":"" + RNWL_ED_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RNWL_ED_PRD_DIV_CD==null?"null":RNWL_ED_PRD_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RNWL_ED_PRD==null?"null":RNWL_ED_PRD.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(POLHD_CONV_SIC_SBC_YN==null?"null":POLHD_CONV_SIC_SBC_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PLAN_CD==null?"null":PLAN_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(INS_BGN_DT==null?"null":"" + INS_BGN_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SBCP_CHN_DIV_CD==null?"null":SBCP_CHN_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(INS_PRD==null?"null":INS_PRD.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PY_PRD==null?"null":PY_PRD.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SETL_PD_DIV_CD==null?"null":SETL_PD_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(TRNS_DTM==null?"null":"" + TRNS_DTM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(INPPE_ORG_ID==null?"null":INPPE_ORG_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SYS_OCC_DTM==null?"null":"" + SYS_OCC_DTM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SYS_DEL_DIV_CD==null?"null":SYS_DEL_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(OCC_IP==null?"null":OCC_IP, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(APP_ID==null?"null":APP_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DATA_CHNG_DTM==null?"null":"" + DATA_CHNG_DTM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DMG_RT_COV_DCTG_CD==null?"null":DMG_RT_COV_DCTG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CTR_OBJ_ID==null?"null":CTR_OBJ_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(XCHG_YN==null?"null":XCHG_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(NOCV_YN==null?"null":NOCV_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(INSPE_GRDE_VAL==null?"null":INSPE_GRDE_VAL, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(EIH_LDG_DTM==null?"null":"" + EIH_LDG_DTM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(MOM_COV_CD==null?"null":MOM_COV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ACCM_COV_CD==null?"null":ACCM_COV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(BTH_AF_COV_CD==null?"null":BTH_AF_COV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(COV_SBC_AMT==null?"null":COV_SBC_AMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ACCM_SBC_AMT==null?"null":ACCM_SBC_AMT.toPlainString(), delimiters));
  }
  private static final DelimiterSet __inputDelimiters = new DelimiterSet((char) 1, (char) 10, (char) 0, (char) 0, false);
  private RecordParser __parser;
  public void parse(Text __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(CharSequence __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(byte [] __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(char [] __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(ByteBuffer __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(CharBuffer __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  private void __loadFromFields(List<String> fields) {
    Iterator<String> __it = fields.listIterator();
    String __cur_str = null;
    try {
    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CTR_COV_ID = null; } else {
      this.CTR_COV_ID = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.PRCTR_NO = null; } else {
      this.PRCTR_NO = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.SBCP_DT = null; } else {
      this.SBCP_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.UNT_PD_CD = null; } else {
      this.UNT_PD_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.COV_CD = null; } else {
      this.COV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CLF_DIV_CD = null; } else {
      this.CLF_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.INS_SBC_SH_CD = null; } else {
      this.INS_SBC_SH_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.TRTPE_ORG_CD = null; } else {
      this.TRTPE_ORG_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.HDQT_ORG_CD = null; } else {
      this.HDQT_ORG_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.BCH_ORG_CD = null; } else {
      this.BCH_ORG_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CHN_DIV_CD = null; } else {
      this.CHN_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.FEE_PAY_TP_CD = null; } else {
      this.FEE_PAY_TP_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.OWN_CTR_YN = null; } else {
      this.OWN_CTR_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.JOB_GRD_CD = null; } else {
      this.JOB_GRD_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.MNCL_MD_CD = null; } else {
      this.MNCL_MD_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.BAS_SIC_DIV_CD = null; } else {
      this.BAS_SIC_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.INS_AGE = null; } else {
      this.INS_AGE = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.COV_FRS_SBC_AGE = null; } else {
      this.COV_FRS_SBC_AGE = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.GNDR_CD = null; } else {
      this.GNDR_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.COV_INS_PRD_TP_CD = null; } else {
      this.COV_INS_PRD_TP_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.COV_INS_PRD = null; } else {
      this.COV_INS_PRD = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.COV_PY_PRD_TP_CD = null; } else {
      this.COV_PY_PRD_TP_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.COV_PY_PRD = null; } else {
      this.COV_PY_PRD = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.BAS_PREM = null; } else {
      this.BAS_PREM = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.SLZ_PREM = null; } else {
      this.SLZ_PREM = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.YYPY_CNVS_BAS_PREM = null; } else {
      this.YYPY_CNVS_BAS_PREM = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.YYPY_CNVS_SLZ_PREM = null; } else {
      this.YYPY_CNVS_SLZ_PREM = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.PY_CYC_CD = null; } else {
      this.PY_CYC_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.INSD_AMT = null; } else {
      this.INSD_AMT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.STD_SBC_AMT = null; } else {
      this.STD_SBC_AMT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.COV_INS_BGN_DT = null; } else {
      this.COV_INS_BGN_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.RKEY_CNFG_CHT_VAL = null; } else {
      this.RKEY_CNFG_CHT_VAL = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.RDY_AMT_TRM_VAL1 = null; } else {
      this.RDY_AMT_TRM_VAL1 = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.RDY_AMT_TRM_VAL2 = null; } else {
      this.RDY_AMT_TRM_VAL2 = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.RDY_AMT_TRM_VAL3 = null; } else {
      this.RDY_AMT_TRM_VAL3 = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.RDY_AMT_TRM_VAL4 = null; } else {
      this.RDY_AMT_TRM_VAL4 = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.RDY_AMT_TRM_VAL5 = null; } else {
      this.RDY_AMT_TRM_VAL5 = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.RDY_AMT_TRM_VAL6 = null; } else {
      this.RDY_AMT_TRM_VAL6 = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.RDY_AMT_TRM_VAL7 = null; } else {
      this.RDY_AMT_TRM_VAL7 = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.RDY_AMT_TRM_VAL8 = null; } else {
      this.RDY_AMT_TRM_VAL8 = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.RDY_AMT_TRM_VAL9 = null; } else {
      this.RDY_AMT_TRM_VAL9 = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.RDY_AMT_TRM_VAL10 = null; } else {
      this.RDY_AMT_TRM_VAL10 = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.RDY_AMT_TRM_VAL11 = null; } else {
      this.RDY_AMT_TRM_VAL11 = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.RDY_AMT_TRM_VAL12 = null; } else {
      this.RDY_AMT_TRM_VAL12 = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.RDY_AMT_TRM_VAL13 = null; } else {
      this.RDY_AMT_TRM_VAL13 = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.RDY_AMT_TRM_VAL14 = null; } else {
      this.RDY_AMT_TRM_VAL14 = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.RDY_AMT_TRM_VAL15 = null; } else {
      this.RDY_AMT_TRM_VAL15 = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.DIVD_YN = null; } else {
      this.DIVD_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.ANN_PAY_CYC_CD = null; } else {
      this.ANN_PAY_CYC_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.ANN_PAY_PRD_CD = null; } else {
      this.ANN_PAY_PRD_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.ANN_PAY_SH_CD = null; } else {
      this.ANN_PAY_SH_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.ANN_PAY_ST_AGE = null; } else {
      this.ANN_PAY_ST_AGE = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.GURT_ACU_DIV_CD = null; } else {
      this.GURT_ACU_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.NEGA_GRP_CD = null; } else {
      this.NEGA_GRP_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.COV_SMT_CTG_CD = null; } else {
      this.COV_SMT_CTG_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.XCHG_INDX = null; } else {
      this.XCHG_INDX = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.DC_XCHG_CF = null; } else {
      this.DC_XCHG_CF = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.RNWL_COV_CYC_CD = null; } else {
      this.RNWL_COV_CYC_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RNWL_ED_AGE = null; } else {
      this.RNWL_ED_AGE = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RNWL_ED_DT = null; } else {
      this.RNWL_ED_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.RNWL_ED_PRD_DIV_CD = null; } else {
      this.RNWL_ED_PRD_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RNWL_ED_PRD = null; } else {
      this.RNWL_ED_PRD = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.POLHD_CONV_SIC_SBC_YN = null; } else {
      this.POLHD_CONV_SIC_SBC_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.PLAN_CD = null; } else {
      this.PLAN_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.INS_BGN_DT = null; } else {
      this.INS_BGN_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.SBCP_CHN_DIV_CD = null; } else {
      this.SBCP_CHN_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.INS_PRD = null; } else {
      this.INS_PRD = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.PY_PRD = null; } else {
      this.PY_PRD = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.SETL_PD_DIV_CD = null; } else {
      this.SETL_PD_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.TRNS_DTM = null; } else {
      this.TRNS_DTM = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.INPPE_ORG_ID = null; } else {
      this.INPPE_ORG_ID = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.SYS_OCC_DTM = null; } else {
      this.SYS_OCC_DTM = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.SYS_DEL_DIV_CD = null; } else {
      this.SYS_DEL_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.OCC_IP = null; } else {
      this.OCC_IP = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.APP_ID = null; } else {
      this.APP_ID = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.DATA_CHNG_DTM = null; } else {
      this.DATA_CHNG_DTM = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.DMG_RT_COV_DCTG_CD = null; } else {
      this.DMG_RT_COV_DCTG_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CTR_OBJ_ID = null; } else {
      this.CTR_OBJ_ID = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.XCHG_YN = null; } else {
      this.XCHG_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.NOCV_YN = null; } else {
      this.NOCV_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.INSPE_GRDE_VAL = null; } else {
      this.INSPE_GRDE_VAL = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.EIH_LDG_DTM = null; } else {
      this.EIH_LDG_DTM = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.MOM_COV_CD = null; } else {
      this.MOM_COV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.ACCM_COV_CD = null; } else {
      this.ACCM_COV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.BTH_AF_COV_CD = null; } else {
      this.BTH_AF_COV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.COV_SBC_AMT = null; } else {
      this.COV_SBC_AMT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.ACCM_SBC_AMT = null; } else {
      this.ACCM_SBC_AMT = new java.math.BigDecimal(__cur_str);
    }

    } catch (RuntimeException e) {    throw new RuntimeException("Can't parse input data: '" + __cur_str + "'", e);    }  }

  private void __loadFromFields0(Iterator<String> __it) {
    String __cur_str = null;
    try {
    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CTR_COV_ID = null; } else {
      this.CTR_COV_ID = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.PRCTR_NO = null; } else {
      this.PRCTR_NO = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.SBCP_DT = null; } else {
      this.SBCP_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.UNT_PD_CD = null; } else {
      this.UNT_PD_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.COV_CD = null; } else {
      this.COV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CLF_DIV_CD = null; } else {
      this.CLF_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.INS_SBC_SH_CD = null; } else {
      this.INS_SBC_SH_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.TRTPE_ORG_CD = null; } else {
      this.TRTPE_ORG_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.HDQT_ORG_CD = null; } else {
      this.HDQT_ORG_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.BCH_ORG_CD = null; } else {
      this.BCH_ORG_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CHN_DIV_CD = null; } else {
      this.CHN_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.FEE_PAY_TP_CD = null; } else {
      this.FEE_PAY_TP_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.OWN_CTR_YN = null; } else {
      this.OWN_CTR_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.JOB_GRD_CD = null; } else {
      this.JOB_GRD_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.MNCL_MD_CD = null; } else {
      this.MNCL_MD_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.BAS_SIC_DIV_CD = null; } else {
      this.BAS_SIC_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.INS_AGE = null; } else {
      this.INS_AGE = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.COV_FRS_SBC_AGE = null; } else {
      this.COV_FRS_SBC_AGE = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.GNDR_CD = null; } else {
      this.GNDR_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.COV_INS_PRD_TP_CD = null; } else {
      this.COV_INS_PRD_TP_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.COV_INS_PRD = null; } else {
      this.COV_INS_PRD = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.COV_PY_PRD_TP_CD = null; } else {
      this.COV_PY_PRD_TP_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.COV_PY_PRD = null; } else {
      this.COV_PY_PRD = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.BAS_PREM = null; } else {
      this.BAS_PREM = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.SLZ_PREM = null; } else {
      this.SLZ_PREM = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.YYPY_CNVS_BAS_PREM = null; } else {
      this.YYPY_CNVS_BAS_PREM = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.YYPY_CNVS_SLZ_PREM = null; } else {
      this.YYPY_CNVS_SLZ_PREM = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.PY_CYC_CD = null; } else {
      this.PY_CYC_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.INSD_AMT = null; } else {
      this.INSD_AMT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.STD_SBC_AMT = null; } else {
      this.STD_SBC_AMT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.COV_INS_BGN_DT = null; } else {
      this.COV_INS_BGN_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.RKEY_CNFG_CHT_VAL = null; } else {
      this.RKEY_CNFG_CHT_VAL = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.RDY_AMT_TRM_VAL1 = null; } else {
      this.RDY_AMT_TRM_VAL1 = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.RDY_AMT_TRM_VAL2 = null; } else {
      this.RDY_AMT_TRM_VAL2 = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.RDY_AMT_TRM_VAL3 = null; } else {
      this.RDY_AMT_TRM_VAL3 = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.RDY_AMT_TRM_VAL4 = null; } else {
      this.RDY_AMT_TRM_VAL4 = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.RDY_AMT_TRM_VAL5 = null; } else {
      this.RDY_AMT_TRM_VAL5 = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.RDY_AMT_TRM_VAL6 = null; } else {
      this.RDY_AMT_TRM_VAL6 = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.RDY_AMT_TRM_VAL7 = null; } else {
      this.RDY_AMT_TRM_VAL7 = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.RDY_AMT_TRM_VAL8 = null; } else {
      this.RDY_AMT_TRM_VAL8 = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.RDY_AMT_TRM_VAL9 = null; } else {
      this.RDY_AMT_TRM_VAL9 = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.RDY_AMT_TRM_VAL10 = null; } else {
      this.RDY_AMT_TRM_VAL10 = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.RDY_AMT_TRM_VAL11 = null; } else {
      this.RDY_AMT_TRM_VAL11 = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.RDY_AMT_TRM_VAL12 = null; } else {
      this.RDY_AMT_TRM_VAL12 = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.RDY_AMT_TRM_VAL13 = null; } else {
      this.RDY_AMT_TRM_VAL13 = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.RDY_AMT_TRM_VAL14 = null; } else {
      this.RDY_AMT_TRM_VAL14 = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.RDY_AMT_TRM_VAL15 = null; } else {
      this.RDY_AMT_TRM_VAL15 = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.DIVD_YN = null; } else {
      this.DIVD_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.ANN_PAY_CYC_CD = null; } else {
      this.ANN_PAY_CYC_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.ANN_PAY_PRD_CD = null; } else {
      this.ANN_PAY_PRD_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.ANN_PAY_SH_CD = null; } else {
      this.ANN_PAY_SH_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.ANN_PAY_ST_AGE = null; } else {
      this.ANN_PAY_ST_AGE = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.GURT_ACU_DIV_CD = null; } else {
      this.GURT_ACU_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.NEGA_GRP_CD = null; } else {
      this.NEGA_GRP_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.COV_SMT_CTG_CD = null; } else {
      this.COV_SMT_CTG_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.XCHG_INDX = null; } else {
      this.XCHG_INDX = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.DC_XCHG_CF = null; } else {
      this.DC_XCHG_CF = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.RNWL_COV_CYC_CD = null; } else {
      this.RNWL_COV_CYC_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RNWL_ED_AGE = null; } else {
      this.RNWL_ED_AGE = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RNWL_ED_DT = null; } else {
      this.RNWL_ED_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.RNWL_ED_PRD_DIV_CD = null; } else {
      this.RNWL_ED_PRD_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RNWL_ED_PRD = null; } else {
      this.RNWL_ED_PRD = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.POLHD_CONV_SIC_SBC_YN = null; } else {
      this.POLHD_CONV_SIC_SBC_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.PLAN_CD = null; } else {
      this.PLAN_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.INS_BGN_DT = null; } else {
      this.INS_BGN_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.SBCP_CHN_DIV_CD = null; } else {
      this.SBCP_CHN_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.INS_PRD = null; } else {
      this.INS_PRD = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.PY_PRD = null; } else {
      this.PY_PRD = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.SETL_PD_DIV_CD = null; } else {
      this.SETL_PD_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.TRNS_DTM = null; } else {
      this.TRNS_DTM = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.INPPE_ORG_ID = null; } else {
      this.INPPE_ORG_ID = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.SYS_OCC_DTM = null; } else {
      this.SYS_OCC_DTM = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.SYS_DEL_DIV_CD = null; } else {
      this.SYS_DEL_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.OCC_IP = null; } else {
      this.OCC_IP = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.APP_ID = null; } else {
      this.APP_ID = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.DATA_CHNG_DTM = null; } else {
      this.DATA_CHNG_DTM = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.DMG_RT_COV_DCTG_CD = null; } else {
      this.DMG_RT_COV_DCTG_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CTR_OBJ_ID = null; } else {
      this.CTR_OBJ_ID = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.XCHG_YN = null; } else {
      this.XCHG_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.NOCV_YN = null; } else {
      this.NOCV_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.INSPE_GRDE_VAL = null; } else {
      this.INSPE_GRDE_VAL = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.EIH_LDG_DTM = null; } else {
      this.EIH_LDG_DTM = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.MOM_COV_CD = null; } else {
      this.MOM_COV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.ACCM_COV_CD = null; } else {
      this.ACCM_COV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.BTH_AF_COV_CD = null; } else {
      this.BTH_AF_COV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.COV_SBC_AMT = null; } else {
      this.COV_SBC_AMT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.ACCM_SBC_AMT = null; } else {
      this.ACCM_SBC_AMT = new java.math.BigDecimal(__cur_str);
    }

    } catch (RuntimeException e) {    throw new RuntimeException("Can't parse input data: '" + __cur_str + "'", e);    }  }

  public Object clone() throws CloneNotSupportedException {
    QueryResult o = (QueryResult) super.clone();
    o.SBCP_DT = (o.SBCP_DT != null) ? (java.sql.Timestamp) o.SBCP_DT.clone() : null;
    o.COV_INS_BGN_DT = (o.COV_INS_BGN_DT != null) ? (java.sql.Timestamp) o.COV_INS_BGN_DT.clone() : null;
    o.RNWL_ED_DT = (o.RNWL_ED_DT != null) ? (java.sql.Timestamp) o.RNWL_ED_DT.clone() : null;
    o.INS_BGN_DT = (o.INS_BGN_DT != null) ? (java.sql.Timestamp) o.INS_BGN_DT.clone() : null;
    o.TRNS_DTM = (o.TRNS_DTM != null) ? (java.sql.Timestamp) o.TRNS_DTM.clone() : null;
    o.SYS_OCC_DTM = (o.SYS_OCC_DTM != null) ? (java.sql.Timestamp) o.SYS_OCC_DTM.clone() : null;
    o.DATA_CHNG_DTM = (o.DATA_CHNG_DTM != null) ? (java.sql.Timestamp) o.DATA_CHNG_DTM.clone() : null;
    o.EIH_LDG_DTM = (o.EIH_LDG_DTM != null) ? (java.sql.Timestamp) o.EIH_LDG_DTM.clone() : null;
    return o;
  }

  public void clone0(QueryResult o) throws CloneNotSupportedException {
    o.SBCP_DT = (o.SBCP_DT != null) ? (java.sql.Timestamp) o.SBCP_DT.clone() : null;
    o.COV_INS_BGN_DT = (o.COV_INS_BGN_DT != null) ? (java.sql.Timestamp) o.COV_INS_BGN_DT.clone() : null;
    o.RNWL_ED_DT = (o.RNWL_ED_DT != null) ? (java.sql.Timestamp) o.RNWL_ED_DT.clone() : null;
    o.INS_BGN_DT = (o.INS_BGN_DT != null) ? (java.sql.Timestamp) o.INS_BGN_DT.clone() : null;
    o.TRNS_DTM = (o.TRNS_DTM != null) ? (java.sql.Timestamp) o.TRNS_DTM.clone() : null;
    o.SYS_OCC_DTM = (o.SYS_OCC_DTM != null) ? (java.sql.Timestamp) o.SYS_OCC_DTM.clone() : null;
    o.DATA_CHNG_DTM = (o.DATA_CHNG_DTM != null) ? (java.sql.Timestamp) o.DATA_CHNG_DTM.clone() : null;
    o.EIH_LDG_DTM = (o.EIH_LDG_DTM != null) ? (java.sql.Timestamp) o.EIH_LDG_DTM.clone() : null;
  }

  public Map<String, Object> getFieldMap() {
    Map<String, Object> __sqoop$field_map = new HashMap<String, Object>();
    __sqoop$field_map.put("CTR_COV_ID", this.CTR_COV_ID);
    __sqoop$field_map.put("PRCTR_NO", this.PRCTR_NO);
    __sqoop$field_map.put("SBCP_DT", this.SBCP_DT);
    __sqoop$field_map.put("UNT_PD_CD", this.UNT_PD_CD);
    __sqoop$field_map.put("COV_CD", this.COV_CD);
    __sqoop$field_map.put("CLF_DIV_CD", this.CLF_DIV_CD);
    __sqoop$field_map.put("INS_SBC_SH_CD", this.INS_SBC_SH_CD);
    __sqoop$field_map.put("TRTPE_ORG_CD", this.TRTPE_ORG_CD);
    __sqoop$field_map.put("HDQT_ORG_CD", this.HDQT_ORG_CD);
    __sqoop$field_map.put("BCH_ORG_CD", this.BCH_ORG_CD);
    __sqoop$field_map.put("CHN_DIV_CD", this.CHN_DIV_CD);
    __sqoop$field_map.put("FEE_PAY_TP_CD", this.FEE_PAY_TP_CD);
    __sqoop$field_map.put("OWN_CTR_YN", this.OWN_CTR_YN);
    __sqoop$field_map.put("JOB_GRD_CD", this.JOB_GRD_CD);
    __sqoop$field_map.put("MNCL_MD_CD", this.MNCL_MD_CD);
    __sqoop$field_map.put("BAS_SIC_DIV_CD", this.BAS_SIC_DIV_CD);
    __sqoop$field_map.put("INS_AGE", this.INS_AGE);
    __sqoop$field_map.put("COV_FRS_SBC_AGE", this.COV_FRS_SBC_AGE);
    __sqoop$field_map.put("GNDR_CD", this.GNDR_CD);
    __sqoop$field_map.put("COV_INS_PRD_TP_CD", this.COV_INS_PRD_TP_CD);
    __sqoop$field_map.put("COV_INS_PRD", this.COV_INS_PRD);
    __sqoop$field_map.put("COV_PY_PRD_TP_CD", this.COV_PY_PRD_TP_CD);
    __sqoop$field_map.put("COV_PY_PRD", this.COV_PY_PRD);
    __sqoop$field_map.put("BAS_PREM", this.BAS_PREM);
    __sqoop$field_map.put("SLZ_PREM", this.SLZ_PREM);
    __sqoop$field_map.put("YYPY_CNVS_BAS_PREM", this.YYPY_CNVS_BAS_PREM);
    __sqoop$field_map.put("YYPY_CNVS_SLZ_PREM", this.YYPY_CNVS_SLZ_PREM);
    __sqoop$field_map.put("PY_CYC_CD", this.PY_CYC_CD);
    __sqoop$field_map.put("INSD_AMT", this.INSD_AMT);
    __sqoop$field_map.put("STD_SBC_AMT", this.STD_SBC_AMT);
    __sqoop$field_map.put("COV_INS_BGN_DT", this.COV_INS_BGN_DT);
    __sqoop$field_map.put("RKEY_CNFG_CHT_VAL", this.RKEY_CNFG_CHT_VAL);
    __sqoop$field_map.put("RDY_AMT_TRM_VAL1", this.RDY_AMT_TRM_VAL1);
    __sqoop$field_map.put("RDY_AMT_TRM_VAL2", this.RDY_AMT_TRM_VAL2);
    __sqoop$field_map.put("RDY_AMT_TRM_VAL3", this.RDY_AMT_TRM_VAL3);
    __sqoop$field_map.put("RDY_AMT_TRM_VAL4", this.RDY_AMT_TRM_VAL4);
    __sqoop$field_map.put("RDY_AMT_TRM_VAL5", this.RDY_AMT_TRM_VAL5);
    __sqoop$field_map.put("RDY_AMT_TRM_VAL6", this.RDY_AMT_TRM_VAL6);
    __sqoop$field_map.put("RDY_AMT_TRM_VAL7", this.RDY_AMT_TRM_VAL7);
    __sqoop$field_map.put("RDY_AMT_TRM_VAL8", this.RDY_AMT_TRM_VAL8);
    __sqoop$field_map.put("RDY_AMT_TRM_VAL9", this.RDY_AMT_TRM_VAL9);
    __sqoop$field_map.put("RDY_AMT_TRM_VAL10", this.RDY_AMT_TRM_VAL10);
    __sqoop$field_map.put("RDY_AMT_TRM_VAL11", this.RDY_AMT_TRM_VAL11);
    __sqoop$field_map.put("RDY_AMT_TRM_VAL12", this.RDY_AMT_TRM_VAL12);
    __sqoop$field_map.put("RDY_AMT_TRM_VAL13", this.RDY_AMT_TRM_VAL13);
    __sqoop$field_map.put("RDY_AMT_TRM_VAL14", this.RDY_AMT_TRM_VAL14);
    __sqoop$field_map.put("RDY_AMT_TRM_VAL15", this.RDY_AMT_TRM_VAL15);
    __sqoop$field_map.put("DIVD_YN", this.DIVD_YN);
    __sqoop$field_map.put("ANN_PAY_CYC_CD", this.ANN_PAY_CYC_CD);
    __sqoop$field_map.put("ANN_PAY_PRD_CD", this.ANN_PAY_PRD_CD);
    __sqoop$field_map.put("ANN_PAY_SH_CD", this.ANN_PAY_SH_CD);
    __sqoop$field_map.put("ANN_PAY_ST_AGE", this.ANN_PAY_ST_AGE);
    __sqoop$field_map.put("GURT_ACU_DIV_CD", this.GURT_ACU_DIV_CD);
    __sqoop$field_map.put("NEGA_GRP_CD", this.NEGA_GRP_CD);
    __sqoop$field_map.put("COV_SMT_CTG_CD", this.COV_SMT_CTG_CD);
    __sqoop$field_map.put("XCHG_INDX", this.XCHG_INDX);
    __sqoop$field_map.put("DC_XCHG_CF", this.DC_XCHG_CF);
    __sqoop$field_map.put("RNWL_COV_CYC_CD", this.RNWL_COV_CYC_CD);
    __sqoop$field_map.put("RNWL_ED_AGE", this.RNWL_ED_AGE);
    __sqoop$field_map.put("RNWL_ED_DT", this.RNWL_ED_DT);
    __sqoop$field_map.put("RNWL_ED_PRD_DIV_CD", this.RNWL_ED_PRD_DIV_CD);
    __sqoop$field_map.put("RNWL_ED_PRD", this.RNWL_ED_PRD);
    __sqoop$field_map.put("POLHD_CONV_SIC_SBC_YN", this.POLHD_CONV_SIC_SBC_YN);
    __sqoop$field_map.put("PLAN_CD", this.PLAN_CD);
    __sqoop$field_map.put("INS_BGN_DT", this.INS_BGN_DT);
    __sqoop$field_map.put("SBCP_CHN_DIV_CD", this.SBCP_CHN_DIV_CD);
    __sqoop$field_map.put("INS_PRD", this.INS_PRD);
    __sqoop$field_map.put("PY_PRD", this.PY_PRD);
    __sqoop$field_map.put("SETL_PD_DIV_CD", this.SETL_PD_DIV_CD);
    __sqoop$field_map.put("TRNS_DTM", this.TRNS_DTM);
    __sqoop$field_map.put("INPPE_ORG_ID", this.INPPE_ORG_ID);
    __sqoop$field_map.put("SYS_OCC_DTM", this.SYS_OCC_DTM);
    __sqoop$field_map.put("SYS_DEL_DIV_CD", this.SYS_DEL_DIV_CD);
    __sqoop$field_map.put("OCC_IP", this.OCC_IP);
    __sqoop$field_map.put("APP_ID", this.APP_ID);
    __sqoop$field_map.put("DATA_CHNG_DTM", this.DATA_CHNG_DTM);
    __sqoop$field_map.put("DMG_RT_COV_DCTG_CD", this.DMG_RT_COV_DCTG_CD);
    __sqoop$field_map.put("CTR_OBJ_ID", this.CTR_OBJ_ID);
    __sqoop$field_map.put("XCHG_YN", this.XCHG_YN);
    __sqoop$field_map.put("NOCV_YN", this.NOCV_YN);
    __sqoop$field_map.put("INSPE_GRDE_VAL", this.INSPE_GRDE_VAL);
    __sqoop$field_map.put("EIH_LDG_DTM", this.EIH_LDG_DTM);
    __sqoop$field_map.put("MOM_COV_CD", this.MOM_COV_CD);
    __sqoop$field_map.put("ACCM_COV_CD", this.ACCM_COV_CD);
    __sqoop$field_map.put("BTH_AF_COV_CD", this.BTH_AF_COV_CD);
    __sqoop$field_map.put("COV_SBC_AMT", this.COV_SBC_AMT);
    __sqoop$field_map.put("ACCM_SBC_AMT", this.ACCM_SBC_AMT);
    return __sqoop$field_map;
  }

  public void getFieldMap0(Map<String, Object> __sqoop$field_map) {
    __sqoop$field_map.put("CTR_COV_ID", this.CTR_COV_ID);
    __sqoop$field_map.put("PRCTR_NO", this.PRCTR_NO);
    __sqoop$field_map.put("SBCP_DT", this.SBCP_DT);
    __sqoop$field_map.put("UNT_PD_CD", this.UNT_PD_CD);
    __sqoop$field_map.put("COV_CD", this.COV_CD);
    __sqoop$field_map.put("CLF_DIV_CD", this.CLF_DIV_CD);
    __sqoop$field_map.put("INS_SBC_SH_CD", this.INS_SBC_SH_CD);
    __sqoop$field_map.put("TRTPE_ORG_CD", this.TRTPE_ORG_CD);
    __sqoop$field_map.put("HDQT_ORG_CD", this.HDQT_ORG_CD);
    __sqoop$field_map.put("BCH_ORG_CD", this.BCH_ORG_CD);
    __sqoop$field_map.put("CHN_DIV_CD", this.CHN_DIV_CD);
    __sqoop$field_map.put("FEE_PAY_TP_CD", this.FEE_PAY_TP_CD);
    __sqoop$field_map.put("OWN_CTR_YN", this.OWN_CTR_YN);
    __sqoop$field_map.put("JOB_GRD_CD", this.JOB_GRD_CD);
    __sqoop$field_map.put("MNCL_MD_CD", this.MNCL_MD_CD);
    __sqoop$field_map.put("BAS_SIC_DIV_CD", this.BAS_SIC_DIV_CD);
    __sqoop$field_map.put("INS_AGE", this.INS_AGE);
    __sqoop$field_map.put("COV_FRS_SBC_AGE", this.COV_FRS_SBC_AGE);
    __sqoop$field_map.put("GNDR_CD", this.GNDR_CD);
    __sqoop$field_map.put("COV_INS_PRD_TP_CD", this.COV_INS_PRD_TP_CD);
    __sqoop$field_map.put("COV_INS_PRD", this.COV_INS_PRD);
    __sqoop$field_map.put("COV_PY_PRD_TP_CD", this.COV_PY_PRD_TP_CD);
    __sqoop$field_map.put("COV_PY_PRD", this.COV_PY_PRD);
    __sqoop$field_map.put("BAS_PREM", this.BAS_PREM);
    __sqoop$field_map.put("SLZ_PREM", this.SLZ_PREM);
    __sqoop$field_map.put("YYPY_CNVS_BAS_PREM", this.YYPY_CNVS_BAS_PREM);
    __sqoop$field_map.put("YYPY_CNVS_SLZ_PREM", this.YYPY_CNVS_SLZ_PREM);
    __sqoop$field_map.put("PY_CYC_CD", this.PY_CYC_CD);
    __sqoop$field_map.put("INSD_AMT", this.INSD_AMT);
    __sqoop$field_map.put("STD_SBC_AMT", this.STD_SBC_AMT);
    __sqoop$field_map.put("COV_INS_BGN_DT", this.COV_INS_BGN_DT);
    __sqoop$field_map.put("RKEY_CNFG_CHT_VAL", this.RKEY_CNFG_CHT_VAL);
    __sqoop$field_map.put("RDY_AMT_TRM_VAL1", this.RDY_AMT_TRM_VAL1);
    __sqoop$field_map.put("RDY_AMT_TRM_VAL2", this.RDY_AMT_TRM_VAL2);
    __sqoop$field_map.put("RDY_AMT_TRM_VAL3", this.RDY_AMT_TRM_VAL3);
    __sqoop$field_map.put("RDY_AMT_TRM_VAL4", this.RDY_AMT_TRM_VAL4);
    __sqoop$field_map.put("RDY_AMT_TRM_VAL5", this.RDY_AMT_TRM_VAL5);
    __sqoop$field_map.put("RDY_AMT_TRM_VAL6", this.RDY_AMT_TRM_VAL6);
    __sqoop$field_map.put("RDY_AMT_TRM_VAL7", this.RDY_AMT_TRM_VAL7);
    __sqoop$field_map.put("RDY_AMT_TRM_VAL8", this.RDY_AMT_TRM_VAL8);
    __sqoop$field_map.put("RDY_AMT_TRM_VAL9", this.RDY_AMT_TRM_VAL9);
    __sqoop$field_map.put("RDY_AMT_TRM_VAL10", this.RDY_AMT_TRM_VAL10);
    __sqoop$field_map.put("RDY_AMT_TRM_VAL11", this.RDY_AMT_TRM_VAL11);
    __sqoop$field_map.put("RDY_AMT_TRM_VAL12", this.RDY_AMT_TRM_VAL12);
    __sqoop$field_map.put("RDY_AMT_TRM_VAL13", this.RDY_AMT_TRM_VAL13);
    __sqoop$field_map.put("RDY_AMT_TRM_VAL14", this.RDY_AMT_TRM_VAL14);
    __sqoop$field_map.put("RDY_AMT_TRM_VAL15", this.RDY_AMT_TRM_VAL15);
    __sqoop$field_map.put("DIVD_YN", this.DIVD_YN);
    __sqoop$field_map.put("ANN_PAY_CYC_CD", this.ANN_PAY_CYC_CD);
    __sqoop$field_map.put("ANN_PAY_PRD_CD", this.ANN_PAY_PRD_CD);
    __sqoop$field_map.put("ANN_PAY_SH_CD", this.ANN_PAY_SH_CD);
    __sqoop$field_map.put("ANN_PAY_ST_AGE", this.ANN_PAY_ST_AGE);
    __sqoop$field_map.put("GURT_ACU_DIV_CD", this.GURT_ACU_DIV_CD);
    __sqoop$field_map.put("NEGA_GRP_CD", this.NEGA_GRP_CD);
    __sqoop$field_map.put("COV_SMT_CTG_CD", this.COV_SMT_CTG_CD);
    __sqoop$field_map.put("XCHG_INDX", this.XCHG_INDX);
    __sqoop$field_map.put("DC_XCHG_CF", this.DC_XCHG_CF);
    __sqoop$field_map.put("RNWL_COV_CYC_CD", this.RNWL_COV_CYC_CD);
    __sqoop$field_map.put("RNWL_ED_AGE", this.RNWL_ED_AGE);
    __sqoop$field_map.put("RNWL_ED_DT", this.RNWL_ED_DT);
    __sqoop$field_map.put("RNWL_ED_PRD_DIV_CD", this.RNWL_ED_PRD_DIV_CD);
    __sqoop$field_map.put("RNWL_ED_PRD", this.RNWL_ED_PRD);
    __sqoop$field_map.put("POLHD_CONV_SIC_SBC_YN", this.POLHD_CONV_SIC_SBC_YN);
    __sqoop$field_map.put("PLAN_CD", this.PLAN_CD);
    __sqoop$field_map.put("INS_BGN_DT", this.INS_BGN_DT);
    __sqoop$field_map.put("SBCP_CHN_DIV_CD", this.SBCP_CHN_DIV_CD);
    __sqoop$field_map.put("INS_PRD", this.INS_PRD);
    __sqoop$field_map.put("PY_PRD", this.PY_PRD);
    __sqoop$field_map.put("SETL_PD_DIV_CD", this.SETL_PD_DIV_CD);
    __sqoop$field_map.put("TRNS_DTM", this.TRNS_DTM);
    __sqoop$field_map.put("INPPE_ORG_ID", this.INPPE_ORG_ID);
    __sqoop$field_map.put("SYS_OCC_DTM", this.SYS_OCC_DTM);
    __sqoop$field_map.put("SYS_DEL_DIV_CD", this.SYS_DEL_DIV_CD);
    __sqoop$field_map.put("OCC_IP", this.OCC_IP);
    __sqoop$field_map.put("APP_ID", this.APP_ID);
    __sqoop$field_map.put("DATA_CHNG_DTM", this.DATA_CHNG_DTM);
    __sqoop$field_map.put("DMG_RT_COV_DCTG_CD", this.DMG_RT_COV_DCTG_CD);
    __sqoop$field_map.put("CTR_OBJ_ID", this.CTR_OBJ_ID);
    __sqoop$field_map.put("XCHG_YN", this.XCHG_YN);
    __sqoop$field_map.put("NOCV_YN", this.NOCV_YN);
    __sqoop$field_map.put("INSPE_GRDE_VAL", this.INSPE_GRDE_VAL);
    __sqoop$field_map.put("EIH_LDG_DTM", this.EIH_LDG_DTM);
    __sqoop$field_map.put("MOM_COV_CD", this.MOM_COV_CD);
    __sqoop$field_map.put("ACCM_COV_CD", this.ACCM_COV_CD);
    __sqoop$field_map.put("BTH_AF_COV_CD", this.BTH_AF_COV_CD);
    __sqoop$field_map.put("COV_SBC_AMT", this.COV_SBC_AMT);
    __sqoop$field_map.put("ACCM_SBC_AMT", this.ACCM_SBC_AMT);
  }

  public void setField(String __fieldName, Object __fieldVal) {
    if (!setters.containsKey(__fieldName)) {
      throw new RuntimeException("No such field:"+__fieldName);
    }
    setters.get(__fieldName).setField(__fieldVal);
  }

}
