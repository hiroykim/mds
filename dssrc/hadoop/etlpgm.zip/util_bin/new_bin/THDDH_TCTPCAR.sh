#!/bin/bash

if [ $# -eq 0 ]
then           
    ARGS=N    
else           
    ARGS=$1
fi             

NOW=$(date +"+%Y-%m-%d_%T")
SHLOG_DIR=/sqoopbin/scripts/etlpgm/cur_log
HISLOG_DIR=/sqoopbin/scripts/etlpgm/his_log

export HADOOP_OPTS=-Djava.security.egd=file:/dev/../dev/urandom
export ORACLE_BASE=/sw/oracle
export ORACLE_HOME=/sw/oracle/product/11.2.0.4/client_1
export LD_LIBRARY_PATH=/sw/oracle/product/11.2.0.4/client_1/lib:/sw/oracle/product/11.2.0.4/client_1/lib:
export PATH=/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/usr/lib64/qt-3.3/bin:/usr/hdp/3.0.0.0-1634/spark2/bin/:/var/opt/node/bin/:/opt/maven/bin:/usr/local/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/home/hdpapp/workspace/data-science-at-the-command-line/tools:/home/hdpapp/.local/bin:/home/hdpapp/bin
export TNS_ADMIN=/sw/oracle/product/11.2.0.4/client_1/network/admin
export ORACLE_SID=DBEDWP2
export NLS_LANG=American_America.KO16MSWIN949

#----------------------------------------------------#
# 작업내용 : THDDH_TCTPCAR 테이블 sqoop 복제 작업
# 작업주기 :  
#----------------------------------------------------#

    echo " "
    echo "*-----------[ THDDH_TCTPCAR.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TCTPCAR.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`  >  ${SHLOG_DIR}/THDDH_TCTPCAR.shlog

#----------------------------------------------------#
# 테이블별 전체 데이터를 받아 오는 부분
#----------------------------------------------------#
    /usr/bin/hadoop fs -rm -r -f  /tmp2/LAST_THDDH_TCTPCAR  >> ${SHLOG_DIR}/THDDH_TCTPCAR.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.LAST_THDDH_TCTPCAR ; " >> ${SHLOG_DIR}/THDDH_TCTPCAR.shlog 2>&1 &&
    /usr/hdp/3.0.0.0-1634/sqoop/bin/sqoop import -D mapred.child.java.opts="-Djava.security.egd=file:/dev/../dev/urandom" \
    --connect jdbc:oracle:thin:EDWHADOOP/wjdqhrP\!23@10.91.41.172:12560:DBEDWP2 \
    --username  EDWHADOOP \
    --password wjdqhrP\!23 \
    --query "SELECT /*+ FULL(THDDH_TCTPCAR) */ REPLACE(REPLACE(CTR_OBJ_ID,CHR(13),''),CHR(10),'') CTR_OBJ_ID
, HIS_SEQ
, REPLACE(REPLACE(BIZ_SYS_CD,CHR(13),''),CHR(10),'') BIZ_SYS_CD
, REPLACE(REPLACE(CTR_ID,CHR(13),''),CHR(10),'') CTR_ID
, REPLACE(REPLACE(PRCTR_NO,CHR(13),''),CHR(10),'') PRCTR_NO
, REPLACE(REPLACE(VEHC_NO,CHR(13),''),CHR(10),'') VEHC_NO
, REPLACE(REPLACE(VEHC_NO_SIDO_CD,CHR(13),''),CHR(10),'') VEHC_NO_SIDO_CD
, REPLACE(REPLACE(VEHC_NO_SCTG_NO,CHR(13),''),CHR(10),'') VEHC_NO_SCTG_NO
, REPLACE(REPLACE(VEHC_NO_MCTG_NO,CHR(13),''),CHR(10),'') VEHC_NO_MCTG_NO
, REPLACE(REPLACE(VEHC_NO_LCTG_CD,CHR(13),''),CHR(10),'') VEHC_NO_LCTG_CD
, REPLACE(REPLACE(VEHC_NO_SNO,CHR(13),''),CHR(10),'') VEHC_NO_SNO
, REPLACE(REPLACE(ATM_LRG_NO_DIV_CD,CHR(13),''),CHR(10),'') ATM_LRG_NO_DIV_CD
, REPLACE(REPLACE(CRBD_NO,CHR(13),''),CHR(10),'') CRBD_NO
, REPLACE(REPLACE(ATM_NM_CD,CHR(13),''),CHR(10),'') ATM_NM_CD
, REPLACE(REPLACE(ATM_NM_DSC_CON,CHR(13),''),CHR(10),'') ATM_NM_DSC_CON
, VEHC_VAMT
, REPLACE(REPLACE(SBSC_CD,CHR(13),''),CHR(10),'') SBSC_CD
, REPLACE(REPLACE(MNFCO_CD,CHR(13),''),CHR(10),'') MNFCO_CD
, LDG_FX_QT
, REPLACE(REPLACE(LDG_FX_QT_UNT_CD,CHR(13),''),CHR(10),'') LDG_FX_QT_UNT_CD
, REPLACE(REPLACE(VEHC_USG_CD,CHR(13),''),CHR(10),'') VEHC_USG_CD
, REPLACE(REPLACE(USE_USG_CD,CHR(13),''),CHR(10),'') USE_USG_CD
, REPLACE(REPLACE(COMPS_TRN_SH_CD,CHR(13),''),CHR(10),'') COMPS_TRN_SH_CD
, REPLACE(REPLACE(VEHC_SH_CD,CHR(13),''),CHR(10),'') VEHC_SH_CD
, VEHC_SH_VAMT
, REPLACE(REPLACE(VEHC_SH_DTL_DSC_CON,CHR(13),''),CHR(10),'') VEHC_SH_DTL_DSC_CON
, REPLACE(REPLACE(VEHC_STRU_CHNG_YN,CHR(13),''),CHR(10),'') VEHC_STRU_CHNG_YN
, REPLACE(REPLACE(FRCU_INDI_PD_VHCTG_CD,CHR(13),''),CHR(10),'') FRCU_INDI_PD_VHCTG_CD
, VEHC_EXAM_DT
, REPLACE(REPLACE(ATM_NM_GRDE_CD,CHR(13),''),CHR(10),'') ATM_NM_GRDE_CD
, REPLACE(REPLACE(NECR_YN,CHR(13),''),CHR(10),'') NECR_YN
, REPLACE(REPLACE(VHTP_CD,CHR(13),''),CHR(10),'') VHTP_CD
, REPLACE(REPLACE(VEHC_YMDL,CHR(13),''),CHR(10),'') VEHC_YMDL
, VEHC_REG_DT
, REPLACE(REPLACE(VEHC_USG_SCTG_CD,CHR(13),''),CHR(10),'') VEHC_USG_SCTG_CD
, REPLACE(REPLACE(ATL_CTR_OBJ_ID,CHR(13),''),CHR(10),'') ATL_CTR_OBJ_ID
, ATL_HIS_SEQ
, ENDR_NO
, RTRO_ENDR_NO
, ENDR_HIS_ST_NO
, ENDR_HIS_ED_NO
, SUMUP_DT
, HIS_ST_DT
, HIS_ED_DT
, REPLACE(REPLACE(INPPE_ORG_ID,CHR(13),''),CHR(10),'') INPPE_ORG_ID
, SYS_OCC_DTM
, REPLACE(REPLACE(SYS_DEL_DIV_CD,CHR(13),''),CHR(10),'') SYS_DEL_DIV_CD
, REPLACE(REPLACE(OCC_IP,CHR(13),''),CHR(10),'') OCC_IP
, REPLACE(REPLACE(APP_ID,CHR(13),''),CHR(10),'') APP_ID
, DATA_CHNG_DTM
, REPLACE(REPLACE(BLBX_MNFCO_NM,CHR(13),''),CHR(10),'') BLBX_MNFCO_NM
, REPLACE(REPLACE(BLBX_MFCT_NM,CHR(13),''),CHR(10),'') BLBX_MFCT_NM
, REPLACE(REPLACE(BLBX_INHR_NO,CHR(13),''),CHR(10),'') BLBX_INHR_NO
, EIH_LDG_DTM
, REPLACE(REPLACE(VEHC_REG_INQ_RSL_CD,CHR(13),''),CHR(10),'') VEHC_REG_INQ_RSL_CD
, REPLACE(REPLACE(VEHC_REG_OWNR_CNSS_CD,CHR(13),''),CHR(10),'') VEHC_REG_OWNR_CNSS_CD
, REPLACE(REPLACE(VEREINQ_MIS_RSN_CD,CHR(13),''),CHR(10),'') VEREINQ_MIS_RSN_CD
, REPLACE(REPLACE(VEHC_REG_INQ_OWNR_NM,CHR(13),''),CHR(10),'') VEHC_REG_INQ_OWNR_NM
, REPLACE(REPLACE(RPS_ATM_NM,CHR(13),''),CHR(10),'') RPS_ATM_NM
, REPLACE(REPLACE(VEHC_ALTN_BF_STAT_CD,CHR(13),''),CHR(10),'') VEHC_ALTN_BF_STAT_CD
, REPLACE(REPLACE(KIDI_VEHC_INF_ID,CHR(13),''),CHR(10),'') KIDI_VEHC_INF_ID FROM THDDH_TCTPCAR
                       WHERE \$CONDITIONS "\
    --m 8 \
    --boundary-query "SELECT 0, 7 FROM DUAL"\
    --split-by "ORA_HASH(CTR_OBJ_ID, 7)"\
    --target-dir /tmp2/LAST_THDDH_TCTPCAR \
    --hive-import \
    --external-table-dir hdfs:///tmp2/temp_tbl/LAST_THDDH_TCTPCAR \
    --hive-overwrite \
    --hive-table DEFAULT.LAST_THDDH_TCTPCAR  >> ${SHLOG_DIR}/THDDH_TCTPCAR.shlog 2>&1 &&

#----------------------------------------------------#
# Hadoop 원본테이블에 변경분 최종 적용
#----------------------------------------------------#
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TCTPCAR_TMP ; " >> ${SHLOG_DIR}/THDDH_TCTPCAR.shlog 2>&1 &&
    /usr/bin/hive -e "CREATE EXTERNAL TABLE MERITZ.THDDH_TCTPCAR_TMP STORED AS PARQUET TBLPROPERTIES ('PARQUET.COMPRESS'='SNAPPY') AS
                                SELECT *
                                FROM DEFAULT.LAST_THDDH_TCTPCAR ;" >> ${SHLOG_DIR}/THDDH_TCTPCAR.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.LAST_THDDH_TCTPCAR ;" >> ${SHLOG_DIR}/THDDH_TCTPCAR.shlog 2>&1 &&
    /usr/bin/hdfs dfs -rm -r -f -skipTrash /tmp2/temp_tbl/LAST_THDDH_TCTPCAR >> ${SHLOG_DIR}/THDDH_TCTPCAR.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TCTPCAR ;" >> ${SHLOG_DIR}/THDDH_TCTPCAR.shlog 2>&1 &&
    /usr/bin/hive -e "ALTER TABLE MERITZ.THDDH_TCTPCAR_TMP RENAME TO MERITZ.THDDH_TCTPCAR ;" >> ${SHLOG_DIR}/THDDH_TCTPCAR.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TCTPCAR_TMP ;" >> ${SHLOG_DIR}/THDDH_TCTPCAR.shlog 2>&1 

if [ $? -ne 0 ]
then             
    echo "*-----------[ THDDH_TCTPCAR.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/THDDH_TCTPCAR.shlog"
    echo "*-----------[ THDDH_TCTPCAR.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/THDDH_TCTPCAR.shlog"  >>  ${SHLOG_DIR}/THDDH_TCTPCAR.shlog
    echo "*-----------[ THDDH_TCTPCAR.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TCTPCAR.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/THDDH_TCTPCAR.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/THDDH_TCTPCAR.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCTPCAR.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCTPCAR.shlog /sqoopbin/scripts/etlpgm/his_log/THDDH_TCTPCAR_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  THDDH_TCTPCAR.sh cmd command error !! ***
    fi               

    exit -1      

else             
    echo "*-----------[ THDDH_TCTPCAR.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TCTPCAR.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/THDDH_TCTPCAR.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/THDDH_TCTPCAR.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCTPCAR.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCTPCAR.shlog /sqoopbin/scripts/etlpgm/his_log/THDDH_TCTPCAR_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  THDDH_TCTPCAR.sh cmd command error !! ***
        exit -1      
    else             
        exit 0       
    fi               
fi               
