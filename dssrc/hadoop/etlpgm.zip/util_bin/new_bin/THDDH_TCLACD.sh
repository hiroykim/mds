#!/bin/bash

if [ $# -eq 0 ]
then           
    ARGS=N    
else           
    ARGS=$1
fi             

NOW=$(date +"+%Y-%m-%d_%T")
SHLOG_DIR=/sqoopbin/scripts/etlpgm/cur_log
HISLOG_DIR=/sqoopbin/scripts/etlpgm/his_log

export HADOOP_OPTS=-Djava.security.egd=file:/dev/../dev/urandom
export ORACLE_BASE=/sw/oracle
export ORACLE_HOME=/sw/oracle/product/11.2.0.4/client_1
export LD_LIBRARY_PATH=/sw/oracle/product/11.2.0.4/client_1/lib:/sw/oracle/product/11.2.0.4/client_1/lib:
export PATH=/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/usr/lib64/qt-3.3/bin:/usr/hdp/3.0.0.0-1634/spark2/bin/:/var/opt/node/bin/:/opt/maven/bin:/usr/local/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/home/hdpapp/workspace/data-science-at-the-command-line/tools:/home/hdpapp/.local/bin:/home/hdpapp/bin
export TNS_ADMIN=/sw/oracle/product/11.2.0.4/client_1/network/admin
export ORACLE_SID=DBEDWP2
export NLS_LANG=American_America.KO16MSWIN949

#----------------------------------------------------#
# 작업내용 : THDDH_TCLACD 테이블 sqoop 복제 작업
# 작업주기 :  
#----------------------------------------------------#

    echo " "
    echo "*-----------[ THDDH_TCLACD.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TCLACD.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`  >  ${SHLOG_DIR}/THDDH_TCLACD.shlog

#----------------------------------------------------#
# 테이블별 전체 데이터를 받아 오는 부분
#----------------------------------------------------#
    /usr/bin/hadoop fs -rm -r -f  /tmp2/LAST_THDDH_TCLACD  >> ${SHLOG_DIR}/THDDH_TCLACD.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.LAST_THDDH_TCLACD ; " >> ${SHLOG_DIR}/THDDH_TCLACD.shlog 2>&1 &&
    /usr/hdp/3.0.0.0-1634/sqoop/bin/sqoop import -D mapred.child.java.opts="-Djava.security.egd=file:/dev/../dev/urandom" \
    --connect jdbc:oracle:thin:EDWHADOOP/wjdqhrP\!23@10.91.41.172:12560:DBEDWP2 \
    --username  EDWHADOOP \
    --password wjdqhrP\!23 \
    --query "SELECT /*+ FULL(THDDH_TCLACD) */ REPLACE(REPLACE(ACD_RCT_ID,CHR(13),''),CHR(10),'') ACD_RCT_ID
, HIS_SEQ
, REPLACE(REPLACE(COMS_BIZ_DIV_CD,CHR(13),''),CHR(10),'') COMS_BIZ_DIV_CD
, REPLACE(REPLACE(ACD_NO_YY,CHR(13),''),CHR(10),'') ACD_NO_YY
, ACD_NO_SEQ
, RCT_DT
, RCT_DTM
, ACD_DT
, ACD_DTM
, REPLACE(REPLACE(HOLI_YN,CHR(13),''),CHR(10),'') HOLI_YN
, REPLACE(REPLACE(ACD_SH_LCTG_CD,CHR(13),''),CHR(10),'') ACD_SH_LCTG_CD
, REPLACE(REPLACE(ACD_SH_SCTG_CD,CHR(13),''),CHR(10),'') ACD_SH_SCTG_CD
, REPLACE(REPLACE(ACD_RCT_PTH_CD,CHR(13),''),CHR(10),'') ACD_RCT_PTH_CD
, REPLACE(REPLACE(ACD_RCT_DIV_CD,CHR(13),''),CHR(10),'') ACD_RCT_DIV_CD
, REPLACE(REPLACE(DMG_AMT_DIV_CD,CHR(13),''),CHR(10),'') DMG_AMT_DIV_CD
, REPLACE(REPLACE(DAM_DGR_CD,CHR(13),''),CHR(10),'') DAM_DGR_CD
, REPLACE(REPLACE(STM_PBOFC_DIV_CD,CHR(13),''),CHR(10),'') STM_PBOFC_DIV_CD
, REPLACE(REPLACE(PLCST_STM_YN,CHR(13),''),CHR(10),'') PLCST_STM_YN
, REPLACE(REPLACE(PLCST_ADMN_INST_CD,CHR(13),''),CHR(10),'') PLCST_ADMN_INST_CD
, REPLACE(REPLACE(PLCST_NM,CHR(13),''),CHR(10),'') PLCST_NM
, REPLACE(REPLACE(PLCST_CHRPE_NM,CHR(13),''),CHR(10),'') PLCST_CHRPE_NM
, REPLACE(REPLACE(PLCST_RCT_NO,CHR(13),''),CHR(10),'') PLCST_RCT_NO
, PLCST_STM_DTM
, REPLACE(REPLACE(PLCST_AR_CCO_CD,CHR(13),''),CHR(10),'') PLCST_AR_CCO_CD
, REPLACE(REPLACE(PLCST_TELOF_NO,CHR(13),''),CHR(10),'') PLCST_TELOF_NO
, REPLACE(REPLACE(PLCST_TEL_SNO,CHR(13),''),CHR(10),'') PLCST_TEL_SNO
, REPLACE(REPLACE(DSS_CD_YY,CHR(13),''),CHR(10),'') DSS_CD_YY
, DSS_CD_SEQ
, REPLACE(REPLACE(SPOT_PRSRV_YN,CHR(13),''),CHR(10),'') SPOT_PRSRV_YN
, REPLACE(REPLACE(WTN_BEIN_YN,CHR(13),''),CHR(10),'') WTN_BEIN_YN
, REPLACE(REPLACE(ACD_CON,CHR(13),''),CHR(10),'') ACD_CON
, REPLACE(REPLACE(ACD_ETC_CON,CHR(13),''),CHR(10),'') ACD_ETC_CON
, REPLACE(REPLACE(URGC_PCS_TRG_YN,CHR(13),''),CHR(10),'') URGC_PCS_TRG_YN
, REPLACE(REPLACE(DRVPE_NGBD_YN,CHR(13),''),CHR(10),'') DRVPE_NGBD_YN
, REPLACE(REPLACE(OTH_VEHC_DRV_YN,CHR(13),''),CHR(10),'') OTH_VEHC_DRV_YN
, REPLACE(REPLACE(OTH_VEHC_INSCO_CD,CHR(13),''),CHR(10),'') OTH_VEHC_INSCO_CD
, REPLACE(REPLACE(OTH_VEHC_NO,CHR(13),''),CHR(10),'') OTH_VEHC_NO
, REPLACE(REPLACE(OTHCO_ACD_NO,CHR(13),''),CHR(10),'') OTHCO_ACD_NO
, REPLACE(REPLACE(CLOG_AF_CTR_YN,CHR(13),''),CHR(10),'') CLOG_AF_CTR_YN
, REPLACE(REPLACE(GURT_BZ_APV_NO,CHR(13),''),CHR(10),'') GURT_BZ_APV_NO
, REPLACE(REPLACE(COMS_ACD_TP_CD,CHR(13),''),CHR(10),'') COMS_ACD_TP_CD
, REPLACE(REPLACE(OD_ACD_NO,CHR(13),''),CHR(10),'') OD_ACD_NO
, REPLACE(REPLACE(ACD_STAT_CD,CHR(13),''),CHR(10),'') ACD_STAT_CD
, REPLACE(REPLACE(RCTPE_ORG_ID,CHR(13),''),CHR(10),'') RCTPE_ORG_ID
, HIS_ST_DTM
, HIS_ED_DTM
, REPLACE(REPLACE(INPPE_ORG_ID,CHR(13),''),CHR(10),'') INPPE_ORG_ID
, SYS_OCC_DTM
, REPLACE(REPLACE(SYS_DEL_DIV_CD,CHR(13),''),CHR(10),'') SYS_DEL_DIV_CD
, REPLACE(REPLACE(OCC_IP,CHR(13),''),CHR(10),'') OCC_IP
, REPLACE(REPLACE(APP_ID,CHR(13),''),CHR(10),'') APP_ID
, DATA_CHNG_DTM
, EIH_LDG_DTM
, REPLACE(REPLACE(CMPS_PRDA_VEHC_DIV_CD,CHR(13),''),CHR(10),'') CMPS_PRDA_VEHC_DIV_CD
, REPLACE(REPLACE(SPC_ACD_YN,CHR(13),''),CHR(10),'') SPC_ACD_YN
, REPLACE(REPLACE(IMPR_LWRG_CD,CHR(13),''),CHR(10),'') IMPR_LWRG_CD
, REPLACE(REPLACE(BLBX_YN,CHR(13),''),CHR(10),'') BLBX_YN
, REPLACE(REPLACE(MDTR_LSN_TRG_DIV_CD,CHR(13),''),CHR(10),'') MDTR_LSN_TRG_DIV_CD
, REPLACE(REPLACE(SPC_ACD_TP_CD,CHR(13),''),CHR(10),'') SPC_ACD_TP_CD
, REPLACE(REPLACE(SPC_ACD_CON,CHR(13),''),CHR(10),'') SPC_ACD_CON
, REPLACE(REPLACE(LET_SND_YN,CHR(13),''),CHR(10),'') LET_SND_YN
, REPLACE(REPLACE(NURPE_SVC_RQE_YN,CHR(13),''),CHR(10),'') NURPE_SVC_RQE_YN
, REPLACE(REPLACE(MED_SLRY_QURE_YN,CHR(13),''),CHR(10),'') MED_SLRY_QURE_YN
, REPLACE(REPLACE(INS_LNCR_YN,CHR(13),''),CHR(10),'') INS_LNCR_YN
, REPLACE(REPLACE(VST_CUS_PTY_REL_CD,CHR(13),''),CHR(10),'') VST_CUS_PTY_REL_CD
, REPLACE(REPLACE(VST_CUS_NM,CHR(13),''),CHR(10),'') VST_CUS_NM
, REPLACE(REPLACE(SMOV_DIRCT_STAT_CD,CHR(13),''),CHR(10),'') SMOV_DIRCT_STAT_CD
, REPLACE(REPLACE(INS_FRUD_EXPC_YN,CHR(13),''),CHR(10),'') INS_FRUD_EXPC_YN
, REPLACE(REPLACE(CASH_RCE_REQ_YN,CHR(13),''),CHR(10),'') CASH_RCE_REQ_YN
, REPLACE(REPLACE(PAY_PRHBT_YN,CHR(13),''),CHR(10),'') PAY_PRHBT_YN
, REPLACE(REPLACE(RCLL_TRG_YN,CHR(13),''),CHR(10),'') RCLL_TRG_YN
, REPLACE(REPLACE(GPIR_CPS_DIVD_YN,CHR(13),''),CHR(10),'') GPIR_CPS_DIVD_YN
, REPLACE(REPLACE(INS_AMT_CLM_VCEX_YN,CHR(13),''),CHR(10),'') INS_AMT_CLM_VCEX_YN
, REPLACE(REPLACE(RCT_SPPL_EXPT_YN,CHR(13),''),CHR(10),'') RCT_SPPL_EXPT_YN FROM THDDH_TCLACD
                       WHERE \$CONDITIONS "\
    --m 8 \
    --boundary-query "SELECT 0, 7 FROM DUAL"\
    --split-by "ORA_HASH(ACD_RCT_ID, 7)"\
    --target-dir /tmp2/LAST_THDDH_TCLACD \
    --hive-import \
    --external-table-dir hdfs:///tmp2/temp_tbl/LAST_THDDH_TCLACD \
    --hive-overwrite \
    --hive-table DEFAULT.LAST_THDDH_TCLACD  >> ${SHLOG_DIR}/THDDH_TCLACD.shlog 2>&1 &&

#----------------------------------------------------#
# Hadoop 원본테이블에 변경분 최종 적용
#----------------------------------------------------#
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TCLACD_TMP ; " >> ${SHLOG_DIR}/THDDH_TCLACD.shlog 2>&1 &&
    /usr/bin/hive -e "CREATE EXTERNAL TABLE MERITZ.THDDH_TCLACD_TMP STORED AS PARQUET TBLPROPERTIES ('PARQUET.COMPRESS'='SNAPPY') AS
                                SELECT *
                                FROM DEFAULT.LAST_THDDH_TCLACD ;" >> ${SHLOG_DIR}/THDDH_TCLACD.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.LAST_THDDH_TCLACD ;" >> ${SHLOG_DIR}/THDDH_TCLACD.shlog 2>&1 &&
    /usr/bin/hdfs dfs -rm -r -f -skipTrash /tmp2/temp_tbl/LAST_THDDH_TCLACD >> ${SHLOG_DIR}/THDDH_TCLACD.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TCLACD ;" >> ${SHLOG_DIR}/THDDH_TCLACD.shlog 2>&1 &&
    /usr/bin/hive -e "ALTER TABLE MERITZ.THDDH_TCLACD_TMP RENAME TO MERITZ.THDDH_TCLACD ;" >> ${SHLOG_DIR}/THDDH_TCLACD.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TCLACD_TMP ;" >> ${SHLOG_DIR}/THDDH_TCLACD.shlog 2>&1 

if [ $? -ne 0 ]
then             
    echo "*-----------[ THDDH_TCLACD.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/THDDH_TCLACD.shlog"
    echo "*-----------[ THDDH_TCLACD.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/THDDH_TCLACD.shlog"  >>  ${SHLOG_DIR}/THDDH_TCLACD.shlog
    echo "*-----------[ THDDH_TCLACD.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TCLACD.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/THDDH_TCLACD.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/THDDH_TCLACD.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCLACD.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCLACD.shlog /sqoopbin/scripts/etlpgm/his_log/THDDH_TCLACD_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  THDDH_TCLACD.sh cmd command error !! ***
    fi               

    exit -1      

else             
    echo "*-----------[ THDDH_TCLACD.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TCLACD.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/THDDH_TCLACD.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/THDDH_TCLACD.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCLACD.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCLACD.shlog /sqoopbin/scripts/etlpgm/his_log/THDDH_TCLACD_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  THDDH_TCLACD.sh cmd command error !! ***
        exit -1      
    else             
        exit 0       
    fi               
fi               
