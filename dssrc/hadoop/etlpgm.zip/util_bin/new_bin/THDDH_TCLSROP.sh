#!/bin/bash

if [ $# -eq 0 ]
then           
    ARGS=N    
else           
    ARGS=$1
fi             

NOW=$(date +"+%Y-%m-%d_%T")
SHLOG_DIR=/sqoopbin/scripts/etlpgm/cur_log
HISLOG_DIR=/sqoopbin/scripts/etlpgm/his_log

export HADOOP_OPTS=-Djava.security.egd=file:/dev/../dev/urandom
export ORACLE_BASE=/sw/oracle
export ORACLE_HOME=/sw/oracle/product/11.2.0.4/client_1
export LD_LIBRARY_PATH=/sw/oracle/product/11.2.0.4/client_1/lib:/sw/oracle/product/11.2.0.4/client_1/lib:
export PATH=/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/usr/lib64/qt-3.3/bin:/usr/hdp/3.0.0.0-1634/spark2/bin/:/var/opt/node/bin/:/opt/maven/bin:/usr/local/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/home/hdpapp/workspace/data-science-at-the-command-line/tools:/home/hdpapp/.local/bin:/home/hdpapp/bin
export TNS_ADMIN=/sw/oracle/product/11.2.0.4/client_1/network/admin
export ORACLE_SID=DBEDWP2
export NLS_LANG=American_America.KO16MSWIN949

#----------------------------------------------------#
# 작업내용 : THDDH_TCLSROP 테이블 sqoop 복제 작업
# 작업주기 :  
#----------------------------------------------------#

    echo " "
    echo "*-----------[ THDDH_TCLSROP.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TCLSROP.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`  >  ${SHLOG_DIR}/THDDH_TCLSROP.shlog

#----------------------------------------------------#
# 테이블별 전체 데이터를 받아 오는 부분
#----------------------------------------------------#
    /usr/bin/hadoop fs -rm -r -f  /tmp2/LAST_THDDH_TCLSROP  >> ${SHLOG_DIR}/THDDH_TCLSROP.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.LAST_THDDH_TCLSROP ; " >> ${SHLOG_DIR}/THDDH_TCLSROP.shlog 2>&1 &&
    /usr/hdp/3.0.0.0-1634/sqoop/bin/sqoop import -D mapred.child.java.opts="-Djava.security.egd=file:/dev/../dev/urandom" \
    --connect jdbc:oracle:thin:EDWHADOOP/wjdqhrP\!23@10.91.41.172:12560:DBEDWP2 \
    --username  EDWHADOOP \
    --password wjdqhrP\!23 \
    --query "SELECT /*+ FULL(THDDH_TCLSROP) */ REPLACE(REPLACE(SROP_ID,CHR(13),''),CHR(10),'') SROP_ID
, HIS_SEQ
, REPLACE(REPLACE(COMS_BIZ_DIV_CD,CHR(13),''),CHR(10),'') COMS_BIZ_DIV_CD
, REPLACE(REPLACE(DMPE_ID,CHR(13),''),CHR(10),'') DMPE_ID
, REPLACE(REPLACE(DMG_SVY_OCDIV_CD,CHR(13),''),CHR(10),'') DMG_SVY_OCDIV_CD
, REPLACE(REPLACE(CLM_ID,CHR(13),''),CHR(10),'') CLM_ID
, REPLACE(REPLACE(SROP_DIV_CD,CHR(13),''),CHR(10),'') SROP_DIV_CD
, REPLACE(REPLACE(HOSP_BZAC_ID,CHR(13),''),CHR(10),'') HOSP_BZAC_ID
, SROP_DT
, REPLACE(REPLACE(KR_DISZ_CD,CHR(13),''),CHR(10),'') KR_DISZ_CD
, REPLACE(REPLACE(HOSP_NM,CHR(13),''),CHR(10),'') HOSP_NM
, REPLACE(REPLACE(SROP_NM,CHR(13),''),CHR(10),'') SROP_NM
, REPLACE(REPLACE(MET_SBJ_CD,CHR(13),''),CHR(10),'') MET_SBJ_CD
, REPLACE(REPLACE(SROP_TP_CD,CHR(13),''),CHR(10),'') SROP_TP_CD
, REPLACE(REPLACE(SROP_DTLS_TP_CD,CHR(13),''),CHR(10),'') SROP_DTLS_TP_CD
, FACE_DFCR_LEN
, UPLMB_DFCR_LEN
, WRST_DFCR_LEN
, TCUS_DFCR_LEN
, REPLACE(REPLACE(SROP_DGN_RGN_CD,CHR(13),''),CHR(10),'') SROP_DGN_RGN_CD
, REPLACE(REPLACE(SROP_DR_NM,CHR(13),''),CHR(10),'') SROP_DR_NM
, REPLACE(REPLACE(MED_FLT_YN,CHR(13),''),CHR(10),'') MED_FLT_YN
, REPLACE(REPLACE(SROP_STAT_CON,CHR(13),''),CHR(10),'') SROP_STAT_CON
, BDW
, PRGN_WK_NUM
, PRGN_PRD_DD_NUM
, ISS_DT
, REPLACE(REPLACE(ORN_SROP_ID,CHR(13),''),CHR(10),'') ORN_SROP_ID
, REPLACE(REPLACE(DUP_DOC_CNF_CD,CHR(13),''),CHR(10),'') DUP_DOC_CNF_CD
, INF_OBM_FIX_SEQ
, REPLACE(REPLACE(INF_OBM_DCM_NO,CHR(13),''),CHR(10),'') INF_OBM_DCM_NO
, REPLACE(REPLACE(COMS_CHRPE_DIV_CD,CHR(13),''),CHR(10),'') COMS_CHRPE_DIV_CD
, HIS_ST_DTM
, HIS_ED_DTM
, REPLACE(REPLACE(INPPE_ORG_ID,CHR(13),''),CHR(10),'') INPPE_ORG_ID
, SYS_OCC_DTM
, REPLACE(REPLACE(SYS_DEL_DIV_CD,CHR(13),''),CHR(10),'') SYS_DEL_DIV_CD
, REPLACE(REPLACE(OCC_IP,CHR(13),''),CHR(10),'') OCC_IP
, REPLACE(REPLACE(APP_ID,CHR(13),''),CHR(10),'') APP_ID
, DATA_CHNG_DTM
, EIH_LDG_DTM
, REPLACE(REPLACE(MDF_CHRPE_ORG_ID,CHR(13),''),CHR(10),'') MDF_CHRPE_ORG_ID
, REPLACE(REPLACE(CHRPE_MDF_RSN_CD,CHR(13),''),CHR(10),'') CHRPE_MDF_RSN_CD
, CHRPE_MDF_DTM
, REPLACE(REPLACE(TRFR_TRG_YN,CHR(13),''),CHR(10),'') TRFR_TRG_YN
, REPLACE(REPLACE(TRFR_ACD_RCT_ID,CHR(13),''),CHR(10),'') TRFR_ACD_RCT_ID
, REPLACE(REPLACE(DATA_TRFR_YN,CHR(13),''),CHR(10),'') DATA_TRFR_YN
, REPLACE(REPLACE(IMG_TRFR_YN,CHR(13),''),CHR(10),'') IMG_TRFR_YN
, REPLACE(REPLACE(OTH_ACD_USE_DIV_CD,CHR(13),''),CHR(10),'') OTH_ACD_USE_DIV_CD
, REPLACE(REPLACE(OTH_ACD_PRIMARYKEY_ID,CHR(13),''),CHR(10),'') OTH_ACD_PRIMARYKEY_ID
, REPLACE(REPLACE(KND_SROP_EXP_LCTG_CD,CHR(13),''),CHR(10),'') KND_SROP_EXP_LCTG_CD
, REPLACE(REPLACE(KND_SROP_EXP_MCTG_CD,CHR(13),''),CHR(10),'') KND_SROP_EXP_MCTG_CD
, REPLACE(REPLACE(KND_SROP_EXP_SCTG_CD,CHR(13),''),CHR(10),'') KND_SROP_EXP_SCTG_CD
, REPLACE(REPLACE(KND_SROP_EXP_KD_CD,CHR(13),''),CHR(10),'') KND_SROP_EXP_KD_CD
, REPLACE(REPLACE(CRRC_MCOST_CD_NM1,CHR(13),''),CHR(10),'') CRRC_MCOST_CD_NM1
, REPLACE(REPLACE(CRRC_MCOST_CD_NM2,CHR(13),''),CHR(10),'') CRRC_MCOST_CD_NM2
, REPLACE(REPLACE(CRRC_MCOST_CD_NM3,CHR(13),''),CHR(10),'') CRRC_MCOST_CD_NM3
, REPLACE(REPLACE(CLADJ_MCOST_CD_NM,CHR(13),''),CHR(10),'') CLADJ_MCOST_CD_NM
, REPLACE(REPLACE(ADRG_CD,CHR(13),''),CHR(10),'') ADRG_CD
, REPLACE(REPLACE(KND7_SROP_EXP_KD_CD,CHR(13),''),CHR(10),'') KND7_SROP_EXP_KD_CD
, REPLACE(REPLACE(CLADJ_LNK_DATA_DIV_CD,CHR(13),''),CHR(10),'') CLADJ_LNK_DATA_DIV_CD
, REPLACE(REPLACE(CLADJ_LNK_DATA_ID,CHR(13),''),CHR(10),'') CLADJ_LNK_DATA_ID FROM THDDH_TCLSROP
                       WHERE \$CONDITIONS "\
    --m 1 \
    --target-dir /tmp2/LAST_THDDH_TCLSROP \
    --hive-import \
    --external-table-dir hdfs:///tmp2/temp_tbl/LAST_THDDH_TCLSROP \
    --hive-overwrite \
    --hive-table DEFAULT.LAST_THDDH_TCLSROP  >> ${SHLOG_DIR}/THDDH_TCLSROP.shlog 2>&1 &&

#----------------------------------------------------#
# Hadoop 원본테이블에 변경분 최종 적용
#----------------------------------------------------#
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TCLSROP_TMP ; " >> ${SHLOG_DIR}/THDDH_TCLSROP.shlog 2>&1 &&
    /usr/bin/hive -e "CREATE EXTERNAL TABLE MERITZ.THDDH_TCLSROP_TMP STORED AS PARQUET TBLPROPERTIES ('PARQUET.COMPRESS'='SNAPPY') AS
                                SELECT *
                                FROM DEFAULT.LAST_THDDH_TCLSROP ;" >> ${SHLOG_DIR}/THDDH_TCLSROP.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.LAST_THDDH_TCLSROP ;" >> ${SHLOG_DIR}/THDDH_TCLSROP.shlog 2>&1 &&
    /usr/bin/hdfs dfs -rm -r -f -skipTrash /tmp2/temp_tbl/LAST_THDDH_TCLSROP >> ${SHLOG_DIR}/THDDH_TCLSROP.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TCLSROP ;" >> ${SHLOG_DIR}/THDDH_TCLSROP.shlog 2>&1 &&
    /usr/bin/hive -e "ALTER TABLE MERITZ.THDDH_TCLSROP_TMP RENAME TO MERITZ.THDDH_TCLSROP ;" >> ${SHLOG_DIR}/THDDH_TCLSROP.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TCLSROP_TMP ;" >> ${SHLOG_DIR}/THDDH_TCLSROP.shlog 2>&1 

if [ $? -ne 0 ]
then             
    echo "*-----------[ THDDH_TCLSROP.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/THDDH_TCLSROP.shlog"
    echo "*-----------[ THDDH_TCLSROP.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/THDDH_TCLSROP.shlog"  >>  ${SHLOG_DIR}/THDDH_TCLSROP.shlog
    echo "*-----------[ THDDH_TCLSROP.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TCLSROP.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/THDDH_TCLSROP.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/THDDH_TCLSROP.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCLSROP.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCLSROP.shlog /sqoopbin/scripts/etlpgm/his_log/THDDH_TCLSROP_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  THDDH_TCLSROP.sh cmd command error !! ***
    fi               

    exit -1      

else             
    echo "*-----------[ THDDH_TCLSROP.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TCLSROP.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/THDDH_TCLSROP.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/THDDH_TCLSROP.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCLSROP.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCLSROP.shlog /sqoopbin/scripts/etlpgm/his_log/THDDH_TCLSROP_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  THDDH_TCLSROP.sh cmd command error !! ***
        exit -1      
    else             
        exit 0       
    fi               
fi               
