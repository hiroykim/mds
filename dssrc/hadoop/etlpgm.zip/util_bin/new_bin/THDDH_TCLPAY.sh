#!/bin/bash

if [ $# -eq 0 ]
then           
    ARGS=N    
else           
    ARGS=$1
fi             

NOW=$(date +"+%Y-%m-%d_%T")
SHLOG_DIR=/sqoopbin/scripts/etlpgm/cur_log
HISLOG_DIR=/sqoopbin/scripts/etlpgm/his_log

export HADOOP_OPTS=-Djava.security.egd=file:/dev/../dev/urandom
export ORACLE_BASE=/sw/oracle
export ORACLE_HOME=/sw/oracle/product/11.2.0.4/client_1
export LD_LIBRARY_PATH=/sw/oracle/product/11.2.0.4/client_1/lib:/sw/oracle/product/11.2.0.4/client_1/lib:
export PATH=/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/usr/lib64/qt-3.3/bin:/usr/hdp/3.0.0.0-1634/spark2/bin/:/var/opt/node/bin/:/opt/maven/bin:/usr/local/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/home/hdpapp/workspace/data-science-at-the-command-line/tools:/home/hdpapp/.local/bin:/home/hdpapp/bin
export TNS_ADMIN=/sw/oracle/product/11.2.0.4/client_1/network/admin
export ORACLE_SID=DBEDWP2
export NLS_LANG=American_America.KO16MSWIN949

#----------------------------------------------------#
# 작업내용 : THDDH_TCLPAY 테이블 sqoop 복제 작업
# 작업주기 :  
#----------------------------------------------------#

    echo " "
    echo "*-----------[ THDDH_TCLPAY.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TCLPAY.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`  >  ${SHLOG_DIR}/THDDH_TCLPAY.shlog

#----------------------------------------------------#
# 테이블별 전체 데이터를 받아 오는 부분
#----------------------------------------------------#
    /usr/bin/hadoop fs -rm -r -f  /tmp2/LAST_THDDH_TCLPAY  >> ${SHLOG_DIR}/THDDH_TCLPAY.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.LAST_THDDH_TCLPAY ; " >> ${SHLOG_DIR}/THDDH_TCLPAY.shlog 2>&1 &&
    /usr/hdp/3.0.0.0-1634/sqoop/bin/sqoop import -D mapred.child.java.opts="-Djava.security.egd=file:/dev/../dev/urandom" \
    --connect jdbc:oracle:thin:EDWHADOOP/wjdqhrP\!23@10.91.41.172:12560:DBEDWP2 \
    --username  EDWHADOOP \
    --password wjdqhrP\!23 \
    --query "SELECT /*+ FULL(THDDH_TCLPAY) */ REPLACE(REPLACE(DCN_ID,CHR(13),''),CHR(10),'') DCN_ID
, HIS_SEQ
, REPLACE(REPLACE(CLM_ID,CHR(13),''),CHR(10),'') CLM_ID
, DCN_SEQ
, REPLACE(REPLACE(COMS_BIZ_DIV_CD,CHR(13),''),CHR(10),'') COMS_BIZ_DIV_CD
, REPLACE(REPLACE(ACD_NO_YY,CHR(13),''),CHR(10),'') ACD_NO_YY
, ACD_NO_SEQ
, REPLACE(REPLACE(POL_NO,CHR(13),''),CHR(10),'') POL_NO
, REPLACE(REPLACE(CLM_TP_CD,CHR(13),''),CHR(10),'') CLM_TP_CD
, REPLACE(REPLACE(COMS_COV_CD,CHR(13),''),CHR(10),'') COMS_COV_CD
, DAM_ORD
, REPLACE(REPLACE(DCN_DIV_CD,CHR(13),''),CHR(10),'') DCN_DIV_CD
, DCN_WRT_DT
, DCN_DT
, REPLACE(REPLACE(RGNT_RTRO_YN,CHR(13),''),CHR(10),'') RGNT_RTRO_YN
, PPY_DT
, REPLACE(REPLACE(PPY_YN,CHR(13),''),CHR(10),'') PPY_YN
, REPLACE(REPLACE(PPY_CON,CHR(13),''),CHR(10),'') PPY_CON
, REPLACE(REPLACE(CNC_DCN_ID,CHR(13),''),CHR(10),'') CNC_DCN_ID
, REPLACE(REPLACE(SPTPY_DIV_CD,CHR(13),''),CHR(10),'') SPTPY_DIV_CD
, REPLACE(REPLACE(SPOT_FNDS_ARR_YN,CHR(13),''),CHR(10),'') SPOT_FNDS_ARR_YN
, SHCLS_DT
, REPLACE(REPLACE(DCN_OCC_PTH_CD,CHR(13),''),CHR(10),'') DCN_OCC_PTH_CD
, REPLACE(REPLACE(CHRPE_ORG_ID,CHR(13),''),CHR(10),'') CHRPE_ORG_ID
, REPLACE(REPLACE(CHRPE_PART_ORG_ID,CHR(13),''),CHR(10),'') CHRPE_PART_ORG_ID
, REPLACE(REPLACE(CHRPE_TEM_ORG_ID,CHR(13),''),CHR(10),'') CHRPE_TEM_ORG_ID
, REG_DTM
, HIS_ST_DTM
, HIS_ED_DTM
, REPLACE(REPLACE(INPPE_ORG_ID,CHR(13),''),CHR(10),'') INPPE_ORG_ID
, SYS_OCC_DTM
, REPLACE(REPLACE(SYS_DEL_DIV_CD,CHR(13),''),CHR(10),'') SYS_DEL_DIV_CD
, REPLACE(REPLACE(OCC_IP,CHR(13),''),CHR(10),'') OCC_IP
, REPLACE(REPLACE(APP_ID,CHR(13),''),CHR(10),'') APP_ID
, DATA_CHNG_DTM
, REPLACE(REPLACE(ADD_CLM_EXPT_YN,CHR(13),''),CHR(10),'') ADD_CLM_EXPT_YN
, REPLACE(REPLACE(DCN_CNC_YN,CHR(13),''),CHR(10),'') DCN_CNC_YN
, EIH_LDG_DTM
, REPLACE(REPLACE(DCN_AT_OCC_PTH_CD,CHR(13),''),CHR(10),'') DCN_AT_OCC_PTH_CD
, STND_DOC_CMPLN_DT
, REPLACE(REPLACE(DLY_IAMT_TRG_DCN_ID,CHR(13),''),CHR(10),'') DLY_IAMT_TRG_DCN_ID
, REPLACE(REPLACE(BIZ_APVL_REQ_ID,CHR(13),''),CHR(10),'') BIZ_APVL_REQ_ID
, REPLACE(REPLACE(BIZ_APVL_REF_KEY_VAL,CHR(13),''),CHR(10),'') BIZ_APVL_REF_KEY_VAL
, REPLACE(REPLACE(AJST_FEE_PAY_TRG_YN,CHR(13),''),CHR(10),'') AJST_FEE_PAY_TRG_YN
, DCN_DTM
, REPLACE(REPLACE(INSPE_GUID_SND_YN,CHR(13),''),CHR(10),'') INSPE_GUID_SND_YN
, REPLACE(REPLACE(DPCPE_GUID_SND_YN,CHR(13),''),CHR(10),'') DPCPE_GUID_SND_YN
, REPLACE(REPLACE(CNCLU_RSN_CD,CHR(13),''),CHR(10),'') CNCLU_RSN_CD
, REPLACE(REPLACE(WON0_CNCLU_RSN_CD,CHR(13),''),CHR(10),'') WON0_CNCLU_RSN_CD
, REPLACE(REPLACE(SRO_STFF_ORG_ID,CHR(13),''),CHR(10),'') SRO_STFF_ORG_ID
, LAST_ACD_DT
, LAST_RCT_DT
, LAST_RCT_DTM
, LAST_INF_OBM_FIX_DTM
, LAST_INF_OBM_FIX_SEQ
, REPLACE(REPLACE(AJST_DOC_INSPE_SND_YN,CHR(13),''),CHR(10),'') AJST_DOC_INSPE_SND_YN
, REPLACE(REPLACE(AJST_DOC_POLHD_SND_YN,CHR(13),''),CHR(10),'') AJST_DOC_POLHD_SND_YN
, REPLACE(REPLACE(AJST_DOC_ERNPE_SND_YN,CHR(13),''),CHR(10),'') AJST_DOC_ERNPE_SND_YN
, REPLACE(REPLACE(AJST_DOC_ADD_DSC_CON,CHR(13),''),CHR(10),'') AJST_DOC_ADD_DSC_CON FROM THDDH_TCLPAY
                       WHERE \$CONDITIONS "\
    --m 8 \
    --boundary-query "SELECT 0, 7 FROM DUAL"\
    --split-by "ORA_HASH(DCN_ID, 7)"\
    --target-dir /tmp2/LAST_THDDH_TCLPAY \
    --hive-import \
    --external-table-dir hdfs:///tmp2/temp_tbl/LAST_THDDH_TCLPAY \
    --hive-overwrite \
    --hive-table DEFAULT.LAST_THDDH_TCLPAY  >> ${SHLOG_DIR}/THDDH_TCLPAY.shlog 2>&1 &&

#----------------------------------------------------#
# Hadoop 원본테이블에 변경분 최종 적용
#----------------------------------------------------#
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TCLPAY_TMP ; " >> ${SHLOG_DIR}/THDDH_TCLPAY.shlog 2>&1 &&
    /usr/bin/hive -e "CREATE EXTERNAL TABLE MERITZ.THDDH_TCLPAY_TMP STORED AS PARQUET TBLPROPERTIES ('PARQUET.COMPRESS'='SNAPPY') AS
                                SELECT *
                                FROM DEFAULT.LAST_THDDH_TCLPAY ;" >> ${SHLOG_DIR}/THDDH_TCLPAY.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.LAST_THDDH_TCLPAY ;" >> ${SHLOG_DIR}/THDDH_TCLPAY.shlog 2>&1 &&
    /usr/bin/hdfs dfs -rm -r -f -skipTrash /tmp2/temp_tbl/LAST_THDDH_TCLPAY >> ${SHLOG_DIR}/THDDH_TCLPAY.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TCLPAY ;" >> ${SHLOG_DIR}/THDDH_TCLPAY.shlog 2>&1 &&
    /usr/bin/hive -e "ALTER TABLE MERITZ.THDDH_TCLPAY_TMP RENAME TO MERITZ.THDDH_TCLPAY ;" >> ${SHLOG_DIR}/THDDH_TCLPAY.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TCLPAY_TMP ;" >> ${SHLOG_DIR}/THDDH_TCLPAY.shlog 2>&1 

if [ $? -ne 0 ]
then             
    echo "*-----------[ THDDH_TCLPAY.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/THDDH_TCLPAY.shlog"
    echo "*-----------[ THDDH_TCLPAY.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/THDDH_TCLPAY.shlog"  >>  ${SHLOG_DIR}/THDDH_TCLPAY.shlog
    echo "*-----------[ THDDH_TCLPAY.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TCLPAY.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/THDDH_TCLPAY.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/THDDH_TCLPAY.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCLPAY.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCLPAY.shlog /sqoopbin/scripts/etlpgm/his_log/THDDH_TCLPAY_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  THDDH_TCLPAY.sh cmd command error !! ***
    fi               

    exit -1      

else             
    echo "*-----------[ THDDH_TCLPAY.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TCLPAY.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/THDDH_TCLPAY.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/THDDH_TCLPAY.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCLPAY.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCLPAY.shlog /sqoopbin/scripts/etlpgm/his_log/THDDH_TCLPAY_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  THDDH_TCLPAY.sh cmd command error !! ***
        exit -1      
    else             
        exit 0       
    fi               
fi               
