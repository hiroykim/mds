#!/bin/bash

if [ $# -eq 0 ]
then           
    ARGS=N    
else           
    ARGS=$1
fi             

NOW=$(date +"+%Y-%m-%d_%T")
SHLOG_DIR=/sqoopbin/scripts/etlpgm/cur_log
HISLOG_DIR=/sqoopbin/scripts/etlpgm/his_log

export HADOOP_OPTS=-Djava.security.egd=file:/dev/../dev/urandom
export ORACLE_BASE=/sw/oracle
export ORACLE_HOME=/sw/oracle/product/11.2.0.4/client_1
export LD_LIBRARY_PATH=/sw/oracle/product/11.2.0.4/client_1/lib:/sw/oracle/product/11.2.0.4/client_1/lib:
export PATH=/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/usr/lib64/qt-3.3/bin:/usr/hdp/3.0.0.0-1634/spark2/bin/:/var/opt/node/bin/:/opt/maven/bin:/usr/local/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/home/hdpapp/workspace/data-science-at-the-command-line/tools:/home/hdpapp/.local/bin:/home/hdpapp/bin
export TNS_ADMIN=/sw/oracle/product/11.2.0.4/client_1/network/admin
export ORACLE_SID=DBEDWP2
export NLS_LANG=American_America.KO16MSWIN949

#----------------------------------------------------#
# 작업내용 : THDDH_TCOORGMMCL 테이블 sqoop 복제 작업
# 작업주기 :  
#----------------------------------------------------#

    echo " "
    echo "*-----------[ THDDH_TCOORGMMCL.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TCOORGMMCL.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`  >  ${SHLOG_DIR}/THDDH_TCOORGMMCL.shlog

#----------------------------------------------------#
# 테이블별 전체 데이터를 받아 오는 부분
#----------------------------------------------------#
    /usr/bin/hadoop fs -rm -r -f  /tmp2/LAST_THDDH_TCOORGMMCL  >> ${SHLOG_DIR}/THDDH_TCOORGMMCL.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.LAST_THDDH_TCOORGMMCL ; " >> ${SHLOG_DIR}/THDDH_TCOORGMMCL.shlog 2>&1 &&
    /usr/hdp/3.0.0.0-1634/sqoop/bin/sqoop import -D mapred.child.java.opts="-Djava.security.egd=file:/dev/../dev/urandom" \
    --connect jdbc:oracle:thin:EDWHADOOP/wjdqhrP\!23@10.91.41.172:12560:DBEDWP2 \
    --username  EDWHADOOP \
    --password wjdqhrP\!23 \
    --query "SELECT /*+ FULL(THDDH_TCOORGMMCL) */ REPLACE(REPLACE(STD_YYMM,CHR(13),''),CHR(10),'') STD_YYMM
, REPLACE(REPLACE(ORG_CLAS_DIV_CD,CHR(13),''),CHR(10),'') ORG_CLAS_DIV_CD
, REPLACE(REPLACE(ORG_ID,CHR(13),''),CHR(10),'') ORG_ID
, REPLACE(REPLACE(ORG_CD,CHR(13),''),CHR(10),'') ORG_CD
, REPLACE(REPLACE(ORG_NM,CHR(13),''),CHR(10),'') ORG_NM
, REPLACE(REPLACE(ORG_DAT_DIV_CD,CHR(13),''),CHR(10),'') ORG_DAT_DIV_CD
, REPLACE(REPLACE(ORG_STAT_CD,CHR(13),''),CHR(10),'') ORG_STAT_CD
, REPLACE(REPLACE(ORG_TP_CD,CHR(13),''),CHR(10),'') ORG_TP_CD
, REPLACE(REPLACE(ORG_DIV_CD,CHR(13),''),CHR(10),'') ORG_DIV_CD
, REPLACE(REPLACE(ORG_SH_DIV_CD,CHR(13),''),CHR(10),'') ORG_SH_DIV_CD
, REPLACE(REPLACE(CHN_DIV_CD,CHR(13),''),CHR(10),'') CHN_DIV_CD
, REPLACE(REPLACE(SELF_CUS_ID,CHR(13),''),CHR(10),'') SELF_CUS_ID
, REPLACE(REPLACE(RPS_CUS_ID,CHR(13),''),CHR(10),'') RPS_CUS_ID
, REPLACE(REPLACE(HGRK_ORG_ID,CHR(13),''),CHR(10),'') HGRK_ORG_ID
, REPLACE(REPLACE(HGRK_ORG_CD,CHR(13),''),CHR(10),'') HGRK_ORG_CD
, REPLACE(REPLACE(HGRK_ORG_NM,CHR(13),''),CHR(10),'') HGRK_ORG_NM
, REPLACE(REPLACE(HGRK_ORG_TP_CD,CHR(13),''),CHR(10),'') HGRK_ORG_TP_CD
, REPLACE(REPLACE(HGRK_ORG_DIV_CD,CHR(13),''),CHR(10),'') HGRK_ORG_DIV_CD
, REPLACE(REPLACE(SMRZ_ORG_ID,CHR(13),''),CHR(10),'') SMRZ_ORG_ID
, REPLACE(REPLACE(SMRZ_ORG_CD,CHR(13),''),CHR(10),'') SMRZ_ORG_CD
, REPLACE(REPLACE(SMRZ_ORG_NM,CHR(13),''),CHR(10),'') SMRZ_ORG_NM
, REPLACE(REPLACE(BZ_SB_THNK_CMTT_ORG_ID,CHR(13),''),CHR(10),'') BZ_SB_THNK_CMTT_ORG_ID
, REPLACE(REPLACE(BZ_SB_ADT_CMTT_ORG_CD,CHR(13),''),CHR(10),'') BZ_SB_ADT_CMTT_ORG_CD
, REPLACE(REPLACE(BZ_SB_ADT_CMTT_ORG_NM,CHR(13),''),CHR(10),'') BZ_SB_ADT_CMTT_ORG_NM
, REPLACE(REPLACE(HDQT_ORG_ID,CHR(13),''),CHR(10),'') HDQT_ORG_ID
, REPLACE(REPLACE(HDQT_ORG_CD,CHR(13),''),CHR(10),'') HDQT_ORG_CD
, REPLACE(REPLACE(HDQT_ORG_NM,CHR(13),''),CHR(10),'') HDQT_ORG_NM
, REPLACE(REPLACE(BRCH_ORG_ID,CHR(13),''),CHR(10),'') BRCH_ORG_ID
, REPLACE(REPLACE(BRCH_ORG_CD,CHR(13),''),CHR(10),'') BRCH_ORG_CD
, REPLACE(REPLACE(BRCH_ORG_NM,CHR(13),''),CHR(10),'') BRCH_ORG_NM
, REPLACE(REPLACE(BCH_ORG_ID,CHR(13),''),CHR(10),'') BCH_ORG_ID
, REPLACE(REPLACE(BCH_ORG_CD,CHR(13),''),CHR(10),'') BCH_ORG_CD
, REPLACE(REPLACE(BCH_ORG_NM,CHR(13),''),CHR(10),'') BCH_ORG_NM
, REPLACE(REPLACE(BCH_DRBG_TEM_ORG_ID,CHR(13),''),CHR(10),'') BCH_DRBG_TEM_ORG_ID
, REPLACE(REPLACE(BCH_DRBG_TEM_ORG_CD,CHR(13),''),CHR(10),'') BCH_DRBG_TEM_ORG_CD
, REPLACE(REPLACE(BCH_DRBG_TEM_NM,CHR(13),''),CHR(10),'') BCH_DRBG_TEM_NM
, REPLACE(REPLACE(SLZ_FML_ORG_ID,CHR(13),''),CHR(10),'') SLZ_FML_ORG_ID
, REPLACE(REPLACE(SLZ_FML_ORG_CD,CHR(13),''),CHR(10),'') SLZ_FML_ORG_CD
, REPLACE(REPLACE(SLZ_FML_NM,CHR(13),''),CHR(10),'') SLZ_FML_NM
, REPLACE(REPLACE(RLMR_ORG_ID,CHR(13),''),CHR(10),'') RLMR_ORG_ID
, REPLACE(REPLACE(RLMR_ORG_CD,CHR(13),''),CHR(10),'') RLMR_ORG_CD
, REPLACE(REPLACE(RLMR_ORG_NM,CHR(13),''),CHR(10),'') RLMR_ORG_NM
, REPLACE(REPLACE(AGC_BROF_ORG_ID,CHR(13),''),CHR(10),'') AGC_BROF_ORG_ID
, REPLACE(REPLACE(AGC_BROF_ORG_CD,CHR(13),''),CHR(10),'') AGC_BROF_ORG_CD
, REPLACE(REPLACE(AGC_BROF_NM,CHR(13),''),CHR(10),'') AGC_BROF_NM
, REPLACE(REPLACE(AGPLR_ORG_ID,CHR(13),''),CHR(10),'') AGPLR_ORG_ID
, REPLACE(REPLACE(AGC_PLNR_ORG_CD,CHR(13),''),CHR(10),'') AGC_PLNR_ORG_CD
, REPLACE(REPLACE(AGPLR_NM,CHR(13),''),CHR(10),'') AGPLR_NM
, OPE_DT
, CLSU_DT
, OPE_DMM
, SRT_SQ
, REPLACE(REPLACE(UPB_INSTL_CD,CHR(13),''),CHR(10),'') UPB_INSTL_CD
, REPLACE(REPLACE(OFRP_CD,CHR(13),''),CHR(10),'') OFRP_CD
, REPLACE(REPLACE(OFPOS_CD,CHR(13),''),CHR(10),'') OFPOS_CD
, REPLACE(REPLACE(FEE_PAY_TP_CD,CHR(13),''),CHR(10),'') FEE_PAY_TP_CD
, CRR_DMM
, REPLACE(REPLACE(INS_CRR_CD,CHR(13),''),CHR(10),'') INS_CRR_CD
, REPLACE(REPLACE(INTRD_PTH_CD,CHR(13),''),CHR(10),'') INTRD_PTH_CD
, REPLACE(REPLACE(INTRD_TP_CD,CHR(13),''),CHR(10),'') INTRD_TP_CD
, REPLACE(REPLACE(ORG_STGE_CD,CHR(13),''),CHR(10),'') ORG_STGE_CD
, REPLACE(REPLACE(SLZ_SH_DIV_CD,CHR(13),''),CHR(10),'') SLZ_SH_DIV_CD
, REPLACE(REPLACE(RRN_BDT,CHR(13),''),CHR(10),'') RRN_BDT
, REPLACE(REPLACE(GNDR_CD,CHR(13),''),CHR(10),'') GNDR_CD
, AGE
, REPLACE(REPLACE(SCPOS_CONV_CD,CHR(13),''),CHR(10),'') SCPOS_CONV_CD
, REPLACE(REPLACE(BF_PST_PTNCO_CD,CHR(13),''),CHR(10),'') BF_PST_PTNCO_CD
, REPLACE(REPLACE(INDV_CRP_DIV_CD,CHR(13),''),CHR(10),'') INDV_CRP_DIV_CD
, REPLACE(REPLACE(AGC_CTR_TP_CD,CHR(13),''),CHR(10),'') AGC_CTR_TP_CD
, REPLACE(REPLACE(AGC_TPIDS_DIV_CD,CHR(13),''),CHR(10),'') AGC_TPIDS_DIV_CD
, REPLACE(REPLACE(BNCA_COPR_FNC_INST_CD,CHR(13),''),CHR(10),'') BNCA_COPR_FNC_INST_CD
, REPLACE(REPLACE(AGC_MVIN_SH_CD,CHR(13),''),CHR(10),'') AGC_MVIN_SH_CD
, REPLACE(REPLACE(CONV_CRP_DIV_CD,CHR(13),''),CHR(10),'') CONV_CRP_DIV_CD
, SDJOB_CCLU_DT
, REPLACE(REPLACE(AGC_RPSPE_NM,CHR(13),''),CHR(10),'') AGC_RPSPE_NM
, REPLACE(REPLACE(CRSS_SAL_PTNCO_CD,CHR(13),''),CHR(10),'') CRSS_SAL_PTNCO_CD
, REPLACE(REPLACE(AGPLR_DIV_CD,CHR(13),''),CHR(10),'') AGPLR_DIV_CD
, REPLACE(REPLACE(AGPLR_REQ_PTNCO_CD,CHR(13),''),CHR(10),'') AGPLR_REQ_PTNCO_CD
, REPLACE(REPLACE(BFT_ORG_ID,CHR(13),''),CHR(10),'') BFT_ORG_ID
, REPLACE(REPLACE(BFT_ORG_CD,CHR(13),''),CHR(10),'') BFT_ORG_CD
, REPLACE(REPLACE(BFT_ORG_NM,CHR(13),''),CHR(10),'') BFT_ORG_NM
, BFT_ORG_OPE_DT
, BFT_ORG_CLSU_DT
, REPLACE(REPLACE(INDC_ORG_ID,CHR(13),''),CHR(10),'') INDC_ORG_ID
, REPLACE(REPLACE(INDC_ORG_CD,CHR(13),''),CHR(10),'') INDC_ORG_CD
, REPLACE(REPLACE(INDC_ORG_NM,CHR(13),''),CHR(10),'') INDC_ORG_NM
, REPLACE(REPLACE(NWCM_CORR_CD,CHR(13),''),CHR(10),'') NWCM_CORR_CD
, REPLACE(REPLACE(POSI_DIV_CD,CHR(13),''),CHR(10),'') POSI_DIV_CD
, REPLACE(REPLACE(INPPE_ORG_ID,CHR(13),''),CHR(10),'') INPPE_ORG_ID
, SYS_OCC_DTM
, REPLACE(REPLACE(SYS_DEL_DIV_CD,CHR(13),''),CHR(10),'') SYS_DEL_DIV_CD
, REPLACE(REPLACE(APP_ID,CHR(13),''),CHR(10),'') APP_ID
, REPLACE(REPLACE(OCC_IP,CHR(13),''),CHR(10),'') OCC_IP
, DATA_CHNG_DTM
, REPLACE(REPLACE(CRSS_SAL_YN,CHR(13),''),CHR(10),'') CRSS_SAL_YN
, EIH_LDG_DTM FROM THDDH_TCOORGMMCL
                       WHERE \$CONDITIONS "\
    --m 8 \
    --boundary-query "SELECT 0, 7 FROM DUAL"\
    --split-by "ORA_HASH(ORG_ID, 7)"\
    --target-dir /tmp2/LAST_THDDH_TCOORGMMCL \
    --hive-import \
    --external-table-dir hdfs:///tmp2/temp_tbl/LAST_THDDH_TCOORGMMCL \
    --hive-overwrite \
    --hive-table DEFAULT.LAST_THDDH_TCOORGMMCL  >> ${SHLOG_DIR}/THDDH_TCOORGMMCL.shlog 2>&1 &&

#----------------------------------------------------#
# Hadoop 원본테이블에 변경분 최종 적용
#----------------------------------------------------#
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TCOORGMMCL_TMP ; " >> ${SHLOG_DIR}/THDDH_TCOORGMMCL.shlog 2>&1 &&
    /usr/bin/hive -e "CREATE EXTERNAL TABLE MERITZ.THDDH_TCOORGMMCL_TMP STORED AS PARQUET TBLPROPERTIES ('PARQUET.COMPRESS'='SNAPPY') AS
                                SELECT *
                                FROM DEFAULT.LAST_THDDH_TCOORGMMCL ;" >> ${SHLOG_DIR}/THDDH_TCOORGMMCL.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.LAST_THDDH_TCOORGMMCL ;" >> ${SHLOG_DIR}/THDDH_TCOORGMMCL.shlog 2>&1 &&
    /usr/bin/hdfs dfs -rm -r -f -skipTrash /tmp2/temp_tbl/LAST_THDDH_TCOORGMMCL >> ${SHLOG_DIR}/THDDH_TCOORGMMCL.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TCOORGMMCL ;" >> ${SHLOG_DIR}/THDDH_TCOORGMMCL.shlog 2>&1 &&
    /usr/bin/hive -e "ALTER TABLE MERITZ.THDDH_TCOORGMMCL_TMP RENAME TO MERITZ.THDDH_TCOORGMMCL ;" >> ${SHLOG_DIR}/THDDH_TCOORGMMCL.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TCOORGMMCL_TMP ;" >> ${SHLOG_DIR}/THDDH_TCOORGMMCL.shlog 2>&1 

if [ $? -ne 0 ]
then             
    echo "*-----------[ THDDH_TCOORGMMCL.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/THDDH_TCOORGMMCL.shlog"
    echo "*-----------[ THDDH_TCOORGMMCL.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/THDDH_TCOORGMMCL.shlog"  >>  ${SHLOG_DIR}/THDDH_TCOORGMMCL.shlog
    echo "*-----------[ THDDH_TCOORGMMCL.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TCOORGMMCL.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/THDDH_TCOORGMMCL.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/THDDH_TCOORGMMCL.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCOORGMMCL.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCOORGMMCL.shlog /sqoopbin/scripts/etlpgm/his_log/THDDH_TCOORGMMCL_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  THDDH_TCOORGMMCL.sh cmd command error !! ***
    fi               

    exit -1      

else             
    echo "*-----------[ THDDH_TCOORGMMCL.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TCOORGMMCL.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/THDDH_TCOORGMMCL.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/THDDH_TCOORGMMCL.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCOORGMMCL.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCOORGMMCL.shlog /sqoopbin/scripts/etlpgm/his_log/THDDH_TCOORGMMCL_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  THDDH_TCOORGMMCL.sh cmd command error !! ***
        exit -1      
    else             
        exit 0       
    fi               
fi               
