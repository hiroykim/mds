#!/bin/bash

if [ $# -eq 0 ]
then           
    ARGS=N    
else           
    ARGS=$1
fi             

NOW=$(date +"+%Y-%m-%d_%T")
SHLOG_DIR=/sqoopbin/scripts/etlpgm/cur_log
HISLOG_DIR=/sqoopbin/scripts/etlpgm/his_log

export HADOOP_OPTS=-Djava.security.egd=file:/dev/../dev/urandom
export ORACLE_BASE=/sw/oracle
export ORACLE_HOME=/sw/oracle/product/11.2.0.4/client_1
export LD_LIBRARY_PATH=/sw/oracle/product/11.2.0.4/client_1/lib:/sw/oracle/product/11.2.0.4/client_1/lib:
export PATH=/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/usr/lib64/qt-3.3/bin:/usr/hdp/3.0.0.0-1634/spark2/bin/:/var/opt/node/bin/:/opt/maven/bin:/usr/local/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/home/hdpapp/workspace/data-science-at-the-command-line/tools:/home/hdpapp/.local/bin:/home/hdpapp/bin
export TNS_ADMIN=/sw/oracle/product/11.2.0.4/client_1/network/admin
export ORACLE_SID=DBEDWP2
export NLS_LANG=American_America.KO16MSWIN949

#----------------------------------------------------#
# 작업내용 : THDDH_TSASLZCPCL 테이블 sqoop 복제 작업
# 작업주기 :  
#----------------------------------------------------#

    echo " "
    echo "*-----------[ THDDH_TSASLZCPCL.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TSASLZCPCL.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`  >  ${SHLOG_DIR}/THDDH_TSASLZCPCL.shlog

#----------------------------------------------------#
# 테이블별 전체 데이터를 받아 오는 부분
#----------------------------------------------------#
    /usr/bin/hadoop fs -rm -r -f  /tmp2/LAST_THDDH_TSASLZCPCL  >> ${SHLOG_DIR}/THDDH_TSASLZCPCL.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.LAST_THDDH_TSASLZCPCL ; " >> ${SHLOG_DIR}/THDDH_TSASLZCPCL.shlog 2>&1 &&
    /usr/hdp/3.0.0.0-1634/sqoop/bin/sqoop import -D mapred.child.java.opts="-Djava.security.egd=file:/dev/../dev/urandom" \
    --connect jdbc:oracle:thin:EDWHADOOP/wjdqhrP\!23@10.91.41.172:12560:DBEDWP2 \
    --username  EDWHADOOP \
    --password wjdqhrP\!23 \
    --query "SELECT /*+ FULL(THDDH_TSASLZCPCL) */ REPLACE(REPLACE(ORG_ID,CHR(13),''),CHR(10),'') ORG_ID
, REPLACE(REPLACE(STD_YYMM,CHR(13),''),CHR(10),'') STD_YYMM
, STD_DNO
, REPLACE(REPLACE(PSA_CLOG_BIZ_DIV_CD,CHR(13),''),CHR(10),'') PSA_CLOG_BIZ_DIV_CD
, REPLACE(REPLACE(ORG_DIV_CD,CHR(13),''),CHR(10),'') ORG_DIV_CD
, REPLACE(REPLACE(AGC_CTR_TP_CD,CHR(13),''),CHR(10),'') AGC_CTR_TP_CD
, REPLACE(REPLACE(INDV_CRP_DIV_CD,CHR(13),''),CHR(10),'') INDV_CRP_DIV_CD
, REPLACE(REPLACE(FEE_SLZ_FML_DIV_CD,CHR(13),''),CHR(10),'') FEE_SLZ_FML_DIV_CD
, REPLACE(REPLACE(ORG_SH_DIV_CD,CHR(13),''),CHR(10),'') ORG_SH_DIV_CD
, REPLACE(REPLACE(SLZ_FML_NM,CHR(13),''),CHR(10),'') SLZ_FML_NM
, REPLACE(REPLACE(PSA_CLOG_ORG_STAT_CD,CHR(13),''),CHR(10),'') PSA_CLOG_ORG_STAT_CD
, REPLACE(REPLACE(FEE_PAY_TP_CD,CHR(13),''),CHR(10),'') FEE_PAY_TP_CD
, REPLACE(REPLACE(BFT_FEE_PAY_TP_CD,CHR(13),''),CHR(10),'') BFT_FEE_PAY_TP_CD
, REPLACE(REPLACE(BZ_SB_ORG_ID,CHR(13),''),CHR(10),'') BZ_SB_ORG_ID
, REPLACE(REPLACE(BZ_SB_ORG_NM,CHR(13),''),CHR(10),'') BZ_SB_ORG_NM
, REPLACE(REPLACE(HDQT_ORG_ID,CHR(13),''),CHR(10),'') HDQT_ORG_ID
, REPLACE(REPLACE(HDQT_ORG_NM,CHR(13),''),CHR(10),'') HDQT_ORG_NM
, REPLACE(REPLACE(BRCH_ORG_ID,CHR(13),''),CHR(10),'') BRCH_ORG_ID
, REPLACE(REPLACE(BRCH_ORG_NM,CHR(13),''),CHR(10),'') BRCH_ORG_NM
, REPLACE(REPLACE(BCH_ORG_ID,CHR(13),''),CHR(10),'') BCH_ORG_ID
, REPLACE(REPLACE(BCH_ORG_NM,CHR(13),''),CHR(10),'') BCH_ORG_NM
, REPLACE(REPLACE(TEM_ORG_ID,CHR(13),''),CHR(10),'') TEM_ORG_ID
, REPLACE(REPLACE(TEM_ORG_NM,CHR(13),''),CHR(10),'') TEM_ORG_NM
, REPLACE(REPLACE(OFC_ORG_ID,CHR(13),''),CHR(10),'') OFC_ORG_ID
, OPE_DT
, CLSU_DT
, REPLACE(REPLACE(BFT_ORG_ID,CHR(13),''),CHR(10),'') BFT_ORG_ID
, REPLACE(REPLACE(SCPOS_CONV_CD,CHR(13),''),CHR(10),'') SCPOS_CONV_CD
, REPLACE(REPLACE(INTRD_TP_CD,CHR(13),''),CHR(10),'') INTRD_TP_CD
, BFT_ORG_OPE_DT
, BFT_ORG_CLSU_DT
, REPLACE(REPLACE(OFRP_CD,CHR(13),''),CHR(10),'') OFRP_CD
, ENTCO_DMM
, CRR_DMM
, REPLACE(REPLACE(INDC_ORG_ID,CHR(13),''),CHR(10),'') INDC_ORG_ID
, REPLACE(REPLACE(CRSS_SAL_YN,CHR(13),''),CHR(10),'') CRSS_SAL_YN
, REPLACE(REPLACE(NWCM_GRDE_VAL,CHR(13),''),CHR(10),'') NWCM_GRDE_VAL
, REPLACE(REPLACE(FTJB_GRDE_VAL,CHR(13),''),CHR(10),'') FTJB_GRDE_VAL
, REPLACE(REPLACE(TMGM_GRDE_VAL,CHR(13),''),CHR(10),'') TMGM_GRDE_VAL
, REPLACE(REPLACE(NWCM_CORR_CD,CHR(13),''),CHR(10),'') NWCM_CORR_CD
, PSA_CLOG_DT
, AGE
, REPLACE(REPLACE(GNDR_CD,CHR(13),''),CHR(10),'') GNDR_CD
, REPLACE(REPLACE(CRSS_SAL_PTNCO_CD,CHR(13),''),CHR(10),'') CRSS_SAL_PTNCO_CD
, REPLACE(REPLACE(GUEMP_ORG_ID,CHR(13),''),CHR(10),'') GUEMP_ORG_ID
, REPLACE(REPLACE(AG_CHN_DIV_CD,CHR(13),''),CHR(10),'') AG_CHN_DIV_CD
, REPLACE(REPLACE(OPR_EXP_ORG_DIV_CD,CHR(13),''),CHR(10),'') OPR_EXP_ORG_DIV_CD
, REPLACE(REPLACE(INPPE_ORG_ID,CHR(13),''),CHR(10),'') INPPE_ORG_ID
, SYS_OCC_DTM
, REPLACE(REPLACE(SYS_DEL_DIV_CD,CHR(13),''),CHR(10),'') SYS_DEL_DIV_CD
, REPLACE(REPLACE(APP_ID,CHR(13),''),CHR(10),'') APP_ID
, REPLACE(REPLACE(OCC_IP,CHR(13),''),CHR(10),'') OCC_IP
, DATA_CHNG_DTM
, REPLACE(REPLACE(CMPU_EQUP_REG_YYMM,CHR(13),''),CHR(10),'') CMPU_EQUP_REG_YYMM
, REPLACE(REPLACE(UPB_CEN_ORG_ID,CHR(13),''),CHR(10),'') UPB_CEN_ORG_ID
, REPLACE(REPLACE(UPB_DRBG_TEM_ORG_ID,CHR(13),''),CHR(10),'') UPB_DRBG_TEM_ORG_ID
, EIH_LDG_DTM
, REPLACE(REPLACE(FEE_CHN_DIV_CD,CHR(13),''),CHR(10),'') FEE_CHN_DIV_CD FROM THDDH_TSASLZCPCL
                       WHERE \$CONDITIONS "\
    --m 8 \
    --boundary-query "SELECT 0, 7 FROM DUAL"\
    --split-by "ORA_HASH(ORG_ID, 7)"\
    --target-dir /tmp2/LAST_THDDH_TSASLZCPCL \
    --hive-import \
    --external-table-dir hdfs:///tmp2/temp_tbl/LAST_THDDH_TSASLZCPCL \
    --hive-overwrite \
    --hive-table DEFAULT.LAST_THDDH_TSASLZCPCL  >> ${SHLOG_DIR}/THDDH_TSASLZCPCL.shlog 2>&1 &&

#----------------------------------------------------#
# Hadoop 원본테이블에 변경분 최종 적용
#----------------------------------------------------#
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TSASLZCPCL_TMP ; " >> ${SHLOG_DIR}/THDDH_TSASLZCPCL.shlog 2>&1 &&
    /usr/bin/hive -e "CREATE EXTERNAL TABLE MERITZ.THDDH_TSASLZCPCL_TMP STORED AS PARQUET TBLPROPERTIES ('PARQUET.COMPRESS'='SNAPPY') AS
                                SELECT *
                                FROM DEFAULT.LAST_THDDH_TSASLZCPCL ;" >> ${SHLOG_DIR}/THDDH_TSASLZCPCL.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.LAST_THDDH_TSASLZCPCL ;" >> ${SHLOG_DIR}/THDDH_TSASLZCPCL.shlog 2>&1 &&
    /usr/bin/hdfs dfs -rm -r -f -skipTrash /tmp2/temp_tbl/LAST_THDDH_TSASLZCPCL >> ${SHLOG_DIR}/THDDH_TSASLZCPCL.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TSASLZCPCL ;" >> ${SHLOG_DIR}/THDDH_TSASLZCPCL.shlog 2>&1 &&
    /usr/bin/hive -e "ALTER TABLE MERITZ.THDDH_TSASLZCPCL_TMP RENAME TO MERITZ.THDDH_TSASLZCPCL ;" >> ${SHLOG_DIR}/THDDH_TSASLZCPCL.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TSASLZCPCL_TMP ;" >> ${SHLOG_DIR}/THDDH_TSASLZCPCL.shlog 2>&1 

if [ $? -ne 0 ]
then             
    echo "*-----------[ THDDH_TSASLZCPCL.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/THDDH_TSASLZCPCL.shlog"
    echo "*-----------[ THDDH_TSASLZCPCL.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/THDDH_TSASLZCPCL.shlog"  >>  ${SHLOG_DIR}/THDDH_TSASLZCPCL.shlog
    echo "*-----------[ THDDH_TSASLZCPCL.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TSASLZCPCL.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/THDDH_TSASLZCPCL.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/THDDH_TSASLZCPCL.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TSASLZCPCL.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TSASLZCPCL.shlog /sqoopbin/scripts/etlpgm/his_log/THDDH_TSASLZCPCL_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  THDDH_TSASLZCPCL.sh cmd command error !! ***
    fi               

    exit -1      

else             
    echo "*-----------[ THDDH_TSASLZCPCL.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TSASLZCPCL.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/THDDH_TSASLZCPCL.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/THDDH_TSASLZCPCL.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TSASLZCPCL.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TSASLZCPCL.shlog /sqoopbin/scripts/etlpgm/his_log/THDDH_TSASLZCPCL_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  THDDH_TSASLZCPCL.sh cmd command error !! ***
        exit -1      
    else             
        exit 0       
    fi               
fi               
