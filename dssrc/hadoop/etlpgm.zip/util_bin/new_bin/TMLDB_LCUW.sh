#!/bin/bash

if [ $# -eq 0 ]
then           
    ARGS=N    
else           
    ARGS=$1
fi             

NOW=$(date +"+%Y-%m-%d_%T")
SHLOG_DIR=/sqoopbin/scripts/etlpgm/cur_log
HISLOG_DIR=/sqoopbin/scripts/etlpgm/his_log

export HADOOP_OPTS=-Djava.security.egd=file:/dev/../dev/urandom
export ORACLE_BASE=/sw/oracle
export ORACLE_HOME=/sw/oracle/product/11.2.0.4/client_1
export LD_LIBRARY_PATH=/sw/oracle/product/11.2.0.4/client_1/lib:/sw/oracle/product/11.2.0.4/client_1/lib:
export PATH=/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/usr/lib64/qt-3.3/bin:/usr/hdp/3.0.0.0-1634/spark2/bin/:/var/opt/node/bin/:/opt/maven/bin:/usr/local/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/home/hdpapp/workspace/data-science-at-the-command-line/tools:/home/hdpapp/.local/bin:/home/hdpapp/bin
export TNS_ADMIN=/sw/oracle/product/11.2.0.4/client_1/network/admin
export ORACLE_SID=DBEDWP2
export NLS_LANG=American_America.KO16MSWIN949

#----------------------------------------------------#
# 작업내용 : TMLDB_LCUW 테이블 sqoop 복제 작업
# 작업주기 :  
#----------------------------------------------------#

    echo " "
    echo "*-----------[ TMLDB_LCUW.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ TMLDB_LCUW.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`  >  ${SHLOG_DIR}/TMLDB_LCUW.shlog

#----------------------------------------------------#
# 테이블별 전체 데이터를 받아 오는 부분
#----------------------------------------------------#
    /usr/bin/hadoop fs -rm -r -f  /tmp2/LAST_TMLDB_LCUW  >> ${SHLOG_DIR}/TMLDB_LCUW.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.LAST_TMLDB_LCUW ; " >> ${SHLOG_DIR}/TMLDB_LCUW.shlog 2>&1 &&
    /usr/hdp/3.0.0.0-1634/sqoop/bin/sqoop import -D mapred.child.java.opts="-Djava.security.egd=file:/dev/../dev/urandom" \
    --connect jdbc:oracle:thin:EDWHADOOP/wjdqhrP\!23@10.91.41.172:12560:DBEDWP2 \
    --username  EDWHADOOP \
    --password wjdqhrP\!23 \
    --query "SELECT /*+ FULL(TMLDB_LCUW) */ STD_DT
, REPLACE(REPLACE(CLOG_DIV_CD,CHR(13),''),CHR(10),'') CLOG_DIV_CD
, REPLACE(REPLACE(UW_ID,CHR(13),''),CHR(10),'') UW_ID
, REPLACE(REPLACE(CLOG_YYMM,CHR(13),''),CHR(10),'') CLOG_YYMM
, REPLACE(REPLACE(ISP_NO,CHR(13),''),CHR(10),'') ISP_NO
, REPLACE(REPLACE(TRT_HDQT_ORG_ID,CHR(13),''),CHR(10),'') TRT_HDQT_ORG_ID
, REPLACE(REPLACE(TRT_HDQT_ORG_CD,CHR(13),''),CHR(10),'') TRT_HDQT_ORG_CD
, REPLACE(REPLACE(TRT_BRCH_ORG_ID,CHR(13),''),CHR(10),'') TRT_BRCH_ORG_ID
, REPLACE(REPLACE(TRT_BRCH_ORG_CD,CHR(13),''),CHR(10),'') TRT_BRCH_ORG_CD
, REPLACE(REPLACE(TRT_BCH_ORG_ID,CHR(13),''),CHR(10),'') TRT_BCH_ORG_ID
, REPLACE(REPLACE(TRT_BCH_ORG_CD,CHR(13),''),CHR(10),'') TRT_BCH_ORG_CD
, REPLACE(REPLACE(TRTPE_ORG_ID,CHR(13),''),CHR(10),'') TRTPE_ORG_ID
, REPLACE(REPLACE(TRTPE_ORG_CD,CHR(13),''),CHR(10),'') TRTPE_ORG_CD
, REPLACE(REPLACE(BROF_PST_HDQT_ORG_ID,CHR(13),''),CHR(10),'') BROF_PST_HDQT_ORG_ID
, REPLACE(REPLACE(BROF_PST_HDQT_ORG_CD,CHR(13),''),CHR(10),'') BROF_PST_HDQT_ORG_CD
, REPLACE(REPLACE(BROF_PST_BRCH_ORG_ID,CHR(13),''),CHR(10),'') BROF_PST_BRCH_ORG_ID
, REPLACE(REPLACE(BROF_PST_BRCH_ORG_CD,CHR(13),''),CHR(10),'') BROF_PST_BRCH_ORG_CD
, REPLACE(REPLACE(TRT_RLMR_ORG_ID,CHR(13),''),CHR(10),'') TRT_RLMR_ORG_ID
, REPLACE(REPLACE(TRT_RLMR_ORG_CD,CHR(13),''),CHR(10),'') TRT_RLMR_ORG_CD
, REPLACE(REPLACE(TRT_AGC_BROF_ORG_ID,CHR(13),''),CHR(10),'') TRT_AGC_BROF_ORG_ID
, REPLACE(REPLACE(TRT_AGC_BROF_ORG_CD,CHR(13),''),CHR(10),'') TRT_AGC_BROF_ORG_CD
, REPLACE(REPLACE(TRT_AGPLR_ORG_ID,CHR(13),''),CHR(10),'') TRT_AGPLR_ORG_ID
, REPLACE(REPLACE(TRT_AGPLR_ORG_CD,CHR(13),''),CHR(10),'') TRT_AGPLR_ORG_CD
, REPLACE(REPLACE(CHN_DIV_CD,CHR(13),''),CHR(10),'') CHN_DIV_CD
, REPLACE(REPLACE(ISP_CLSS_CD,CHR(13),''),CHR(10),'') ISP_CLSS_CD
, REPLACE(REPLACE(ISP_PD_CTG_CD,CHR(13),''),CHR(10),'') ISP_PD_CTG_CD
, REPLACE(REPLACE(ACP_ISP_KD_CD,CHR(13),''),CHR(10),'') ACP_ISP_KD_CD
, REPLACE(REPLACE(ACP_ISP_KD_DTL_CD,CHR(13),''),CHR(10),'') ACP_ISP_KD_DTL_CD
, REPLACE(REPLACE(ISP_CTG_CD,CHR(13),''),CHR(10),'') ISP_CTG_CD
, REPLACE(REPLACE(ISP_TRG_CTG_CD,CHR(13),''),CHR(10),'') ISP_TRG_CTG_CD
, REPLACE(REPLACE(LAST_ISPPE_LV_CD,CHR(13),''),CHR(10),'') LAST_ISPPE_LV_CD
, REPLACE(REPLACE(ISP_STAT_CD,CHR(13),''),CHR(10),'') ISP_STAT_CD
, REPLACE(REPLACE(ISP_RSL_CD,CHR(13),''),CHR(10),'') ISP_RSL_CD
, REPLACE(REPLACE(REQPE_ORG_ID,CHR(13),''),CHR(10),'') REQPE_ORG_ID
, REPLACE(REPLACE(ISPPE_ORG_ID,CHR(13),''),CHR(10),'') ISPPE_ORG_ID
, REPLACE(REPLACE(ISPPE_ORG_CD,CHR(13),''),CHR(10),'') ISPPE_ORG_CD
, REPLACE(REPLACE(ISP_BIZ_CTG_CD,CHR(13),''),CHR(10),'') ISP_BIZ_CTG_CD
, REPLACE(REPLACE(ISP_DTL_CTG_CD,CHR(13),''),CHR(10),'') ISP_DTL_CTG_CD
, REPLACE(REPLACE(ISP_APRT_STD_CTG_CD,CHR(13),''),CHR(10),'') ISP_APRT_STD_CTG_CD
, RSL_DPC_REQ_DT
, REQ_TMS
, REQ_DTM
, APV_DTM
, REPLACE(REPLACE(POL_NO,CHR(13),''),CHR(10),'') POL_NO
, REPLACE(REPLACE(PRCTR_NO,CHR(13),''),CHR(10),'') PRCTR_NO
, REPLACE(REPLACE(SAL_PD_CD,CHR(13),''),CHR(10),'') SAL_PD_CD
, REPLACE(REPLACE(UNT_PD_CD,CHR(13),''),CHR(10),'') UNT_PD_CD
, REPLACE(REPLACE(NW_STIC_PD_CTG_CD,CHR(13),''),CHR(10),'') NW_STIC_PD_CTG_CD
, REPLACE(REPLACE(SBCP_CHN_DIV_CD,CHR(13),''),CHR(10),'') SBCP_CHN_DIV_CD
, REPLACE(REPLACE(POLHD_CUS_ID,CHR(13),''),CHR(10),'') POLHD_CUS_ID
, REPLACE(REPLACE(POLHD_CUS_NO,CHR(13),''),CHR(10),'') POLHD_CUS_NO
, REPLACE(REPLACE(DUP_SNC_YN,CHR(13),''),CHR(10),'') DUP_SNC_YN
, REPLACE(REPLACE(CNDL_APV_RSN_CD,CHR(13),''),CHR(10),'') CNDL_APV_RSN_CD
, REPLACE(REPLACE(SPPL_RSN_CD,CHR(13),''),CHR(10),'') SPPL_RSN_CD
, REPLACE(REPLACE(RFS_RSN_CD,CHR(13),''),CHR(10),'') RFS_RSN_CD
, SNC_ISP_SEQ
, REPLACE(REPLACE(SNC_ISP_DIV_CD,CHR(13),''),CHR(10),'') SNC_ISP_DIV_CD
, REPLACE(REPLACE(SNC_ISPPE_ORG_ID,CHR(13),''),CHR(10),'') SNC_ISPPE_ORG_ID
, REPLACE(REPLACE(SNC_ISPPE_ORG_CD,CHR(13),''),CHR(10),'') SNC_ISPPE_ORG_CD
, REPLACE(REPLACE(SNC_ISP_STAT_CD,CHR(13),''),CHR(10),'') SNC_ISP_STAT_CD
, REPLACE(REPLACE(SNC_ISP_RSL_CD,CHR(13),''),CHR(10),'') SNC_ISP_RSL_CD
, SNC_ISP_DTM
, REPLACE(REPLACE(CTR_OBJ_ID,CHR(13),''),CHR(10),'') CTR_OBJ_ID
, REPLACE(REPLACE(INSPE_CUS_ID,CHR(13),''),CHR(10),'') INSPE_CUS_ID
, REPLACE(REPLACE(TNG_DIV_CD,CHR(13),''),CHR(10),'') TNG_DIV_CD
, REPLACE(REPLACE(OPN_JBCL_CD,CHR(13),''),CHR(10),'') OPN_JBCL_CD
, REPLACE(REPLACE(ACD_RCT_ID,CHR(13),''),CHR(10),'') ACD_RCT_ID
, REPLACE(REPLACE(ERST_ACD_DIV_CD,CHR(13),''),CHR(10),'') ERST_ACD_DIV_CD
, ACD_OCC_DT
, ACD_RCT_DT
, REPLACE(REPLACE(CTR_ID,CHR(13),''),CHR(10),'') CTR_ID
, INS_BGN_DT
, REPLACE(REPLACE(DATA_DIV_CD,CHR(13),''),CHR(10),'') DATA_DIV_CD
, REPLACE(REPLACE(DATA_ID,CHR(13),''),CHR(10),'') DATA_ID
, ISP_REQ_CNT
, ISP_CNT
, ISP_TCH_CNT
, APV_CNT
, CNDL_APV_CNT
, SPPL_CNT
, RFS_CNT
, PSINS_CNT
, PROP_INS_CNT
, LGTM_ISP_PCS_HR
, CKUP_TRG_CNT
, CKUP_REQ_CNT
, ALTN_CKUP_CNT
, REAL_CKUP_CNT
, PRPT_TRG_CNT
, CNC_CTR_CNT
, CTR_NCCLU_CNT
, SLZ_PREM
, EIH_LDG_DTM
, REPLACE(REPLACE(INSPE_CUS_NO,CHR(13),''),CHR(10),'') INSPE_CUS_NO
, REPLACE(REPLACE(FRS_ISPPE_ORG_ID,CHR(13),''),CHR(10),'') FRS_ISPPE_ORG_ID
, REPLACE(REPLACE(SBC_TNG_DIV_CD,CHR(13),''),CHR(10),'') SBC_TNG_DIV_CD
, REPLACE(REPLACE(SBC_OPN_JBCL_CD,CHR(13),''),CHR(10),'') SBC_OPN_JBCL_CD
, LAST_ISP_DTM
, REPLACE(REPLACE(PY_CYC_CD,CHR(13),''),CHR(10),'') PY_CYC_CD
, GURT_PREM
, MMPY_CNVS_PREM FROM TMLDB_LCUW
                       WHERE \$CONDITIONS "\
    --m 8 \
    --boundary-query "SELECT 0, 7 FROM DUAL"\
    --split-by "ORA_HASH(UW_ID, 7)"\
    --target-dir /tmp2/LAST_TMLDB_LCUW \
    --hive-import \
    --external-table-dir hdfs:///tmp2/temp_tbl/LAST_TMLDB_LCUW \
    --hive-overwrite \
    --hive-table DEFAULT.LAST_TMLDB_LCUW  >> ${SHLOG_DIR}/TMLDB_LCUW.shlog 2>&1 &&

#----------------------------------------------------#
# Hadoop 원본테이블에 변경분 최종 적용
#----------------------------------------------------#
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.TMLDB_LCUW_TMP ; " >> ${SHLOG_DIR}/TMLDB_LCUW.shlog 2>&1 &&
    /usr/bin/hive -e "CREATE EXTERNAL TABLE MERITZ.TMLDB_LCUW_TMP STORED AS PARQUET TBLPROPERTIES ('PARQUET.COMPRESS'='SNAPPY') AS
                                SELECT *
                                FROM DEFAULT.LAST_TMLDB_LCUW ;" >> ${SHLOG_DIR}/TMLDB_LCUW.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.LAST_TMLDB_LCUW ;" >> ${SHLOG_DIR}/TMLDB_LCUW.shlog 2>&1 &&
    /usr/bin/hdfs dfs -rm -r -f -skipTrash /tmp2/temp_tbl/LAST_TMLDB_LCUW >> ${SHLOG_DIR}/TMLDB_LCUW.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.TMLDB_LCUW ;" >> ${SHLOG_DIR}/TMLDB_LCUW.shlog 2>&1 &&
    /usr/bin/hive -e "ALTER TABLE MERITZ.TMLDB_LCUW_TMP RENAME TO MERITZ.TMLDB_LCUW ;" >> ${SHLOG_DIR}/TMLDB_LCUW.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.TMLDB_LCUW_TMP ;" >> ${SHLOG_DIR}/TMLDB_LCUW.shlog 2>&1 

if [ $? -ne 0 ]
then             
    echo "*-----------[ TMLDB_LCUW.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/TMLDB_LCUW.shlog"
    echo "*-----------[ TMLDB_LCUW.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/TMLDB_LCUW.shlog"  >>  ${SHLOG_DIR}/TMLDB_LCUW.shlog
    echo "*-----------[ TMLDB_LCUW.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ TMLDB_LCUW.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/TMLDB_LCUW.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/TMLDB_LCUW.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/TMLDB_LCUW.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/TMLDB_LCUW.shlog /sqoopbin/scripts/etlpgm/his_log/TMLDB_LCUW_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  TMLDB_LCUW.sh cmd command error !! ***
    fi               

    exit -1      

else             
    echo "*-----------[ TMLDB_LCUW.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ TMLDB_LCUW.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/TMLDB_LCUW.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/TMLDB_LCUW.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/TMLDB_LCUW.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/TMLDB_LCUW.shlog /sqoopbin/scripts/etlpgm/his_log/TMLDB_LCUW_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  TMLDB_LCUW.sh cmd command error !! ***
        exit -1      
    else             
        exit 0       
    fi               
fi               
