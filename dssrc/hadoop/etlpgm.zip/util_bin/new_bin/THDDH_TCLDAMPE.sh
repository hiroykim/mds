#!/bin/bash

if [ $# -eq 0 ]
then           
    ARGS=N    
else           
    ARGS=$1
fi             

NOW=$(date +"+%Y-%m-%d_%T")
SHLOG_DIR=/sqoopbin/scripts/etlpgm/cur_log
HISLOG_DIR=/sqoopbin/scripts/etlpgm/his_log

export HADOOP_OPTS=-Djava.security.egd=file:/dev/../dev/urandom
export ORACLE_BASE=/sw/oracle
export ORACLE_HOME=/sw/oracle/product/11.2.0.4/client_1
export LD_LIBRARY_PATH=/sw/oracle/product/11.2.0.4/client_1/lib:/sw/oracle/product/11.2.0.4/client_1/lib:
export PATH=/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/usr/lib64/qt-3.3/bin:/usr/hdp/3.0.0.0-1634/spark2/bin/:/var/opt/node/bin/:/opt/maven/bin:/usr/local/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/home/hdpapp/workspace/data-science-at-the-command-line/tools:/home/hdpapp/.local/bin:/home/hdpapp/bin
export TNS_ADMIN=/sw/oracle/product/11.2.0.4/client_1/network/admin
export ORACLE_SID=DBEDWP2
export NLS_LANG=American_America.KO16MSWIN949

#----------------------------------------------------#
# 작업내용 : THDDH_TCLDAMPE 테이블 sqoop 복제 작업
# 작업주기 :  
#----------------------------------------------------#

    echo " "
    echo "*-----------[ THDDH_TCLDAMPE.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TCLDAMPE.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`  >  ${SHLOG_DIR}/THDDH_TCLDAMPE.shlog

#----------------------------------------------------#
# 테이블별 전체 데이터를 받아 오는 부분
#----------------------------------------------------#
    /usr/bin/hadoop fs -rm -r -f  /tmp2/LAST_THDDH_TCLDAMPE  >> ${SHLOG_DIR}/THDDH_TCLDAMPE.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.LAST_THDDH_TCLDAMPE ; " >> ${SHLOG_DIR}/THDDH_TCLDAMPE.shlog 2>&1 &&
    /usr/hdp/3.0.0.0-1634/sqoop/bin/sqoop import -D mapred.child.java.opts="-Djava.security.egd=file:/dev/../dev/urandom" \
    --connect jdbc:oracle:thin:EDWHADOOP/wjdqhrP\!23@10.91.41.172:12560:DBEDWP2 \
    --username  EDWHADOOP \
    --password wjdqhrP\!23 \
    --query "SELECT /*+ FULL(THDDH_TCLDAMPE) */ REPLACE(REPLACE(DMPE_ID,CHR(13),''),CHR(10),'') DMPE_ID
, HIS_SEQ
, REPLACE(REPLACE(COMS_BIZ_DIV_CD,CHR(13),''),CHR(10),'') COMS_BIZ_DIV_CD
, REPLACE(REPLACE(ACD_NO_YY,CHR(13),''),CHR(10),'') ACD_NO_YY
, ACD_NO_SEQ
, REPLACE(REPLACE(COMS_COV_CD,CHR(13),''),CHR(10),'') COMS_COV_CD
, DAM_ORD
, REPLACE(REPLACE(ACD_RCT_ID,CHR(13),''),CHR(10),'') ACD_RCT_ID
, REPLACE(REPLACE(DMPE_NM,CHR(13),''),CHR(10),'') DMPE_NM
, REPLACE(REPLACE(DMPE_STAT_CD,CHR(13),''),CHR(10),'') DMPE_STAT_CD
, REPLACE(REPLACE(DAM_DIV_CD,CHR(13),''),CHR(10),'') DAM_DIV_CD
, REPLACE(REPLACE(HSP_GHR_DIV_CD,CHR(13),''),CHR(10),'') HSP_GHR_DIV_CD
, REPLACE(REPLACE(SFBT_HELM_WEAR_DIV_CD,CHR(13),''),CHR(10),'') SFBT_HELM_WEAR_DIV_CD
, REPLACE(REPLACE(DAM_SH_CD,CHR(13),''),CHR(10),'') DAM_SH_CD
, REPLACE(REPLACE(NT_INS_ATM_INJR_DIV_CD,CHR(13),''),CHR(10),'') NT_INS_ATM_INJR_DIV_CD
, REPLACE(REPLACE(BORD_POS_CD,CHR(13),''),CHR(10),'') BORD_POS_CD
, REPLACE(REPLACE(OTCR_ACD_ID,CHR(13),''),CHR(10),'') OTCR_ACD_ID
, REPLACE(REPLACE(BORD_VEHC_NO,CHR(13),''),CHR(10),'') BORD_VEHC_NO
, REPLACE(REPLACE(MLTS_DIV_CD,CHR(13),''),CHR(10),'') MLTS_DIV_CD
, SRVC_ED_DT
, REPLACE(REPLACE(JOB_CD,CHR(13),''),CHR(10),'') JOB_CD
, REPLACE(REPLACE(JOB_GRD_CD,CHR(13),''),CHR(10),'') JOB_GRD_CD
, MDI_ST_DT
, DGN_DD_NUM
, CLSR_DD_NUM
, REPLACE(REPLACE(ULDD_YN,CHR(13),''),CHR(10),'') ULDD_YN
, REPLACE(REPLACE(HNR_NT_INS_YN,CHR(13),''),CHR(10),'') HNR_NT_INS_YN
, RCT_DTM
, REPLACE(REPLACE(CPUA_PCS_CD,CHR(13),''),CHR(10),'') CPUA_PCS_CD
, REPLACE(REPLACE(SBC_INSCO_CD,CHR(13),''),CHR(10),'') SBC_INSCO_CD
, RDT_SBTR_RT
, SFBT_NWR_FLT_RT
, BAS_FLT_RT
, LNCR_FLT_RT
, APL_FLT_RT
, RMDD_STD_DT
, EXPET_RMDD
, SHRT_RT
, SHRT_RMDD
, SVV_RMDD
, RMDD_ED_DT
, REPLACE(REPLACE(OVSE_MET_YN,CHR(13),''),CHR(10),'') OVSE_MET_YN
, REPLACE(REPLACE(CLM_TP_CD,CHR(13),''),CHR(10),'') CLM_TP_CD
, REPLACE(REPLACE(ACD_CAUS_LCTG_CD,CHR(13),''),CHR(10),'') ACD_CAUS_LCTG_CD
, REPLACE(REPLACE(ACD_CAUS_MCTG_CD,CHR(13),''),CHR(10),'') ACD_CAUS_MCTG_CD
, REPLACE(REPLACE(ACD_CAUS_SCTG_CD,CHR(13),''),CHR(10),'') ACD_CAUS_SCTG_CD
, REPLACE(REPLACE(ACD_CAUS_DCTG_CD,CHR(13),''),CHR(10),'') ACD_CAUS_DCTG_CD
, REPLACE(REPLACE(ACD_CAUS_DCTG2_CD,CHR(13),''),CHR(10),'') ACD_CAUS_DCTG2_CD
, ACD_CTDG
, REPLACE(REPLACE(PVDS_YN,CHR(13),''),CHR(10),'') PVDS_YN
, REPLACE(REPLACE(ITGR_ACD_RCT_TRG_YN,CHR(13),''),CHR(10),'') ITGR_ACD_RCT_TRG_YN
, REPLACE(REPLACE(PERS_RCT_YN,CHR(13),''),CHR(10),'') PERS_RCT_YN
, REPLACE(REPLACE(PERS_RCT_ACD_CLM_NO,CHR(13),''),CHR(10),'') PERS_RCT_ACD_CLM_NO
, REPLACE(REPLACE(PERS_RCT_INSCO_CD,CHR(13),''),CHR(10),'') PERS_RCT_INSCO_CD
, REPLACE(REPLACE(PERS_NRCT_RSN_CD,CHR(13),''),CHR(10),'') PERS_NRCT_RSN_CD
, REPLACE(REPLACE(PERS_DMPE_ID,CHR(13),''),CHR(10),'') PERS_DMPE_ID
, REPLACE(REPLACE(OBI_NRCT_RSN_CD,CHR(13),''),CHR(10),'') OBI_NRCT_RSN_CD
, REPLACE(REPLACE(OBI_NRCT_RSN_CON,CHR(13),''),CHR(10),'') OBI_NRCT_RSN_CON
, REPLACE(REPLACE(APL_STD_DT_CD,CHR(13),''),CHR(10),'') APL_STD_DT_CD
, APL_STD_DT
, REPLACE(REPLACE(RDT_TP_LCTG_CD,CHR(13),''),CHR(10),'') RDT_TP_LCTG_CD
, REPLACE(REPLACE(RDT_TP_MCTG_CD,CHR(13),''),CHR(10),'') RDT_TP_MCTG_CD
, REPLACE(REPLACE(RDT_PRPS_CD,CHR(13),''),CHR(10),'') RDT_PRPS_CD
, REPLACE(REPLACE(ADD_RCT_RSN_CON,CHR(13),''),CHR(10),'') ADD_RCT_RSN_CON
, REPLACE(REPLACE(UQN_CON,CHR(13),''),CHR(10),'') UQN_CON
, HIS_ST_DTM
, HIS_ED_DTM
, REPLACE(REPLACE(INPPE_ORG_ID,CHR(13),''),CHR(10),'') INPPE_ORG_ID
, SYS_OCC_DTM
, REPLACE(REPLACE(SYS_DEL_DIV_CD,CHR(13),''),CHR(10),'') SYS_DEL_DIV_CD
, REPLACE(REPLACE(OCC_IP,CHR(13),''),CHR(10),'') OCC_IP
, REPLACE(REPLACE(APP_ID,CHR(13),''),CHR(10),'') APP_ID
, DATA_CHNG_DTM
, EIH_LDG_DTM
, REPLACE(REPLACE(CNCLU_CNC_PEND_YN,CHR(13),''),CHR(10),'') CNCLU_CNC_PEND_YN
, REPLACE(REPLACE(LET_SND_YN,CHR(13),''),CHR(10),'') LET_SND_YN
, REPLACE(REPLACE(OPA_FRQ_CD,CHR(13),''),CHR(10),'') OPA_FRQ_CD
, REPLACE(REPLACE(DRV_ABLT_DIV_CD,CHR(13),''),CHR(10),'') DRV_ABLT_DIV_CD
, REPLACE(REPLACE(DRKN_FRQ_CD,CHR(13),''),CHR(10),'') DRKN_FRQ_CD
, REPLACE(REPLACE(SMK_QT_CD,CHR(13),''),CHR(10),'') SMK_QT_CD
, TT_OBST_RT
, REPLACE(REPLACE(OBST_RT_CMPT_STD_CD,CHR(13),''),CHR(10),'') OBST_RT_CMPT_STD_CD
, PRSM_DMG_AMT
, REPLACE(REPLACE(INTN_SCID_YN,CHR(13),''),CHR(10),'') INTN_SCID_YN
, REPLACE(REPLACE(SLACD_DMPE_YN,CHR(13),''),CHR(10),'') SLACD_DMPE_YN
, REPLACE(REPLACE(MADYMO_DIV_CD,CHR(13),''),CHR(10),'') MADYMO_DIV_CD
, OD_CLM_TT_OBST_RT
, OD_APL_TT_OBST_RT
, NW_CLM_TT_OBST_RT
, NW_APL_TT_OBST_RT
, NURS_DD_NUM
, MDI_EXP
, REPLACE(REPLACE(PY_EXEM_RSN_DTL_CD_LST,CHR(13),''),CHR(10),'') PY_EXEM_RSN_DTL_CD_LST
, REPLACE(REPLACE(PY_EXEM_POL_NO_LST,CHR(13),''),CHR(10),'') PY_EXEM_POL_NO_LST FROM THDDH_TCLDAMPE
                       WHERE \$CONDITIONS "\
    --m 8 \
    --boundary-query "SELECT 0, 7 FROM DUAL"\
    --split-by "ORA_HASH(DMPE_ID, 7)"\
    --target-dir /tmp2/LAST_THDDH_TCLDAMPE \
    --hive-import \
    --external-table-dir hdfs:///tmp2/temp_tbl/LAST_THDDH_TCLDAMPE \
    --hive-overwrite \
    --hive-table DEFAULT.LAST_THDDH_TCLDAMPE  >> ${SHLOG_DIR}/THDDH_TCLDAMPE.shlog 2>&1 &&

#----------------------------------------------------#
# Hadoop 원본테이블에 변경분 최종 적용
#----------------------------------------------------#
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TCLDAMPE_TMP ; " >> ${SHLOG_DIR}/THDDH_TCLDAMPE.shlog 2>&1 &&
    /usr/bin/hive -e "CREATE EXTERNAL TABLE MERITZ.THDDH_TCLDAMPE_TMP STORED AS PARQUET TBLPROPERTIES ('PARQUET.COMPRESS'='SNAPPY') AS
                                SELECT *
                                FROM DEFAULT.LAST_THDDH_TCLDAMPE ;" >> ${SHLOG_DIR}/THDDH_TCLDAMPE.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.LAST_THDDH_TCLDAMPE ;" >> ${SHLOG_DIR}/THDDH_TCLDAMPE.shlog 2>&1 &&
    /usr/bin/hdfs dfs -rm -r -f -skipTrash /tmp2/temp_tbl/LAST_THDDH_TCLDAMPE >> ${SHLOG_DIR}/THDDH_TCLDAMPE.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TCLDAMPE ;" >> ${SHLOG_DIR}/THDDH_TCLDAMPE.shlog 2>&1 &&
    /usr/bin/hive -e "ALTER TABLE MERITZ.THDDH_TCLDAMPE_TMP RENAME TO MERITZ.THDDH_TCLDAMPE ;" >> ${SHLOG_DIR}/THDDH_TCLDAMPE.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TCLDAMPE_TMP ;" >> ${SHLOG_DIR}/THDDH_TCLDAMPE.shlog 2>&1 

if [ $? -ne 0 ]
then             
    echo "*-----------[ THDDH_TCLDAMPE.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/THDDH_TCLDAMPE.shlog"
    echo "*-----------[ THDDH_TCLDAMPE.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/THDDH_TCLDAMPE.shlog"  >>  ${SHLOG_DIR}/THDDH_TCLDAMPE.shlog
    echo "*-----------[ THDDH_TCLDAMPE.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TCLDAMPE.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/THDDH_TCLDAMPE.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/THDDH_TCLDAMPE.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCLDAMPE.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCLDAMPE.shlog /sqoopbin/scripts/etlpgm/his_log/THDDH_TCLDAMPE_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  THDDH_TCLDAMPE.sh cmd command error !! ***
    fi               

    exit -1      

else             
    echo "*-----------[ THDDH_TCLDAMPE.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TCLDAMPE.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/THDDH_TCLDAMPE.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/THDDH_TCLDAMPE.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCLDAMPE.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCLDAMPE.shlog /sqoopbin/scripts/etlpgm/his_log/THDDH_TCLDAMPE_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  THDDH_TCLDAMPE.sh cmd command error !! ***
        exit -1      
    else             
        exit 0       
    fi               
fi               
