#!/bin/bash

if [ $# -eq 0 ]
then           
    ARGS=N    
else           
    ARGS=$1
fi             

NOW=$(date +"+%Y-%m-%d_%T")
SHLOG_DIR=/sqoopbin/scripts/etlpgm/cur_log
HISLOG_DIR=/sqoopbin/scripts/etlpgm/his_log

export HADOOP_OPTS=-Djava.security.egd=file:/dev/../dev/urandom
export ORACLE_BASE=/sw/oracle
export ORACLE_HOME=/sw/oracle/product/11.2.0.4/client_1
export LD_LIBRARY_PATH=/sw/oracle/product/11.2.0.4/client_1/lib:/sw/oracle/product/11.2.0.4/client_1/lib:
export PATH=/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/usr/lib64/qt-3.3/bin:/usr/hdp/3.0.0.0-1634/spark2/bin/:/var/opt/node/bin/:/opt/maven/bin:/usr/local/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/home/hdpapp/workspace/data-science-at-the-command-line/tools:/home/hdpapp/.local/bin:/home/hdpapp/bin
export TNS_ADMIN=/sw/oracle/product/11.2.0.4/client_1/network/admin
export ORACLE_SID=DBEDWP2
export NLS_LANG=American_America.KO16MSWIN949

#----------------------------------------------------#
# 작업내용 : THDDH_TCLACDREL 테이블 sqoop 복제 작업
# 작업주기 :  
#----------------------------------------------------#

    echo " "
    echo "*-----------[ THDDH_TCLACDREL.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TCLACDREL.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`  >  ${SHLOG_DIR}/THDDH_TCLACDREL.shlog

#----------------------------------------------------#
# 테이블별 전체 데이터를 받아 오는 부분
#----------------------------------------------------#
    /usr/bin/hadoop fs -rm -r -f  /tmp2/LAST_THDDH_TCLACDREL  >> ${SHLOG_DIR}/THDDH_TCLACDREL.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.LAST_THDDH_TCLACDREL ; " >> ${SHLOG_DIR}/THDDH_TCLACDREL.shlog 2>&1 &&
    /usr/hdp/3.0.0.0-1634/sqoop/bin/sqoop import -D mapred.child.java.opts="-Djava.security.egd=file:/dev/../dev/urandom" \
    --connect jdbc:oracle:thin:EDWHADOOP/wjdqhrP\!23@10.91.41.172:12560:DBEDWP2 \
    --username  EDWHADOOP \
    --password wjdqhrP\!23 \
    --query "SELECT /*+ FULL(THDDH_TCLACDREL) */ REPLACE(REPLACE(ACD_RELPE_ID,CHR(13),''),CHR(10),'') ACD_RELPE_ID
, HIS_SEQ
, REPLACE(REPLACE(COMS_BIZ_DIV_CD,CHR(13),''),CHR(10),'') COMS_BIZ_DIV_CD
, REPLACE(REPLACE(ACD_RCT_ID,CHR(13),''),CHR(10),'') ACD_RCT_ID
, REPLACE(REPLACE(ACD_RELPERL_CD,CHR(13),''),CHR(10),'') ACD_RELPERL_CD
, REPLACE(REPLACE(PTY_DIV_CD,CHR(13),''),CHR(10),'') PTY_DIV_CD
, REPLACE(REPLACE(PTY_ID,CHR(13),''),CHR(10),'') PTY_ID
, REPLACE(REPLACE(RELPE_NM,CHR(13),''),CHR(10),'') RELPE_NM
, REPLACE(REPLACE(CLM_ID,CHR(13),''),CHR(10),'') CLM_ID
, REPLACE(REPLACE(ACD_OBJ_DIV_CD,CHR(13),''),CHR(10),'') ACD_OBJ_DIV_CD
, REPLACE(REPLACE(ACD_OBJ_ID,CHR(13),''),CHR(10),'') ACD_OBJ_ID
, REPLACE(REPLACE(BZAC_ID,CHR(13),''),CHR(10),'') BZAC_ID
, REPLACE(REPLACE(DPCPE_REL_CD,CHR(13),''),CHR(10),'') DPCPE_REL_CD
, REPLACE(REPLACE(INSPE_REL_CD,CHR(13),''),CHR(10),'') INSPE_REL_CD
, REPLACE(REPLACE(POLHD_CPUAPE_REL_CD,CHR(13),''),CHR(10),'') POLHD_CPUAPE_REL_CD
, REPLACE(REPLACE(DMPE_CPUAPE_REL_CD,CHR(13),''),CHR(10),'') DMPE_CPUAPE_REL_CD
, AGE
, REPLACE(REPLACE(GNDR_CD,CHR(13),''),CHR(10),'') GNDR_CD
, REPLACE(REPLACE(DRVLNS_CLF_DIV_CD,CHR(13),''),CHR(10),'') DRVLNS_CLF_DIV_CD
, REPLACE(REPLACE(DRVLNS_SIDO_CD,CHR(13),''),CHR(10),'') DRVLNS_SIDO_CD
, REPLACE(REPLACE(DRVLNS_CNF_MD_CD,CHR(13),''),CHR(10),'') DRVLNS_CNF_MD_CD
, REPLACE(REPLACE(DRVLNS_CNF_YN,CHR(13),''),CHR(10),'') DRVLNS_CNF_YN
, DRVLNS_EFCT_ST_DT
, DRVLNS_EFCT_ED_DT
, REPLACE(REPLACE(CLADJ_QUAL_YN,CHR(13),''),CHR(10),'') CLADJ_QUAL_YN
, REPLACE(REPLACE(COSLAMT_PAY_YN,CHR(13),''),CHR(10),'') COSLAMT_PAY_YN
, REPLACE(REPLACE(TH3PE_ETP_ID,CHR(13),''),CHR(10),'') TH3PE_ETP_ID
, REPLACE(REPLACE(TH3PE_DIV_CD,CHR(13),''),CHR(10),'') TH3PE_DIV_CD
, REPLACE(REPLACE(TH3PE_BIZ_CODG_CD,CHR(13),''),CHR(10),'') TH3PE_BIZ_CODG_CD
, REPLACE(REPLACE(CVAP_DIV_CD,CHR(13),''),CHR(10),'') CVAP_DIV_CD
, REPLACE(REPLACE(TH3PE_SUERIS_DIV_CD,CHR(13),''),CHR(10),'') TH3PE_SUERIS_DIV_CD
, REPLACE(REPLACE(DLG_YN,CHR(13),''),CHR(10),'') DLG_YN
, REPLACE(REPLACE(LNK_ACD_RELPE_ID,CHR(13),''),CHR(10),'') LNK_ACD_RELPE_ID
, REPLACE(REPLACE(FSS_ACDSVY_YN,CHR(13),''),CHR(10),'') FSS_ACDSVY_YN
, REPLACE(REPLACE(FSS_INSPE_REL_CD,CHR(13),''),CHR(10),'') FSS_INSPE_REL_CD
, REPLACE(REPLACE(FSS_JOB_CD,CHR(13),''),CHR(10),'') FSS_JOB_CD
, REPLACE(REPLACE(COMS_JOB_CD,CHR(13),''),CHR(10),'') COMS_JOB_CD
, RECG_DT
, REPLACE(REPLACE(RELPE_CTP_CON,CHR(13),''),CHR(10),'') RELPE_CTP_CON
, REPLACE(REPLACE(UQN_CON,CHR(13),''),CHR(10),'') UQN_CON
, HIS_ST_DTM
, HIS_ED_DTM
, REPLACE(REPLACE(INPPE_ORG_ID,CHR(13),''),CHR(10),'') INPPE_ORG_ID
, SYS_OCC_DTM
, REPLACE(REPLACE(SYS_DEL_DIV_CD,CHR(13),''),CHR(10),'') SYS_DEL_DIV_CD
, REPLACE(REPLACE(OCC_IP,CHR(13),''),CHR(10),'') OCC_IP
, REPLACE(REPLACE(APP_ID,CHR(13),''),CHR(10),'') APP_ID
, DATA_CHNG_DTM
, EIH_LDG_DTM
, REPLACE(REPLACE(DRVLNS_SIDO_DIV_CD,CHR(13),''),CHR(10),'') DRVLNS_SIDO_DIV_CD
, REPLACE(REPLACE(CTR_PTY_RL_CD,CHR(13),''),CHR(10),'') CTR_PTY_RL_CD
, REPLACE(REPLACE(RPDC_SBM_YN,CHR(13),''),CHR(10),'') RPDC_SBM_YN FROM THDDH_TCLACDREL
                       WHERE \$CONDITIONS "\
    --m 8 \
    --boundary-query "SELECT 0, 7 FROM DUAL"\
    --split-by "ORA_HASH(ACD_RELPE_ID, 7)"\
    --target-dir /tmp2/LAST_THDDH_TCLACDREL \
    --hive-import \
    --external-table-dir hdfs:///tmp2/temp_tbl/LAST_THDDH_TCLACDREL \
    --hive-overwrite \
    --hive-table DEFAULT.LAST_THDDH_TCLACDREL  >> ${SHLOG_DIR}/THDDH_TCLACDREL.shlog 2>&1 &&

#----------------------------------------------------#
# Hadoop 원본테이블에 변경분 최종 적용
#----------------------------------------------------#
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TCLACDREL_TMP ; " >> ${SHLOG_DIR}/THDDH_TCLACDREL.shlog 2>&1 &&
    /usr/bin/hive -e "CREATE EXTERNAL TABLE MERITZ.THDDH_TCLACDREL_TMP STORED AS PARQUET TBLPROPERTIES ('PARQUET.COMPRESS'='SNAPPY') AS
                                SELECT *
                                FROM DEFAULT.LAST_THDDH_TCLACDREL ;" >> ${SHLOG_DIR}/THDDH_TCLACDREL.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.LAST_THDDH_TCLACDREL ;" >> ${SHLOG_DIR}/THDDH_TCLACDREL.shlog 2>&1 &&
    /usr/bin/hdfs dfs -rm -r -f -skipTrash /tmp2/temp_tbl/LAST_THDDH_TCLACDREL >> ${SHLOG_DIR}/THDDH_TCLACDREL.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TCLACDREL ;" >> ${SHLOG_DIR}/THDDH_TCLACDREL.shlog 2>&1 &&
    /usr/bin/hive -e "ALTER TABLE MERITZ.THDDH_TCLACDREL_TMP RENAME TO MERITZ.THDDH_TCLACDREL ;" >> ${SHLOG_DIR}/THDDH_TCLACDREL.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TCLACDREL_TMP ;" >> ${SHLOG_DIR}/THDDH_TCLACDREL.shlog 2>&1 

if [ $? -ne 0 ]
then             
    echo "*-----------[ THDDH_TCLACDREL.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/THDDH_TCLACDREL.shlog"
    echo "*-----------[ THDDH_TCLACDREL.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/THDDH_TCLACDREL.shlog"  >>  ${SHLOG_DIR}/THDDH_TCLACDREL.shlog
    echo "*-----------[ THDDH_TCLACDREL.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TCLACDREL.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/THDDH_TCLACDREL.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/THDDH_TCLACDREL.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCLACDREL.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCLACDREL.shlog /sqoopbin/scripts/etlpgm/his_log/THDDH_TCLACDREL_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  THDDH_TCLACDREL.sh cmd command error !! ***
    fi               

    exit -1      

else             
    echo "*-----------[ THDDH_TCLACDREL.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TCLACDREL.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/THDDH_TCLACDREL.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/THDDH_TCLACDREL.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCLACDREL.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCLACDREL.shlog /sqoopbin/scripts/etlpgm/his_log/THDDH_TCLACDREL_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  THDDH_TCLACDREL.sh cmd command error !! ***
        exit -1      
    else             
        exit 0       
    fi               
fi               
