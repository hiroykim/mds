// ORM class for table 'null'
// WARNING: This class is AUTO-GENERATED. Modify at your own risk.
//
// Debug information:
// Generated date: Fri Aug 06 05:44:34 GMT 2021
// For connector: org.apache.sqoop.manager.OracleManager
import org.apache.hadoop.io.BytesWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.mapred.lib.db.DBWritable;
import org.apache.sqoop.lib.JdbcWritableBridge;
import org.apache.sqoop.lib.DelimiterSet;
import org.apache.sqoop.lib.FieldFormatter;
import org.apache.sqoop.lib.RecordParser;
import org.apache.sqoop.lib.BooleanParser;
import org.apache.sqoop.lib.BlobRef;
import org.apache.sqoop.lib.ClobRef;
import org.apache.sqoop.lib.LargeObjectLoader;
import org.apache.sqoop.lib.SqoopRecord;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.sql.Date;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

public class QueryResult extends SqoopRecord  implements DBWritable, Writable {
  private final int PROTOCOL_VERSION = 3;
  public int getClassFormatVersion() { return PROTOCOL_VERSION; }
  public static interface FieldSetterCommand {    void setField(Object value);  }  protected ResultSet __cur_result_set;
  private Map<String, FieldSetterCommand> setters = new HashMap<String, FieldSetterCommand>();
  private void init0() {
    setters.put("ORG_ID", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.ORG_ID = (String)value;
      }
    });
    setters.put("CUS_ID", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.CUS_ID = (String)value;
      }
    });
    setters.put("FML_REL_CRT_DIV_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.FML_REL_CRT_DIV_CD = (String)value;
      }
    });
    setters.put("ORG_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.ORG_CD = (String)value;
      }
    });
    setters.put("ORG_CUS_ID", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.ORG_CUS_ID = (String)value;
      }
    });
    setters.put("ORG_FML_REL_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.ORG_FML_REL_CD = (String)value;
      }
    });
    setters.put("INPPE_ORG_ID", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.INPPE_ORG_ID = (String)value;
      }
    });
    setters.put("INPPE_ORG_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.INPPE_ORG_CD = (String)value;
      }
    });
    setters.put("EXCE_PCS_YN", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.EXCE_PCS_YN = (String)value;
      }
    });
    setters.put("EIH_LDG_DTM", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.EIH_LDG_DTM = (java.sql.Timestamp)value;
      }
    });
  }
  public QueryResult() {
    init0();
  }
  private String ORG_ID;
  public String get_ORG_ID() {
    return ORG_ID;
  }
  public void set_ORG_ID(String ORG_ID) {
    this.ORG_ID = ORG_ID;
  }
  public QueryResult with_ORG_ID(String ORG_ID) {
    this.ORG_ID = ORG_ID;
    return this;
  }
  private String CUS_ID;
  public String get_CUS_ID() {
    return CUS_ID;
  }
  public void set_CUS_ID(String CUS_ID) {
    this.CUS_ID = CUS_ID;
  }
  public QueryResult with_CUS_ID(String CUS_ID) {
    this.CUS_ID = CUS_ID;
    return this;
  }
  private String FML_REL_CRT_DIV_CD;
  public String get_FML_REL_CRT_DIV_CD() {
    return FML_REL_CRT_DIV_CD;
  }
  public void set_FML_REL_CRT_DIV_CD(String FML_REL_CRT_DIV_CD) {
    this.FML_REL_CRT_DIV_CD = FML_REL_CRT_DIV_CD;
  }
  public QueryResult with_FML_REL_CRT_DIV_CD(String FML_REL_CRT_DIV_CD) {
    this.FML_REL_CRT_DIV_CD = FML_REL_CRT_DIV_CD;
    return this;
  }
  private String ORG_CD;
  public String get_ORG_CD() {
    return ORG_CD;
  }
  public void set_ORG_CD(String ORG_CD) {
    this.ORG_CD = ORG_CD;
  }
  public QueryResult with_ORG_CD(String ORG_CD) {
    this.ORG_CD = ORG_CD;
    return this;
  }
  private String ORG_CUS_ID;
  public String get_ORG_CUS_ID() {
    return ORG_CUS_ID;
  }
  public void set_ORG_CUS_ID(String ORG_CUS_ID) {
    this.ORG_CUS_ID = ORG_CUS_ID;
  }
  public QueryResult with_ORG_CUS_ID(String ORG_CUS_ID) {
    this.ORG_CUS_ID = ORG_CUS_ID;
    return this;
  }
  private String ORG_FML_REL_CD;
  public String get_ORG_FML_REL_CD() {
    return ORG_FML_REL_CD;
  }
  public void set_ORG_FML_REL_CD(String ORG_FML_REL_CD) {
    this.ORG_FML_REL_CD = ORG_FML_REL_CD;
  }
  public QueryResult with_ORG_FML_REL_CD(String ORG_FML_REL_CD) {
    this.ORG_FML_REL_CD = ORG_FML_REL_CD;
    return this;
  }
  private String INPPE_ORG_ID;
  public String get_INPPE_ORG_ID() {
    return INPPE_ORG_ID;
  }
  public void set_INPPE_ORG_ID(String INPPE_ORG_ID) {
    this.INPPE_ORG_ID = INPPE_ORG_ID;
  }
  public QueryResult with_INPPE_ORG_ID(String INPPE_ORG_ID) {
    this.INPPE_ORG_ID = INPPE_ORG_ID;
    return this;
  }
  private String INPPE_ORG_CD;
  public String get_INPPE_ORG_CD() {
    return INPPE_ORG_CD;
  }
  public void set_INPPE_ORG_CD(String INPPE_ORG_CD) {
    this.INPPE_ORG_CD = INPPE_ORG_CD;
  }
  public QueryResult with_INPPE_ORG_CD(String INPPE_ORG_CD) {
    this.INPPE_ORG_CD = INPPE_ORG_CD;
    return this;
  }
  private String EXCE_PCS_YN;
  public String get_EXCE_PCS_YN() {
    return EXCE_PCS_YN;
  }
  public void set_EXCE_PCS_YN(String EXCE_PCS_YN) {
    this.EXCE_PCS_YN = EXCE_PCS_YN;
  }
  public QueryResult with_EXCE_PCS_YN(String EXCE_PCS_YN) {
    this.EXCE_PCS_YN = EXCE_PCS_YN;
    return this;
  }
  private java.sql.Timestamp EIH_LDG_DTM;
  public java.sql.Timestamp get_EIH_LDG_DTM() {
    return EIH_LDG_DTM;
  }
  public void set_EIH_LDG_DTM(java.sql.Timestamp EIH_LDG_DTM) {
    this.EIH_LDG_DTM = EIH_LDG_DTM;
  }
  public QueryResult with_EIH_LDG_DTM(java.sql.Timestamp EIH_LDG_DTM) {
    this.EIH_LDG_DTM = EIH_LDG_DTM;
    return this;
  }
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (!(o instanceof QueryResult)) {
      return false;
    }
    QueryResult that = (QueryResult) o;
    boolean equal = true;
    equal = equal && (this.ORG_ID == null ? that.ORG_ID == null : this.ORG_ID.equals(that.ORG_ID));
    equal = equal && (this.CUS_ID == null ? that.CUS_ID == null : this.CUS_ID.equals(that.CUS_ID));
    equal = equal && (this.FML_REL_CRT_DIV_CD == null ? that.FML_REL_CRT_DIV_CD == null : this.FML_REL_CRT_DIV_CD.equals(that.FML_REL_CRT_DIV_CD));
    equal = equal && (this.ORG_CD == null ? that.ORG_CD == null : this.ORG_CD.equals(that.ORG_CD));
    equal = equal && (this.ORG_CUS_ID == null ? that.ORG_CUS_ID == null : this.ORG_CUS_ID.equals(that.ORG_CUS_ID));
    equal = equal && (this.ORG_FML_REL_CD == null ? that.ORG_FML_REL_CD == null : this.ORG_FML_REL_CD.equals(that.ORG_FML_REL_CD));
    equal = equal && (this.INPPE_ORG_ID == null ? that.INPPE_ORG_ID == null : this.INPPE_ORG_ID.equals(that.INPPE_ORG_ID));
    equal = equal && (this.INPPE_ORG_CD == null ? that.INPPE_ORG_CD == null : this.INPPE_ORG_CD.equals(that.INPPE_ORG_CD));
    equal = equal && (this.EXCE_PCS_YN == null ? that.EXCE_PCS_YN == null : this.EXCE_PCS_YN.equals(that.EXCE_PCS_YN));
    equal = equal && (this.EIH_LDG_DTM == null ? that.EIH_LDG_DTM == null : this.EIH_LDG_DTM.equals(that.EIH_LDG_DTM));
    return equal;
  }
  public boolean equals0(Object o) {
    if (this == o) {
      return true;
    }
    if (!(o instanceof QueryResult)) {
      return false;
    }
    QueryResult that = (QueryResult) o;
    boolean equal = true;
    equal = equal && (this.ORG_ID == null ? that.ORG_ID == null : this.ORG_ID.equals(that.ORG_ID));
    equal = equal && (this.CUS_ID == null ? that.CUS_ID == null : this.CUS_ID.equals(that.CUS_ID));
    equal = equal && (this.FML_REL_CRT_DIV_CD == null ? that.FML_REL_CRT_DIV_CD == null : this.FML_REL_CRT_DIV_CD.equals(that.FML_REL_CRT_DIV_CD));
    equal = equal && (this.ORG_CD == null ? that.ORG_CD == null : this.ORG_CD.equals(that.ORG_CD));
    equal = equal && (this.ORG_CUS_ID == null ? that.ORG_CUS_ID == null : this.ORG_CUS_ID.equals(that.ORG_CUS_ID));
    equal = equal && (this.ORG_FML_REL_CD == null ? that.ORG_FML_REL_CD == null : this.ORG_FML_REL_CD.equals(that.ORG_FML_REL_CD));
    equal = equal && (this.INPPE_ORG_ID == null ? that.INPPE_ORG_ID == null : this.INPPE_ORG_ID.equals(that.INPPE_ORG_ID));
    equal = equal && (this.INPPE_ORG_CD == null ? that.INPPE_ORG_CD == null : this.INPPE_ORG_CD.equals(that.INPPE_ORG_CD));
    equal = equal && (this.EXCE_PCS_YN == null ? that.EXCE_PCS_YN == null : this.EXCE_PCS_YN.equals(that.EXCE_PCS_YN));
    equal = equal && (this.EIH_LDG_DTM == null ? that.EIH_LDG_DTM == null : this.EIH_LDG_DTM.equals(that.EIH_LDG_DTM));
    return equal;
  }
  public void readFields(ResultSet __dbResults) throws SQLException {
    this.__cur_result_set = __dbResults;
    this.ORG_ID = JdbcWritableBridge.readString(1, __dbResults);
    this.CUS_ID = JdbcWritableBridge.readString(2, __dbResults);
    this.FML_REL_CRT_DIV_CD = JdbcWritableBridge.readString(3, __dbResults);
    this.ORG_CD = JdbcWritableBridge.readString(4, __dbResults);
    this.ORG_CUS_ID = JdbcWritableBridge.readString(5, __dbResults);
    this.ORG_FML_REL_CD = JdbcWritableBridge.readString(6, __dbResults);
    this.INPPE_ORG_ID = JdbcWritableBridge.readString(7, __dbResults);
    this.INPPE_ORG_CD = JdbcWritableBridge.readString(8, __dbResults);
    this.EXCE_PCS_YN = JdbcWritableBridge.readString(9, __dbResults);
    this.EIH_LDG_DTM = JdbcWritableBridge.readTimestamp(10, __dbResults);
  }
  public void readFields0(ResultSet __dbResults) throws SQLException {
    this.ORG_ID = JdbcWritableBridge.readString(1, __dbResults);
    this.CUS_ID = JdbcWritableBridge.readString(2, __dbResults);
    this.FML_REL_CRT_DIV_CD = JdbcWritableBridge.readString(3, __dbResults);
    this.ORG_CD = JdbcWritableBridge.readString(4, __dbResults);
    this.ORG_CUS_ID = JdbcWritableBridge.readString(5, __dbResults);
    this.ORG_FML_REL_CD = JdbcWritableBridge.readString(6, __dbResults);
    this.INPPE_ORG_ID = JdbcWritableBridge.readString(7, __dbResults);
    this.INPPE_ORG_CD = JdbcWritableBridge.readString(8, __dbResults);
    this.EXCE_PCS_YN = JdbcWritableBridge.readString(9, __dbResults);
    this.EIH_LDG_DTM = JdbcWritableBridge.readTimestamp(10, __dbResults);
  }
  public void loadLargeObjects(LargeObjectLoader __loader)
      throws SQLException, IOException, InterruptedException {
  }
  public void loadLargeObjects0(LargeObjectLoader __loader)
      throws SQLException, IOException, InterruptedException {
  }
  public void write(PreparedStatement __dbStmt) throws SQLException {
    write(__dbStmt, 0);
  }

  public int write(PreparedStatement __dbStmt, int __off) throws SQLException {
    JdbcWritableBridge.writeString(ORG_ID, 1 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(CUS_ID, 2 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(FML_REL_CRT_DIV_CD, 3 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(ORG_CD, 4 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(ORG_CUS_ID, 5 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(ORG_FML_REL_CD, 6 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(INPPE_ORG_ID, 7 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(INPPE_ORG_CD, 8 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(EXCE_PCS_YN, 9 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeTimestamp(EIH_LDG_DTM, 10 + __off, 93, __dbStmt);
    return 10;
  }
  public void write0(PreparedStatement __dbStmt, int __off) throws SQLException {
    JdbcWritableBridge.writeString(ORG_ID, 1 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(CUS_ID, 2 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(FML_REL_CRT_DIV_CD, 3 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(ORG_CD, 4 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(ORG_CUS_ID, 5 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(ORG_FML_REL_CD, 6 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(INPPE_ORG_ID, 7 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(INPPE_ORG_CD, 8 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(EXCE_PCS_YN, 9 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeTimestamp(EIH_LDG_DTM, 10 + __off, 93, __dbStmt);
  }
  public void readFields(DataInput __dataIn) throws IOException {
this.readFields0(__dataIn);  }
  public void readFields0(DataInput __dataIn) throws IOException {
    if (__dataIn.readBoolean()) { 
        this.ORG_ID = null;
    } else {
    this.ORG_ID = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.CUS_ID = null;
    } else {
    this.CUS_ID = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.FML_REL_CRT_DIV_CD = null;
    } else {
    this.FML_REL_CRT_DIV_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.ORG_CD = null;
    } else {
    this.ORG_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.ORG_CUS_ID = null;
    } else {
    this.ORG_CUS_ID = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.ORG_FML_REL_CD = null;
    } else {
    this.ORG_FML_REL_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.INPPE_ORG_ID = null;
    } else {
    this.INPPE_ORG_ID = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.INPPE_ORG_CD = null;
    } else {
    this.INPPE_ORG_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.EXCE_PCS_YN = null;
    } else {
    this.EXCE_PCS_YN = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.EIH_LDG_DTM = null;
    } else {
    this.EIH_LDG_DTM = new Timestamp(__dataIn.readLong());
    this.EIH_LDG_DTM.setNanos(__dataIn.readInt());
    }
  }
  public void write(DataOutput __dataOut) throws IOException {
    if (null == this.ORG_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ORG_ID);
    }
    if (null == this.CUS_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CUS_ID);
    }
    if (null == this.FML_REL_CRT_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, FML_REL_CRT_DIV_CD);
    }
    if (null == this.ORG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ORG_CD);
    }
    if (null == this.ORG_CUS_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ORG_CUS_ID);
    }
    if (null == this.ORG_FML_REL_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ORG_FML_REL_CD);
    }
    if (null == this.INPPE_ORG_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, INPPE_ORG_ID);
    }
    if (null == this.INPPE_ORG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, INPPE_ORG_CD);
    }
    if (null == this.EXCE_PCS_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, EXCE_PCS_YN);
    }
    if (null == this.EIH_LDG_DTM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.EIH_LDG_DTM.getTime());
    __dataOut.writeInt(this.EIH_LDG_DTM.getNanos());
    }
  }
  public void write0(DataOutput __dataOut) throws IOException {
    if (null == this.ORG_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ORG_ID);
    }
    if (null == this.CUS_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CUS_ID);
    }
    if (null == this.FML_REL_CRT_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, FML_REL_CRT_DIV_CD);
    }
    if (null == this.ORG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ORG_CD);
    }
    if (null == this.ORG_CUS_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ORG_CUS_ID);
    }
    if (null == this.ORG_FML_REL_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ORG_FML_REL_CD);
    }
    if (null == this.INPPE_ORG_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, INPPE_ORG_ID);
    }
    if (null == this.INPPE_ORG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, INPPE_ORG_CD);
    }
    if (null == this.EXCE_PCS_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, EXCE_PCS_YN);
    }
    if (null == this.EIH_LDG_DTM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.EIH_LDG_DTM.getTime());
    __dataOut.writeInt(this.EIH_LDG_DTM.getNanos());
    }
  }
  private static final DelimiterSet __outputDelimiters = new DelimiterSet((char) 1, (char) 10, (char) 0, (char) 0, false);
  public String toString() {
    return toString(__outputDelimiters, true);
  }
  public String toString(DelimiterSet delimiters) {
    return toString(delimiters, true);
  }
  public String toString(boolean useRecordDelim) {
    return toString(__outputDelimiters, useRecordDelim);
  }
  public String toString(DelimiterSet delimiters, boolean useRecordDelim) {
    StringBuilder __sb = new StringBuilder();
    char fieldDelim = delimiters.getFieldsTerminatedBy();
    __sb.append(FieldFormatter.escapeAndEnclose(ORG_ID==null?"null":ORG_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CUS_ID==null?"null":CUS_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(FML_REL_CRT_DIV_CD==null?"null":FML_REL_CRT_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ORG_CD==null?"null":ORG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ORG_CUS_ID==null?"null":ORG_CUS_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ORG_FML_REL_CD==null?"null":ORG_FML_REL_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(INPPE_ORG_ID==null?"null":INPPE_ORG_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(INPPE_ORG_CD==null?"null":INPPE_ORG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(EXCE_PCS_YN==null?"null":EXCE_PCS_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(EIH_LDG_DTM==null?"null":"" + EIH_LDG_DTM, delimiters));
    if (useRecordDelim) {
      __sb.append(delimiters.getLinesTerminatedBy());
    }
    return __sb.toString();
  }
  public void toString0(DelimiterSet delimiters, StringBuilder __sb, char fieldDelim) {
    __sb.append(FieldFormatter.escapeAndEnclose(ORG_ID==null?"null":ORG_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CUS_ID==null?"null":CUS_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(FML_REL_CRT_DIV_CD==null?"null":FML_REL_CRT_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ORG_CD==null?"null":ORG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ORG_CUS_ID==null?"null":ORG_CUS_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ORG_FML_REL_CD==null?"null":ORG_FML_REL_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(INPPE_ORG_ID==null?"null":INPPE_ORG_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(INPPE_ORG_CD==null?"null":INPPE_ORG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(EXCE_PCS_YN==null?"null":EXCE_PCS_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(EIH_LDG_DTM==null?"null":"" + EIH_LDG_DTM, delimiters));
  }
  private static final DelimiterSet __inputDelimiters = new DelimiterSet((char) 1, (char) 10, (char) 0, (char) 0, false);
  private RecordParser __parser;
  public void parse(Text __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(CharSequence __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(byte [] __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(char [] __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(ByteBuffer __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(CharBuffer __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  private void __loadFromFields(List<String> fields) {
    Iterator<String> __it = fields.listIterator();
    String __cur_str = null;
    try {
    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.ORG_ID = null; } else {
      this.ORG_ID = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CUS_ID = null; } else {
      this.CUS_ID = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.FML_REL_CRT_DIV_CD = null; } else {
      this.FML_REL_CRT_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.ORG_CD = null; } else {
      this.ORG_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.ORG_CUS_ID = null; } else {
      this.ORG_CUS_ID = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.ORG_FML_REL_CD = null; } else {
      this.ORG_FML_REL_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.INPPE_ORG_ID = null; } else {
      this.INPPE_ORG_ID = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.INPPE_ORG_CD = null; } else {
      this.INPPE_ORG_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.EXCE_PCS_YN = null; } else {
      this.EXCE_PCS_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.EIH_LDG_DTM = null; } else {
      this.EIH_LDG_DTM = java.sql.Timestamp.valueOf(__cur_str);
    }

    } catch (RuntimeException e) {    throw new RuntimeException("Can't parse input data: '" + __cur_str + "'", e);    }  }

  private void __loadFromFields0(Iterator<String> __it) {
    String __cur_str = null;
    try {
    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.ORG_ID = null; } else {
      this.ORG_ID = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CUS_ID = null; } else {
      this.CUS_ID = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.FML_REL_CRT_DIV_CD = null; } else {
      this.FML_REL_CRT_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.ORG_CD = null; } else {
      this.ORG_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.ORG_CUS_ID = null; } else {
      this.ORG_CUS_ID = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.ORG_FML_REL_CD = null; } else {
      this.ORG_FML_REL_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.INPPE_ORG_ID = null; } else {
      this.INPPE_ORG_ID = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.INPPE_ORG_CD = null; } else {
      this.INPPE_ORG_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.EXCE_PCS_YN = null; } else {
      this.EXCE_PCS_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.EIH_LDG_DTM = null; } else {
      this.EIH_LDG_DTM = java.sql.Timestamp.valueOf(__cur_str);
    }

    } catch (RuntimeException e) {    throw new RuntimeException("Can't parse input data: '" + __cur_str + "'", e);    }  }

  public Object clone() throws CloneNotSupportedException {
    QueryResult o = (QueryResult) super.clone();
    o.EIH_LDG_DTM = (o.EIH_LDG_DTM != null) ? (java.sql.Timestamp) o.EIH_LDG_DTM.clone() : null;
    return o;
  }

  public void clone0(QueryResult o) throws CloneNotSupportedException {
    o.EIH_LDG_DTM = (o.EIH_LDG_DTM != null) ? (java.sql.Timestamp) o.EIH_LDG_DTM.clone() : null;
  }

  public Map<String, Object> getFieldMap() {
    Map<String, Object> __sqoop$field_map = new HashMap<String, Object>();
    __sqoop$field_map.put("ORG_ID", this.ORG_ID);
    __sqoop$field_map.put("CUS_ID", this.CUS_ID);
    __sqoop$field_map.put("FML_REL_CRT_DIV_CD", this.FML_REL_CRT_DIV_CD);
    __sqoop$field_map.put("ORG_CD", this.ORG_CD);
    __sqoop$field_map.put("ORG_CUS_ID", this.ORG_CUS_ID);
    __sqoop$field_map.put("ORG_FML_REL_CD", this.ORG_FML_REL_CD);
    __sqoop$field_map.put("INPPE_ORG_ID", this.INPPE_ORG_ID);
    __sqoop$field_map.put("INPPE_ORG_CD", this.INPPE_ORG_CD);
    __sqoop$field_map.put("EXCE_PCS_YN", this.EXCE_PCS_YN);
    __sqoop$field_map.put("EIH_LDG_DTM", this.EIH_LDG_DTM);
    return __sqoop$field_map;
  }

  public void getFieldMap0(Map<String, Object> __sqoop$field_map) {
    __sqoop$field_map.put("ORG_ID", this.ORG_ID);
    __sqoop$field_map.put("CUS_ID", this.CUS_ID);
    __sqoop$field_map.put("FML_REL_CRT_DIV_CD", this.FML_REL_CRT_DIV_CD);
    __sqoop$field_map.put("ORG_CD", this.ORG_CD);
    __sqoop$field_map.put("ORG_CUS_ID", this.ORG_CUS_ID);
    __sqoop$field_map.put("ORG_FML_REL_CD", this.ORG_FML_REL_CD);
    __sqoop$field_map.put("INPPE_ORG_ID", this.INPPE_ORG_ID);
    __sqoop$field_map.put("INPPE_ORG_CD", this.INPPE_ORG_CD);
    __sqoop$field_map.put("EXCE_PCS_YN", this.EXCE_PCS_YN);
    __sqoop$field_map.put("EIH_LDG_DTM", this.EIH_LDG_DTM);
  }

  public void setField(String __fieldName, Object __fieldVal) {
    if (!setters.containsKey(__fieldName)) {
      throw new RuntimeException("No such field:"+__fieldName);
    }
    setters.get(__fieldName).setField(__fieldVal);
  }

}
