#!/bin/bash

if [ $# -eq 0 ]
then           
    ARGS=N    
else           
    ARGS=$1
fi             

NOW=$(date +"+%Y-%m-%d_%T")
SHLOG_DIR=/sqoopbin/scripts/etlpgm/cur_log
HISLOG_DIR=/sqoopbin/scripts/etlpgm/his_log

export HADOOP_OPTS=-Djava.security.egd=file:/dev/../dev/urandom
export ORACLE_BASE=/sw/oracle
export ORACLE_HOME=/sw/oracle/product/11.2.0.4/client_1
export LD_LIBRARY_PATH=/sw/oracle/product/11.2.0.4/client_1/lib:/sw/oracle/product/11.2.0.4/client_1/lib:
export PATH=/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/usr/lib64/qt-3.3/bin:/usr/hdp/3.0.0.0-1634/spark2/bin/:/var/opt/node/bin/:/opt/maven/bin:/usr/local/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/home/hdpapp/workspace/data-science-at-the-command-line/tools:/home/hdpapp/.local/bin:/home/hdpapp/bin
export TNS_ADMIN=/sw/oracle/product/11.2.0.4/client_1/network/admin
export ORACLE_SID=DBEDWP2
export NLS_LANG=American_America.KO16MSWIN949

#----------------------------------------------------#
# 작업내용 : THDDH_TCOJOB 테이블 sqoop 복제 작업
# 작업주기 :  
#----------------------------------------------------#

    echo " "
    echo "*-----------[ THDDH_TCOJOB.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TCOJOB.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`  >  ${SHLOG_DIR}/THDDH_TCOJOB.shlog

#----------------------------------------------------#
# 테이블별 전체 데이터를 받아 오는 부분
#----------------------------------------------------#
    /usr/bin/hadoop fs -rm -r -f  /tmp2/LAST_THDDH_TCOJOB  >> ${SHLOG_DIR}/THDDH_TCOJOB.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.LAST_THDDH_TCOJOB ; " >> ${SHLOG_DIR}/THDDH_TCOJOB.shlog 2>&1 &&
    /usr/hdp/3.0.0.0-1634/sqoop/bin/sqoop import -D mapred.child.java.opts="-Djava.security.egd=file:/dev/../dev/urandom" \
    --connect jdbc:oracle:thin:EDWHADOOP/wjdqhrP\!23@10.91.41.172:12560:DBEDWP2 \
    --username  EDWHADOOP \
    --password wjdqhrP\!23 \
    --query "SELECT /*+ FULL(THDDH_TCOJOB) */ REPLACE(REPLACE(JOB_CD,CHR(13),''),CHR(10),'') JOB_CD
, HIS_SEQ
, REPLACE(REPLACE(JOB_NM,CHR(13),''),CHR(10),'') JOB_NM
, REPLACE(REPLACE(JOB_ABR_NM,CHR(13),''),CHR(10),'') JOB_ABR_NM
, REPLACE(REPLACE(JOB_LCTG_CD,CHR(13),''),CHR(10),'') JOB_LCTG_CD
, REPLACE(REPLACE(JOB_MCTG_CD,CHR(13),''),CHR(10),'') JOB_MCTG_CD
, REPLACE(REPLACE(JOB_SCTG_CD,CHR(13),''),CHR(10),'') JOB_SCTG_CD
, REPLACE(REPLACE(JOB_GRD_CD,CHR(13),''),CHR(10),'') JOB_GRD_CD
, REPLACE(REPLACE(KIDI_JOB_CD,CHR(13),''),CHR(10),'') KIDI_JOB_CD
, REPLACE(REPLACE(OD_JOB_CD,CHR(13),''),CHR(10),'') OD_JOB_CD
, REPLACE(REPLACE(GNR_JOB_YN,CHR(13),''),CHR(10),'') GNR_JOB_YN
, REPLACE(REPLACE(LGTM_JOB_YN,CHR(13),''),CHR(10),'') LGTM_JOB_YN
, REPLACE(REPLACE(CAR_JOB_YN,CHR(13),''),CHR(10),'') CAR_JOB_YN
, REPLACE(REPLACE(JOB_CON,CHR(13),''),CHR(10),'') JOB_CON
, REPLACE(REPLACE(RSMB_JOB_CON,CHR(13),''),CHR(10),'') RSMB_JOB_CON
, HIS_ST_DT
, HIS_ED_DT
, REPLACE(REPLACE(SYS_DEL_DIV_CD,CHR(13),''),CHR(10),'') SYS_DEL_DIV_CD
, REPLACE(REPLACE(INPPE_ORG_ID,CHR(13),''),CHR(10),'') INPPE_ORG_ID
, SYS_OCC_DTM
, REPLACE(REPLACE(OCC_IP,CHR(13),''),CHR(10),'') OCC_IP
, REPLACE(REPLACE(APP_ID,CHR(13),''),CHR(10),'') APP_ID
, DATA_CHNG_DTM
, REPLACE(REPLACE(AML_JOB_GRDE_CD,CHR(13),''),CHR(10),'') AML_JOB_GRDE_CD
, EIH_LDG_DTM
, REPLACE(REPLACE(NW_JOB_CD,CHR(13),''),CHR(10),'') NW_JOB_CD
, NW_JOB_CD_CRT_DT
, REPLACE(REPLACE(NW_JOB_LCTG_CD,CHR(13),''),CHR(10),'') NW_JOB_LCTG_CD
, REPLACE(REPLACE(NW_JOB_MCTG_CD,CHR(13),''),CHR(10),'') NW_JOB_MCTG_CD
, REPLACE(REPLACE(NW_JOB_SCTG_CD,CHR(13),''),CHR(10),'') NW_JOB_SCTG_CD
, REPLACE(REPLACE(NW_JOB_NM,CHR(13),''),CHR(10),'') NW_JOB_NM
, REPLACE(REPLACE(NW_JOB_ABR_NM,CHR(13),''),CHR(10),'') NW_JOB_ABR_NM
, REPLACE(REPLACE(JOBGP_GRDE_CD,CHR(13),''),CHR(10),'') JOBGP_GRDE_CD
, REPLACE(REPLACE(RSMB_SRCH_CON,CHR(13),''),CHR(10),'') RSMB_SRCH_CON
, RNK
, REPLACE(REPLACE(GNR_INS_JOB_NM,CHR(13),''),CHR(10),'') GNR_INS_JOB_NM
, REPLACE(REPLACE(GNR_INS_JOB_ABR_NM,CHR(13),''),CHR(10),'') GNR_INS_JOB_ABR_NM
, REPLACE(REPLACE(GNR_INS_JOB_GRD_CD,CHR(13),''),CHR(10),'') GNR_INS_JOB_GRD_CD
, REPLACE(REPLACE(GNR_INS_JOB_CON,CHR(13),''),CHR(10),'') GNR_INS_JOB_CON
, REPLACE(REPLACE(GNR_INS_RSMB_JOB_CON,CHR(13),''),CHR(10),'') GNR_INS_RSMB_JOB_CON
, REPLACE(REPLACE(GNR_INS_JOBGP_GRDE_CD,CHR(13),''),CHR(10),'') GNR_INS_JOBGP_GRDE_CD FROM THDDH_TCOJOB
                       WHERE \$CONDITIONS "\
    --m 1 \
    --target-dir /tmp2/LAST_THDDH_TCOJOB \
    --hive-import \
    --external-table-dir hdfs:///tmp2/temp_tbl/LAST_THDDH_TCOJOB \
    --hive-overwrite \
    --hive-table DEFAULT.LAST_THDDH_TCOJOB  >> ${SHLOG_DIR}/THDDH_TCOJOB.shlog 2>&1 &&

#----------------------------------------------------#
# Hadoop 원본테이블에 변경분 최종 적용
#----------------------------------------------------#
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TCOJOB_TMP ; " >> ${SHLOG_DIR}/THDDH_TCOJOB.shlog 2>&1 &&
    /usr/bin/hive -e "CREATE EXTERNAL TABLE MERITZ.THDDH_TCOJOB_TMP STORED AS PARQUET TBLPROPERTIES ('PARQUET.COMPRESS'='SNAPPY') AS
                                SELECT *
                                FROM DEFAULT.LAST_THDDH_TCOJOB ;" >> ${SHLOG_DIR}/THDDH_TCOJOB.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.LAST_THDDH_TCOJOB ;" >> ${SHLOG_DIR}/THDDH_TCOJOB.shlog 2>&1 &&
    /usr/bin/hdfs dfs -rm -r -f -skipTrash /tmp2/temp_tbl/LAST_THDDH_TCOJOB >> ${SHLOG_DIR}/THDDH_TCOJOB.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TCOJOB ;" >> ${SHLOG_DIR}/THDDH_TCOJOB.shlog 2>&1 &&
    /usr/bin/hive -e "ALTER TABLE MERITZ.THDDH_TCOJOB_TMP RENAME TO MERITZ.THDDH_TCOJOB ;" >> ${SHLOG_DIR}/THDDH_TCOJOB.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TCOJOB_TMP ;" >> ${SHLOG_DIR}/THDDH_TCOJOB.shlog 2>&1 

if [ $? -ne 0 ]
then             
    echo "*-----------[ THDDH_TCOJOB.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/THDDH_TCOJOB.shlog"
    echo "*-----------[ THDDH_TCOJOB.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/THDDH_TCOJOB.shlog"  >>  ${SHLOG_DIR}/THDDH_TCOJOB.shlog
    echo "*-----------[ THDDH_TCOJOB.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TCOJOB.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/THDDH_TCOJOB.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/THDDH_TCOJOB.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCOJOB.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCOJOB.shlog /sqoopbin/scripts/etlpgm/his_log/THDDH_TCOJOB_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  THDDH_TCOJOB.sh cmd command error !! ***
    fi               

    exit -1      

else             
    echo "*-----------[ THDDH_TCOJOB.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TCOJOB.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/THDDH_TCOJOB.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/THDDH_TCOJOB.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCOJOB.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCOJOB.shlog /sqoopbin/scripts/etlpgm/his_log/THDDH_TCOJOB_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  THDDH_TCOJOB.sh cmd command error !! ***
        exit -1      
    else             
        exit 0       
    fi               
fi               
