#!/bin/bash

if [ $# -eq 0 ]
then           
    ARGS=N    
else           
    ARGS=$1
fi             

NOW=$(date +"+%Y-%m-%d_%T")
SHLOG_DIR=/sqoopbin/scripts/etlpgm/cur_log
HISLOG_DIR=/sqoopbin/scripts/etlpgm/his_log

export HADOOP_OPTS=-Djava.security.egd=file:/dev/../dev/urandom
export ORACLE_BASE=/sw/oracle
export ORACLE_HOME=/sw/oracle/product/11.2.0.4/client_1
export LD_LIBRARY_PATH=/sw/oracle/product/11.2.0.4/client_1/lib:/sw/oracle/product/11.2.0.4/client_1/lib:
export PATH=/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/usr/lib64/qt-3.3/bin:/usr/hdp/3.0.0.0-1634/spark2/bin/:/var/opt/node/bin/:/opt/maven/bin:/usr/local/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/home/hdpapp/workspace/data-science-at-the-command-line/tools:/home/hdpapp/.local/bin:/home/hdpapp/bin
export TNS_ADMIN=/sw/oracle/product/11.2.0.4/client_1/network/admin
export ORACLE_SID=DBEDWP2
export NLS_LANG=American_America.KO16MSWIN949

#----------------------------------------------------#
# 작업내용 : THDDH_TSASLZORG 테이블 sqoop 복제 작업
# 작업주기 :  
#----------------------------------------------------#

    echo " "
    echo "*-----------[ THDDH_TSASLZORG.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TSASLZORG.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`  >  ${SHLOG_DIR}/THDDH_TSASLZORG.shlog

#----------------------------------------------------#
# 테이블별 전체 데이터를 받아 오는 부분
#----------------------------------------------------#
    /usr/bin/hadoop fs -rm -r -f  /tmp2/LAST_THDDH_TSASLZORG  >> ${SHLOG_DIR}/THDDH_TSASLZORG.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.LAST_THDDH_TSASLZORG ; " >> ${SHLOG_DIR}/THDDH_TSASLZORG.shlog 2>&1 &&
    /usr/hdp/3.0.0.0-1634/sqoop/bin/sqoop import -D mapred.child.java.opts="-Djava.security.egd=file:/dev/../dev/urandom" \
    --connect jdbc:oracle:thin:EDWHADOOP/wjdqhrP\!23@10.91.41.172:12560:DBEDWP2 \
    --username  EDWHADOOP \
    --password wjdqhrP\!23 \
    --query "SELECT /*+ FULL(THDDH_TSASLZORG) */ REPLACE(REPLACE(ORG_ID,CHR(13),''),CHR(10),'') ORG_ID
, HIS_SEQ
, REPLACE(REPLACE(SLZ_ORG_DIV_CD,CHR(13),''),CHR(10),'') SLZ_ORG_DIV_CD
, REPLACE(REPLACE(INS_CRR_CD,CHR(13),''),CHR(10),'') INS_CRR_CD
, REPLACE(REPLACE(INTRD_PTH_CD,CHR(13),''),CHR(10),'') INTRD_PTH_CD
, REPLACE(REPLACE(INTRD_TP_CD,CHR(13),''),CHR(10),'') INTRD_TP_CD
, REPLACE(REPLACE(ORG_STGE_CD,CHR(13),''),CHR(10),'') ORG_STGE_CD
, REPLACE(REPLACE(SLZ_SH_DIV_CD,CHR(13),''),CHR(10),'') SLZ_SH_DIV_CD
, REPLACE(REPLACE(DMG_INS_REG_NO,CHR(13),''),CHR(10),'') DMG_INS_REG_NO
, DMG_INS_REG_DT
, DMG_INS_ERAS_DT
, REPLACE(REPLACE(TH3IN_REG_NO,CHR(13),''),CHR(10),'') TH3IN_REG_NO
, TH3IN_REG_DT
, TH3IN_ERAS_DT
, REPLACE(REPLACE(RRN_BDT,CHR(13),''),CHR(10),'') RRN_BDT
, REPLACE(REPLACE(GNDR_CD,CHR(13),''),CHR(10),'') GNDR_CD
, REPLACE(REPLACE(SCPOS_CONV_CD,CHR(13),''),CHR(10),'') SCPOS_CONV_CD
, REPLACE(REPLACE(SPC_ENTT_EVL_YN,CHR(13),''),CHR(10),'') SPC_ENTT_EVL_YN
, REPLACE(REPLACE(BF_PST_PTNCO_CD,CHR(13),''),CHR(10),'') BF_PST_PTNCO_CD
, REPLACE(REPLACE(LET_TRNS_YN,CHR(13),''),CHR(10),'') LET_TRNS_YN
, REPLACE(REPLACE(ENTT_PSB_YN,CHR(13),''),CHR(10),'') ENTT_PSB_YN
, REPLACE(REPLACE(ENTT_EVL_ORG_ID,CHR(13),''),CHR(10),'') ENTT_EVL_ORG_ID
, CULT_ORG_INP_DT
, HIS_ST_DT
, HIS_ED_DT
, REPLACE(REPLACE(INPPE_ORG_ID,CHR(13),''),CHR(10),'') INPPE_ORG_ID
, SYS_OCC_DTM
, REPLACE(REPLACE(SYS_DEL_DIV_CD,CHR(13),''),CHR(10),'') SYS_DEL_DIV_CD
, REPLACE(REPLACE(APP_ID,CHR(13),''),CHR(10),'') APP_ID
, REPLACE(REPLACE(OCC_IP,CHR(13),''),CHR(10),'') OCC_IP
, DATA_CHNG_DTM
, REPLACE(REPLACE(FRD_TMN_RSN_CD,CHR(13),''),CHR(10),'') FRD_TMN_RSN_CD
, REPLACE(REPLACE(DM_RCEPL_CD,CHR(13),''),CHR(10),'') DM_RCEPL_CD
, REPLACE(REPLACE(HG_EFCY_ORG_DIV_CD,CHR(13),''),CHR(10),'') HG_EFCY_ORG_DIV_CD
, EIH_LDG_DTM
, REPLACE(REPLACE(RE_REG_APV_YN,CHR(13),''),CHR(10),'') RE_REG_APV_YN
, REPLACE(REPLACE(RE_REG_RSN_CD,CHR(13),''),CHR(10),'') RE_REG_RSN_CD
, REPLACE(REPLACE(MNGR_EVL_GRDE_DIV_CD,CHR(13),''),CHR(10),'') MNGR_EVL_GRDE_DIV_CD
, REPLACE(REPLACE(SMPH_USE_YN,CHR(13),''),CHR(10),'') SMPH_USE_YN
, REPLACE(REPLACE(OPMT_WKPL_CTP_APL_YN,CHR(13),''),CHR(10),'') OPMT_WKPL_CTP_APL_YN
, REPLACE(REPLACE(RCRT_EGMPE_INHR_NO,CHR(13),''),CHR(10),'') RCRT_EGMPE_INHR_NO
, REPLACE(REPLACE(CRR_STGE_CD,CHR(13),''),CHR(10),'') CRR_STGE_CD FROM THDDH_TSASLZORG
                       WHERE \$CONDITIONS "\
    --m 1 \
    --target-dir /tmp2/LAST_THDDH_TSASLZORG \
    --hive-import \
    --external-table-dir hdfs:///tmp2/temp_tbl/LAST_THDDH_TSASLZORG \
    --hive-overwrite \
    --hive-table DEFAULT.LAST_THDDH_TSASLZORG  >> ${SHLOG_DIR}/THDDH_TSASLZORG.shlog 2>&1 &&

#----------------------------------------------------#
# Hadoop 원본테이블에 변경분 최종 적용
#----------------------------------------------------#
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TSASLZORG_TMP ; " >> ${SHLOG_DIR}/THDDH_TSASLZORG.shlog 2>&1 &&
    /usr/bin/hive -e "CREATE EXTERNAL TABLE MERITZ.THDDH_TSASLZORG_TMP STORED AS PARQUET TBLPROPERTIES ('PARQUET.COMPRESS'='SNAPPY') AS
                                SELECT *
                                FROM DEFAULT.LAST_THDDH_TSASLZORG ;" >> ${SHLOG_DIR}/THDDH_TSASLZORG.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.LAST_THDDH_TSASLZORG ;" >> ${SHLOG_DIR}/THDDH_TSASLZORG.shlog 2>&1 &&
    /usr/bin/hdfs dfs -rm -r -f -skipTrash /tmp2/temp_tbl/LAST_THDDH_TSASLZORG >> ${SHLOG_DIR}/THDDH_TSASLZORG.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TSASLZORG ;" >> ${SHLOG_DIR}/THDDH_TSASLZORG.shlog 2>&1 &&
    /usr/bin/hive -e "ALTER TABLE MERITZ.THDDH_TSASLZORG_TMP RENAME TO MERITZ.THDDH_TSASLZORG ;" >> ${SHLOG_DIR}/THDDH_TSASLZORG.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TSASLZORG_TMP ;" >> ${SHLOG_DIR}/THDDH_TSASLZORG.shlog 2>&1 

if [ $? -ne 0 ]
then             
    echo "*-----------[ THDDH_TSASLZORG.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/THDDH_TSASLZORG.shlog"
    echo "*-----------[ THDDH_TSASLZORG.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/THDDH_TSASLZORG.shlog"  >>  ${SHLOG_DIR}/THDDH_TSASLZORG.shlog
    echo "*-----------[ THDDH_TSASLZORG.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TSASLZORG.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/THDDH_TSASLZORG.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/THDDH_TSASLZORG.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TSASLZORG.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TSASLZORG.shlog /sqoopbin/scripts/etlpgm/his_log/THDDH_TSASLZORG_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  THDDH_TSASLZORG.sh cmd command error !! ***
    fi               

    exit -1      

else             
    echo "*-----------[ THDDH_TSASLZORG.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TSASLZORG.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/THDDH_TSASLZORG.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/THDDH_TSASLZORG.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TSASLZORG.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TSASLZORG.shlog /sqoopbin/scripts/etlpgm/his_log/THDDH_TSASLZORG_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  THDDH_TSASLZORG.sh cmd command error !! ***
        exit -1      
    else             
        exit 0       
    fi               
fi               
