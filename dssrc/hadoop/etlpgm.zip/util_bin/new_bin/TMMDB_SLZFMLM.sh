#!/bin/bash

if [ $# -eq 0 ]
then           
    ARGS=N    
else           
    ARGS=$1
fi             

NOW=$(date +"+%Y-%m-%d_%T")
SHLOG_DIR=/sqoopbin/scripts/etlpgm/cur_log
HISLOG_DIR=/sqoopbin/scripts/etlpgm/his_log

export HADOOP_OPTS=-Djava.security.egd=file:/dev/../dev/urandom
export ORACLE_BASE=/sw/oracle
export ORACLE_HOME=/sw/oracle/product/11.2.0.4/client_1
export LD_LIBRARY_PATH=/sw/oracle/product/11.2.0.4/client_1/lib:/sw/oracle/product/11.2.0.4/client_1/lib:
export PATH=/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/usr/lib64/qt-3.3/bin:/usr/hdp/3.0.0.0-1634/spark2/bin/:/var/opt/node/bin/:/opt/maven/bin:/usr/local/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/home/hdpapp/workspace/data-science-at-the-command-line/tools:/home/hdpapp/.local/bin:/home/hdpapp/bin
export TNS_ADMIN=/sw/oracle/product/11.2.0.4/client_1/network/admin
export ORACLE_SID=DBEDWP2
export NLS_LANG=American_America.KO16MSWIN949

#----------------------------------------------------#
# 작업내용 : TMMDB_SLZFMLM 테이블 sqoop 복제 작업
# 작업주기 :  
#----------------------------------------------------#

    echo " "
    echo "*-----------[ TMMDB_SLZFMLM.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ TMMDB_SLZFMLM.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`  >  ${SHLOG_DIR}/TMMDB_SLZFMLM.shlog

#----------------------------------------------------#
# 테이블별 전체 데이터를 받아 오는 부분
#----------------------------------------------------#
    /usr/bin/hadoop fs -rm -r -f  /tmp2/LAST_TMMDB_SLZFMLM  >> ${SHLOG_DIR}/TMMDB_SLZFMLM.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.LAST_TMMDB_SLZFMLM ; " >> ${SHLOG_DIR}/TMMDB_SLZFMLM.shlog 2>&1 &&
    /usr/hdp/3.0.0.0-1634/sqoop/bin/sqoop import -D mapred.child.java.opts="-Djava.security.egd=file:/dev/../dev/urandom" \
    --connect jdbc:oracle:thin:EDWHADOOP/wjdqhrP\!23@10.91.41.172:12560:DBEDWP2 \
    --username  EDWHADOOP \
    --password wjdqhrP\!23 \
    --query "SELECT /*+ FULL(TMMDB_SLZFMLM) */ REPLACE(REPLACE(CLOG_YYMM,CHR(13),''),CHR(10),'') CLOG_YYMM
, REPLACE(REPLACE(ORG_CD,CHR(13),''),CHR(10),'') ORG_CD
, REPLACE(REPLACE(ORG_NM,CHR(13),''),CHR(10),'') ORG_NM
, REPLACE(REPLACE(ORG_TP_CD,CHR(13),''),CHR(10),'') ORG_TP_CD
, REPLACE(REPLACE(ORG_DIV_CD,CHR(13),''),CHR(10),'') ORG_DIV_CD
, REPLACE(REPLACE(ORG_STAT_CD,CHR(13),''),CHR(10),'') ORG_STAT_CD
, OPE_DT
, CLSU_DT
, REPLACE(REPLACE(OFRP_CD,CHR(13),''),CHR(10),'') OFRP_CD
, REPLACE(REPLACE(OFPOS_CD,CHR(13),''),CHR(10),'') OFPOS_CD
, REPLACE(REPLACE(PSA_ORG_DUTY_CD,CHR(13),''),CHR(10),'') PSA_ORG_DUTY_CD
, REPLACE(REPLACE(CHN_DIV_CD,CHR(13),''),CHR(10),'') CHN_DIV_CD
, REPLACE(REPLACE(SMRZ_ORG_CD,CHR(13),''),CHR(10),'') SMRZ_ORG_CD
, REPLACE(REPLACE(SMRZ_ORG_NM,CHR(13),''),CHR(10),'') SMRZ_ORG_NM
, REPLACE(REPLACE(BZ_SB_ORG_CD,CHR(13),''),CHR(10),'') BZ_SB_ORG_CD
, REPLACE(REPLACE(BZ_SB_ORG_NM,CHR(13),''),CHR(10),'') BZ_SB_ORG_NM
, REPLACE(REPLACE(HDQT_ORG_CD,CHR(13),''),CHR(10),'') HDQT_ORG_CD
, REPLACE(REPLACE(HDQT_ORG_NM,CHR(13),''),CHR(10),'') HDQT_ORG_NM
, REPLACE(REPLACE(BRCH_ORG_CD,CHR(13),''),CHR(10),'') BRCH_ORG_CD
, REPLACE(REPLACE(BRCH_ORG_NM,CHR(13),''),CHR(10),'') BRCH_ORG_NM
, REPLACE(REPLACE(BCH_ORG_CD,CHR(13),''),CHR(10),'') BCH_ORG_CD
, REPLACE(REPLACE(BCH_ORG_NM,CHR(13),''),CHR(10),'') BCH_ORG_NM
, REPLACE(REPLACE(BCH_DRBG_TEM_ORG_CD,CHR(13),''),CHR(10),'') BCH_DRBG_TEM_ORG_CD
, REPLACE(REPLACE(BCH_DRBG_TEM_NM,CHR(13),''),CHR(10),'') BCH_DRBG_TEM_NM
, REPLACE(REPLACE(UPB_CEN_ORG_CD,CHR(13),''),CHR(10),'') UPB_CEN_ORG_CD
, REPLACE(REPLACE(UPB_CEN_ORG_NM,CHR(13),''),CHR(10),'') UPB_CEN_ORG_NM
, REPLACE(REPLACE(INS_CRR_CD,CHR(13),''),CHR(10),'') INS_CRR_CD
, REPLACE(REPLACE(INTRD_PTH_CD,CHR(13),''),CHR(10),'') INTRD_PTH_CD
, REPLACE(REPLACE(INTRD_TP_CD,CHR(13),''),CHR(10),'') INTRD_TP_CD
, REPLACE(REPLACE(ORG_STGE_CD,CHR(13),''),CHR(10),'') ORG_STGE_CD
, REPLACE(REPLACE(SLZ_SH_DIV_CD,CHR(13),''),CHR(10),'') SLZ_SH_DIV_CD
, REPLACE(REPLACE(DMG_INS_REG_NO,CHR(13),''),CHR(10),'') DMG_INS_REG_NO
, DMG_INS_REG_DT
, DMG_INS_ERAS_DT
, REPLACE(REPLACE(TH3IN_REG_NO,CHR(13),''),CHR(10),'') TH3IN_REG_NO
, TH3IN_REG_DT
, TH3IN_ERAS_DT
, REPLACE(REPLACE(RRN_BDT,CHR(13),''),CHR(10),'') RRN_BDT
, REPLACE(REPLACE(GNDR_CD,CHR(13),''),CHR(10),'') GNDR_CD
, REPLACE(REPLACE(SCPOS_CONV_CD,CHR(13),''),CHR(10),'') SCPOS_CONV_CD
, REPLACE(REPLACE(BF_PST_PTNCO_CD,CHR(13),''),CHR(10),'') BF_PST_PTNCO_CD
, REPLACE(REPLACE(LET_TRNS_YN,CHR(13),''),CHR(10),'') LET_TRNS_YN
, REPLACE(REPLACE(FRD_TMN_RSN_CD,CHR(13),''),CHR(10),'') FRD_TMN_RSN_CD
, REPLACE(REPLACE(DM_RCEPL_CD,CHR(13),''),CHR(10),'') DM_RCEPL_CD
, REPLACE(REPLACE(HG_EFCY_ORG_DIV_CD,CHR(13),''),CHR(10),'') HG_EFCY_ORG_DIV_CD
, REPLACE(REPLACE(CULT_GRDE_CD,CHR(13),''),CHR(10),'') CULT_GRDE_CD
, REPLACE(REPLACE(CULT_ELP_CD,CHR(13),''),CHR(10),'') CULT_ELP_CD
, REPLACE(REPLACE(SPUS_JOB_CD,CHR(13),''),CHR(10),'') SPUS_JOB_CD
, CHDN_NUM
, REPLACE(REPLACE(ATRC_PSBL_PRD_CD,CHR(13),''),CHR(10),'') ATRC_PSBL_PRD_CD
, REPLACE(REPLACE(MA_TRSC_PTNCO_CD,CHR(13),''),CHR(10),'') MA_TRSC_PTNCO_CD
, REPLACE(REPLACE(CNSRV_YR_NUM_CD,CHR(13),''),CHR(10),'') CNSRV_YR_NUM_CD
, REPLACE(REPLACE(AVG_INCM_CD,CHR(13),''),CHR(10),'') AVG_INCM_CD
, REPLACE(REPLACE(CRSS_CO_OFRP_CD,CHR(13),''),CHR(10),'') CRSS_CO_OFRP_CD
, REPLACE(REPLACE(CULT_SPUS_JOB_DIV_CD,CHR(13),''),CHR(10),'') CULT_SPUS_JOB_DIV_CD
, REPLACE(REPLACE(CULT_PSTBT_JOB_DIV_CD,CHR(13),''),CHR(10),'') CULT_PSTBT_JOB_DIV_CD
, REPLACE(REPLACE(ORG_ID,CHR(13),''),CHR(10),'') ORG_ID
, REPLACE(REPLACE(SMRZ_ORG_ID,CHR(13),''),CHR(10),'') SMRZ_ORG_ID
, REPLACE(REPLACE(BZ_SB_ORG_ID,CHR(13),''),CHR(10),'') BZ_SB_ORG_ID
, REPLACE(REPLACE(HDQT_ORG_ID,CHR(13),''),CHR(10),'') HDQT_ORG_ID
, REPLACE(REPLACE(BRCH_ORG_ID,CHR(13),''),CHR(10),'') BRCH_ORG_ID
, REPLACE(REPLACE(BCH_ORG_ID,CHR(13),''),CHR(10),'') BCH_ORG_ID
, REPLACE(REPLACE(BCH_DRBG_TEM_ORG_ID,CHR(13),''),CHR(10),'') BCH_DRBG_TEM_ORG_ID
, REPLACE(REPLACE(UPB_CEN_ORG_ID,CHR(13),''),CHR(10),'') UPB_CEN_ORG_ID
, DATA_CHNG_DTM
, REPLACE(REPLACE(PART_ORG_ID,CHR(13),''),CHR(10),'') PART_ORG_ID
, REPLACE(REPLACE(PART_ORG_CD,CHR(13),''),CHR(10),'') PART_ORG_CD
, REPLACE(REPLACE(PART_ORG_NM,CHR(13),''),CHR(10),'') PART_ORG_NM
, REPLACE(REPLACE(PART_ORG_CHIF_ORG_ID,CHR(13),''),CHR(10),'') PART_ORG_CHIF_ORG_ID
, REPLACE(REPLACE(PART_ORG_CHIF_ORG_CD,CHR(13),''),CHR(10),'') PART_ORG_CHIF_ORG_CD
, REPLACE(REPLACE(PART_ORG_CHIF_NM,CHR(13),''),CHR(10),'') PART_ORG_CHIF_NM
, REPLACE(REPLACE(CEN_ORG_ID,CHR(13),''),CHR(10),'') CEN_ORG_ID
, REPLACE(REPLACE(CEN_ORG_CD,CHR(13),''),CHR(10),'') CEN_ORG_CD
, REPLACE(REPLACE(CEN_ORG_NM,CHR(13),''),CHR(10),'') CEN_ORG_NM
, REPLACE(REPLACE(CEN_ORG_CHIF_ORG_ID,CHR(13),''),CHR(10),'') CEN_ORG_CHIF_ORG_ID
, REPLACE(REPLACE(CEN_ORG_CHIF_ORG_CD,CHR(13),''),CHR(10),'') CEN_ORG_CHIF_ORG_CD
, REPLACE(REPLACE(CEN_ORG_CHIF_NM,CHR(13),''),CHR(10),'') CEN_ORG_CHIF_NM
, REPLACE(REPLACE(WCKT_ORG_ID,CHR(13),''),CHR(10),'') WCKT_ORG_ID
, REPLACE(REPLACE(WCKT_ORG_CD,CHR(13),''),CHR(10),'') WCKT_ORG_CD
, REPLACE(REPLACE(WCKT_ORG_NM,CHR(13),''),CHR(10),'') WCKT_ORG_NM
, REPLACE(REPLACE(WCKT_ORG_CHIF_ORG_ID,CHR(13),''),CHR(10),'') WCKT_ORG_CHIF_ORG_ID
, REPLACE(REPLACE(WCKT_ORG_CHIF_ORG_CD,CHR(13),''),CHR(10),'') WCKT_ORG_CHIF_ORG_CD
, REPLACE(REPLACE(WCKT_ORG_CHIF_NM,CHR(13),''),CHR(10),'') WCKT_ORG_CHIF_NM FROM TMMDB_SLZFMLM
                       WHERE \$CONDITIONS "\
    --m 8 \
    --boundary-query "SELECT 0, 7 FROM DUAL"\
    --split-by "ORA_HASH(ORG_CD, 7)"\
    --target-dir /tmp2/LAST_TMMDB_SLZFMLM \
    --hive-import \
    --external-table-dir hdfs:///tmp2/temp_tbl/LAST_TMMDB_SLZFMLM \
    --hive-overwrite \
    --hive-table DEFAULT.LAST_TMMDB_SLZFMLM  >> ${SHLOG_DIR}/TMMDB_SLZFMLM.shlog 2>&1 &&

#----------------------------------------------------#
# Hadoop 원본테이블에 변경분 최종 적용
#----------------------------------------------------#
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.TMMDB_SLZFMLM_TMP ; " >> ${SHLOG_DIR}/TMMDB_SLZFMLM.shlog 2>&1 &&
    /usr/bin/hive -e "CREATE EXTERNAL TABLE MERITZ.TMMDB_SLZFMLM_TMP STORED AS PARQUET TBLPROPERTIES ('PARQUET.COMPRESS'='SNAPPY') AS
                                SELECT *
                                FROM DEFAULT.LAST_TMMDB_SLZFMLM ;" >> ${SHLOG_DIR}/TMMDB_SLZFMLM.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.LAST_TMMDB_SLZFMLM ;" >> ${SHLOG_DIR}/TMMDB_SLZFMLM.shlog 2>&1 &&
    /usr/bin/hdfs dfs -rm -r -f -skipTrash /tmp2/temp_tbl/LAST_TMMDB_SLZFMLM >> ${SHLOG_DIR}/TMMDB_SLZFMLM.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.TMMDB_SLZFMLM ;" >> ${SHLOG_DIR}/TMMDB_SLZFMLM.shlog 2>&1 &&
    /usr/bin/hive -e "ALTER TABLE MERITZ.TMMDB_SLZFMLM_TMP RENAME TO MERITZ.TMMDB_SLZFMLM ;" >> ${SHLOG_DIR}/TMMDB_SLZFMLM.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.TMMDB_SLZFMLM_TMP ;" >> ${SHLOG_DIR}/TMMDB_SLZFMLM.shlog 2>&1 

if [ $? -ne 0 ]
then             
    echo "*-----------[ TMMDB_SLZFMLM.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/TMMDB_SLZFMLM.shlog"
    echo "*-----------[ TMMDB_SLZFMLM.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/TMMDB_SLZFMLM.shlog"  >>  ${SHLOG_DIR}/TMMDB_SLZFMLM.shlog
    echo "*-----------[ TMMDB_SLZFMLM.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ TMMDB_SLZFMLM.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/TMMDB_SLZFMLM.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/TMMDB_SLZFMLM.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/TMMDB_SLZFMLM.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/TMMDB_SLZFMLM.shlog /sqoopbin/scripts/etlpgm/his_log/TMMDB_SLZFMLM_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  TMMDB_SLZFMLM.sh cmd command error !! ***
    fi               

    exit -1      

else             
    echo "*-----------[ TMMDB_SLZFMLM.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ TMMDB_SLZFMLM.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/TMMDB_SLZFMLM.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/TMMDB_SLZFMLM.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/TMMDB_SLZFMLM.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/TMMDB_SLZFMLM.shlog /sqoopbin/scripts/etlpgm/his_log/TMMDB_SLZFMLM_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  TMMDB_SLZFMLM.sh cmd command error !! ***
        exit -1      
    else             
        exit 0       
    fi               
fi               
