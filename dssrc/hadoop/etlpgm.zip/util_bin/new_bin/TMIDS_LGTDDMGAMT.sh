#!/bin/bash

if [ $# -eq 0 ]
then           
    ARGS=N    
else           
    ARGS=$1
fi             

NOW=$(date +"+%Y-%m-%d_%T")
SHLOG_DIR=/sqoopbin/scripts/etlpgm/cur_log
HISLOG_DIR=/sqoopbin/scripts/etlpgm/his_log

export HADOOP_OPTS=-Djava.security.egd=file:/dev/../dev/urandom
export ORACLE_BASE=/sw/oracle
export ORACLE_HOME=/sw/oracle/product/11.2.0.4/client_1
export LD_LIBRARY_PATH=/sw/oracle/product/11.2.0.4/client_1/lib:/sw/oracle/product/11.2.0.4/client_1/lib:
export PATH=/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/usr/lib64/qt-3.3/bin:/usr/hdp/3.0.0.0-1634/spark2/bin/:/var/opt/node/bin/:/opt/maven/bin:/usr/local/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/home/hdpapp/workspace/data-science-at-the-command-line/tools:/home/hdpapp/.local/bin:/home/hdpapp/bin
export TNS_ADMIN=/sw/oracle/product/11.2.0.4/client_1/network/admin
export ORACLE_SID=DBEDWP2
export NLS_LANG=American_America.KO16MSWIN949

#----------------------------------------------------#
# 작업내용 : TMIDS_LGTDDMGAMT 테이블 sqoop 복제 작업
# 작업주기 :  
#----------------------------------------------------#

    echo " "
    echo "*-----------[ TMIDS_LGTDDMGAMT.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ TMIDS_LGTDDMGAMT.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`  >  ${SHLOG_DIR}/TMIDS_LGTDDMGAMT.shlog

#----------------------------------------------------#
# 테이블별 전체 데이터를 받아 오는 부분
#----------------------------------------------------#
    /usr/bin/hadoop fs -rm -r -f  /tmp2/LAST_TMIDS_LGTDDMGAMT  >> ${SHLOG_DIR}/TMIDS_LGTDDMGAMT.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.LAST_TMIDS_LGTDDMGAMT ; " >> ${SHLOG_DIR}/TMIDS_LGTDDMGAMT.shlog 2>&1 &&
    /usr/hdp/3.0.0.0-1634/sqoop/bin/sqoop import -D mapred.child.java.opts="-Djava.security.egd=file:/dev/../dev/urandom" \
    --connect jdbc:oracle:thin:EDWHADOOP/wjdqhrP\!23@10.91.41.172:12560:DBEDWP2 \
    --username  EDWHADOOP \
    --password wjdqhrP\!23 \
    --query "SELECT /*+ FULL(TMIDS_LGTDDMGAMT) */ STD_DT
, REPLACE(REPLACE(CLM_ID,CHR(13),''),CHR(10),'') CLM_ID
, REPLACE(REPLACE(COV_CD,CHR(13),''),CHR(10),'') COV_CD
, REPLACE(REPLACE(RSK_UNT_CD,CHR(13),''),CHR(10),'') RSK_UNT_CD
, REPLACE(REPLACE(GURT_UNT_CD,CHR(13),''),CHR(10),'') GURT_UNT_CD
, REPLACE(REPLACE(ACD_OBJ_ID,CHR(13),''),CHR(10),'') ACD_OBJ_ID
, REPLACE(REPLACE(CTR_OBJ_ID,CHR(13),''),CHR(10),'') CTR_OBJ_ID
, REPLACE(REPLACE(ACD_NO_YY,CHR(13),''),CHR(10),'') ACD_NO_YY
, ACD_NO_SEQ
, REPLACE(REPLACE(POL_NO,CHR(13),''),CHR(10),'') POL_NO
, REPLACE(REPLACE(CLM_TP_CD,CHR(13),''),CHR(10),'') CLM_TP_CD
, DAM_ORD
, REPLACE(REPLACE(DMG_RT_COV_LCTG_CD,CHR(13),''),CHR(10),'') DMG_RT_COV_LCTG_CD
, REPLACE(REPLACE(DMG_RT_COV_MCTG_CD,CHR(13),''),CHR(10),'') DMG_RT_COV_MCTG_CD
, REPLACE(REPLACE(DMG_RT_COV_SCTG_CD,CHR(13),''),CHR(10),'') DMG_RT_COV_SCTG_CD
, REPLACE(REPLACE(DMG_RT_COV_DCTG_CD,CHR(13),''),CHR(10),'') DMG_RT_COV_DCTG_CD
, REPLACE(REPLACE(SAL_PD_CD,CHR(13),''),CHR(10),'') SAL_PD_CD
, REPLACE(REPLACE(UNT_PD_CD,CHR(13),''),CHR(10),'') UNT_PD_CD
, REPLACE(REPLACE(ACD_RCT_ID,CHR(13),''),CHR(10),'') ACD_RCT_ID
, RCT_DT
, REPLACE(REPLACE(ACD_CTR_ID,CHR(13),''),CHR(10),'') ACD_CTR_ID
, REPLACE(REPLACE(POLHD_CUS_ID,CHR(13),''),CHR(10),'') POLHD_CUS_ID
, SBCP_DT
, REPLACE(REPLACE(ACD_CTR_OBJ_ID,CHR(13),''),CHR(10),'') ACD_CTR_OBJ_ID
, REPLACE(REPLACE(ACD_OBJ_DIV_CD,CHR(13),''),CHR(10),'') ACD_OBJ_DIV_CD
, REPLACE(REPLACE(CTR_OBJ_ADR_ID,CHR(13),''),CHR(10),'') CTR_OBJ_ADR_ID
, INSD_AMT
, ORIG_DINS_AMT
, ORIG_OS_INS_AMT
, PRPD_ORIG_OINS_AMT
, ORIG_DMG_AMT
, PSSE_DINS_AMT
, PSSE_OINS_AMT
, PRPD_PSSE_OINS_AMT
, PSSE_DMG_AMT
, EIH_LDG_DTM FROM TMIDS_LGTDDMGAMT
                       WHERE \$CONDITIONS "\
    --m 8 \
    --boundary-query "SELECT 0, 7 FROM DUAL"\
    --split-by "ORA_HASH(CLM_ID, 7)"\
    --target-dir /tmp2/LAST_TMIDS_LGTDDMGAMT \
    --hive-import \
    --external-table-dir hdfs:///tmp2/temp_tbl/LAST_TMIDS_LGTDDMGAMT \
    --hive-overwrite \
    --hive-table DEFAULT.LAST_TMIDS_LGTDDMGAMT  >> ${SHLOG_DIR}/TMIDS_LGTDDMGAMT.shlog 2>&1 &&

#----------------------------------------------------#
# Hadoop 원본테이블에 변경분 최종 적용
#----------------------------------------------------#
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.TMIDS_LGTDDMGAMT_TMP ; " >> ${SHLOG_DIR}/TMIDS_LGTDDMGAMT.shlog 2>&1 &&
    /usr/bin/hive -e "CREATE EXTERNAL TABLE MERITZ.TMIDS_LGTDDMGAMT_TMP STORED AS PARQUET TBLPROPERTIES ('PARQUET.COMPRESS'='SNAPPY') AS
                                SELECT *
                                FROM DEFAULT.LAST_TMIDS_LGTDDMGAMT ;" >> ${SHLOG_DIR}/TMIDS_LGTDDMGAMT.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.LAST_TMIDS_LGTDDMGAMT ;" >> ${SHLOG_DIR}/TMIDS_LGTDDMGAMT.shlog 2>&1 &&
    /usr/bin/hdfs dfs -rm -r -f -skipTrash /tmp2/temp_tbl/LAST_TMIDS_LGTDDMGAMT >> ${SHLOG_DIR}/TMIDS_LGTDDMGAMT.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.TMIDS_LGTDDMGAMT ;" >> ${SHLOG_DIR}/TMIDS_LGTDDMGAMT.shlog 2>&1 &&
    /usr/bin/hive -e "ALTER TABLE MERITZ.TMIDS_LGTDDMGAMT_TMP RENAME TO MERITZ.TMIDS_LGTDDMGAMT ;" >> ${SHLOG_DIR}/TMIDS_LGTDDMGAMT.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.TMIDS_LGTDDMGAMT_TMP ;" >> ${SHLOG_DIR}/TMIDS_LGTDDMGAMT.shlog 2>&1 

if [ $? -ne 0 ]
then             
    echo "*-----------[ TMIDS_LGTDDMGAMT.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/TMIDS_LGTDDMGAMT.shlog"
    echo "*-----------[ TMIDS_LGTDDMGAMT.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/TMIDS_LGTDDMGAMT.shlog"  >>  ${SHLOG_DIR}/TMIDS_LGTDDMGAMT.shlog
    echo "*-----------[ TMIDS_LGTDDMGAMT.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ TMIDS_LGTDDMGAMT.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/TMIDS_LGTDDMGAMT.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/TMIDS_LGTDDMGAMT.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/TMIDS_LGTDDMGAMT.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/TMIDS_LGTDDMGAMT.shlog /sqoopbin/scripts/etlpgm/his_log/TMIDS_LGTDDMGAMT_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  TMIDS_LGTDDMGAMT.sh cmd command error !! ***
    fi               

    exit -1      

else             
    echo "*-----------[ TMIDS_LGTDDMGAMT.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ TMIDS_LGTDDMGAMT.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/TMIDS_LGTDDMGAMT.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/TMIDS_LGTDDMGAMT.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/TMIDS_LGTDDMGAMT.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/TMIDS_LGTDDMGAMT.shlog /sqoopbin/scripts/etlpgm/his_log/TMIDS_LGTDDMGAMT_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  TMIDS_LGTDDMGAMT.sh cmd command error !! ***
        exit -1      
    else             
        exit 0       
    fi               
fi               
