#!/bin/bash

if [ $# -eq 0 ]
then           
    ARGS=N    
else           
    ARGS=$1
fi             

NOW=$(date +"+%Y-%m-%d_%T")
SHLOG_DIR=/sqoopbin/scripts/etlpgm/cur_log
HISLOG_DIR=/sqoopbin/scripts/etlpgm/his_log

export HADOOP_OPTS=-Djava.security.egd=file:/dev/../dev/urandom
export ORACLE_BASE=/sw/oracle
export ORACLE_HOME=/sw/oracle/product/11.2.0.4/client_1
export LD_LIBRARY_PATH=/sw/oracle/product/11.2.0.4/client_1/lib:/sw/oracle/product/11.2.0.4/client_1/lib:
export PATH=/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/usr/lib64/qt-3.3/bin:/usr/hdp/3.0.0.0-1634/spark2/bin/:/var/opt/node/bin/:/opt/maven/bin:/usr/local/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/home/hdpapp/workspace/data-science-at-the-command-line/tools:/home/hdpapp/.local/bin:/home/hdpapp/bin
export TNS_ADMIN=/sw/oracle/product/11.2.0.4/client_1/network/admin
export ORACLE_SID=DBEDWP2
export NLS_LANG=American_America.KO16MSWIN949

#----------------------------------------------------#
# 작업내용 : TMMDB_MSTAPOSCOV 테이블 sqoop 복제 작업
# 작업주기 :  
#----------------------------------------------------#

    echo " "
    echo "*-----------[ TMMDB_MSTAPOSCOV.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ TMMDB_MSTAPOSCOV.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`  >  ${SHLOG_DIR}/TMMDB_MSTAPOSCOV.shlog

#----------------------------------------------------#
# 테이블별 전체 데이터를 받아 오는 부분
#----------------------------------------------------#
    /usr/bin/hadoop fs -rm -r -f  /tmp2/LAST_TMMDB_MSTAPOSCOV  >> ${SHLOG_DIR}/TMMDB_MSTAPOSCOV.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.LAST_TMMDB_MSTAPOSCOV ; " >> ${SHLOG_DIR}/TMMDB_MSTAPOSCOV.shlog 2>&1 &&
    /usr/hdp/3.0.0.0-1634/sqoop/bin/sqoop import -D mapred.child.java.opts="-Djava.security.egd=file:/dev/../dev/urandom" \
    --connect jdbc:oracle:thin:EDWHADOOP/wjdqhrP\!23@10.91.41.172:12560:DBEDWP2 \
    --username  EDWHADOOP \
    --password wjdqhrP\!23 \
    --query "SELECT /*+ FULL(TMMDB_MSTAPOSCOV) */ REPLACE(REPLACE(PD_COV_CD_VAL,CHR(13),''),CHR(10),'') PD_COV_CD_VAL
, REPLACE(REPLACE(PD_CD,CHR(13),''),CHR(10),'') PD_CD
, REPLACE(REPLACE(COV_CD,CHR(13),''),CHR(10),'') COV_CD
, REPLACE(REPLACE(OS_COV_GRP_CD,CHR(13),''),CHR(10),'') OS_COV_GRP_CD
, REPLACE(REPLACE(INPPE_ORG_ID,CHR(13),''),CHR(10),'') INPPE_ORG_ID
, REPLACE(REPLACE(BIZ_SYS_CD,CHR(13),''),CHR(10),'') BIZ_SYS_CD
, EIH_LDG_DTM
, REPLACE(REPLACE(IBNR_COV_GRP_CD,CHR(13),''),CHR(10),'') IBNR_COV_GRP_CD FROM TMMDB_MSTAPOSCOV
                       WHERE \$CONDITIONS "\
    --m 1 \
    --target-dir /tmp2/LAST_TMMDB_MSTAPOSCOV \
    --hive-import \
    --external-table-dir hdfs:///tmp2/temp_tbl/LAST_TMMDB_MSTAPOSCOV \
    --hive-overwrite \
    --hive-table DEFAULT.LAST_TMMDB_MSTAPOSCOV  >> ${SHLOG_DIR}/TMMDB_MSTAPOSCOV.shlog 2>&1 &&

#----------------------------------------------------#
# Hadoop 원본테이블에 변경분 최종 적용
#----------------------------------------------------#
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.TMMDB_MSTAPOSCOV_TMP ; " >> ${SHLOG_DIR}/TMMDB_MSTAPOSCOV.shlog 2>&1 &&
    /usr/bin/hive -e "CREATE EXTERNAL TABLE MERITZ.TMMDB_MSTAPOSCOV_TMP STORED AS PARQUET TBLPROPERTIES ('PARQUET.COMPRESS'='SNAPPY') AS
                                SELECT *
                                FROM DEFAULT.LAST_TMMDB_MSTAPOSCOV ;" >> ${SHLOG_DIR}/TMMDB_MSTAPOSCOV.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.LAST_TMMDB_MSTAPOSCOV ;" >> ${SHLOG_DIR}/TMMDB_MSTAPOSCOV.shlog 2>&1 &&
    /usr/bin/hdfs dfs -rm -r -f -skipTrash /tmp2/temp_tbl/LAST_TMMDB_MSTAPOSCOV >> ${SHLOG_DIR}/TMMDB_MSTAPOSCOV.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.TMMDB_MSTAPOSCOV ;" >> ${SHLOG_DIR}/TMMDB_MSTAPOSCOV.shlog 2>&1 &&
    /usr/bin/hive -e "ALTER TABLE MERITZ.TMMDB_MSTAPOSCOV_TMP RENAME TO MERITZ.TMMDB_MSTAPOSCOV ;" >> ${SHLOG_DIR}/TMMDB_MSTAPOSCOV.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.TMMDB_MSTAPOSCOV_TMP ;" >> ${SHLOG_DIR}/TMMDB_MSTAPOSCOV.shlog 2>&1 

if [ $? -ne 0 ]
then             
    echo "*-----------[ TMMDB_MSTAPOSCOV.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/TMMDB_MSTAPOSCOV.shlog"
    echo "*-----------[ TMMDB_MSTAPOSCOV.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/TMMDB_MSTAPOSCOV.shlog"  >>  ${SHLOG_DIR}/TMMDB_MSTAPOSCOV.shlog
    echo "*-----------[ TMMDB_MSTAPOSCOV.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ TMMDB_MSTAPOSCOV.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/TMMDB_MSTAPOSCOV.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/TMMDB_MSTAPOSCOV.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/TMMDB_MSTAPOSCOV.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/TMMDB_MSTAPOSCOV.shlog /sqoopbin/scripts/etlpgm/his_log/TMMDB_MSTAPOSCOV_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  TMMDB_MSTAPOSCOV.sh cmd command error !! ***
    fi               

    exit -1      

else             
    echo "*-----------[ TMMDB_MSTAPOSCOV.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ TMMDB_MSTAPOSCOV.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/TMMDB_MSTAPOSCOV.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/TMMDB_MSTAPOSCOV.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/TMMDB_MSTAPOSCOV.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/TMMDB_MSTAPOSCOV.shlog /sqoopbin/scripts/etlpgm/his_log/TMMDB_MSTAPOSCOV_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  TMMDB_MSTAPOSCOV.sh cmd command error !! ***
        exit -1      
    else             
        exit 0       
    fi               
fi               
