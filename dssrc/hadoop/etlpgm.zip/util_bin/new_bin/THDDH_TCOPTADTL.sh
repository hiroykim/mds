#!/bin/bash

if [ $# -eq 0 ]
then           
    ARGS=N    
else           
    ARGS=$1
fi             

NOW=$(date +"+%Y-%m-%d_%T")
SHLOG_DIR=/sqoopbin/scripts/etlpgm/cur_log
HISLOG_DIR=/sqoopbin/scripts/etlpgm/his_log

export HADOOP_OPTS=-Djava.security.egd=file:/dev/../dev/urandom
export ORACLE_BASE=/sw/oracle
export ORACLE_HOME=/sw/oracle/product/11.2.0.4/client_1
export LD_LIBRARY_PATH=/sw/oracle/product/11.2.0.4/client_1/lib:/sw/oracle/product/11.2.0.4/client_1/lib:
export PATH=/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/usr/lib64/qt-3.3/bin:/usr/hdp/3.0.0.0-1634/spark2/bin/:/var/opt/node/bin/:/opt/maven/bin:/usr/local/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/home/hdpapp/workspace/data-science-at-the-command-line/tools:/home/hdpapp/.local/bin:/home/hdpapp/bin
export TNS_ADMIN=/sw/oracle/product/11.2.0.4/client_1/network/admin
export ORACLE_SID=DBEDWP2
export NLS_LANG=American_America.KO16MSWIN949

#----------------------------------------------------#
# 작업내용 : THDDH_TCOPTADTL 테이블 sqoop 복제 작업
# 작업주기 :  
#----------------------------------------------------#

    echo " "
    echo "*-----------[ THDDH_TCOPTADTL.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TCOPTADTL.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`  >  ${SHLOG_DIR}/THDDH_TCOPTADTL.shlog

#----------------------------------------------------#
# 테이블별 전체 데이터를 받아 오는 부분
#----------------------------------------------------#
    /usr/bin/hadoop fs -rm -r -f  /tmp2/LAST_THDDH_TCOPTADTL  >> ${SHLOG_DIR}/THDDH_TCOPTADTL.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.LAST_THDDH_TCOPTADTL ; " >> ${SHLOG_DIR}/THDDH_TCOPTADTL.shlog 2>&1 &&
    /usr/hdp/3.0.0.0-1634/sqoop/bin/sqoop import -D mapred.child.java.opts="-Djava.security.egd=file:/dev/../dev/urandom" \
    --connect jdbc:oracle:thin:EDWHADOOP/wjdqhrP\!23@10.91.41.172:12560:DBEDWP2 \
    --username  EDWHADOOP \
    --password wjdqhrP\!23 \
    --query "SELECT /*+ FULL(THDDH_TCOPTADTL) */ REPLACE(REPLACE(BIZ_PTY_ADR_ID,CHR(13),''),CHR(10),'') BIZ_PTY_ADR_ID
, HIS_SEQ
, REPLACE(REPLACE(SIDO_NM,CHR(13),''),CHR(10),'') SIDO_NM
, REPLACE(REPLACE(SGK_NM,CHR(13),''),CHR(10),'') SGK_NM
, REPLACE(REPLACE(EMD_NM,CHR(13),''),CHR(10),'') EMD_NM
, REPLACE(REPLACE(RI_NM,CHR(13),''),CHR(10),'') RI_NM
, REPLACE(REPLACE(LGDG_CD,CHR(13),''),CHR(10),'') LGDG_CD
, REPLACE(REPLACE(HJD_CD,CHR(13),''),CHR(10),'') HJD_CD
, REPLACE(REPLACE(HSNO_DIV_CD,CHR(13),''),CHR(10),'') HSNO_DIV_CD
, MA_HSNO
, SB_HSNO
, REPLACE(REPLACE(JNT_HUS_CD,CHR(13),''),CHR(10),'') JNT_HUS_CD
, REPLACE(REPLACE(BLDG_NM,CHR(13),''),CHR(10),'') BLDG_NM
, REPLACE(REPLACE(BLDG_DNG,CHR(13),''),CHR(10),'') BLDG_DNG
, REPLACE(REPLACE(BLDG_HO,CHR(13),''),CHR(10),'') BLDG_HO
, REPLACE(REPLACE(BLDG_FLR,CHR(13),''),CHR(10),'') BLDG_FLR
, REPLACE(REPLACE(BLDG_MNG_NO,CHR(13),''),CHR(10),'') BLDG_MNG_NO
, REPLACE(REPLACE(BLDG_UNDG_DIV_CD,CHR(13),''),CHR(10),'') BLDG_UNDG_DIV_CD
, REPLACE(REPLACE(ROAD_NM_CD,CHR(13),''),CHR(10),'') ROAD_NM_CD
, REPLACE(REPLACE(ROAD_NM,CHR(13),''),CHR(10),'') ROAD_NM
, REPLACE(REPLACE(GPS_LTT,CHR(13),''),CHR(10),'') GPS_LTT
, REPLACE(REPLACE(GPS_LNT,CHR(13),''),CHR(10),'') GPS_LNT
, REPLACE(REPLACE(GPS_ALTD,CHR(13),''),CHR(10),'') GPS_ALTD
, HIS_ST_DT
, HIS_ED_DT
, REPLACE(REPLACE(SYS_DEL_DIV_CD,CHR(13),''),CHR(10),'') SYS_DEL_DIV_CD
, REPLACE(REPLACE(INPPE_ORG_ID,CHR(13),''),CHR(10),'') INPPE_ORG_ID
, SYS_OCC_DTM
, REPLACE(REPLACE(OCC_IP,CHR(13),''),CHR(10),'') OCC_IP
, REPLACE(REPLACE(APP_ID,CHR(13),''),CHR(10),'') APP_ID
, DATA_CHNG_DTM
, REPLACE(REPLACE(EMD_NO,CHR(13),''),CHR(10),'') EMD_NO
, ORI_BLDG_NO
, SB_BLDG_NO
, REPLACE(REPLACE(ROAD_NM_ADR_IDF_VAL,CHR(13),''),CHR(10),'') ROAD_NM_ADR_IDF_VAL
, REPLACE(REPLACE(LNO_ADR_HSHD_CD,CHR(13),''),CHR(10),'') LNO_ADR_HSHD_CD
, REPLACE(REPLACE(ADR_HSHD_CD,CHR(13),''),CHR(10),'') ADR_HSHD_CD
, REPLACE(REPLACE(ZPCD,CHR(13),''),CHR(10),'') ZPCD
, EIH_LDG_DTM FROM THDDH_TCOPTADTL
                       WHERE \$CONDITIONS "\
    --m 8 \
    --boundary-query "SELECT 0, 7 FROM DUAL"\
    --split-by "ORA_HASH(BIZ_PTY_ADR_ID, 7)"\
    --target-dir /tmp2/LAST_THDDH_TCOPTADTL \
    --hive-import \
    --external-table-dir hdfs:///tmp2/temp_tbl/LAST_THDDH_TCOPTADTL \
    --hive-overwrite \
    --hive-table DEFAULT.LAST_THDDH_TCOPTADTL  >> ${SHLOG_DIR}/THDDH_TCOPTADTL.shlog 2>&1 &&

#----------------------------------------------------#
# Hadoop 원본테이블에 변경분 최종 적용
#----------------------------------------------------#
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TCOPTADTL_TMP ; " >> ${SHLOG_DIR}/THDDH_TCOPTADTL.shlog 2>&1 &&
    /usr/bin/hive -e "CREATE EXTERNAL TABLE MERITZ.THDDH_TCOPTADTL_TMP STORED AS PARQUET TBLPROPERTIES ('PARQUET.COMPRESS'='SNAPPY') AS
                                SELECT *
                                FROM DEFAULT.LAST_THDDH_TCOPTADTL ;" >> ${SHLOG_DIR}/THDDH_TCOPTADTL.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.LAST_THDDH_TCOPTADTL ;" >> ${SHLOG_DIR}/THDDH_TCOPTADTL.shlog 2>&1 &&
    /usr/bin/hdfs dfs -rm -r -f -skipTrash /tmp2/temp_tbl/LAST_THDDH_TCOPTADTL >> ${SHLOG_DIR}/THDDH_TCOPTADTL.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TCOPTADTL ;" >> ${SHLOG_DIR}/THDDH_TCOPTADTL.shlog 2>&1 &&
    /usr/bin/hive -e "ALTER TABLE MERITZ.THDDH_TCOPTADTL_TMP RENAME TO MERITZ.THDDH_TCOPTADTL ;" >> ${SHLOG_DIR}/THDDH_TCOPTADTL.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TCOPTADTL_TMP ;" >> ${SHLOG_DIR}/THDDH_TCOPTADTL.shlog 2>&1 

if [ $? -ne 0 ]
then             
    echo "*-----------[ THDDH_TCOPTADTL.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/THDDH_TCOPTADTL.shlog"
    echo "*-----------[ THDDH_TCOPTADTL.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/THDDH_TCOPTADTL.shlog"  >>  ${SHLOG_DIR}/THDDH_TCOPTADTL.shlog
    echo "*-----------[ THDDH_TCOPTADTL.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TCOPTADTL.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/THDDH_TCOPTADTL.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/THDDH_TCOPTADTL.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCOPTADTL.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCOPTADTL.shlog /sqoopbin/scripts/etlpgm/his_log/THDDH_TCOPTADTL_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  THDDH_TCOPTADTL.sh cmd command error !! ***
    fi               

    exit -1      

else             
    echo "*-----------[ THDDH_TCOPTADTL.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TCOPTADTL.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/THDDH_TCOPTADTL.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/THDDH_TCOPTADTL.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCOPTADTL.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCOPTADTL.shlog /sqoopbin/scripts/etlpgm/his_log/THDDH_TCOPTADTL_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  THDDH_TCOPTADTL.sh cmd command error !! ***
        exit -1      
    else             
        exit 0       
    fi               
fi               
