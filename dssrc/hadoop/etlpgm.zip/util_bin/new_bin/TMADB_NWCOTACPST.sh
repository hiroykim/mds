#!/bin/bash

if [ $# -eq 0 ]
then           
    ARGS=N    
else           
    ARGS=$1
fi             

NOW=$(date +"+%Y-%m-%d_%T")
SHLOG_DIR=/sqoopbin/scripts/etlpgm/cur_log
HISLOG_DIR=/sqoopbin/scripts/etlpgm/his_log

export HADOOP_OPTS=-Djava.security.egd=file:/dev/../dev/urandom
export ORACLE_BASE=/sw/oracle
export ORACLE_HOME=/sw/oracle/product/11.2.0.4/client_1
export LD_LIBRARY_PATH=/sw/oracle/product/11.2.0.4/client_1/lib:/sw/oracle/product/11.2.0.4/client_1/lib:
export PATH=/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/usr/lib64/qt-3.3/bin:/usr/hdp/3.0.0.0-1634/spark2/bin/:/var/opt/node/bin/:/opt/maven/bin:/usr/local/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/home/hdpapp/workspace/data-science-at-the-command-line/tools:/home/hdpapp/.local/bin:/home/hdpapp/bin
export TNS_ADMIN=/sw/oracle/product/11.2.0.4/client_1/network/admin
export ORACLE_SID=DBEDWP2
export NLS_LANG=American_America.KO16MSWIN949

#----------------------------------------------------#
# 작업내용 : TMADB_NWCOTACPST 테이블 sqoop 복제 작업
# 작업주기 :  
#----------------------------------------------------#

    echo " "
    echo "*-----------[ TMADB_NWCOTACPST.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ TMADB_NWCOTACPST.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`  >  ${SHLOG_DIR}/TMADB_NWCOTACPST.shlog

#----------------------------------------------------#
# 테이블별 전체 데이터를 받아 오는 부분
#----------------------------------------------------#
    /usr/bin/hadoop fs -rm -r -f  /tmp2/LAST_TMADB_NWCOTACPST  >> ${SHLOG_DIR}/TMADB_NWCOTACPST.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.LAST_TMADB_NWCOTACPST ; " >> ${SHLOG_DIR}/TMADB_NWCOTACPST.shlog 2>&1 &&
    /usr/hdp/3.0.0.0-1634/sqoop/bin/sqoop import -D mapred.child.java.opts="-Djava.security.egd=file:/dev/../dev/urandom" \
    --connect jdbc:oracle:thin:EDWHADOOP/wjdqhrP\!23@10.91.41.172:12560:DBEDWP2 \
    --username  EDWHADOOP \
    --password wjdqhrP\!23 \
    --query "SELECT /*+ FULL(TMADB_NWCOTACPST) */ REPLACE(REPLACE(CLOG_YYMM,CHR(13),''),CHR(10),'') CLOG_YYMM
, REPLACE(REPLACE(POL_NO,CHR(13),''),CHR(10),'') POL_NO
, REPLACE(REPLACE(PDGP_CD,CHR(13),''),CHR(10),'') PDGP_CD
, REPLACE(REPLACE(UNT_PD_CD,CHR(13),''),CHR(10),'') UNT_PD_CD
, INS_BGN_DT
, INS_ED_DT
, INSD_DD_NUM
, REPLACE(REPLACE(VEHC_YMDL,CHR(13),''),CHR(10),'') VEHC_YMDL
, REPLACE(REPLACE(ELP_VEHC_YMDL,CHR(13),''),CHR(10),'') ELP_VEHC_YMDL
, REPLACE(REPLACE(ISP_YN,CHR(13),''),CHR(10),'') ISP_YN
, NW_CTR_APL_PREM
, REPLACE(REPLACE(CAR_COV_UNI_CD,CHR(13),''),CHR(10),'') CAR_COV_UNI_CD
, REPLACE(REPLACE(CTR_RNWL_DIV_CD,CHR(13),''),CHR(10),'') CTR_RNWL_DIV_CD
, REPLACE(REPLACE(RISK_BD_CD,CHR(13),''),CHR(10),'') RISK_BD_CD
, REPLACE(REPLACE(FRCR_YN,CHR(13),''),CHR(10),'') FRCR_YN
, TRT_ORG_OPE_DMM
, REPLACE(REPLACE(TRTPE_ORG_CD,CHR(13),''),CHR(10),'') TRTPE_ORG_CD
, REPLACE(REPLACE(TRTPE_NM,CHR(13),''),CHR(10),'') TRTPE_NM
, REPLACE(REPLACE(TRT_HDQT_ORG_CD,CHR(13),''),CHR(10),'') TRT_HDQT_ORG_CD
, REPLACE(REPLACE(TRT_HDQT_ORG_NM,CHR(13),''),CHR(10),'') TRT_HDQT_ORG_NM
, REPLACE(REPLACE(ATM_NM_CD,CHR(13),''),CHR(10),'') ATM_NM_CD
, EIH_LDG_DTM
, REPLACE(REPLACE(ATM_NM_DSC_CON,CHR(13),''),CHR(10),'') ATM_NM_DSC_CON
, VEHC_VAMT
, REPLACE(REPLACE(ATM_NM_GRDE_CD,CHR(13),''),CHR(10),'') ATM_NM_GRDE_CD
, REPLACE(REPLACE(VHTP_CD,CHR(13),''),CHR(10),'') VHTP_CD
, REPLACE(REPLACE(ACP_VHTP_SBDV_CD,CHR(13),''),CHR(10),'') ACP_VHTP_SBDV_CD
, REPLACE(REPLACE(VEHC_NO_SIDO_CD,CHR(13),''),CHR(10),'') VEHC_NO_SIDO_CD
, REPLACE(REPLACE(PY_CYC_CD,CHR(13),''),CHR(10),'') PY_CYC_CD
, REPLACE(REPLACE(RPSB_PRTT_YN,CHR(13),''),CHR(10),'') RPSB_PRTT_YN
, REPLACE(REPLACE(BCT_KIDI_INSCO_CD,CHR(13),''),CHR(10),'') BCT_KIDI_INSCO_CD
, REPLACE(REPLACE(AGE_SIC_CD,CHR(13),''),CHR(10),'') AGE_SIC_CD
, REPLACE(REPLACE(DRVPE_LIMT_SIC_CD,CHR(13),''),CHR(10),'') DRVPE_LIMT_SIC_CD
, REPLACE(REPLACE(INSPE_CUS_NO,CHR(13),''),CHR(10),'') INSPE_CUS_NO
, REPLACE(REPLACE(INSPE_NM,CHR(13),''),CHR(10),'') INSPE_NM
, REPLACE(REPLACE(PSSPE_CD,CHR(13),''),CHR(10),'') PSSPE_CD
, REPLACE(REPLACE(BDT_IDF_NO,CHR(13),''),CHR(10),'') BDT_IDF_NO
, INSPE_FULL_AGE
, REPLACE(REPLACE(INSPE_ZPCD,CHR(13),''),CHR(10),'') INSPE_ZPCD
, REPLACE(REPLACE(SIDO_NM,CHR(13),''),CHR(10),'') SIDO_NM
, REPLACE(REPLACE(SGK_NM,CHR(13),''),CHR(10),'') SGK_NM
, REPLACE(REPLACE(DC_XCHG_GRDE_CD,CHR(13),''),CHR(10),'') DC_XCHG_GRDE_CD
, REPLACE(REPLACE(YY1_ACDC_CD,CHR(13),''),CHR(10),'') YY1_ACDC_CD
, REPLACE(REPLACE(YY3_ACDC_CD,CHR(13),''),CHR(10),'') YY3_ACDC_CD
, REPLACE(REPLACE(SBC_CRR_CD,CHR(13),''),CHR(10),'') SBC_CRR_CD
, EXPC_DMG_RT
, REPLACE(REPLACE(TRT_BRCH_ORG_CD,CHR(13),''),CHR(10),'') TRT_BRCH_ORG_CD
, REPLACE(REPLACE(TRT_BRCH_ORG_NM,CHR(13),''),CHR(10),'') TRT_BRCH_ORG_NM
, REPLACE(REPLACE(TRT_BCH_ORG_CD,CHR(13),''),CHR(10),'') TRT_BCH_ORG_CD
, REPLACE(REPLACE(TRT_BCH_ORG_NM,CHR(13),''),CHR(10),'') TRT_BCH_ORG_NM
, REPLACE(REPLACE(GNDR_CD,CHR(13),''),CHR(10),'') GNDR_CD
, REPLACE(REPLACE(SPC_XCHG_CD,CHR(13),''),CHR(10),'') SPC_XCHG_CD
, REPLACE(REPLACE(CAR_RISK_GRDE_VAL,CHR(13),''),CHR(10),'') CAR_RISK_GRDE_VAL
, REPLACE(REPLACE(BCT_THCO_POL_NO,CHR(13),''),CHR(10),'') BCT_THCO_POL_NO
, YY1_ACD_CNT
, YY3_ACD_CNT
, YY1_DMG_AMT
, YY3_DMG_AMT
, REPLACE(REPLACE(SMNS_POL_TP_CD,CHR(13),''),CHR(10),'') SMNS_POL_TP_CD
, NW_CTR_SUMUP_DT
, PRPY_DD_NUM
, REPLACE(REPLACE(GRUP_ISP_YN,CHR(13),''),CHR(10),'') GRUP_ISP_YN
, REPLACE(REPLACE(GRUP_ISPPE_NM,CHR(13),''),CHR(10),'') GRUP_ISPPE_NM
, LGTM_SMTM_SBC_CNT
, REPLACE(REPLACE(RPS_ATM_NM,CHR(13),''),CHR(10),'') RPS_ATM_NM
, BCT_UMOV_USE_TIMS
, ATRT_BCT_UMOV_USE_TIMS
, REPLACE(REPLACE(TFLW_VLT_CD,CHR(13),''),CHR(10),'') TFLW_VLT_CD
, VEHC_FXNO_NUM
, REPLACE(REPLACE(VEHC_LDG_FX_QT_VAL,CHR(13),''),CHR(10),'') VEHC_LDG_FX_QT_VAL
, VEHC_DPL_QT
, REPLACE(REPLACE(ENGN_FRML_DIV_CD,CHR(13),''),CHR(10),'') ENGN_FRML_DIV_CD
, USCR_CR
, TCRP_PSSE_CCNT
, REPLACE(REPLACE(TCRP_VEHC_SBC_CRR_VAL,CHR(13),''),CHR(10),'') TCRP_VEHC_SBC_CRR_VAL
, REPLACE(REPLACE(KIDI_DINSPE_SBC_CRR_CD,CHR(13),''),CHR(10),'') KIDI_DINSPE_SBC_CRR_CD
, REPLACE(REPLACE(MNFCO_CD,CHR(13),''),CHR(10),'') MNFCO_CD
, REPLACE(REPLACE(SNGL_ISPPE_NM,CHR(13),''),CHR(10),'') SNGL_ISPPE_NM
, REPLACE(REPLACE(LGTM_LEND_OWS_DIV_CD,CHR(13),''),CHR(10),'') LGTM_LEND_OWS_DIV_CD
, LGTM_LEND_AGE
, REPLACE(REPLACE(LGTM_LEND_NM,CHR(13),''),CHR(10),'') LGTM_LEND_NM
, REPLACE(REPLACE(VEHC_USG_CD,CHR(13),''),CHR(10),'') VEHC_USG_CD
, REPLACE(REPLACE(USE_USG_CD,CHR(13),''),CHR(10),'') USE_USG_CD
, REPLACE(REPLACE(VEHC_USG_SCTG_CD,CHR(13),''),CHR(10),'') VEHC_USG_SCTG_CD
, REPLACE(REPLACE(ISP_APL_DIV_CD,CHR(13),''),CHR(10),'') ISP_APL_DIV_CD
, REPLACE(REPLACE(TRT_AGPLR_ORG_CD,CHR(13),''),CHR(10),'') TRT_AGPLR_ORG_CD
, REPLACE(REPLACE(TRT_AGPLR_NM,CHR(13),''),CHR(10),'') TRT_AGPLR_NM FROM TMADB_NWCOTACPST
                       WHERE \$CONDITIONS "\
    --m 8 \
    --boundary-query "SELECT 0, 7 FROM DUAL"\
    --split-by "ORA_HASH(POL_NO, 7)"\
    --target-dir /tmp2/LAST_TMADB_NWCOTACPST \
    --hive-import \
    --external-table-dir hdfs:///tmp2/temp_tbl/LAST_TMADB_NWCOTACPST \
    --hive-overwrite \
    --hive-table DEFAULT.LAST_TMADB_NWCOTACPST  >> ${SHLOG_DIR}/TMADB_NWCOTACPST.shlog 2>&1 &&

#----------------------------------------------------#
# Hadoop 원본테이블에 변경분 최종 적용
#----------------------------------------------------#
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.TMADB_NWCOTACPST_TMP ; " >> ${SHLOG_DIR}/TMADB_NWCOTACPST.shlog 2>&1 &&
    /usr/bin/hive -e "CREATE EXTERNAL TABLE MERITZ.TMADB_NWCOTACPST_TMP STORED AS PARQUET TBLPROPERTIES ('PARQUET.COMPRESS'='SNAPPY') AS
                                SELECT *
                                FROM DEFAULT.LAST_TMADB_NWCOTACPST ;" >> ${SHLOG_DIR}/TMADB_NWCOTACPST.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.LAST_TMADB_NWCOTACPST ;" >> ${SHLOG_DIR}/TMADB_NWCOTACPST.shlog 2>&1 &&
    /usr/bin/hdfs dfs -rm -r -f -skipTrash /tmp2/temp_tbl/LAST_TMADB_NWCOTACPST >> ${SHLOG_DIR}/TMADB_NWCOTACPST.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.TMADB_NWCOTACPST ;" >> ${SHLOG_DIR}/TMADB_NWCOTACPST.shlog 2>&1 &&
    /usr/bin/hive -e "ALTER TABLE MERITZ.TMADB_NWCOTACPST_TMP RENAME TO MERITZ.TMADB_NWCOTACPST ;" >> ${SHLOG_DIR}/TMADB_NWCOTACPST.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.TMADB_NWCOTACPST_TMP ;" >> ${SHLOG_DIR}/TMADB_NWCOTACPST.shlog 2>&1 

if [ $? -ne 0 ]
then             
    echo "*-----------[ TMADB_NWCOTACPST.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/TMADB_NWCOTACPST.shlog"
    echo "*-----------[ TMADB_NWCOTACPST.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/TMADB_NWCOTACPST.shlog"  >>  ${SHLOG_DIR}/TMADB_NWCOTACPST.shlog
    echo "*-----------[ TMADB_NWCOTACPST.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ TMADB_NWCOTACPST.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/TMADB_NWCOTACPST.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/TMADB_NWCOTACPST.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/TMADB_NWCOTACPST.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/TMADB_NWCOTACPST.shlog /sqoopbin/scripts/etlpgm/his_log/TMADB_NWCOTACPST_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  TMADB_NWCOTACPST.sh cmd command error !! ***
    fi               

    exit -1      

else             
    echo "*-----------[ TMADB_NWCOTACPST.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ TMADB_NWCOTACPST.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/TMADB_NWCOTACPST.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/TMADB_NWCOTACPST.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/TMADB_NWCOTACPST.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/TMADB_NWCOTACPST.shlog /sqoopbin/scripts/etlpgm/his_log/TMADB_NWCOTACPST_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  TMADB_NWCOTACPST.sh cmd command error !! ***
        exit -1      
    else             
        exit 0       
    fi               
fi               
