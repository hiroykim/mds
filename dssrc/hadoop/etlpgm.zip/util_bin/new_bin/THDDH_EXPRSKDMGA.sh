#!/bin/bash

if [ $# -eq 0 ]
then           
    ARGS=N    
else           
    ARGS=$1
fi             

NOW=$(date +"+%Y-%m-%d_%T")
SHLOG_DIR=/sqoopbin/scripts/etlpgm/cur_log
HISLOG_DIR=/sqoopbin/scripts/etlpgm/his_log

export HADOOP_OPTS=-Djava.security.egd=file:/dev/../dev/urandom
export ORACLE_BASE=/sw/oracle
export ORACLE_HOME=/sw/oracle/product/11.2.0.4/client_1
export LD_LIBRARY_PATH=/sw/oracle/product/11.2.0.4/client_1/lib:/sw/oracle/product/11.2.0.4/client_1/lib:
export PATH=/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/usr/lib64/qt-3.3/bin:/usr/hdp/3.0.0.0-1634/spark2/bin/:/var/opt/node/bin/:/opt/maven/bin:/usr/local/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/home/hdpapp/workspace/data-science-at-the-command-line/tools:/home/hdpapp/.local/bin:/home/hdpapp/bin
export TNS_ADMIN=/sw/oracle/product/11.2.0.4/client_1/network/admin
export ORACLE_SID=DBEDWP2
export NLS_LANG=American_America.KO16MSWIN949

#----------------------------------------------------#
# 작업내용 : THDDH_EXPRSKDMGA 테이블 sqoop 복제 작업
# 작업주기 :  
#----------------------------------------------------#

    echo " "
    echo "*-----------[ THDDH_EXPRSKDMGA.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_EXPRSKDMGA.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`  >  ${SHLOG_DIR}/THDDH_EXPRSKDMGA.shlog

#----------------------------------------------------#
# 테이블별 전체 데이터를 받아 오는 부분
#----------------------------------------------------#
    /usr/bin/hadoop fs -rm -r -f  /tmp2/LAST_THDDH_EXPRSKDMGA  >> ${SHLOG_DIR}/THDDH_EXPRSKDMGA.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.LAST_THDDH_EXPRSKDMGA ; " >> ${SHLOG_DIR}/THDDH_EXPRSKDMGA.shlog 2>&1 &&
    /usr/hdp/3.0.0.0-1634/sqoop/bin/sqoop import -D mapred.child.java.opts="-Djava.security.egd=file:/dev/../dev/urandom" \
    --connect jdbc:oracle:thin:EDWHADOOP/wjdqhrP\!23@10.91.41.172:12560:DBEDWP2 \
    --username  EDWHADOOP \
    --password wjdqhrP\!23 \
    --query "SELECT /*+ FULL(THDDH_EXPRSKDMGA) */ REPLACE(REPLACE(CLG_YM,CHR(13),''),CHR(10),'') CLG_YM
, REPLACE(REPLACE(ACCD_MTT_ID,CHR(13),''),CHR(10),'') ACCD_MTT_ID
, SQNO
, REPLACE(REPLACE(CTC_MTT_ID,CHR(13),''),CHR(10),'') CTC_MTT_ID
, REPLACE(REPLACE(OST_DS_DVCD,CHR(13),''),CHR(10),'') OST_DS_DVCD
, REPLACE(REPLACE(ACCD_RPT_NO,CHR(13),''),CHR(10),'') ACCD_RPT_NO
, REPLACE(REPLACE(PLNO,CHR(13),''),CHR(10),'') PLNO
, PLY_SQNO
, REPLACE(REPLACE(SCY_SLSF_CD,CHR(13),''),CHR(10),'') SCY_SLSF_CD
, REPLACE(REPLACE(OJT_DVCD,CHR(13),''),CHR(10),'') OJT_DVCD
, OJT_SQNO
, REPLACE(REPLACE(OJT_CD,CHR(13),''),CHR(10),'') OJT_CD
, REPLACE(REPLACE(CVR_TTY_CD,CHR(13),''),CHR(10),'') CVR_TTY_CD
, CVR_TTY_SQNO
, OST_DS_SQNO
, REPLACE(REPLACE(ACCD_CVR_CD,CHR(13),''),CHR(10),'') ACCD_CVR_CD
, REPLACE(REPLACE(KID_PDC_CD,CHR(13),''),CHR(10),'') KID_PDC_CD
, REPLACE(REPLACE(KID_CTC_CD,CHR(13),''),CHR(10),'') KID_CTC_CD
, REPLACE(REPLACE(KID_CTC_CVR_CD,CHR(13),''),CHR(10),'') KID_CTC_CVR_CD
, REPLACE(REPLACE(KID_ACCD_CVR_CD,CHR(13),''),CHR(10),'') KID_ACCD_CVR_CD
, REPLACE(REPLACE(KID_DVCD_1,CHR(13),''),CHR(10),'') KID_DVCD_1
, REPLACE(REPLACE(KID_DVCD_2,CHR(13),''),CHR(10),'') KID_DVCD_2
, REPLACE(REPLACE(KID_DVCD_3,CHR(13),''),CHR(10),'') KID_DVCD_3
, REPLACE(REPLACE(KID_DVCD_4,CHR(13),''),CHR(10),'') KID_DVCD_4
, REPLACE(REPLACE(KID_DVCD_VAL_1,CHR(13),''),CHR(10),'') KID_DVCD_VAL_1
, REPLACE(REPLACE(KID_DVCD_VAL_2,CHR(13),''),CHR(10),'') KID_DVCD_VAL_2
, REPLACE(REPLACE(KID_DVCD_VAL_3,CHR(13),''),CHR(10),'') KID_DVCD_VAL_3
, REPLACE(REPLACE(KID_DVCD_VAL_4,CHR(13),''),CHR(10),'') KID_DVCD_VAL_4
, REPLACE(REPLACE(PDC_CD,CHR(13),''),CHR(10),'') PDC_CD
, REPLACE(REPLACE(PDC_PTL_DVCD,CHR(13),''),CHR(10),'') PDC_PTL_DVCD
, REPLACE(REPLACE(CVR_PDC_CD,CHR(13),''),CHR(10),'') CVR_PDC_CD
, REPLACE(REPLACE(CVR_PDC_PTL_DVCD,CHR(13),''),CHR(10),'') CVR_PDC_PTL_DVCD
, ARC_TRM_STR_DT
, ARC_TRM_FIN_DT
, FRST_CVR_TRM_STR_DT
, CVR_TRM_STR_DT
, CVR_TRM_FIN_DT
, PPS_INAM
, CVR_INAM
, PYN_DT
, PYN_ELP_YCNT
, ACCD_OCDT
, ACCD_RPT_DT
, FRST_ACCD_RPT_DT
, FRST_OST_DT
, FRST_PYN_DT
, PYN_BNF
, OST_BNF
, LSTM_OST_BNF
, LSAT
, REPLACE(REPLACE(DETH_YN,CHR(13),''),CHR(10),'') DETH_YN
, REPLACE(REPLACE(STDBD_DVCD,CHR(13),''),CHR(10),'') STDBD_DVCD
, REPLACE(REPLACE(SPCI_CD,CHR(13),''),CHR(10),'') SPCI_CD
, REPLACE(REPLACE(KID_ARC_TRM_CD,CHR(13),''),CHR(10),'') KID_ARC_TRM_CD
, REPLACE(REPLACE(AFCT_OBST_ICCO_CD,CHR(13),''),CHR(10),'') AFCT_OBST_ICCO_CD
, REPLACE(REPLACE(INJ_EXNS_CD,CHR(13),''),CHR(10),'') INJ_EXNS_CD
, REPLACE(REPLACE(KID_AG_CD,CHR(13),''),CHR(10),'') KID_AG_CD
, REPLACE(REPLACE(INS_RLT_DVCD,CHR(13),''),CHR(10),'') INS_RLT_DVCD
, REPLACE(REPLACE(APCN_BSTP_CD,CHR(13),''),CHR(10),'') APCN_BSTP_CD
, REPLACE(REPLACE(KID_BD_STRU_RTG_CD,CHR(13),''),CHR(10),'') KID_BD_STRU_RTG_CD
, REPLACE(REPLACE(INS_SX_CD,CHR(13),''),CHR(10),'') INS_SX_CD
, REPLACE(REPLACE(INS_JOB_CD,CHR(13),''),CHR(10),'') INS_JOB_CD
, INS_ARC_AG
, INS_CVR_AG
, INS_FRST_CVR_AG
, REPLACE(REPLACE(INS_DRVE_YN,CHR(13),''),CHR(10),'') INS_DRVE_YN
, REPLACE(REPLACE(INJ_RTG_CD,CHR(13),''),CHR(10),'') INJ_RTG_CD
, REPLACE(REPLACE(FT_CVR_YN,CHR(13),''),CHR(10),'') FT_CVR_YN
, REPLACE(REPLACE(INS_CUST_NO,CHR(13),''),CHR(10),'') INS_CUST_NO
, REPLACE(REPLACE(DIAG_YN,CHR(13),''),CHR(10),'') DIAG_YN
, REPLACE(REPLACE(SCNL_YN,CHR(13),''),CHR(10),'') SCNL_YN
, REPLACE(REPLACE(CVS_KID_ACCD_CVR_CD,CHR(13),''),CHR(10),'') CVS_KID_ACCD_CVR_CD
, REPLACE(REPLACE(CVS_KID_DVCD_1,CHR(13),''),CHR(10),'') CVS_KID_DVCD_1
, REPLACE(REPLACE(CVS_KID_DVCD_2,CHR(13),''),CHR(10),'') CVS_KID_DVCD_2
, REPLACE(REPLACE(CVS_KID_DVCD_3,CHR(13),''),CHR(10),'') CVS_KID_DVCD_3
, REPLACE(REPLACE(CVS_KID_DVCD_4,CHR(13),''),CHR(10),'') CVS_KID_DVCD_4
, REPLACE(REPLACE(CVS_KID_DVCD_VAL_1,CHR(13),''),CHR(10),'') CVS_KID_DVCD_VAL_1
, REPLACE(REPLACE(CVS_KID_DVCD_VAL_2,CHR(13),''),CHR(10),'') CVS_KID_DVCD_VAL_2
, REPLACE(REPLACE(CVS_KID_DVCD_VAL_3,CHR(13),''),CHR(10),'') CVS_KID_DVCD_VAL_3
, REPLACE(REPLACE(CVS_KID_DVCD_VAL_4,CHR(13),''),CHR(10),'') CVS_KID_DVCD_VAL_4
, FNAL_CHNG_DTTM
, REPLACE(REPLACE(FNAL_CHNG_ID,CHR(13),''),CHR(10),'') FNAL_CHNG_ID
, EIH_LDG_DTM FROM THDDH_EXPRSKDMGA
                       WHERE \$CONDITIONS "\
    --m 8 \
    --boundary-query "SELECT 0, 7 FROM DUAL"\
    --split-by "ORA_HASH(ACCD_MTT_ID, 7)"\
    --target-dir /tmp2/LAST_THDDH_EXPRSKDMGA \
    --hive-import \
    --external-table-dir hdfs:///tmp2/temp_tbl/LAST_THDDH_EXPRSKDMGA \
    --hive-overwrite \
    --hive-table DEFAULT.LAST_THDDH_EXPRSKDMGA  >> ${SHLOG_DIR}/THDDH_EXPRSKDMGA.shlog 2>&1 &&

#----------------------------------------------------#
# Hadoop 원본테이블에 변경분 최종 적용
#----------------------------------------------------#
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_EXPRSKDMGA_TMP ; " >> ${SHLOG_DIR}/THDDH_EXPRSKDMGA.shlog 2>&1 &&
    /usr/bin/hive -e "CREATE EXTERNAL TABLE MERITZ.THDDH_EXPRSKDMGA_TMP STORED AS PARQUET TBLPROPERTIES ('PARQUET.COMPRESS'='SNAPPY') AS
                                SELECT *
                                FROM DEFAULT.LAST_THDDH_EXPRSKDMGA ;" >> ${SHLOG_DIR}/THDDH_EXPRSKDMGA.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.LAST_THDDH_EXPRSKDMGA ;" >> ${SHLOG_DIR}/THDDH_EXPRSKDMGA.shlog 2>&1 &&
    /usr/bin/hdfs dfs -rm -r -f -skipTrash /tmp2/temp_tbl/LAST_THDDH_EXPRSKDMGA >> ${SHLOG_DIR}/THDDH_EXPRSKDMGA.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_EXPRSKDMGA ;" >> ${SHLOG_DIR}/THDDH_EXPRSKDMGA.shlog 2>&1 &&
    /usr/bin/hive -e "ALTER TABLE MERITZ.THDDH_EXPRSKDMGA_TMP RENAME TO MERITZ.THDDH_EXPRSKDMGA ;" >> ${SHLOG_DIR}/THDDH_EXPRSKDMGA.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_EXPRSKDMGA_TMP ;" >> ${SHLOG_DIR}/THDDH_EXPRSKDMGA.shlog 2>&1 

if [ $? -ne 0 ]
then             
    echo "*-----------[ THDDH_EXPRSKDMGA.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/THDDH_EXPRSKDMGA.shlog"
    echo "*-----------[ THDDH_EXPRSKDMGA.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/THDDH_EXPRSKDMGA.shlog"  >>  ${SHLOG_DIR}/THDDH_EXPRSKDMGA.shlog
    echo "*-----------[ THDDH_EXPRSKDMGA.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_EXPRSKDMGA.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/THDDH_EXPRSKDMGA.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/THDDH_EXPRSKDMGA.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/THDDH_EXPRSKDMGA.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/THDDH_EXPRSKDMGA.shlog /sqoopbin/scripts/etlpgm/his_log/THDDH_EXPRSKDMGA_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  THDDH_EXPRSKDMGA.sh cmd command error !! ***
    fi               

    exit -1      

else             
    echo "*-----------[ THDDH_EXPRSKDMGA.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_EXPRSKDMGA.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/THDDH_EXPRSKDMGA.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/THDDH_EXPRSKDMGA.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/THDDH_EXPRSKDMGA.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/THDDH_EXPRSKDMGA.shlog /sqoopbin/scripts/etlpgm/his_log/THDDH_EXPRSKDMGA_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  THDDH_EXPRSKDMGA.sh cmd command error !! ***
        exit -1      
    else             
        exit 0       
    fi               
fi               
