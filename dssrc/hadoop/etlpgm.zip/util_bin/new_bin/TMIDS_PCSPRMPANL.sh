#!/bin/bash

if [ $# -eq 0 ]
then           
    ARGS=N    
else           
    ARGS=$1
fi             

NOW=$(date +"+%Y-%m-%d_%T")
SHLOG_DIR=/sqoopbin/scripts/etlpgm/cur_log
HISLOG_DIR=/sqoopbin/scripts/etlpgm/his_log

export HADOOP_OPTS=-Djava.security.egd=file:/dev/../dev/urandom
export ORACLE_BASE=/sw/oracle
export ORACLE_HOME=/sw/oracle/product/11.2.0.4/client_1
export LD_LIBRARY_PATH=/sw/oracle/product/11.2.0.4/client_1/lib:/sw/oracle/product/11.2.0.4/client_1/lib:
export PATH=/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/usr/lib64/qt-3.3/bin:/usr/hdp/3.0.0.0-1634/spark2/bin/:/var/opt/node/bin/:/opt/maven/bin:/usr/local/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/home/hdpapp/workspace/data-science-at-the-command-line/tools:/home/hdpapp/.local/bin:/home/hdpapp/bin
export TNS_ADMIN=/sw/oracle/product/11.2.0.4/client_1/network/admin
export ORACLE_SID=DBEDWP2
export NLS_LANG=American_America.KO16MSWIN949

#----------------------------------------------------#
# 작업내용 : TMIDS_PCSPRMPANL 테이블 sqoop 복제 작업
# 작업주기 :  
#----------------------------------------------------#

    echo " "
    echo "*-----------[ TMIDS_PCSPRMPANL.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ TMIDS_PCSPRMPANL.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`  >  ${SHLOG_DIR}/TMIDS_PCSPRMPANL.shlog

#----------------------------------------------------#
# 테이블별 전체 데이터를 받아 오는 부분
#----------------------------------------------------#
    /usr/bin/hadoop fs -rm -r -f  /tmp2/LAST_TMIDS_PCSPRMPANL  >> ${SHLOG_DIR}/TMIDS_PCSPRMPANL.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.LAST_TMIDS_PCSPRMPANL ; " >> ${SHLOG_DIR}/TMIDS_PCSPRMPANL.shlog 2>&1 &&
    /usr/hdp/3.0.0.0-1634/sqoop/bin/sqoop import -D mapred.child.java.opts="-Djava.security.egd=file:/dev/../dev/urandom" \
    --connect jdbc:oracle:thin:EDWHADOOP/wjdqhrP\!23@10.91.41.172:12560:DBEDWP2 \
    --username  EDWHADOOP \
    --password wjdqhrP\!23 \
    --query "SELECT /*+ FULL(TMIDS_PCSPRMPANL) */ STD_DT
, REPLACE(REPLACE(CLM_ID,CHR(13),''),CHR(10),'') CLM_ID
, REPLACE(REPLACE(ACD_NO_YY,CHR(13),''),CHR(10),'') ACD_NO_YY
, ACD_NO_SEQ
, REPLACE(REPLACE(POL_NO,CHR(13),''),CHR(10),'') POL_NO
, REPLACE(REPLACE(CLM_TP_CD,CHR(13),''),CHR(10),'') CLM_TP_CD
, DAM_ORD
, RCT_DT
, APVL_DT
, DIVD_DT
, ELP_DD_NUM
, FRS_APVL_DT
, LAST_APVL_DT
, REPLACE(REPLACE(ACD_CAUS_LCTG_CD,CHR(13),''),CHR(10),'') ACD_CAUS_LCTG_CD
, REPLACE(REPLACE(ACD_STAT_CD,CHR(13),''),CHR(10),'') ACD_STAT_CD
, REPLACE(REPLACE(CHRPE_PART_ORG_CD,CHR(13),''),CHR(10),'') CHRPE_PART_ORG_CD
, REPLACE(REPLACE(CHRPE_PART_NM,CHR(13),''),CHR(10),'') CHRPE_PART_NM
, REPLACE(REPLACE(CHRPE_ORG_CD,CHR(13),''),CHR(10),'') CHRPE_ORG_CD
, REPLACE(REPLACE(CHRPE_NM,CHR(13),''),CHR(10),'') CHRPE_NM
, PRD_WTHN_CNT
, KW_CNVS_DCN_INS_AMT
, EIH_LDG_DTM FROM TMIDS_PCSPRMPANL
                       WHERE \$CONDITIONS "\
    --m 8 \
    --boundary-query "SELECT 0, 7 FROM DUAL"\
    --split-by "ORA_HASH(CLM_ID, 7)"\
    --target-dir /tmp2/LAST_TMIDS_PCSPRMPANL \
    --hive-import \
    --external-table-dir hdfs:///tmp2/temp_tbl/LAST_TMIDS_PCSPRMPANL \
    --hive-overwrite \
    --hive-table DEFAULT.LAST_TMIDS_PCSPRMPANL  >> ${SHLOG_DIR}/TMIDS_PCSPRMPANL.shlog 2>&1 &&

#----------------------------------------------------#
# Hadoop 원본테이블에 변경분 최종 적용
#----------------------------------------------------#
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.TMIDS_PCSPRMPANL_TMP ; " >> ${SHLOG_DIR}/TMIDS_PCSPRMPANL.shlog 2>&1 &&
    /usr/bin/hive -e "CREATE EXTERNAL TABLE MERITZ.TMIDS_PCSPRMPANL_TMP STORED AS PARQUET TBLPROPERTIES ('PARQUET.COMPRESS'='SNAPPY') AS
                                SELECT *
                                FROM DEFAULT.LAST_TMIDS_PCSPRMPANL ;" >> ${SHLOG_DIR}/TMIDS_PCSPRMPANL.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.LAST_TMIDS_PCSPRMPANL ;" >> ${SHLOG_DIR}/TMIDS_PCSPRMPANL.shlog 2>&1 &&
    /usr/bin/hdfs dfs -rm -r -f -skipTrash /tmp2/temp_tbl/LAST_TMIDS_PCSPRMPANL >> ${SHLOG_DIR}/TMIDS_PCSPRMPANL.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.TMIDS_PCSPRMPANL ;" >> ${SHLOG_DIR}/TMIDS_PCSPRMPANL.shlog 2>&1 &&
    /usr/bin/hive -e "ALTER TABLE MERITZ.TMIDS_PCSPRMPANL_TMP RENAME TO MERITZ.TMIDS_PCSPRMPANL ;" >> ${SHLOG_DIR}/TMIDS_PCSPRMPANL.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.TMIDS_PCSPRMPANL_TMP ;" >> ${SHLOG_DIR}/TMIDS_PCSPRMPANL.shlog 2>&1 

if [ $? -ne 0 ]
then             
    echo "*-----------[ TMIDS_PCSPRMPANL.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/TMIDS_PCSPRMPANL.shlog"
    echo "*-----------[ TMIDS_PCSPRMPANL.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/TMIDS_PCSPRMPANL.shlog"  >>  ${SHLOG_DIR}/TMIDS_PCSPRMPANL.shlog
    echo "*-----------[ TMIDS_PCSPRMPANL.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ TMIDS_PCSPRMPANL.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/TMIDS_PCSPRMPANL.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/TMIDS_PCSPRMPANL.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/TMIDS_PCSPRMPANL.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/TMIDS_PCSPRMPANL.shlog /sqoopbin/scripts/etlpgm/his_log/TMIDS_PCSPRMPANL_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  TMIDS_PCSPRMPANL.sh cmd command error !! ***
    fi               

    exit -1      

else             
    echo "*-----------[ TMIDS_PCSPRMPANL.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ TMIDS_PCSPRMPANL.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/TMIDS_PCSPRMPANL.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/TMIDS_PCSPRMPANL.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/TMIDS_PCSPRMPANL.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/TMIDS_PCSPRMPANL.shlog /sqoopbin/scripts/etlpgm/his_log/TMIDS_PCSPRMPANL_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  TMIDS_PCSPRMPANL.sh cmd command error !! ***
        exit -1      
    else             
        exit 0       
    fi               
fi               
