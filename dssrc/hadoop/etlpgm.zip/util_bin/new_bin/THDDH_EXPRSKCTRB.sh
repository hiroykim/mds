#!/bin/bash

if [ $# -eq 0 ]
then           
    ARGS=N    
else           
    ARGS=$1
fi             

NOW=$(date +"+%Y-%m-%d_%T")
SHLOG_DIR=/sqoopbin/scripts/etlpgm/cur_log
HISLOG_DIR=/sqoopbin/scripts/etlpgm/his_log

export HADOOP_OPTS=-Djava.security.egd=file:/dev/../dev/urandom
export ORACLE_BASE=/sw/oracle
export ORACLE_HOME=/sw/oracle/product/11.2.0.4/client_1
export LD_LIBRARY_PATH=/sw/oracle/product/11.2.0.4/client_1/lib:/sw/oracle/product/11.2.0.4/client_1/lib:
export PATH=/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/usr/lib64/qt-3.3/bin:/usr/hdp/3.0.0.0-1634/spark2/bin/:/var/opt/node/bin/:/opt/maven/bin:/usr/local/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/home/hdpapp/workspace/data-science-at-the-command-line/tools:/home/hdpapp/.local/bin:/home/hdpapp/bin
export TNS_ADMIN=/sw/oracle/product/11.2.0.4/client_1/network/admin
export ORACLE_SID=DBEDWP2
export NLS_LANG=American_America.KO16MSWIN949

#----------------------------------------------------#
# 작업내용 : THDDH_EXPRSKCTRB 테이블 sqoop 복제 작업
# 작업주기 :  
#----------------------------------------------------#

    echo " "
    echo "*-----------[ THDDH_EXPRSKCTRB.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_EXPRSKCTRB.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`  >  ${SHLOG_DIR}/THDDH_EXPRSKCTRB.shlog

#----------------------------------------------------#
# 테이블별 전체 데이터를 받아 오는 부분
#----------------------------------------------------#
    /usr/bin/hadoop fs -rm -r -f  /tmp2/LAST_THDDH_EXPRSKCTRB  >> ${SHLOG_DIR}/THDDH_EXPRSKCTRB.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.LAST_THDDH_EXPRSKCTRB ; " >> ${SHLOG_DIR}/THDDH_EXPRSKCTRB.shlog 2>&1 &&
    /usr/hdp/3.0.0.0-1634/sqoop/bin/sqoop import -D mapred.child.java.opts="-Djava.security.egd=file:/dev/../dev/urandom" \
    --connect jdbc:oracle:thin:EDWHADOOP/wjdqhrP\!23@10.91.41.172:12560:DBEDWP2 \
    --username  EDWHADOOP \
    --password wjdqhrP\!23 \
    --query "SELECT /*+ FULL(THDDH_EXPRSKCTRB) */ REPLACE(REPLACE(STD_YYMM,CHR(13),''),CHR(10),'') STD_YYMM
, REPLACE(REPLACE(CVR_MTT_ID,CHR(13),''),CHR(10),'') CVR_MTT_ID
, CVR_CHNG_SQNO
, SQNO
, REPLACE(REPLACE(KID_ACCD_CVR_CD,CHR(13),''),CHR(10),'') KID_ACCD_CVR_CD
, REPLACE(REPLACE(CTC_MTT_ID,CHR(13),''),CHR(10),'') CTC_MTT_ID
, REPLACE(REPLACE(PLNO,CHR(13),''),CHR(10),'') PLNO
, PLY_SQNO
, REPLACE(REPLACE(SCY_SLSF_CD,CHR(13),''),CHR(10),'') SCY_SLSF_CD
, REPLACE(REPLACE(OJT_DVCD,CHR(13),''),CHR(10),'') OJT_DVCD
, OJT_SQNO
, REPLACE(REPLACE(CVR_TTY_CD,CHR(13),''),CHR(10),'') CVR_TTY_CD
, CVR_TTY_SQNO
, APCN_STR_DT
, APCN_FIN_DT
, ARC_TRM_STR_DT
, ARC_TRM_FIN_DT
, FRST_CVR_TRM_STR_DT
, CVR_TRM_STR_DT
, CVR_TRM_FIN_DT
, RNW_NTS
, IMMU_APCN_CVR_BGDT
, FS_ARC_TRM_FIN_DT
, REPLACE(REPLACE(FT_CVR_YN,CHR(13),''),CHR(10),'') FT_CVR_YN
, FT_BTH_EPCT_DT
, FT_BTH_DT
, REPLACE(REPLACE(PDC_CD,CHR(13),''),CHR(10),'') PDC_CD
, REPLACE(REPLACE(PDC_PTL_DVCD,CHR(13),''),CHR(10),'') PDC_PTL_DVCD
, REPLACE(REPLACE(CTC_STAT_CD,CHR(13),''),CHR(10),'') CTC_STAT_CD
, EPCT_IRT
, REPLACE(REPLACE(KID_PDC_CD,CHR(13),''),CHR(10),'') KID_PDC_CD
, REPLACE(REPLACE(KID_CTC_CD,CHR(13),''),CHR(10),'') KID_CTC_CD
, REPLACE(REPLACE(KID_CTC_CVR_CD,CHR(13),''),CHR(10),'') KID_CTC_CVR_CD
, KID_CMP_SNO
, REPLACE(REPLACE(KID_CLSF_TPCD,CHR(13),''),CHR(10),'') KID_CLSF_TPCD
, REPLACE(REPLACE(KID_CLSF_CD,CHR(13),''),CHR(10),'') KID_CLSF_CD
, REPLACE(REPLACE(KID_DVCD_1,CHR(13),''),CHR(10),'') KID_DVCD_1
, REPLACE(REPLACE(KID_DVCD_2,CHR(13),''),CHR(10),'') KID_DVCD_2
, REPLACE(REPLACE(KID_DVCD_3,CHR(13),''),CHR(10),'') KID_DVCD_3
, REPLACE(REPLACE(KID_DVCD_4,CHR(13),''),CHR(10),'') KID_DVCD_4
, REPLACE(REPLACE(KID_DVCD_VAL_1,CHR(13),''),CHR(10),'') KID_DVCD_VAL_1
, REPLACE(REPLACE(KID_DVCD_VAL_2,CHR(13),''),CHR(10),'') KID_DVCD_VAL_2
, REPLACE(REPLACE(KID_DVCD_VAL_3,CHR(13),''),CHR(10),'') KID_DVCD_VAL_3
, REPLACE(REPLACE(KID_DVCD_VAL_4,CHR(13),''),CHR(10),'') KID_DVCD_VAL_4
, KID_ASR_RTO
, REPLACE(REPLACE(KID_CMP_TPCD,CHR(13),''),CHR(10),'') KID_CMP_TPCD
, KID_CMP_FCT_VAL_1
, KID_CMP_FCT_VAL_2
, KID_CMP_FCT_VAL_3
, KID_CMP_FCT_VAL_4
, KID_CMP_FCT_VAL_5
, CMP_IF_CNUM
, REPLACE(REPLACE(CVS_CVR_YN,CHR(13),''),CHR(10),'') CVS_CVR_YN
, REPLACE(REPLACE(CVS_KID_ACCD_CVR_CD,CHR(13),''),CHR(10),'') CVS_KID_ACCD_CVR_CD
, REPLACE(REPLACE(CVS_KID_DVCD_1,CHR(13),''),CHR(10),'') CVS_KID_DVCD_1
, REPLACE(REPLACE(CVS_KID_DVCD_2,CHR(13),''),CHR(10),'') CVS_KID_DVCD_2
, REPLACE(REPLACE(CVS_KID_DVCD_3,CHR(13),''),CHR(10),'') CVS_KID_DVCD_3
, REPLACE(REPLACE(CVS_KID_DVCD_4,CHR(13),''),CHR(10),'') CVS_KID_DVCD_4
, REPLACE(REPLACE(CVS_KID_DVCD_VAL_1,CHR(13),''),CHR(10),'') CVS_KID_DVCD_VAL_1
, REPLACE(REPLACE(CVS_KID_DVCD_VAL_2,CHR(13),''),CHR(10),'') CVS_KID_DVCD_VAL_2
, REPLACE(REPLACE(CVS_KID_DVCD_VAL_3,CHR(13),''),CHR(10),'') CVS_KID_DVCD_VAL_3
, REPLACE(REPLACE(CVS_KID_DVCD_VAL_4,CHR(13),''),CHR(10),'') CVS_KID_DVCD_VAL_4
, REPLACE(REPLACE(CVS_KID_CMP_TPCD,CHR(13),''),CHR(10),'') CVS_KID_CMP_TPCD
, CVS_KID_CMP_FCT_VAL_1
, CVS_KID_CMP_FCT_VAL_2
, CVS_KID_CMP_FCT_VAL_3
, CVS_KID_CMP_FCT_VAL_4
, CVS_KID_CMP_FCT_VAL_5
, REPLACE(REPLACE(SPCI_CD,CHR(13),''),CHR(10),'') SPCI_CD
, REPLACE(REPLACE(INS_RLT_DVCD,CHR(13),''),CHR(10),'') INS_RLT_DVCD
, REPLACE(REPLACE(KID_ARC_TRM_CD,CHR(13),''),CHR(10),'') KID_ARC_TRM_CD
, REPLACE(REPLACE(KID_AG_CD,CHR(13),''),CHR(10),'') KID_AG_CD
, REPLACE(REPLACE(AFCT_OBST_ICCO_CD,CHR(13),''),CHR(10),'') AFCT_OBST_ICCO_CD
, REPLACE(REPLACE(INJ_EXNS_CD,CHR(13),''),CHR(10),'') INJ_EXNS_CD
, REPLACE(REPLACE(INS_SX_CD,CHR(13),''),CHR(10),'') INS_SX_CD
, INS_ARC_AG
, INS_CVR_AG
, INS_FRST_CVR_AG
, INS_CRNT_AG
, REPLACE(REPLACE(INJ_RTG_CD,CHR(13),''),CHR(10),'') INJ_RTG_CD
, REPLACE(REPLACE(STDBD_DVCD,CHR(13),''),CHR(10),'') STDBD_DVCD
, REPLACE(REPLACE(SCNL_APCN_MTP,CHR(13),''),CHR(10),'') SCNL_APCN_MTP
, ASR_PRM
, ARC_INAM
, ST1_CANR_OCDT
, CHD_ENY_AG
, CHD_CRNT_AG
, REPLACE(REPLACE(AO_KID_VAL,CHR(13),''),CHR(10),'') AO_KID_VAL
, REPLACE(REPLACE(AP_KID_VAL,CHR(13),''),CHR(10),'') AP_KID_VAL
, REPLACE(REPLACE(KID_XCPT_TPCD,CHR(13),''),CHR(10),'') KID_XCPT_TPCD
, REPLACE(REPLACE(XCPT_PROC_VAL,CHR(13),''),CHR(10),'') XCPT_PROC_VAL
, REPLACE(REPLACE(PMI_CVR_YN,CHR(13),''),CHR(10),'') PMI_CVR_YN
, RKRT_BSE_DT
, ONLV_RKRT_BSE_DT
, BSE_INAM
, ONLV_BSE_INAM
, REPLACE(REPLACE(RKRT_DVCD,CHR(13),''),CHR(10),'') RKRT_DVCD
, APCN_RKRT
, OTM_RKRT
, PMI_MDCS_ACUM_RSRT
, PMI_MDCS_ADJ_CFC
, ONLV_APCN_RKRT
, ONLV_OTM_RKRT
, ONLV_RFOT_RKRT
, ONLV_PMI_MDCS_ACUM_RSRT
, ONLV_PMI_MDCS_ADJ_CFC
, CMP_ELP_YCNT
, ARC_ELP_YCNT
, FRST_CVR_ELP_YCNT
, ELP_STR_DT
, ELP_FIN_DT
, DUNT_ELP_CCNT
, DUNT_APCN_ELP_RPRM
, DUNT_OTM_ELP_RPRM
, ONLV_DUNT_APCN_ELP_RPRM
, ONLV_DUNT_OTM_ELP_RPRM
, ONLV_DUNT_RFOT_ELP_RPRM
, MUNT_ELP_CCNT
, MUNT_APCN_ELP_RPRM
, MUNT_OTM_ELP_RPRM
, ONLV_MUNT_APCN_ELP_RPRM
, ONLV_MUNT_OTM_ELP_RPRM
, ONLV_MUNT_RFOT_ELP_RPRM
, FNAL_CHNG_DTTM
, REPLACE(REPLACE(FNAL_CHNG_ID,CHR(13),''),CHR(10),'') FNAL_CHNG_ID
, EIH_LDG_DTM FROM THDDH_EXPRSKCTRB
                       WHERE \$CONDITIONS "\
    --m 8 \
    --boundary-query "SELECT 0, 7 FROM DUAL"\
    --split-by "ORA_HASH(CVR_MTT_ID, 7)"\
    --target-dir /tmp2/LAST_THDDH_EXPRSKCTRB \
    --hive-import \
    --external-table-dir hdfs:///tmp2/temp_tbl/LAST_THDDH_EXPRSKCTRB \
    --hive-overwrite \
    --hive-table DEFAULT.LAST_THDDH_EXPRSKCTRB  >> ${SHLOG_DIR}/THDDH_EXPRSKCTRB.shlog 2>&1 &&

#----------------------------------------------------#
# Hadoop 원본테이블에 변경분 최종 적용
#----------------------------------------------------#
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_EXPRSKCTRB_TMP ; " >> ${SHLOG_DIR}/THDDH_EXPRSKCTRB.shlog 2>&1 &&
    /usr/bin/hive -e "CREATE EXTERNAL TABLE MERITZ.THDDH_EXPRSKCTRB_TMP STORED AS PARQUET TBLPROPERTIES ('PARQUET.COMPRESS'='SNAPPY') AS
                                SELECT *
                                FROM DEFAULT.LAST_THDDH_EXPRSKCTRB ;" >> ${SHLOG_DIR}/THDDH_EXPRSKCTRB.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.LAST_THDDH_EXPRSKCTRB ;" >> ${SHLOG_DIR}/THDDH_EXPRSKCTRB.shlog 2>&1 &&
    /usr/bin/hdfs dfs -rm -r -f -skipTrash /tmp2/temp_tbl/LAST_THDDH_EXPRSKCTRB >> ${SHLOG_DIR}/THDDH_EXPRSKCTRB.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_EXPRSKCTRB ;" >> ${SHLOG_DIR}/THDDH_EXPRSKCTRB.shlog 2>&1 &&
    /usr/bin/hive -e "ALTER TABLE MERITZ.THDDH_EXPRSKCTRB_TMP RENAME TO MERITZ.THDDH_EXPRSKCTRB ;" >> ${SHLOG_DIR}/THDDH_EXPRSKCTRB.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_EXPRSKCTRB_TMP ;" >> ${SHLOG_DIR}/THDDH_EXPRSKCTRB.shlog 2>&1 

if [ $? -ne 0 ]
then             
    echo "*-----------[ THDDH_EXPRSKCTRB.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/THDDH_EXPRSKCTRB.shlog"
    echo "*-----------[ THDDH_EXPRSKCTRB.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/THDDH_EXPRSKCTRB.shlog"  >>  ${SHLOG_DIR}/THDDH_EXPRSKCTRB.shlog
    echo "*-----------[ THDDH_EXPRSKCTRB.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_EXPRSKCTRB.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/THDDH_EXPRSKCTRB.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/THDDH_EXPRSKCTRB.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/THDDH_EXPRSKCTRB.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/THDDH_EXPRSKCTRB.shlog /sqoopbin/scripts/etlpgm/his_log/THDDH_EXPRSKCTRB_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  THDDH_EXPRSKCTRB.sh cmd command error !! ***
    fi               

    exit -1      

else             
    echo "*-----------[ THDDH_EXPRSKCTRB.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_EXPRSKCTRB.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/THDDH_EXPRSKCTRB.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/THDDH_EXPRSKCTRB.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/THDDH_EXPRSKCTRB.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/THDDH_EXPRSKCTRB.shlog /sqoopbin/scripts/etlpgm/his_log/THDDH_EXPRSKCTRB_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  THDDH_EXPRSKCTRB.sh cmd command error !! ***
        exit -1      
    else             
        exit 0       
    fi               
fi               
