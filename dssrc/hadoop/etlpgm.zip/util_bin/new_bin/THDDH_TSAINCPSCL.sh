#!/bin/bash

if [ $# -eq 0 ]
then           
    ARGS=N    
else           
    ARGS=$1
fi             

NOW=$(date +"+%Y-%m-%d_%T")
SHLOG_DIR=/sqoopbin/scripts/etlpgm/cur_log
HISLOG_DIR=/sqoopbin/scripts/etlpgm/his_log

export HADOOP_OPTS=-Djava.security.egd=file:/dev/../dev/urandom
export ORACLE_BASE=/sw/oracle
export ORACLE_HOME=/sw/oracle/product/11.2.0.4/client_1
export LD_LIBRARY_PATH=/sw/oracle/product/11.2.0.4/client_1/lib:/sw/oracle/product/11.2.0.4/client_1/lib:
export PATH=/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/usr/lib64/qt-3.3/bin:/usr/hdp/3.0.0.0-1634/spark2/bin/:/var/opt/node/bin/:/opt/maven/bin:/usr/local/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/home/hdpapp/workspace/data-science-at-the-command-line/tools:/home/hdpapp/.local/bin:/home/hdpapp/bin
export TNS_ADMIN=/sw/oracle/product/11.2.0.4/client_1/network/admin
export ORACLE_SID=DBEDWP2
export NLS_LANG=American_America.KO16MSWIN949

#----------------------------------------------------#
# 작업내용 : THDDH_TSAINCPSCL 테이블 sqoop 복제 작업
# 작업주기 :  
#----------------------------------------------------#

    echo " "
    echo "*-----------[ THDDH_TSAINCPSCL.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TSAINCPSCL.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`  >  ${SHLOG_DIR}/THDDH_TSAINCPSCL.shlog

#----------------------------------------------------#
# 테이블별 전체 데이터를 받아 오는 부분
#----------------------------------------------------#
    /usr/bin/hadoop fs -rm -r -f  /tmp2/LAST_THDDH_TSAINCPSCL  >> ${SHLOG_DIR}/THDDH_TSAINCPSCL.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.LAST_THDDH_TSAINCPSCL ; " >> ${SHLOG_DIR}/THDDH_TSAINCPSCL.shlog 2>&1 &&
    /usr/hdp/3.0.0.0-1634/sqoop/bin/sqoop import -D mapred.child.java.opts="-Djava.security.egd=file:/dev/../dev/urandom" \
    --connect jdbc:oracle:thin:EDWHADOOP/wjdqhrP\!23@10.91.41.172:12560:DBEDWP2 \
    --username  EDWHADOOP \
    --password wjdqhrP\!23 \
    --query "SELECT /*+ FULL(THDDH_TSAINCPSCL) */ REPLACE(REPLACE(STD_YYMM,CHR(13),''),CHR(10),'') STD_YYMM
, STD_DNO
, REPLACE(REPLACE(ORG_ID,CHR(13),''),CHR(10),'') ORG_ID
, REPLACE(REPLACE(PSA_CLOG_BIZ_DIV_CD,CHR(13),''),CHR(10),'') PSA_CLOG_BIZ_DIV_CD
, REPLACE(REPLACE(FEE_SLZ_FML_DIV_CD,CHR(13),''),CHR(10),'') FEE_SLZ_FML_DIV_CD
, REPLACE(REPLACE(AGC_GRDE_VAL,CHR(13),''),CHR(10),'') AGC_GRDE_VAL
, PAY_DT
, REPLACE(REPLACE(PAY_FNC_INST_CD,CHR(13),''),CHR(10),'') PAY_FNC_INST_CD
, REPLACE(REPLACE(REG_ID,CHR(13),''),CHR(10),'') REG_ID
, REPLACE(REPLACE(AGC_BIZ_NO,CHR(13),''),CHR(10),'') AGC_BIZ_NO
, REPLACE(REPLACE(CMPU_EQUP_PSSE_YN,CHR(13),''),CHR(10),'') CMPU_EQUP_PSSE_YN
, REPLACE(REPLACE(EDU_EXEM_YN,CHR(13),''),CHR(10),'') EDU_EXEM_YN
, REPLACE(REPLACE(UPB_INSTL_YN,CHR(13),''),CHR(10),'') UPB_INSTL_YN
, REPLACE(REPLACE(TRS_FNC_INST_CD,CHR(13),''),CHR(10),'') TRS_FNC_INST_CD
, REPLACE(REPLACE(TRS_REG_ID,CHR(13),''),CHR(10),'') TRS_REG_ID
, REPLACE(REPLACE(FP_QUAL_YN,CHR(13),''),CHR(10),'') FP_QUAL_YN
, REPLACE(REPLACE(DMS_MNGR_INP_YYMM,CHR(13),''),CHR(10),'') DMS_MNGR_INP_YYMM
, REPLACE(REPLACE(BRC_QUAL_YN,CHR(13),''),CHR(10),'') BRC_QUAL_YN
, REPLACE(REPLACE(AGC_RNT_SUPT_YN,CHR(13),''),CHR(10),'') AGC_RNT_SUPT_YN
, REPLACE(REPLACE(WRL_MDM_USE_YN,CHR(13),''),CHR(10),'') WRL_MDM_USE_YN
, PSCH_CHDN_PE_NUM
, REPLACE(REPLACE(EXCL_ATH_SLZ_FML_YN,CHR(13),''),CHR(10),'') EXCL_ATH_SLZ_FML_YN
, REPLACE(REPLACE(CRSS_SAL_ATRC_QUAL_YN,CHR(13),''),CHR(10),'') CRSS_SAL_ATRC_QUAL_YN
, REPLACE(REPLACE(FTMGM_BCH_ORG_ID,CHR(13),''),CHR(10),'') FTMGM_BCH_ORG_ID
, REPLACE(REPLACE(BFSZF_SCPOS_CONV_CD,CHR(13),''),CHR(10),'') BFSZF_SCPOS_CONV_CD
, REPLACE(REPLACE(BFT_BFSZF_ORG_ID,CHR(13),''),CHR(10),'') BFT_BFSZF_ORG_ID
, BFT_BFSZF_ENTCO_DT
, BFT_BFSZF_RTRM_DT
, REPLACE(REPLACE(FEE_ACU_PL_TRGPE_YN,CHR(13),''),CHR(10),'') FEE_ACU_PL_TRGPE_YN
, REPLACE(REPLACE(CRSS_MNGR_ENTT_YYMM,CHR(13),''),CHR(10),'') CRSS_MNGR_ENTT_YYMM
, REPLACE(REPLACE(NWCM_CCH_ENTT_YYMM,CHR(13),''),CHR(10),'') NWCM_CCH_ENTT_YYMM
, REPLACE(REPLACE(GUEMP_ORG_ID,CHR(13),''),CHR(10),'') GUEMP_ORG_ID
, REPLACE(REPLACE(RECRU_TMGM_ENTT_YYMM,CHR(13),''),CHR(10),'') RECRU_TMGM_ENTT_YYMM
, REPLACE(REPLACE(PAY_TIMS_CD,CHR(13),''),CHR(10),'') PAY_TIMS_CD
, REPLACE(REPLACE(TBLPC_REG_YN,CHR(13),''),CHR(10),'') TBLPC_REG_YN
, REPLACE(REPLACE(INPPE_ORG_ID,CHR(13),''),CHR(10),'') INPPE_ORG_ID
, SYS_OCC_DTM
, REPLACE(REPLACE(SYS_DEL_DIV_CD,CHR(13),''),CHR(10),'') SYS_DEL_DIV_CD
, REPLACE(REPLACE(APP_ID,CHR(13),''),CHR(10),'') APP_ID
, REPLACE(REPLACE(OCC_IP,CHR(13),''),CHR(10),'') OCC_IP
, DATA_CHNG_DTM
, REPLACE(REPLACE(EDU_MNGR_ORG_ID,CHR(13),''),CHR(10),'') EDU_MNGR_ORG_ID
, REPLACE(REPLACE(SALE_MNGR_ORG_ID,CHR(13),''),CHR(10),'') SALE_MNGR_ORG_ID
, REPLACE(REPLACE(AGC_TPIDS_DIV_CD,CHR(13),''),CHR(10),'') AGC_TPIDS_DIV_CD
, REPLACE(REPLACE(TCH_RT_ACHIV_YN,CHR(13),''),CHR(10),'') TCH_RT_ACHIV_YN
, EIH_LDG_DTM
, REPLACE(REPLACE(BFT_FEE_PAY_TP_CD,CHR(13),''),CHR(10),'') BFT_FEE_PAY_TP_CD
, REPLACE(REPLACE(CMPU_EQUP_REG_YYMM,CHR(13),''),CHR(10),'') CMPU_EQUP_REG_YYMM
, REPLACE(REPLACE(CRSS_SAL_YN,CHR(13),''),CHR(10),'') CRSS_SAL_YN
, REPLACE(REPLACE(FTJB_GRDE_VAL,CHR(13),''),CHR(10),'') FTJB_GRDE_VAL
, REPLACE(REPLACE(NWCM_GRDE_VAL,CHR(13),''),CHR(10),'') NWCM_GRDE_VAL
, REPLACE(REPLACE(TMGM_GRDE_VAL,CHR(13),''),CHR(10),'') TMGM_GRDE_VAL
, ELC_SBCP_CNT
, REPLACE(REPLACE(TMGM_ENTT_YYMM,CHR(13),''),CHR(10),'') TMGM_ENTT_YYMM
, REPLACE(REPLACE(TB_TMGM_ENTT_YYMM,CHR(13),''),CHR(10),'') TB_TMGM_ENTT_YYMM
, LWST_GURT_DMM
, REPLACE(REPLACE(RCPT_PREM_USE_YN,CHR(13),''),CHR(10),'') RCPT_PREM_USE_YN
, REPLACE(REPLACE(EMPM_INS_TRG_YN,CHR(13),''),CHR(10),'') EMPM_INS_TRG_YN FROM THDDH_TSAINCPSCL
                       WHERE \$CONDITIONS "\
    --m 1 \
    --target-dir /tmp2/LAST_THDDH_TSAINCPSCL \
    --hive-import \
    --external-table-dir hdfs:///tmp2/temp_tbl/LAST_THDDH_TSAINCPSCL \
    --hive-overwrite \
    --hive-table DEFAULT.LAST_THDDH_TSAINCPSCL  >> ${SHLOG_DIR}/THDDH_TSAINCPSCL.shlog 2>&1 &&

#----------------------------------------------------#
# Hadoop 원본테이블에 변경분 최종 적용
#----------------------------------------------------#
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TSAINCPSCL_TMP ; " >> ${SHLOG_DIR}/THDDH_TSAINCPSCL.shlog 2>&1 &&
    /usr/bin/hive -e "CREATE EXTERNAL TABLE MERITZ.THDDH_TSAINCPSCL_TMP STORED AS PARQUET TBLPROPERTIES ('PARQUET.COMPRESS'='SNAPPY') AS
                                SELECT *
                                FROM DEFAULT.LAST_THDDH_TSAINCPSCL ;" >> ${SHLOG_DIR}/THDDH_TSAINCPSCL.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.LAST_THDDH_TSAINCPSCL ;" >> ${SHLOG_DIR}/THDDH_TSAINCPSCL.shlog 2>&1 &&
    /usr/bin/hdfs dfs -rm -r -f -skipTrash /tmp2/temp_tbl/LAST_THDDH_TSAINCPSCL >> ${SHLOG_DIR}/THDDH_TSAINCPSCL.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TSAINCPSCL ;" >> ${SHLOG_DIR}/THDDH_TSAINCPSCL.shlog 2>&1 &&
    /usr/bin/hive -e "ALTER TABLE MERITZ.THDDH_TSAINCPSCL_TMP RENAME TO MERITZ.THDDH_TSAINCPSCL ;" >> ${SHLOG_DIR}/THDDH_TSAINCPSCL.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TSAINCPSCL_TMP ;" >> ${SHLOG_DIR}/THDDH_TSAINCPSCL.shlog 2>&1 

if [ $? -ne 0 ]
then             
    echo "*-----------[ THDDH_TSAINCPSCL.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/THDDH_TSAINCPSCL.shlog"
    echo "*-----------[ THDDH_TSAINCPSCL.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/THDDH_TSAINCPSCL.shlog"  >>  ${SHLOG_DIR}/THDDH_TSAINCPSCL.shlog
    echo "*-----------[ THDDH_TSAINCPSCL.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TSAINCPSCL.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/THDDH_TSAINCPSCL.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/THDDH_TSAINCPSCL.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TSAINCPSCL.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TSAINCPSCL.shlog /sqoopbin/scripts/etlpgm/his_log/THDDH_TSAINCPSCL_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  THDDH_TSAINCPSCL.sh cmd command error !! ***
    fi               

    exit -1      

else             
    echo "*-----------[ THDDH_TSAINCPSCL.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TSAINCPSCL.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/THDDH_TSAINCPSCL.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/THDDH_TSAINCPSCL.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TSAINCPSCL.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TSAINCPSCL.shlog /sqoopbin/scripts/etlpgm/his_log/THDDH_TSAINCPSCL_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  THDDH_TSAINCPSCL.sh cmd command error !! ***
        exit -1      
    else             
        exit 0       
    fi               
fi               
