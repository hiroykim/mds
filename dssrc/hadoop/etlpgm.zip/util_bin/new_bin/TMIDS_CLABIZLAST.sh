#!/bin/bash

if [ $# -eq 0 ]
then           
    ARGS=N    
else           
    ARGS=$1
fi             

NOW=$(date +"+%Y-%m-%d_%T")
SHLOG_DIR=/sqoopbin/scripts/etlpgm/cur_log
HISLOG_DIR=/sqoopbin/scripts/etlpgm/his_log

export HADOOP_OPTS=-Djava.security.egd=file:/dev/../dev/urandom
export ORACLE_BASE=/sw/oracle
export ORACLE_HOME=/sw/oracle/product/11.2.0.4/client_1
export LD_LIBRARY_PATH=/sw/oracle/product/11.2.0.4/client_1/lib:/sw/oracle/product/11.2.0.4/client_1/lib:
export PATH=/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/usr/lib64/qt-3.3/bin:/usr/hdp/3.0.0.0-1634/spark2/bin/:/var/opt/node/bin/:/opt/maven/bin:/usr/local/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/home/hdpapp/workspace/data-science-at-the-command-line/tools:/home/hdpapp/.local/bin:/home/hdpapp/bin
export TNS_ADMIN=/sw/oracle/product/11.2.0.4/client_1/network/admin
export ORACLE_SID=DBEDWP2
export NLS_LANG=American_America.KO16MSWIN949

#----------------------------------------------------#
# 작업내용 : TMIDS_CLABIZLAST 테이블 sqoop 복제 작업
# 작업주기 :  
#----------------------------------------------------#

    echo " "
    echo "*-----------[ TMIDS_CLABIZLAST.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ TMIDS_CLABIZLAST.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`  >  ${SHLOG_DIR}/TMIDS_CLABIZLAST.shlog

#----------------------------------------------------#
# 테이블별 전체 데이터를 받아 오는 부분
#----------------------------------------------------#
    /usr/bin/hadoop fs -rm -r -f  /tmp2/LAST_TMIDS_CLABIZLAST  >> ${SHLOG_DIR}/TMIDS_CLABIZLAST.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.LAST_TMIDS_CLABIZLAST ; " >> ${SHLOG_DIR}/TMIDS_CLABIZLAST.shlog 2>&1 &&
    /usr/hdp/3.0.0.0-1634/sqoop/bin/sqoop import -D mapred.child.java.opts="-Djava.security.egd=file:/dev/../dev/urandom" \
    --connect jdbc:oracle:thin:EDWHADOOP/wjdqhrP\!23@10.91.41.172:12560:DBEDWP2 \
    --username  EDWHADOOP \
    --password wjdqhrP\!23 \
    --query "SELECT /*+ FULL(TMIDS_CLABIZLAST) */ REPLACE(REPLACE(STD_YYMM,CHR(13),''),CHR(10),'') STD_YYMM
, STD_DT
, REPLACE(REPLACE(CLM_ID,CHR(13),''),CHR(10),'') CLM_ID
, REPLACE(REPLACE(DATA_ID,CHR(13),''),CHR(10),'') DATA_ID
, REPLACE(REPLACE(ACD_OBJ_DIV_CD,CHR(13),''),CHR(10),'') ACD_OBJ_DIV_CD
, REPLACE(REPLACE(ACD_OBJ_ID,CHR(13),''),CHR(10),'') ACD_OBJ_ID
, REPLACE(REPLACE(COV_CD,CHR(13),''),CHR(10),'') COV_CD
, REPLACE(REPLACE(RSK_UNT_CD,CHR(13),''),CHR(10),'') RSK_UNT_CD
, REPLACE(REPLACE(GURT_UNT_CD,CHR(13),''),CHR(10),'') GURT_UNT_CD
, SLZ_DD_NUM
, REPLACE(REPLACE(INS_ITMS_DIV_CD,CHR(13),''),CHR(10),'') INS_ITMS_DIV_CD
, REPLACE(REPLACE(ACP_SH_CD,CHR(13),''),CHR(10),'') ACP_SH_CD
, REPLACE(REPLACE(ACD_NO_YY,CHR(13),''),CHR(10),'') ACD_NO_YY
, ACD_NO_SEQ
, REPLACE(REPLACE(POL_NO,CHR(13),''),CHR(10),'') POL_NO
, SBCP_DT
, REPLACE(REPLACE(UY_YY,CHR(13),''),CHR(10),'') UY_YY
, REPLACE(REPLACE(CLM_TP_CD,CHR(13),''),CHR(10),'') CLM_TP_CD
, DAM_ORD
, REPLACE(REPLACE(DMG_RT_COV_MCTG_CD,CHR(13),''),CHR(10),'') DMG_RT_COV_MCTG_CD
, REPLACE(REPLACE(DCN_ID,CHR(13),''),CHR(10),'') DCN_ID
, DCN_SEQ
, REPLACE(REPLACE(DCN_DIV_CD,CHR(13),''),CHR(10),'') DCN_DIV_CD
, DCN_DT
, REPLACE(REPLACE(CNCLU_ID,CHR(13),''),CHR(10),'') CNCLU_ID
, CNCLU_SEQ
, REPLACE(REPLACE(CNCLU_DIV_CD,CHR(13),''),CHR(10),'') CNCLU_DIV_CD
, REPLACE(REPLACE(EXMP_DIV_CD,CHR(13),''),CHR(10),'') EXMP_DIV_CD
, CNCLU_DT
, REPLACE(REPLACE(CHRPE_ORG_CD,CHR(13),''),CHR(10),'') CHRPE_ORG_CD
, REPLACE(REPLACE(CHRPE_ORG_NM,CHR(13),''),CHR(10),'') CHRPE_ORG_NM
, REPLACE(REPLACE(CHRPE_PART_ORG_CD,CHR(13),''),CHR(10),'') CHRPE_PART_ORG_CD
, REPLACE(REPLACE(CHRPE_PART_ORG_NM,CHR(13),''),CHR(10),'') CHRPE_PART_ORG_NM
, REPLACE(REPLACE(CHRPE_CEN_ORG_CD,CHR(13),''),CHR(10),'') CHRPE_CEN_ORG_CD
, REPLACE(REPLACE(CHRPE_CEN_ORG_NM,CHR(13),''),CHR(10),'') CHRPE_CEN_ORG_NM
, REPLACE(REPLACE(CLADJ_DAMR_LCTG_CD,CHR(13),''),CHR(10),'') CLADJ_DAMR_LCTG_CD
, REPLACE(REPLACE(CLADJ_DAMR_MCTG_CD,CHR(13),''),CHR(10),'') CLADJ_DAMR_MCTG_CD
, REPLACE(REPLACE(CLADJ_DAMR_SCTG_CD,CHR(13),''),CHR(10),'') CLADJ_DAMR_SCTG_CD
, INSD_AMT
, DCN_INS_AMT
, ACCM_DCN_INS_AMT
, DMG_RDUC_AMT
, CLM_AMT
, REPLACE(REPLACE(DAMR_EVL_STD_CD,CHR(13),''),CHR(10),'') DAMR_EVL_STD_CD
, REPLACE(REPLACE(DMPE_ID,CHR(13),''),CHR(10),'') DMPE_ID
, REPLACE(REPLACE(DMPE_CUS_ID,CHR(13),''),CHR(10),'') DMPE_CUS_ID
, REPLACE(REPLACE(DMPE_NM,CHR(13),''),CHR(10),'') DMPE_NM
, REPLACE(REPLACE(KR_DISZ_CD0,CHR(13),''),CHR(10),'') KR_DISZ_CD0
, RCT_DT
, LAST_RCT_DT
, ACD_DT
, REPLACE(REPLACE(DLG_ETP_NM,CHR(13),''),CHR(10),'') DLG_ETP_NM
, REPLACE(REPLACE(DLG_CON_CD,CHR(13),''),CHR(10),'') DLG_CON_CD
, DLG_DT
, REPLACE(REPLACE(FDIV_CHRPE_ORG_CD,CHR(13),''),CHR(10),'') FDIV_CHRPE_ORG_CD
, REPLACE(REPLACE(FDIV_CHRPE_ORG_NM,CHR(13),''),CHR(10),'') FDIV_CHRPE_ORG_NM
, REPLACE(REPLACE(FDIV_CHRPE_PART_ORG_CD,CHR(13),''),CHR(10),'') FDIV_CHRPE_PART_ORG_CD
, REPLACE(REPLACE(FDIV_CHRPE_PART_ORG_NM,CHR(13),''),CHR(10),'') FDIV_CHRPE_PART_ORG_NM
, REPLACE(REPLACE(FDIV_CHRPE_CEN_ORG_CD,CHR(13),''),CHR(10),'') FDIV_CHRPE_CEN_ORG_CD
, REPLACE(REPLACE(FDIV_CHRPE_CEN_ORG_NM,CHR(13),''),CHR(10),'') FDIV_CHRPE_CEN_ORG_NM
, DIVD_SCRG_SCR
, REPLACE(REPLACE(CLUNIT_CD,CHR(13),''),CHR(10),'') CLUNIT_CD
, EIH_LDG_DTM
, TPSSE_INS_AMT
, TPSSE_DCN_DAMT
, LAST_ACD_DT
, REPLACE(REPLACE(CTR_OBJ_ID,CHR(13),''),CHR(10),'') CTR_OBJ_ID
, DCN_EXT_EXP
, ATYPE_DAMR_AMT
, BTYPE_DAMR_AMT
, CTYPE_DAMR_AMT
, DTYPE_DAMR_AMT
, ETYPE_DAMR_AMT
, REPLACE(REPLACE(BASFE_DIV_CD,CHR(13),''),CHR(10),'') BASFE_DIV_CD FROM TMIDS_CLABIZLAST
                       WHERE \$CONDITIONS "\
    --m 8 \
    --boundary-query "SELECT 0, 7 FROM DUAL"\
    --split-by "ORA_HASH(CLM_ID, 7)"\
    --target-dir /tmp2/LAST_TMIDS_CLABIZLAST \
    --hive-import \
    --external-table-dir hdfs:///tmp2/temp_tbl/LAST_TMIDS_CLABIZLAST \
    --hive-overwrite \
    --hive-table DEFAULT.LAST_TMIDS_CLABIZLAST  >> ${SHLOG_DIR}/TMIDS_CLABIZLAST.shlog 2>&1 &&

#----------------------------------------------------#
# Hadoop 원본테이블에 변경분 최종 적용
#----------------------------------------------------#
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.TMIDS_CLABIZLAST_TMP ; " >> ${SHLOG_DIR}/TMIDS_CLABIZLAST.shlog 2>&1 &&
    /usr/bin/hive -e "CREATE EXTERNAL TABLE MERITZ.TMIDS_CLABIZLAST_TMP STORED AS PARQUET TBLPROPERTIES ('PARQUET.COMPRESS'='SNAPPY') AS
                                SELECT *
                                FROM DEFAULT.LAST_TMIDS_CLABIZLAST ;" >> ${SHLOG_DIR}/TMIDS_CLABIZLAST.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.LAST_TMIDS_CLABIZLAST ;" >> ${SHLOG_DIR}/TMIDS_CLABIZLAST.shlog 2>&1 &&
    /usr/bin/hdfs dfs -rm -r -f -skipTrash /tmp2/temp_tbl/LAST_TMIDS_CLABIZLAST >> ${SHLOG_DIR}/TMIDS_CLABIZLAST.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.TMIDS_CLABIZLAST ;" >> ${SHLOG_DIR}/TMIDS_CLABIZLAST.shlog 2>&1 &&
    /usr/bin/hive -e "ALTER TABLE MERITZ.TMIDS_CLABIZLAST_TMP RENAME TO MERITZ.TMIDS_CLABIZLAST ;" >> ${SHLOG_DIR}/TMIDS_CLABIZLAST.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.TMIDS_CLABIZLAST_TMP ;" >> ${SHLOG_DIR}/TMIDS_CLABIZLAST.shlog 2>&1 

if [ $? -ne 0 ]
then             
    echo "*-----------[ TMIDS_CLABIZLAST.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/TMIDS_CLABIZLAST.shlog"
    echo "*-----------[ TMIDS_CLABIZLAST.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/TMIDS_CLABIZLAST.shlog"  >>  ${SHLOG_DIR}/TMIDS_CLABIZLAST.shlog
    echo "*-----------[ TMIDS_CLABIZLAST.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ TMIDS_CLABIZLAST.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/TMIDS_CLABIZLAST.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/TMIDS_CLABIZLAST.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/TMIDS_CLABIZLAST.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/TMIDS_CLABIZLAST.shlog /sqoopbin/scripts/etlpgm/his_log/TMIDS_CLABIZLAST_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  TMIDS_CLABIZLAST.sh cmd command error !! ***
    fi               

    exit -1      

else             
    echo "*-----------[ TMIDS_CLABIZLAST.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ TMIDS_CLABIZLAST.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/TMIDS_CLABIZLAST.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/TMIDS_CLABIZLAST.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/TMIDS_CLABIZLAST.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/TMIDS_CLABIZLAST.shlog /sqoopbin/scripts/etlpgm/his_log/TMIDS_CLABIZLAST_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  TMIDS_CLABIZLAST.sh cmd command error !! ***
        exit -1      
    else             
        exit 0       
    fi               
fi               
