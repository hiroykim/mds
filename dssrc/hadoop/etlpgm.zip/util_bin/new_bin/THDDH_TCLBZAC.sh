#!/bin/bash

if [ $# -eq 0 ]
then           
    ARGS=N    
else           
    ARGS=$1
fi             

NOW=$(date +"+%Y-%m-%d_%T")
SHLOG_DIR=/sqoopbin/scripts/etlpgm/cur_log
HISLOG_DIR=/sqoopbin/scripts/etlpgm/his_log

export HADOOP_OPTS=-Djava.security.egd=file:/dev/../dev/urandom
export ORACLE_BASE=/sw/oracle
export ORACLE_HOME=/sw/oracle/product/11.2.0.4/client_1
export LD_LIBRARY_PATH=/sw/oracle/product/11.2.0.4/client_1/lib:/sw/oracle/product/11.2.0.4/client_1/lib:
export PATH=/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/usr/lib64/qt-3.3/bin:/usr/hdp/3.0.0.0-1634/spark2/bin/:/var/opt/node/bin/:/opt/maven/bin:/usr/local/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/home/hdpapp/workspace/data-science-at-the-command-line/tools:/home/hdpapp/.local/bin:/home/hdpapp/bin
export TNS_ADMIN=/sw/oracle/product/11.2.0.4/client_1/network/admin
export ORACLE_SID=DBEDWP2
export NLS_LANG=American_America.KO16MSWIN949

#----------------------------------------------------#
# 작업내용 : THDDH_TCLBZAC 테이블 sqoop 복제 작업
# 작업주기 :  
#----------------------------------------------------#

    echo " "
    echo "*-----------[ THDDH_TCLBZAC.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TCLBZAC.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`  >  ${SHLOG_DIR}/THDDH_TCLBZAC.shlog

#----------------------------------------------------#
# 테이블별 전체 데이터를 받아 오는 부분
#----------------------------------------------------#
    /usr/bin/hadoop fs -rm -r -f  /tmp2/LAST_THDDH_TCLBZAC  >> ${SHLOG_DIR}/THDDH_TCLBZAC.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.LAST_THDDH_TCLBZAC ; " >> ${SHLOG_DIR}/THDDH_TCLBZAC.shlog 2>&1 &&
    /usr/hdp/3.0.0.0-1634/sqoop/bin/sqoop import -D mapred.child.java.opts="-Djava.security.egd=file:/dev/../dev/urandom" \
    --connect jdbc:oracle:thin:EDWHADOOP/wjdqhrP\!23@10.91.41.172:12560:DBEDWP2 \
    --username  EDWHADOOP \
    --password wjdqhrP\!23 \
    --query "SELECT /*+ FULL(THDDH_TCLBZAC) */ REPLACE(REPLACE(BZAC_ID,CHR(13),''),CHR(10),'') BZAC_ID
, HIS_SEQ
, REPLACE(REPLACE(BZAC_BIZ_DIV_CD,CHR(13),''),CHR(10),'') BZAC_BIZ_DIV_CD
, REPLACE(REPLACE(PTY_DIV_CD,CHR(13),''),CHR(10),'') PTY_DIV_CD
, REPLACE(REPLACE(PTY_ID,CHR(13),''),CHR(10),'') PTY_ID
, REPLACE(REPLACE(BZAC_NM,CHR(13),''),CHR(10),'') BZAC_NM
, REPLACE(REPLACE(RPSPE_BIZ_PTY_ID,CHR(13),''),CHR(10),'') RPSPE_BIZ_PTY_ID
, REPLACE(REPLACE(RPSPE_NM,CHR(13),''),CHR(10),'') RPSPE_NM
, REPLACE(REPLACE(BZAC_DIV_CD,CHR(13),''),CHR(10),'') BZAC_DIV_CD
, REPLACE(REPLACE(WHTX_YN,CHR(13),''),CHR(10),'') WHTX_YN
, REPLACE(REPLACE(DMST_OVSE_DIV_CD,CHR(13),''),CHR(10),'') DMST_OVSE_DIV_CD
, REPLACE(REPLACE(CITY_NATL_CD,CHR(13),''),CHR(10),'') CITY_NATL_CD
, REPLACE(REPLACE(INCP_YY,CHR(13),''),CHR(10),'') INCP_YY
, REPLACE(REPLACE(COMS_HOSP_GRDE_CD,CHR(13),''),CHR(10),'') COMS_HOSP_GRDE_CD
, REPLACE(REPLACE(CLADJ_HOSP_GRDE_CD,CHR(13),''),CHR(10),'') CLADJ_HOSP_GRDE_CD
, REPLACE(REPLACE(MED_INST_ATTR_CD,CHR(13),''),CHR(10),'') MED_INST_ATTR_CD
, REPLACE(REPLACE(RPSHOP_GRDE_CD,CHR(13),''),CHR(10),'') RPSHOP_GRDE_CD
, REPLACE(REPLACE(COP_ETP_YN,CHR(13),''),CHR(10),'') COP_ETP_YN
, REPLACE(REPLACE(GRMB_SVVOB_DIV_CD,CHR(13),''),CHR(10),'') GRMB_SVVOB_DIV_CD
, REPLACE(REPLACE(BZAC_TND_CD,CHR(13),''),CHR(10),'') BZAC_TND_CD
, REPLACE(REPLACE(TRT_VHTP_DIV_CD,CHR(13),''),CHR(10),'') TRT_VHTP_DIV_CD
, REPLACE(REPLACE(COMS_DLG_TPIDS_DIV_CD,CHR(13),''),CHR(10),'') COMS_DLG_TPIDS_DIV_CD
, REPLACE(REPLACE(COMS_DLG_TRSC_DIV_CD,CHR(13),''),CHR(10),'') COMS_DLG_TRSC_DIV_CD
, REPLACE(REPLACE(RCPR_INST_CD,CHR(13),''),CHR(10),'') RCPR_INST_CD
, REPLACE(REPLACE(TRSC_STAT_CD,CHR(13),''),CHR(10),'') TRSC_STAT_CD
, REPLACE(REPLACE(PRM_USE_YN,CHR(13),''),CHR(10),'') PRM_USE_YN
, REPLACE(REPLACE(NUM_PRCTR_YN,CHR(13),''),CHR(10),'') NUM_PRCTR_YN
, OPBZ_DT
, CLBZ_DT
, REPLACE(REPLACE(BZAC_POS_DIV_CD,CHR(13),''),CHR(10),'') BZAC_POS_DIV_CD
, REPLACE(REPLACE(ROAD_ACCEB_DIV_CD,CHR(13),''),CHR(10),'') ROAD_ACCEB_DIV_CD
, REPLACE(REPLACE(BLDG_STRU_DIV_CD,CHR(13),''),CHR(10),'') BLDG_STRU_DIV_CD
, REPLACE(REPLACE(BLDG_SCL_DIV_CD,CHR(13),''),CHR(10),'') BLDG_SCL_DIV_CD
, REPLACE(REPLACE(SCTR_ETP_EN,CHR(13),''),CHR(10),'') SCTR_ETP_EN
, REPLACE(REPLACE(MA_RTCAR_BZAC_ID,CHR(13),''),CHR(10),'') MA_RTCAR_BZAC_ID
, REPLACE(REPLACE(BIZ_NO,CHR(13),''),CHR(10),'') BIZ_NO
, REPLACE(REPLACE(BIZPE_NM,CHR(13),''),CHR(10),'') BIZPE_NM
, REPLACE(REPLACE(DLG_RCIPE_NM,CHR(13),''),CHR(10),'') DLG_RCIPE_NM
, REPLACE(REPLACE(DLG_RCIPE_CTP_CON,CHR(13),''),CHR(10),'') DLG_RCIPE_CTP_CON
, REPLACE(REPLACE(MNG_BCH_CON,CHR(13),''),CHR(10),'') MNG_BCH_CON
, REPLACE(REPLACE(BZAC_INF_CON,CHR(13),''),CHR(10),'') BZAC_INF_CON
, REPLACE(REPLACE(RMAP_CON,CHR(13),''),CHR(10),'') RMAP_CON
, HIS_ST_DTM
, HIS_ED_DTM
, REPLACE(REPLACE(INPPE_ORG_ID,CHR(13),''),CHR(10),'') INPPE_ORG_ID
, SYS_OCC_DTM
, REPLACE(REPLACE(SYS_DEL_DIV_CD,CHR(13),''),CHR(10),'') SYS_DEL_DIV_CD
, REPLACE(REPLACE(OCC_IP,CHR(13),''),CHR(10),'') OCC_IP
, REPLACE(REPLACE(APP_ID,CHR(13),''),CHR(10),'') APP_ID
, DATA_CHNG_DTM
, EIH_LDG_DTM
, REPLACE(REPLACE(HOSP_TP_CD,CHR(13),''),CHR(10),'') HOSP_TP_CD
, REPLACE(REPLACE(CRP_NM,CHR(13),''),CHR(10),'') CRP_NM
, PMSS_SKBD_NUM
, REPLACE(REPLACE(DEL_YN,CHR(13),''),CHR(10),'') DEL_YN
, REPLACE(REPLACE(BCH_NM,CHR(13),''),CHR(10),'') BCH_NM
, REPLACE(REPLACE(UQN_CON,CHR(13),''),CHR(10),'') UQN_CON
, REPLACE(REPLACE(EMGC_MED_INST_DIV_CD,CHR(13),''),CHR(10),'') EMGC_MED_INST_DIV_CD
, REPLACE(REPLACE(SIMPLE_BZAC_YN,CHR(13),''),CHR(10),'') SIMPLE_BZAC_YN FROM THDDH_TCLBZAC
                       WHERE \$CONDITIONS "\
    --m 1 \
    --target-dir /tmp2/LAST_THDDH_TCLBZAC \
    --hive-import \
    --external-table-dir hdfs:///tmp2/temp_tbl/LAST_THDDH_TCLBZAC \
    --hive-overwrite \
    --hive-table DEFAULT.LAST_THDDH_TCLBZAC  >> ${SHLOG_DIR}/THDDH_TCLBZAC.shlog 2>&1 &&

#----------------------------------------------------#
# Hadoop 원본테이블에 변경분 최종 적용
#----------------------------------------------------#
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TCLBZAC_TMP ; " >> ${SHLOG_DIR}/THDDH_TCLBZAC.shlog 2>&1 &&
    /usr/bin/hive -e "CREATE EXTERNAL TABLE MERITZ.THDDH_TCLBZAC_TMP STORED AS PARQUET TBLPROPERTIES ('PARQUET.COMPRESS'='SNAPPY') AS
                                SELECT *
                                FROM DEFAULT.LAST_THDDH_TCLBZAC ;" >> ${SHLOG_DIR}/THDDH_TCLBZAC.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.LAST_THDDH_TCLBZAC ;" >> ${SHLOG_DIR}/THDDH_TCLBZAC.shlog 2>&1 &&
    /usr/bin/hdfs dfs -rm -r -f -skipTrash /tmp2/temp_tbl/LAST_THDDH_TCLBZAC >> ${SHLOG_DIR}/THDDH_TCLBZAC.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TCLBZAC ;" >> ${SHLOG_DIR}/THDDH_TCLBZAC.shlog 2>&1 &&
    /usr/bin/hive -e "ALTER TABLE MERITZ.THDDH_TCLBZAC_TMP RENAME TO MERITZ.THDDH_TCLBZAC ;" >> ${SHLOG_DIR}/THDDH_TCLBZAC.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TCLBZAC_TMP ;" >> ${SHLOG_DIR}/THDDH_TCLBZAC.shlog 2>&1 

if [ $? -ne 0 ]
then             
    echo "*-----------[ THDDH_TCLBZAC.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/THDDH_TCLBZAC.shlog"
    echo "*-----------[ THDDH_TCLBZAC.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/THDDH_TCLBZAC.shlog"  >>  ${SHLOG_DIR}/THDDH_TCLBZAC.shlog
    echo "*-----------[ THDDH_TCLBZAC.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TCLBZAC.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/THDDH_TCLBZAC.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/THDDH_TCLBZAC.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCLBZAC.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCLBZAC.shlog /sqoopbin/scripts/etlpgm/his_log/THDDH_TCLBZAC_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  THDDH_TCLBZAC.sh cmd command error !! ***
    fi               

    exit -1      

else             
    echo "*-----------[ THDDH_TCLBZAC.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TCLBZAC.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/THDDH_TCLBZAC.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/THDDH_TCLBZAC.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCLBZAC.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCLBZAC.shlog /sqoopbin/scripts/etlpgm/his_log/THDDH_TCLBZAC_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  THDDH_TCLBZAC.sh cmd command error !! ***
        exit -1      
    else             
        exit 0       
    fi               
fi               
