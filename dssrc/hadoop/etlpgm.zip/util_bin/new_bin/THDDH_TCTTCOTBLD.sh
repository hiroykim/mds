#!/bin/bash

if [ $# -eq 0 ]
then           
    ARGS=N    
else           
    ARGS=$1
fi             

NOW=$(date +"+%Y-%m-%d_%T")
SHLOG_DIR=/sqoopbin/scripts/etlpgm/cur_log
HISLOG_DIR=/sqoopbin/scripts/etlpgm/his_log

export HADOOP_OPTS=-Djava.security.egd=file:/dev/../dev/urandom
export ORACLE_BASE=/sw/oracle
export ORACLE_HOME=/sw/oracle/product/11.2.0.4/client_1
export LD_LIBRARY_PATH=/sw/oracle/product/11.2.0.4/client_1/lib:/sw/oracle/product/11.2.0.4/client_1/lib:
export PATH=/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/usr/lib64/qt-3.3/bin:/usr/hdp/3.0.0.0-1634/spark2/bin/:/var/opt/node/bin/:/opt/maven/bin:/usr/local/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/home/hdpapp/workspace/data-science-at-the-command-line/tools:/home/hdpapp/.local/bin:/home/hdpapp/bin
export TNS_ADMIN=/sw/oracle/product/11.2.0.4/client_1/network/admin
export ORACLE_SID=DBEDWP2
export NLS_LANG=American_America.KO16MSWIN949

#----------------------------------------------------#
# 작업내용 : THDDH_TCTTCOTBLD 테이블 sqoop 복제 작업
# 작업주기 :  
#----------------------------------------------------#

    echo " "
    echo "*-----------[ THDDH_TCTTCOTBLD.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TCTTCOTBLD.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`  >  ${SHLOG_DIR}/THDDH_TCTTCOTBLD.shlog

#----------------------------------------------------#
# 테이블별 전체 데이터를 받아 오는 부분
#----------------------------------------------------#
    /usr/bin/hadoop fs -rm -r -f  /tmp2/LAST_THDDH_TCTTCOTBLD  >> ${SHLOG_DIR}/THDDH_TCTTCOTBLD.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.LAST_THDDH_TCTTCOTBLD ; " >> ${SHLOG_DIR}/THDDH_TCTTCOTBLD.shlog 2>&1 &&
    /usr/hdp/3.0.0.0-1634/sqoop/bin/sqoop import -D mapred.child.java.opts="-Djava.security.egd=file:/dev/../dev/urandom" \
    --connect jdbc:oracle:thin:EDWHADOOP/wjdqhrP\!23@10.91.41.172:12560:DBEDWP2 \
    --username  EDWHADOOP \
    --password wjdqhrP\!23 \
    --query "SELECT /*+ FULL(THDDH_TCTTCOTBLD) */ REPLACE(REPLACE(CTR_OBJ_ID,CHR(13),''),CHR(10),'') CTR_OBJ_ID
, HIS_SEQ
, REPLACE(REPLACE(BIZ_SYS_CD,CHR(13),''),CHR(10),'') BIZ_SYS_CD
, REPLACE(REPLACE(BILD_ACCBK_INHR_NO,CHR(13),''),CHR(10),'') BILD_ACCBK_INHR_NO
, REPLACE(REPLACE(FM_NM,CHR(13),''),CHR(10),'') FM_NM
, REPLACE(REPLACE(BLDG_NM,CHR(13),''),CHR(10),'') BLDG_NM
, BLDG_FLR_NUM
, GND_FLR_NUM
, UNDG_FLR_NUM
, BLDG_HGT
, REPLACE(REPLACE(BF_FLR_INSD_YN,CHR(13),''),CHR(10),'') BF_FLR_INSD_YN
, REPLACE(REPLACE(INSD_GND_FLR_NUM_VAL,CHR(13),''),CHR(10),'') INSD_GND_FLR_NUM_VAL
, REPLACE(REPLACE(INSD_UNDG_FLR_NUM_VAL,CHR(13),''),CHR(10),'') INSD_UNDG_FLR_NUM_VAL
, REPLACE(REPLACE(ARCH_YYMM,CHR(13),''),CHR(10),'') ARCH_YYMM
, REPLACE(REPLACE(BLDG_POLE_STRU_CD,CHR(13),''),CHR(10),'') BLDG_POLE_STRU_CD
, REPLACE(REPLACE(BLDG_ROF_STRU_CD,CHR(13),''),CHR(10),'') BLDG_ROF_STRU_CD
, REPLACE(REPLACE(BLDG_WALL_STRU_CD,CHR(13),''),CHR(10),'') BLDG_WALL_STRU_CD
, REPLACE(REPLACE(BFLR_FRPV_SECTN_YN,CHR(13),''),CHR(10),'') BFLR_FRPV_SECTN_YN
, REPLACE(REPLACE(CMPD_BLDG_YN,CHR(13),''),CHR(10),'') CMPD_BLDG_YN
, REPLACE(REPLACE(DGAT_GRD_CD,CHR(13),''),CHR(10),'') DGAT_GRD_CD
, REPLACE(REPLACE(VLDC_CFNT_BLDG_GRD_CD,CHR(13),''),CHR(10),'') VLDC_CFNT_BLDG_GRD_CD
, REPLACE(REPLACE(VLDC_CFNT_BLDG_DSTN_CD,CHR(13),''),CHR(10),'') VLDC_CFNT_BLDG_DSTN_CD
, ABSE_DD_NUM
, CL1_DGAT_OCP_SQME
, CL2_DGAT_OCP_SQME
, CL3_DGAT_OCP_SQME
, CL4_DGAT_OCP_SQME
, REPLACE(REPLACE(HUS_DIV_CD,CHR(13),''),CHR(10),'') HUS_DIV_CD
, BLDG_SQME
, INSD_SQME
, REPLACE(REPLACE(INN_HOTL_DIV_CD,CHR(13),''),CHR(10),'') INN_HOTL_DIV_CD
, GURM_NUM
, HSHD_NUM
, REPLACE(REPLACE(BLDG_KD_CD,CHR(13),''),CHR(10),'') BLDG_KD_CD
, REPLACE(REPLACE(BLDG_DTLS_CD,CHR(13),''),CHR(10),'') BLDG_DTLS_CD
, ENDR_NO
, RTRO_ENDR_NO
, ENDR_HIS_ST_NO
, ENDR_HIS_ED_NO
, SUMUP_DT
, HIS_ST_DT
, HIS_ED_DT
, REPLACE(REPLACE(INPPE_ORG_ID,CHR(13),''),CHR(10),'') INPPE_ORG_ID
, SYS_OCC_DTM
, REPLACE(REPLACE(SYS_DEL_DIV_CD,CHR(13),''),CHR(10),'') SYS_DEL_DIV_CD
, REPLACE(REPLACE(OCC_IP,CHR(13),''),CHR(10),'') OCC_IP
, REPLACE(REPLACE(APP_ID,CHR(13),''),CHR(10),'') APP_ID
, DATA_CHNG_DTM
, EIH_LDG_DTM
, REPLACE(REPLACE(FRPF_ACKN_DOC_ATC_EN,CHR(13),''),CHR(10),'') FRPF_ACKN_DOC_ATC_EN
, CMPD_BLDG_JGMT_GR_NUM FROM THDDH_TCTTCOTBLD
                       WHERE \$CONDITIONS "\
    --m 1 \
    --target-dir /tmp2/LAST_THDDH_TCTTCOTBLD \
    --hive-import \
    --external-table-dir hdfs:///tmp2/temp_tbl/LAST_THDDH_TCTTCOTBLD \
    --hive-overwrite \
    --hive-table DEFAULT.LAST_THDDH_TCTTCOTBLD  >> ${SHLOG_DIR}/THDDH_TCTTCOTBLD.shlog 2>&1 &&

#----------------------------------------------------#
# Hadoop 원본테이블에 변경분 최종 적용
#----------------------------------------------------#
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TCTTCOTBLD_TMP ; " >> ${SHLOG_DIR}/THDDH_TCTTCOTBLD.shlog 2>&1 &&
    /usr/bin/hive -e "CREATE EXTERNAL TABLE MERITZ.THDDH_TCTTCOTBLD_TMP STORED AS PARQUET TBLPROPERTIES ('PARQUET.COMPRESS'='SNAPPY') AS
                                SELECT *
                                FROM DEFAULT.LAST_THDDH_TCTTCOTBLD ;" >> ${SHLOG_DIR}/THDDH_TCTTCOTBLD.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.LAST_THDDH_TCTTCOTBLD ;" >> ${SHLOG_DIR}/THDDH_TCTTCOTBLD.shlog 2>&1 &&
    /usr/bin/hdfs dfs -rm -r -f -skipTrash /tmp2/temp_tbl/LAST_THDDH_TCTTCOTBLD >> ${SHLOG_DIR}/THDDH_TCTTCOTBLD.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TCTTCOTBLD ;" >> ${SHLOG_DIR}/THDDH_TCTTCOTBLD.shlog 2>&1 &&
    /usr/bin/hive -e "ALTER TABLE MERITZ.THDDH_TCTTCOTBLD_TMP RENAME TO MERITZ.THDDH_TCTTCOTBLD ;" >> ${SHLOG_DIR}/THDDH_TCTTCOTBLD.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TCTTCOTBLD_TMP ;" >> ${SHLOG_DIR}/THDDH_TCTTCOTBLD.shlog 2>&1 

if [ $? -ne 0 ]
then             
    echo "*-----------[ THDDH_TCTTCOTBLD.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/THDDH_TCTTCOTBLD.shlog"
    echo "*-----------[ THDDH_TCTTCOTBLD.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/THDDH_TCTTCOTBLD.shlog"  >>  ${SHLOG_DIR}/THDDH_TCTTCOTBLD.shlog
    echo "*-----------[ THDDH_TCTTCOTBLD.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TCTTCOTBLD.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/THDDH_TCTTCOTBLD.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/THDDH_TCTTCOTBLD.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCTTCOTBLD.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCTTCOTBLD.shlog /sqoopbin/scripts/etlpgm/his_log/THDDH_TCTTCOTBLD_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  THDDH_TCTTCOTBLD.sh cmd command error !! ***
    fi               

    exit -1      

else             
    echo "*-----------[ THDDH_TCTTCOTBLD.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TCTTCOTBLD.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/THDDH_TCTTCOTBLD.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/THDDH_TCTTCOTBLD.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCTTCOTBLD.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCTTCOTBLD.shlog /sqoopbin/scripts/etlpgm/his_log/THDDH_TCTTCOTBLD_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  THDDH_TCTTCOTBLD.sh cmd command error !! ***
        exit -1      
    else             
        exit 0       
    fi               
fi               
