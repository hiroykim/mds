#!/bin/bash

if [ $# -eq 0 ]
then           
    ARGS=N    
else           
    ARGS=$1
fi             

NOW=$(date +"+%Y-%m-%d_%T")
SHLOG_DIR=/sqoopbin/scripts/etlpgm/cur_log
HISLOG_DIR=/sqoopbin/scripts/etlpgm/his_log

export HADOOP_OPTS=-Djava.security.egd=file:/dev/../dev/urandom
export ORACLE_BASE=/sw/oracle
export ORACLE_HOME=/sw/oracle/product/11.2.0.4/client_1
export LD_LIBRARY_PATH=/sw/oracle/product/11.2.0.4/client_1/lib:/sw/oracle/product/11.2.0.4/client_1/lib:
export PATH=/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/usr/lib64/qt-3.3/bin:/usr/hdp/3.0.0.0-1634/spark2/bin/:/var/opt/node/bin/:/opt/maven/bin:/usr/local/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/home/hdpapp/workspace/data-science-at-the-command-line/tools:/home/hdpapp/.local/bin:/home/hdpapp/bin
export TNS_ADMIN=/sw/oracle/product/11.2.0.4/client_1/network/admin
export ORACLE_SID=DBEDWP2
export NLS_LANG=American_America.KO16MSWIN949

#----------------------------------------------------#
# 작업내용 : THDDH_TCLACDCTR 테이블 sqoop 복제 작업
# 작업주기 :  
#----------------------------------------------------#

    echo " "
    echo "*-----------[ THDDH_TCLACDCTR.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TCLACDCTR.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`  >  ${SHLOG_DIR}/THDDH_TCLACDCTR.shlog

#----------------------------------------------------#
# 테이블별 전체 데이터를 받아 오는 부분
#----------------------------------------------------#
    /usr/bin/hadoop fs -rm -r -f  /tmp2/LAST_THDDH_TCLACDCTR  >> ${SHLOG_DIR}/THDDH_TCLACDCTR.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.LAST_THDDH_TCLACDCTR ; " >> ${SHLOG_DIR}/THDDH_TCLACDCTR.shlog 2>&1 &&
    /usr/hdp/3.0.0.0-1634/sqoop/bin/sqoop import -D mapred.child.java.opts="-Djava.security.egd=file:/dev/../dev/urandom" \
    --connect jdbc:oracle:thin:EDWHADOOP/wjdqhrP\!23@10.91.41.172:12560:DBEDWP2 \
    --username  EDWHADOOP \
    --password wjdqhrP\!23 \
    --query "SELECT /*+ FULL(THDDH_TCLACDCTR) */ REPLACE(REPLACE(ACD_CTR_ID,CHR(13),''),CHR(10),'') ACD_CTR_ID
, HIS_SEQ
, REPLACE(REPLACE(COMS_BIZ_DIV_CD,CHR(13),''),CHR(10),'') COMS_BIZ_DIV_CD
, REPLACE(REPLACE(ACD_RCT_ID,CHR(13),''),CHR(10),'') ACD_RCT_ID
, REPLACE(REPLACE(CTR_ID,CHR(13),''),CHR(10),'') CTR_ID
, REPLACE(REPLACE(POL_NO,CHR(13),''),CHR(10),'') POL_NO
, REPLACE(REPLACE(PD_CD,CHR(13),''),CHR(10),'') PD_CD
, REPLACE(REPLACE(PD_NM,CHR(13),''),CHR(10),'') PD_NM
, REPLACE(REPLACE(UNT_PD_CD,CHR(13),''),CHR(10),'') UNT_PD_CD
, REPLACE(REPLACE(UNT_PD_NM,CHR(13),''),CHR(10),'') UNT_PD_NM
, REPLACE(REPLACE(INS_ITMS_DIV_CD,CHR(13),''),CHR(10),'') INS_ITMS_DIV_CD
, REPLACE(REPLACE(BZPLN_PD_CTG_CD,CHR(13),''),CHR(10),'') BZPLN_PD_CTG_CD
, REPLACE(REPLACE(PREBL_MNG_PD_CTG_CD,CHR(13),''),CHR(10),'') PREBL_MNG_PD_CTG_CD
, INS_BGN_DT
, INS_ED_DT
, REPLACE(REPLACE(INS_BGN_TM,CHR(13),''),CHR(10),'') INS_BGN_TM
, REPLACE(REPLACE(INS_ED_TM,CHR(13),''),CHR(10),'') INS_ED_TM
, REPLACE(REPLACE(MRIN_PD_DIV_CD,CHR(13),''),CHR(10),'') MRIN_PD_DIV_CD
, ENDR_NO
, RTRO_ENDR_NO
, ENDR_HIS_STD_NO
, REPLACE(REPLACE(CTR_CUS_ID,CHR(13),''),CHR(10),'') CTR_CUS_ID
, REPLACE(REPLACE(POLHD_NM,CHR(13),''),CHR(10),'') POLHD_NM
, REPLACE(REPLACE(CTR_STAT_CD,CHR(13),''),CHR(10),'') CTR_STAT_CD
, REPLACE(REPLACE(CTR_STAT_DTL_CD,CHR(13),''),CHR(10),'') CTR_STAT_DTL_CD
, REPLACE(REPLACE(CRBD_NO,CHR(13),''),CHR(10),'') CRBD_NO
, REPLACE(REPLACE(VEHC_NO,CHR(13),''),CHR(10),'') VEHC_NO
, REPLACE(REPLACE(RPSB_POL_NO,CHR(13),''),CHR(10),'') RPSB_POL_NO
, REPLACE(REPLACE(RPSB_PD_CD,CHR(13),''),CHR(10),'') RPSB_PD_CD
, RPSB_INS_BGN_DT
, RPSB_INS_ED_DT
, REPLACE(REPLACE(RPSB_CTR_INSCO_CD,CHR(13),''),CHR(10),'') RPSB_CTR_INSCO_CD
, SBCP_DT
, REPLACE(REPLACE(MA_INSPE_CUS_ID,CHR(13),''),CHR(10),'') MA_INSPE_CUS_ID
, REPLACE(REPLACE(MA_INSPE_NM,CHR(13),''),CHR(10),'') MA_INSPE_NM
, REPLACE(REPLACE(JNT_TNG_YN,CHR(13),''),CHR(10),'') JNT_TNG_YN
, REPLACE(REPLACE(ACP_SH_DIV_CD,CHR(13),''),CHR(10),'') ACP_SH_DIV_CD
, REPLACE(REPLACE(LDCO_CTR_BZAC_CD,CHR(13),''),CHR(10),'') LDCO_CTR_BZAC_CD
, REPLACE(REPLACE(BNCA_AFLCO_CD,CHR(13),''),CHR(10),'') BNCA_AFLCO_CD
, REPLACE(REPLACE(CTR_ADD_DIV_CD,CHR(13),''),CHR(10),'') CTR_ADD_DIV_CD
, REPLACE(REPLACE(PLR_STUP_YN,CHR(13),''),CHR(10),'') PLR_STUP_YN
, REPLACE(REPLACE(STPT_CITY_NATL_CD,CHR(13),''),CHR(10),'') STPT_CITY_NATL_CD
, REPLACE(REPLACE(ARPT_CITY_NATL_CD,CHR(13),''),CHR(10),'') ARPT_CITY_NATL_CD
, HIS_ST_DTM
, HIS_ED_DTM
, REPLACE(REPLACE(INPPE_ORG_ID,CHR(13),''),CHR(10),'') INPPE_ORG_ID
, SYS_OCC_DTM
, REPLACE(REPLACE(SYS_DEL_DIV_CD,CHR(13),''),CHR(10),'') SYS_DEL_DIV_CD
, REPLACE(REPLACE(OCC_IP,CHR(13),''),CHR(10),'') OCC_IP
, REPLACE(REPLACE(APP_ID,CHR(13),''),CHR(10),'') APP_ID
, DATA_CHNG_DTM
, REPLACE(REPLACE(SYTH_INS_SBC_YN,CHR(13),''),CHR(10),'') SYTH_INS_SBC_YN
, REPLACE(REPLACE(GRUP_DIV_CD,CHR(13),''),CHR(10),'') GRUP_DIV_CD
, REPLACE(REPLACE(IVS_CTR_YN,CHR(13),''),CHR(10),'') IVS_CTR_YN
, EIH_LDG_DTM
, REPLACE(REPLACE(LET_SND_YN,CHR(13),''),CHR(10),'') LET_SND_YN
, REPLACE(REPLACE(ORIG_RTRC_DIV_CD,CHR(13),''),CHR(10),'') ORIG_RTRC_DIV_CD
, REPLACE(REPLACE(PET_INS_YN,CHR(13),''),CHR(10),'') PET_INS_YN FROM THDDH_TCLACDCTR
                       WHERE \$CONDITIONS "\
    --m 8 \
    --boundary-query "SELECT 0, 7 FROM DUAL"\
    --split-by "ORA_HASH(ACD_CTR_ID, 7)"\
    --target-dir /tmp2/LAST_THDDH_TCLACDCTR \
    --hive-import \
    --external-table-dir hdfs:///tmp2/temp_tbl/LAST_THDDH_TCLACDCTR \
    --hive-overwrite \
    --hive-table DEFAULT.LAST_THDDH_TCLACDCTR  >> ${SHLOG_DIR}/THDDH_TCLACDCTR.shlog 2>&1 &&

#----------------------------------------------------#
# Hadoop 원본테이블에 변경분 최종 적용
#----------------------------------------------------#
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TCLACDCTR_TMP ; " >> ${SHLOG_DIR}/THDDH_TCLACDCTR.shlog 2>&1 &&
    /usr/bin/hive -e "CREATE EXTERNAL TABLE MERITZ.THDDH_TCLACDCTR_TMP STORED AS PARQUET TBLPROPERTIES ('PARQUET.COMPRESS'='SNAPPY') AS
                                SELECT *
                                FROM DEFAULT.LAST_THDDH_TCLACDCTR ;" >> ${SHLOG_DIR}/THDDH_TCLACDCTR.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.LAST_THDDH_TCLACDCTR ;" >> ${SHLOG_DIR}/THDDH_TCLACDCTR.shlog 2>&1 &&
    /usr/bin/hdfs dfs -rm -r -f -skipTrash /tmp2/temp_tbl/LAST_THDDH_TCLACDCTR >> ${SHLOG_DIR}/THDDH_TCLACDCTR.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TCLACDCTR ;" >> ${SHLOG_DIR}/THDDH_TCLACDCTR.shlog 2>&1 &&
    /usr/bin/hive -e "ALTER TABLE MERITZ.THDDH_TCLACDCTR_TMP RENAME TO MERITZ.THDDH_TCLACDCTR ;" >> ${SHLOG_DIR}/THDDH_TCLACDCTR.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TCLACDCTR_TMP ;" >> ${SHLOG_DIR}/THDDH_TCLACDCTR.shlog 2>&1 

if [ $? -ne 0 ]
then             
    echo "*-----------[ THDDH_TCLACDCTR.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/THDDH_TCLACDCTR.shlog"
    echo "*-----------[ THDDH_TCLACDCTR.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/THDDH_TCLACDCTR.shlog"  >>  ${SHLOG_DIR}/THDDH_TCLACDCTR.shlog
    echo "*-----------[ THDDH_TCLACDCTR.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TCLACDCTR.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/THDDH_TCLACDCTR.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/THDDH_TCLACDCTR.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCLACDCTR.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCLACDCTR.shlog /sqoopbin/scripts/etlpgm/his_log/THDDH_TCLACDCTR_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  THDDH_TCLACDCTR.sh cmd command error !! ***
    fi               

    exit -1      

else             
    echo "*-----------[ THDDH_TCLACDCTR.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TCLACDCTR.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/THDDH_TCLACDCTR.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/THDDH_TCLACDCTR.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCLACDCTR.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCLACDCTR.shlog /sqoopbin/scripts/etlpgm/his_log/THDDH_TCLACDCTR_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  THDDH_TCLACDCTR.sh cmd command error !! ***
        exit -1      
    else             
        exit 0       
    fi               
fi               
