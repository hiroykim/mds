#!/bin/bash

if [ $# -eq 0 ]
then           
    ARGS=N    
else           
    ARGS=$1
fi             

NOW=$(date +"+%Y-%m-%d_%T")
SHLOG_DIR=/sqoopbin/scripts/etlpgm/cur_log
HISLOG_DIR=/sqoopbin/scripts/etlpgm/his_log

export HADOOP_OPTS=-Djava.security.egd=file:/dev/../dev/urandom
export ORACLE_BASE=/sw/oracle
export ORACLE_HOME=/sw/oracle/product/11.2.0.4/client_1
export LD_LIBRARY_PATH=/sw/oracle/product/11.2.0.4/client_1/lib:/sw/oracle/product/11.2.0.4/client_1/lib:
export PATH=/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/usr/lib64/qt-3.3/bin:/usr/hdp/3.0.0.0-1634/spark2/bin/:/var/opt/node/bin/:/opt/maven/bin:/usr/local/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/home/hdpapp/workspace/data-science-at-the-command-line/tools:/home/hdpapp/.local/bin:/home/hdpapp/bin
export TNS_ADMIN=/sw/oracle/product/11.2.0.4/client_1/network/admin
export ORACLE_SID=DBEDWP2
export NLS_LANG=American_America.KO16MSWIN949

#----------------------------------------------------#
# 작업내용 : TMLDB_ICPSISPQRY 테이블 sqoop 복제 작업
# 작업주기 :  
#----------------------------------------------------#

    echo " "
    echo "*-----------[ TMLDB_ICPSISPQRY.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ TMLDB_ICPSISPQRY.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`  >  ${SHLOG_DIR}/TMLDB_ICPSISPQRY.shlog

#----------------------------------------------------#
# 테이블별 전체 데이터를 받아 오는 부분
#----------------------------------------------------#
    /usr/bin/hadoop fs -rm -r -f  /tmp2/LAST_TMLDB_ICPSISPQRY  >> ${SHLOG_DIR}/TMLDB_ICPSISPQRY.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.LAST_TMLDB_ICPSISPQRY ; " >> ${SHLOG_DIR}/TMLDB_ICPSISPQRY.shlog 2>&1 &&
    /usr/hdp/3.0.0.0-1634/sqoop/bin/sqoop import -D mapred.child.java.opts="-Djava.security.egd=file:/dev/../dev/urandom" \
    --connect jdbc:oracle:thin:EDWHADOOP/wjdqhrP\!23@10.91.41.172:12560:DBEDWP2 \
    --username  EDWHADOOP \
    --password wjdqhrP\!23 \
    --query "SELECT /*+ FULL(TMLDB_ICPSISPQRY) */ REPLACE(REPLACE(STD_YYMM,CHR(13),''),CHR(10),'') STD_YYMM
, REPLACE(REPLACE(POL_NO,CHR(13),''),CHR(10),'') POL_NO
, REPLACE(REPLACE(CUS_NO,CHR(13),''),CHR(10),'') CUS_NO
, INQ_DT
, INQ_MTH_NUM
, REPLACE(REPLACE(CTR_ID,CHR(13),''),CHR(10),'') CTR_ID
, SBCP_DT
, REPLACE(REPLACE(UNT_PD_CD,CHR(13),''),CHR(10),'') UNT_PD_CD
, REPLACE(REPLACE(SBCP_CHN_DIV_CD,CHR(13),''),CHR(10),'') SBCP_CHN_DIV_CD
, REPLACE(REPLACE(CTR_OBJ_ID,CHR(13),''),CHR(10),'') CTR_OBJ_ID
, REPLACE(REPLACE(CUS_ID,CHR(13),''),CHR(10),'') CUS_ID
, INS_AGE
, REPLACE(REPLACE(JOB_CD,CHR(13),''),CHR(10),'') JOB_CD
, REPLACE(REPLACE(JOB_NM,CHR(13),''),CHR(10),'') JOB_NM
, REPLACE(REPLACE(RCRT_BZ_SB_ORG_CD,CHR(13),''),CHR(10),'') RCRT_BZ_SB_ORG_CD
, REPLACE(REPLACE(RCRT_BZ_SB_ORG_NM,CHR(13),''),CHR(10),'') RCRT_BZ_SB_ORG_NM
, REPLACE(REPLACE(RCRT_HDQT_ORG_CD,CHR(13),''),CHR(10),'') RCRT_HDQT_ORG_CD
, REPLACE(REPLACE(RCRT_HDQT_ORG_NM,CHR(13),''),CHR(10),'') RCRT_HDQT_ORG_NM
, REPLACE(REPLACE(RCRT_BRCH_ORG_CD,CHR(13),''),CHR(10),'') RCRT_BRCH_ORG_CD
, REPLACE(REPLACE(RCRT_BRCH_ORG_NM,CHR(13),''),CHR(10),'') RCRT_BRCH_ORG_NM
, REPLACE(REPLACE(RCRT_BCH_ORG_CD,CHR(13),''),CHR(10),'') RCRT_BCH_ORG_CD
, REPLACE(REPLACE(RCRT_BCH_ORG_NM,CHR(13),''),CHR(10),'') RCRT_BCH_ORG_NM
, REPLACE(REPLACE(CLLPE_ORG_CD,CHR(13),''),CHR(10),'') CLLPE_ORG_CD
, REPLACE(REPLACE(CLLPE_ORG_ID,CHR(13),''),CHR(10),'') CLLPE_ORG_ID
, REPLACE(REPLACE(CLLPE_ORG_NM,CHR(13),''),CHR(10),'') CLLPE_ORG_NM
, REPLACE(REPLACE(RCRT_AGPLR_ORG_ID,CHR(13),''),CHR(10),'') RCRT_AGPLR_ORG_ID
, REPLACE(REPLACE(RCRT_AGPLR_ORG_CD,CHR(13),''),CHR(10),'') RCRT_AGPLR_ORG_CD
, REPLACE(REPLACE(RCRT_AGPLR_NM,CHR(13),''),CHR(10),'') RCRT_AGPLR_NM
, REPLACE(REPLACE(ISP_NO,CHR(13),''),CHR(10),'') ISP_NO
, REPLACE(REPLACE(PISP_TRG_YN,CHR(13),''),CHR(10),'') PISP_TRG_YN
, ICPS_TRM1
, ICPS_TRM2
, ICPS_TRM3
, ICPS_TRM4
, ICPS_TRM5
, ICPS_TRM6
, ICPS_TRM7
, ICPS_TRM8
, ICPS_TRM9
, ICPS_TRM10
, ICPS_TRM11
, ICPS_TRM12
, ICPS_TRM13
, ICPS_TRM14
, ICPS_TRM15
, ICPS_TRM16
, ICPS_TRM17
, ICPS_TRM18
, ICPS_TRM19
, ICPS_TRM20
, ICPS_TRM21
, ICPS_TRM22
, ICPS_TRM23
, ICPS_TRM24
, ICPS_TRM25
, ICPS_TRM26
, ICPS_TRM27
, ICPS_TRM28
, ICPS_TRM29
, ICPS_TRM30
, ICPS_TRM31
, ICPS_TRM32
, ICPS_TRM33
, ICPS_TRM34
, ICPS_TRM35
, ICPS_TRM36
, ICPS_TRM37
, ICPS_TRM38
, ICPS_TRM39
, ICPS_TRM40
, ICPS_TRM41
, ICPS_TRM42
, ICPS_TRM43
, ICPS_TRM44
, ICPS_TRM45
, ICPS_TRM46
, ICPS_TRM47
, ICPS_TRM48
, ICPS_TRM49
, ICPS_TRM50
, ICPS_TRM51
, ICPS_TRM52
, ICPS_TRM53
, ICPS_TRM54
, ICPS_TRM55
, ICPS_TRM56
, ICPS_TRM57
, ICPS_TRM58
, ICPS_TRM59
, ICPS_TRM60
, ICPS_TRM61
, ICPS_TRM62
, ICPS_TRM63
, ICPS_TRM64
, ICPS_TRM65
, ICPS_TRM66
, ICPS_TRM67
, ICPS_TRM68
, ICPS_TRM69
, ICPS_TRM70
, ICPS_TRM71
, ICPS_TRM72
, ICPS_TRM73
, ICPS_TRM74
, ICPS_TRM75
, ICPS_TRM76
, ICPS_TRM77
, ICPS_TRM78
, ICPS_TRM79
, ICPS_TRM80
, ICPS_TRM81
, ICPS_TRM82
, ICPS_TRM83
, ICPS_TRM84
, ICPS_TRM85
, ICPS_TRM86
, ICPS_TRM87
, ICPS_TRM88
, ICPS_TRM89
, ICPS_TRM90
, ICPS_TRM91
, ICPS_TRM92
, ICPS_TRM93
, ICPS_TRM94
, ICPS_TRM95
, ICPS_TRM96
, ICPS_TRM97
, ICPS_TRM98
, ICPS_TRM99
, ICPS_TRM100
, ICPS_TRM101
, ICPS_TRM102
, ICPS_TRM103
, ICPS_TRM104
, ICPS_TRM105
, ICPS_TRM106
, ICPS_TRM107
, ICPS_TRM108
, ICPS_TRM109
, ICPS_TRM110
, ICPS_TRM111
, ICPS_TRM112
, ICPS_TRM113
, ICPS_TRM114
, ICPS_TRM115
, ICPS_TRM116
, ICPS_TRM117
, ICPS_TRM118
, ICPS_TRM119
, ICPS_TRM120
, ICPS_TRM121
, ICPS_TRM122
, ICPS_TRM123
, ICPS_TRM124
, ICPS_TRM125
, ICPS_TRM126
, ICPS_TRM127
, ICPS_TRM128
, ICPS_TRM129
, ICPS_TRM130
, ICPS_TRM131
, ICPS_TRM132
, ICPS_TRM133
, ICPS_TRM134
, ICPS_TRM135
, ICPS_TRM136
, ICPS_TRM137
, ICPS_TRM138
, ICPS_TRM139
, ICPS_TRM140
, ICPS_TRM141
, ICPS_TRM142
, ICPS_TRM143
, ICPS_TRM144
, ICPS_TRM145
, ICPS_TRM146
, ICPS_TRM147
, ICPS_TRM148
, ICPS_TRM149
, ICPS_TRM150
, ICPS_TRM151
, ICPS_TRM152
, ICPS_TRM153
, ICPS_TRM154
, ICPS_TRM155
, ICPS_TRM156
, ICPS_TRM157
, ICPS_TRM158
, ICPS_TRM159
, ICPS_TRM160
, ICPS_TRM161
, ICPS_TRM162
, ICPS_TRM163
, ICPS_TRM164
, ICPS_TRM165
, ICPS_TRM166
, ICPS_TRM167
, ICPS_TRM168
, ICPS_TRM169
, ICPS_TRM170
, ICPS_TRM171
, ICPS_TRM172
, ICPS_TRM173
, ICPS_TRM174
, ICPS_TRM175
, ICPS_TRM176
, ICPS_TRM177
, ICPS_TRM178
, ICPS_TRM179
, ICPS_TRM180
, ICPS_TRM181
, ICPS_TRM182
, ICPS_TRM183
, ICPS_TRM184
, ICPS_TRM185
, ICPS_TRM186
, ICPS_TRM187
, ICPS_TRM188
, ICPS_TRM189
, ICPS_TRM190
, ICPS_TRM191
, ICPS_TRM192
, ICPS_TRM193
, ICPS_TRM194
, ICPS_TRM195
, ICPS_TRM196
, ICPS_TRM197
, ICPS_TRM198
, REPLACE(REPLACE(ICPS_CHK_TRG_YN,CHR(13),''),CHR(10),'') ICPS_CHK_TRG_YN
, EIH_LDG_DTM FROM TMLDB_ICPSISPQRY
                       WHERE \$CONDITIONS "\
    --m 8 \
    --boundary-query "SELECT 0, 7 FROM DUAL"\
    --split-by "ORA_HASH(POL_NO, 7)"\
    --target-dir /tmp2/LAST_TMLDB_ICPSISPQRY \
    --hive-import \
    --external-table-dir hdfs:///tmp2/temp_tbl/LAST_TMLDB_ICPSISPQRY \
    --hive-overwrite \
    --hive-table DEFAULT.LAST_TMLDB_ICPSISPQRY  >> ${SHLOG_DIR}/TMLDB_ICPSISPQRY.shlog 2>&1 &&

#----------------------------------------------------#
# Hadoop 원본테이블에 변경분 최종 적용
#----------------------------------------------------#
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.TMLDB_ICPSISPQRY_TMP ; " >> ${SHLOG_DIR}/TMLDB_ICPSISPQRY.shlog 2>&1 &&
    /usr/bin/hive -e "CREATE EXTERNAL TABLE MERITZ.TMLDB_ICPSISPQRY_TMP STORED AS PARQUET TBLPROPERTIES ('PARQUET.COMPRESS'='SNAPPY') AS
                                SELECT *
                                FROM DEFAULT.LAST_TMLDB_ICPSISPQRY ;" >> ${SHLOG_DIR}/TMLDB_ICPSISPQRY.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.LAST_TMLDB_ICPSISPQRY ;" >> ${SHLOG_DIR}/TMLDB_ICPSISPQRY.shlog 2>&1 &&
    /usr/bin/hdfs dfs -rm -r -f -skipTrash /tmp2/temp_tbl/LAST_TMLDB_ICPSISPQRY >> ${SHLOG_DIR}/TMLDB_ICPSISPQRY.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.TMLDB_ICPSISPQRY ;" >> ${SHLOG_DIR}/TMLDB_ICPSISPQRY.shlog 2>&1 &&
    /usr/bin/hive -e "ALTER TABLE MERITZ.TMLDB_ICPSISPQRY_TMP RENAME TO MERITZ.TMLDB_ICPSISPQRY ;" >> ${SHLOG_DIR}/TMLDB_ICPSISPQRY.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.TMLDB_ICPSISPQRY_TMP ;" >> ${SHLOG_DIR}/TMLDB_ICPSISPQRY.shlog 2>&1 

if [ $? -ne 0 ]
then             
    echo "*-----------[ TMLDB_ICPSISPQRY.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/TMLDB_ICPSISPQRY.shlog"
    echo "*-----------[ TMLDB_ICPSISPQRY.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/TMLDB_ICPSISPQRY.shlog"  >>  ${SHLOG_DIR}/TMLDB_ICPSISPQRY.shlog
    echo "*-----------[ TMLDB_ICPSISPQRY.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ TMLDB_ICPSISPQRY.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/TMLDB_ICPSISPQRY.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/TMLDB_ICPSISPQRY.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/TMLDB_ICPSISPQRY.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/TMLDB_ICPSISPQRY.shlog /sqoopbin/scripts/etlpgm/his_log/TMLDB_ICPSISPQRY_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  TMLDB_ICPSISPQRY.sh cmd command error !! ***
    fi               

    exit -1      

else             
    echo "*-----------[ TMLDB_ICPSISPQRY.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ TMLDB_ICPSISPQRY.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/TMLDB_ICPSISPQRY.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/TMLDB_ICPSISPQRY.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/TMLDB_ICPSISPQRY.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/TMLDB_ICPSISPQRY.shlog /sqoopbin/scripts/etlpgm/his_log/TMLDB_ICPSISPQRY_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  TMLDB_ICPSISPQRY.sh cmd command error !! ***
        exit -1      
    else             
        exit 0       
    fi               
fi               
