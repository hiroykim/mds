#!/bin/bash

#------------------------------------------------------------------------------#
# sqoop Shell 실행파일 만들기
#------------------------------------------------------------------------------#

if [ $# -eq 0 ]
then
    echo " "
    echo "프로그램 실행에 오류가 있습니다. !!! 다음을 참고하십시요."
    echo "사용법 : sqoop_shellgen.sh 배포프로그램 작업주기 OR sqoop_shellgen.sh 배포프로그램"
    echo "[예] last_sqoop_shellgen.sh THDDH_TCTTCOT D OR last_sqoop_shellgen.sh THDDH_TCTTCOT"
    echo " "
    exit
fi

#------------------------------------------------------------------------------#
# 변수 부문
# Job Frequency 추출주기 : parameter가 1개일 경우 작업주기는 D
#                          parameter가 2개일 경우 2번째 Paramter
# 191227 ykhong
# 작업주기 이제 무의미해 삭제
# parameter 2번은 앞으로 오라클에 패러렐로 붙을 맵퍼 수로 정의함
#------------------------------------------------------------------------------#

PGM_NAME=$1
PGM_NAME_SMALL=`echo $PGM_NAME | tr '[A-Z]' '[a-z]'`

if [ $# -eq 1 ]
then
    MAPPER_CNT=1
elif [ $# -gt 1 ]
then
    MAPPER_CNT=$2
    HASH_MAX=`expr $MAPPER_CNT - 1`
fi

if [ $# -gt 2 ]
then
    CUSTOM_ID_COL=$3
else
    CUSTOM_ID_COL=""
fi

echo "------"
echo "making script for ${PGM_NAME}. using ${MAPPER_CNT} mapper(s)."

#------------------------------------------------------------------------------#
# 경로는 손정현 차장님에게 확인 후 수정해야 함!!
# 향후 확장성을 위해 profile에 변수를 넣어서 할지 아니면 shell gen을 할 때 넣어야 할지 판단 필요!!
# 일단 임의로 shell 쉘 경로를 shell gen 할 때 넣어서 변수 처리 하는 것으로 임시 처리
#------------------------------------------------------------------------------#

#PRSS_FULL=${etlbin}/${PGM_NAME}".sh"
PRSS_FULL="/sqoopbin/scripts/etlpgm/temp_bin/mid_size_bin/"${PGM_NAME}".sh"
SHLOG_DIR=${etllog}
HISLOG_DIR=${hislog}

#------------------------------------------------------------------------------#
# Shell 생성
#------------------------------------------------------------------------------#

echo "#!/bin/bash"                                                                                                                                                > ${PRSS_FULL}
echo ""                                                                                                                                                          >> ${PRSS_FULL}
echo "if [ $""# -eq 0 ]"                                                                                                                                         >> ${PRSS_FULL}
echo "then           "                                                                                                                                           >> ${PRSS_FULL}
echo "    ARGS=N    "                                                                                                                                            >> ${PRSS_FULL}
echo "else           "                                                                                                                                           >> ${PRSS_FULL}
echo "    ARGS=$""1"                                                                                                                                             >> ${PRSS_FULL}
echo "fi             "                                                                                                                                           >> ${PRSS_FULL}
echo ""                                                                                                                                                          >> ${PRSS_FULL}
echo "NOW=$""(date +"'"'"+%Y-%m-%d_%T"'"'")"                                                                                                                     >> ${PRSS_FULL}
echo "SHLOG_DIR=${etllog}"                                                                                                                                       >> ${PRSS_FULL}
echo "HISLOG_DIR=${hislog}"                                                                                                                                      >> ${PRSS_FULL}
echo ""                                                                                                                                                          >> ${PRSS_FULL}
echo "export HADOOP_OPTS=-Djava.security.egd=file:/dev/../dev/urandom"                                                                                           >> ${PRSS_FULL}
echo "export ORACLE_BASE=/sw/oracle"                                                                                                                             >> ${PRSS_FULL}
echo "export ORACLE_HOME=/sw/oracle/product/11.2.0.4/client_1"                                                                                                   >> ${PRSS_FULL}
echo "export LD_LIBRARY_PATH=/sw/oracle/product/11.2.0.4/client_1/lib:$LD_LIBRARY_PATH"                                                                          >> ${PRSS_FULL}
echo "export PATH=/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:$PATH"                                                    >> ${PRSS_FULL}
echo "export TNS_ADMIN=/sw/oracle/product/11.2.0.4/client_1/network/admin"                                                                                       >> ${PRSS_FULL}
echo "export ORACLE_SID=DBEDWP2"                                                                                                                                 >> ${PRSS_FULL}
echo "export NLS_LANG=American_America.KO16MSWIN949"                                                                                                             >> ${PRSS_FULL}

echo ""                                                                                                                                                          >> ${PRSS_FULL}
echo "#----------------------------------------------------#"                                                                                                    >> ${PRSS_FULL}
echo "# 작업내용 : ${PGM_NAME} 테이블 sqoop 복제 작업"                                                                                                           >> ${PRSS_FULL}
echo "# 작업주기 : ${PRSS_FREQ} "                                                                                                                                >> ${PRSS_FULL}
echo "#----------------------------------------------------#"                                                                                                    >> ${PRSS_FULL}
echo ""                                                                                                                                                          >> ${PRSS_FULL}

echo "    echo "'"'" "'"'                                                                                                                                        >> ${PRSS_FULL}
echo "    echo "'"'"*-----------[ ${PGM_NAME}.sh ] [PROCESS_START -->] "'"' '`''date '"'"+%Y-%m-%d %T"'"'`'                                                      >> ${PRSS_FULL}
echo "    echo "'"'"*-----------[ ${PGM_NAME}.sh ] [PROCESS_START -->] "'"' '`''date '"'"+%Y-%m-%d %T"'"'`'          " > " "$""{SHLOG_DIR}/""${PGM_NAME}.shlog"  >> ${PRSS_FULL}
echo ""                                                                                                                                                          >> ${PRSS_FULL}

#------------------------------------------------------------------------------#
# Stage 테이블 삭제(drop) 및 일데이터 변경분을 COPY
# 현재 정보계는 선분이력 테이블일 경우 Legacy에서 D-2일보다 큰 데이터를 가져오게 되어 있음(이유는 D-1일로 할 경우 기간계 COMMIT 시점으로 인하여 데이터 정합성 불일치)
# Hadoop의 경우 D-3일을 해야 할지 의사결정 필요
# 또한 선분이력의 경우 삭제로그(기간계 물리삭제건)을 반영해야 함
# -m, num-mappers : mapper의 수를 결정, 속도에 영향을 미침(손정현 차장님과 협의 필요)
#
# ============ 해야 할일 ==============
# 기존 프로세스 변경
# incremental_table_테이블명 -> 일변경 데이터를 정보계에서 받아옴
# t1_테이블명(view) -> 일변경 데이터 + 기존 hadoop에 저장된 데이터
# t2_테이블명(view) -> t1_테이블의 key값 기준으로 max변경일시 생성
# reconcile_view_테이블명(view) -> t1테이블에서 max변경일시에 해당하는 데이하는 최종 데이터를 생성
# reporting_table_테이블명 -> reconcile_view_테이블명을 parquet로 생성
# 기존테이블명(parquet)으로 저장 -> reconcile_view_테이블을 기존 테이블명으로 rename
#
# 변경 프로세스(문서 내용상 OR파일일 경우에만 가능하다고 되어 있는데 실제 테스트 확인 필요)
# 삭제로그 관련 데이터를 먼저 정보계에서 받아옴 TXLOG_테이블명
# 일변경 데이터를 정보계에서 받아옴 : STG_테이블명
# 기존 데이터를 백업
# 백업데이터에서 삭제로그 데이터 삭제
# 백업데이터에서 일변경 데이터를 key값 기준으로 삭제
# 백업데이터와 일변경 데이터를 union all 할때 parquet로 저장
# 최종 저장된 parquet 테이블을 기존 테이블명으로 rename
#
#
# ============ 추가적으로 구현해야 할 내용 ==============
# 정보계에서 작업이 종료된 이후에 데이터를 어떻게 가져오고 적용할지 고민해야 함
# 일단 파일 이벤트 또는 테이블 이벤트를 통해서 구현할 예정임(파일 이벤트의 경우 VM 경로와 실제 FTP 경로 싱크를 어떻게 맞출지가 관건)
#------------------------------------------------------------------------------#

#------------------------------------------------------------------------------#
# Hadoop 테이블에 변경분 적용
#------------------------------------------------------------------------------#
echo "#----------------------------------------------------#"                                                                                                    >> ${PRSS_FULL}
echo "# Hadoop 원본테이블에 변경분 최종 적용"                                                                                                                    >> ${PRSS_FULL}
echo "#----------------------------------------------------#"                                                                                                    >> ${PRSS_FULL}
echo "    /usr/bin/hive -e "'"'"DROP TABLE IF EXISTS MERITZ.${PGM_NAME}_TMP ; "'"'" >> $""{SHLOG_DIR}/${PGM_NAME}.shlog 2>&""1 "'&&'                             >> ${PRSS_FULL}
echo "    /usr/bin/hive -e "'"'"CREATE EXTERNAL TABLE MERITZ.${PGM_NAME}_TMP STORED AS PARQUET TBLPROPERTIES ('PARQUET.COMPRESS'='SNAPPY') AS
                                SELECT *
                                FROM DEFAULT.LAST_${PGM_NAME} ;"'"'" >> $""{SHLOG_DIR}/${PGM_NAME}.shlog 2>&""1 "'&&'                                            >> ${PRSS_FULL}
echo "    /usr/bin/hive -e "'"'"DROP TABLE IF EXISTS DEFAULT.LAST_${PGM_NAME} ;"'"'" >> $""{SHLOG_DIR}/${PGM_NAME}.shlog 2>&""1 "'&&'                            >> ${PRSS_FULL}
echo "    /usr/bin/hdfs dfs -rm -r -f -skipTrash /warehouse/tablespace/external/hive/last_${PGM_NAME_SMALL}"" >> $""{SHLOG_DIR}/${PGM_NAME}.shlog 2>&""1 "'&&'                            >> ${PRSS_FULL}
echo "    /usr/bin/hive -e "'"'"DROP TABLE IF EXISTS MERITZ.${PGM_NAME} ;"'"'" >> $""{SHLOG_DIR}/${PGM_NAME}.shlog 2>&""1 "'&&'                                  >> ${PRSS_FULL}
echo "    /usr/bin/hive -e "'"'"ALTER TABLE MERITZ.${PGM_NAME}_TMP RENAME TO MERITZ.${PGM_NAME} ;"'"'" >> $""{SHLOG_DIR}/${PGM_NAME}.shlog 2>&""1 "'&&'          >> ${PRSS_FULL}
echo "    /usr/bin/hive -e "'"'"DROP TABLE IF EXISTS MERITZ.${PGM_NAME}_TMP ;"'"'" >> $""{SHLOG_DIR}/${PGM_NAME}.shlog 2>&""1 "                                  >> ${PRSS_FULL}
echo ""                                                                                                                                                          >> ${PRSS_FULL}
echo "if [ $""? -ne 0 ]"                                                                                                                                         >> ${PRSS_FULL}
echo "then             "                                                                                                                                         >> ${PRSS_FULL}
echo "    echo "'"'"*-----------[ ${PGM_NAME}.sh ] [실행 에러 *** -->] Log = ""$""{SHLOG_DIR}/""${PGM_NAME}"".shlog"'"'                                          >> ${PRSS_FULL}
echo "    echo "'"'"*-----------[ ${PGM_NAME}.sh ] [실행 에러 *** -->] Log = ""$""{SHLOG_DIR}/""${PGM_NAME}"".shlog"'"' " >> " "$""{SHLOG_DIR}/""${PGM_NAME}.shlog"   >> ${PRSS_FULL}
echo "    echo "'"'"*-----------[ ${PGM_NAME}.sh ] [실행 에러 *** -->] "'"' '`''date '"'"+%Y-%m-%d %T"'"'`'                                                      >> ${PRSS_FULL}
echo "    echo "'"'"*-----------[ ${PGM_NAME}.sh ] [실행 에러 *** -->] "'"' '`''date '"'"+%Y-%m-%d %T"'"'`'         " >> " "$""{SHLOG_DIR}/""${PGM_NAME}.shlog"  >> ${PRSS_FULL}
echo "    echo "'"'" "'"'                                                                                                                                        >> ${PRSS_FULL}
echo "    echo "'"'" "'"'                                                                                            " >> " "$""{SHLOG_DIR}/""${PGM_NAME}.shlog" >> ${PRSS_FULL}
echo ""                                                                                                                                                          >> ${PRSS_FULL}
echo "    chmod 777 " ${SHLOG_DIR}"/"${PGM_NAME}".shlog"                                                                                                         >> ${PRSS_FULL}
echo "    cp " ${SHLOG_DIR}"/"${PGM_NAME}".shlog" ${HISLOG_DIR}"/"${PGM_NAME}_"$""{NOW}.shlog"                                                                   >> ${PRSS_FULL}
echo ""                                                                                                                                                          >> ${PRSS_FULL}
echo "    if [ $""? -ne 0 ]"                                                                                                                                     >> ${PRSS_FULL}
echo "    then             "                                                                                                                                     >> ${PRSS_FULL}
echo "        echo  **** " ${PGM_NAME}.sh "cmd command error !! ***"                                                                                             >> ${PRSS_FULL}
echo "    fi               "                                                                                                                                     >> ${PRSS_FULL}
echo ""                                                                                                                                                          >> ${PRSS_FULL}
echo "    exit -1      "                                                                                                                                         >> ${PRSS_FULL}
echo ""                                                                                                                                                          >> ${PRSS_FULL}
echo "else             "                                                                                                                                         >> ${PRSS_FULL}
echo "    echo "'"'"*-----------[ ${PGM_NAME}.sh ] [PROCESS_GOOD  -->] "'"' '`''date '"'"+%Y-%m-%d %T"'"'`'                                                      >> ${PRSS_FULL}
echo "    echo "'"'"*-----------[ ${PGM_NAME}.sh ] [PROCESS_GOOD  -->] "'"' '`''date '"'"+%Y-%m-%d %T"'"'`'         " >> " "$""{SHLOG_DIR}/""${PGM_NAME}.shlog"  >> ${PRSS_FULL}
echo "    echo "'"'" "'"'                                                                                                                                        >> ${PRSS_FULL}
echo "    echo "'"'" "'"'                                                                                            " >> " "$""{SHLOG_DIR}/""${PGM_NAME}.shlog" >> ${PRSS_FULL}
echo ""                                                                                                                                                          >> ${PRSS_FULL}
echo "    chmod 777 " ${SHLOG_DIR}"/"${PGM_NAME}".shlog"                                                                                                         >> ${PRSS_FULL}
echo "    cp " ${SHLOG_DIR}"/"${PGM_NAME}".shlog" ${HISLOG_DIR}"/"${PGM_NAME}_"$""{NOW}.shlog"                                                                   >> ${PRSS_FULL}
echo ""                                                                                                                                                          >> ${PRSS_FULL}
echo "    if [ $""? -ne 0 ]"                                                                                                                                     >> ${PRSS_FULL}
echo "    then             "                                                                                                                                     >> ${PRSS_FULL}
echo "        echo  **** " ${PGM_NAME}.sh "cmd command error !! ***"                                                                                             >> ${PRSS_FULL}
echo "        exit -1      "                                                                                                                                     >> ${PRSS_FULL}
echo "    else             "                                                                                                                                     >> ${PRSS_FULL}
echo "        exit 0       "                                                                                                                                     >> ${PRSS_FULL}
echo "    fi               "                                                                                                                                     >> ${PRSS_FULL}
echo "fi               "                                                                                                                                         >> ${PRSS_FULL}

chmod 775  ${PRSS_FULL}

echo "making ${PRSS_FULL} complete successfully."
echo "------"
