#!/bin/bash

NOW=$(date +"+%Y-%m-%d_%T")

cd /sqoopbin/scripts/etlpgm/

tar -cvf /sqoopbin/scripts/etlpgm/bin_bakcup/sqoop_${NOW}.tar bin

cd /sqoopbin/scripts/etlpgm/bin_bakcup

compress sqoop_${NOW}.tar
