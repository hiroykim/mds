#!/bin/bash

#------------------------------------------------------------------------------#
# sqoop Shell 실행파일 만들기
#------------------------------------------------------------------------------#

if [ $# -eq 0 ]
then
    echo " "
    echo "프로그램 실행에 오류가 있습니다. !!! 다음을 참고하십시요."
    echo "사용법 : init_sqoop_shellgen.sh 배포프로그램 작업주기 OR init_sqoop_shellgen.sh 배포프로그램"
    echo "[예] init_sqoop_shellgen.sh THDDH_TCTTCOT D OR init_sqoop_shellgen.sh THDDH_TCTTCOT"
    echo " "
    exit
fi

#------------------------------------------------------------------------------#
# 변수 부문
# Job Frequency 추출주기 : parameter가 1개일 경우 작업주기는 D
#                          parameter가 2개일 경우 2번째 Paramter
#------------------------------------------------------------------------------#

PGM_NAME=$1
typeset -l PGM_NAME_SML=${PGM_NAME}

if [ $# -eq 1 ]
then
    PRSS_FREQ="D"
elif [ $# -gt 1 ]
then
    PRSS_FREQ=$2
fi

PRSS_FULL=/sqoopbin/scripts/etlpgm/init_bin/INIT_${PGM_NAME}".sh"
SHLOG_DIR=${etllog}
HISLOG_DIR=${hislog}

#------------------------------------------------------------------------------#
# Shell 생성
#------------------------------------------------------------------------------#

echo "#!/bin/bash"                                                                                                                                                > ${PRSS_FULL}
echo ""                                                                                                                                                          >> ${PRSS_FULL}
echo "if [ $""# -eq 0 ]"                                                                                                                                         >> ${PRSS_FULL}
echo "then           "                                                                                                                                           >> ${PRSS_FULL}
echo "    ARGS=N    "                                                                                                                                            >> ${PRSS_FULL}
echo "else           "                                                                                                                                           >> ${PRSS_FULL}
echo "    ARGS=$""1"                                                                                                                                             >> ${PRSS_FULL}
echo "fi             "                                                                                                                                           >> ${PRSS_FULL}
echo ""                                                                                                                                                          >> ${PRSS_FULL}
echo "NOW=$""(date +"'"'"+%Y-%m-%d_%T"'"'")"                                                                                                                     >> ${PRSS_FULL}
echo "SHLOG_DIR=${etllog}"                                                                                                                                       >> ${PRSS_FULL}
echo "HISLOG_DIR=${hislog}"                                                                                                                                      >> ${PRSS_FULL}
echo ""                                                                                                                                                          >> ${PRSS_FULL}
echo "export HADOOP_OPTS=-Djava.security.egd=file:/dev/../dev/urandom"                                                                                           >> ${PRSS_FULL}
echo "export ORACLE_BASE=/sw/oracle"                                                                                                                             >> ${PRSS_FULL}
echo "export ORACLE_HOME=/sw/oracle/product/11.2.0.4/client_1"                                                                                                   >> ${PRSS_FULL}
echo "export LD_LIBRARY_PATH=/sw/oracle/product/11.2.0.4/client_1/lib:$LD_LIBRARY_PATH"                                                                          >> ${PRSS_FULL}
echo "export PATH=/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:$PATH"                                                    >> ${PRSS_FULL}
echo "export TNS_ADMIN=/sw/oracle/product/11.2.0.4/client_1/network/admin"                                                                                       >> ${PRSS_FULL}
echo "export ORACLE_SID=DBEDWP2"                                                                                                                                 >> ${PRSS_FULL}
echo "export NLS_LANG=American_America.KO16MSWIN949"                                                                                                             >> ${PRSS_FULL}

echo ""                                                                                                                                                          >> ${PRSS_FULL}
echo "#----------------------------------------------------#"                                                                                                    >> ${PRSS_FULL}
echo "# 작업내용 : ${PGM_NAME} 테이블 sqoop 복제 작업"                                                                                                           >> ${PRSS_FULL}
echo "# 작업주기 : ${PRSS_FREQ} "                                                                                                                                >> ${PRSS_FULL}
echo "#----------------------------------------------------#"                                                                                                    >> ${PRSS_FULL}
echo ""                                                                                                                                                          >> ${PRSS_FULL}

echo "    echo "'"'" "'"'                                                                                                                                        >> ${PRSS_FULL}
echo "    echo "'"'"*-----------[ INIT_${PGM_NAME}.sh ] [PROCESS_START -->] "'"' '`''date '"'"+%Y-%m-%d %T"'"'`'                                                 >> ${PRSS_FULL}
echo "    echo "'"'"*-----------[ INIT_${PGM_NAME}.sh ] [PROCESS_START -->] "'"' '`''date '"'"+%Y-%m-%d %T"'"'`'          " > " "$""{SHLOG_DIR}/""INIT_${PGM_NAME}.shlog"  >> ${PRSS_FULL}
echo ""                                                                                                                                                          >> ${PRSS_FULL}

#------------------------------------------------------------------------------#
# 엔터값 제거 로직 적용 부분
#------------------------------------------------------------------------------#
COL_LIST=`sqlplus -S edwhadoop/\"wjdqhrp\!23\"@EXA_DBEDWP << EOF
set echo off
set head off
set feedback off
set termout off
set linesize 32767
set pagesize 0
SELECT
     CASE WHEN T1.COLUMN_ID = 1 AND T1.DATA_TYPE = 'VARCHAR2' THEN 'REPLACE(REPLACE('||T1.COLUMN_NAME||',CHR(13),''''),CHR(10),'''') '||T1.COLUMN_NAME
            WHEN T1.COLUMN_ID = 1 AND T1.DATA_TYPE <> 'VARCHAR2' THEN T1.COLUMN_NAME
            WHEN T1.DATA_TYPE = 'VARCHAR2' THEN ', REPLACE(REPLACE('||T1.COLUMN_NAME||',CHR(13),''''),CHR(10),'''') '||T1.COLUMN_NAME
          ELSE ', '||T1.COLUMN_NAME
     END COLUMN_NAME
FROM ALL_TAB_COLUMNS T1
WHERE 1 = 1
  AND T1.OWNER IN('HDS_HIS','HDS_MDI')
  AND T1.TABLE_NAME = '${PGM_NAME}'
ORDER BY T1.COLUMN_ID;
exit;
EOF`

#------------------------------------------------------------------------------#
# 테이블별 전체 데이터를 받아 오는 부분
#------------------------------------------------------------------------------#
echo "#----------------------------------------------------#"                                                                                                    >> ${PRSS_FULL}
echo "# 테이블별 전체 데이터를 받아 오는 부분"                                                                                                                   >> ${PRSS_FULL}
echo "#----------------------------------------------------#"                                                                                                    >> ${PRSS_FULL}
echo "    /usr/bin/hadoop fs -rm -r -f  /tmp2/INIT_${PGM_NAME} "" >> $""{SHLOG_DIR}/INIT_${PGM_NAME}.shlog 2>&""1 "'&&'                                          >> ${PRSS_FULL}
echo "    /usr/bin/hive -e "'"'"DROP TABLE IF EXISTS DEFAULT.INIT_${PGM_NAME} ; "'"'" >> $""{SHLOG_DIR}/INIT_${PGM_NAME}.shlog 2>&""1 "'&&'                      >> ${PRSS_FULL}
echo "    /usr/hdp/3.0.0.0-1634/sqoop/bin/sqoop import -D mapred.child.java.opts="'"'"-Djava.security.egd=file:/dev/../dev/urandom"'"'' \'                        >> ${PRSS_FULL}
echo "    --connect jdbc:oracle:thin:EDWHADOOP/wjdqhrP\!23@10.91.41.172:12560:DBEDWP2 "'\'                                                                       >> ${PRSS_FULL}
echo "    --username  EDWHADOOP "'\'                                                                                                                             >> ${PRSS_FULL}
echo "    --password wjdqhrP\!23 "'\'                                                                                                                            >> ${PRSS_FULL}
echo "    --query "'"'"SELECT ${COL_LIST} FROM ${PGM_NAME}
                       WHERE" '\$CONDITIONS' '"''\'                                                                                                              >> ${PRSS_FULL}
echo "    --m 1 "'\'                                                                                                                                             >> ${PRSS_FULL}
echo "    --target-dir /tmp2/INIT_${PGM_NAME} "'\'                                                                                                               >> ${PRSS_FULL}
echo "    --hive-import "'\'                                                                                                                                     >> ${PRSS_FULL}
echo "    --external-table-dir hdfs:///tmp2/temp_tbl/INIT_${PGM_NAME} "'\'                                                                                       >> ${PRSS_FULL}
echo "    --hive-overwrite "'\'                                                                                                                                  >> ${PRSS_FULL}
echo "    --hive-table DEFAULT.INIT_${PGM_NAME} "" >> $""{SHLOG_DIR}/INIT_${PGM_NAME}.shlog 2>&""1 "'&&'                                                         >> ${PRSS_FULL}
echo ""                                                                                                                                                          >> ${PRSS_FULL}

#------------------------------------------------------------------------------#
# Hadoop 테이블에 변경분 적용
#------------------------------------------------------------------------------#
echo "#----------------------------------------------------#"                                                                                                    >> ${PRSS_FULL}
echo "# Hadoop 원본테이블에 변경분 최종 적용"                                                                                                                    >> ${PRSS_FULL}
echo "#----------------------------------------------------#"                                                                                                    >> ${PRSS_FULL}
echo "    /usr/bin/hive -e "'"'"DROP TABLE IF EXISTS MERITZ.${PGM_NAME}_ITMP ; "'"'" >> $""{SHLOG_DIR}/INIT_${PGM_NAME}.shlog 2>&""1 "'&&'                       >> ${PRSS_FULL}
echo "    /usr/bin/hive -e "'"'"CREATE EXTERNAL TABLE MERITZ.${PGM_NAME}_ITMP STORED AS PARQUET TBLPROPERTIES ('PARQUET.COMPRESS'='SNAPPY') AS
                                SELECT *
                                FROM DEFAULT.INIT_${PGM_NAME} ;"'"'" >> $""{SHLOG_DIR}/INIT_${PGM_NAME}.shlog 2>&""1 "'&&'                                       >> ${PRSS_FULL}
echo "    /usr/bin/hive -e "'"'"DROP TABLE IF EXISTS DEFAULT.INIT_${PGM_NAME} ;"'"'" >> $""{SHLOG_DIR}/INIT_${PGM_NAME}.shlog 2>&""1 "'&&'                       >> ${PRSS_FULL}
echo "    /usr/bin/hive -e "'"'"DROP TABLE IF EXISTS MERITZ.${PGM_NAME} ;"'"'" >> $""{SHLOG_DIR}/INIT_${PGM_NAME}.shlog 2>&""1 "'&&'                             >> ${PRSS_FULL}
echo "    /usr/bin/hive -e "'"'"ALTER TABLE MERITZ.${PGM_NAME}_ITMP RENAME TO MERITZ.${PGM_NAME} ;"'"'" >> $""{SHLOG_DIR}/INIT_${PGM_NAME}.shlog 2>&""1 "'&&'    >> ${PRSS_FULL}
echo "# external table 이 alter문 동작 다른 문제로 아래 과정이 필요해짐 "                                                                                        >> ${PRSS_FULL}
echo "    /usr/bin/hive -e "'"'"ALTER TABLE MERITZ.${PGM_NAME} SET LOCATION 'hdfs:///warehouse/tablespace/external/hive/meritz.db/${PGM_NAME_SML}_tmp' ;"'"'" >> $""{SHLOG_DIR}/${PGM_NAME}.shlog 2>&""1 "'&&'  >> ${PRSS_FULL}
echo "    /usr/bin/hdfs dfs -mv /warehouse/tablespace/external/hive/meritz.db/${PGM_NAME_SML}_itmp /warehouse/tablespace/external/hive/meritz.db/${PGM_NAME_SML}_tmp"" >> $""{SHLOG_DIR}/${PGM_NAME}.shlog 2>&""1 "'&&'  >> ${PRSS_FULL}
echo "    /usr/bin/hive -e "'"'"DROP TABLE IF EXISTS MERITZ.${PGM_NAME}_ITMP ;"'"'" >> $""{SHLOG_DIR}/INIT_${PGM_NAME}.shlog 2>&""1 "                            >> ${PRSS_FULL}

echo ""                                                                                                                                                          >> ${PRSS_FULL}
echo "if [ $""? -ne 0 ]"                                                                                                                                         >> ${PRSS_FULL}
echo "then             "                                                                                                                                         >> ${PRSS_FULL}
echo "    echo "'"'"*-----------[ INIT_${PGM_NAME}.sh ] [실행 에러 *** -->] Log = ""$""{SHLOG_DIR}/""INIT_${PGM_NAME}"".shlog"'"'                                >> ${PRSS_FULL}
echo "    echo "'"'"*-----------[ INIT_${PGM_NAME}.sh ] [실행 에러 *** -->] Log = ""$""{SHLOG_DIR}/""INIT_${PGM_NAME}"".shlog"'"' " >> " "$""{SHLOG_DIR}/""INIT_${PGM_NAME}.shlog"   >> ${PRSS_FULL}
echo "    echo "'"'"*-----------[ INIT_${PGM_NAME}.sh ] [실행 에러 *** -->] "'"' '`''date '"'"+%Y-%m-%d %T"'"'`'                                                      >> ${PRSS_FULL}
echo "    echo "'"'"*-----------[ INIT_${PGM_NAME}.sh ] [실행 에러 *** -->] "'"' '`''date '"'"+%Y-%m-%d %T"'"'`'         " >> " "$""{SHLOG_DIR}/""INIT_${PGM_NAME}.shlog"  >> ${PRSS_FULL}
echo "    echo "'"'" "'"'                                                                                                                                        >> ${PRSS_FULL}
echo "    echo "'"'" "'"'                                                                                            " >> " "$""{SHLOG_DIR}/""INIT_${PGM_NAME}.shlog" >> ${PRSS_FULL}
echo ""                                                                                                                                                          >> ${PRSS_FULL}
echo "    chmod 777 " ${SHLOG_DIR}"/"INIT_${PGM_NAME}".shlog"                                                                                                    >> ${PRSS_FULL}
echo "    cp " ${SHLOG_DIR}"/"INIT_${PGM_NAME}".shlog" ${HISLOG_DIR}"/"INIT_${PGM_NAME}_"$""{NOW}.shlog"                                                         >> ${PRSS_FULL}
echo ""                                                                                                                                                          >> ${PRSS_FULL}
echo "    if [ $""? -ne 0 ]"                                                                                                                                     >> ${PRSS_FULL}
echo "    then             "                                                                                                                                     >> ${PRSS_FULL}
echo "        echo  **** " INIT_${PGM_NAME}.sh "cmd command error !! ***"                                                                                        >> ${PRSS_FULL}
echo "    fi               "                                                                                                                                     >> ${PRSS_FULL}
echo ""                                                                                                                                                          >> ${PRSS_FULL}
echo "    exit -1      "                                                                                                                                         >> ${PRSS_FULL}
echo ""                                                                                                                                                          >> ${PRSS_FULL}
echo "else             "                                                                                                                                         >> ${PRSS_FULL}
echo "    echo "'"'"*-----------[ INIT_${PGM_NAME}.sh ] [PROCESS_GOOD  -->] "'"' '`''date '"'"+%Y-%m-%d %T"'"'`'                                                 >> ${PRSS_FULL}
echo "    echo "'"'"*-----------[ INIT_${PGM_NAME}.sh ] [PROCESS_GOOD  -->] "'"' '`''date '"'"+%Y-%m-%d %T"'"'`'         " >> " "$""{SHLOG_DIR}/""INIT_${PGM_NAME}.shlog"  >> ${PRSS_FULL}
echo "    echo "'"'" "'"'                                                                                                                                        >> ${PRSS_FULL}
echo "    echo "'"'" "'"'                                                                                            " >> " "$""{SHLOG_DIR}/""INIT_${PGM_NAME}.shlog" >> ${PRSS_FULL}
echo ""                                                                                                                                                          >> ${PRSS_FULL}
echo "    chmod 777 " ${SHLOG_DIR}"/"INIT_${PGM_NAME}".shlog"                                                                                                    >> ${PRSS_FULL}
echo "    cp " ${SHLOG_DIR}"/"INIT_${PGM_NAME}".shlog" ${HISLOG_DIR}"/"INIT_${PGM_NAME}_"$""{NOW}.shlog"                                                         >> ${PRSS_FULL}
echo ""                                                                                                                                                          >> ${PRSS_FULL}
echo "    if [ $""? -ne 0 ]"                                                                                                                                     >> ${PRSS_FULL}
echo "    then             "                                                                                                                                     >> ${PRSS_FULL}
echo "        echo  **** " INIT_${PGM_NAME}.sh "cmd command error !! ***"                                                                                        >> ${PRSS_FULL}
echo "        exit -1      "                                                                                                                                     >> ${PRSS_FULL}
echo "    else             "                                                                                                                                     >> ${PRSS_FULL}
echo "        exit 0       "                                                                                                                                     >> ${PRSS_FULL}
echo "    fi               "                                                                                                                                     >> ${PRSS_FULL}
echo "fi               "                                                                                                                                         >> ${PRSS_FULL}

chmod 775  ${PRSS_FULL}

echo ""

