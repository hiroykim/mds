#!/bin/bash

find /sqoopbin/scripts/etlpgm/his_log -name "**" -mtime +24 -exec rm -f {} \;
find /sqoopbin/scripts/etlpgm/bin_bakcup -name "**" -mtime +90 -exec rm -f {} \;
