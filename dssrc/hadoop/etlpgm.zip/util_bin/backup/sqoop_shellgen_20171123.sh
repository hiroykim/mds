#!/bin/bash

#------------------------------------------------------------------------------#
# sqoop Shell 실행파일 만들기
#------------------------------------------------------------------------------#

if [ $# -eq 0 ]
then
    echo " "
    echo "프로그램 실행에 오류가 있습니다. !!! 다음을 참고하십시요."
    echo "사용법 : sqoop_shellgen.sh 배포프로그램 작업주기 OR sqoop_shellgen.sh 배포프로그램"
    echo "[예] sqoop_shellgen.sh THDDH_TCTTCOT D OR sqoop_shellgen.sh THDDH_TCTTCOT"
    echo " "
    exit
fi

#------------------------------------------------------------------------------#
# 변수 부문
# Job Frequency 추출주기 : parameter가 1개일 경우 작업주기는 D
#                          parameter가 2개일 경우 2번째 Paramter
#------------------------------------------------------------------------------#

PGM_NAME=$1

if [ $# -eq 1 ]
then
    PRSS_FREQ="D"
elif [ $# -gt 1 ]
then
    PRSS_FREQ=$2
fi

#------------------------------------------------------------------------------#
# 경로는 손정현 차장님에게 확인 후 수정해야 함!!
# 향후 확장성을 위해 profile에 변수를 넣어서 할지 아니면 shell gen을 할 때 넣어야 할지 판단 필요!!
# 일단 임의로 shell 쉘 경로를 shell gen 할 때 넣어서 변수 처리 하는 것으로 임시 처리
#------------------------------------------------------------------------------#

PRSS_FULL=${etlbin}/${PGM_NAME}".sh"
SHLOG_DIR=${etllog}
HISLOG_DIR=${hislog}

#------------------------------------------------------------------------------#
# Shell 생성
#------------------------------------------------------------------------------#

echo "#!/bin/bash"                                                                                                                                                > ${PRSS_FULL}
echo ""                                                                                                                                                          >> ${PRSS_FULL}
echo "if [ $""# -eq 0 ]"                                                                                                                                         >> ${PRSS_FULL}
echo "then           "                                                                                                                                           >> ${PRSS_FULL}
echo "    ARGS=N    "                                                                                                                                            >> ${PRSS_FULL}
echo "else           "                                                                                                                                           >> ${PRSS_FULL}
echo "    ARGS=$""1"                                                                                                                                             >> ${PRSS_FULL}
echo "fi             "                                                                                                                                           >> ${PRSS_FULL}
echo ""                                                                                                                                                          >> ${PRSS_FULL}

echo "NOW=$""(date +"'"'"+%Y-%m-%d_%T"'"'")"                                                                                                                     >> ${PRSS_FULL}
echo "SHLOG_DIR=${etllog}"                                                                                                                                       >> ${PRSS_FULL}
echo "HISLOG_DIR=${hislog}"                                                                                                                                      >> ${PRSS_FULL}
echo ""                                                                                                                                                          >> ${PRSS_FULL}
echo "export HADOOP_OPTS=-Djava.security.egd=file:/dev/../dev/urandom"                                                                                           >> ${PRSS_FULL}

echo ""                                                                                                                                                          >> ${PRSS_FULL}
echo "#----------------------------------------------------#"                                                                                                    >> ${PRSS_FULL}
echo "# 작업내용 : ${PGM_NAME} 테이블 sqoop 복제 작업"                                                                                                           >> ${PRSS_FULL}
echo "# 작업주기 : ${PRSS_FREQ} "                                                                                                                                >> ${PRSS_FULL}
echo "#----------------------------------------------------#"                                                                                                    >> ${PRSS_FULL}
echo ""                                                                                                                                                          >> ${PRSS_FULL}

echo "    echo "'"'" "'"'                                                                                                                                        >> ${PRSS_FULL}
echo "    echo "'"'"*-----------[ ${PGM_NAME}.sh ] [PROCESS_START -->] "'"' '`''date '"'"+%Y-%m-%d %T"'"'`'                                                      >> ${PRSS_FULL}
echo "    echo "'"'"*-----------[ ${PGM_NAME}.sh ] [PROCESS_START -->] "'"' '`''date '"'"+%Y-%m-%d %T"'"'`'          " > " "$""{SHLOG_DIR}/""${PGM_NAME}.shlog"  >> ${PRSS_FULL}
echo ""                                                                                                                                                          >> ${PRSS_FULL}

#------------------------------------------------------------------------------#
# Stage 테이블 삭제(drop) 및 일데이터 변경분을 COPY
# 현재 정보계는 선분이력 테이블일 경우 Legacy에서 D-2일보다 큰 데이터를 가져오게 되어 있음(이유는 D-1일로 할 경우 기간계 COMMIT 시점으로 인하여 데이터 정합성 불일치)
# Hadoop의 경우 D-3일을 해야 할지 의사결정 필요
# 또한 선분이력의 경우 삭제로그(기간계 물리삭제건)을 반영해야 함
# -m, num-mappers : mapper의 수를 결정, 속도에 영향을 미침(손정현 차장님과 협의 필요)
#
# ============ 해야 할일 ==============
# 기존 프로세스 변경
# incremental_table_테이블명 -> 일변경 데이터를 정보계에서 받아옴
# t1_테이블명(view) -> 일변경 데이터 + 기존 hadoop에 저장된 데이터
# t2_테이블명(view) -> t1_테이블의 key값 기준으로 max변경일시 생성
# reconcile_view_테이블명(view) -> t1테이블에서 max변경일시에 해당하는 데이하는 최종 데이터를 생성
# reporting_table_테이블명 -> reconcile_view_테이블명을 parquet로 생성
# 기존테이블명(parquet)으로 저장 -> reconcile_view_테이블을 기존 테이블명으로 rename
#
# 변경 프로세스(문서 내용상 OR파일일 경우에만 가능하다고 되어 있는데 실제 테스트 확인 필요)
# 삭제로그 관련 데이터를 먼저 정보계에서 받아옴 TXLOG_테이블명
# 일변경 데이터를 정보계에서 받아옴 : STG_테이블명
# 기존 데이터를 백업
# 백업데이터에서 삭제로그 데이터 삭제
# 백업데이터에서 일변경 데이터를 key값 기준으로 삭제
# 백업데이터와 일변경 데이터를 union all 할때 parquet로 저장
# 최종 저장된 parquet 테이블을 기존 테이블명으로 rename
#
#
# ============ 추가적으로 구현해야 할 내용 ==============
# 정보계에서 작업이 종료된 이후에 데이터를 어떻게 가져오고 적용할지 고민해야 함
# 일단 파일 이벤트 또는 테이블 이벤트를 통해서 구현할 예정임(파일 이벤트의 경우 VM 경로와 실제 FTP 경로 싱크를 어떻게 맞출지가 관건)
#------------------------------------------------------------------------------#

#------------------------------------------------------------------------------#
# 테이블의 첫번째 컬럼 정보를 받아 오는 부분
#------------------------------------------------------------------------------#
COL_CHECK=`sqlplus -S edwhadoop/\"wjdqhrp\!23\"@EXA_DBEDWP << EOF
set echo off
set head off
set feedback off
set termout off
set linesize 30000
set pagesize 0
SELECT T1.COLUMN_NAME AS COL_CHECK
FROM ALL_IND_COLUMNS T1
    ,ALL_INDEXES T2
WHERE 1 = 1
  AND T1.TABLE_OWNER = T2.OWNER
  AND T1.TABLE_NAME = T2.TABLE_NAME
  AND T1.INDEX_NAME = T2.INDEX_NAME
  AND T2.UNIQUENESS = 'UNIQUE'
  AND T1.COLUMN_POSITION = 1
  AND T1.TABLE_OWNER IN('HDS_HIS','HDS_MDI')
  AND T1.TABLE_NAME = '${PGM_NAME}';
exit;
EOF`

#------------------------------------------------------------------------------#
# 테이블의 UNIQUE KEY 정보를 받아 오는 부분
#------------------------------------------------------------------------------#
IND_COL_LIST=`sqlplus -S EDWHADOOP/\"wjdqhrp\!23\"@EXA_DBEDWP << EOF
set echo off
set head off
set feedback off
set termout off
set lines 30000
set pages 0
SELECT LISTAGG(T1.COLUMN_NAME,',') WITHIN GROUP(ORDER BY T1.COLUMN_POSITION) AS IND_COL_LIST
FROM ALL_IND_COLUMNS T1
    ,ALL_INDEXES T2
WHERE 1 = 1
  AND T1.TABLE_OWNER = T2.OWNER
  AND T1.TABLE_NAME = T2.TABLE_NAME
  AND T1.INDEX_NAME = T2.INDEX_NAME
  AND T2.UNIQUENESS = 'UNIQUE'
  AND T1.TABLE_OWNER IN('HDS_HIS','HDS_MDI')
  AND T1.TABLE_NAME = '${PGM_NAME}';
exit;
EOF`

#------------------------------------------------------------------------------#
# 엔터값 제거 로직 적용 부분
#------------------------------------------------------------------------------#
COL_LIST=`sqlplus -S edwhadoop/\"wjdqhrp\!23\"@EXA_DBEDWP << EOF
set echo off
set head off
set feedback off
set termout off
set linesize 32767
set pagesize 0
SELECT
     CASE WHEN T1.COLUMN_ID = 1 AND T1.DATA_TYPE = 'VARCHAR2' THEN 'REPLACE(REPLACE('||T1.COLUMN_NAME||',CHR(13),''''),CHR(10),'''') '||T1.COLUMN_NAME
            WHEN T1.COLUMN_ID = 1 AND T1.DATA_TYPE <> 'VARCHAR2' THEN T1.COLUMN_NAME
            WHEN T1.DATA_TYPE = 'VARCHAR2' THEN ', REPLACE(REPLACE('||T1.COLUMN_NAME||',CHR(13),''''),CHR(10),'''') '||T1.COLUMN_NAME
          ELSE ', '||T1.COLUMN_NAME
     END COLUMN_NAME
FROM ALL_TAB_COLUMNS T1
WHERE 1 = 1
  AND T1.OWNER IN('HDS_HIS','HDS_MDI')
  AND T1.TABLE_NAME = '${PGM_NAME}'
ORDER BY T1.COLUMN_ID;
exit;
EOF`

#------------------------------------------------------------------------------#
# 테이블의 JOIN 정보를 받아 오는 부분
#------------------------------------------------------------------------------#
JOIN_LIST=`sqlplus -S edwhadoop/\"wjdqhrp\!23\"@EXA_DBEDWP << EOF
set echo off
set head off
set feedback off
set termout off
set linesize 30000
set pagesize 0
SELECT LISTAGG(T1.COLUMN_NAME,' ') WITHIN GROUP(ORDER BY T1.COLUMN_POSITION) AS JOIN_LIST
FROM
    (
        SELECT
             CASE WHEN T1.COLUMN_POSITION = 1 THEN 'T1.'||T1.COLUMN_NAME||' = T2.'||T1.COLUMN_NAME
                  ELSE 'AND T1.'||T1.COLUMN_NAME||' = T2.'||T1.COLUMN_NAME
             END COLUMN_NAME
            ,T1.COLUMN_POSITION
        FROM ALL_IND_COLUMNS T1
            ,ALL_INDEXES T2
        WHERE 1 = 1
          AND T1.TABLE_OWNER = T2.OWNER
          AND T1.TABLE_NAME = T2.TABLE_NAME
          AND T1.INDEX_NAME = T2.INDEX_NAME
          AND T2.UNIQUENESS = 'UNIQUE'
          AND T1.TABLE_OWNER IN('HDS_HIS','HDS_MDI')
          AND T1.TABLE_NAME = '${PGM_NAME}'
    ) T1;
exit;
EOF`

#------------------------------------------------------------------------------#
# 테이블의 삭제로그컬럼 변경 부분
#------------------------------------------------------------------------------#
CONVERT_LIST=`sqlplus -S EDWHADOOP/\"wjdqhrp\!23\"@EXA_DBEDWP << EOF
set echo off
set head off
set feedback off
set termout off
set lines 30000
set pages 0
SELECT LISTAGG(M_BASIC.COVNERT_COLUMN,',') WITHIN GROUP(ORDER BY M_BASIC.COLUMN_POSITION) AS CONVERT_LIST
FROM
    (
        SELECT
             CASE WHEN T3.DATA_TYPE = 'DATE'
                  THEN 'CASE WHEN SUBSTR(KEY_VAL'
                      ||TO_CHAR(T1.COLUMN_POSITION)||',3,1) = ''/'' AND LENGTH(KEY_VAL'
                      ||TO_CHAR(T1.COLUMN_POSITION)||') = 8 THEN CONCAT(''20'',SUBSTR(KEY_VAL'
                      ||TO_CHAR(T1.COLUMN_POSITION)||',1,2),''-'',SUBSTR(KEY_VAL'
                      ||TO_CHAR(T1.COLUMN_POSITION)||',4,2),''-'',SUBSTR(KEY_VAL'
                      ||TO_CHAR(T1.COLUMN_POSITION)||',7,2),'' 00:00:00.0'') WHEN LENGTH(KEY_VAL'
                      ||TO_CHAR(T1.COLUMN_POSITION)||') = 14 THEN CONCAT(SUBSTR(KEY_VAL'
                      ||TO_CHAR(T1.COLUMN_POSITION)||',1,4),''-'',SUBSTR(KEY_VAL'
                      ||TO_CHAR(T1.COLUMN_POSITION)||',5,2),''-'',SUBSTR(KEY_VAL'
                      ||TO_CHAR(T1.COLUMN_POSITION)||',7,2),'' 00:00:00.0'') ELSE CONCAT(SUBSTR(KEY_VAL'
                      ||TO_CHAR(T1.COLUMN_POSITION)||',1,4),''-'',SUBSTR(KEY_VAL'
                      ||TO_CHAR(T1.COLUMN_POSITION)||',5,2),''-'',SUBSTR(KEY_VAL'
                      ||TO_CHAR(T1.COLUMN_POSITION)||',7,2),'' 00:00:00.0'') END AS '||T1.COLUMN_NAME
                  WHEN T3.DATA_TYPE = 'TIMESTAMP'
                  THEN 'CASE WHEN SUBSTR(KEY_VAL'
                      ||TO_CHAR(T1.COLUMN_POSITION)||',3,1) = ''/'' AND LENGTH(KEY_VAL'
                      ||TO_CHAR(T1.COLUMN_POSITION)||') = 8 THEN CONCAT(''20'',SUBSTR(KEY_VAL'
                      ||TO_CHAR(T1.COLUMN_POSITION)||',1,2),''-'',SUBSTR(KEY_VAL'
                      ||TO_CHAR(T1.COLUMN_POSITION)||',4,2),''-'',SUBSTR(KEY_VAL'
                      ||TO_CHAR(T1.COLUMN_POSITION)||',7,2),'' 00:00:00.0'') WHEN LENGTH(KEY_VAL'
                      ||TO_CHAR(T1.COLUMN_POSITION)||') = 14 THEN CONCAT(SUBSTR(KEY_VAL'
                      ||TO_CHAR(T1.COLUMN_POSITION)||',1,4),''-'',SUBSTR(KEY_VAL'
                      ||TO_CHAR(T1.COLUMN_POSITION)||',5,2),''-'',SUBSTR(KEY_VAL'
                      ||TO_CHAR(T1.COLUMN_POSITION)||',7,2),'' '',SUBSTR(KEY_VAL'
                      ||TO_CHAR(T1.COLUMN_POSITION)||',9,2),'':'',SUBSTR(KEY_VAL'
                      ||TO_CHAR(T1.COLUMN_POSITION)||',11,2),'':'',SUBSTR(KEY_VAL'
                      ||TO_CHAR(T1.COLUMN_POSITION)||',13,2)) ELSE CONCAT(SUBSTR(KEY_VAL'
                      ||TO_CHAR(T1.COLUMN_POSITION)||',1,4),''-'',SUBSTR(KEY_VAL'
                      ||TO_CHAR(T1.COLUMN_POSITION)||',5,2),''-'',SUBSTR(KEY_VAL'
                      ||TO_CHAR(T1.COLUMN_POSITION)||',7,2),'' 00:00:00.0'') END AS '||T1.COLUMN_NAME
                  WHEN T3.DATA_TYPE = 'NUMBER'
                  THEN 'CAST(KEY_VAL'||TO_CHAR(T1.COLUMN_POSITION)||' AS DOUBLE) AS '||T1.COLUMN_NAME
                  ELSE 'KEY_VAL'||TO_CHAR(T1.COLUMN_POSITION)||' AS '||T1.COLUMN_NAME
             END COVNERT_COLUMN
            ,T1.COLUMN_POSITION
        FROM ALL_IND_COLUMNS T1
            ,ALL_INDEXES T2
            ,ALL_TAB_COLUMNS T3
        WHERE 1 = 1
          AND T1.TABLE_OWNER = T2.OWNER
          AND T1.TABLE_NAME = T2.TABLE_NAME
          AND T1.INDEX_NAME = T2.INDEX_NAME
          AND T1.TABLE_OWNER = T3.OWNER
          AND T1.TABLE_NAME = T3.TABLE_NAME
          AND T1.COLUMN_NAME = T3.COLUMN_NAME
          AND T2.UNIQUENESS = 'UNIQUE'
          AND T1.TABLE_OWNER IN('HDS_HIS','HDS_MDI')
          AND T1.TABLE_NAME = '${PGM_NAME}'
    ) M_BASIC;
exit;
EOF`

#------------------------------------------------------------------------------#
# 테이블별 데이터변경LOG 데이터를 받아 오는 부분
#------------------------------------------------------------------------------#
echo "#----------------------------------------------------#"                                                                                                    >> ${PRSS_FULL}
echo "# 테이블별 데이터변경LOG 데이터를 받아 오는 부분"                                                                                                          >> ${PRSS_FULL}
echo "#----------------------------------------------------#"                                                                                                    >> ${PRSS_FULL}
echo "    /usr/bin/hadoop fs -rm -r -f  /tmp2/TXLOG_${PGM_NAME} "" >> $""{SHLOG_DIR}/${PGM_NAME}.shlog 2>&""1 "'&&'                                              >> ${PRSS_FULL}
echo "    /usr/bin/hive -e "'"'"DROP TABLE IF EXISTS DEFAULT.TXLOG_${PGM_NAME} ; "'"'" >> $""{SHLOG_DIR}/${PGM_NAME}.shlog 2>&""1 "'&&'                          >> ${PRSS_FULL}
echo "    /usr/hdp/2.6.1.0-129/sqoop/bin/sqoop import -D mapred.child.java.opts="'"'"-Djava.security.egd=file:/dev/../dev/urandom"'"'' \'                        >> ${PRSS_FULL}
echo "    --connect jdbc:oracle:thin:EDWHADOOP/wjdqhrP\!23@10.91.41.139:12560:DBEDWP2 "'\'                                                                       >> ${PRSS_FULL}
echo "    --username  EDWHADOOP "'\'                                                                                                                             >> ${PRSS_FULL}
echo "    --password wjdqhrP\!23 "'\'                                                                                                                            >> ${PRSS_FULL}
echo "    --query "'"'"SELECT * FROM THDDH_TCOTXLOG
                       WHERE" '\$CONDITIONS' "
                         AND DATA_CHNG_DTM >= TO_TIMESTAMP(TO_CHAR(CURRENT_DATE -16 ,'YYYYMMDD')||' 00:00:00','YYYYMMDD HH24:MI:SS')
                         AND TBL_NM IN ( UPPER('${PGM_NAME:6}'), LOWER('${PGM_NAME:6}')) "'"'""'\'                                                               >> ${PRSS_FULL}
echo "    --m 1 "'\'                                                                                                                                             >> ${PRSS_FULL}
echo "    --target-dir /tmp2/TXLOG_${PGM_NAME} "'\'                                                                                                              >> ${PRSS_FULL}
echo "    --hive-import "'\'                                                                                                                                     >> ${PRSS_FULL}
echo "    --hive-overwrite "'\'                                                                                                                                  >> ${PRSS_FULL}
echo "    --hive-table DEFAULT.TXLOG_${PGM_NAME} "" >> $""{SHLOG_DIR}/${PGM_NAME}.shlog 2>&""1 "'&&'                                                             >> ${PRSS_FULL}
echo ""                                                                                                                                                          >> ${PRSS_FULL}

#------------------------------------------------------------------------------#
# 테이블별 데이터강제수정LOG 데이터를 받아 오는 부분
#------------------------------------------------------------------------------#
echo "#----------------------------------------------------#"                                                                                                    >> ${PRSS_FULL}
echo "# 테이블별 데이터강제수정LOG 데이터를 받아 오는 부분"                                                                                                      >> ${PRSS_FULL}
echo "#----------------------------------------------------#"                                                                                                    >> ${PRSS_FULL}
echo "    /usr/bin/hadoop fs -rm -r -f  /tmp2/BTXLOG_${PGM_NAME} "" >> $""{SHLOG_DIR}/${PGM_NAME}.shlog 2>&""1 "'&&'                                             >> ${PRSS_FULL}
echo "    /usr/bin/hive -e "'"'"DROP TABLE IF EXISTS DEFAULT.BTXLOG_${PGM_NAME} ; "'"'" >> $""{SHLOG_DIR}/${PGM_NAME}.shlog 2>&""1 "'&&'                         >> ${PRSS_FULL}
echo "    /usr/hdp/2.6.1.0-129/sqoop/bin/sqoop import -D mapred.child.java.opts="'"'"-Djava.security.egd=file:/dev/../dev/urandom"'"'' \'                        >> ${PRSS_FULL}
echo "    --connect jdbc:oracle:thin:EDWHADOOP/wjdqhrP\!23@10.91.41.139:12560:DBEDWP2 "'\'                                                                       >> ${PRSS_FULL}
echo "    --username  EDWHADOOP "'\'                                                                                                                             >> ${PRSS_FULL}
echo "    --password wjdqhrP\!23 "'\'                                                                                                                            >> ${PRSS_FULL}
echo "    --query "'"'"SELECT * FROM THDDH_TCODBTXLOG
                       WHERE" '\$CONDITIONS' "
                         AND DATA_CHNG_DTM >= TO_TIMESTAMP(TO_CHAR(CURRENT_DATE -16 ,'YYYYMMDD')||' 00:00:00','YYYYMMDD HH24:MI:SS')
                         AND TBL_NM IN ( UPPER('${PGM_NAME:6}'), LOWER('${PGM_NAME:6}')) "'"'""'\'                                                               >> ${PRSS_FULL}
echo "    --m 1 "'\'                                                                                                                                             >> ${PRSS_FULL}
echo "    --target-dir /tmp2/BTXLOG_${PGM_NAME} "'\'                                                                                                             >> ${PRSS_FULL}
echo "    --hive-import "'\'                                                                                                                                     >> ${PRSS_FULL}
echo "    --hive-overwrite "'\'                                                                                                                                  >> ${PRSS_FULL}
echo "    --hive-table DEFAULT.BTXLOG_${PGM_NAME} "" >> $""{SHLOG_DIR}/${PGM_NAME}.shlog 2>&""1 "'&&'                                                            >> ${PRSS_FULL}
echo ""                                                                                                                                                          >> ${PRSS_FULL}

#------------------------------------------------------------------------------#
# 테이블별 일변경 데이터를 받아 오는 부분
#------------------------------------------------------------------------------#
echo "#----------------------------------------------------#"                                                                                                    >> ${PRSS_FULL}
echo "# 테이블별 일변경 데이터를 받아 오는 부분"                                                                                                                 >> ${PRSS_FULL}
echo "#----------------------------------------------------#"                                                                                                    >> ${PRSS_FULL}
echo "    /usr/bin/hadoop fs -rm -r -f  /tmp2/STG_${PGM_NAME} ""{SHLOG_DIR}/${PGM_NAME}.shlog 2>&""1 "'&&'                                                       >> ${PRSS_FULL}
echo "    /usr/bin/hive -e "'"'"DROP TABLE IF EXISTS DEFAULT.STG_${PGM_NAME} ; "'"'" >> $""{SHLOG_DIR}/${PGM_NAME}.shlog 2>&""1 "'&&'                            >> ${PRSS_FULL}
echo "    /usr/hdp/2.6.1.0-129/sqoop/bin/sqoop import -D mapred.child.java.opts="'"'"-Djava.security.egd=file:/dev/../dev/urandom"'"'' \'                        >> ${PRSS_FULL}
echo "    --connect jdbc:oracle:thin:EDWHADOOP/wjdqhrP\!23@10.91.41.139:12560:DBEDWP2 "'\'                                                                       >> ${PRSS_FULL}
echo "    --username  EDWHADOOP "'\'                                                                                                                             >> ${PRSS_FULL}
echo "    --password wjdqhrP\!23 "'\'                                                                                                                            >> ${PRSS_FULL}
echo "    --query "'"'"SELECT ${COL_LIST} FROM ${PGM_NAME}
                       WHERE" '\$CONDITIONS' "
                         AND DATA_CHNG_DTM >= TO_TIMESTAMP(TO_CHAR(CURRENT_DATE -16 ,'YYYYMMDD')||' 00:00:00','YYYYMMDD HH24:MI:SS') "'"'""'\'                   >> ${PRSS_FULL}
echo "    --m 1 "'\'                                                                                                                                             >> ${PRSS_FULL}
echo "    --target-dir /tmp2/STG_${PGM_NAME} "'\'                                                                                                                >> ${PRSS_FULL}
echo "    --hive-import "'\'                                                                                                                                     >> ${PRSS_FULL}
echo "    --hive-overwrite "'\'                                                                                                                                  >> ${PRSS_FULL}
echo "    --hive-table DEFAULT.STG_${PGM_NAME} "" >> $""{SHLOG_DIR}/${PGM_NAME}.shlog 2>&""1 "'&&'                                                               >> ${PRSS_FULL}
echo ""                                                                                                                                                          >> ${PRSS_FULL}

#------------------------------------------------------------------------------#
# 이전 테이블에 일변경 데이터 OR 삭제로그 적용
#------------------------------------------------------------------------------#
echo "#----------------------------------------------------#"                                                                                                    >> ${PRSS_FULL}
echo "# 이전 테이블에 일변경 데이터 OR 삭제로그 적용"                                                                                                            >> ${PRSS_FULL}
echo "#----------------------------------------------------#"                                                                                                    >> ${PRSS_FULL}
echo "    /usr/bin/hive -e "'"'"DROP TABLE IF EXISTS DEFAULT.EXCEPT_${PGM_NAME} ; "'"'" >> $""{SHLOG_DIR}/${PGM_NAME}.shlog 2>&""1 "'&&'                         >> ${PRSS_FULL}
echo "    /usr/bin/hive -e "'"'"CREATE TABLE DEFAULT.EXCEPT_${PGM_NAME} AS
                                    SELECT ${IND_COL_LIST} FROM DEFAULT.STG_${PGM_NAME}
                                    UNION ALL
                                    SELECT ${CONVERT_LIST} FROM DEFAULT.TXLOG_${PGM_NAME}
                                    UNION ALL
                                    SELECT ${CONVERT_LIST} FROM DEFAULT.BTXLOG_${PGM_NAME} ;"'"'" >> $""{SHLOG_DIR}/${PGM_NAME}.shlog 2>&""1 "'&&'               >> ${PRSS_FULL}
echo ""                                                                                                                                                          >> ${PRSS_FULL}

#------------------------------------------------------------------------------#
# Hadoop 테이블에 변경분 적용
#------------------------------------------------------------------------------#
echo "#----------------------------------------------------#"                                                                                                    >> ${PRSS_FULL}
echo "# Hadoop 테이블에 변경분 적용"                                                                                                                             >> ${PRSS_FULL}
echo "# RENAME할 테이블 생성(오류 작업시 ROLLBACK)"                                                                                                              >> ${PRSS_FULL}
echo "#----------------------------------------------------#"                                                                                                    >> ${PRSS_FULL}
echo "    /usr/bin/hive -e "'"'"DROP TABLE IF EXISTS DEFAULT.LAST_${PGM_NAME} ; "'"'" >> $""{SHLOG_DIR}/${PGM_NAME}.shlog 2>&""1 "'&&'                           >> ${PRSS_FULL}
echo "    /usr/bin/hive -e "'"'"CREATE TABLE DEFAULT.LAST_${PGM_NAME} STORED AS PARQUET TBLPROPERTIES ('PARQUET.COMPRESS'='SNAPPY') AS
                                    SELECT T1.*
                                    FROM MERITZ.${PGM_NAME} AS T1
                                        LEFT JOIN DEFAULT.EXCEPT_${PGM_NAME} AS T2
                                          ON 1 = 1
                                          AND ${JOIN_LIST}
                                    WHERE 1 = 1
                                      AND T2.${COL_CHECK} IS NULL
                                    UNION ALL
                                    SELECT *
                                    FROM DEFAULT.STG_${PGM_NAME} ;"'"'" >> $""{SHLOG_DIR}/${PGM_NAME}.shlog 2>&""1 "'&&'                                         >> ${PRSS_FULL}
#------------------------------------------------------------------------------#
# Hadoop 원본테이블에 변경분 최종 적용(UNION ALL 일경우 SPARK에서 인식 못함)
#------------------------------------------------------------------------------#
echo "#----------------------------------------------------#"                                                                                                    >> ${PRSS_FULL}
echo "# Hadoop 원본테이블에 변경분 최종 적용"                                                                                                                    >> ${PRSS_FULL}
echo "#----------------------------------------------------#"                                                                                                    >> ${PRSS_FULL}
echo "    /usr/bin/hive -e "'"'"DROP TABLE IF EXISTS MERITZ.${PGM_NAME}_TMP ; "'"'" >> $""{SHLOG_DIR}/${PGM_NAME}.shlog 2>&""1 "'&&'                             >> ${PRSS_FULL}
echo "    /usr/bin/hive -e "'"'"CREATE TABLE MERITZ.${PGM_NAME}_TMP STORED AS PARQUET TBLPROPERTIES ('PARQUET.COMPRESS'='SNAPPY') AS
                                SELECT *
                                FROM DEFAULT.LAST_${PGM_NAME} ;"'"'" >> $""{SHLOG_DIR}/${PGM_NAME}.shlog 2>&""1 "'&&'                                            >> ${PRSS_FULL}
echo "    /usr/bin/hive -e "'"'"DROP TABLE IF EXISTS DEFAULT.LAST_${PGM_NAME} ;"'"'" >> $""{SHLOG_DIR}/${PGM_NAME}.shlog 2>&""1 "'&&'                            >> ${PRSS_FULL}
echo "    /usr/bin/hive -e "'"'"DROP TABLE IF EXISTS MERITZ.${PGM_NAME} ;"'"'" >> $""{SHLOG_DIR}/${PGM_NAME}.shlog 2>&""1 "'&&'                                  >> ${PRSS_FULL}
echo "    /usr/bin/hive -e "'"'"ALTER TABLE MERITZ.${PGM_NAME}_TMP RENAME TO MERITZ.${PGM_NAME} ;"'"'" >> $""{SHLOG_DIR}/${PGM_NAME}.shlog 2>&""1 "'&&'          >> ${PRSS_FULL}
echo "    /usr/bin/hive -e "'"'"DROP TABLE IF EXISTS MERITZ.${PGM_NAME}_TMP ;"'"'" >> $""{SHLOG_DIR}/${PGM_NAME}.shlog 2>&""1 "                                  >> ${PRSS_FULL}
echo ""                                                                                                                                                          >> ${PRSS_FULL}
echo "if [ $""? -ne 0 ]"                                                                                                                                         >> ${PRSS_FULL}
echo "then             "                                                                                                                                         >> ${PRSS_FULL}
echo "    echo "'"'"*-----------[ ${PGM_NAME}.sh ] [실행 에러 *** -->] Log = ""$""{SHLOG_DIR}/""${PGM_NAME}"".shlog"'"'                                          >> ${PRSS_FULL}
echo "    echo "'"'"*-----------[ ${PGM_NAME}.sh ] [실행 에러 *** -->] Log = ""$""{SHLOG_DIR}/""${PGM_NAME}"".shlog"'"' " >> " "$""{SHLOG_DIR}/""${PGM_NAME}.shlog"   >> ${PRSS_FULL}
echo "    echo "'"'"*-----------[ ${PGM_NAME}.sh ] [실행 에러 *** -->] "'"' '`''date '"'"+%Y-%m-%d %T"'"'`'                                                      >> ${PRSS_FULL}
echo "    echo "'"'"*-----------[ ${PGM_NAME}.sh ] [실행 에러 *** -->] "'"' '`''date '"'"+%Y-%m-%d %T"'"'`'         " >> " "$""{SHLOG_DIR}/""${PGM_NAME}.shlog"  >> ${PRSS_FULL}
echo "    echo "'"'" "'"'                                                                                                                                        >> ${PRSS_FULL}
echo "    echo "'"'" "'"'                                                                                            " >> " "$""{SHLOG_DIR}/""${PGM_NAME}.shlog" >> ${PRSS_FULL}
echo ""                                                                                                                                                          >> ${PRSS_FULL}
echo "    chmod 777 " ${SHLOG_DIR}"/"${PGM_NAME}".shlog"                                                                                                         >> ${PRSS_FULL}
echo "    cp " ${SHLOG_DIR}"/"${PGM_NAME}".shlog" ${HISLOG_DIR}"/"${PGM_NAME}_"$""{NOW}.shlog"                                                                   >> ${PRSS_FULL}
echo ""                                                                                                                                                          >> ${PRSS_FULL}
echo "    if [ $""? -ne 0 ]"                                                                                                                                     >> ${PRSS_FULL}
echo "    then             "                                                                                                                                     >> ${PRSS_FULL}
echo "        echo  **** " ${PGM_NAME}.sh "cmd command error !! ***"                                                                                             >> ${PRSS_FULL}
echo "    fi               "                                                                                                                                     >> ${PRSS_FULL}
echo ""                                                                                                                                                          >> ${PRSS_FULL}
echo "    exit -1      "                                                                                                                                         >> ${PRSS_FULL}
echo ""                                                                                                                                                          >> ${PRSS_FULL}
echo "else             "                                                                                                                                         >> ${PRSS_FULL}
echo "    echo "'"'"*-----------[ ${PGM_NAME}.sh ] [PROCESS_GOOD  -->] "'"' '`''date '"'"+%Y-%m-%d %T"'"'`'                                                      >> ${PRSS_FULL}
echo "    echo "'"'"*-----------[ ${PGM_NAME}.sh ] [PROCESS_GOOD  -->] "'"' '`''date '"'"+%Y-%m-%d %T"'"'`'         " >> " "$""{SHLOG_DIR}/""${PGM_NAME}.shlog"  >> ${PRSS_FULL}
echo "    echo "'"'" "'"'                                                                                                                                        >> ${PRSS_FULL}
echo "    echo "'"'" "'"'                                                                                            " >> " "$""{SHLOG_DIR}/""${PGM_NAME}.shlog" >> ${PRSS_FULL}
echo ""                                                                                                                                                          >> ${PRSS_FULL}
echo "    chmod 777 " ${SHLOG_DIR}"/"${PGM_NAME}".shlog"                                                                                                         >> ${PRSS_FULL}
echo "    cp " ${SHLOG_DIR}"/"${PGM_NAME}".shlog" ${HISLOG_DIR}"/"${PGM_NAME}_"$""{NOW}.shlog"                                                                   >> ${PRSS_FULL}
echo ""                                                                                                                                                          >> ${PRSS_FULL}
echo "    if [ $""? -ne 0 ]"                                                                                                                                     >> ${PRSS_FULL}
echo "    then             "                                                                                                                                     >> ${PRSS_FULL}
echo "        echo  **** " ${PGM_NAME}.sh "cmd command error !! ***"                                                                                             >> ${PRSS_FULL}
echo "        exit -1      "                                                                                                                                     >> ${PRSS_FULL}
echo "    else             "                                                                                                                                     >> ${PRSS_FULL}
echo "        exit 0       "                                                                                                                                     >> ${PRSS_FULL}
echo "    fi               "                                                                                                                                     >> ${PRSS_FULL}
echo "fi               "                                                                                                                                         >> ${PRSS_FULL}

chmod 775  ${PRSS_FULL}

echo ""
