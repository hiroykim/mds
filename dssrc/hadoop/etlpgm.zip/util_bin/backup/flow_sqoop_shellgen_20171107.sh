#!/bin/bash

#------------------------------------------------------------------------------#
# sqoop Shell 실행파일 만들기
#------------------------------------------------------------------------------#

if [ $# -eq 0 ]
then
    echo " "
    echo "프로그램 실행에 오류가 있습니다. !!! 다음을 참고하십시요."
    echo "사용법 : flow_sqoop_shellgen.sh FLOW명 FLOW그룹개수" 
    echo "[예] flow_sqoop_shellgen.sh HADOOP_HIS_D_CO_U_01 5"
    echo " "
    exit
fi

FLOW_NAME=$1
GROUP_NUM=$2

#------------------------------------------------------------------------------#
# sqoop Shell 실행파일 만들기
#------------------------------------------------------------------------------#

PRSS_FULL=/sqoopbin/scripts/etlpgm/flow_bin/${FLOW_NAME}".sh"
JOB_FULL=${etlbin}
SPRSS_FULL=/sqoopbin/scripts/etlpgm/flow_bin/${FLOW_NAME}
SHLOG_DIR=${etllog}

#------------------------------------------------------------------------------#
# Shell 생성
#------------------------------------------------------------------------------#

echo "#!/bin/bash"                                                                                                                                                > ${PRSS_FULL}
echo ""                                                                                                                                                          >> ${PRSS_FULL}
echo "#----------------------------------------------------#"                                                                                                    >> ${PRSS_FULL}
echo "# 작업내용 : ${FLOW_NAME} FLOW 그룹개수 : ${GROUP_NUM}"                                                                                                    >> ${PRSS_FULL}
echo "#----------------------------------------------------#"                                                                                                    >> ${PRSS_FULL}
echo ""                                                                                                                                                          >> ${PRSS_FULL}
echo "F_CHECK=1"                                                                                                                                                 >> ${PRSS_FULL}
echo ""                                                                                                                                                          >> ${PRSS_FULL}
echo "#------------------------------------------------------------------------------#"                                                                          >> ${PRSS_FULL}
echo "# Hadoop 연계 그룹작업이 모두 종료했는지 체크"                                                                                                             >> ${PRSS_FULL}
echo "# 해당 그룹의 정보계 작업이 모두 종료 되었는지 체크 함"                                                                                                    >> ${PRSS_FULL}
echo "#------------------------------------------------------------------------------#"                                                                          >> ${PRSS_FULL}
echo ""                                                                                                                                                          >> ${PRSS_FULL}
echo "while [ "'$'"F_CHECK -ne 0 ]"                                                                                                                              >> ${PRSS_FULL}
echo "do"                                                                                                                                                        >> ${PRSS_FULL}
echo "F_CHECK="'`'"sqlplus -S edwhadoop/"'\''"'"wjdqhrp"'\!23\"'"@EXA_DBEDWP << EOF"                                                                             >> ${PRSS_FULL}
echo "set echo off"                                                                                                                                              >> ${PRSS_FULL}
echo "set head off"                                                                                                                                              >> ${PRSS_FULL}
echo "set feedback off"                                                                                                                                          >> ${PRSS_FULL}
echo "set termout off"                                                                                                                                           >> ${PRSS_FULL}
echo "set linesize 30000"                                                                                                                                        >> ${PRSS_FULL}
echo "set pagesize 0"                                                                                                                                            >> ${PRSS_FULL}
echo "SELECT COUNT(*) AS CNT"                                                                                                                                    >> ${PRSS_FULL}
echo "FROM HDS_PUB.TMMDD_IFSISJOBIF IFSISJOBIF"                                                                                                                  >> ${PRSS_FULL}
echo "    ,HDS_MDI.TMMDD_WRKCOMPMST WRKCOMPMST"                                                                                                                  >> ${PRSS_FULL}
echo "WHERE 1 = 1"                                                                                                                                               >> ${PRSS_FULL}
echo "AND IFSISJOBIF.LDG_SYS_DIV_CD = '02'"                                                                                                                      >> ${PRSS_FULL}
echo "AND IFSISJOBIF.WRK_FLW_NM = '${FLOW_NAME}'"                                                                                                                >> ${PRSS_FULL}
echo "AND IFSISJOBIF.WRK_NM = WRKCOMPMST.TBL_NM"                                                                                                                 >> ${PRSS_FULL}
echo "AND WRKCOMPMST.STD_DT = TO_DATE(TO_CHAR(CURRENT_DATE-1,'YYYYMMDD'),'YYYYMMDD')"                                                                            >> ${PRSS_FULL}
echo "AND WRKCOMPMST.DD_WRK_COMP_YN = '2';"                                                                                                                      >> ${PRSS_FULL}
echo "exit;"                                                                                                                                                     >> ${PRSS_FULL}
echo "EOF"'`'                                                                                                                                                    >> ${PRSS_FULL}
echo ""                                                                                                                                                          >> ${PRSS_FULL}
echo "if [ "'$'"F_CHECK -eq 0 ]"                                                                                                                                 >> ${PRSS_FULL}
echo "then"                                                                                                                                                      >> ${PRSS_FULL}
echo "    break"                                                                                                                                                 >> ${PRSS_FULL}
echo "else"                                                                                                                                                      >> ${PRSS_FULL}
echo "    sleep 300"                                                                                                                                             >> ${PRSS_FULL}
echo "fi"                                                                                                                                                        >> ${PRSS_FULL}
echo ""                                                                                                                                                          >> ${PRSS_FULL}
echo "done"                                                                                                                                                      >> ${PRSS_FULL}
echo ""                                                                                                                                                          >> ${PRSS_FULL}

#------------------------------------------------------------------------------#
# FLOW 그룹 순서 및 SUB 그룹 내 순번 체크
# 그룹은 총 Parameter 그룹으로 분리
# 그룹은 총 Parameter 그룹으로 분리의 subshell 생성
#------------------------------------------------------------------------------#
for((c=1; c<=${GROUP_NUM}; c++))
do

JOB_LIST=`sqlplus -S edwhadoop/\"wjdqhrp\!23\"@EXA_DBEDWP << EOF
set echo off
set head off
set feedback off
set termout off
set linesize 32767
set pagesize 0
SELECT T_BASIC.PGM_NAME
FROM 
    (
        SELECT
             '${JOB_FULL}'||'/'||M_BASIC.WRK_NM||'.sh' PGM_NAME
            ,MOD(ROWNUM + ${GROUP_NUM} -1, ${GROUP_NUM}) + 1 GROUP_DIV 
            ,CASE WHEN FLOOR(ROWNUM / ${GROUP_NUM}) = 0 THEN FLOOR(ROWNUM / ${GROUP_NUM}) + 1
                    WHEN MOD(ROWNUM,${GROUP_NUM}) = 0 THEN FLOOR(ROWNUM / ${GROUP_NUM})
                    ELSE FLOOR(ROWNUM /${GROUP_NUM} ) + 1  
             END GROUP_SEQ
        FROM 
            ( 
                SELECT 
                    WRK_NM
                FROM HDS_PUB.TMMDD_IFSISJOBIF IFSISJOBIF
                    ,HDS_PUB.EXA_BATCH_ETL_LOG ETL_LOG
                WHERE 1 = 1
                AND IFSISJOBIF.LDG_SYS_DIV_CD = '02'  
                AND IFSISJOBIF.WRK_FLW_NM = '${FLOW_NAME}'
                AND IFSISJOBIF.WRK_NM||'_E' = ETL_LOG.JOB_NAME
                AND ETL_LOG.EXTRACT_BASE_DATE = TO_CHAR(CURRENT_DATE -1,'YYYYMMDD')
                AND TRIM(ETL_LOG.JOB_NAME) IS NOT NULL
                AND ETL_LOG.LAST_YN = 'Y'
                ORDER BY ETL_LOG.LOAD_CNT DESC 
            ) M_BASIC
    ) T_BASIC
WHERE 1 = 1
  AND T_BASIC.GROUP_DIV = ${c}
ORDER BY T_BASIC.GROUP_DIV, T_BASIC.GROUP_SEQ;
exit;
EOF`

echo "#!/bin/bash"                                                                                                                                                > ${SPRSS_FULL}_S${c}".sh"
echo ""                                                                                                                                                          >> ${SPRSS_FULL}_S${c}".sh"
echo "${JOB_LIST} "                                                                                                                                              >> ${SPRSS_FULL}_S${c}".sh"

echo "${SPRSS_FULL}_S${c}.sh &"                                                                                                                                  >> ${PRSS_FULL}

chmod 775 ${SPRSS_FULL}_S${c}".sh"

done

echo "wait"                                                                                                                                                      >> ${PRSS_FULL}

chmod 775 ${PRSS_FULL}

echo ""                                                                                                                                                          >> ${PRSS_FULL}

