#!/bin/bash

while read line
do
    echo "$line"
    eval "hive -e 'select count(*) as cnt from meritz.${line};'"
done
