#!/bin/bash

#------------------------------------------------------------------------------#
# sqoop Shell 실행파일 만들기
#------------------------------------------------------------------------------#

if [ $# -eq 0 ]
then
    echo " "
    echo "프로그램 실행에 오류가 있습니다. !!! 다음을 참고하십시요."
    echo "사용법 : flow_sqoop_shellgen.sh FLOW명 FLOW그룹개수" 
    echo "[예] flow_sqoop_shellgen.sh HADOOP_HIS_D_CO_U_01 5"
    echo " "
    exit
fi

FLOW_NAME=$1
GROUP_NUM=$2

#------------------------------------------------------------------------------#
# sqoop Shell 실행파일 만들기
#------------------------------------------------------------------------------#

PRSS_FULL=/sqoopbin/scripts/etlpgm/flow_bin/${FLOW_NAME}".sh"
JOB_FULL=${etlbin}
SPRSS_FULL=/sqoopbin/scripts/etlpgm/flow_bin/${FLOW_NAME}
SHLOG_DIR=${etllog}

#------------------------------------------------------------------------------#
# FLOW 그룹 순서 및 SUB 그룹 내 순번 체크
# 그룹은 총 Parameter 그룹으로 분리
# 그룹은 총 Parameter 그룹으로 분리의 subshell 생성
#------------------------------------------------------------------------------#
for((c=1; c<=${GROUP_NUM}; c++))
do

JOB_LIST=`sqlplus -S edwhadoop/\"wjdqhrp\!23\"@EXA_DBEDWP << EOF
set echo off
set head off
set feedback off
set termout off
set linesize 32767
set pagesize 0
SELECT T_BASIC.PGM_NAME
FROM 
    (
        SELECT
             '${JOB_FULL}'||'/'||M_BASIC.WRK_NM||'.sh' PGM_NAME
            ,MOD(ROWNUM + ${GROUP_NUM} -1, ${GROUP_NUM}) + 1 GROUP_DIV 
            ,CASE WHEN FLOOR(ROWNUM / ${GROUP_NUM}) = 0 THEN FLOOR(ROWNUM / ${GROUP_NUM}) + 1
                    WHEN MOD(ROWNUM,${GROUP_NUM}) = 0 THEN FLOOR(ROWNUM / ${GROUP_NUM})
                    ELSE FLOOR(ROWNUM /${GROUP_NUM} ) + 1  
             END GROUP_SEQ
        FROM 
            ( 
                SELECT 
                    WRK_NM
                FROM HDS_PUB.TMMDD_IFSISJOBIF IFSISJOBIF
                WHERE 1 = 1
                  AND IFSISJOBIF.LDG_SYS_DIV_CD = '02'  
                  AND IFSISJOBIF.WRK_FLW_NM = '${FLOW_NAME}'
                ORDER BY 
                    WRK_NM
            ) M_BASIC    
    ) T_BASIC
WHERE 1 = 1
  AND T_BASIC.GROUP_DIV = ${c}
ORDER BY T_BASIC.GROUP_DIV, T_BASIC.GROUP_SEQ;
exit;
EOF`

echo "#!/bin/bash"                                                                                                                                                > ${SPRSS_FULL}_S${c}".sh"
echo ""                                                                                                                                                          >> ${SPRSS_FULL}_S${c}".sh"
echo "${JOB_LIST} "                                                                                                                                              >> ${SPRSS_FULL}_S${c}".sh"

chmod 775 ${SPRSS_FULL}_S${c}".sh"

done
