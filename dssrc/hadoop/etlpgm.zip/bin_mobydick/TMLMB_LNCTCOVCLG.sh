#!/bin/bash

if [ $# -eq 0 ]
then           
    ARGS=N    
else           
    ARGS=$1
fi             

NOW=$(date +"+%Y-%m-%d_%T")
SHLOG_DIR=/sqoopbin/scripts/etlpgm/cur_log
HISLOG_DIR=/sqoopbin/scripts/etlpgm/his_log

export HADOOP_OPTS=-Djava.security.egd=file:/dev/../dev/urandom
export ORACLE_BASE=/sw/oracle
export ORACLE_HOME=/sw/oracle/product/11.2.0.4/client_1
export LD_LIBRARY_PATH=/sw/oracle/product/11.2.0.4/client_1/lib:/sw/oracle/product/11.2.0.4/client_1/lib:
export PATH=/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/usr/lib64/qt-3.3/bin:/usr/hdp/3.0.0.0-1634/spark2/bin/:/var/opt/node/bin/:/opt/maven/bin:/usr/local/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/home/hdpapp/workspace/data-science-at-the-command-line/tools:/home/hdpapp/.local/bin:/home/hdpapp/bin
export TNS_ADMIN=/sw/oracle/product/11.2.0.4/client_1/network/admin
export ORACLE_SID=DBEDWP2
export NLS_LANG=American_America.KO16MSWIN949

#----------------------------------------------------#
# 작업내용 : TMLMB_LNCTCOVCLG 테이블 sqoop 복제 작업
# 작업주기 :  
#----------------------------------------------------#

    echo " "
    echo "*-----------[ TMLMB_LNCTCOVCLG.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ TMLMB_LNCTCOVCLG.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`  >  ${SHLOG_DIR}/TMLMB_LNCTCOVCLG.shlog

PART=`date -d "-1 month" '+%Y%m'`

#----------------------------------------------------#
# 테이블별 전체 데이터를 받아 오는 부분
#----------------------------------------------------#
    /usr/bin/hadoop fs -rm -r -f  /tmp2/STG_TMLMB_LNCTCOVCLG  >> ${SHLOG_DIR}/TMLMB_LNCTCOVCLG.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.STG_TMLMB_LNCTCOVCLG ; " >> ${SHLOG_DIR}/TMLMB_LNCTCOVCLG.shlog 2>&1 &&
    /usr/hdp/3.0.0.0-1634/sqoop/bin/sqoop import -D mapred.child.java.opts="-Djava.security.egd=file:/dev/../dev/urandom" \
    --connect jdbc:oracle:thin:EDWHADOOP/wjdqhrP\!23@10.91.41.172:12560:DBEDWP2 \
    --username  EDWHADOOP \
    --password wjdqhrP\!23 \
    --query "SELECT /*+ FULL(TMLMB_LNCTCOVCLG) */ REPLACE(REPLACE(STD_YYMM,CHR(13),''),CHR(10),'') STD_YYMM
, REPLACE(REPLACE(CTR_COV_ID,CHR(13),''),CHR(10),'') CTR_COV_ID
, REPLACE(REPLACE(POL_NO,CHR(13),''),CHR(10),'') POL_NO
, REPLACE(REPLACE(CTR_ID,CHR(13),''),CHR(10),'') CTR_ID
, REPLACE(REPLACE(CTR_OBJ_ID,CHR(13),''),CHR(10),'') CTR_OBJ_ID
, REPLACE(REPLACE(OBJ_ID,CHR(13),''),CHR(10),'') OBJ_ID
, REPLACE(REPLACE(COV_CD,CHR(13),''),CHR(10),'') COV_CD
, REPLACE(REPLACE(COV_UNT_PD_CD,CHR(13),''),CHR(10),'') COV_UNT_PD_CD
, REPLACE(REPLACE(BAS_SIC_DIV_CD,CHR(13),''),CHR(10),'') BAS_SIC_DIV_CD
, REPLACE(REPLACE(CTR_COV_STAT_CD,CHR(13),''),CHR(10),'') CTR_COV_STAT_CD
, REPLACE(REPLACE(CTR_COV_STAT_DTL_CD,CHR(13),''),CHR(10),'') CTR_COV_STAT_DTL_CD
, COV_INS_BGN_DT
, COV_INS_ED_DT
, REPLACE(REPLACE(COV_INS_PRD_TP_CD,CHR(13),''),CHR(10),'') COV_INS_PRD_TP_CD
, REPLACE(REPLACE(COV_PY_PRD_TP_CD,CHR(13),''),CHR(10),'') COV_PY_PRD_TP_CD
, COV_INS_PRD
, COV_PY_PRD
, COV_INS_ED_AGE
, COV_PY_ED_AGE
, COV_BAS_PREM
, COV_APL_PREM
, COV_SLZ_PREM
, COV_INSD_AMT
, REPLACE(REPLACE(XCHG_RDU_DIV_CD,CHR(13),''),CHR(10),'') XCHG_RDU_DIV_CD
, REPLACE(REPLACE(RNWL_CYC_DIV_CD,CHR(13),''),CHR(10),'') RNWL_CYC_DIV_CD
, REPLACE(REPLACE(ALMEXP_STDTN_YN,CHR(13),''),CHR(10),'') ALMEXP_STDTN_YN
, REPLACE(REPLACE(RNWL_ED_PRD_DIV_CD,CHR(13),''),CHR(10),'') RNWL_ED_PRD_DIV_CD
, RNWL_ED_PRD
, RNWL_ED_AGE
, RNWL_ED_DT
, RNWL_TMS
, REPLACE(REPLACE(MOM_PD_CD,CHR(13),''),CHR(10),'') MOM_PD_CD
, REPLACE(REPLACE(OBJ_TP_CD,CHR(13),''),CHR(10),'') OBJ_TP_CD
, REPLACE(REPLACE(OBJ_DIV_CD,CHR(13),''),CHR(10),'') OBJ_DIV_CD
, REPLACE(REPLACE(OPN_JBCL_CD,CHR(13),''),CHR(10),'') OPN_JBCL_CD
, REPLACE(REPLACE(TNG_DIV_CD,CHR(13),''),CHR(10),'') TNG_DIV_CD
, REPLACE(REPLACE(OBJ_GRD_CD,CHR(13),''),CHR(10),'') OBJ_GRD_CD
, REPLACE(REPLACE(INSPE_CUS_NO,CHR(13),''),CHR(10),'') INSPE_CUS_NO
, REPLACE(REPLACE(INSPE_JOB_CD,CHR(13),''),CHR(10),'') INSPE_JOB_CD
, REPLACE(REPLACE(INSPE_JOB_GRD_CD,CHR(13),''),CHR(10),'') INSPE_JOB_GRD_CD
, REPLACE(REPLACE(INSPE_GNDR_CD,CHR(13),''),CHR(10),'') INSPE_GNDR_CD
, INSPE_INS_AGE
, REPLACE(REPLACE(INSPE_NATL_CD,CHR(13),''),CHR(10),'') INSPE_NATL_CD
, REPLACE(REPLACE(INSPE_STAY_QUAL_KD_CD,CHR(13),''),CHR(10),'') INSPE_STAY_QUAL_KD_CD
, REPLACE(REPLACE(INSPE_FETS_YN,CHR(13),''),CHR(10),'') INSPE_FETS_YN
, REPLACE(REPLACE(MFETS_YN,CHR(13),''),CHR(10),'') MFETS_YN
, REPLACE(REPLACE(PLAN_CD,CHR(13),''),CHR(10),'') PLAN_CD
, REPLACE(REPLACE(PLAN_GRP_DIV_CD,CHR(13),''),CHR(10),'') PLAN_GRP_DIV_CD
, EIH_LDG_DTM
, REPLACE(REPLACE(MOM_COV_CD,CHR(13),''),CHR(10),'') MOM_COV_CD
, MOM_COV_INSD_AMT FROM TMLMB_LNCTCOVCLG
                       WHERE \$CONDITIONS 
			AND STD_YYMM = '${PART}'"\
    --m 8 \
    --boundary-query "SELECT 0, 7 FROM DUAL"\
    --split-by "ORA_HASH(CTR_COV_ID, 7)"\
    --target-dir /tmp2/STG_TMLMB_LNCTCOVCLG \
    --hive-import \
    --external-table-dir hdfs:///tmp2/temp_tbl/STG_TMLMB_LNCTCOVCLG \
    --hive-overwrite \
    --hive-table DEFAULT.STG_TMLMB_LNCTCOVCLG  >> ${SHLOG_DIR}/TMLMB_LNCTCOVCLG.shlog 2>&1 &&

#----------------------------------------------------#
# Hadoop 원본테이블에 변경분 최종 적용
#----------------------------------------------------#
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.TMLMB_LNCTCOVCLG_TMP ; " >> ${SHLOG_DIR}/TMLMB_LNCTCOVCLG.shlog 2>&1 &&
    /usr/bin/hive -e "CREATE EXTERNAL TABLE MERITZ.TMLMB_LNCTCOVCLG_TMP STORED AS PARQUET TBLPROPERTIES ('PARQUET.COMPRESS'='SNAPPY') AS
                                SELECT *
                                FROM DEFAULT.STG_TMLMB_LNCTCOVCLG ;" >> ${SHLOG_DIR}/TMLMB_LNCTCOVCLG.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.STG_TMLMB_LNCTCOVCLG ;" >> ${SHLOG_DIR}/TMLMB_LNCTCOVCLG.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.TMLMB_LNCTCOVCLG_${PART} ;" >> ${SHLOG_DIR}/TMLMB_LNCTCOVCLG.shlog 2>&1 &&
# 위의 파티션 드롭 코드는 아래 파일삭제를 전제하고 있음 
# external table은 drop시 자동삭제가 되지 않기 때문에 꼬였었음 181129 수정 
    /usr/bin/hadoop fs -rm -r -f  /warehouse/tablespace/external/hive/meritz.db/tmlmb_lnctcovclg_${PART}  >> ${SHLOG_DIR}/TMLMB_LNCTCOVCLG.shlog 2>&1 &&
    /usr/bin/hive -e "ALTER TABLE MERITZ.TMLMB_LNCTCOVCLG_TMP RENAME TO MERITZ.TMLMB_LNCTCOVCLG_${PART} ;" >> ${SHLOG_DIR}/TMLMB_LNCTCOVCLG.shlog 2>&1 &&
# external table 이 alter문 동작 다른 문제로 아래 과정이 필요해짐 
    /usr/bin/hive -e "ALTER TABLE MERITZ.TMLMB_LNCTCOVCLG_${PART} SET LOCATION 'hdfs:///warehouse/tablespace/external/hive/meritz.db/tmlmb_lnctcovclg_${PART}' ;" >> ${SHLOG_DIR}/TMLMB_LNCTCOVCLG.shlog 2>&1 &&
    /usr/bin/hdfs dfs -mv /warehouse/tablespace/external/hive/meritz.db/tmlmb_lnctcovclg_tmp /warehouse/tablespace/external/hive/meritz.db/tmlmb_lnctcovclg_${PART} >> ${SHLOG_DIR}/TMLMB_LNCTCOVCLG.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.TMLMB_LNCTCOVCLG_TMP ;" >> ${SHLOG_DIR}/TMLMB_LNCTCOVCLG.shlog 2>&1 

if [ $? -ne 0 ]
then             
    echo "*-----------[ TMLMB_LNCTCOVCLG.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/TMLMB_LNCTCOVCLG.shlog"
    echo "*-----------[ TMLMB_LNCTCOVCLG.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/TMLMB_LNCTCOVCLG.shlog"  >>  ${SHLOG_DIR}/TMLMB_LNCTCOVCLG.shlog
    echo "*-----------[ TMLMB_LNCTCOVCLG.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ TMLMB_LNCTCOVCLG.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/TMLMB_LNCTCOVCLG.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/TMLMB_LNCTCOVCLG.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/TMLMB_LNCTCOVCLG.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/TMLMB_LNCTCOVCLG.shlog /sqoopbin/scripts/etlpgm/his_log/TMLMB_LNCTCOVCLG_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  TMLMB_LNCTCOVCLG.sh cmd command error !! ***
    fi               

    exit -1      

else             
    echo "*-----------[ TMLMB_LNCTCOVCLG.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ TMLMB_LNCTCOVCLG.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/TMLMB_LNCTCOVCLG.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/TMLMB_LNCTCOVCLG.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/TMLMB_LNCTCOVCLG.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/TMLMB_LNCTCOVCLG.shlog /sqoopbin/scripts/etlpgm/his_log/TMLMB_LNCTCOVCLG_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  TMLMB_LNCTCOVCLG.sh cmd command error !! ***
        exit -1      
    else             
        exit 0       
    fi               
fi               
