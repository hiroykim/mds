#!/bin/bash

if [ $# -eq 0 ]
then           
    ARGS=N    
else           
    ARGS=$1
fi             

NOW=$(date +"+%Y-%m-%d_%T")
SHLOG_DIR=/sqoopbin/scripts/etlpgm/cur_log
HISLOG_DIR=/sqoopbin/scripts/etlpgm/his_log

export HADOOP_OPTS=-Djava.security.egd=file:/dev/../dev/urandom
export ORACLE_BASE=/sw/oracle
export ORACLE_HOME=/sw/oracle/product/11.2.0.4/client_1
export LD_LIBRARY_PATH=/sw/oracle/product/11.2.0.4/client_1/lib:/sw/oracle/product/11.2.0.4/client_1/lib:
export PATH=/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/usr/lib64/qt-3.3/bin:/usr/hdp/3.0.0.0-1634/spark2/bin/:/var/opt/node/bin/:/opt/maven/bin:/usr/local/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/home/hdpapp/workspace/data-science-at-the-command-line/tools:/home/hdpapp/.local/bin:/home/hdpapp/bin
export TNS_ADMIN=/sw/oracle/product/11.2.0.4/client_1/network/admin
export ORACLE_SID=DBEDWP2
export NLS_LANG=American_America.KO16MSWIN949

#----------------------------------------------------#
# 작업내용 : THDDH_TCTEWPYCLG 테이블 sqoop 복제 작업
# 작업주기 :  
#----------------------------------------------------#

    echo " "
    echo "*-----------[ THDDH_TCTEWPYCLG.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TCTEWPYCLG.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`  >  ${SHLOG_DIR}/THDDH_TCTEWPYCLG.shlog

#----------------------------------------------------#
# 테이블별 전체 데이터를 받아 오는 부분
#----------------------------------------------------#
    /usr/bin/hadoop fs -rm -r -f  /tmp2/LAST_THDDH_TCTEWPYCLG  >> ${SHLOG_DIR}/THDDH_TCTEWPYCLG.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.LAST_THDDH_TCTEWPYCLG ; " >> ${SHLOG_DIR}/THDDH_TCTEWPYCLG.shlog 2>&1 &&
    /usr/hdp/3.0.0.0-1634/sqoop/bin/sqoop import -D mapred.child.java.opts="-Djava.security.egd=file:/dev/../dev/urandom" \
    --connect jdbc:oracle:thin:EDWHADOOP/wjdqhrP\!23@10.91.41.172:12560:DBEDWP2 \
    --username  EDWHADOOP \
    --password wjdqhrP\!23 \
    --query "SELECT /*+ FULL(THDDH_TCTEWPYCLG) */ REPLACE(REPLACE(CLOG_YYMM,CHR(13),''),CHR(10),'') CLOG_YYMM
, REPLACE(REPLACE(POL_NO,CHR(13),''),CHR(10),'') POL_NO
, REPLACE(REPLACE(EWPY_TP_CD,CHR(13),''),CHR(10),'') EWPY_TP_CD
, OCC_DT
, REPLACE(REPLACE(UNT_PD_CD,CHR(13),''),CHR(10),'') UNT_PD_CD
, REPLACE(REPLACE(POLHD_CUS_ID,CHR(13),''),CHR(10),'') POLHD_CUS_ID
, REPLACE(REPLACE(MNCL_MD_CD,CHR(13),''),CHR(10),'') MNCL_MD_CD
, REPLACE(REPLACE(SUCL_RFD_DIV_CD,CHR(13),''),CHR(10),'') SUCL_RFD_DIV_CD
, EWPY_AMT
, REPLACE(REPLACE(TRT_HDQT_ORG_ID,CHR(13),''),CHR(10),'') TRT_HDQT_ORG_ID
, REPLACE(REPLACE(TRT_BRCH_ORG_ID,CHR(13),''),CHR(10),'') TRT_BRCH_ORG_ID
, REPLACE(REPLACE(TRT_BCH_ORG_ID,CHR(13),''),CHR(10),'') TRT_BCH_ORG_ID
, REPLACE(REPLACE(TRTPE_ORG_ID,CHR(13),''),CHR(10),'') TRTPE_ORG_ID
, REPLACE(REPLACE(AGPLR_ORG_ID,CHR(13),''),CHR(10),'') AGPLR_ORG_ID
, REPLACE(REPLACE(PCS_BRCH_ORG_ID,CHR(13),''),CHR(10),'') PCS_BRCH_ORG_ID
, REPLACE(REPLACE(PCS_BCH_ORG_ID,CHR(13),''),CHR(10),'') PCS_BCH_ORG_ID
, REPLACE(REPLACE(OPTPE_ORG_ID,CHR(13),''),CHR(10),'') OPTPE_ORG_ID
, REPLACE(REPLACE(INPPE_ORG_ID,CHR(13),''),CHR(10),'') INPPE_ORG_ID
, SYS_OCC_DTM
, REPLACE(REPLACE(SYS_DEL_DIV_CD,CHR(13),''),CHR(10),'') SYS_DEL_DIV_CD
, REPLACE(REPLACE(OCC_IP,CHR(13),''),CHR(10),'') OCC_IP
, REPLACE(REPLACE(APP_ID,CHR(13),''),CHR(10),'') APP_ID
, DATA_CHNG_DTM
, REPLACE(REPLACE(AGC_BROF_ORG_ID,CHR(13),''),CHR(10),'') AGC_BROF_ORG_ID
, REPLACE(REPLACE(CTR_STAT_DTL_CD,CHR(13),''),CHR(10),'') CTR_STAT_DTL_CD
, EIH_LDG_DTM
, REPLACE(REPLACE(IVS_CTR_YN,CHR(13),''),CHR(10),'') IVS_CTR_YN FROM THDDH_TCTEWPYCLG
                       WHERE \$CONDITIONS "\
    --m 1 \
    --target-dir /tmp2/LAST_THDDH_TCTEWPYCLG \
    --hive-import \
    --external-table-dir hdfs:///tmp2/temp_tbl/LAST_THDDH_TCTEWPYCLG \
    --hive-overwrite \
    --hive-table DEFAULT.LAST_THDDH_TCTEWPYCLG  >> ${SHLOG_DIR}/THDDH_TCTEWPYCLG.shlog 2>&1 &&

#----------------------------------------------------#
# Hadoop 원본테이블에 변경분 최종 적용
#----------------------------------------------------#
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TCTEWPYCLG_TMP ; " >> ${SHLOG_DIR}/THDDH_TCTEWPYCLG.shlog 2>&1 &&
    /usr/bin/hive -e "CREATE EXTERNAL TABLE MERITZ.THDDH_TCTEWPYCLG_TMP STORED AS PARQUET TBLPROPERTIES ('PARQUET.COMPRESS'='SNAPPY') AS
                                SELECT *
                                FROM DEFAULT.LAST_THDDH_TCTEWPYCLG ;" >> ${SHLOG_DIR}/THDDH_TCTEWPYCLG.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.LAST_THDDH_TCTEWPYCLG ;" >> ${SHLOG_DIR}/THDDH_TCTEWPYCLG.shlog 2>&1 &&
    /usr/bin/hdfs dfs -rm -r -f -skipTrash /tmp2/temp_tbl/LAST_THDDH_TCTEWPYCLG >> ${SHLOG_DIR}/THDDH_TCTEWPYCLG.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TCTEWPYCLG ;" >> ${SHLOG_DIR}/THDDH_TCTEWPYCLG.shlog 2>&1 &&
    /usr/bin/hive -e "ALTER TABLE MERITZ.THDDH_TCTEWPYCLG_TMP RENAME TO MERITZ.THDDH_TCTEWPYCLG ;" >> ${SHLOG_DIR}/THDDH_TCTEWPYCLG.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TCTEWPYCLG_TMP ;" >> ${SHLOG_DIR}/THDDH_TCTEWPYCLG.shlog 2>&1 

if [ $? -ne 0 ]
then             
    echo "*-----------[ THDDH_TCTEWPYCLG.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/THDDH_TCTEWPYCLG.shlog"
    echo "*-----------[ THDDH_TCTEWPYCLG.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/THDDH_TCTEWPYCLG.shlog"  >>  ${SHLOG_DIR}/THDDH_TCTEWPYCLG.shlog
    echo "*-----------[ THDDH_TCTEWPYCLG.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TCTEWPYCLG.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/THDDH_TCTEWPYCLG.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/THDDH_TCTEWPYCLG.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCTEWPYCLG.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCTEWPYCLG.shlog /sqoopbin/scripts/etlpgm/his_log/THDDH_TCTEWPYCLG_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  THDDH_TCTEWPYCLG.sh cmd command error !! ***
    fi               

    exit -1      

else             
    echo "*-----------[ THDDH_TCTEWPYCLG.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TCTEWPYCLG.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/THDDH_TCTEWPYCLG.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/THDDH_TCTEWPYCLG.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCTEWPYCLG.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCTEWPYCLG.shlog /sqoopbin/scripts/etlpgm/his_log/THDDH_TCTEWPYCLG_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  THDDH_TCTEWPYCLG.sh cmd command error !! ***
        exit -1      
    else             
        exit 0       
    fi               
fi               
