#!/bin/bash

if [ $# -eq 0 ]
then           
    ARGS=N    
else           
    ARGS=$1
fi             

NOW=$(date +"+%Y-%m-%d_%T")
SHLOG_DIR=/sqoopbin/scripts/etlpgm/cur_log
HISLOG_DIR=/sqoopbin/scripts/etlpgm/his_log

export HADOOP_OPTS=-Djava.security.egd=file:/dev/../dev/urandom
export ORACLE_BASE=/sw/oracle
export ORACLE_HOME=/sw/oracle/product/11.2.0.4/client_1
export LD_LIBRARY_PATH=/sw/oracle/product/11.2.0.4/client_1/lib:/sw/oracle/product/11.2.0.4/client_1/lib:
export PATH=/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/usr/lib64/qt-3.3/bin:/usr/hdp/3.0.0.0-1634/spark2/bin/:/var/opt/node/bin/:/opt/maven/bin:/usr/local/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/home/hdpapp/workspace/data-science-at-the-command-line/tools:/home/hdpapp/.local/bin:/home/hdpapp/bin
export TNS_ADMIN=/sw/oracle/product/11.2.0.4/client_1/network/admin
export ORACLE_SID=DBEDWP2
export NLS_LANG=American_America.KO16MSWIN949

#----------------------------------------------------#
# 작업내용 : THDDH_TCTRFDPYRC 테이블 sqoop 복제 작업
# 작업주기 :  
#----------------------------------------------------#

    echo " "
    echo "*-----------[ THDDH_TCTRFDPYRC.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TCTRFDPYRC.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`  >  ${SHLOG_DIR}/THDDH_TCTRFDPYRC.shlog

#----------------------------------------------------#
# 테이블별 전체 데이터를 받아 오는 부분
#----------------------------------------------------#
    /usr/bin/hadoop fs -rm -r -f  /tmp2/LAST_THDDH_TCTRFDPYRC  >> ${SHLOG_DIR}/THDDH_TCTRFDPYRC.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.LAST_THDDH_TCTRFDPYRC ; " >> ${SHLOG_DIR}/THDDH_TCTRFDPYRC.shlog 2>&1 &&
    /usr/hdp/3.0.0.0-1634/sqoop/bin/sqoop import -D mapred.child.java.opts="-Djava.security.egd=file:/dev/../dev/urandom" \
    --connect jdbc:oracle:thin:EDWHADOOP/wjdqhrP\!23@10.91.41.172:12560:DBEDWP2 \
    --username  EDWHADOOP \
    --password wjdqhrP\!23 \
    --query "SELECT /*+ FULL(THDDH_TCTRFDPYRC) */ REPLACE(REPLACE(RFD_AMT_PYRC_ID,CHR(13),''),CHR(10),'') RFD_AMT_PYRC_ID
, REPLACE(REPLACE(POL_NO,CHR(13),''),CHR(10),'') POL_NO
, RFD_RETR_SEQ
, RFD_AMT_PYRC_SEQ
, RFD_RETR_AMT
, TT_PY_PREM
, RFD_RT
, RFD_RETR_DT
, REPLACE(REPLACE(RFD_RETR_DIV_CD,CHR(13),''),CHR(10),'') RFD_RETR_DIV_CD
, REPLACE(REPLACE(RFD_KD_CD,CHR(13),''),CHR(10),'') RFD_KD_CD
, REPLACE(REPLACE(RFD_KD_DTL_CD,CHR(13),''),CHR(10),'') RFD_KD_DTL_CD
, REPLACE(REPLACE(CNCLL_RSN_CD,CHR(13),''),CHR(10),'') CNCLL_RSN_CD
, REPLACE(REPLACE(TXEX_RSN_CD,CHR(13),''),CHR(10),'') TXEX_RSN_CD
, REPLACE(REPLACE(RFD_RSN_CON,CHR(13),''),CHR(10),'') RFD_RSN_CON
, REPLACE(REPLACE(CTR_STAT_CD,CHR(13),''),CHR(10),'') CTR_STAT_CD
, REPLACE(REPLACE(CTR_STAT_DTL_CD,CHR(13),''),CHR(10),'') CTR_STAT_DTL_CD
, REPLACE(REPLACE(RCT_MD_CD,CHR(13),''),CHR(10),'') RCT_MD_CD
, REPLACE(REPLACE(TTAX_DIV_CD,CHR(13),''),CHR(10),'') TTAX_DIV_CD
, REPLACE(REPLACE(ALTN_BIZ_SYS_CD,CHR(13),''),CHR(10),'') ALTN_BIZ_SYS_CD
, REPLACE(REPLACE(PAY_CHN_CD,CHR(13),''),CHR(10),'') PAY_CHN_CD
, REPLACE(REPLACE(RFD_AMT_RCPY_TRG_ID,CHR(13),''),CHR(10),'') RFD_AMT_RCPY_TRG_ID
, REPLACE(REPLACE(RCPPE_ORG_ID,CHR(13),''),CHR(10),'') RCPPE_ORG_ID
, REPLACE(REPLACE(TRTPE_ORG_ID,CHR(13),''),CHR(10),'') TRTPE_ORG_ID
, REPLACE(REPLACE(AGPLR_ORG_ID,CHR(13),''),CHR(10),'') AGPLR_ORG_ID
, REPLACE(REPLACE(CNC_RFD_AMT_PYRC_ID,CHR(13),''),CHR(10),'') CNC_RFD_AMT_PYRC_ID
, CNC_DT
, REPLACE(REPLACE(CMPR_GUID_YN,CHR(13),''),CHR(10),'') CMPR_GUID_YN
, ENDR_HIS_STD_NO
, ENDR_NO
, REPLACE(REPLACE(BNCA_AFLCO_MNG_NO,CHR(13),''),CHR(10),'') BNCA_AFLCO_MNG_NO
, REPLACE(REPLACE(BNCA_AFLCO_CD,CHR(13),''),CHR(10),'') BNCA_AFLCO_CD
, REPLACE(REPLACE(BNCA_AGC_BROF_ORG_CD,CHR(13),''),CHR(10),'') BNCA_AGC_BROF_ORG_CD
, REPLACE(REPLACE(BNCA_AGPLR_NO,CHR(13),''),CHR(10),'') BNCA_AGPLR_NO
, REPLACE(REPLACE(POSS_DOC_UNATC_YN,CHR(13),''),CHR(10),'') POSS_DOC_UNATC_YN
, REPLACE(REPLACE(INPPE_ORG_ID,CHR(13),''),CHR(10),'') INPPE_ORG_ID
, SYS_OCC_DTM
, REPLACE(REPLACE(SYS_DEL_DIV_CD,CHR(13),''),CHR(10),'') SYS_DEL_DIV_CD
, REPLACE(REPLACE(OCC_IP,CHR(13),''),CHR(10),'') OCC_IP
, REPLACE(REPLACE(APP_ID,CHR(13),''),CHR(10),'') APP_ID
, DATA_CHNG_DTM
, REPLACE(REPLACE(CTR_ID,CHR(13),''),CHR(10),'') CTR_ID
, REPLACE(REPLACE(TRTS_ORG_ID,CHR(13),''),CHR(10),'') TRTS_ORG_ID
, REPLACE(REPLACE(TRT_SB_ORG_ID,CHR(13),''),CHR(10),'') TRT_SB_ORG_ID
, PYRC_XPT_TMS
, REPLACE(REPLACE(LAST_PY_YYMM,CHR(13),''),CHR(10),'') LAST_PY_YYMM
, REPLACE(REPLACE(AGC_BROF_ORG_ID,CHR(13),''),CHR(10),'') AGC_BROF_ORG_ID
, REPLACE(REPLACE(RCP_SB_ORG_ID,CHR(13),''),CHR(10),'') RCP_SB_ORG_ID
, REPLACE(REPLACE(RCPS_ORG_ID,CHR(13),''),CHR(10),'') RCPS_ORG_ID
, REPLACE(REPLACE(UNT_PD_CD,CHR(13),''),CHR(10),'') UNT_PD_CD
, EIH_LDG_DTM
, DTH_DT FROM THDDH_TCTRFDPYRC
                       WHERE \$CONDITIONS "\
    --m 8 \
    --boundary-query "SELECT 0, 7 FROM DUAL"\
    --split-by "ORA_HASH(RFD_AMT_PYRC_ID, 7)"\
    --target-dir /tmp2/LAST_THDDH_TCTRFDPYRC \
    --hive-import \
    --external-table-dir hdfs:///tmp2/temp_tbl/LAST_THDDH_TCTRFDPYRC \
    --hive-overwrite \
    --hive-table DEFAULT.LAST_THDDH_TCTRFDPYRC  >> ${SHLOG_DIR}/THDDH_TCTRFDPYRC.shlog 2>&1 &&

#----------------------------------------------------#
# Hadoop 원본테이블에 변경분 최종 적용
#----------------------------------------------------#
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TCTRFDPYRC_TMP ; " >> ${SHLOG_DIR}/THDDH_TCTRFDPYRC.shlog 2>&1 &&
    /usr/bin/hive -e "CREATE EXTERNAL TABLE MERITZ.THDDH_TCTRFDPYRC_TMP STORED AS PARQUET TBLPROPERTIES ('PARQUET.COMPRESS'='SNAPPY') AS
                                SELECT *
                                FROM DEFAULT.LAST_THDDH_TCTRFDPYRC ;" >> ${SHLOG_DIR}/THDDH_TCTRFDPYRC.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.LAST_THDDH_TCTRFDPYRC ;" >> ${SHLOG_DIR}/THDDH_TCTRFDPYRC.shlog 2>&1 &&
    /usr/bin/hdfs dfs -rm -r -f -skipTrash /tmp2/temp_tbl/LAST_THDDH_TCTRFDPYRC >> ${SHLOG_DIR}/THDDH_TCTRFDPYRC.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TCTRFDPYRC ;" >> ${SHLOG_DIR}/THDDH_TCTRFDPYRC.shlog 2>&1 &&
    /usr/bin/hive -e "ALTER TABLE MERITZ.THDDH_TCTRFDPYRC_TMP RENAME TO MERITZ.THDDH_TCTRFDPYRC ;" >> ${SHLOG_DIR}/THDDH_TCTRFDPYRC.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TCTRFDPYRC_TMP ;" >> ${SHLOG_DIR}/THDDH_TCTRFDPYRC.shlog 2>&1 

if [ $? -ne 0 ]
then             
    echo "*-----------[ THDDH_TCTRFDPYRC.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/THDDH_TCTRFDPYRC.shlog"
    echo "*-----------[ THDDH_TCTRFDPYRC.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/THDDH_TCTRFDPYRC.shlog"  >>  ${SHLOG_DIR}/THDDH_TCTRFDPYRC.shlog
    echo "*-----------[ THDDH_TCTRFDPYRC.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TCTRFDPYRC.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/THDDH_TCTRFDPYRC.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/THDDH_TCTRFDPYRC.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCTRFDPYRC.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCTRFDPYRC.shlog /sqoopbin/scripts/etlpgm/his_log/THDDH_TCTRFDPYRC_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  THDDH_TCTRFDPYRC.sh cmd command error !! ***
    fi               

    exit -1      

else             
    echo "*-----------[ THDDH_TCTRFDPYRC.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TCTRFDPYRC.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/THDDH_TCTRFDPYRC.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/THDDH_TCTRFDPYRC.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCTRFDPYRC.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCTRFDPYRC.shlog /sqoopbin/scripts/etlpgm/his_log/THDDH_TCTRFDPYRC_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  THDDH_TCTRFDPYRC.sh cmd command error !! ***
        exit -1      
    else             
        exit 0       
    fi               
fi               
