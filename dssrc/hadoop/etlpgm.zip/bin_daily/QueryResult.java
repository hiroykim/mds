// ORM class for table 'null'
// WARNING: This class is AUTO-GENERATED. Modify at your own risk.
//
// Debug information:
// Generated date: Tue Jun 08 02:47:17 GMT 2021
// For connector: org.apache.sqoop.manager.OracleManager
import org.apache.hadoop.io.BytesWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.mapred.lib.db.DBWritable;
import org.apache.sqoop.lib.JdbcWritableBridge;
import org.apache.sqoop.lib.DelimiterSet;
import org.apache.sqoop.lib.FieldFormatter;
import org.apache.sqoop.lib.RecordParser;
import org.apache.sqoop.lib.BooleanParser;
import org.apache.sqoop.lib.BlobRef;
import org.apache.sqoop.lib.ClobRef;
import org.apache.sqoop.lib.LargeObjectLoader;
import org.apache.sqoop.lib.SqoopRecord;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.sql.Date;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

public class QueryResult extends SqoopRecord  implements DBWritable, Writable {
  private final int PROTOCOL_VERSION = 3;
  public int getClassFormatVersion() { return PROTOCOL_VERSION; }
  public static interface FieldSetterCommand {    void setField(Object value);  }  protected ResultSet __cur_result_set;
  private Map<String, FieldSetterCommand> setters = new HashMap<String, FieldSetterCommand>();
  private void init0() {
    setters.put("CTR_ID", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.CTR_ID = (String)value;
      }
    });
    setters.put("CTR_PTY_SEQ", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.CTR_PTY_SEQ = (java.math.BigDecimal)value;
      }
    });
    setters.put("HIS_SEQ", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.HIS_SEQ = (java.math.BigDecimal)value;
      }
    });
    setters.put("BIZ_SYS_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.BIZ_SYS_CD = (String)value;
      }
    });
    setters.put("PRCTR_NO", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.PRCTR_NO = (String)value;
      }
    });
    setters.put("RL_APL_RNG_DIV_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.RL_APL_RNG_DIV_CD = (String)value;
      }
    });
    setters.put("DATA_ID", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.DATA_ID = (String)value;
      }
    });
    setters.put("DATA_SEQ", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.DATA_SEQ = (java.math.BigDecimal)value;
      }
    });
    setters.put("CTR_PTY_RL_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.CTR_PTY_RL_CD = (String)value;
      }
    });
    setters.put("PTY_DIV_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.PTY_DIV_CD = (String)value;
      }
    });
    setters.put("PTY_ID", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.PTY_ID = (String)value;
      }
    });
    setters.put("CUS_NO", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.CUS_NO = (String)value;
      }
    });
    setters.put("CUS_BCH_NO", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.CUS_BCH_NO = (String)value;
      }
    });
    setters.put("RL_RTO", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.RL_RTO = (java.math.BigDecimal)value;
      }
    });
    setters.put("RL_REL_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.RL_REL_CD = (String)value;
      }
    });
    setters.put("REL_PTY_RL_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.REL_PTY_RL_CD = (String)value;
      }
    });
    setters.put("TXPF_REG_TRGPE_DIV_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.TXPF_REG_TRGPE_DIV_CD = (String)value;
      }
    });
    setters.put("POLHD_GRDE_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.POLHD_GRDE_CD = (String)value;
      }
    });
    setters.put("POLHD_CHNG_RSN_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.POLHD_CHNG_RSN_CD = (String)value;
      }
    });
    setters.put("DTL_ADJT_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.DTL_ADJT_CD = (String)value;
      }
    });
    setters.put("RPS_CTR_PTY_YN", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.RPS_CTR_PTY_YN = (String)value;
      }
    });
    setters.put("GNR_POLHD_DIV_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.GNR_POLHD_DIV_CD = (String)value;
      }
    });
    setters.put("RLSIT_NRMN_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.RLSIT_NRMN_CD = (String)value;
      }
    });
    setters.put("AGE", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.AGE = (java.math.BigDecimal)value;
      }
    });
    setters.put("NKNM", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.NKNM = (String)value;
      }
    });
    setters.put("ADDTL_FM_NM", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.ADDTL_FM_NM = (String)value;
      }
    });
    setters.put("POL_RCEPL_DIV_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.POL_RCEPL_DIV_CD = (String)value;
      }
    });
    setters.put("DM_SNDPL_DIV_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.DM_SNDPL_DIV_CD = (String)value;
      }
    });
    setters.put("CMC_MN_TMN_AGR_YN", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.CMC_MN_TMN_AGR_YN = (String)value;
      }
    });
    setters.put("PTY_IDF_INF_SEQ", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.PTY_IDF_INF_SEQ = (java.math.BigDecimal)value;
      }
    });
    setters.put("PSSPE_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.PSSPE_CD = (String)value;
      }
    });
    setters.put("JOB_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.JOB_CD = (String)value;
      }
    });
    setters.put("JOB_GRD_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.JOB_GRD_CD = (String)value;
      }
    });
    setters.put("MARY_YN", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.MARY_YN = (String)value;
      }
    });
    setters.put("CHDN_DRV_YN", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.CHDN_DRV_YN = (String)value;
      }
    });
    setters.put("INSPE_TP_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.INSPE_TP_CD = (String)value;
      }
    });
    setters.put("POL_RCGPE_YN", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.POL_RCGPE_YN = (String)value;
      }
    });
    setters.put("HAPE_EMP_DIV_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.HAPE_EMP_DIV_CD = (String)value;
      }
    });
    setters.put("HAPE_AGE_SIC_DIV_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.HAPE_AGE_SIC_DIV_CD = (String)value;
      }
    });
    setters.put("LCNS_DIV_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.LCNS_DIV_CD = (String)value;
      }
    });
    setters.put("LCNS_NO", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.LCNS_NO = (String)value;
      }
    });
    setters.put("LCNS_DLV_DT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.LCNS_DLV_DT = (java.sql.Timestamp)value;
      }
    });
    setters.put("ENTCO_DT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.ENTCO_DT = (java.sql.Timestamp)value;
      }
    });
    setters.put("ATL_CTR_ID", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.ATL_CTR_ID = (String)value;
      }
    });
    setters.put("ATL_CTR_PTY_SEQ", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.ATL_CTR_PTY_SEQ = (java.math.BigDecimal)value;
      }
    });
    setters.put("ATL_HIS_SEQ", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.ATL_HIS_SEQ = (java.math.BigDecimal)value;
      }
    });
    setters.put("ENDR_NO", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.ENDR_NO = (java.math.BigDecimal)value;
      }
    });
    setters.put("RTRO_ENDR_NO", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.RTRO_ENDR_NO = (java.math.BigDecimal)value;
      }
    });
    setters.put("ENDR_HIS_ST_NO", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.ENDR_HIS_ST_NO = (java.math.BigDecimal)value;
      }
    });
    setters.put("ENDR_HIS_ED_NO", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.ENDR_HIS_ED_NO = (java.math.BigDecimal)value;
      }
    });
    setters.put("SUMUP_DT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.SUMUP_DT = (java.sql.Timestamp)value;
      }
    });
    setters.put("HIS_ST_DT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.HIS_ST_DT = (java.sql.Timestamp)value;
      }
    });
    setters.put("HIS_ED_DT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.HIS_ED_DT = (java.sql.Timestamp)value;
      }
    });
    setters.put("INPPE_ORG_ID", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.INPPE_ORG_ID = (String)value;
      }
    });
    setters.put("SYS_OCC_DTM", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.SYS_OCC_DTM = (java.sql.Timestamp)value;
      }
    });
    setters.put("SYS_DEL_DIV_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.SYS_DEL_DIV_CD = (String)value;
      }
    });
    setters.put("OCC_IP", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.OCC_IP = (String)value;
      }
    });
    setters.put("APP_ID", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.APP_ID = (String)value;
      }
    });
    setters.put("DATA_CHNG_DTM", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.DATA_CHNG_DTM = (java.sql.Timestamp)value;
      }
    });
    setters.put("DSC_CON", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.DSC_CON = (String)value;
      }
    });
    setters.put("RNM_CNF_KD_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.RNM_CNF_KD_CD = (String)value;
      }
    });
    setters.put("IDF_ATH_CHT_ISS_DT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.IDF_ATH_CHT_ISS_DT = (java.sql.Timestamp)value;
      }
    });
    setters.put("ISS_INST_NM", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.ISS_INST_NM = (String)value;
      }
    });
    setters.put("ADDTL_REF_NO", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.ADDTL_REF_NO = (String)value;
      }
    });
    setters.put("RNM_ATH_FNM", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.RNM_ATH_FNM = (String)value;
      }
    });
    setters.put("EIH_LDG_DTM", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.EIH_LDG_DTM = (java.sql.Timestamp)value;
      }
    });
    setters.put("KIS_ETP_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.KIS_ETP_CD = (String)value;
      }
    });
    setters.put("APL_ST_DT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.APL_ST_DT = (java.sql.Timestamp)value;
      }
    });
    setters.put("APL_ED_DT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.APL_ED_DT = (java.sql.Timestamp)value;
      }
    });
    setters.put("HNC_REG_ED_DT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.HNC_REG_ED_DT = (java.sql.Timestamp)value;
      }
    });
    setters.put("HNCPE_CTR_YN", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.HNCPE_CTR_YN = (String)value;
      }
    });
  }
  public QueryResult() {
    init0();
  }
  private String CTR_ID;
  public String get_CTR_ID() {
    return CTR_ID;
  }
  public void set_CTR_ID(String CTR_ID) {
    this.CTR_ID = CTR_ID;
  }
  public QueryResult with_CTR_ID(String CTR_ID) {
    this.CTR_ID = CTR_ID;
    return this;
  }
  private java.math.BigDecimal CTR_PTY_SEQ;
  public java.math.BigDecimal get_CTR_PTY_SEQ() {
    return CTR_PTY_SEQ;
  }
  public void set_CTR_PTY_SEQ(java.math.BigDecimal CTR_PTY_SEQ) {
    this.CTR_PTY_SEQ = CTR_PTY_SEQ;
  }
  public QueryResult with_CTR_PTY_SEQ(java.math.BigDecimal CTR_PTY_SEQ) {
    this.CTR_PTY_SEQ = CTR_PTY_SEQ;
    return this;
  }
  private java.math.BigDecimal HIS_SEQ;
  public java.math.BigDecimal get_HIS_SEQ() {
    return HIS_SEQ;
  }
  public void set_HIS_SEQ(java.math.BigDecimal HIS_SEQ) {
    this.HIS_SEQ = HIS_SEQ;
  }
  public QueryResult with_HIS_SEQ(java.math.BigDecimal HIS_SEQ) {
    this.HIS_SEQ = HIS_SEQ;
    return this;
  }
  private String BIZ_SYS_CD;
  public String get_BIZ_SYS_CD() {
    return BIZ_SYS_CD;
  }
  public void set_BIZ_SYS_CD(String BIZ_SYS_CD) {
    this.BIZ_SYS_CD = BIZ_SYS_CD;
  }
  public QueryResult with_BIZ_SYS_CD(String BIZ_SYS_CD) {
    this.BIZ_SYS_CD = BIZ_SYS_CD;
    return this;
  }
  private String PRCTR_NO;
  public String get_PRCTR_NO() {
    return PRCTR_NO;
  }
  public void set_PRCTR_NO(String PRCTR_NO) {
    this.PRCTR_NO = PRCTR_NO;
  }
  public QueryResult with_PRCTR_NO(String PRCTR_NO) {
    this.PRCTR_NO = PRCTR_NO;
    return this;
  }
  private String RL_APL_RNG_DIV_CD;
  public String get_RL_APL_RNG_DIV_CD() {
    return RL_APL_RNG_DIV_CD;
  }
  public void set_RL_APL_RNG_DIV_CD(String RL_APL_RNG_DIV_CD) {
    this.RL_APL_RNG_DIV_CD = RL_APL_RNG_DIV_CD;
  }
  public QueryResult with_RL_APL_RNG_DIV_CD(String RL_APL_RNG_DIV_CD) {
    this.RL_APL_RNG_DIV_CD = RL_APL_RNG_DIV_CD;
    return this;
  }
  private String DATA_ID;
  public String get_DATA_ID() {
    return DATA_ID;
  }
  public void set_DATA_ID(String DATA_ID) {
    this.DATA_ID = DATA_ID;
  }
  public QueryResult with_DATA_ID(String DATA_ID) {
    this.DATA_ID = DATA_ID;
    return this;
  }
  private java.math.BigDecimal DATA_SEQ;
  public java.math.BigDecimal get_DATA_SEQ() {
    return DATA_SEQ;
  }
  public void set_DATA_SEQ(java.math.BigDecimal DATA_SEQ) {
    this.DATA_SEQ = DATA_SEQ;
  }
  public QueryResult with_DATA_SEQ(java.math.BigDecimal DATA_SEQ) {
    this.DATA_SEQ = DATA_SEQ;
    return this;
  }
  private String CTR_PTY_RL_CD;
  public String get_CTR_PTY_RL_CD() {
    return CTR_PTY_RL_CD;
  }
  public void set_CTR_PTY_RL_CD(String CTR_PTY_RL_CD) {
    this.CTR_PTY_RL_CD = CTR_PTY_RL_CD;
  }
  public QueryResult with_CTR_PTY_RL_CD(String CTR_PTY_RL_CD) {
    this.CTR_PTY_RL_CD = CTR_PTY_RL_CD;
    return this;
  }
  private String PTY_DIV_CD;
  public String get_PTY_DIV_CD() {
    return PTY_DIV_CD;
  }
  public void set_PTY_DIV_CD(String PTY_DIV_CD) {
    this.PTY_DIV_CD = PTY_DIV_CD;
  }
  public QueryResult with_PTY_DIV_CD(String PTY_DIV_CD) {
    this.PTY_DIV_CD = PTY_DIV_CD;
    return this;
  }
  private String PTY_ID;
  public String get_PTY_ID() {
    return PTY_ID;
  }
  public void set_PTY_ID(String PTY_ID) {
    this.PTY_ID = PTY_ID;
  }
  public QueryResult with_PTY_ID(String PTY_ID) {
    this.PTY_ID = PTY_ID;
    return this;
  }
  private String CUS_NO;
  public String get_CUS_NO() {
    return CUS_NO;
  }
  public void set_CUS_NO(String CUS_NO) {
    this.CUS_NO = CUS_NO;
  }
  public QueryResult with_CUS_NO(String CUS_NO) {
    this.CUS_NO = CUS_NO;
    return this;
  }
  private String CUS_BCH_NO;
  public String get_CUS_BCH_NO() {
    return CUS_BCH_NO;
  }
  public void set_CUS_BCH_NO(String CUS_BCH_NO) {
    this.CUS_BCH_NO = CUS_BCH_NO;
  }
  public QueryResult with_CUS_BCH_NO(String CUS_BCH_NO) {
    this.CUS_BCH_NO = CUS_BCH_NO;
    return this;
  }
  private java.math.BigDecimal RL_RTO;
  public java.math.BigDecimal get_RL_RTO() {
    return RL_RTO;
  }
  public void set_RL_RTO(java.math.BigDecimal RL_RTO) {
    this.RL_RTO = RL_RTO;
  }
  public QueryResult with_RL_RTO(java.math.BigDecimal RL_RTO) {
    this.RL_RTO = RL_RTO;
    return this;
  }
  private String RL_REL_CD;
  public String get_RL_REL_CD() {
    return RL_REL_CD;
  }
  public void set_RL_REL_CD(String RL_REL_CD) {
    this.RL_REL_CD = RL_REL_CD;
  }
  public QueryResult with_RL_REL_CD(String RL_REL_CD) {
    this.RL_REL_CD = RL_REL_CD;
    return this;
  }
  private String REL_PTY_RL_CD;
  public String get_REL_PTY_RL_CD() {
    return REL_PTY_RL_CD;
  }
  public void set_REL_PTY_RL_CD(String REL_PTY_RL_CD) {
    this.REL_PTY_RL_CD = REL_PTY_RL_CD;
  }
  public QueryResult with_REL_PTY_RL_CD(String REL_PTY_RL_CD) {
    this.REL_PTY_RL_CD = REL_PTY_RL_CD;
    return this;
  }
  private String TXPF_REG_TRGPE_DIV_CD;
  public String get_TXPF_REG_TRGPE_DIV_CD() {
    return TXPF_REG_TRGPE_DIV_CD;
  }
  public void set_TXPF_REG_TRGPE_DIV_CD(String TXPF_REG_TRGPE_DIV_CD) {
    this.TXPF_REG_TRGPE_DIV_CD = TXPF_REG_TRGPE_DIV_CD;
  }
  public QueryResult with_TXPF_REG_TRGPE_DIV_CD(String TXPF_REG_TRGPE_DIV_CD) {
    this.TXPF_REG_TRGPE_DIV_CD = TXPF_REG_TRGPE_DIV_CD;
    return this;
  }
  private String POLHD_GRDE_CD;
  public String get_POLHD_GRDE_CD() {
    return POLHD_GRDE_CD;
  }
  public void set_POLHD_GRDE_CD(String POLHD_GRDE_CD) {
    this.POLHD_GRDE_CD = POLHD_GRDE_CD;
  }
  public QueryResult with_POLHD_GRDE_CD(String POLHD_GRDE_CD) {
    this.POLHD_GRDE_CD = POLHD_GRDE_CD;
    return this;
  }
  private String POLHD_CHNG_RSN_CD;
  public String get_POLHD_CHNG_RSN_CD() {
    return POLHD_CHNG_RSN_CD;
  }
  public void set_POLHD_CHNG_RSN_CD(String POLHD_CHNG_RSN_CD) {
    this.POLHD_CHNG_RSN_CD = POLHD_CHNG_RSN_CD;
  }
  public QueryResult with_POLHD_CHNG_RSN_CD(String POLHD_CHNG_RSN_CD) {
    this.POLHD_CHNG_RSN_CD = POLHD_CHNG_RSN_CD;
    return this;
  }
  private String DTL_ADJT_CD;
  public String get_DTL_ADJT_CD() {
    return DTL_ADJT_CD;
  }
  public void set_DTL_ADJT_CD(String DTL_ADJT_CD) {
    this.DTL_ADJT_CD = DTL_ADJT_CD;
  }
  public QueryResult with_DTL_ADJT_CD(String DTL_ADJT_CD) {
    this.DTL_ADJT_CD = DTL_ADJT_CD;
    return this;
  }
  private String RPS_CTR_PTY_YN;
  public String get_RPS_CTR_PTY_YN() {
    return RPS_CTR_PTY_YN;
  }
  public void set_RPS_CTR_PTY_YN(String RPS_CTR_PTY_YN) {
    this.RPS_CTR_PTY_YN = RPS_CTR_PTY_YN;
  }
  public QueryResult with_RPS_CTR_PTY_YN(String RPS_CTR_PTY_YN) {
    this.RPS_CTR_PTY_YN = RPS_CTR_PTY_YN;
    return this;
  }
  private String GNR_POLHD_DIV_CD;
  public String get_GNR_POLHD_DIV_CD() {
    return GNR_POLHD_DIV_CD;
  }
  public void set_GNR_POLHD_DIV_CD(String GNR_POLHD_DIV_CD) {
    this.GNR_POLHD_DIV_CD = GNR_POLHD_DIV_CD;
  }
  public QueryResult with_GNR_POLHD_DIV_CD(String GNR_POLHD_DIV_CD) {
    this.GNR_POLHD_DIV_CD = GNR_POLHD_DIV_CD;
    return this;
  }
  private String RLSIT_NRMN_CD;
  public String get_RLSIT_NRMN_CD() {
    return RLSIT_NRMN_CD;
  }
  public void set_RLSIT_NRMN_CD(String RLSIT_NRMN_CD) {
    this.RLSIT_NRMN_CD = RLSIT_NRMN_CD;
  }
  public QueryResult with_RLSIT_NRMN_CD(String RLSIT_NRMN_CD) {
    this.RLSIT_NRMN_CD = RLSIT_NRMN_CD;
    return this;
  }
  private java.math.BigDecimal AGE;
  public java.math.BigDecimal get_AGE() {
    return AGE;
  }
  public void set_AGE(java.math.BigDecimal AGE) {
    this.AGE = AGE;
  }
  public QueryResult with_AGE(java.math.BigDecimal AGE) {
    this.AGE = AGE;
    return this;
  }
  private String NKNM;
  public String get_NKNM() {
    return NKNM;
  }
  public void set_NKNM(String NKNM) {
    this.NKNM = NKNM;
  }
  public QueryResult with_NKNM(String NKNM) {
    this.NKNM = NKNM;
    return this;
  }
  private String ADDTL_FM_NM;
  public String get_ADDTL_FM_NM() {
    return ADDTL_FM_NM;
  }
  public void set_ADDTL_FM_NM(String ADDTL_FM_NM) {
    this.ADDTL_FM_NM = ADDTL_FM_NM;
  }
  public QueryResult with_ADDTL_FM_NM(String ADDTL_FM_NM) {
    this.ADDTL_FM_NM = ADDTL_FM_NM;
    return this;
  }
  private String POL_RCEPL_DIV_CD;
  public String get_POL_RCEPL_DIV_CD() {
    return POL_RCEPL_DIV_CD;
  }
  public void set_POL_RCEPL_DIV_CD(String POL_RCEPL_DIV_CD) {
    this.POL_RCEPL_DIV_CD = POL_RCEPL_DIV_CD;
  }
  public QueryResult with_POL_RCEPL_DIV_CD(String POL_RCEPL_DIV_CD) {
    this.POL_RCEPL_DIV_CD = POL_RCEPL_DIV_CD;
    return this;
  }
  private String DM_SNDPL_DIV_CD;
  public String get_DM_SNDPL_DIV_CD() {
    return DM_SNDPL_DIV_CD;
  }
  public void set_DM_SNDPL_DIV_CD(String DM_SNDPL_DIV_CD) {
    this.DM_SNDPL_DIV_CD = DM_SNDPL_DIV_CD;
  }
  public QueryResult with_DM_SNDPL_DIV_CD(String DM_SNDPL_DIV_CD) {
    this.DM_SNDPL_DIV_CD = DM_SNDPL_DIV_CD;
    return this;
  }
  private String CMC_MN_TMN_AGR_YN;
  public String get_CMC_MN_TMN_AGR_YN() {
    return CMC_MN_TMN_AGR_YN;
  }
  public void set_CMC_MN_TMN_AGR_YN(String CMC_MN_TMN_AGR_YN) {
    this.CMC_MN_TMN_AGR_YN = CMC_MN_TMN_AGR_YN;
  }
  public QueryResult with_CMC_MN_TMN_AGR_YN(String CMC_MN_TMN_AGR_YN) {
    this.CMC_MN_TMN_AGR_YN = CMC_MN_TMN_AGR_YN;
    return this;
  }
  private java.math.BigDecimal PTY_IDF_INF_SEQ;
  public java.math.BigDecimal get_PTY_IDF_INF_SEQ() {
    return PTY_IDF_INF_SEQ;
  }
  public void set_PTY_IDF_INF_SEQ(java.math.BigDecimal PTY_IDF_INF_SEQ) {
    this.PTY_IDF_INF_SEQ = PTY_IDF_INF_SEQ;
  }
  public QueryResult with_PTY_IDF_INF_SEQ(java.math.BigDecimal PTY_IDF_INF_SEQ) {
    this.PTY_IDF_INF_SEQ = PTY_IDF_INF_SEQ;
    return this;
  }
  private String PSSPE_CD;
  public String get_PSSPE_CD() {
    return PSSPE_CD;
  }
  public void set_PSSPE_CD(String PSSPE_CD) {
    this.PSSPE_CD = PSSPE_CD;
  }
  public QueryResult with_PSSPE_CD(String PSSPE_CD) {
    this.PSSPE_CD = PSSPE_CD;
    return this;
  }
  private String JOB_CD;
  public String get_JOB_CD() {
    return JOB_CD;
  }
  public void set_JOB_CD(String JOB_CD) {
    this.JOB_CD = JOB_CD;
  }
  public QueryResult with_JOB_CD(String JOB_CD) {
    this.JOB_CD = JOB_CD;
    return this;
  }
  private String JOB_GRD_CD;
  public String get_JOB_GRD_CD() {
    return JOB_GRD_CD;
  }
  public void set_JOB_GRD_CD(String JOB_GRD_CD) {
    this.JOB_GRD_CD = JOB_GRD_CD;
  }
  public QueryResult with_JOB_GRD_CD(String JOB_GRD_CD) {
    this.JOB_GRD_CD = JOB_GRD_CD;
    return this;
  }
  private String MARY_YN;
  public String get_MARY_YN() {
    return MARY_YN;
  }
  public void set_MARY_YN(String MARY_YN) {
    this.MARY_YN = MARY_YN;
  }
  public QueryResult with_MARY_YN(String MARY_YN) {
    this.MARY_YN = MARY_YN;
    return this;
  }
  private String CHDN_DRV_YN;
  public String get_CHDN_DRV_YN() {
    return CHDN_DRV_YN;
  }
  public void set_CHDN_DRV_YN(String CHDN_DRV_YN) {
    this.CHDN_DRV_YN = CHDN_DRV_YN;
  }
  public QueryResult with_CHDN_DRV_YN(String CHDN_DRV_YN) {
    this.CHDN_DRV_YN = CHDN_DRV_YN;
    return this;
  }
  private String INSPE_TP_CD;
  public String get_INSPE_TP_CD() {
    return INSPE_TP_CD;
  }
  public void set_INSPE_TP_CD(String INSPE_TP_CD) {
    this.INSPE_TP_CD = INSPE_TP_CD;
  }
  public QueryResult with_INSPE_TP_CD(String INSPE_TP_CD) {
    this.INSPE_TP_CD = INSPE_TP_CD;
    return this;
  }
  private String POL_RCGPE_YN;
  public String get_POL_RCGPE_YN() {
    return POL_RCGPE_YN;
  }
  public void set_POL_RCGPE_YN(String POL_RCGPE_YN) {
    this.POL_RCGPE_YN = POL_RCGPE_YN;
  }
  public QueryResult with_POL_RCGPE_YN(String POL_RCGPE_YN) {
    this.POL_RCGPE_YN = POL_RCGPE_YN;
    return this;
  }
  private String HAPE_EMP_DIV_CD;
  public String get_HAPE_EMP_DIV_CD() {
    return HAPE_EMP_DIV_CD;
  }
  public void set_HAPE_EMP_DIV_CD(String HAPE_EMP_DIV_CD) {
    this.HAPE_EMP_DIV_CD = HAPE_EMP_DIV_CD;
  }
  public QueryResult with_HAPE_EMP_DIV_CD(String HAPE_EMP_DIV_CD) {
    this.HAPE_EMP_DIV_CD = HAPE_EMP_DIV_CD;
    return this;
  }
  private String HAPE_AGE_SIC_DIV_CD;
  public String get_HAPE_AGE_SIC_DIV_CD() {
    return HAPE_AGE_SIC_DIV_CD;
  }
  public void set_HAPE_AGE_SIC_DIV_CD(String HAPE_AGE_SIC_DIV_CD) {
    this.HAPE_AGE_SIC_DIV_CD = HAPE_AGE_SIC_DIV_CD;
  }
  public QueryResult with_HAPE_AGE_SIC_DIV_CD(String HAPE_AGE_SIC_DIV_CD) {
    this.HAPE_AGE_SIC_DIV_CD = HAPE_AGE_SIC_DIV_CD;
    return this;
  }
  private String LCNS_DIV_CD;
  public String get_LCNS_DIV_CD() {
    return LCNS_DIV_CD;
  }
  public void set_LCNS_DIV_CD(String LCNS_DIV_CD) {
    this.LCNS_DIV_CD = LCNS_DIV_CD;
  }
  public QueryResult with_LCNS_DIV_CD(String LCNS_DIV_CD) {
    this.LCNS_DIV_CD = LCNS_DIV_CD;
    return this;
  }
  private String LCNS_NO;
  public String get_LCNS_NO() {
    return LCNS_NO;
  }
  public void set_LCNS_NO(String LCNS_NO) {
    this.LCNS_NO = LCNS_NO;
  }
  public QueryResult with_LCNS_NO(String LCNS_NO) {
    this.LCNS_NO = LCNS_NO;
    return this;
  }
  private java.sql.Timestamp LCNS_DLV_DT;
  public java.sql.Timestamp get_LCNS_DLV_DT() {
    return LCNS_DLV_DT;
  }
  public void set_LCNS_DLV_DT(java.sql.Timestamp LCNS_DLV_DT) {
    this.LCNS_DLV_DT = LCNS_DLV_DT;
  }
  public QueryResult with_LCNS_DLV_DT(java.sql.Timestamp LCNS_DLV_DT) {
    this.LCNS_DLV_DT = LCNS_DLV_DT;
    return this;
  }
  private java.sql.Timestamp ENTCO_DT;
  public java.sql.Timestamp get_ENTCO_DT() {
    return ENTCO_DT;
  }
  public void set_ENTCO_DT(java.sql.Timestamp ENTCO_DT) {
    this.ENTCO_DT = ENTCO_DT;
  }
  public QueryResult with_ENTCO_DT(java.sql.Timestamp ENTCO_DT) {
    this.ENTCO_DT = ENTCO_DT;
    return this;
  }
  private String ATL_CTR_ID;
  public String get_ATL_CTR_ID() {
    return ATL_CTR_ID;
  }
  public void set_ATL_CTR_ID(String ATL_CTR_ID) {
    this.ATL_CTR_ID = ATL_CTR_ID;
  }
  public QueryResult with_ATL_CTR_ID(String ATL_CTR_ID) {
    this.ATL_CTR_ID = ATL_CTR_ID;
    return this;
  }
  private java.math.BigDecimal ATL_CTR_PTY_SEQ;
  public java.math.BigDecimal get_ATL_CTR_PTY_SEQ() {
    return ATL_CTR_PTY_SEQ;
  }
  public void set_ATL_CTR_PTY_SEQ(java.math.BigDecimal ATL_CTR_PTY_SEQ) {
    this.ATL_CTR_PTY_SEQ = ATL_CTR_PTY_SEQ;
  }
  public QueryResult with_ATL_CTR_PTY_SEQ(java.math.BigDecimal ATL_CTR_PTY_SEQ) {
    this.ATL_CTR_PTY_SEQ = ATL_CTR_PTY_SEQ;
    return this;
  }
  private java.math.BigDecimal ATL_HIS_SEQ;
  public java.math.BigDecimal get_ATL_HIS_SEQ() {
    return ATL_HIS_SEQ;
  }
  public void set_ATL_HIS_SEQ(java.math.BigDecimal ATL_HIS_SEQ) {
    this.ATL_HIS_SEQ = ATL_HIS_SEQ;
  }
  public QueryResult with_ATL_HIS_SEQ(java.math.BigDecimal ATL_HIS_SEQ) {
    this.ATL_HIS_SEQ = ATL_HIS_SEQ;
    return this;
  }
  private java.math.BigDecimal ENDR_NO;
  public java.math.BigDecimal get_ENDR_NO() {
    return ENDR_NO;
  }
  public void set_ENDR_NO(java.math.BigDecimal ENDR_NO) {
    this.ENDR_NO = ENDR_NO;
  }
  public QueryResult with_ENDR_NO(java.math.BigDecimal ENDR_NO) {
    this.ENDR_NO = ENDR_NO;
    return this;
  }
  private java.math.BigDecimal RTRO_ENDR_NO;
  public java.math.BigDecimal get_RTRO_ENDR_NO() {
    return RTRO_ENDR_NO;
  }
  public void set_RTRO_ENDR_NO(java.math.BigDecimal RTRO_ENDR_NO) {
    this.RTRO_ENDR_NO = RTRO_ENDR_NO;
  }
  public QueryResult with_RTRO_ENDR_NO(java.math.BigDecimal RTRO_ENDR_NO) {
    this.RTRO_ENDR_NO = RTRO_ENDR_NO;
    return this;
  }
  private java.math.BigDecimal ENDR_HIS_ST_NO;
  public java.math.BigDecimal get_ENDR_HIS_ST_NO() {
    return ENDR_HIS_ST_NO;
  }
  public void set_ENDR_HIS_ST_NO(java.math.BigDecimal ENDR_HIS_ST_NO) {
    this.ENDR_HIS_ST_NO = ENDR_HIS_ST_NO;
  }
  public QueryResult with_ENDR_HIS_ST_NO(java.math.BigDecimal ENDR_HIS_ST_NO) {
    this.ENDR_HIS_ST_NO = ENDR_HIS_ST_NO;
    return this;
  }
  private java.math.BigDecimal ENDR_HIS_ED_NO;
  public java.math.BigDecimal get_ENDR_HIS_ED_NO() {
    return ENDR_HIS_ED_NO;
  }
  public void set_ENDR_HIS_ED_NO(java.math.BigDecimal ENDR_HIS_ED_NO) {
    this.ENDR_HIS_ED_NO = ENDR_HIS_ED_NO;
  }
  public QueryResult with_ENDR_HIS_ED_NO(java.math.BigDecimal ENDR_HIS_ED_NO) {
    this.ENDR_HIS_ED_NO = ENDR_HIS_ED_NO;
    return this;
  }
  private java.sql.Timestamp SUMUP_DT;
  public java.sql.Timestamp get_SUMUP_DT() {
    return SUMUP_DT;
  }
  public void set_SUMUP_DT(java.sql.Timestamp SUMUP_DT) {
    this.SUMUP_DT = SUMUP_DT;
  }
  public QueryResult with_SUMUP_DT(java.sql.Timestamp SUMUP_DT) {
    this.SUMUP_DT = SUMUP_DT;
    return this;
  }
  private java.sql.Timestamp HIS_ST_DT;
  public java.sql.Timestamp get_HIS_ST_DT() {
    return HIS_ST_DT;
  }
  public void set_HIS_ST_DT(java.sql.Timestamp HIS_ST_DT) {
    this.HIS_ST_DT = HIS_ST_DT;
  }
  public QueryResult with_HIS_ST_DT(java.sql.Timestamp HIS_ST_DT) {
    this.HIS_ST_DT = HIS_ST_DT;
    return this;
  }
  private java.sql.Timestamp HIS_ED_DT;
  public java.sql.Timestamp get_HIS_ED_DT() {
    return HIS_ED_DT;
  }
  public void set_HIS_ED_DT(java.sql.Timestamp HIS_ED_DT) {
    this.HIS_ED_DT = HIS_ED_DT;
  }
  public QueryResult with_HIS_ED_DT(java.sql.Timestamp HIS_ED_DT) {
    this.HIS_ED_DT = HIS_ED_DT;
    return this;
  }
  private String INPPE_ORG_ID;
  public String get_INPPE_ORG_ID() {
    return INPPE_ORG_ID;
  }
  public void set_INPPE_ORG_ID(String INPPE_ORG_ID) {
    this.INPPE_ORG_ID = INPPE_ORG_ID;
  }
  public QueryResult with_INPPE_ORG_ID(String INPPE_ORG_ID) {
    this.INPPE_ORG_ID = INPPE_ORG_ID;
    return this;
  }
  private java.sql.Timestamp SYS_OCC_DTM;
  public java.sql.Timestamp get_SYS_OCC_DTM() {
    return SYS_OCC_DTM;
  }
  public void set_SYS_OCC_DTM(java.sql.Timestamp SYS_OCC_DTM) {
    this.SYS_OCC_DTM = SYS_OCC_DTM;
  }
  public QueryResult with_SYS_OCC_DTM(java.sql.Timestamp SYS_OCC_DTM) {
    this.SYS_OCC_DTM = SYS_OCC_DTM;
    return this;
  }
  private String SYS_DEL_DIV_CD;
  public String get_SYS_DEL_DIV_CD() {
    return SYS_DEL_DIV_CD;
  }
  public void set_SYS_DEL_DIV_CD(String SYS_DEL_DIV_CD) {
    this.SYS_DEL_DIV_CD = SYS_DEL_DIV_CD;
  }
  public QueryResult with_SYS_DEL_DIV_CD(String SYS_DEL_DIV_CD) {
    this.SYS_DEL_DIV_CD = SYS_DEL_DIV_CD;
    return this;
  }
  private String OCC_IP;
  public String get_OCC_IP() {
    return OCC_IP;
  }
  public void set_OCC_IP(String OCC_IP) {
    this.OCC_IP = OCC_IP;
  }
  public QueryResult with_OCC_IP(String OCC_IP) {
    this.OCC_IP = OCC_IP;
    return this;
  }
  private String APP_ID;
  public String get_APP_ID() {
    return APP_ID;
  }
  public void set_APP_ID(String APP_ID) {
    this.APP_ID = APP_ID;
  }
  public QueryResult with_APP_ID(String APP_ID) {
    this.APP_ID = APP_ID;
    return this;
  }
  private java.sql.Timestamp DATA_CHNG_DTM;
  public java.sql.Timestamp get_DATA_CHNG_DTM() {
    return DATA_CHNG_DTM;
  }
  public void set_DATA_CHNG_DTM(java.sql.Timestamp DATA_CHNG_DTM) {
    this.DATA_CHNG_DTM = DATA_CHNG_DTM;
  }
  public QueryResult with_DATA_CHNG_DTM(java.sql.Timestamp DATA_CHNG_DTM) {
    this.DATA_CHNG_DTM = DATA_CHNG_DTM;
    return this;
  }
  private String DSC_CON;
  public String get_DSC_CON() {
    return DSC_CON;
  }
  public void set_DSC_CON(String DSC_CON) {
    this.DSC_CON = DSC_CON;
  }
  public QueryResult with_DSC_CON(String DSC_CON) {
    this.DSC_CON = DSC_CON;
    return this;
  }
  private String RNM_CNF_KD_CD;
  public String get_RNM_CNF_KD_CD() {
    return RNM_CNF_KD_CD;
  }
  public void set_RNM_CNF_KD_CD(String RNM_CNF_KD_CD) {
    this.RNM_CNF_KD_CD = RNM_CNF_KD_CD;
  }
  public QueryResult with_RNM_CNF_KD_CD(String RNM_CNF_KD_CD) {
    this.RNM_CNF_KD_CD = RNM_CNF_KD_CD;
    return this;
  }
  private java.sql.Timestamp IDF_ATH_CHT_ISS_DT;
  public java.sql.Timestamp get_IDF_ATH_CHT_ISS_DT() {
    return IDF_ATH_CHT_ISS_DT;
  }
  public void set_IDF_ATH_CHT_ISS_DT(java.sql.Timestamp IDF_ATH_CHT_ISS_DT) {
    this.IDF_ATH_CHT_ISS_DT = IDF_ATH_CHT_ISS_DT;
  }
  public QueryResult with_IDF_ATH_CHT_ISS_DT(java.sql.Timestamp IDF_ATH_CHT_ISS_DT) {
    this.IDF_ATH_CHT_ISS_DT = IDF_ATH_CHT_ISS_DT;
    return this;
  }
  private String ISS_INST_NM;
  public String get_ISS_INST_NM() {
    return ISS_INST_NM;
  }
  public void set_ISS_INST_NM(String ISS_INST_NM) {
    this.ISS_INST_NM = ISS_INST_NM;
  }
  public QueryResult with_ISS_INST_NM(String ISS_INST_NM) {
    this.ISS_INST_NM = ISS_INST_NM;
    return this;
  }
  private String ADDTL_REF_NO;
  public String get_ADDTL_REF_NO() {
    return ADDTL_REF_NO;
  }
  public void set_ADDTL_REF_NO(String ADDTL_REF_NO) {
    this.ADDTL_REF_NO = ADDTL_REF_NO;
  }
  public QueryResult with_ADDTL_REF_NO(String ADDTL_REF_NO) {
    this.ADDTL_REF_NO = ADDTL_REF_NO;
    return this;
  }
  private String RNM_ATH_FNM;
  public String get_RNM_ATH_FNM() {
    return RNM_ATH_FNM;
  }
  public void set_RNM_ATH_FNM(String RNM_ATH_FNM) {
    this.RNM_ATH_FNM = RNM_ATH_FNM;
  }
  public QueryResult with_RNM_ATH_FNM(String RNM_ATH_FNM) {
    this.RNM_ATH_FNM = RNM_ATH_FNM;
    return this;
  }
  private java.sql.Timestamp EIH_LDG_DTM;
  public java.sql.Timestamp get_EIH_LDG_DTM() {
    return EIH_LDG_DTM;
  }
  public void set_EIH_LDG_DTM(java.sql.Timestamp EIH_LDG_DTM) {
    this.EIH_LDG_DTM = EIH_LDG_DTM;
  }
  public QueryResult with_EIH_LDG_DTM(java.sql.Timestamp EIH_LDG_DTM) {
    this.EIH_LDG_DTM = EIH_LDG_DTM;
    return this;
  }
  private String KIS_ETP_CD;
  public String get_KIS_ETP_CD() {
    return KIS_ETP_CD;
  }
  public void set_KIS_ETP_CD(String KIS_ETP_CD) {
    this.KIS_ETP_CD = KIS_ETP_CD;
  }
  public QueryResult with_KIS_ETP_CD(String KIS_ETP_CD) {
    this.KIS_ETP_CD = KIS_ETP_CD;
    return this;
  }
  private java.sql.Timestamp APL_ST_DT;
  public java.sql.Timestamp get_APL_ST_DT() {
    return APL_ST_DT;
  }
  public void set_APL_ST_DT(java.sql.Timestamp APL_ST_DT) {
    this.APL_ST_DT = APL_ST_DT;
  }
  public QueryResult with_APL_ST_DT(java.sql.Timestamp APL_ST_DT) {
    this.APL_ST_DT = APL_ST_DT;
    return this;
  }
  private java.sql.Timestamp APL_ED_DT;
  public java.sql.Timestamp get_APL_ED_DT() {
    return APL_ED_DT;
  }
  public void set_APL_ED_DT(java.sql.Timestamp APL_ED_DT) {
    this.APL_ED_DT = APL_ED_DT;
  }
  public QueryResult with_APL_ED_DT(java.sql.Timestamp APL_ED_DT) {
    this.APL_ED_DT = APL_ED_DT;
    return this;
  }
  private java.sql.Timestamp HNC_REG_ED_DT;
  public java.sql.Timestamp get_HNC_REG_ED_DT() {
    return HNC_REG_ED_DT;
  }
  public void set_HNC_REG_ED_DT(java.sql.Timestamp HNC_REG_ED_DT) {
    this.HNC_REG_ED_DT = HNC_REG_ED_DT;
  }
  public QueryResult with_HNC_REG_ED_DT(java.sql.Timestamp HNC_REG_ED_DT) {
    this.HNC_REG_ED_DT = HNC_REG_ED_DT;
    return this;
  }
  private String HNCPE_CTR_YN;
  public String get_HNCPE_CTR_YN() {
    return HNCPE_CTR_YN;
  }
  public void set_HNCPE_CTR_YN(String HNCPE_CTR_YN) {
    this.HNCPE_CTR_YN = HNCPE_CTR_YN;
  }
  public QueryResult with_HNCPE_CTR_YN(String HNCPE_CTR_YN) {
    this.HNCPE_CTR_YN = HNCPE_CTR_YN;
    return this;
  }
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (!(o instanceof QueryResult)) {
      return false;
    }
    QueryResult that = (QueryResult) o;
    boolean equal = true;
    equal = equal && (this.CTR_ID == null ? that.CTR_ID == null : this.CTR_ID.equals(that.CTR_ID));
    equal = equal && (this.CTR_PTY_SEQ == null ? that.CTR_PTY_SEQ == null : this.CTR_PTY_SEQ.equals(that.CTR_PTY_SEQ));
    equal = equal && (this.HIS_SEQ == null ? that.HIS_SEQ == null : this.HIS_SEQ.equals(that.HIS_SEQ));
    equal = equal && (this.BIZ_SYS_CD == null ? that.BIZ_SYS_CD == null : this.BIZ_SYS_CD.equals(that.BIZ_SYS_CD));
    equal = equal && (this.PRCTR_NO == null ? that.PRCTR_NO == null : this.PRCTR_NO.equals(that.PRCTR_NO));
    equal = equal && (this.RL_APL_RNG_DIV_CD == null ? that.RL_APL_RNG_DIV_CD == null : this.RL_APL_RNG_DIV_CD.equals(that.RL_APL_RNG_DIV_CD));
    equal = equal && (this.DATA_ID == null ? that.DATA_ID == null : this.DATA_ID.equals(that.DATA_ID));
    equal = equal && (this.DATA_SEQ == null ? that.DATA_SEQ == null : this.DATA_SEQ.equals(that.DATA_SEQ));
    equal = equal && (this.CTR_PTY_RL_CD == null ? that.CTR_PTY_RL_CD == null : this.CTR_PTY_RL_CD.equals(that.CTR_PTY_RL_CD));
    equal = equal && (this.PTY_DIV_CD == null ? that.PTY_DIV_CD == null : this.PTY_DIV_CD.equals(that.PTY_DIV_CD));
    equal = equal && (this.PTY_ID == null ? that.PTY_ID == null : this.PTY_ID.equals(that.PTY_ID));
    equal = equal && (this.CUS_NO == null ? that.CUS_NO == null : this.CUS_NO.equals(that.CUS_NO));
    equal = equal && (this.CUS_BCH_NO == null ? that.CUS_BCH_NO == null : this.CUS_BCH_NO.equals(that.CUS_BCH_NO));
    equal = equal && (this.RL_RTO == null ? that.RL_RTO == null : this.RL_RTO.equals(that.RL_RTO));
    equal = equal && (this.RL_REL_CD == null ? that.RL_REL_CD == null : this.RL_REL_CD.equals(that.RL_REL_CD));
    equal = equal && (this.REL_PTY_RL_CD == null ? that.REL_PTY_RL_CD == null : this.REL_PTY_RL_CD.equals(that.REL_PTY_RL_CD));
    equal = equal && (this.TXPF_REG_TRGPE_DIV_CD == null ? that.TXPF_REG_TRGPE_DIV_CD == null : this.TXPF_REG_TRGPE_DIV_CD.equals(that.TXPF_REG_TRGPE_DIV_CD));
    equal = equal && (this.POLHD_GRDE_CD == null ? that.POLHD_GRDE_CD == null : this.POLHD_GRDE_CD.equals(that.POLHD_GRDE_CD));
    equal = equal && (this.POLHD_CHNG_RSN_CD == null ? that.POLHD_CHNG_RSN_CD == null : this.POLHD_CHNG_RSN_CD.equals(that.POLHD_CHNG_RSN_CD));
    equal = equal && (this.DTL_ADJT_CD == null ? that.DTL_ADJT_CD == null : this.DTL_ADJT_CD.equals(that.DTL_ADJT_CD));
    equal = equal && (this.RPS_CTR_PTY_YN == null ? that.RPS_CTR_PTY_YN == null : this.RPS_CTR_PTY_YN.equals(that.RPS_CTR_PTY_YN));
    equal = equal && (this.GNR_POLHD_DIV_CD == null ? that.GNR_POLHD_DIV_CD == null : this.GNR_POLHD_DIV_CD.equals(that.GNR_POLHD_DIV_CD));
    equal = equal && (this.RLSIT_NRMN_CD == null ? that.RLSIT_NRMN_CD == null : this.RLSIT_NRMN_CD.equals(that.RLSIT_NRMN_CD));
    equal = equal && (this.AGE == null ? that.AGE == null : this.AGE.equals(that.AGE));
    equal = equal && (this.NKNM == null ? that.NKNM == null : this.NKNM.equals(that.NKNM));
    equal = equal && (this.ADDTL_FM_NM == null ? that.ADDTL_FM_NM == null : this.ADDTL_FM_NM.equals(that.ADDTL_FM_NM));
    equal = equal && (this.POL_RCEPL_DIV_CD == null ? that.POL_RCEPL_DIV_CD == null : this.POL_RCEPL_DIV_CD.equals(that.POL_RCEPL_DIV_CD));
    equal = equal && (this.DM_SNDPL_DIV_CD == null ? that.DM_SNDPL_DIV_CD == null : this.DM_SNDPL_DIV_CD.equals(that.DM_SNDPL_DIV_CD));
    equal = equal && (this.CMC_MN_TMN_AGR_YN == null ? that.CMC_MN_TMN_AGR_YN == null : this.CMC_MN_TMN_AGR_YN.equals(that.CMC_MN_TMN_AGR_YN));
    equal = equal && (this.PTY_IDF_INF_SEQ == null ? that.PTY_IDF_INF_SEQ == null : this.PTY_IDF_INF_SEQ.equals(that.PTY_IDF_INF_SEQ));
    equal = equal && (this.PSSPE_CD == null ? that.PSSPE_CD == null : this.PSSPE_CD.equals(that.PSSPE_CD));
    equal = equal && (this.JOB_CD == null ? that.JOB_CD == null : this.JOB_CD.equals(that.JOB_CD));
    equal = equal && (this.JOB_GRD_CD == null ? that.JOB_GRD_CD == null : this.JOB_GRD_CD.equals(that.JOB_GRD_CD));
    equal = equal && (this.MARY_YN == null ? that.MARY_YN == null : this.MARY_YN.equals(that.MARY_YN));
    equal = equal && (this.CHDN_DRV_YN == null ? that.CHDN_DRV_YN == null : this.CHDN_DRV_YN.equals(that.CHDN_DRV_YN));
    equal = equal && (this.INSPE_TP_CD == null ? that.INSPE_TP_CD == null : this.INSPE_TP_CD.equals(that.INSPE_TP_CD));
    equal = equal && (this.POL_RCGPE_YN == null ? that.POL_RCGPE_YN == null : this.POL_RCGPE_YN.equals(that.POL_RCGPE_YN));
    equal = equal && (this.HAPE_EMP_DIV_CD == null ? that.HAPE_EMP_DIV_CD == null : this.HAPE_EMP_DIV_CD.equals(that.HAPE_EMP_DIV_CD));
    equal = equal && (this.HAPE_AGE_SIC_DIV_CD == null ? that.HAPE_AGE_SIC_DIV_CD == null : this.HAPE_AGE_SIC_DIV_CD.equals(that.HAPE_AGE_SIC_DIV_CD));
    equal = equal && (this.LCNS_DIV_CD == null ? that.LCNS_DIV_CD == null : this.LCNS_DIV_CD.equals(that.LCNS_DIV_CD));
    equal = equal && (this.LCNS_NO == null ? that.LCNS_NO == null : this.LCNS_NO.equals(that.LCNS_NO));
    equal = equal && (this.LCNS_DLV_DT == null ? that.LCNS_DLV_DT == null : this.LCNS_DLV_DT.equals(that.LCNS_DLV_DT));
    equal = equal && (this.ENTCO_DT == null ? that.ENTCO_DT == null : this.ENTCO_DT.equals(that.ENTCO_DT));
    equal = equal && (this.ATL_CTR_ID == null ? that.ATL_CTR_ID == null : this.ATL_CTR_ID.equals(that.ATL_CTR_ID));
    equal = equal && (this.ATL_CTR_PTY_SEQ == null ? that.ATL_CTR_PTY_SEQ == null : this.ATL_CTR_PTY_SEQ.equals(that.ATL_CTR_PTY_SEQ));
    equal = equal && (this.ATL_HIS_SEQ == null ? that.ATL_HIS_SEQ == null : this.ATL_HIS_SEQ.equals(that.ATL_HIS_SEQ));
    equal = equal && (this.ENDR_NO == null ? that.ENDR_NO == null : this.ENDR_NO.equals(that.ENDR_NO));
    equal = equal && (this.RTRO_ENDR_NO == null ? that.RTRO_ENDR_NO == null : this.RTRO_ENDR_NO.equals(that.RTRO_ENDR_NO));
    equal = equal && (this.ENDR_HIS_ST_NO == null ? that.ENDR_HIS_ST_NO == null : this.ENDR_HIS_ST_NO.equals(that.ENDR_HIS_ST_NO));
    equal = equal && (this.ENDR_HIS_ED_NO == null ? that.ENDR_HIS_ED_NO == null : this.ENDR_HIS_ED_NO.equals(that.ENDR_HIS_ED_NO));
    equal = equal && (this.SUMUP_DT == null ? that.SUMUP_DT == null : this.SUMUP_DT.equals(that.SUMUP_DT));
    equal = equal && (this.HIS_ST_DT == null ? that.HIS_ST_DT == null : this.HIS_ST_DT.equals(that.HIS_ST_DT));
    equal = equal && (this.HIS_ED_DT == null ? that.HIS_ED_DT == null : this.HIS_ED_DT.equals(that.HIS_ED_DT));
    equal = equal && (this.INPPE_ORG_ID == null ? that.INPPE_ORG_ID == null : this.INPPE_ORG_ID.equals(that.INPPE_ORG_ID));
    equal = equal && (this.SYS_OCC_DTM == null ? that.SYS_OCC_DTM == null : this.SYS_OCC_DTM.equals(that.SYS_OCC_DTM));
    equal = equal && (this.SYS_DEL_DIV_CD == null ? that.SYS_DEL_DIV_CD == null : this.SYS_DEL_DIV_CD.equals(that.SYS_DEL_DIV_CD));
    equal = equal && (this.OCC_IP == null ? that.OCC_IP == null : this.OCC_IP.equals(that.OCC_IP));
    equal = equal && (this.APP_ID == null ? that.APP_ID == null : this.APP_ID.equals(that.APP_ID));
    equal = equal && (this.DATA_CHNG_DTM == null ? that.DATA_CHNG_DTM == null : this.DATA_CHNG_DTM.equals(that.DATA_CHNG_DTM));
    equal = equal && (this.DSC_CON == null ? that.DSC_CON == null : this.DSC_CON.equals(that.DSC_CON));
    equal = equal && (this.RNM_CNF_KD_CD == null ? that.RNM_CNF_KD_CD == null : this.RNM_CNF_KD_CD.equals(that.RNM_CNF_KD_CD));
    equal = equal && (this.IDF_ATH_CHT_ISS_DT == null ? that.IDF_ATH_CHT_ISS_DT == null : this.IDF_ATH_CHT_ISS_DT.equals(that.IDF_ATH_CHT_ISS_DT));
    equal = equal && (this.ISS_INST_NM == null ? that.ISS_INST_NM == null : this.ISS_INST_NM.equals(that.ISS_INST_NM));
    equal = equal && (this.ADDTL_REF_NO == null ? that.ADDTL_REF_NO == null : this.ADDTL_REF_NO.equals(that.ADDTL_REF_NO));
    equal = equal && (this.RNM_ATH_FNM == null ? that.RNM_ATH_FNM == null : this.RNM_ATH_FNM.equals(that.RNM_ATH_FNM));
    equal = equal && (this.EIH_LDG_DTM == null ? that.EIH_LDG_DTM == null : this.EIH_LDG_DTM.equals(that.EIH_LDG_DTM));
    equal = equal && (this.KIS_ETP_CD == null ? that.KIS_ETP_CD == null : this.KIS_ETP_CD.equals(that.KIS_ETP_CD));
    equal = equal && (this.APL_ST_DT == null ? that.APL_ST_DT == null : this.APL_ST_DT.equals(that.APL_ST_DT));
    equal = equal && (this.APL_ED_DT == null ? that.APL_ED_DT == null : this.APL_ED_DT.equals(that.APL_ED_DT));
    equal = equal && (this.HNC_REG_ED_DT == null ? that.HNC_REG_ED_DT == null : this.HNC_REG_ED_DT.equals(that.HNC_REG_ED_DT));
    equal = equal && (this.HNCPE_CTR_YN == null ? that.HNCPE_CTR_YN == null : this.HNCPE_CTR_YN.equals(that.HNCPE_CTR_YN));
    return equal;
  }
  public boolean equals0(Object o) {
    if (this == o) {
      return true;
    }
    if (!(o instanceof QueryResult)) {
      return false;
    }
    QueryResult that = (QueryResult) o;
    boolean equal = true;
    equal = equal && (this.CTR_ID == null ? that.CTR_ID == null : this.CTR_ID.equals(that.CTR_ID));
    equal = equal && (this.CTR_PTY_SEQ == null ? that.CTR_PTY_SEQ == null : this.CTR_PTY_SEQ.equals(that.CTR_PTY_SEQ));
    equal = equal && (this.HIS_SEQ == null ? that.HIS_SEQ == null : this.HIS_SEQ.equals(that.HIS_SEQ));
    equal = equal && (this.BIZ_SYS_CD == null ? that.BIZ_SYS_CD == null : this.BIZ_SYS_CD.equals(that.BIZ_SYS_CD));
    equal = equal && (this.PRCTR_NO == null ? that.PRCTR_NO == null : this.PRCTR_NO.equals(that.PRCTR_NO));
    equal = equal && (this.RL_APL_RNG_DIV_CD == null ? that.RL_APL_RNG_DIV_CD == null : this.RL_APL_RNG_DIV_CD.equals(that.RL_APL_RNG_DIV_CD));
    equal = equal && (this.DATA_ID == null ? that.DATA_ID == null : this.DATA_ID.equals(that.DATA_ID));
    equal = equal && (this.DATA_SEQ == null ? that.DATA_SEQ == null : this.DATA_SEQ.equals(that.DATA_SEQ));
    equal = equal && (this.CTR_PTY_RL_CD == null ? that.CTR_PTY_RL_CD == null : this.CTR_PTY_RL_CD.equals(that.CTR_PTY_RL_CD));
    equal = equal && (this.PTY_DIV_CD == null ? that.PTY_DIV_CD == null : this.PTY_DIV_CD.equals(that.PTY_DIV_CD));
    equal = equal && (this.PTY_ID == null ? that.PTY_ID == null : this.PTY_ID.equals(that.PTY_ID));
    equal = equal && (this.CUS_NO == null ? that.CUS_NO == null : this.CUS_NO.equals(that.CUS_NO));
    equal = equal && (this.CUS_BCH_NO == null ? that.CUS_BCH_NO == null : this.CUS_BCH_NO.equals(that.CUS_BCH_NO));
    equal = equal && (this.RL_RTO == null ? that.RL_RTO == null : this.RL_RTO.equals(that.RL_RTO));
    equal = equal && (this.RL_REL_CD == null ? that.RL_REL_CD == null : this.RL_REL_CD.equals(that.RL_REL_CD));
    equal = equal && (this.REL_PTY_RL_CD == null ? that.REL_PTY_RL_CD == null : this.REL_PTY_RL_CD.equals(that.REL_PTY_RL_CD));
    equal = equal && (this.TXPF_REG_TRGPE_DIV_CD == null ? that.TXPF_REG_TRGPE_DIV_CD == null : this.TXPF_REG_TRGPE_DIV_CD.equals(that.TXPF_REG_TRGPE_DIV_CD));
    equal = equal && (this.POLHD_GRDE_CD == null ? that.POLHD_GRDE_CD == null : this.POLHD_GRDE_CD.equals(that.POLHD_GRDE_CD));
    equal = equal && (this.POLHD_CHNG_RSN_CD == null ? that.POLHD_CHNG_RSN_CD == null : this.POLHD_CHNG_RSN_CD.equals(that.POLHD_CHNG_RSN_CD));
    equal = equal && (this.DTL_ADJT_CD == null ? that.DTL_ADJT_CD == null : this.DTL_ADJT_CD.equals(that.DTL_ADJT_CD));
    equal = equal && (this.RPS_CTR_PTY_YN == null ? that.RPS_CTR_PTY_YN == null : this.RPS_CTR_PTY_YN.equals(that.RPS_CTR_PTY_YN));
    equal = equal && (this.GNR_POLHD_DIV_CD == null ? that.GNR_POLHD_DIV_CD == null : this.GNR_POLHD_DIV_CD.equals(that.GNR_POLHD_DIV_CD));
    equal = equal && (this.RLSIT_NRMN_CD == null ? that.RLSIT_NRMN_CD == null : this.RLSIT_NRMN_CD.equals(that.RLSIT_NRMN_CD));
    equal = equal && (this.AGE == null ? that.AGE == null : this.AGE.equals(that.AGE));
    equal = equal && (this.NKNM == null ? that.NKNM == null : this.NKNM.equals(that.NKNM));
    equal = equal && (this.ADDTL_FM_NM == null ? that.ADDTL_FM_NM == null : this.ADDTL_FM_NM.equals(that.ADDTL_FM_NM));
    equal = equal && (this.POL_RCEPL_DIV_CD == null ? that.POL_RCEPL_DIV_CD == null : this.POL_RCEPL_DIV_CD.equals(that.POL_RCEPL_DIV_CD));
    equal = equal && (this.DM_SNDPL_DIV_CD == null ? that.DM_SNDPL_DIV_CD == null : this.DM_SNDPL_DIV_CD.equals(that.DM_SNDPL_DIV_CD));
    equal = equal && (this.CMC_MN_TMN_AGR_YN == null ? that.CMC_MN_TMN_AGR_YN == null : this.CMC_MN_TMN_AGR_YN.equals(that.CMC_MN_TMN_AGR_YN));
    equal = equal && (this.PTY_IDF_INF_SEQ == null ? that.PTY_IDF_INF_SEQ == null : this.PTY_IDF_INF_SEQ.equals(that.PTY_IDF_INF_SEQ));
    equal = equal && (this.PSSPE_CD == null ? that.PSSPE_CD == null : this.PSSPE_CD.equals(that.PSSPE_CD));
    equal = equal && (this.JOB_CD == null ? that.JOB_CD == null : this.JOB_CD.equals(that.JOB_CD));
    equal = equal && (this.JOB_GRD_CD == null ? that.JOB_GRD_CD == null : this.JOB_GRD_CD.equals(that.JOB_GRD_CD));
    equal = equal && (this.MARY_YN == null ? that.MARY_YN == null : this.MARY_YN.equals(that.MARY_YN));
    equal = equal && (this.CHDN_DRV_YN == null ? that.CHDN_DRV_YN == null : this.CHDN_DRV_YN.equals(that.CHDN_DRV_YN));
    equal = equal && (this.INSPE_TP_CD == null ? that.INSPE_TP_CD == null : this.INSPE_TP_CD.equals(that.INSPE_TP_CD));
    equal = equal && (this.POL_RCGPE_YN == null ? that.POL_RCGPE_YN == null : this.POL_RCGPE_YN.equals(that.POL_RCGPE_YN));
    equal = equal && (this.HAPE_EMP_DIV_CD == null ? that.HAPE_EMP_DIV_CD == null : this.HAPE_EMP_DIV_CD.equals(that.HAPE_EMP_DIV_CD));
    equal = equal && (this.HAPE_AGE_SIC_DIV_CD == null ? that.HAPE_AGE_SIC_DIV_CD == null : this.HAPE_AGE_SIC_DIV_CD.equals(that.HAPE_AGE_SIC_DIV_CD));
    equal = equal && (this.LCNS_DIV_CD == null ? that.LCNS_DIV_CD == null : this.LCNS_DIV_CD.equals(that.LCNS_DIV_CD));
    equal = equal && (this.LCNS_NO == null ? that.LCNS_NO == null : this.LCNS_NO.equals(that.LCNS_NO));
    equal = equal && (this.LCNS_DLV_DT == null ? that.LCNS_DLV_DT == null : this.LCNS_DLV_DT.equals(that.LCNS_DLV_DT));
    equal = equal && (this.ENTCO_DT == null ? that.ENTCO_DT == null : this.ENTCO_DT.equals(that.ENTCO_DT));
    equal = equal && (this.ATL_CTR_ID == null ? that.ATL_CTR_ID == null : this.ATL_CTR_ID.equals(that.ATL_CTR_ID));
    equal = equal && (this.ATL_CTR_PTY_SEQ == null ? that.ATL_CTR_PTY_SEQ == null : this.ATL_CTR_PTY_SEQ.equals(that.ATL_CTR_PTY_SEQ));
    equal = equal && (this.ATL_HIS_SEQ == null ? that.ATL_HIS_SEQ == null : this.ATL_HIS_SEQ.equals(that.ATL_HIS_SEQ));
    equal = equal && (this.ENDR_NO == null ? that.ENDR_NO == null : this.ENDR_NO.equals(that.ENDR_NO));
    equal = equal && (this.RTRO_ENDR_NO == null ? that.RTRO_ENDR_NO == null : this.RTRO_ENDR_NO.equals(that.RTRO_ENDR_NO));
    equal = equal && (this.ENDR_HIS_ST_NO == null ? that.ENDR_HIS_ST_NO == null : this.ENDR_HIS_ST_NO.equals(that.ENDR_HIS_ST_NO));
    equal = equal && (this.ENDR_HIS_ED_NO == null ? that.ENDR_HIS_ED_NO == null : this.ENDR_HIS_ED_NO.equals(that.ENDR_HIS_ED_NO));
    equal = equal && (this.SUMUP_DT == null ? that.SUMUP_DT == null : this.SUMUP_DT.equals(that.SUMUP_DT));
    equal = equal && (this.HIS_ST_DT == null ? that.HIS_ST_DT == null : this.HIS_ST_DT.equals(that.HIS_ST_DT));
    equal = equal && (this.HIS_ED_DT == null ? that.HIS_ED_DT == null : this.HIS_ED_DT.equals(that.HIS_ED_DT));
    equal = equal && (this.INPPE_ORG_ID == null ? that.INPPE_ORG_ID == null : this.INPPE_ORG_ID.equals(that.INPPE_ORG_ID));
    equal = equal && (this.SYS_OCC_DTM == null ? that.SYS_OCC_DTM == null : this.SYS_OCC_DTM.equals(that.SYS_OCC_DTM));
    equal = equal && (this.SYS_DEL_DIV_CD == null ? that.SYS_DEL_DIV_CD == null : this.SYS_DEL_DIV_CD.equals(that.SYS_DEL_DIV_CD));
    equal = equal && (this.OCC_IP == null ? that.OCC_IP == null : this.OCC_IP.equals(that.OCC_IP));
    equal = equal && (this.APP_ID == null ? that.APP_ID == null : this.APP_ID.equals(that.APP_ID));
    equal = equal && (this.DATA_CHNG_DTM == null ? that.DATA_CHNG_DTM == null : this.DATA_CHNG_DTM.equals(that.DATA_CHNG_DTM));
    equal = equal && (this.DSC_CON == null ? that.DSC_CON == null : this.DSC_CON.equals(that.DSC_CON));
    equal = equal && (this.RNM_CNF_KD_CD == null ? that.RNM_CNF_KD_CD == null : this.RNM_CNF_KD_CD.equals(that.RNM_CNF_KD_CD));
    equal = equal && (this.IDF_ATH_CHT_ISS_DT == null ? that.IDF_ATH_CHT_ISS_DT == null : this.IDF_ATH_CHT_ISS_DT.equals(that.IDF_ATH_CHT_ISS_DT));
    equal = equal && (this.ISS_INST_NM == null ? that.ISS_INST_NM == null : this.ISS_INST_NM.equals(that.ISS_INST_NM));
    equal = equal && (this.ADDTL_REF_NO == null ? that.ADDTL_REF_NO == null : this.ADDTL_REF_NO.equals(that.ADDTL_REF_NO));
    equal = equal && (this.RNM_ATH_FNM == null ? that.RNM_ATH_FNM == null : this.RNM_ATH_FNM.equals(that.RNM_ATH_FNM));
    equal = equal && (this.EIH_LDG_DTM == null ? that.EIH_LDG_DTM == null : this.EIH_LDG_DTM.equals(that.EIH_LDG_DTM));
    equal = equal && (this.KIS_ETP_CD == null ? that.KIS_ETP_CD == null : this.KIS_ETP_CD.equals(that.KIS_ETP_CD));
    equal = equal && (this.APL_ST_DT == null ? that.APL_ST_DT == null : this.APL_ST_DT.equals(that.APL_ST_DT));
    equal = equal && (this.APL_ED_DT == null ? that.APL_ED_DT == null : this.APL_ED_DT.equals(that.APL_ED_DT));
    equal = equal && (this.HNC_REG_ED_DT == null ? that.HNC_REG_ED_DT == null : this.HNC_REG_ED_DT.equals(that.HNC_REG_ED_DT));
    equal = equal && (this.HNCPE_CTR_YN == null ? that.HNCPE_CTR_YN == null : this.HNCPE_CTR_YN.equals(that.HNCPE_CTR_YN));
    return equal;
  }
  public void readFields(ResultSet __dbResults) throws SQLException {
    this.__cur_result_set = __dbResults;
    this.CTR_ID = JdbcWritableBridge.readString(1, __dbResults);
    this.CTR_PTY_SEQ = JdbcWritableBridge.readBigDecimal(2, __dbResults);
    this.HIS_SEQ = JdbcWritableBridge.readBigDecimal(3, __dbResults);
    this.BIZ_SYS_CD = JdbcWritableBridge.readString(4, __dbResults);
    this.PRCTR_NO = JdbcWritableBridge.readString(5, __dbResults);
    this.RL_APL_RNG_DIV_CD = JdbcWritableBridge.readString(6, __dbResults);
    this.DATA_ID = JdbcWritableBridge.readString(7, __dbResults);
    this.DATA_SEQ = JdbcWritableBridge.readBigDecimal(8, __dbResults);
    this.CTR_PTY_RL_CD = JdbcWritableBridge.readString(9, __dbResults);
    this.PTY_DIV_CD = JdbcWritableBridge.readString(10, __dbResults);
    this.PTY_ID = JdbcWritableBridge.readString(11, __dbResults);
    this.CUS_NO = JdbcWritableBridge.readString(12, __dbResults);
    this.CUS_BCH_NO = JdbcWritableBridge.readString(13, __dbResults);
    this.RL_RTO = JdbcWritableBridge.readBigDecimal(14, __dbResults);
    this.RL_REL_CD = JdbcWritableBridge.readString(15, __dbResults);
    this.REL_PTY_RL_CD = JdbcWritableBridge.readString(16, __dbResults);
    this.TXPF_REG_TRGPE_DIV_CD = JdbcWritableBridge.readString(17, __dbResults);
    this.POLHD_GRDE_CD = JdbcWritableBridge.readString(18, __dbResults);
    this.POLHD_CHNG_RSN_CD = JdbcWritableBridge.readString(19, __dbResults);
    this.DTL_ADJT_CD = JdbcWritableBridge.readString(20, __dbResults);
    this.RPS_CTR_PTY_YN = JdbcWritableBridge.readString(21, __dbResults);
    this.GNR_POLHD_DIV_CD = JdbcWritableBridge.readString(22, __dbResults);
    this.RLSIT_NRMN_CD = JdbcWritableBridge.readString(23, __dbResults);
    this.AGE = JdbcWritableBridge.readBigDecimal(24, __dbResults);
    this.NKNM = JdbcWritableBridge.readString(25, __dbResults);
    this.ADDTL_FM_NM = JdbcWritableBridge.readString(26, __dbResults);
    this.POL_RCEPL_DIV_CD = JdbcWritableBridge.readString(27, __dbResults);
    this.DM_SNDPL_DIV_CD = JdbcWritableBridge.readString(28, __dbResults);
    this.CMC_MN_TMN_AGR_YN = JdbcWritableBridge.readString(29, __dbResults);
    this.PTY_IDF_INF_SEQ = JdbcWritableBridge.readBigDecimal(30, __dbResults);
    this.PSSPE_CD = JdbcWritableBridge.readString(31, __dbResults);
    this.JOB_CD = JdbcWritableBridge.readString(32, __dbResults);
    this.JOB_GRD_CD = JdbcWritableBridge.readString(33, __dbResults);
    this.MARY_YN = JdbcWritableBridge.readString(34, __dbResults);
    this.CHDN_DRV_YN = JdbcWritableBridge.readString(35, __dbResults);
    this.INSPE_TP_CD = JdbcWritableBridge.readString(36, __dbResults);
    this.POL_RCGPE_YN = JdbcWritableBridge.readString(37, __dbResults);
    this.HAPE_EMP_DIV_CD = JdbcWritableBridge.readString(38, __dbResults);
    this.HAPE_AGE_SIC_DIV_CD = JdbcWritableBridge.readString(39, __dbResults);
    this.LCNS_DIV_CD = JdbcWritableBridge.readString(40, __dbResults);
    this.LCNS_NO = JdbcWritableBridge.readString(41, __dbResults);
    this.LCNS_DLV_DT = JdbcWritableBridge.readTimestamp(42, __dbResults);
    this.ENTCO_DT = JdbcWritableBridge.readTimestamp(43, __dbResults);
    this.ATL_CTR_ID = JdbcWritableBridge.readString(44, __dbResults);
    this.ATL_CTR_PTY_SEQ = JdbcWritableBridge.readBigDecimal(45, __dbResults);
    this.ATL_HIS_SEQ = JdbcWritableBridge.readBigDecimal(46, __dbResults);
    this.ENDR_NO = JdbcWritableBridge.readBigDecimal(47, __dbResults);
    this.RTRO_ENDR_NO = JdbcWritableBridge.readBigDecimal(48, __dbResults);
    this.ENDR_HIS_ST_NO = JdbcWritableBridge.readBigDecimal(49, __dbResults);
    this.ENDR_HIS_ED_NO = JdbcWritableBridge.readBigDecimal(50, __dbResults);
    this.SUMUP_DT = JdbcWritableBridge.readTimestamp(51, __dbResults);
    this.HIS_ST_DT = JdbcWritableBridge.readTimestamp(52, __dbResults);
    this.HIS_ED_DT = JdbcWritableBridge.readTimestamp(53, __dbResults);
    this.INPPE_ORG_ID = JdbcWritableBridge.readString(54, __dbResults);
    this.SYS_OCC_DTM = JdbcWritableBridge.readTimestamp(55, __dbResults);
    this.SYS_DEL_DIV_CD = JdbcWritableBridge.readString(56, __dbResults);
    this.OCC_IP = JdbcWritableBridge.readString(57, __dbResults);
    this.APP_ID = JdbcWritableBridge.readString(58, __dbResults);
    this.DATA_CHNG_DTM = JdbcWritableBridge.readTimestamp(59, __dbResults);
    this.DSC_CON = JdbcWritableBridge.readString(60, __dbResults);
    this.RNM_CNF_KD_CD = JdbcWritableBridge.readString(61, __dbResults);
    this.IDF_ATH_CHT_ISS_DT = JdbcWritableBridge.readTimestamp(62, __dbResults);
    this.ISS_INST_NM = JdbcWritableBridge.readString(63, __dbResults);
    this.ADDTL_REF_NO = JdbcWritableBridge.readString(64, __dbResults);
    this.RNM_ATH_FNM = JdbcWritableBridge.readString(65, __dbResults);
    this.EIH_LDG_DTM = JdbcWritableBridge.readTimestamp(66, __dbResults);
    this.KIS_ETP_CD = JdbcWritableBridge.readString(67, __dbResults);
    this.APL_ST_DT = JdbcWritableBridge.readTimestamp(68, __dbResults);
    this.APL_ED_DT = JdbcWritableBridge.readTimestamp(69, __dbResults);
    this.HNC_REG_ED_DT = JdbcWritableBridge.readTimestamp(70, __dbResults);
    this.HNCPE_CTR_YN = JdbcWritableBridge.readString(71, __dbResults);
  }
  public void readFields0(ResultSet __dbResults) throws SQLException {
    this.CTR_ID = JdbcWritableBridge.readString(1, __dbResults);
    this.CTR_PTY_SEQ = JdbcWritableBridge.readBigDecimal(2, __dbResults);
    this.HIS_SEQ = JdbcWritableBridge.readBigDecimal(3, __dbResults);
    this.BIZ_SYS_CD = JdbcWritableBridge.readString(4, __dbResults);
    this.PRCTR_NO = JdbcWritableBridge.readString(5, __dbResults);
    this.RL_APL_RNG_DIV_CD = JdbcWritableBridge.readString(6, __dbResults);
    this.DATA_ID = JdbcWritableBridge.readString(7, __dbResults);
    this.DATA_SEQ = JdbcWritableBridge.readBigDecimal(8, __dbResults);
    this.CTR_PTY_RL_CD = JdbcWritableBridge.readString(9, __dbResults);
    this.PTY_DIV_CD = JdbcWritableBridge.readString(10, __dbResults);
    this.PTY_ID = JdbcWritableBridge.readString(11, __dbResults);
    this.CUS_NO = JdbcWritableBridge.readString(12, __dbResults);
    this.CUS_BCH_NO = JdbcWritableBridge.readString(13, __dbResults);
    this.RL_RTO = JdbcWritableBridge.readBigDecimal(14, __dbResults);
    this.RL_REL_CD = JdbcWritableBridge.readString(15, __dbResults);
    this.REL_PTY_RL_CD = JdbcWritableBridge.readString(16, __dbResults);
    this.TXPF_REG_TRGPE_DIV_CD = JdbcWritableBridge.readString(17, __dbResults);
    this.POLHD_GRDE_CD = JdbcWritableBridge.readString(18, __dbResults);
    this.POLHD_CHNG_RSN_CD = JdbcWritableBridge.readString(19, __dbResults);
    this.DTL_ADJT_CD = JdbcWritableBridge.readString(20, __dbResults);
    this.RPS_CTR_PTY_YN = JdbcWritableBridge.readString(21, __dbResults);
    this.GNR_POLHD_DIV_CD = JdbcWritableBridge.readString(22, __dbResults);
    this.RLSIT_NRMN_CD = JdbcWritableBridge.readString(23, __dbResults);
    this.AGE = JdbcWritableBridge.readBigDecimal(24, __dbResults);
    this.NKNM = JdbcWritableBridge.readString(25, __dbResults);
    this.ADDTL_FM_NM = JdbcWritableBridge.readString(26, __dbResults);
    this.POL_RCEPL_DIV_CD = JdbcWritableBridge.readString(27, __dbResults);
    this.DM_SNDPL_DIV_CD = JdbcWritableBridge.readString(28, __dbResults);
    this.CMC_MN_TMN_AGR_YN = JdbcWritableBridge.readString(29, __dbResults);
    this.PTY_IDF_INF_SEQ = JdbcWritableBridge.readBigDecimal(30, __dbResults);
    this.PSSPE_CD = JdbcWritableBridge.readString(31, __dbResults);
    this.JOB_CD = JdbcWritableBridge.readString(32, __dbResults);
    this.JOB_GRD_CD = JdbcWritableBridge.readString(33, __dbResults);
    this.MARY_YN = JdbcWritableBridge.readString(34, __dbResults);
    this.CHDN_DRV_YN = JdbcWritableBridge.readString(35, __dbResults);
    this.INSPE_TP_CD = JdbcWritableBridge.readString(36, __dbResults);
    this.POL_RCGPE_YN = JdbcWritableBridge.readString(37, __dbResults);
    this.HAPE_EMP_DIV_CD = JdbcWritableBridge.readString(38, __dbResults);
    this.HAPE_AGE_SIC_DIV_CD = JdbcWritableBridge.readString(39, __dbResults);
    this.LCNS_DIV_CD = JdbcWritableBridge.readString(40, __dbResults);
    this.LCNS_NO = JdbcWritableBridge.readString(41, __dbResults);
    this.LCNS_DLV_DT = JdbcWritableBridge.readTimestamp(42, __dbResults);
    this.ENTCO_DT = JdbcWritableBridge.readTimestamp(43, __dbResults);
    this.ATL_CTR_ID = JdbcWritableBridge.readString(44, __dbResults);
    this.ATL_CTR_PTY_SEQ = JdbcWritableBridge.readBigDecimal(45, __dbResults);
    this.ATL_HIS_SEQ = JdbcWritableBridge.readBigDecimal(46, __dbResults);
    this.ENDR_NO = JdbcWritableBridge.readBigDecimal(47, __dbResults);
    this.RTRO_ENDR_NO = JdbcWritableBridge.readBigDecimal(48, __dbResults);
    this.ENDR_HIS_ST_NO = JdbcWritableBridge.readBigDecimal(49, __dbResults);
    this.ENDR_HIS_ED_NO = JdbcWritableBridge.readBigDecimal(50, __dbResults);
    this.SUMUP_DT = JdbcWritableBridge.readTimestamp(51, __dbResults);
    this.HIS_ST_DT = JdbcWritableBridge.readTimestamp(52, __dbResults);
    this.HIS_ED_DT = JdbcWritableBridge.readTimestamp(53, __dbResults);
    this.INPPE_ORG_ID = JdbcWritableBridge.readString(54, __dbResults);
    this.SYS_OCC_DTM = JdbcWritableBridge.readTimestamp(55, __dbResults);
    this.SYS_DEL_DIV_CD = JdbcWritableBridge.readString(56, __dbResults);
    this.OCC_IP = JdbcWritableBridge.readString(57, __dbResults);
    this.APP_ID = JdbcWritableBridge.readString(58, __dbResults);
    this.DATA_CHNG_DTM = JdbcWritableBridge.readTimestamp(59, __dbResults);
    this.DSC_CON = JdbcWritableBridge.readString(60, __dbResults);
    this.RNM_CNF_KD_CD = JdbcWritableBridge.readString(61, __dbResults);
    this.IDF_ATH_CHT_ISS_DT = JdbcWritableBridge.readTimestamp(62, __dbResults);
    this.ISS_INST_NM = JdbcWritableBridge.readString(63, __dbResults);
    this.ADDTL_REF_NO = JdbcWritableBridge.readString(64, __dbResults);
    this.RNM_ATH_FNM = JdbcWritableBridge.readString(65, __dbResults);
    this.EIH_LDG_DTM = JdbcWritableBridge.readTimestamp(66, __dbResults);
    this.KIS_ETP_CD = JdbcWritableBridge.readString(67, __dbResults);
    this.APL_ST_DT = JdbcWritableBridge.readTimestamp(68, __dbResults);
    this.APL_ED_DT = JdbcWritableBridge.readTimestamp(69, __dbResults);
    this.HNC_REG_ED_DT = JdbcWritableBridge.readTimestamp(70, __dbResults);
    this.HNCPE_CTR_YN = JdbcWritableBridge.readString(71, __dbResults);
  }
  public void loadLargeObjects(LargeObjectLoader __loader)
      throws SQLException, IOException, InterruptedException {
  }
  public void loadLargeObjects0(LargeObjectLoader __loader)
      throws SQLException, IOException, InterruptedException {
  }
  public void write(PreparedStatement __dbStmt) throws SQLException {
    write(__dbStmt, 0);
  }

  public int write(PreparedStatement __dbStmt, int __off) throws SQLException {
    JdbcWritableBridge.writeString(CTR_ID, 1 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(CTR_PTY_SEQ, 2 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(HIS_SEQ, 3 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(BIZ_SYS_CD, 4 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(PRCTR_NO, 5 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(RL_APL_RNG_DIV_CD, 6 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(DATA_ID, 7 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(DATA_SEQ, 8 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(CTR_PTY_RL_CD, 9 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(PTY_DIV_CD, 10 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(PTY_ID, 11 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(CUS_NO, 12 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(CUS_BCH_NO, 13 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(RL_RTO, 14 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(RL_REL_CD, 15 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(REL_PTY_RL_CD, 16 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(TXPF_REG_TRGPE_DIV_CD, 17 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(POLHD_GRDE_CD, 18 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(POLHD_CHNG_RSN_CD, 19 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(DTL_ADJT_CD, 20 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(RPS_CTR_PTY_YN, 21 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(GNR_POLHD_DIV_CD, 22 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(RLSIT_NRMN_CD, 23 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(AGE, 24 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(NKNM, 25 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(ADDTL_FM_NM, 26 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(POL_RCEPL_DIV_CD, 27 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(DM_SNDPL_DIV_CD, 28 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(CMC_MN_TMN_AGR_YN, 29 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(PTY_IDF_INF_SEQ, 30 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(PSSPE_CD, 31 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(JOB_CD, 32 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(JOB_GRD_CD, 33 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(MARY_YN, 34 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(CHDN_DRV_YN, 35 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(INSPE_TP_CD, 36 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(POL_RCGPE_YN, 37 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(HAPE_EMP_DIV_CD, 38 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(HAPE_AGE_SIC_DIV_CD, 39 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(LCNS_DIV_CD, 40 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(LCNS_NO, 41 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeTimestamp(LCNS_DLV_DT, 42 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeTimestamp(ENTCO_DT, 43 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeString(ATL_CTR_ID, 44 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(ATL_CTR_PTY_SEQ, 45 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(ATL_HIS_SEQ, 46 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(ENDR_NO, 47 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(RTRO_ENDR_NO, 48 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(ENDR_HIS_ST_NO, 49 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(ENDR_HIS_ED_NO, 50 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeTimestamp(SUMUP_DT, 51 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeTimestamp(HIS_ST_DT, 52 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeTimestamp(HIS_ED_DT, 53 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeString(INPPE_ORG_ID, 54 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeTimestamp(SYS_OCC_DTM, 55 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeString(SYS_DEL_DIV_CD, 56 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(OCC_IP, 57 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(APP_ID, 58 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeTimestamp(DATA_CHNG_DTM, 59 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeString(DSC_CON, 60 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(RNM_CNF_KD_CD, 61 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeTimestamp(IDF_ATH_CHT_ISS_DT, 62 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeString(ISS_INST_NM, 63 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(ADDTL_REF_NO, 64 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(RNM_ATH_FNM, 65 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeTimestamp(EIH_LDG_DTM, 66 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeString(KIS_ETP_CD, 67 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeTimestamp(APL_ST_DT, 68 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeTimestamp(APL_ED_DT, 69 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeTimestamp(HNC_REG_ED_DT, 70 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeString(HNCPE_CTR_YN, 71 + __off, 12, __dbStmt);
    return 71;
  }
  public void write0(PreparedStatement __dbStmt, int __off) throws SQLException {
    JdbcWritableBridge.writeString(CTR_ID, 1 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(CTR_PTY_SEQ, 2 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(HIS_SEQ, 3 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(BIZ_SYS_CD, 4 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(PRCTR_NO, 5 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(RL_APL_RNG_DIV_CD, 6 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(DATA_ID, 7 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(DATA_SEQ, 8 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(CTR_PTY_RL_CD, 9 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(PTY_DIV_CD, 10 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(PTY_ID, 11 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(CUS_NO, 12 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(CUS_BCH_NO, 13 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(RL_RTO, 14 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(RL_REL_CD, 15 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(REL_PTY_RL_CD, 16 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(TXPF_REG_TRGPE_DIV_CD, 17 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(POLHD_GRDE_CD, 18 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(POLHD_CHNG_RSN_CD, 19 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(DTL_ADJT_CD, 20 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(RPS_CTR_PTY_YN, 21 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(GNR_POLHD_DIV_CD, 22 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(RLSIT_NRMN_CD, 23 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(AGE, 24 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(NKNM, 25 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(ADDTL_FM_NM, 26 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(POL_RCEPL_DIV_CD, 27 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(DM_SNDPL_DIV_CD, 28 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(CMC_MN_TMN_AGR_YN, 29 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(PTY_IDF_INF_SEQ, 30 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(PSSPE_CD, 31 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(JOB_CD, 32 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(JOB_GRD_CD, 33 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(MARY_YN, 34 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(CHDN_DRV_YN, 35 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(INSPE_TP_CD, 36 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(POL_RCGPE_YN, 37 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(HAPE_EMP_DIV_CD, 38 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(HAPE_AGE_SIC_DIV_CD, 39 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(LCNS_DIV_CD, 40 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(LCNS_NO, 41 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeTimestamp(LCNS_DLV_DT, 42 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeTimestamp(ENTCO_DT, 43 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeString(ATL_CTR_ID, 44 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(ATL_CTR_PTY_SEQ, 45 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(ATL_HIS_SEQ, 46 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(ENDR_NO, 47 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(RTRO_ENDR_NO, 48 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(ENDR_HIS_ST_NO, 49 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(ENDR_HIS_ED_NO, 50 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeTimestamp(SUMUP_DT, 51 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeTimestamp(HIS_ST_DT, 52 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeTimestamp(HIS_ED_DT, 53 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeString(INPPE_ORG_ID, 54 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeTimestamp(SYS_OCC_DTM, 55 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeString(SYS_DEL_DIV_CD, 56 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(OCC_IP, 57 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(APP_ID, 58 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeTimestamp(DATA_CHNG_DTM, 59 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeString(DSC_CON, 60 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(RNM_CNF_KD_CD, 61 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeTimestamp(IDF_ATH_CHT_ISS_DT, 62 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeString(ISS_INST_NM, 63 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(ADDTL_REF_NO, 64 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(RNM_ATH_FNM, 65 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeTimestamp(EIH_LDG_DTM, 66 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeString(KIS_ETP_CD, 67 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeTimestamp(APL_ST_DT, 68 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeTimestamp(APL_ED_DT, 69 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeTimestamp(HNC_REG_ED_DT, 70 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeString(HNCPE_CTR_YN, 71 + __off, 12, __dbStmt);
  }
  public void readFields(DataInput __dataIn) throws IOException {
this.readFields0(__dataIn);  }
  public void readFields0(DataInput __dataIn) throws IOException {
    if (__dataIn.readBoolean()) { 
        this.CTR_ID = null;
    } else {
    this.CTR_ID = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.CTR_PTY_SEQ = null;
    } else {
    this.CTR_PTY_SEQ = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.HIS_SEQ = null;
    } else {
    this.HIS_SEQ = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.BIZ_SYS_CD = null;
    } else {
    this.BIZ_SYS_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.PRCTR_NO = null;
    } else {
    this.PRCTR_NO = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RL_APL_RNG_DIV_CD = null;
    } else {
    this.RL_APL_RNG_DIV_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.DATA_ID = null;
    } else {
    this.DATA_ID = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.DATA_SEQ = null;
    } else {
    this.DATA_SEQ = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.CTR_PTY_RL_CD = null;
    } else {
    this.CTR_PTY_RL_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.PTY_DIV_CD = null;
    } else {
    this.PTY_DIV_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.PTY_ID = null;
    } else {
    this.PTY_ID = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.CUS_NO = null;
    } else {
    this.CUS_NO = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.CUS_BCH_NO = null;
    } else {
    this.CUS_BCH_NO = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RL_RTO = null;
    } else {
    this.RL_RTO = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RL_REL_CD = null;
    } else {
    this.RL_REL_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.REL_PTY_RL_CD = null;
    } else {
    this.REL_PTY_RL_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.TXPF_REG_TRGPE_DIV_CD = null;
    } else {
    this.TXPF_REG_TRGPE_DIV_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.POLHD_GRDE_CD = null;
    } else {
    this.POLHD_GRDE_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.POLHD_CHNG_RSN_CD = null;
    } else {
    this.POLHD_CHNG_RSN_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.DTL_ADJT_CD = null;
    } else {
    this.DTL_ADJT_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RPS_CTR_PTY_YN = null;
    } else {
    this.RPS_CTR_PTY_YN = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.GNR_POLHD_DIV_CD = null;
    } else {
    this.GNR_POLHD_DIV_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RLSIT_NRMN_CD = null;
    } else {
    this.RLSIT_NRMN_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.AGE = null;
    } else {
    this.AGE = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.NKNM = null;
    } else {
    this.NKNM = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.ADDTL_FM_NM = null;
    } else {
    this.ADDTL_FM_NM = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.POL_RCEPL_DIV_CD = null;
    } else {
    this.POL_RCEPL_DIV_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.DM_SNDPL_DIV_CD = null;
    } else {
    this.DM_SNDPL_DIV_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.CMC_MN_TMN_AGR_YN = null;
    } else {
    this.CMC_MN_TMN_AGR_YN = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.PTY_IDF_INF_SEQ = null;
    } else {
    this.PTY_IDF_INF_SEQ = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.PSSPE_CD = null;
    } else {
    this.PSSPE_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.JOB_CD = null;
    } else {
    this.JOB_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.JOB_GRD_CD = null;
    } else {
    this.JOB_GRD_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.MARY_YN = null;
    } else {
    this.MARY_YN = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.CHDN_DRV_YN = null;
    } else {
    this.CHDN_DRV_YN = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.INSPE_TP_CD = null;
    } else {
    this.INSPE_TP_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.POL_RCGPE_YN = null;
    } else {
    this.POL_RCGPE_YN = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.HAPE_EMP_DIV_CD = null;
    } else {
    this.HAPE_EMP_DIV_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.HAPE_AGE_SIC_DIV_CD = null;
    } else {
    this.HAPE_AGE_SIC_DIV_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.LCNS_DIV_CD = null;
    } else {
    this.LCNS_DIV_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.LCNS_NO = null;
    } else {
    this.LCNS_NO = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.LCNS_DLV_DT = null;
    } else {
    this.LCNS_DLV_DT = new Timestamp(__dataIn.readLong());
    this.LCNS_DLV_DT.setNanos(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.ENTCO_DT = null;
    } else {
    this.ENTCO_DT = new Timestamp(__dataIn.readLong());
    this.ENTCO_DT.setNanos(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.ATL_CTR_ID = null;
    } else {
    this.ATL_CTR_ID = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.ATL_CTR_PTY_SEQ = null;
    } else {
    this.ATL_CTR_PTY_SEQ = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.ATL_HIS_SEQ = null;
    } else {
    this.ATL_HIS_SEQ = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.ENDR_NO = null;
    } else {
    this.ENDR_NO = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RTRO_ENDR_NO = null;
    } else {
    this.RTRO_ENDR_NO = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.ENDR_HIS_ST_NO = null;
    } else {
    this.ENDR_HIS_ST_NO = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.ENDR_HIS_ED_NO = null;
    } else {
    this.ENDR_HIS_ED_NO = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.SUMUP_DT = null;
    } else {
    this.SUMUP_DT = new Timestamp(__dataIn.readLong());
    this.SUMUP_DT.setNanos(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.HIS_ST_DT = null;
    } else {
    this.HIS_ST_DT = new Timestamp(__dataIn.readLong());
    this.HIS_ST_DT.setNanos(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.HIS_ED_DT = null;
    } else {
    this.HIS_ED_DT = new Timestamp(__dataIn.readLong());
    this.HIS_ED_DT.setNanos(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.INPPE_ORG_ID = null;
    } else {
    this.INPPE_ORG_ID = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.SYS_OCC_DTM = null;
    } else {
    this.SYS_OCC_DTM = new Timestamp(__dataIn.readLong());
    this.SYS_OCC_DTM.setNanos(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.SYS_DEL_DIV_CD = null;
    } else {
    this.SYS_DEL_DIV_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.OCC_IP = null;
    } else {
    this.OCC_IP = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.APP_ID = null;
    } else {
    this.APP_ID = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.DATA_CHNG_DTM = null;
    } else {
    this.DATA_CHNG_DTM = new Timestamp(__dataIn.readLong());
    this.DATA_CHNG_DTM.setNanos(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.DSC_CON = null;
    } else {
    this.DSC_CON = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RNM_CNF_KD_CD = null;
    } else {
    this.RNM_CNF_KD_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.IDF_ATH_CHT_ISS_DT = null;
    } else {
    this.IDF_ATH_CHT_ISS_DT = new Timestamp(__dataIn.readLong());
    this.IDF_ATH_CHT_ISS_DT.setNanos(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.ISS_INST_NM = null;
    } else {
    this.ISS_INST_NM = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.ADDTL_REF_NO = null;
    } else {
    this.ADDTL_REF_NO = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RNM_ATH_FNM = null;
    } else {
    this.RNM_ATH_FNM = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.EIH_LDG_DTM = null;
    } else {
    this.EIH_LDG_DTM = new Timestamp(__dataIn.readLong());
    this.EIH_LDG_DTM.setNanos(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.KIS_ETP_CD = null;
    } else {
    this.KIS_ETP_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.APL_ST_DT = null;
    } else {
    this.APL_ST_DT = new Timestamp(__dataIn.readLong());
    this.APL_ST_DT.setNanos(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.APL_ED_DT = null;
    } else {
    this.APL_ED_DT = new Timestamp(__dataIn.readLong());
    this.APL_ED_DT.setNanos(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.HNC_REG_ED_DT = null;
    } else {
    this.HNC_REG_ED_DT = new Timestamp(__dataIn.readLong());
    this.HNC_REG_ED_DT.setNanos(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.HNCPE_CTR_YN = null;
    } else {
    this.HNCPE_CTR_YN = Text.readString(__dataIn);
    }
  }
  public void write(DataOutput __dataOut) throws IOException {
    if (null == this.CTR_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CTR_ID);
    }
    if (null == this.CTR_PTY_SEQ) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.CTR_PTY_SEQ, __dataOut);
    }
    if (null == this.HIS_SEQ) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.HIS_SEQ, __dataOut);
    }
    if (null == this.BIZ_SYS_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, BIZ_SYS_CD);
    }
    if (null == this.PRCTR_NO) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, PRCTR_NO);
    }
    if (null == this.RL_APL_RNG_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RL_APL_RNG_DIV_CD);
    }
    if (null == this.DATA_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, DATA_ID);
    }
    if (null == this.DATA_SEQ) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.DATA_SEQ, __dataOut);
    }
    if (null == this.CTR_PTY_RL_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CTR_PTY_RL_CD);
    }
    if (null == this.PTY_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, PTY_DIV_CD);
    }
    if (null == this.PTY_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, PTY_ID);
    }
    if (null == this.CUS_NO) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CUS_NO);
    }
    if (null == this.CUS_BCH_NO) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CUS_BCH_NO);
    }
    if (null == this.RL_RTO) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.RL_RTO, __dataOut);
    }
    if (null == this.RL_REL_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RL_REL_CD);
    }
    if (null == this.REL_PTY_RL_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, REL_PTY_RL_CD);
    }
    if (null == this.TXPF_REG_TRGPE_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, TXPF_REG_TRGPE_DIV_CD);
    }
    if (null == this.POLHD_GRDE_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, POLHD_GRDE_CD);
    }
    if (null == this.POLHD_CHNG_RSN_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, POLHD_CHNG_RSN_CD);
    }
    if (null == this.DTL_ADJT_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, DTL_ADJT_CD);
    }
    if (null == this.RPS_CTR_PTY_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RPS_CTR_PTY_YN);
    }
    if (null == this.GNR_POLHD_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, GNR_POLHD_DIV_CD);
    }
    if (null == this.RLSIT_NRMN_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RLSIT_NRMN_CD);
    }
    if (null == this.AGE) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.AGE, __dataOut);
    }
    if (null == this.NKNM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, NKNM);
    }
    if (null == this.ADDTL_FM_NM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ADDTL_FM_NM);
    }
    if (null == this.POL_RCEPL_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, POL_RCEPL_DIV_CD);
    }
    if (null == this.DM_SNDPL_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, DM_SNDPL_DIV_CD);
    }
    if (null == this.CMC_MN_TMN_AGR_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CMC_MN_TMN_AGR_YN);
    }
    if (null == this.PTY_IDF_INF_SEQ) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.PTY_IDF_INF_SEQ, __dataOut);
    }
    if (null == this.PSSPE_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, PSSPE_CD);
    }
    if (null == this.JOB_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, JOB_CD);
    }
    if (null == this.JOB_GRD_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, JOB_GRD_CD);
    }
    if (null == this.MARY_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, MARY_YN);
    }
    if (null == this.CHDN_DRV_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CHDN_DRV_YN);
    }
    if (null == this.INSPE_TP_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, INSPE_TP_CD);
    }
    if (null == this.POL_RCGPE_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, POL_RCGPE_YN);
    }
    if (null == this.HAPE_EMP_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, HAPE_EMP_DIV_CD);
    }
    if (null == this.HAPE_AGE_SIC_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, HAPE_AGE_SIC_DIV_CD);
    }
    if (null == this.LCNS_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, LCNS_DIV_CD);
    }
    if (null == this.LCNS_NO) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, LCNS_NO);
    }
    if (null == this.LCNS_DLV_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.LCNS_DLV_DT.getTime());
    __dataOut.writeInt(this.LCNS_DLV_DT.getNanos());
    }
    if (null == this.ENTCO_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.ENTCO_DT.getTime());
    __dataOut.writeInt(this.ENTCO_DT.getNanos());
    }
    if (null == this.ATL_CTR_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ATL_CTR_ID);
    }
    if (null == this.ATL_CTR_PTY_SEQ) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.ATL_CTR_PTY_SEQ, __dataOut);
    }
    if (null == this.ATL_HIS_SEQ) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.ATL_HIS_SEQ, __dataOut);
    }
    if (null == this.ENDR_NO) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.ENDR_NO, __dataOut);
    }
    if (null == this.RTRO_ENDR_NO) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.RTRO_ENDR_NO, __dataOut);
    }
    if (null == this.ENDR_HIS_ST_NO) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.ENDR_HIS_ST_NO, __dataOut);
    }
    if (null == this.ENDR_HIS_ED_NO) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.ENDR_HIS_ED_NO, __dataOut);
    }
    if (null == this.SUMUP_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.SUMUP_DT.getTime());
    __dataOut.writeInt(this.SUMUP_DT.getNanos());
    }
    if (null == this.HIS_ST_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.HIS_ST_DT.getTime());
    __dataOut.writeInt(this.HIS_ST_DT.getNanos());
    }
    if (null == this.HIS_ED_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.HIS_ED_DT.getTime());
    __dataOut.writeInt(this.HIS_ED_DT.getNanos());
    }
    if (null == this.INPPE_ORG_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, INPPE_ORG_ID);
    }
    if (null == this.SYS_OCC_DTM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.SYS_OCC_DTM.getTime());
    __dataOut.writeInt(this.SYS_OCC_DTM.getNanos());
    }
    if (null == this.SYS_DEL_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, SYS_DEL_DIV_CD);
    }
    if (null == this.OCC_IP) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, OCC_IP);
    }
    if (null == this.APP_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, APP_ID);
    }
    if (null == this.DATA_CHNG_DTM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.DATA_CHNG_DTM.getTime());
    __dataOut.writeInt(this.DATA_CHNG_DTM.getNanos());
    }
    if (null == this.DSC_CON) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, DSC_CON);
    }
    if (null == this.RNM_CNF_KD_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RNM_CNF_KD_CD);
    }
    if (null == this.IDF_ATH_CHT_ISS_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.IDF_ATH_CHT_ISS_DT.getTime());
    __dataOut.writeInt(this.IDF_ATH_CHT_ISS_DT.getNanos());
    }
    if (null == this.ISS_INST_NM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ISS_INST_NM);
    }
    if (null == this.ADDTL_REF_NO) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ADDTL_REF_NO);
    }
    if (null == this.RNM_ATH_FNM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RNM_ATH_FNM);
    }
    if (null == this.EIH_LDG_DTM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.EIH_LDG_DTM.getTime());
    __dataOut.writeInt(this.EIH_LDG_DTM.getNanos());
    }
    if (null == this.KIS_ETP_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, KIS_ETP_CD);
    }
    if (null == this.APL_ST_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.APL_ST_DT.getTime());
    __dataOut.writeInt(this.APL_ST_DT.getNanos());
    }
    if (null == this.APL_ED_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.APL_ED_DT.getTime());
    __dataOut.writeInt(this.APL_ED_DT.getNanos());
    }
    if (null == this.HNC_REG_ED_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.HNC_REG_ED_DT.getTime());
    __dataOut.writeInt(this.HNC_REG_ED_DT.getNanos());
    }
    if (null == this.HNCPE_CTR_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, HNCPE_CTR_YN);
    }
  }
  public void write0(DataOutput __dataOut) throws IOException {
    if (null == this.CTR_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CTR_ID);
    }
    if (null == this.CTR_PTY_SEQ) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.CTR_PTY_SEQ, __dataOut);
    }
    if (null == this.HIS_SEQ) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.HIS_SEQ, __dataOut);
    }
    if (null == this.BIZ_SYS_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, BIZ_SYS_CD);
    }
    if (null == this.PRCTR_NO) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, PRCTR_NO);
    }
    if (null == this.RL_APL_RNG_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RL_APL_RNG_DIV_CD);
    }
    if (null == this.DATA_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, DATA_ID);
    }
    if (null == this.DATA_SEQ) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.DATA_SEQ, __dataOut);
    }
    if (null == this.CTR_PTY_RL_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CTR_PTY_RL_CD);
    }
    if (null == this.PTY_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, PTY_DIV_CD);
    }
    if (null == this.PTY_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, PTY_ID);
    }
    if (null == this.CUS_NO) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CUS_NO);
    }
    if (null == this.CUS_BCH_NO) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CUS_BCH_NO);
    }
    if (null == this.RL_RTO) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.RL_RTO, __dataOut);
    }
    if (null == this.RL_REL_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RL_REL_CD);
    }
    if (null == this.REL_PTY_RL_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, REL_PTY_RL_CD);
    }
    if (null == this.TXPF_REG_TRGPE_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, TXPF_REG_TRGPE_DIV_CD);
    }
    if (null == this.POLHD_GRDE_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, POLHD_GRDE_CD);
    }
    if (null == this.POLHD_CHNG_RSN_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, POLHD_CHNG_RSN_CD);
    }
    if (null == this.DTL_ADJT_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, DTL_ADJT_CD);
    }
    if (null == this.RPS_CTR_PTY_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RPS_CTR_PTY_YN);
    }
    if (null == this.GNR_POLHD_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, GNR_POLHD_DIV_CD);
    }
    if (null == this.RLSIT_NRMN_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RLSIT_NRMN_CD);
    }
    if (null == this.AGE) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.AGE, __dataOut);
    }
    if (null == this.NKNM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, NKNM);
    }
    if (null == this.ADDTL_FM_NM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ADDTL_FM_NM);
    }
    if (null == this.POL_RCEPL_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, POL_RCEPL_DIV_CD);
    }
    if (null == this.DM_SNDPL_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, DM_SNDPL_DIV_CD);
    }
    if (null == this.CMC_MN_TMN_AGR_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CMC_MN_TMN_AGR_YN);
    }
    if (null == this.PTY_IDF_INF_SEQ) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.PTY_IDF_INF_SEQ, __dataOut);
    }
    if (null == this.PSSPE_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, PSSPE_CD);
    }
    if (null == this.JOB_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, JOB_CD);
    }
    if (null == this.JOB_GRD_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, JOB_GRD_CD);
    }
    if (null == this.MARY_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, MARY_YN);
    }
    if (null == this.CHDN_DRV_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CHDN_DRV_YN);
    }
    if (null == this.INSPE_TP_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, INSPE_TP_CD);
    }
    if (null == this.POL_RCGPE_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, POL_RCGPE_YN);
    }
    if (null == this.HAPE_EMP_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, HAPE_EMP_DIV_CD);
    }
    if (null == this.HAPE_AGE_SIC_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, HAPE_AGE_SIC_DIV_CD);
    }
    if (null == this.LCNS_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, LCNS_DIV_CD);
    }
    if (null == this.LCNS_NO) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, LCNS_NO);
    }
    if (null == this.LCNS_DLV_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.LCNS_DLV_DT.getTime());
    __dataOut.writeInt(this.LCNS_DLV_DT.getNanos());
    }
    if (null == this.ENTCO_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.ENTCO_DT.getTime());
    __dataOut.writeInt(this.ENTCO_DT.getNanos());
    }
    if (null == this.ATL_CTR_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ATL_CTR_ID);
    }
    if (null == this.ATL_CTR_PTY_SEQ) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.ATL_CTR_PTY_SEQ, __dataOut);
    }
    if (null == this.ATL_HIS_SEQ) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.ATL_HIS_SEQ, __dataOut);
    }
    if (null == this.ENDR_NO) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.ENDR_NO, __dataOut);
    }
    if (null == this.RTRO_ENDR_NO) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.RTRO_ENDR_NO, __dataOut);
    }
    if (null == this.ENDR_HIS_ST_NO) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.ENDR_HIS_ST_NO, __dataOut);
    }
    if (null == this.ENDR_HIS_ED_NO) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.ENDR_HIS_ED_NO, __dataOut);
    }
    if (null == this.SUMUP_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.SUMUP_DT.getTime());
    __dataOut.writeInt(this.SUMUP_DT.getNanos());
    }
    if (null == this.HIS_ST_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.HIS_ST_DT.getTime());
    __dataOut.writeInt(this.HIS_ST_DT.getNanos());
    }
    if (null == this.HIS_ED_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.HIS_ED_DT.getTime());
    __dataOut.writeInt(this.HIS_ED_DT.getNanos());
    }
    if (null == this.INPPE_ORG_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, INPPE_ORG_ID);
    }
    if (null == this.SYS_OCC_DTM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.SYS_OCC_DTM.getTime());
    __dataOut.writeInt(this.SYS_OCC_DTM.getNanos());
    }
    if (null == this.SYS_DEL_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, SYS_DEL_DIV_CD);
    }
    if (null == this.OCC_IP) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, OCC_IP);
    }
    if (null == this.APP_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, APP_ID);
    }
    if (null == this.DATA_CHNG_DTM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.DATA_CHNG_DTM.getTime());
    __dataOut.writeInt(this.DATA_CHNG_DTM.getNanos());
    }
    if (null == this.DSC_CON) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, DSC_CON);
    }
    if (null == this.RNM_CNF_KD_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RNM_CNF_KD_CD);
    }
    if (null == this.IDF_ATH_CHT_ISS_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.IDF_ATH_CHT_ISS_DT.getTime());
    __dataOut.writeInt(this.IDF_ATH_CHT_ISS_DT.getNanos());
    }
    if (null == this.ISS_INST_NM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ISS_INST_NM);
    }
    if (null == this.ADDTL_REF_NO) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ADDTL_REF_NO);
    }
    if (null == this.RNM_ATH_FNM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RNM_ATH_FNM);
    }
    if (null == this.EIH_LDG_DTM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.EIH_LDG_DTM.getTime());
    __dataOut.writeInt(this.EIH_LDG_DTM.getNanos());
    }
    if (null == this.KIS_ETP_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, KIS_ETP_CD);
    }
    if (null == this.APL_ST_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.APL_ST_DT.getTime());
    __dataOut.writeInt(this.APL_ST_DT.getNanos());
    }
    if (null == this.APL_ED_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.APL_ED_DT.getTime());
    __dataOut.writeInt(this.APL_ED_DT.getNanos());
    }
    if (null == this.HNC_REG_ED_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.HNC_REG_ED_DT.getTime());
    __dataOut.writeInt(this.HNC_REG_ED_DT.getNanos());
    }
    if (null == this.HNCPE_CTR_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, HNCPE_CTR_YN);
    }
  }
  private static final DelimiterSet __outputDelimiters = new DelimiterSet((char) 1, (char) 10, (char) 0, (char) 0, false);
  public String toString() {
    return toString(__outputDelimiters, true);
  }
  public String toString(DelimiterSet delimiters) {
    return toString(delimiters, true);
  }
  public String toString(boolean useRecordDelim) {
    return toString(__outputDelimiters, useRecordDelim);
  }
  public String toString(DelimiterSet delimiters, boolean useRecordDelim) {
    StringBuilder __sb = new StringBuilder();
    char fieldDelim = delimiters.getFieldsTerminatedBy();
    __sb.append(FieldFormatter.escapeAndEnclose(CTR_ID==null?"null":CTR_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CTR_PTY_SEQ==null?"null":CTR_PTY_SEQ.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(HIS_SEQ==null?"null":HIS_SEQ.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(BIZ_SYS_CD==null?"null":BIZ_SYS_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PRCTR_NO==null?"null":PRCTR_NO, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RL_APL_RNG_DIV_CD==null?"null":RL_APL_RNG_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DATA_ID==null?"null":DATA_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DATA_SEQ==null?"null":DATA_SEQ.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CTR_PTY_RL_CD==null?"null":CTR_PTY_RL_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PTY_DIV_CD==null?"null":PTY_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PTY_ID==null?"null":PTY_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CUS_NO==null?"null":CUS_NO, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CUS_BCH_NO==null?"null":CUS_BCH_NO, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RL_RTO==null?"null":RL_RTO.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RL_REL_CD==null?"null":RL_REL_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(REL_PTY_RL_CD==null?"null":REL_PTY_RL_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(TXPF_REG_TRGPE_DIV_CD==null?"null":TXPF_REG_TRGPE_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(POLHD_GRDE_CD==null?"null":POLHD_GRDE_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(POLHD_CHNG_RSN_CD==null?"null":POLHD_CHNG_RSN_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DTL_ADJT_CD==null?"null":DTL_ADJT_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RPS_CTR_PTY_YN==null?"null":RPS_CTR_PTY_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(GNR_POLHD_DIV_CD==null?"null":GNR_POLHD_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RLSIT_NRMN_CD==null?"null":RLSIT_NRMN_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(AGE==null?"null":AGE.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(NKNM==null?"null":NKNM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ADDTL_FM_NM==null?"null":ADDTL_FM_NM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(POL_RCEPL_DIV_CD==null?"null":POL_RCEPL_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DM_SNDPL_DIV_CD==null?"null":DM_SNDPL_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CMC_MN_TMN_AGR_YN==null?"null":CMC_MN_TMN_AGR_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PTY_IDF_INF_SEQ==null?"null":PTY_IDF_INF_SEQ.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PSSPE_CD==null?"null":PSSPE_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(JOB_CD==null?"null":JOB_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(JOB_GRD_CD==null?"null":JOB_GRD_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(MARY_YN==null?"null":MARY_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CHDN_DRV_YN==null?"null":CHDN_DRV_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(INSPE_TP_CD==null?"null":INSPE_TP_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(POL_RCGPE_YN==null?"null":POL_RCGPE_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(HAPE_EMP_DIV_CD==null?"null":HAPE_EMP_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(HAPE_AGE_SIC_DIV_CD==null?"null":HAPE_AGE_SIC_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(LCNS_DIV_CD==null?"null":LCNS_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(LCNS_NO==null?"null":LCNS_NO, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(LCNS_DLV_DT==null?"null":"" + LCNS_DLV_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ENTCO_DT==null?"null":"" + ENTCO_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ATL_CTR_ID==null?"null":ATL_CTR_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ATL_CTR_PTY_SEQ==null?"null":ATL_CTR_PTY_SEQ.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ATL_HIS_SEQ==null?"null":ATL_HIS_SEQ.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ENDR_NO==null?"null":ENDR_NO.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RTRO_ENDR_NO==null?"null":RTRO_ENDR_NO.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ENDR_HIS_ST_NO==null?"null":ENDR_HIS_ST_NO.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ENDR_HIS_ED_NO==null?"null":ENDR_HIS_ED_NO.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SUMUP_DT==null?"null":"" + SUMUP_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(HIS_ST_DT==null?"null":"" + HIS_ST_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(HIS_ED_DT==null?"null":"" + HIS_ED_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(INPPE_ORG_ID==null?"null":INPPE_ORG_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SYS_OCC_DTM==null?"null":"" + SYS_OCC_DTM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SYS_DEL_DIV_CD==null?"null":SYS_DEL_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(OCC_IP==null?"null":OCC_IP, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(APP_ID==null?"null":APP_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DATA_CHNG_DTM==null?"null":"" + DATA_CHNG_DTM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DSC_CON==null?"null":DSC_CON, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RNM_CNF_KD_CD==null?"null":RNM_CNF_KD_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(IDF_ATH_CHT_ISS_DT==null?"null":"" + IDF_ATH_CHT_ISS_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ISS_INST_NM==null?"null":ISS_INST_NM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ADDTL_REF_NO==null?"null":ADDTL_REF_NO, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RNM_ATH_FNM==null?"null":RNM_ATH_FNM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(EIH_LDG_DTM==null?"null":"" + EIH_LDG_DTM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(KIS_ETP_CD==null?"null":KIS_ETP_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(APL_ST_DT==null?"null":"" + APL_ST_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(APL_ED_DT==null?"null":"" + APL_ED_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(HNC_REG_ED_DT==null?"null":"" + HNC_REG_ED_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(HNCPE_CTR_YN==null?"null":HNCPE_CTR_YN, delimiters));
    if (useRecordDelim) {
      __sb.append(delimiters.getLinesTerminatedBy());
    }
    return __sb.toString();
  }
  public void toString0(DelimiterSet delimiters, StringBuilder __sb, char fieldDelim) {
    __sb.append(FieldFormatter.escapeAndEnclose(CTR_ID==null?"null":CTR_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CTR_PTY_SEQ==null?"null":CTR_PTY_SEQ.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(HIS_SEQ==null?"null":HIS_SEQ.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(BIZ_SYS_CD==null?"null":BIZ_SYS_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PRCTR_NO==null?"null":PRCTR_NO, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RL_APL_RNG_DIV_CD==null?"null":RL_APL_RNG_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DATA_ID==null?"null":DATA_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DATA_SEQ==null?"null":DATA_SEQ.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CTR_PTY_RL_CD==null?"null":CTR_PTY_RL_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PTY_DIV_CD==null?"null":PTY_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PTY_ID==null?"null":PTY_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CUS_NO==null?"null":CUS_NO, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CUS_BCH_NO==null?"null":CUS_BCH_NO, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RL_RTO==null?"null":RL_RTO.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RL_REL_CD==null?"null":RL_REL_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(REL_PTY_RL_CD==null?"null":REL_PTY_RL_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(TXPF_REG_TRGPE_DIV_CD==null?"null":TXPF_REG_TRGPE_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(POLHD_GRDE_CD==null?"null":POLHD_GRDE_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(POLHD_CHNG_RSN_CD==null?"null":POLHD_CHNG_RSN_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DTL_ADJT_CD==null?"null":DTL_ADJT_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RPS_CTR_PTY_YN==null?"null":RPS_CTR_PTY_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(GNR_POLHD_DIV_CD==null?"null":GNR_POLHD_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RLSIT_NRMN_CD==null?"null":RLSIT_NRMN_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(AGE==null?"null":AGE.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(NKNM==null?"null":NKNM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ADDTL_FM_NM==null?"null":ADDTL_FM_NM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(POL_RCEPL_DIV_CD==null?"null":POL_RCEPL_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DM_SNDPL_DIV_CD==null?"null":DM_SNDPL_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CMC_MN_TMN_AGR_YN==null?"null":CMC_MN_TMN_AGR_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PTY_IDF_INF_SEQ==null?"null":PTY_IDF_INF_SEQ.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PSSPE_CD==null?"null":PSSPE_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(JOB_CD==null?"null":JOB_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(JOB_GRD_CD==null?"null":JOB_GRD_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(MARY_YN==null?"null":MARY_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CHDN_DRV_YN==null?"null":CHDN_DRV_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(INSPE_TP_CD==null?"null":INSPE_TP_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(POL_RCGPE_YN==null?"null":POL_RCGPE_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(HAPE_EMP_DIV_CD==null?"null":HAPE_EMP_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(HAPE_AGE_SIC_DIV_CD==null?"null":HAPE_AGE_SIC_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(LCNS_DIV_CD==null?"null":LCNS_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(LCNS_NO==null?"null":LCNS_NO, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(LCNS_DLV_DT==null?"null":"" + LCNS_DLV_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ENTCO_DT==null?"null":"" + ENTCO_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ATL_CTR_ID==null?"null":ATL_CTR_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ATL_CTR_PTY_SEQ==null?"null":ATL_CTR_PTY_SEQ.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ATL_HIS_SEQ==null?"null":ATL_HIS_SEQ.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ENDR_NO==null?"null":ENDR_NO.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RTRO_ENDR_NO==null?"null":RTRO_ENDR_NO.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ENDR_HIS_ST_NO==null?"null":ENDR_HIS_ST_NO.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ENDR_HIS_ED_NO==null?"null":ENDR_HIS_ED_NO.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SUMUP_DT==null?"null":"" + SUMUP_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(HIS_ST_DT==null?"null":"" + HIS_ST_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(HIS_ED_DT==null?"null":"" + HIS_ED_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(INPPE_ORG_ID==null?"null":INPPE_ORG_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SYS_OCC_DTM==null?"null":"" + SYS_OCC_DTM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SYS_DEL_DIV_CD==null?"null":SYS_DEL_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(OCC_IP==null?"null":OCC_IP, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(APP_ID==null?"null":APP_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DATA_CHNG_DTM==null?"null":"" + DATA_CHNG_DTM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DSC_CON==null?"null":DSC_CON, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RNM_CNF_KD_CD==null?"null":RNM_CNF_KD_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(IDF_ATH_CHT_ISS_DT==null?"null":"" + IDF_ATH_CHT_ISS_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ISS_INST_NM==null?"null":ISS_INST_NM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ADDTL_REF_NO==null?"null":ADDTL_REF_NO, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RNM_ATH_FNM==null?"null":RNM_ATH_FNM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(EIH_LDG_DTM==null?"null":"" + EIH_LDG_DTM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(KIS_ETP_CD==null?"null":KIS_ETP_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(APL_ST_DT==null?"null":"" + APL_ST_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(APL_ED_DT==null?"null":"" + APL_ED_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(HNC_REG_ED_DT==null?"null":"" + HNC_REG_ED_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(HNCPE_CTR_YN==null?"null":HNCPE_CTR_YN, delimiters));
  }
  private static final DelimiterSet __inputDelimiters = new DelimiterSet((char) 1, (char) 10, (char) 0, (char) 0, false);
  private RecordParser __parser;
  public void parse(Text __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(CharSequence __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(byte [] __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(char [] __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(ByteBuffer __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(CharBuffer __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  private void __loadFromFields(List<String> fields) {
    Iterator<String> __it = fields.listIterator();
    String __cur_str = null;
    try {
    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CTR_ID = null; } else {
      this.CTR_ID = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.CTR_PTY_SEQ = null; } else {
      this.CTR_PTY_SEQ = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.HIS_SEQ = null; } else {
      this.HIS_SEQ = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.BIZ_SYS_CD = null; } else {
      this.BIZ_SYS_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.PRCTR_NO = null; } else {
      this.PRCTR_NO = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.RL_APL_RNG_DIV_CD = null; } else {
      this.RL_APL_RNG_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.DATA_ID = null; } else {
      this.DATA_ID = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.DATA_SEQ = null; } else {
      this.DATA_SEQ = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CTR_PTY_RL_CD = null; } else {
      this.CTR_PTY_RL_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.PTY_DIV_CD = null; } else {
      this.PTY_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.PTY_ID = null; } else {
      this.PTY_ID = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CUS_NO = null; } else {
      this.CUS_NO = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CUS_BCH_NO = null; } else {
      this.CUS_BCH_NO = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RL_RTO = null; } else {
      this.RL_RTO = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.RL_REL_CD = null; } else {
      this.RL_REL_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.REL_PTY_RL_CD = null; } else {
      this.REL_PTY_RL_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.TXPF_REG_TRGPE_DIV_CD = null; } else {
      this.TXPF_REG_TRGPE_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.POLHD_GRDE_CD = null; } else {
      this.POLHD_GRDE_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.POLHD_CHNG_RSN_CD = null; } else {
      this.POLHD_CHNG_RSN_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.DTL_ADJT_CD = null; } else {
      this.DTL_ADJT_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.RPS_CTR_PTY_YN = null; } else {
      this.RPS_CTR_PTY_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.GNR_POLHD_DIV_CD = null; } else {
      this.GNR_POLHD_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.RLSIT_NRMN_CD = null; } else {
      this.RLSIT_NRMN_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.AGE = null; } else {
      this.AGE = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.NKNM = null; } else {
      this.NKNM = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.ADDTL_FM_NM = null; } else {
      this.ADDTL_FM_NM = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.POL_RCEPL_DIV_CD = null; } else {
      this.POL_RCEPL_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.DM_SNDPL_DIV_CD = null; } else {
      this.DM_SNDPL_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CMC_MN_TMN_AGR_YN = null; } else {
      this.CMC_MN_TMN_AGR_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.PTY_IDF_INF_SEQ = null; } else {
      this.PTY_IDF_INF_SEQ = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.PSSPE_CD = null; } else {
      this.PSSPE_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.JOB_CD = null; } else {
      this.JOB_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.JOB_GRD_CD = null; } else {
      this.JOB_GRD_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.MARY_YN = null; } else {
      this.MARY_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CHDN_DRV_YN = null; } else {
      this.CHDN_DRV_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.INSPE_TP_CD = null; } else {
      this.INSPE_TP_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.POL_RCGPE_YN = null; } else {
      this.POL_RCGPE_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.HAPE_EMP_DIV_CD = null; } else {
      this.HAPE_EMP_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.HAPE_AGE_SIC_DIV_CD = null; } else {
      this.HAPE_AGE_SIC_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.LCNS_DIV_CD = null; } else {
      this.LCNS_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.LCNS_NO = null; } else {
      this.LCNS_NO = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.LCNS_DLV_DT = null; } else {
      this.LCNS_DLV_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.ENTCO_DT = null; } else {
      this.ENTCO_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.ATL_CTR_ID = null; } else {
      this.ATL_CTR_ID = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.ATL_CTR_PTY_SEQ = null; } else {
      this.ATL_CTR_PTY_SEQ = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.ATL_HIS_SEQ = null; } else {
      this.ATL_HIS_SEQ = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.ENDR_NO = null; } else {
      this.ENDR_NO = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RTRO_ENDR_NO = null; } else {
      this.RTRO_ENDR_NO = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.ENDR_HIS_ST_NO = null; } else {
      this.ENDR_HIS_ST_NO = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.ENDR_HIS_ED_NO = null; } else {
      this.ENDR_HIS_ED_NO = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.SUMUP_DT = null; } else {
      this.SUMUP_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.HIS_ST_DT = null; } else {
      this.HIS_ST_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.HIS_ED_DT = null; } else {
      this.HIS_ED_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.INPPE_ORG_ID = null; } else {
      this.INPPE_ORG_ID = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.SYS_OCC_DTM = null; } else {
      this.SYS_OCC_DTM = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.SYS_DEL_DIV_CD = null; } else {
      this.SYS_DEL_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.OCC_IP = null; } else {
      this.OCC_IP = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.APP_ID = null; } else {
      this.APP_ID = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.DATA_CHNG_DTM = null; } else {
      this.DATA_CHNG_DTM = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.DSC_CON = null; } else {
      this.DSC_CON = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.RNM_CNF_KD_CD = null; } else {
      this.RNM_CNF_KD_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.IDF_ATH_CHT_ISS_DT = null; } else {
      this.IDF_ATH_CHT_ISS_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.ISS_INST_NM = null; } else {
      this.ISS_INST_NM = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.ADDTL_REF_NO = null; } else {
      this.ADDTL_REF_NO = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.RNM_ATH_FNM = null; } else {
      this.RNM_ATH_FNM = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.EIH_LDG_DTM = null; } else {
      this.EIH_LDG_DTM = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.KIS_ETP_CD = null; } else {
      this.KIS_ETP_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.APL_ST_DT = null; } else {
      this.APL_ST_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.APL_ED_DT = null; } else {
      this.APL_ED_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.HNC_REG_ED_DT = null; } else {
      this.HNC_REG_ED_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.HNCPE_CTR_YN = null; } else {
      this.HNCPE_CTR_YN = __cur_str;
    }

    } catch (RuntimeException e) {    throw new RuntimeException("Can't parse input data: '" + __cur_str + "'", e);    }  }

  private void __loadFromFields0(Iterator<String> __it) {
    String __cur_str = null;
    try {
    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CTR_ID = null; } else {
      this.CTR_ID = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.CTR_PTY_SEQ = null; } else {
      this.CTR_PTY_SEQ = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.HIS_SEQ = null; } else {
      this.HIS_SEQ = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.BIZ_SYS_CD = null; } else {
      this.BIZ_SYS_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.PRCTR_NO = null; } else {
      this.PRCTR_NO = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.RL_APL_RNG_DIV_CD = null; } else {
      this.RL_APL_RNG_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.DATA_ID = null; } else {
      this.DATA_ID = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.DATA_SEQ = null; } else {
      this.DATA_SEQ = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CTR_PTY_RL_CD = null; } else {
      this.CTR_PTY_RL_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.PTY_DIV_CD = null; } else {
      this.PTY_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.PTY_ID = null; } else {
      this.PTY_ID = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CUS_NO = null; } else {
      this.CUS_NO = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CUS_BCH_NO = null; } else {
      this.CUS_BCH_NO = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RL_RTO = null; } else {
      this.RL_RTO = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.RL_REL_CD = null; } else {
      this.RL_REL_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.REL_PTY_RL_CD = null; } else {
      this.REL_PTY_RL_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.TXPF_REG_TRGPE_DIV_CD = null; } else {
      this.TXPF_REG_TRGPE_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.POLHD_GRDE_CD = null; } else {
      this.POLHD_GRDE_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.POLHD_CHNG_RSN_CD = null; } else {
      this.POLHD_CHNG_RSN_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.DTL_ADJT_CD = null; } else {
      this.DTL_ADJT_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.RPS_CTR_PTY_YN = null; } else {
      this.RPS_CTR_PTY_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.GNR_POLHD_DIV_CD = null; } else {
      this.GNR_POLHD_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.RLSIT_NRMN_CD = null; } else {
      this.RLSIT_NRMN_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.AGE = null; } else {
      this.AGE = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.NKNM = null; } else {
      this.NKNM = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.ADDTL_FM_NM = null; } else {
      this.ADDTL_FM_NM = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.POL_RCEPL_DIV_CD = null; } else {
      this.POL_RCEPL_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.DM_SNDPL_DIV_CD = null; } else {
      this.DM_SNDPL_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CMC_MN_TMN_AGR_YN = null; } else {
      this.CMC_MN_TMN_AGR_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.PTY_IDF_INF_SEQ = null; } else {
      this.PTY_IDF_INF_SEQ = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.PSSPE_CD = null; } else {
      this.PSSPE_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.JOB_CD = null; } else {
      this.JOB_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.JOB_GRD_CD = null; } else {
      this.JOB_GRD_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.MARY_YN = null; } else {
      this.MARY_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CHDN_DRV_YN = null; } else {
      this.CHDN_DRV_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.INSPE_TP_CD = null; } else {
      this.INSPE_TP_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.POL_RCGPE_YN = null; } else {
      this.POL_RCGPE_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.HAPE_EMP_DIV_CD = null; } else {
      this.HAPE_EMP_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.HAPE_AGE_SIC_DIV_CD = null; } else {
      this.HAPE_AGE_SIC_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.LCNS_DIV_CD = null; } else {
      this.LCNS_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.LCNS_NO = null; } else {
      this.LCNS_NO = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.LCNS_DLV_DT = null; } else {
      this.LCNS_DLV_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.ENTCO_DT = null; } else {
      this.ENTCO_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.ATL_CTR_ID = null; } else {
      this.ATL_CTR_ID = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.ATL_CTR_PTY_SEQ = null; } else {
      this.ATL_CTR_PTY_SEQ = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.ATL_HIS_SEQ = null; } else {
      this.ATL_HIS_SEQ = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.ENDR_NO = null; } else {
      this.ENDR_NO = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RTRO_ENDR_NO = null; } else {
      this.RTRO_ENDR_NO = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.ENDR_HIS_ST_NO = null; } else {
      this.ENDR_HIS_ST_NO = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.ENDR_HIS_ED_NO = null; } else {
      this.ENDR_HIS_ED_NO = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.SUMUP_DT = null; } else {
      this.SUMUP_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.HIS_ST_DT = null; } else {
      this.HIS_ST_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.HIS_ED_DT = null; } else {
      this.HIS_ED_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.INPPE_ORG_ID = null; } else {
      this.INPPE_ORG_ID = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.SYS_OCC_DTM = null; } else {
      this.SYS_OCC_DTM = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.SYS_DEL_DIV_CD = null; } else {
      this.SYS_DEL_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.OCC_IP = null; } else {
      this.OCC_IP = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.APP_ID = null; } else {
      this.APP_ID = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.DATA_CHNG_DTM = null; } else {
      this.DATA_CHNG_DTM = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.DSC_CON = null; } else {
      this.DSC_CON = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.RNM_CNF_KD_CD = null; } else {
      this.RNM_CNF_KD_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.IDF_ATH_CHT_ISS_DT = null; } else {
      this.IDF_ATH_CHT_ISS_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.ISS_INST_NM = null; } else {
      this.ISS_INST_NM = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.ADDTL_REF_NO = null; } else {
      this.ADDTL_REF_NO = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.RNM_ATH_FNM = null; } else {
      this.RNM_ATH_FNM = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.EIH_LDG_DTM = null; } else {
      this.EIH_LDG_DTM = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.KIS_ETP_CD = null; } else {
      this.KIS_ETP_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.APL_ST_DT = null; } else {
      this.APL_ST_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.APL_ED_DT = null; } else {
      this.APL_ED_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.HNC_REG_ED_DT = null; } else {
      this.HNC_REG_ED_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.HNCPE_CTR_YN = null; } else {
      this.HNCPE_CTR_YN = __cur_str;
    }

    } catch (RuntimeException e) {    throw new RuntimeException("Can't parse input data: '" + __cur_str + "'", e);    }  }

  public Object clone() throws CloneNotSupportedException {
    QueryResult o = (QueryResult) super.clone();
    o.LCNS_DLV_DT = (o.LCNS_DLV_DT != null) ? (java.sql.Timestamp) o.LCNS_DLV_DT.clone() : null;
    o.ENTCO_DT = (o.ENTCO_DT != null) ? (java.sql.Timestamp) o.ENTCO_DT.clone() : null;
    o.SUMUP_DT = (o.SUMUP_DT != null) ? (java.sql.Timestamp) o.SUMUP_DT.clone() : null;
    o.HIS_ST_DT = (o.HIS_ST_DT != null) ? (java.sql.Timestamp) o.HIS_ST_DT.clone() : null;
    o.HIS_ED_DT = (o.HIS_ED_DT != null) ? (java.sql.Timestamp) o.HIS_ED_DT.clone() : null;
    o.SYS_OCC_DTM = (o.SYS_OCC_DTM != null) ? (java.sql.Timestamp) o.SYS_OCC_DTM.clone() : null;
    o.DATA_CHNG_DTM = (o.DATA_CHNG_DTM != null) ? (java.sql.Timestamp) o.DATA_CHNG_DTM.clone() : null;
    o.IDF_ATH_CHT_ISS_DT = (o.IDF_ATH_CHT_ISS_DT != null) ? (java.sql.Timestamp) o.IDF_ATH_CHT_ISS_DT.clone() : null;
    o.EIH_LDG_DTM = (o.EIH_LDG_DTM != null) ? (java.sql.Timestamp) o.EIH_LDG_DTM.clone() : null;
    o.APL_ST_DT = (o.APL_ST_DT != null) ? (java.sql.Timestamp) o.APL_ST_DT.clone() : null;
    o.APL_ED_DT = (o.APL_ED_DT != null) ? (java.sql.Timestamp) o.APL_ED_DT.clone() : null;
    o.HNC_REG_ED_DT = (o.HNC_REG_ED_DT != null) ? (java.sql.Timestamp) o.HNC_REG_ED_DT.clone() : null;
    return o;
  }

  public void clone0(QueryResult o) throws CloneNotSupportedException {
    o.LCNS_DLV_DT = (o.LCNS_DLV_DT != null) ? (java.sql.Timestamp) o.LCNS_DLV_DT.clone() : null;
    o.ENTCO_DT = (o.ENTCO_DT != null) ? (java.sql.Timestamp) o.ENTCO_DT.clone() : null;
    o.SUMUP_DT = (o.SUMUP_DT != null) ? (java.sql.Timestamp) o.SUMUP_DT.clone() : null;
    o.HIS_ST_DT = (o.HIS_ST_DT != null) ? (java.sql.Timestamp) o.HIS_ST_DT.clone() : null;
    o.HIS_ED_DT = (o.HIS_ED_DT != null) ? (java.sql.Timestamp) o.HIS_ED_DT.clone() : null;
    o.SYS_OCC_DTM = (o.SYS_OCC_DTM != null) ? (java.sql.Timestamp) o.SYS_OCC_DTM.clone() : null;
    o.DATA_CHNG_DTM = (o.DATA_CHNG_DTM != null) ? (java.sql.Timestamp) o.DATA_CHNG_DTM.clone() : null;
    o.IDF_ATH_CHT_ISS_DT = (o.IDF_ATH_CHT_ISS_DT != null) ? (java.sql.Timestamp) o.IDF_ATH_CHT_ISS_DT.clone() : null;
    o.EIH_LDG_DTM = (o.EIH_LDG_DTM != null) ? (java.sql.Timestamp) o.EIH_LDG_DTM.clone() : null;
    o.APL_ST_DT = (o.APL_ST_DT != null) ? (java.sql.Timestamp) o.APL_ST_DT.clone() : null;
    o.APL_ED_DT = (o.APL_ED_DT != null) ? (java.sql.Timestamp) o.APL_ED_DT.clone() : null;
    o.HNC_REG_ED_DT = (o.HNC_REG_ED_DT != null) ? (java.sql.Timestamp) o.HNC_REG_ED_DT.clone() : null;
  }

  public Map<String, Object> getFieldMap() {
    Map<String, Object> __sqoop$field_map = new HashMap<String, Object>();
    __sqoop$field_map.put("CTR_ID", this.CTR_ID);
    __sqoop$field_map.put("CTR_PTY_SEQ", this.CTR_PTY_SEQ);
    __sqoop$field_map.put("HIS_SEQ", this.HIS_SEQ);
    __sqoop$field_map.put("BIZ_SYS_CD", this.BIZ_SYS_CD);
    __sqoop$field_map.put("PRCTR_NO", this.PRCTR_NO);
    __sqoop$field_map.put("RL_APL_RNG_DIV_CD", this.RL_APL_RNG_DIV_CD);
    __sqoop$field_map.put("DATA_ID", this.DATA_ID);
    __sqoop$field_map.put("DATA_SEQ", this.DATA_SEQ);
    __sqoop$field_map.put("CTR_PTY_RL_CD", this.CTR_PTY_RL_CD);
    __sqoop$field_map.put("PTY_DIV_CD", this.PTY_DIV_CD);
    __sqoop$field_map.put("PTY_ID", this.PTY_ID);
    __sqoop$field_map.put("CUS_NO", this.CUS_NO);
    __sqoop$field_map.put("CUS_BCH_NO", this.CUS_BCH_NO);
    __sqoop$field_map.put("RL_RTO", this.RL_RTO);
    __sqoop$field_map.put("RL_REL_CD", this.RL_REL_CD);
    __sqoop$field_map.put("REL_PTY_RL_CD", this.REL_PTY_RL_CD);
    __sqoop$field_map.put("TXPF_REG_TRGPE_DIV_CD", this.TXPF_REG_TRGPE_DIV_CD);
    __sqoop$field_map.put("POLHD_GRDE_CD", this.POLHD_GRDE_CD);
    __sqoop$field_map.put("POLHD_CHNG_RSN_CD", this.POLHD_CHNG_RSN_CD);
    __sqoop$field_map.put("DTL_ADJT_CD", this.DTL_ADJT_CD);
    __sqoop$field_map.put("RPS_CTR_PTY_YN", this.RPS_CTR_PTY_YN);
    __sqoop$field_map.put("GNR_POLHD_DIV_CD", this.GNR_POLHD_DIV_CD);
    __sqoop$field_map.put("RLSIT_NRMN_CD", this.RLSIT_NRMN_CD);
    __sqoop$field_map.put("AGE", this.AGE);
    __sqoop$field_map.put("NKNM", this.NKNM);
    __sqoop$field_map.put("ADDTL_FM_NM", this.ADDTL_FM_NM);
    __sqoop$field_map.put("POL_RCEPL_DIV_CD", this.POL_RCEPL_DIV_CD);
    __sqoop$field_map.put("DM_SNDPL_DIV_CD", this.DM_SNDPL_DIV_CD);
    __sqoop$field_map.put("CMC_MN_TMN_AGR_YN", this.CMC_MN_TMN_AGR_YN);
    __sqoop$field_map.put("PTY_IDF_INF_SEQ", this.PTY_IDF_INF_SEQ);
    __sqoop$field_map.put("PSSPE_CD", this.PSSPE_CD);
    __sqoop$field_map.put("JOB_CD", this.JOB_CD);
    __sqoop$field_map.put("JOB_GRD_CD", this.JOB_GRD_CD);
    __sqoop$field_map.put("MARY_YN", this.MARY_YN);
    __sqoop$field_map.put("CHDN_DRV_YN", this.CHDN_DRV_YN);
    __sqoop$field_map.put("INSPE_TP_CD", this.INSPE_TP_CD);
    __sqoop$field_map.put("POL_RCGPE_YN", this.POL_RCGPE_YN);
    __sqoop$field_map.put("HAPE_EMP_DIV_CD", this.HAPE_EMP_DIV_CD);
    __sqoop$field_map.put("HAPE_AGE_SIC_DIV_CD", this.HAPE_AGE_SIC_DIV_CD);
    __sqoop$field_map.put("LCNS_DIV_CD", this.LCNS_DIV_CD);
    __sqoop$field_map.put("LCNS_NO", this.LCNS_NO);
    __sqoop$field_map.put("LCNS_DLV_DT", this.LCNS_DLV_DT);
    __sqoop$field_map.put("ENTCO_DT", this.ENTCO_DT);
    __sqoop$field_map.put("ATL_CTR_ID", this.ATL_CTR_ID);
    __sqoop$field_map.put("ATL_CTR_PTY_SEQ", this.ATL_CTR_PTY_SEQ);
    __sqoop$field_map.put("ATL_HIS_SEQ", this.ATL_HIS_SEQ);
    __sqoop$field_map.put("ENDR_NO", this.ENDR_NO);
    __sqoop$field_map.put("RTRO_ENDR_NO", this.RTRO_ENDR_NO);
    __sqoop$field_map.put("ENDR_HIS_ST_NO", this.ENDR_HIS_ST_NO);
    __sqoop$field_map.put("ENDR_HIS_ED_NO", this.ENDR_HIS_ED_NO);
    __sqoop$field_map.put("SUMUP_DT", this.SUMUP_DT);
    __sqoop$field_map.put("HIS_ST_DT", this.HIS_ST_DT);
    __sqoop$field_map.put("HIS_ED_DT", this.HIS_ED_DT);
    __sqoop$field_map.put("INPPE_ORG_ID", this.INPPE_ORG_ID);
    __sqoop$field_map.put("SYS_OCC_DTM", this.SYS_OCC_DTM);
    __sqoop$field_map.put("SYS_DEL_DIV_CD", this.SYS_DEL_DIV_CD);
    __sqoop$field_map.put("OCC_IP", this.OCC_IP);
    __sqoop$field_map.put("APP_ID", this.APP_ID);
    __sqoop$field_map.put("DATA_CHNG_DTM", this.DATA_CHNG_DTM);
    __sqoop$field_map.put("DSC_CON", this.DSC_CON);
    __sqoop$field_map.put("RNM_CNF_KD_CD", this.RNM_CNF_KD_CD);
    __sqoop$field_map.put("IDF_ATH_CHT_ISS_DT", this.IDF_ATH_CHT_ISS_DT);
    __sqoop$field_map.put("ISS_INST_NM", this.ISS_INST_NM);
    __sqoop$field_map.put("ADDTL_REF_NO", this.ADDTL_REF_NO);
    __sqoop$field_map.put("RNM_ATH_FNM", this.RNM_ATH_FNM);
    __sqoop$field_map.put("EIH_LDG_DTM", this.EIH_LDG_DTM);
    __sqoop$field_map.put("KIS_ETP_CD", this.KIS_ETP_CD);
    __sqoop$field_map.put("APL_ST_DT", this.APL_ST_DT);
    __sqoop$field_map.put("APL_ED_DT", this.APL_ED_DT);
    __sqoop$field_map.put("HNC_REG_ED_DT", this.HNC_REG_ED_DT);
    __sqoop$field_map.put("HNCPE_CTR_YN", this.HNCPE_CTR_YN);
    return __sqoop$field_map;
  }

  public void getFieldMap0(Map<String, Object> __sqoop$field_map) {
    __sqoop$field_map.put("CTR_ID", this.CTR_ID);
    __sqoop$field_map.put("CTR_PTY_SEQ", this.CTR_PTY_SEQ);
    __sqoop$field_map.put("HIS_SEQ", this.HIS_SEQ);
    __sqoop$field_map.put("BIZ_SYS_CD", this.BIZ_SYS_CD);
    __sqoop$field_map.put("PRCTR_NO", this.PRCTR_NO);
    __sqoop$field_map.put("RL_APL_RNG_DIV_CD", this.RL_APL_RNG_DIV_CD);
    __sqoop$field_map.put("DATA_ID", this.DATA_ID);
    __sqoop$field_map.put("DATA_SEQ", this.DATA_SEQ);
    __sqoop$field_map.put("CTR_PTY_RL_CD", this.CTR_PTY_RL_CD);
    __sqoop$field_map.put("PTY_DIV_CD", this.PTY_DIV_CD);
    __sqoop$field_map.put("PTY_ID", this.PTY_ID);
    __sqoop$field_map.put("CUS_NO", this.CUS_NO);
    __sqoop$field_map.put("CUS_BCH_NO", this.CUS_BCH_NO);
    __sqoop$field_map.put("RL_RTO", this.RL_RTO);
    __sqoop$field_map.put("RL_REL_CD", this.RL_REL_CD);
    __sqoop$field_map.put("REL_PTY_RL_CD", this.REL_PTY_RL_CD);
    __sqoop$field_map.put("TXPF_REG_TRGPE_DIV_CD", this.TXPF_REG_TRGPE_DIV_CD);
    __sqoop$field_map.put("POLHD_GRDE_CD", this.POLHD_GRDE_CD);
    __sqoop$field_map.put("POLHD_CHNG_RSN_CD", this.POLHD_CHNG_RSN_CD);
    __sqoop$field_map.put("DTL_ADJT_CD", this.DTL_ADJT_CD);
    __sqoop$field_map.put("RPS_CTR_PTY_YN", this.RPS_CTR_PTY_YN);
    __sqoop$field_map.put("GNR_POLHD_DIV_CD", this.GNR_POLHD_DIV_CD);
    __sqoop$field_map.put("RLSIT_NRMN_CD", this.RLSIT_NRMN_CD);
    __sqoop$field_map.put("AGE", this.AGE);
    __sqoop$field_map.put("NKNM", this.NKNM);
    __sqoop$field_map.put("ADDTL_FM_NM", this.ADDTL_FM_NM);
    __sqoop$field_map.put("POL_RCEPL_DIV_CD", this.POL_RCEPL_DIV_CD);
    __sqoop$field_map.put("DM_SNDPL_DIV_CD", this.DM_SNDPL_DIV_CD);
    __sqoop$field_map.put("CMC_MN_TMN_AGR_YN", this.CMC_MN_TMN_AGR_YN);
    __sqoop$field_map.put("PTY_IDF_INF_SEQ", this.PTY_IDF_INF_SEQ);
    __sqoop$field_map.put("PSSPE_CD", this.PSSPE_CD);
    __sqoop$field_map.put("JOB_CD", this.JOB_CD);
    __sqoop$field_map.put("JOB_GRD_CD", this.JOB_GRD_CD);
    __sqoop$field_map.put("MARY_YN", this.MARY_YN);
    __sqoop$field_map.put("CHDN_DRV_YN", this.CHDN_DRV_YN);
    __sqoop$field_map.put("INSPE_TP_CD", this.INSPE_TP_CD);
    __sqoop$field_map.put("POL_RCGPE_YN", this.POL_RCGPE_YN);
    __sqoop$field_map.put("HAPE_EMP_DIV_CD", this.HAPE_EMP_DIV_CD);
    __sqoop$field_map.put("HAPE_AGE_SIC_DIV_CD", this.HAPE_AGE_SIC_DIV_CD);
    __sqoop$field_map.put("LCNS_DIV_CD", this.LCNS_DIV_CD);
    __sqoop$field_map.put("LCNS_NO", this.LCNS_NO);
    __sqoop$field_map.put("LCNS_DLV_DT", this.LCNS_DLV_DT);
    __sqoop$field_map.put("ENTCO_DT", this.ENTCO_DT);
    __sqoop$field_map.put("ATL_CTR_ID", this.ATL_CTR_ID);
    __sqoop$field_map.put("ATL_CTR_PTY_SEQ", this.ATL_CTR_PTY_SEQ);
    __sqoop$field_map.put("ATL_HIS_SEQ", this.ATL_HIS_SEQ);
    __sqoop$field_map.put("ENDR_NO", this.ENDR_NO);
    __sqoop$field_map.put("RTRO_ENDR_NO", this.RTRO_ENDR_NO);
    __sqoop$field_map.put("ENDR_HIS_ST_NO", this.ENDR_HIS_ST_NO);
    __sqoop$field_map.put("ENDR_HIS_ED_NO", this.ENDR_HIS_ED_NO);
    __sqoop$field_map.put("SUMUP_DT", this.SUMUP_DT);
    __sqoop$field_map.put("HIS_ST_DT", this.HIS_ST_DT);
    __sqoop$field_map.put("HIS_ED_DT", this.HIS_ED_DT);
    __sqoop$field_map.put("INPPE_ORG_ID", this.INPPE_ORG_ID);
    __sqoop$field_map.put("SYS_OCC_DTM", this.SYS_OCC_DTM);
    __sqoop$field_map.put("SYS_DEL_DIV_CD", this.SYS_DEL_DIV_CD);
    __sqoop$field_map.put("OCC_IP", this.OCC_IP);
    __sqoop$field_map.put("APP_ID", this.APP_ID);
    __sqoop$field_map.put("DATA_CHNG_DTM", this.DATA_CHNG_DTM);
    __sqoop$field_map.put("DSC_CON", this.DSC_CON);
    __sqoop$field_map.put("RNM_CNF_KD_CD", this.RNM_CNF_KD_CD);
    __sqoop$field_map.put("IDF_ATH_CHT_ISS_DT", this.IDF_ATH_CHT_ISS_DT);
    __sqoop$field_map.put("ISS_INST_NM", this.ISS_INST_NM);
    __sqoop$field_map.put("ADDTL_REF_NO", this.ADDTL_REF_NO);
    __sqoop$field_map.put("RNM_ATH_FNM", this.RNM_ATH_FNM);
    __sqoop$field_map.put("EIH_LDG_DTM", this.EIH_LDG_DTM);
    __sqoop$field_map.put("KIS_ETP_CD", this.KIS_ETP_CD);
    __sqoop$field_map.put("APL_ST_DT", this.APL_ST_DT);
    __sqoop$field_map.put("APL_ED_DT", this.APL_ED_DT);
    __sqoop$field_map.put("HNC_REG_ED_DT", this.HNC_REG_ED_DT);
    __sqoop$field_map.put("HNCPE_CTR_YN", this.HNCPE_CTR_YN);
  }

  public void setField(String __fieldName, Object __fieldVal) {
    if (!setters.containsKey(__fieldName)) {
      throw new RuntimeException("No such field:"+__fieldName);
    }
    setters.get(__fieldName).setField(__fieldVal);
  }

}
