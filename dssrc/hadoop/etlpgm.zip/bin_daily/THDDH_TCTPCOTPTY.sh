#!/bin/bash

if [ $# -eq 0 ]
then           
    ARGS=N    
else           
    ARGS=$1
fi             

NOW=$(date +"+%Y-%m-%d_%T")
SHLOG_DIR=/sqoopbin/scripts/etlpgm/cur_log
HISLOG_DIR=/sqoopbin/scripts/etlpgm/his_log

export HADOOP_OPTS=-Djava.security.egd=file:/dev/../dev/urandom
export ORACLE_BASE=/sw/oracle
export ORACLE_HOME=/sw/oracle/product/11.2.0.4/client_1
export LD_LIBRARY_PATH=/sw/oracle/product/11.2.0.4/client_1/lib:/sw/oracle/product/11.2.0.4/client_1/lib:
export PATH=/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/usr/lib64/qt-3.3/bin:/usr/hdp/3.0.0.0-1634/spark2/bin/:/var/opt/node/bin/:/opt/maven/bin:/usr/local/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/home/hdpapp/workspace/data-science-at-the-command-line/tools:/home/hdpapp/.local/bin:/home/hdpapp/bin
export TNS_ADMIN=/sw/oracle/product/11.2.0.4/client_1/network/admin
export ORACLE_SID=DBEDWP2
export NLS_LANG=American_America.KO16MSWIN949

#----------------------------------------------------#
# 작업내용 : THDDH_TCTPCOTPTY 테이블 sqoop 복제 작업
# 작업주기 :  
#----------------------------------------------------#

    echo " "
    echo "*-----------[ THDDH_TCTPCOTPTY.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TCTPCOTPTY.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`  >  ${SHLOG_DIR}/THDDH_TCTPCOTPTY.shlog

#----------------------------------------------------#
# 테이블별 전체 데이터를 받아 오는 부분
#----------------------------------------------------#
    /usr/bin/hadoop fs -rm -r -f  /tmp2/LAST_THDDH_TCTPCOTPTY  >> ${SHLOG_DIR}/THDDH_TCTPCOTPTY.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.LAST_THDDH_TCTPCOTPTY ; " >> ${SHLOG_DIR}/THDDH_TCTPCOTPTY.shlog 2>&1 &&
    /usr/hdp/3.0.0.0-1634/sqoop/bin/sqoop import -D mapred.child.java.opts="-Djava.security.egd=file:/dev/../dev/urandom" \
    --connect jdbc:oracle:thin:EDWHADOOP/wjdqhrP\!23@10.91.41.172:12560:DBEDWP2 \
    --username  EDWHADOOP \
    --password wjdqhrP\!23 \
    --query "SELECT /*+ FULL(THDDH_TCTPCOTPTY) */ REPLACE(REPLACE(CTR_ID,CHR(13),''),CHR(10),'') CTR_ID
, CTR_PTY_SEQ
, HIS_SEQ
, REPLACE(REPLACE(BIZ_SYS_CD,CHR(13),''),CHR(10),'') BIZ_SYS_CD
, REPLACE(REPLACE(PRCTR_NO,CHR(13),''),CHR(10),'') PRCTR_NO
, REPLACE(REPLACE(RL_APL_RNG_DIV_CD,CHR(13),''),CHR(10),'') RL_APL_RNG_DIV_CD
, REPLACE(REPLACE(DATA_ID,CHR(13),''),CHR(10),'') DATA_ID
, DATA_SEQ
, REPLACE(REPLACE(CTR_PTY_RL_CD,CHR(13),''),CHR(10),'') CTR_PTY_RL_CD
, REPLACE(REPLACE(PTY_DIV_CD,CHR(13),''),CHR(10),'') PTY_DIV_CD
, REPLACE(REPLACE(PTY_ID,CHR(13),''),CHR(10),'') PTY_ID
, REPLACE(REPLACE(CUS_NO,CHR(13),''),CHR(10),'') CUS_NO
, REPLACE(REPLACE(CUS_BCH_NO,CHR(13),''),CHR(10),'') CUS_BCH_NO
, RL_RTO
, REPLACE(REPLACE(RL_REL_CD,CHR(13),''),CHR(10),'') RL_REL_CD
, REPLACE(REPLACE(REL_PTY_RL_CD,CHR(13),''),CHR(10),'') REL_PTY_RL_CD
, REPLACE(REPLACE(TXPF_REG_TRGPE_DIV_CD,CHR(13),''),CHR(10),'') TXPF_REG_TRGPE_DIV_CD
, REPLACE(REPLACE(POLHD_GRDE_CD,CHR(13),''),CHR(10),'') POLHD_GRDE_CD
, REPLACE(REPLACE(POLHD_CHNG_RSN_CD,CHR(13),''),CHR(10),'') POLHD_CHNG_RSN_CD
, REPLACE(REPLACE(DTL_ADJT_CD,CHR(13),''),CHR(10),'') DTL_ADJT_CD
, REPLACE(REPLACE(RPS_CTR_PTY_YN,CHR(13),''),CHR(10),'') RPS_CTR_PTY_YN
, REPLACE(REPLACE(GNR_POLHD_DIV_CD,CHR(13),''),CHR(10),'') GNR_POLHD_DIV_CD
, REPLACE(REPLACE(RLSIT_NRMN_CD,CHR(13),''),CHR(10),'') RLSIT_NRMN_CD
, AGE
, REPLACE(REPLACE(NKNM,CHR(13),''),CHR(10),'') NKNM
, REPLACE(REPLACE(ADDTL_FM_NM,CHR(13),''),CHR(10),'') ADDTL_FM_NM
, REPLACE(REPLACE(POL_RCEPL_DIV_CD,CHR(13),''),CHR(10),'') POL_RCEPL_DIV_CD
, REPLACE(REPLACE(DM_SNDPL_DIV_CD,CHR(13),''),CHR(10),'') DM_SNDPL_DIV_CD
, REPLACE(REPLACE(CMC_MN_TMN_AGR_YN,CHR(13),''),CHR(10),'') CMC_MN_TMN_AGR_YN
, PTY_IDF_INF_SEQ
, REPLACE(REPLACE(PSSPE_CD,CHR(13),''),CHR(10),'') PSSPE_CD
, REPLACE(REPLACE(JOB_CD,CHR(13),''),CHR(10),'') JOB_CD
, REPLACE(REPLACE(JOB_GRD_CD,CHR(13),''),CHR(10),'') JOB_GRD_CD
, REPLACE(REPLACE(MARY_YN,CHR(13),''),CHR(10),'') MARY_YN
, REPLACE(REPLACE(CHDN_DRV_YN,CHR(13),''),CHR(10),'') CHDN_DRV_YN
, REPLACE(REPLACE(INSPE_TP_CD,CHR(13),''),CHR(10),'') INSPE_TP_CD
, REPLACE(REPLACE(POL_RCGPE_YN,CHR(13),''),CHR(10),'') POL_RCGPE_YN
, REPLACE(REPLACE(HAPE_EMP_DIV_CD,CHR(13),''),CHR(10),'') HAPE_EMP_DIV_CD
, REPLACE(REPLACE(HAPE_AGE_SIC_DIV_CD,CHR(13),''),CHR(10),'') HAPE_AGE_SIC_DIV_CD
, REPLACE(REPLACE(LCNS_DIV_CD,CHR(13),''),CHR(10),'') LCNS_DIV_CD
, REPLACE(REPLACE(LCNS_NO,CHR(13),''),CHR(10),'') LCNS_NO
, LCNS_DLV_DT
, ENTCO_DT
, REPLACE(REPLACE(ATL_CTR_ID,CHR(13),''),CHR(10),'') ATL_CTR_ID
, ATL_CTR_PTY_SEQ
, ATL_HIS_SEQ
, ENDR_NO
, RTRO_ENDR_NO
, ENDR_HIS_ST_NO
, ENDR_HIS_ED_NO
, SUMUP_DT
, HIS_ST_DT
, HIS_ED_DT
, REPLACE(REPLACE(INPPE_ORG_ID,CHR(13),''),CHR(10),'') INPPE_ORG_ID
, SYS_OCC_DTM
, REPLACE(REPLACE(SYS_DEL_DIV_CD,CHR(13),''),CHR(10),'') SYS_DEL_DIV_CD
, REPLACE(REPLACE(OCC_IP,CHR(13),''),CHR(10),'') OCC_IP
, REPLACE(REPLACE(APP_ID,CHR(13),''),CHR(10),'') APP_ID
, DATA_CHNG_DTM
, REPLACE(REPLACE(DSC_CON,CHR(13),''),CHR(10),'') DSC_CON
, REPLACE(REPLACE(RNM_CNF_KD_CD,CHR(13),''),CHR(10),'') RNM_CNF_KD_CD
, IDF_ATH_CHT_ISS_DT
, REPLACE(REPLACE(ISS_INST_NM,CHR(13),''),CHR(10),'') ISS_INST_NM
, REPLACE(REPLACE(ADDTL_REF_NO,CHR(13),''),CHR(10),'') ADDTL_REF_NO
, REPLACE(REPLACE(RNM_ATH_FNM,CHR(13),''),CHR(10),'') RNM_ATH_FNM
, EIH_LDG_DTM
, REPLACE(REPLACE(KIS_ETP_CD,CHR(13),''),CHR(10),'') KIS_ETP_CD
, APL_ST_DT
, APL_ED_DT
, HNC_REG_ED_DT
, REPLACE(REPLACE(HNCPE_CTR_YN,CHR(13),''),CHR(10),'') HNCPE_CTR_YN FROM THDDH_TCTPCOTPTY
                       WHERE \$CONDITIONS "\
    --m 8 \
    --boundary-query "SELECT 0, 7 FROM DUAL"\
    --split-by "ORA_HASH(CTR_ID, 7)"\
    --target-dir /tmp2/LAST_THDDH_TCTPCOTPTY \
    --hive-import \
    --external-table-dir hdfs:///tmp2/temp_tbl/LAST_THDDH_TCTPCOTPTY \
    --hive-overwrite \
    --hive-table DEFAULT.LAST_THDDH_TCTPCOTPTY  >> ${SHLOG_DIR}/THDDH_TCTPCOTPTY.shlog 2>&1 &&

#----------------------------------------------------#
# Hadoop 원본테이블에 변경분 최종 적용
#----------------------------------------------------#
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TCTPCOTPTY_TMP ; " >> ${SHLOG_DIR}/THDDH_TCTPCOTPTY.shlog 2>&1 &&
    /usr/bin/hive -e "CREATE EXTERNAL TABLE MERITZ.THDDH_TCTPCOTPTY_TMP STORED AS PARQUET TBLPROPERTIES ('PARQUET.COMPRESS'='SNAPPY') AS
                                SELECT *
                                FROM DEFAULT.LAST_THDDH_TCTPCOTPTY ;" >> ${SHLOG_DIR}/THDDH_TCTPCOTPTY.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.LAST_THDDH_TCTPCOTPTY ;" >> ${SHLOG_DIR}/THDDH_TCTPCOTPTY.shlog 2>&1 &&
    /usr/bin/hdfs dfs -rm -r -f -skipTrash /tmp2/temp_tbl/LAST_THDDH_TCTPCOTPTY >> ${SHLOG_DIR}/THDDH_TCTPCOTPTY.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TCTPCOTPTY ;" >> ${SHLOG_DIR}/THDDH_TCTPCOTPTY.shlog 2>&1 &&
    /usr/bin/hive -e "ALTER TABLE MERITZ.THDDH_TCTPCOTPTY_TMP RENAME TO MERITZ.THDDH_TCTPCOTPTY ;" >> ${SHLOG_DIR}/THDDH_TCTPCOTPTY.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TCTPCOTPTY_TMP ;" >> ${SHLOG_DIR}/THDDH_TCTPCOTPTY.shlog 2>&1 

if [ $? -ne 0 ]
then             
    echo "*-----------[ THDDH_TCTPCOTPTY.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/THDDH_TCTPCOTPTY.shlog"
    echo "*-----------[ THDDH_TCTPCOTPTY.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/THDDH_TCTPCOTPTY.shlog"  >>  ${SHLOG_DIR}/THDDH_TCTPCOTPTY.shlog
    echo "*-----------[ THDDH_TCTPCOTPTY.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TCTPCOTPTY.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/THDDH_TCTPCOTPTY.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/THDDH_TCTPCOTPTY.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCTPCOTPTY.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCTPCOTPTY.shlog /sqoopbin/scripts/etlpgm/his_log/THDDH_TCTPCOTPTY_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  THDDH_TCTPCOTPTY.sh cmd command error !! ***
    fi               

    exit -1      

else             
    echo "*-----------[ THDDH_TCTPCOTPTY.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TCTPCOTPTY.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/THDDH_TCTPCOTPTY.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/THDDH_TCTPCOTPTY.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCTPCOTPTY.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCTPCOTPTY.shlog /sqoopbin/scripts/etlpgm/his_log/THDDH_TCTPCOTPTY_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  THDDH_TCTPCOTPTY.sh cmd command error !! ***
        exit -1      
    else             
        exit 0       
    fi               
fi               
