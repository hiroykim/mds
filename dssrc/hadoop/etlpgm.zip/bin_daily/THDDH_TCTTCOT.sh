#!/bin/bash

if [ $# -eq 0 ]
then           
    ARGS=N    
else           
    ARGS=$1
fi             

NOW=$(date +"+%Y-%m-%d_%T")
SHLOG_DIR=/sqoopbin/scripts/etlpgm/cur_log
HISLOG_DIR=/sqoopbin/scripts/etlpgm/his_log

export HADOOP_OPTS=-Djava.security.egd=file:/dev/../dev/urandom
export ORACLE_BASE=/sw/oracle
export ORACLE_HOME=/sw/oracle/product/11.2.0.4/client_1
export LD_LIBRARY_PATH=/sw/oracle/product/11.2.0.4/client_1/lib:/sw/oracle/product/11.2.0.4/client_1/lib:
export PATH=/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/usr/lib64/qt-3.3/bin:/usr/hdp/3.0.0.0-1634/spark2/bin/:/var/opt/node/bin/:/opt/maven/bin:/usr/local/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/home/hdpapp/workspace/data-science-at-the-command-line/tools:/home/hdpapp/.local/bin:/home/hdpapp/bin
export TNS_ADMIN=/sw/oracle/product/11.2.0.4/client_1/network/admin
export ORACLE_SID=DBEDWP2
export NLS_LANG=American_America.KO16MSWIN949

#----------------------------------------------------#
# 작업내용 : THDDH_TCTTCOT 테이블 sqoop 복제 작업
# 작업주기 :  
#----------------------------------------------------#

    echo " "
    echo "*-----------[ THDDH_TCTTCOT.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TCTTCOT.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`  >  ${SHLOG_DIR}/THDDH_TCTTCOT.shlog

#----------------------------------------------------#
# 테이블별 전체 데이터를 받아 오는 부분
#----------------------------------------------------#
    /usr/bin/hadoop fs -rm -r -f  /tmp2/LAST_THDDH_TCTTCOT  >> ${SHLOG_DIR}/THDDH_TCTTCOT.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.LAST_THDDH_TCTTCOT ; " >> ${SHLOG_DIR}/THDDH_TCTTCOT.shlog 2>&1 &&
    /usr/hdp/3.0.0.0-1634/sqoop/bin/sqoop import -D mapred.child.java.opts="-Djava.security.egd=file:/dev/../dev/urandom" \
    --connect jdbc:oracle:thin:EDWHADOOP/wjdqhrP\!23@10.91.41.172:12560:DBEDWP2 \
    --username  EDWHADOOP \
    --password wjdqhrP\!23 \
    --query "SELECT /*+ FULL(THDDH_TCTTCOT) */ REPLACE(REPLACE(CTR_ID,CHR(13),''),CHR(10),'') CTR_ID
, HIS_SEQ
, REPLACE(REPLACE(BIZ_SYS_CD,CHR(13),''),CHR(10),'') BIZ_SYS_CD
, REPLACE(REPLACE(PD_CD,CHR(13),''),CHR(10),'') PD_CD
, REPLACE(REPLACE(PDGP_CD,CHR(13),''),CHR(10),'') PDGP_CD
, REPLACE(REPLACE(STIC_PD_CTG_CD,CHR(13),''),CHR(10),'') STIC_PD_CTG_CD
, REPLACE(REPLACE(UNT_PD_CD,CHR(13),''),CHR(10),'') UNT_PD_CD
, REPLACE(REPLACE(POL_NO,CHR(13),''),CHR(10),'') POL_NO
, REPLACE(REPLACE(SCAN_DIV_CD,CHR(13),''),CHR(10),'') SCAN_DIV_CD
, REPLACE(REPLACE(NTDT_VRF_STAT_CD,CHR(13),''),CHR(10),'') NTDT_VRF_STAT_CD
, RFD_RT
, SBCP_DT
, REPLACE(REPLACE(CTR_STAT_CD,CHR(13),''),CHR(10),'') CTR_STAT_CD
, REPLACE(REPLACE(CTR_STAT_DTL_CD,CHR(13),''),CHR(10),'') CTR_STAT_DTL_CD
, REPLACE(REPLACE(INS_PRD_TP_CD,CHR(13),''),CHR(10),'') INS_PRD_TP_CD
, REPLACE(REPLACE(PY_PRD_TP_CD,CHR(13),''),CHR(10),'') PY_PRD_TP_CD
, INS_PRD
, PY_PRD
, INS_ED_AGE
, PY_ED_AGE
, INS_BGN_DT
, REPLACE(REPLACE(INS_BGN_TM,CHR(13),''),CHR(10),'') INS_BGN_TM
, INS_ED_DT
, REPLACE(REPLACE(INS_ED_TM,CHR(13),''),CHR(10),'') INS_ED_TM
, REPLACE(REPLACE(CLUS_KD_CD,CHR(13),''),CHR(10),'') CLUS_KD_CD
, REPLACE(REPLACE(CLF_DIV_CD,CHR(13),''),CHR(10),'') CLF_DIV_CD
, REPLACE(REPLACE(HSEC_DIV_CD,CHR(13),''),CHR(10),'') HSEC_DIV_CD
, REPLACE(REPLACE(NEW_DIV_CD,CHR(13),''),CHR(10),'') NEW_DIV_CD
, REPLACE(REPLACE(ACP_SH_DIV_CD,CHR(13),''),CHR(10),'') ACP_SH_DIV_CD
, REPLACE(REPLACE(FIX_NFIX_RSK_DIV_CD,CHR(13),''),CHR(10),'') FIX_NFIX_RSK_DIV_CD
, REPLACE(REPLACE(FIX_ADJT_DIV_CD,CHR(13),''),CHR(10),'') FIX_ADJT_DIV_CD
, REPLACE(REPLACE(PRD_SECT_INS_DIV_CD,CHR(13),''),CHR(10),'') PRD_SECT_INS_DIV_CD
, REPLACE(REPLACE(INS_SBC_SH_CD,CHR(13),''),CHR(10),'') INS_SBC_SH_CD
, REPLACE(REPLACE(INS_SBC_TP_CD,CHR(13),''),CHR(10),'') INS_SBC_TP_CD
, REPLACE(REPLACE(RCRT_SH_CD,CHR(13),''),CHR(10),'') RCRT_SH_CD
, REPLACE(REPLACE(SBCP_CHN_DIV_CD,CHR(13),''),CHR(10),'') SBCP_CHN_DIV_CD
, REPLACE(REPLACE(SAL_CHN_DIV_CD,CHR(13),''),CHR(10),'') SAL_CHN_DIV_CD
, REPLACE(REPLACE(CMC_MN_TMN_AGR_YN,CHR(13),''),CHR(10),'') CMC_MN_TMN_AGR_YN
, REPLACE(REPLACE(EMB_CTR_YN,CHR(13),''),CHR(10),'') EMB_CTR_YN
, REPLACE(REPLACE(EMB_CTR_NO,CHR(13),''),CHR(10),'') EMB_CTR_NO
, REPLACE(REPLACE(FNC_INST_LNK_PD_YN,CHR(13),''),CHR(10),'') FNC_INST_LNK_PD_YN
, REPLACE(REPLACE(GRUP_KD_CD,CHR(13),''),CHR(10),'') GRUP_KD_CD
, REPLACE(REPLACE(GRUP_DIV_CD,CHR(13),''),CHR(10),'') GRUP_DIV_CD
, REPLACE(REPLACE(REG_GRUP_NO,CHR(13),''),CHR(10),'') REG_GRUP_NO
, REPLACE(REPLACE(DMG_RT_APL_YN,CHR(13),''),CHR(10),'') DMG_RT_APL_YN
, REPLACE(REPLACE(ORDPE_DIV_CD,CHR(13),''),CHR(10),'') ORDPE_DIV_CD
, REPLACE(REPLACE(PLAN_CD,CHR(13),''),CHR(10),'') PLAN_CD
, REPLACE(REPLACE(DDASG_SHTM_DIV_CD,CHR(13),''),CHR(10),'') DDASG_SHTM_DIV_CD
, REPLACE(REPLACE(JNT_TNG_YN,CHR(13),''),CHR(10),'') JNT_TNG_YN
, REPLACE(REPLACE(DPOPT_TRG_YN,CHR(13),''),CHR(10),'') DPOPT_TRG_YN
, REPLACE(REPLACE(NRM_RTRO_DIV_CD,CHR(13),''),CHR(10),'') NRM_RTRO_DIV_CD
, REPLACE(REPLACE(PAYPL_APPN_YN,CHR(13),''),CHR(10),'') PAYPL_APPN_YN
, REPLACE(REPLACE(PHDS_SYTH_INS_YN,CHR(13),''),CHR(10),'') PHDS_SYTH_INS_YN
, REPLACE(REPLACE(GRPCO_YN,CHR(13),''),CHR(10),'') GRPCO_YN
, REPLACE(REPLACE(BF_INSCO_CTR_BZAC_CD,CHR(13),''),CHR(10),'') BF_INSCO_CTR_BZAC_CD
, REPLACE(REPLACE(BF_CTR_POL_NO,CHR(13),''),CHR(10),'') BF_CTR_POL_NO
, REPLACE(REPLACE(ORIG_RTRC_DIV_CD,CHR(13),''),CHR(10),'') ORIG_RTRC_DIV_CD
, REPLACE(REPLACE(AGRM_NAGRM_DIV_CD,CHR(13),''),CHR(10),'') AGRM_NAGRM_DIV_CD
, REPLACE(REPLACE(RNWL_TRG_DIV_CD,CHR(13),''),CHR(10),'') RNWL_TRG_DIV_CD
, REPLACE(REPLACE(RNWL_STAT_CD,CHR(13),''),CHR(10),'') RNWL_STAT_CD
, RNWL_XPT_DT
, REPLACE(REPLACE(NRNW_RSN_CD,CHR(13),''),CHR(10),'') NRNW_RSN_CD
, RNWL_TMS
, REPLACE(REPLACE(PY_CYC_CD,CHR(13),''),CHR(10),'') PY_CYC_CD
, TT_IPY_TIMS
, REPLACE(REPLACE(MNCL_MD_CD,CHR(13),''),CHR(10),'') MNCL_MD_CD
, REPLACE(REPLACE(RPSB_PRTT_YN,CHR(13),''),CHR(10),'') RPSB_PRTT_YN
, REPLACE(REPLACE(NXT_YY_PY_CYC_CD,CHR(13),''),CHR(10),'') NXT_YY_PY_CYC_CD
, REPLACE(REPLACE(NXT_YY_MNCL_MD_CD,CHR(13),''),CHR(10),'') NXT_YY_MNCL_MD_CD
, REPLACE(REPLACE(JNT_ACP_ASG_NO,CHR(13),''),CHR(10),'') JNT_ACP_ASG_NO
, REPLACE(REPLACE(HGPH_SGN_DIV_CD,CHR(13),''),CHR(10),'') HGPH_SGN_DIV_CD
, REPLACE(REPLACE(HGPH_SGN_YN,CHR(13),''),CHR(10),'') HGPH_SGN_YN
, REPLACE(REPLACE(CLUS_TNSF_YN,CHR(13),''),CHR(10),'') CLUS_TNSF_YN
, REPLACE(REPLACE(CLUS_DSC_YN,CHR(13),''),CHR(10),'') CLUS_DSC_YN
, REPLACE(REPLACE(PD_MNDC_TRG_YN,CHR(13),''),CHR(10),'') PD_MNDC_TRG_YN
, REPLACE(REPLACE(PD_MNDC_ATC_YN,CHR(13),''),CHR(10),'') PD_MNDC_ATC_YN
, REPLACE(REPLACE(LDCO_POL_NO,CHR(13),''),CHR(10),'') LDCO_POL_NO
, REPLACE(REPLACE(OD_CTR_YN,CHR(13),''),CHR(10),'') OD_CTR_YN
, REPLACE(REPLACE(PREM_RT_AT_CAL_YN,CHR(13),''),CHR(10),'') PREM_RT_AT_CAL_YN
, REPLACE(REPLACE(SUPR_COV_SBC_CTRL_YN,CHR(13),''),CHR(10),'') SUPR_COV_SBC_CTRL_YN
, PY_ST_DT
, PY_ED_DT
, REPLACE(REPLACE(CLF_DIV_NM,CHR(13),''),CHR(10),'') CLF_DIV_NM
, REPLACE(REPLACE(INS_SBC_SH_NM,CHR(13),''),CHR(10),'') INS_SBC_SH_NM
, REPLACE(REPLACE(CTR_DAT_DIV_CD,CHR(13),''),CHR(10),'') CTR_DAT_DIV_CD
, REPLACE(REPLACE(SCRN_CTG_CD,CHR(13),''),CHR(10),'') SCRN_CTG_CD
, REPLACE(REPLACE(CTR_DIV_CD,CHR(13),''),CHR(10),'') CTR_DIV_CD
, ENDR_NO
, RTRO_ENDR_NO
, ENDR_HIS_ST_NO
, ENDR_HIS_ED_NO
, SUMUP_DT
, HIS_ST_DT
, HIS_ED_DT
, REPLACE(REPLACE(INPPE_ORG_ID,CHR(13),''),CHR(10),'') INPPE_ORG_ID
, SYS_OCC_DTM
, REPLACE(REPLACE(SYS_DEL_DIV_CD,CHR(13),''),CHR(10),'') SYS_DEL_DIV_CD
, REPLACE(REPLACE(OCC_IP,CHR(13),''),CHR(10),'') OCC_IP
, REPLACE(REPLACE(APP_ID,CHR(13),''),CHR(10),'') APP_ID
, DATA_CHNG_DTM
, REPLACE(REPLACE(MPLN_ID,CHR(13),''),CHR(10),'') MPLN_ID
, REPLACE(REPLACE(IVS_CTR_YN,CHR(13),''),CHR(10),'') IVS_CTR_YN
, ADDTL_BNT_RTO
, REPLACE(REPLACE(ADD_PY_SH_CD,CHR(13),''),CHR(10),'') ADD_PY_SH_CD
, REPLACE(REPLACE(ERNPE_CHNG_ENGG_YN,CHR(13),''),CHR(10),'') ERNPE_CHNG_ENGG_YN
, REPLACE(REPLACE(TTAX_TRG_DIV_CD,CHR(13),''),CHR(10),'') TTAX_TRG_DIV_CD
, EIH_LDG_DTM
, PPAT_GURT_PY_ST_DT
, PPAT_GURT_PY_ED_DT
, PPAT_ALTN_PY_ST_DT
, PPAT_ALTN_PY_ED_DT
, REPLACE(REPLACE(STPC_CTR_NO,CHR(13),''),CHR(10),'') STPC_CTR_NO
, REPLACE(REPLACE(SBCP_DOC_VRF_STAT_CD,CHR(13),''),CHR(10),'') SBCP_DOC_VRF_STAT_CD
, REPLACE(REPLACE(PY_EXEM_YN,CHR(13),''),CHR(10),'') PY_EXEM_YN
, REPLACE(REPLACE(CHAN_VRF_TRG_STAT_CD,CHR(13),''),CHR(10),'') CHAN_VRF_TRG_STAT_CD
, REPLACE(REPLACE(OWN_CTR_YN,CHR(13),''),CHR(10),'') OWN_CTR_YN
, REPLACE(REPLACE(LAST_MDFPE_ORG_ID,CHR(13),''),CHR(10),'') LAST_MDFPE_ORG_ID
, REPLACE(REPLACE(LAST_MDF_APP_ID,CHR(13),''),CHR(10),'') LAST_MDF_APP_ID
, REPLACE(REPLACE(LAST_MDF_CON,CHR(13),''),CHR(10),'') LAST_MDF_CON
, REPLACE(REPLACE(PY_EXEM_CHRC_CD,CHR(13),''),CHR(10),'') PY_EXEM_CHRC_CD
, HNC_REG_ED_DT
, REPLACE(REPLACE(HNCPE_CTR_YN,CHR(13),''),CHR(10),'') HNCPE_CTR_YN
, REPLACE(REPLACE(RNWL_COV_CYC_CD,CHR(13),''),CHR(10),'') RNWL_COV_CYC_CD
, REPLACE(REPLACE(ADD_INS_PRD_TP_CD,CHR(13),''),CHR(10),'') ADD_INS_PRD_TP_CD
, REPLACE(REPLACE(ADD_PY_PRD_TP_CD,CHR(13),''),CHR(10),'') ADD_PY_PRD_TP_CD
, ADD_INS_PRD
, ADD_PY_PRD
, ADD_INS_ED_AGE
, ADD_PY_ED_AGE
, BTH_DT
, REPLACE(REPLACE(BTH_BF_AF_DIV_CD,CHR(13),''),CHR(10),'') BTH_BF_AF_DIV_CD
, REPLACE(REPLACE(LWRT_TMN_RFD_TP_CD,CHR(13),''),CHR(10),'') LWRT_TMN_RFD_TP_CD
, REPLACE(REPLACE(PY_EXEM_TP_CD,CHR(13),''),CHR(10),'') PY_EXEM_TP_CD
, REPLACE(REPLACE(HNDY_ISP_TP_CD,CHR(13),''),CHR(10),'') HNDY_ISP_TP_CD
, RNWL_ED_DT
, RNWL_CYC_YR_NUM
, FRS_BGN_DT
, REPLACE(REPLACE(RNWL_ED_PRD_DIV_CD,CHR(13),''),CHR(10),'') RNWL_ED_PRD_DIV_CD
, RNWL_ED_PRD
, RNWL_ED_AGE FROM THDDH_TCTTCOT
                       WHERE \$CONDITIONS "\
    --m 8 \
    --boundary-query "SELECT 0, 7 FROM DUAL"\
    --split-by "ORA_HASH(CTR_ID, 7)"\
    --target-dir /tmp2/LAST_THDDH_TCTTCOT \
    --hive-import \
    --external-table-dir hdfs:///tmp2/temp_tbl/LAST_THDDH_TCTTCOT \
    --hive-overwrite \
    --hive-table DEFAULT.LAST_THDDH_TCTTCOT  >> ${SHLOG_DIR}/THDDH_TCTTCOT.shlog 2>&1 &&

#----------------------------------------------------#
# Hadoop 원본테이블에 변경분 최종 적용
#----------------------------------------------------#
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TCTTCOT_TMP ; " >> ${SHLOG_DIR}/THDDH_TCTTCOT.shlog 2>&1 &&
    /usr/bin/hive -e "CREATE EXTERNAL TABLE MERITZ.THDDH_TCTTCOT_TMP STORED AS PARQUET TBLPROPERTIES ('PARQUET.COMPRESS'='SNAPPY') AS
                                SELECT *
                                FROM DEFAULT.LAST_THDDH_TCTTCOT ;" >> ${SHLOG_DIR}/THDDH_TCTTCOT.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.LAST_THDDH_TCTTCOT ;" >> ${SHLOG_DIR}/THDDH_TCTTCOT.shlog 2>&1 &&
    /usr/bin/hdfs dfs -rm -r -f -skipTrash /tmp2/temp_tbl/LAST_THDDH_TCTTCOT >> ${SHLOG_DIR}/THDDH_TCTTCOT.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TCTTCOT ;" >> ${SHLOG_DIR}/THDDH_TCTTCOT.shlog 2>&1 &&
    /usr/bin/hive -e "ALTER TABLE MERITZ.THDDH_TCTTCOT_TMP RENAME TO MERITZ.THDDH_TCTTCOT ;" >> ${SHLOG_DIR}/THDDH_TCTTCOT.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TCTTCOT_TMP ;" >> ${SHLOG_DIR}/THDDH_TCTTCOT.shlog 2>&1 

if [ $? -ne 0 ]
then             
    echo "*-----------[ THDDH_TCTTCOT.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/THDDH_TCTTCOT.shlog"
    echo "*-----------[ THDDH_TCTTCOT.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/THDDH_TCTTCOT.shlog"  >>  ${SHLOG_DIR}/THDDH_TCTTCOT.shlog
    echo "*-----------[ THDDH_TCTTCOT.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TCTTCOT.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/THDDH_TCTTCOT.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/THDDH_TCTTCOT.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCTTCOT.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCTTCOT.shlog /sqoopbin/scripts/etlpgm/his_log/THDDH_TCTTCOT_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  THDDH_TCTTCOT.sh cmd command error !! ***
    fi               

    exit -1      

else             
    echo "*-----------[ THDDH_TCTTCOT.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TCTTCOT.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/THDDH_TCTTCOT.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/THDDH_TCTTCOT.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCTTCOT.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCTTCOT.shlog /sqoopbin/scripts/etlpgm/his_log/THDDH_TCTTCOT_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  THDDH_TCTTCOT.sh cmd command error !! ***
        exit -1      
    else             
        exit 0       
    fi               
fi               
