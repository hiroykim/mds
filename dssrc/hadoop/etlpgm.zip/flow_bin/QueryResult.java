// ORM class for table 'null'
// WARNING: This class is AUTO-GENERATED. Modify at your own risk.
//
// Debug information:
// Generated date: Tue Nov 07 11:22:56 KST 2017
// For connector: org.apache.sqoop.manager.OracleManager
import org.apache.hadoop.io.BytesWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.mapred.lib.db.DBWritable;
import com.cloudera.sqoop.lib.JdbcWritableBridge;
import com.cloudera.sqoop.lib.DelimiterSet;
import com.cloudera.sqoop.lib.FieldFormatter;
import com.cloudera.sqoop.lib.RecordParser;
import com.cloudera.sqoop.lib.BooleanParser;
import com.cloudera.sqoop.lib.BlobRef;
import com.cloudera.sqoop.lib.ClobRef;
import com.cloudera.sqoop.lib.LargeObjectLoader;
import com.cloudera.sqoop.lib.SqoopRecord;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.sql.Date;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

public class QueryResult extends SqoopRecord  implements DBWritable, Writable {
  private final int PROTOCOL_VERSION = 3;
  public int getClassFormatVersion() { return PROTOCOL_VERSION; }
  public static interface FieldSetterCommand {    void setField(Object value);  }  protected ResultSet __cur_result_set;
  private Map<String, FieldSetterCommand> setters = new HashMap<String, FieldSetterCommand>();
  private void init0() {
    setters.put("STD_YYMM", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        STD_YYMM = (String)value;
      }
    });
    setters.put("ACD_NO_YY", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        ACD_NO_YY = (String)value;
      }
    });
    setters.put("ACD_NO_SEQ", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        ACD_NO_SEQ = (java.math.BigDecimal)value;
      }
    });
    setters.put("POL_NO", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        POL_NO = (String)value;
      }
    });
    setters.put("CLM_TP_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        CLM_TP_CD = (String)value;
      }
    });
    setters.put("DAM_ORD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        DAM_ORD = (java.math.BigDecimal)value;
      }
    });
    setters.put("COV_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        COV_CD = (String)value;
      }
    });
    setters.put("ORIG_INS_AMT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        ORIG_INS_AMT = (java.math.BigDecimal)value;
      }
    });
    setters.put("ORIG_OS_INS_AMT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        ORIG_OS_INS_AMT = (java.math.BigDecimal)value;
      }
    });
    setters.put("PRPD_ORIG_OINS_AMT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        PRPD_ORIG_OINS_AMT = (java.math.BigDecimal)value;
      }
    });
    setters.put("ORIG_DMG_AMT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        ORIG_DMG_AMT = (java.math.BigDecimal)value;
      }
    });
    setters.put("PSSE_INS_AMT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        PSSE_INS_AMT = (java.math.BigDecimal)value;
      }
    });
    setters.put("PSSE_OINS_AMT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        PSSE_OINS_AMT = (java.math.BigDecimal)value;
      }
    });
    setters.put("PRPD_PSSE_OINS_AMT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        PRPD_PSSE_OINS_AMT = (java.math.BigDecimal)value;
      }
    });
    setters.put("PSSE_DMG_AMT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        PSSE_DMG_AMT = (java.math.BigDecimal)value;
      }
    });
    setters.put("ADD_PCS_YN", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        ADD_PCS_YN = (String)value;
      }
    });
    setters.put("ACD_RCT_PTH_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        ACD_RCT_PTH_CD = (String)value;
      }
    });
    setters.put("UNT_PD_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        UNT_PD_CD = (String)value;
      }
    });
    setters.put("SBCP_DT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        SBCP_DT = (java.sql.Timestamp)value;
      }
    });
    setters.put("TACD_DMPE_JOB_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        TACD_DMPE_JOB_CD = (String)value;
      }
    });
    setters.put("TACD_DMPE_JOB_GRD_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        TACD_DMPE_JOB_GRD_CD = (String)value;
      }
    });
    setters.put("TACD_DMPE_GNDR_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        TACD_DMPE_GNDR_CD = (String)value;
      }
    });
    setters.put("TACD_DMPE_AGE", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        TACD_DMPE_AGE = (java.math.BigDecimal)value;
      }
    });
    setters.put("ACD_DT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        ACD_DT = (java.sql.Timestamp)value;
      }
    });
    setters.put("ACD_DT_HOLI_YN", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        ACD_DT_HOLI_YN = (String)value;
      }
    });
    setters.put("ACD_PLC_ZPCD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        ACD_PLC_ZPCD = (String)value;
      }
    });
    setters.put("ACD_PLC_SIDO_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        ACD_PLC_SIDO_CD = (String)value;
      }
    });
    setters.put("ACD_CAUS_LCTG_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        ACD_CAUS_LCTG_CD = (String)value;
      }
    });
    setters.put("ACD_CAUS_MCTG_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        ACD_CAUS_MCTG_CD = (String)value;
      }
    });
    setters.put("ACD_CAUS_SCTG_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        ACD_CAUS_SCTG_CD = (String)value;
      }
    });
    setters.put("OVSE_MET_YN", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        OVSE_MET_YN = (String)value;
      }
    });
    setters.put("KR_DISZ_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        KR_DISZ_CD = (String)value;
      }
    });
    setters.put("RCPR_INST_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        RCPR_INST_CD = (String)value;
      }
    });
    setters.put("HSP_DD_NUM", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        HSP_DD_NUM = (java.math.BigDecimal)value;
      }
    });
    setters.put("GHR_DD_NUM", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        GHR_DD_NUM = (java.math.BigDecimal)value;
      }
    });
    setters.put("PSC_DD_NUM", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        PSC_DD_NUM = (java.math.BigDecimal)value;
      }
    });
    setters.put("DDPY_DD_NUM", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        DDPY_DD_NUM = (java.math.BigDecimal)value;
      }
    });
    setters.put("OBST_RT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        OBST_RT = (java.math.BigDecimal)value;
      }
    });
    setters.put("DTH_DT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        DTH_DT = (java.sql.Timestamp)value;
      }
    });
    setters.put("DMG_RDUC_AMT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        DMG_RDUC_AMT = (java.math.BigDecimal)value;
      }
    });
    setters.put("CLADJ_DAMR_LCTG_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        CLADJ_DAMR_LCTG_CD = (String)value;
      }
    });
    setters.put("CLADJ_DAMR_MCTG_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        CLADJ_DAMR_MCTG_CD = (String)value;
      }
    });
    setters.put("SIU_SVY_RQS_YN", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        SIU_SVY_RQS_YN = (String)value;
      }
    });
    setters.put("DAMR_GRDE_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        DAMR_GRDE_CD = (String)value;
      }
    });
    setters.put("DLG_YN", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        DLG_YN = (String)value;
      }
    });
    setters.put("DLG_CON_CD_NM", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        DLG_CON_CD_NM = (String)value;
      }
    });
    setters.put("DLG_CO_NM", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        DLG_CO_NM = (String)value;
      }
    });
    setters.put("SVY_INST_NM", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        SVY_INST_NM = (String)value;
      }
    });
    setters.put("TRT_HDQT_ORG_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        TRT_HDQT_ORG_CD = (String)value;
      }
    });
    setters.put("TRT_BRCH_ORG_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        TRT_BRCH_ORG_CD = (String)value;
      }
    });
    setters.put("TRT_BCH_ORG_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        TRT_BCH_ORG_CD = (String)value;
      }
    });
    setters.put("TRTPE_ORG_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        TRTPE_ORG_CD = (String)value;
      }
    });
    setters.put("PCS_COMS_TEM_ORG_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        PCS_COMS_TEM_ORG_CD = (String)value;
      }
    });
    setters.put("PCS_COMS_PART_ORG_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        PCS_COMS_PART_ORG_CD = (String)value;
      }
    });
    setters.put("CHRPE_ORG_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        CHRPE_ORG_CD = (String)value;
      }
    });
    setters.put("RCT_DT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        RCT_DT = (java.sql.Timestamp)value;
      }
    });
    setters.put("FRS_OS_DT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        FRS_OS_DT = (java.sql.Timestamp)value;
      }
    });
    setters.put("LAST_OS_DT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        LAST_OS_DT = (java.sql.Timestamp)value;
      }
    });
    setters.put("APVL_DT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        APVL_DT = (java.sql.Timestamp)value;
      }
    });
    setters.put("LAST_RCT_DT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        LAST_RCT_DT = (java.sql.Timestamp)value;
      }
    });
    setters.put("FRS_RCTPE_ORG_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        FRS_RCTPE_ORG_CD = (String)value;
      }
    });
    setters.put("CTR_OBJ_ID", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        CTR_OBJ_ID = (String)value;
      }
    });
    setters.put("DMPE_CUS_ID", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        DMPE_CUS_ID = (String)value;
      }
    });
    setters.put("EIH_LDG_DTM", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        EIH_LDG_DTM = (java.sql.Timestamp)value;
      }
    });
  }
  public QueryResult() {
    init0();
  }
  private String STD_YYMM;
  public String get_STD_YYMM() {
    return STD_YYMM;
  }
  public void set_STD_YYMM(String STD_YYMM) {
    this.STD_YYMM = STD_YYMM;
  }
  public QueryResult with_STD_YYMM(String STD_YYMM) {
    this.STD_YYMM = STD_YYMM;
    return this;
  }
  private String ACD_NO_YY;
  public String get_ACD_NO_YY() {
    return ACD_NO_YY;
  }
  public void set_ACD_NO_YY(String ACD_NO_YY) {
    this.ACD_NO_YY = ACD_NO_YY;
  }
  public QueryResult with_ACD_NO_YY(String ACD_NO_YY) {
    this.ACD_NO_YY = ACD_NO_YY;
    return this;
  }
  private java.math.BigDecimal ACD_NO_SEQ;
  public java.math.BigDecimal get_ACD_NO_SEQ() {
    return ACD_NO_SEQ;
  }
  public void set_ACD_NO_SEQ(java.math.BigDecimal ACD_NO_SEQ) {
    this.ACD_NO_SEQ = ACD_NO_SEQ;
  }
  public QueryResult with_ACD_NO_SEQ(java.math.BigDecimal ACD_NO_SEQ) {
    this.ACD_NO_SEQ = ACD_NO_SEQ;
    return this;
  }
  private String POL_NO;
  public String get_POL_NO() {
    return POL_NO;
  }
  public void set_POL_NO(String POL_NO) {
    this.POL_NO = POL_NO;
  }
  public QueryResult with_POL_NO(String POL_NO) {
    this.POL_NO = POL_NO;
    return this;
  }
  private String CLM_TP_CD;
  public String get_CLM_TP_CD() {
    return CLM_TP_CD;
  }
  public void set_CLM_TP_CD(String CLM_TP_CD) {
    this.CLM_TP_CD = CLM_TP_CD;
  }
  public QueryResult with_CLM_TP_CD(String CLM_TP_CD) {
    this.CLM_TP_CD = CLM_TP_CD;
    return this;
  }
  private java.math.BigDecimal DAM_ORD;
  public java.math.BigDecimal get_DAM_ORD() {
    return DAM_ORD;
  }
  public void set_DAM_ORD(java.math.BigDecimal DAM_ORD) {
    this.DAM_ORD = DAM_ORD;
  }
  public QueryResult with_DAM_ORD(java.math.BigDecimal DAM_ORD) {
    this.DAM_ORD = DAM_ORD;
    return this;
  }
  private String COV_CD;
  public String get_COV_CD() {
    return COV_CD;
  }
  public void set_COV_CD(String COV_CD) {
    this.COV_CD = COV_CD;
  }
  public QueryResult with_COV_CD(String COV_CD) {
    this.COV_CD = COV_CD;
    return this;
  }
  private java.math.BigDecimal ORIG_INS_AMT;
  public java.math.BigDecimal get_ORIG_INS_AMT() {
    return ORIG_INS_AMT;
  }
  public void set_ORIG_INS_AMT(java.math.BigDecimal ORIG_INS_AMT) {
    this.ORIG_INS_AMT = ORIG_INS_AMT;
  }
  public QueryResult with_ORIG_INS_AMT(java.math.BigDecimal ORIG_INS_AMT) {
    this.ORIG_INS_AMT = ORIG_INS_AMT;
    return this;
  }
  private java.math.BigDecimal ORIG_OS_INS_AMT;
  public java.math.BigDecimal get_ORIG_OS_INS_AMT() {
    return ORIG_OS_INS_AMT;
  }
  public void set_ORIG_OS_INS_AMT(java.math.BigDecimal ORIG_OS_INS_AMT) {
    this.ORIG_OS_INS_AMT = ORIG_OS_INS_AMT;
  }
  public QueryResult with_ORIG_OS_INS_AMT(java.math.BigDecimal ORIG_OS_INS_AMT) {
    this.ORIG_OS_INS_AMT = ORIG_OS_INS_AMT;
    return this;
  }
  private java.math.BigDecimal PRPD_ORIG_OINS_AMT;
  public java.math.BigDecimal get_PRPD_ORIG_OINS_AMT() {
    return PRPD_ORIG_OINS_AMT;
  }
  public void set_PRPD_ORIG_OINS_AMT(java.math.BigDecimal PRPD_ORIG_OINS_AMT) {
    this.PRPD_ORIG_OINS_AMT = PRPD_ORIG_OINS_AMT;
  }
  public QueryResult with_PRPD_ORIG_OINS_AMT(java.math.BigDecimal PRPD_ORIG_OINS_AMT) {
    this.PRPD_ORIG_OINS_AMT = PRPD_ORIG_OINS_AMT;
    return this;
  }
  private java.math.BigDecimal ORIG_DMG_AMT;
  public java.math.BigDecimal get_ORIG_DMG_AMT() {
    return ORIG_DMG_AMT;
  }
  public void set_ORIG_DMG_AMT(java.math.BigDecimal ORIG_DMG_AMT) {
    this.ORIG_DMG_AMT = ORIG_DMG_AMT;
  }
  public QueryResult with_ORIG_DMG_AMT(java.math.BigDecimal ORIG_DMG_AMT) {
    this.ORIG_DMG_AMT = ORIG_DMG_AMT;
    return this;
  }
  private java.math.BigDecimal PSSE_INS_AMT;
  public java.math.BigDecimal get_PSSE_INS_AMT() {
    return PSSE_INS_AMT;
  }
  public void set_PSSE_INS_AMT(java.math.BigDecimal PSSE_INS_AMT) {
    this.PSSE_INS_AMT = PSSE_INS_AMT;
  }
  public QueryResult with_PSSE_INS_AMT(java.math.BigDecimal PSSE_INS_AMT) {
    this.PSSE_INS_AMT = PSSE_INS_AMT;
    return this;
  }
  private java.math.BigDecimal PSSE_OINS_AMT;
  public java.math.BigDecimal get_PSSE_OINS_AMT() {
    return PSSE_OINS_AMT;
  }
  public void set_PSSE_OINS_AMT(java.math.BigDecimal PSSE_OINS_AMT) {
    this.PSSE_OINS_AMT = PSSE_OINS_AMT;
  }
  public QueryResult with_PSSE_OINS_AMT(java.math.BigDecimal PSSE_OINS_AMT) {
    this.PSSE_OINS_AMT = PSSE_OINS_AMT;
    return this;
  }
  private java.math.BigDecimal PRPD_PSSE_OINS_AMT;
  public java.math.BigDecimal get_PRPD_PSSE_OINS_AMT() {
    return PRPD_PSSE_OINS_AMT;
  }
  public void set_PRPD_PSSE_OINS_AMT(java.math.BigDecimal PRPD_PSSE_OINS_AMT) {
    this.PRPD_PSSE_OINS_AMT = PRPD_PSSE_OINS_AMT;
  }
  public QueryResult with_PRPD_PSSE_OINS_AMT(java.math.BigDecimal PRPD_PSSE_OINS_AMT) {
    this.PRPD_PSSE_OINS_AMT = PRPD_PSSE_OINS_AMT;
    return this;
  }
  private java.math.BigDecimal PSSE_DMG_AMT;
  public java.math.BigDecimal get_PSSE_DMG_AMT() {
    return PSSE_DMG_AMT;
  }
  public void set_PSSE_DMG_AMT(java.math.BigDecimal PSSE_DMG_AMT) {
    this.PSSE_DMG_AMT = PSSE_DMG_AMT;
  }
  public QueryResult with_PSSE_DMG_AMT(java.math.BigDecimal PSSE_DMG_AMT) {
    this.PSSE_DMG_AMT = PSSE_DMG_AMT;
    return this;
  }
  private String ADD_PCS_YN;
  public String get_ADD_PCS_YN() {
    return ADD_PCS_YN;
  }
  public void set_ADD_PCS_YN(String ADD_PCS_YN) {
    this.ADD_PCS_YN = ADD_PCS_YN;
  }
  public QueryResult with_ADD_PCS_YN(String ADD_PCS_YN) {
    this.ADD_PCS_YN = ADD_PCS_YN;
    return this;
  }
  private String ACD_RCT_PTH_CD;
  public String get_ACD_RCT_PTH_CD() {
    return ACD_RCT_PTH_CD;
  }
  public void set_ACD_RCT_PTH_CD(String ACD_RCT_PTH_CD) {
    this.ACD_RCT_PTH_CD = ACD_RCT_PTH_CD;
  }
  public QueryResult with_ACD_RCT_PTH_CD(String ACD_RCT_PTH_CD) {
    this.ACD_RCT_PTH_CD = ACD_RCT_PTH_CD;
    return this;
  }
  private String UNT_PD_CD;
  public String get_UNT_PD_CD() {
    return UNT_PD_CD;
  }
  public void set_UNT_PD_CD(String UNT_PD_CD) {
    this.UNT_PD_CD = UNT_PD_CD;
  }
  public QueryResult with_UNT_PD_CD(String UNT_PD_CD) {
    this.UNT_PD_CD = UNT_PD_CD;
    return this;
  }
  private java.sql.Timestamp SBCP_DT;
  public java.sql.Timestamp get_SBCP_DT() {
    return SBCP_DT;
  }
  public void set_SBCP_DT(java.sql.Timestamp SBCP_DT) {
    this.SBCP_DT = SBCP_DT;
  }
  public QueryResult with_SBCP_DT(java.sql.Timestamp SBCP_DT) {
    this.SBCP_DT = SBCP_DT;
    return this;
  }
  private String TACD_DMPE_JOB_CD;
  public String get_TACD_DMPE_JOB_CD() {
    return TACD_DMPE_JOB_CD;
  }
  public void set_TACD_DMPE_JOB_CD(String TACD_DMPE_JOB_CD) {
    this.TACD_DMPE_JOB_CD = TACD_DMPE_JOB_CD;
  }
  public QueryResult with_TACD_DMPE_JOB_CD(String TACD_DMPE_JOB_CD) {
    this.TACD_DMPE_JOB_CD = TACD_DMPE_JOB_CD;
    return this;
  }
  private String TACD_DMPE_JOB_GRD_CD;
  public String get_TACD_DMPE_JOB_GRD_CD() {
    return TACD_DMPE_JOB_GRD_CD;
  }
  public void set_TACD_DMPE_JOB_GRD_CD(String TACD_DMPE_JOB_GRD_CD) {
    this.TACD_DMPE_JOB_GRD_CD = TACD_DMPE_JOB_GRD_CD;
  }
  public QueryResult with_TACD_DMPE_JOB_GRD_CD(String TACD_DMPE_JOB_GRD_CD) {
    this.TACD_DMPE_JOB_GRD_CD = TACD_DMPE_JOB_GRD_CD;
    return this;
  }
  private String TACD_DMPE_GNDR_CD;
  public String get_TACD_DMPE_GNDR_CD() {
    return TACD_DMPE_GNDR_CD;
  }
  public void set_TACD_DMPE_GNDR_CD(String TACD_DMPE_GNDR_CD) {
    this.TACD_DMPE_GNDR_CD = TACD_DMPE_GNDR_CD;
  }
  public QueryResult with_TACD_DMPE_GNDR_CD(String TACD_DMPE_GNDR_CD) {
    this.TACD_DMPE_GNDR_CD = TACD_DMPE_GNDR_CD;
    return this;
  }
  private java.math.BigDecimal TACD_DMPE_AGE;
  public java.math.BigDecimal get_TACD_DMPE_AGE() {
    return TACD_DMPE_AGE;
  }
  public void set_TACD_DMPE_AGE(java.math.BigDecimal TACD_DMPE_AGE) {
    this.TACD_DMPE_AGE = TACD_DMPE_AGE;
  }
  public QueryResult with_TACD_DMPE_AGE(java.math.BigDecimal TACD_DMPE_AGE) {
    this.TACD_DMPE_AGE = TACD_DMPE_AGE;
    return this;
  }
  private java.sql.Timestamp ACD_DT;
  public java.sql.Timestamp get_ACD_DT() {
    return ACD_DT;
  }
  public void set_ACD_DT(java.sql.Timestamp ACD_DT) {
    this.ACD_DT = ACD_DT;
  }
  public QueryResult with_ACD_DT(java.sql.Timestamp ACD_DT) {
    this.ACD_DT = ACD_DT;
    return this;
  }
  private String ACD_DT_HOLI_YN;
  public String get_ACD_DT_HOLI_YN() {
    return ACD_DT_HOLI_YN;
  }
  public void set_ACD_DT_HOLI_YN(String ACD_DT_HOLI_YN) {
    this.ACD_DT_HOLI_YN = ACD_DT_HOLI_YN;
  }
  public QueryResult with_ACD_DT_HOLI_YN(String ACD_DT_HOLI_YN) {
    this.ACD_DT_HOLI_YN = ACD_DT_HOLI_YN;
    return this;
  }
  private String ACD_PLC_ZPCD;
  public String get_ACD_PLC_ZPCD() {
    return ACD_PLC_ZPCD;
  }
  public void set_ACD_PLC_ZPCD(String ACD_PLC_ZPCD) {
    this.ACD_PLC_ZPCD = ACD_PLC_ZPCD;
  }
  public QueryResult with_ACD_PLC_ZPCD(String ACD_PLC_ZPCD) {
    this.ACD_PLC_ZPCD = ACD_PLC_ZPCD;
    return this;
  }
  private String ACD_PLC_SIDO_CD;
  public String get_ACD_PLC_SIDO_CD() {
    return ACD_PLC_SIDO_CD;
  }
  public void set_ACD_PLC_SIDO_CD(String ACD_PLC_SIDO_CD) {
    this.ACD_PLC_SIDO_CD = ACD_PLC_SIDO_CD;
  }
  public QueryResult with_ACD_PLC_SIDO_CD(String ACD_PLC_SIDO_CD) {
    this.ACD_PLC_SIDO_CD = ACD_PLC_SIDO_CD;
    return this;
  }
  private String ACD_CAUS_LCTG_CD;
  public String get_ACD_CAUS_LCTG_CD() {
    return ACD_CAUS_LCTG_CD;
  }
  public void set_ACD_CAUS_LCTG_CD(String ACD_CAUS_LCTG_CD) {
    this.ACD_CAUS_LCTG_CD = ACD_CAUS_LCTG_CD;
  }
  public QueryResult with_ACD_CAUS_LCTG_CD(String ACD_CAUS_LCTG_CD) {
    this.ACD_CAUS_LCTG_CD = ACD_CAUS_LCTG_CD;
    return this;
  }
  private String ACD_CAUS_MCTG_CD;
  public String get_ACD_CAUS_MCTG_CD() {
    return ACD_CAUS_MCTG_CD;
  }
  public void set_ACD_CAUS_MCTG_CD(String ACD_CAUS_MCTG_CD) {
    this.ACD_CAUS_MCTG_CD = ACD_CAUS_MCTG_CD;
  }
  public QueryResult with_ACD_CAUS_MCTG_CD(String ACD_CAUS_MCTG_CD) {
    this.ACD_CAUS_MCTG_CD = ACD_CAUS_MCTG_CD;
    return this;
  }
  private String ACD_CAUS_SCTG_CD;
  public String get_ACD_CAUS_SCTG_CD() {
    return ACD_CAUS_SCTG_CD;
  }
  public void set_ACD_CAUS_SCTG_CD(String ACD_CAUS_SCTG_CD) {
    this.ACD_CAUS_SCTG_CD = ACD_CAUS_SCTG_CD;
  }
  public QueryResult with_ACD_CAUS_SCTG_CD(String ACD_CAUS_SCTG_CD) {
    this.ACD_CAUS_SCTG_CD = ACD_CAUS_SCTG_CD;
    return this;
  }
  private String OVSE_MET_YN;
  public String get_OVSE_MET_YN() {
    return OVSE_MET_YN;
  }
  public void set_OVSE_MET_YN(String OVSE_MET_YN) {
    this.OVSE_MET_YN = OVSE_MET_YN;
  }
  public QueryResult with_OVSE_MET_YN(String OVSE_MET_YN) {
    this.OVSE_MET_YN = OVSE_MET_YN;
    return this;
  }
  private String KR_DISZ_CD;
  public String get_KR_DISZ_CD() {
    return KR_DISZ_CD;
  }
  public void set_KR_DISZ_CD(String KR_DISZ_CD) {
    this.KR_DISZ_CD = KR_DISZ_CD;
  }
  public QueryResult with_KR_DISZ_CD(String KR_DISZ_CD) {
    this.KR_DISZ_CD = KR_DISZ_CD;
    return this;
  }
  private String RCPR_INST_CD;
  public String get_RCPR_INST_CD() {
    return RCPR_INST_CD;
  }
  public void set_RCPR_INST_CD(String RCPR_INST_CD) {
    this.RCPR_INST_CD = RCPR_INST_CD;
  }
  public QueryResult with_RCPR_INST_CD(String RCPR_INST_CD) {
    this.RCPR_INST_CD = RCPR_INST_CD;
    return this;
  }
  private java.math.BigDecimal HSP_DD_NUM;
  public java.math.BigDecimal get_HSP_DD_NUM() {
    return HSP_DD_NUM;
  }
  public void set_HSP_DD_NUM(java.math.BigDecimal HSP_DD_NUM) {
    this.HSP_DD_NUM = HSP_DD_NUM;
  }
  public QueryResult with_HSP_DD_NUM(java.math.BigDecimal HSP_DD_NUM) {
    this.HSP_DD_NUM = HSP_DD_NUM;
    return this;
  }
  private java.math.BigDecimal GHR_DD_NUM;
  public java.math.BigDecimal get_GHR_DD_NUM() {
    return GHR_DD_NUM;
  }
  public void set_GHR_DD_NUM(java.math.BigDecimal GHR_DD_NUM) {
    this.GHR_DD_NUM = GHR_DD_NUM;
  }
  public QueryResult with_GHR_DD_NUM(java.math.BigDecimal GHR_DD_NUM) {
    this.GHR_DD_NUM = GHR_DD_NUM;
    return this;
  }
  private java.math.BigDecimal PSC_DD_NUM;
  public java.math.BigDecimal get_PSC_DD_NUM() {
    return PSC_DD_NUM;
  }
  public void set_PSC_DD_NUM(java.math.BigDecimal PSC_DD_NUM) {
    this.PSC_DD_NUM = PSC_DD_NUM;
  }
  public QueryResult with_PSC_DD_NUM(java.math.BigDecimal PSC_DD_NUM) {
    this.PSC_DD_NUM = PSC_DD_NUM;
    return this;
  }
  private java.math.BigDecimal DDPY_DD_NUM;
  public java.math.BigDecimal get_DDPY_DD_NUM() {
    return DDPY_DD_NUM;
  }
  public void set_DDPY_DD_NUM(java.math.BigDecimal DDPY_DD_NUM) {
    this.DDPY_DD_NUM = DDPY_DD_NUM;
  }
  public QueryResult with_DDPY_DD_NUM(java.math.BigDecimal DDPY_DD_NUM) {
    this.DDPY_DD_NUM = DDPY_DD_NUM;
    return this;
  }
  private java.math.BigDecimal OBST_RT;
  public java.math.BigDecimal get_OBST_RT() {
    return OBST_RT;
  }
  public void set_OBST_RT(java.math.BigDecimal OBST_RT) {
    this.OBST_RT = OBST_RT;
  }
  public QueryResult with_OBST_RT(java.math.BigDecimal OBST_RT) {
    this.OBST_RT = OBST_RT;
    return this;
  }
  private java.sql.Timestamp DTH_DT;
  public java.sql.Timestamp get_DTH_DT() {
    return DTH_DT;
  }
  public void set_DTH_DT(java.sql.Timestamp DTH_DT) {
    this.DTH_DT = DTH_DT;
  }
  public QueryResult with_DTH_DT(java.sql.Timestamp DTH_DT) {
    this.DTH_DT = DTH_DT;
    return this;
  }
  private java.math.BigDecimal DMG_RDUC_AMT;
  public java.math.BigDecimal get_DMG_RDUC_AMT() {
    return DMG_RDUC_AMT;
  }
  public void set_DMG_RDUC_AMT(java.math.BigDecimal DMG_RDUC_AMT) {
    this.DMG_RDUC_AMT = DMG_RDUC_AMT;
  }
  public QueryResult with_DMG_RDUC_AMT(java.math.BigDecimal DMG_RDUC_AMT) {
    this.DMG_RDUC_AMT = DMG_RDUC_AMT;
    return this;
  }
  private String CLADJ_DAMR_LCTG_CD;
  public String get_CLADJ_DAMR_LCTG_CD() {
    return CLADJ_DAMR_LCTG_CD;
  }
  public void set_CLADJ_DAMR_LCTG_CD(String CLADJ_DAMR_LCTG_CD) {
    this.CLADJ_DAMR_LCTG_CD = CLADJ_DAMR_LCTG_CD;
  }
  public QueryResult with_CLADJ_DAMR_LCTG_CD(String CLADJ_DAMR_LCTG_CD) {
    this.CLADJ_DAMR_LCTG_CD = CLADJ_DAMR_LCTG_CD;
    return this;
  }
  private String CLADJ_DAMR_MCTG_CD;
  public String get_CLADJ_DAMR_MCTG_CD() {
    return CLADJ_DAMR_MCTG_CD;
  }
  public void set_CLADJ_DAMR_MCTG_CD(String CLADJ_DAMR_MCTG_CD) {
    this.CLADJ_DAMR_MCTG_CD = CLADJ_DAMR_MCTG_CD;
  }
  public QueryResult with_CLADJ_DAMR_MCTG_CD(String CLADJ_DAMR_MCTG_CD) {
    this.CLADJ_DAMR_MCTG_CD = CLADJ_DAMR_MCTG_CD;
    return this;
  }
  private String SIU_SVY_RQS_YN;
  public String get_SIU_SVY_RQS_YN() {
    return SIU_SVY_RQS_YN;
  }
  public void set_SIU_SVY_RQS_YN(String SIU_SVY_RQS_YN) {
    this.SIU_SVY_RQS_YN = SIU_SVY_RQS_YN;
  }
  public QueryResult with_SIU_SVY_RQS_YN(String SIU_SVY_RQS_YN) {
    this.SIU_SVY_RQS_YN = SIU_SVY_RQS_YN;
    return this;
  }
  private String DAMR_GRDE_CD;
  public String get_DAMR_GRDE_CD() {
    return DAMR_GRDE_CD;
  }
  public void set_DAMR_GRDE_CD(String DAMR_GRDE_CD) {
    this.DAMR_GRDE_CD = DAMR_GRDE_CD;
  }
  public QueryResult with_DAMR_GRDE_CD(String DAMR_GRDE_CD) {
    this.DAMR_GRDE_CD = DAMR_GRDE_CD;
    return this;
  }
  private String DLG_YN;
  public String get_DLG_YN() {
    return DLG_YN;
  }
  public void set_DLG_YN(String DLG_YN) {
    this.DLG_YN = DLG_YN;
  }
  public QueryResult with_DLG_YN(String DLG_YN) {
    this.DLG_YN = DLG_YN;
    return this;
  }
  private String DLG_CON_CD_NM;
  public String get_DLG_CON_CD_NM() {
    return DLG_CON_CD_NM;
  }
  public void set_DLG_CON_CD_NM(String DLG_CON_CD_NM) {
    this.DLG_CON_CD_NM = DLG_CON_CD_NM;
  }
  public QueryResult with_DLG_CON_CD_NM(String DLG_CON_CD_NM) {
    this.DLG_CON_CD_NM = DLG_CON_CD_NM;
    return this;
  }
  private String DLG_CO_NM;
  public String get_DLG_CO_NM() {
    return DLG_CO_NM;
  }
  public void set_DLG_CO_NM(String DLG_CO_NM) {
    this.DLG_CO_NM = DLG_CO_NM;
  }
  public QueryResult with_DLG_CO_NM(String DLG_CO_NM) {
    this.DLG_CO_NM = DLG_CO_NM;
    return this;
  }
  private String SVY_INST_NM;
  public String get_SVY_INST_NM() {
    return SVY_INST_NM;
  }
  public void set_SVY_INST_NM(String SVY_INST_NM) {
    this.SVY_INST_NM = SVY_INST_NM;
  }
  public QueryResult with_SVY_INST_NM(String SVY_INST_NM) {
    this.SVY_INST_NM = SVY_INST_NM;
    return this;
  }
  private String TRT_HDQT_ORG_CD;
  public String get_TRT_HDQT_ORG_CD() {
    return TRT_HDQT_ORG_CD;
  }
  public void set_TRT_HDQT_ORG_CD(String TRT_HDQT_ORG_CD) {
    this.TRT_HDQT_ORG_CD = TRT_HDQT_ORG_CD;
  }
  public QueryResult with_TRT_HDQT_ORG_CD(String TRT_HDQT_ORG_CD) {
    this.TRT_HDQT_ORG_CD = TRT_HDQT_ORG_CD;
    return this;
  }
  private String TRT_BRCH_ORG_CD;
  public String get_TRT_BRCH_ORG_CD() {
    return TRT_BRCH_ORG_CD;
  }
  public void set_TRT_BRCH_ORG_CD(String TRT_BRCH_ORG_CD) {
    this.TRT_BRCH_ORG_CD = TRT_BRCH_ORG_CD;
  }
  public QueryResult with_TRT_BRCH_ORG_CD(String TRT_BRCH_ORG_CD) {
    this.TRT_BRCH_ORG_CD = TRT_BRCH_ORG_CD;
    return this;
  }
  private String TRT_BCH_ORG_CD;
  public String get_TRT_BCH_ORG_CD() {
    return TRT_BCH_ORG_CD;
  }
  public void set_TRT_BCH_ORG_CD(String TRT_BCH_ORG_CD) {
    this.TRT_BCH_ORG_CD = TRT_BCH_ORG_CD;
  }
  public QueryResult with_TRT_BCH_ORG_CD(String TRT_BCH_ORG_CD) {
    this.TRT_BCH_ORG_CD = TRT_BCH_ORG_CD;
    return this;
  }
  private String TRTPE_ORG_CD;
  public String get_TRTPE_ORG_CD() {
    return TRTPE_ORG_CD;
  }
  public void set_TRTPE_ORG_CD(String TRTPE_ORG_CD) {
    this.TRTPE_ORG_CD = TRTPE_ORG_CD;
  }
  public QueryResult with_TRTPE_ORG_CD(String TRTPE_ORG_CD) {
    this.TRTPE_ORG_CD = TRTPE_ORG_CD;
    return this;
  }
  private String PCS_COMS_TEM_ORG_CD;
  public String get_PCS_COMS_TEM_ORG_CD() {
    return PCS_COMS_TEM_ORG_CD;
  }
  public void set_PCS_COMS_TEM_ORG_CD(String PCS_COMS_TEM_ORG_CD) {
    this.PCS_COMS_TEM_ORG_CD = PCS_COMS_TEM_ORG_CD;
  }
  public QueryResult with_PCS_COMS_TEM_ORG_CD(String PCS_COMS_TEM_ORG_CD) {
    this.PCS_COMS_TEM_ORG_CD = PCS_COMS_TEM_ORG_CD;
    return this;
  }
  private String PCS_COMS_PART_ORG_CD;
  public String get_PCS_COMS_PART_ORG_CD() {
    return PCS_COMS_PART_ORG_CD;
  }
  public void set_PCS_COMS_PART_ORG_CD(String PCS_COMS_PART_ORG_CD) {
    this.PCS_COMS_PART_ORG_CD = PCS_COMS_PART_ORG_CD;
  }
  public QueryResult with_PCS_COMS_PART_ORG_CD(String PCS_COMS_PART_ORG_CD) {
    this.PCS_COMS_PART_ORG_CD = PCS_COMS_PART_ORG_CD;
    return this;
  }
  private String CHRPE_ORG_CD;
  public String get_CHRPE_ORG_CD() {
    return CHRPE_ORG_CD;
  }
  public void set_CHRPE_ORG_CD(String CHRPE_ORG_CD) {
    this.CHRPE_ORG_CD = CHRPE_ORG_CD;
  }
  public QueryResult with_CHRPE_ORG_CD(String CHRPE_ORG_CD) {
    this.CHRPE_ORG_CD = CHRPE_ORG_CD;
    return this;
  }
  private java.sql.Timestamp RCT_DT;
  public java.sql.Timestamp get_RCT_DT() {
    return RCT_DT;
  }
  public void set_RCT_DT(java.sql.Timestamp RCT_DT) {
    this.RCT_DT = RCT_DT;
  }
  public QueryResult with_RCT_DT(java.sql.Timestamp RCT_DT) {
    this.RCT_DT = RCT_DT;
    return this;
  }
  private java.sql.Timestamp FRS_OS_DT;
  public java.sql.Timestamp get_FRS_OS_DT() {
    return FRS_OS_DT;
  }
  public void set_FRS_OS_DT(java.sql.Timestamp FRS_OS_DT) {
    this.FRS_OS_DT = FRS_OS_DT;
  }
  public QueryResult with_FRS_OS_DT(java.sql.Timestamp FRS_OS_DT) {
    this.FRS_OS_DT = FRS_OS_DT;
    return this;
  }
  private java.sql.Timestamp LAST_OS_DT;
  public java.sql.Timestamp get_LAST_OS_DT() {
    return LAST_OS_DT;
  }
  public void set_LAST_OS_DT(java.sql.Timestamp LAST_OS_DT) {
    this.LAST_OS_DT = LAST_OS_DT;
  }
  public QueryResult with_LAST_OS_DT(java.sql.Timestamp LAST_OS_DT) {
    this.LAST_OS_DT = LAST_OS_DT;
    return this;
  }
  private java.sql.Timestamp APVL_DT;
  public java.sql.Timestamp get_APVL_DT() {
    return APVL_DT;
  }
  public void set_APVL_DT(java.sql.Timestamp APVL_DT) {
    this.APVL_DT = APVL_DT;
  }
  public QueryResult with_APVL_DT(java.sql.Timestamp APVL_DT) {
    this.APVL_DT = APVL_DT;
    return this;
  }
  private java.sql.Timestamp LAST_RCT_DT;
  public java.sql.Timestamp get_LAST_RCT_DT() {
    return LAST_RCT_DT;
  }
  public void set_LAST_RCT_DT(java.sql.Timestamp LAST_RCT_DT) {
    this.LAST_RCT_DT = LAST_RCT_DT;
  }
  public QueryResult with_LAST_RCT_DT(java.sql.Timestamp LAST_RCT_DT) {
    this.LAST_RCT_DT = LAST_RCT_DT;
    return this;
  }
  private String FRS_RCTPE_ORG_CD;
  public String get_FRS_RCTPE_ORG_CD() {
    return FRS_RCTPE_ORG_CD;
  }
  public void set_FRS_RCTPE_ORG_CD(String FRS_RCTPE_ORG_CD) {
    this.FRS_RCTPE_ORG_CD = FRS_RCTPE_ORG_CD;
  }
  public QueryResult with_FRS_RCTPE_ORG_CD(String FRS_RCTPE_ORG_CD) {
    this.FRS_RCTPE_ORG_CD = FRS_RCTPE_ORG_CD;
    return this;
  }
  private String CTR_OBJ_ID;
  public String get_CTR_OBJ_ID() {
    return CTR_OBJ_ID;
  }
  public void set_CTR_OBJ_ID(String CTR_OBJ_ID) {
    this.CTR_OBJ_ID = CTR_OBJ_ID;
  }
  public QueryResult with_CTR_OBJ_ID(String CTR_OBJ_ID) {
    this.CTR_OBJ_ID = CTR_OBJ_ID;
    return this;
  }
  private String DMPE_CUS_ID;
  public String get_DMPE_CUS_ID() {
    return DMPE_CUS_ID;
  }
  public void set_DMPE_CUS_ID(String DMPE_CUS_ID) {
    this.DMPE_CUS_ID = DMPE_CUS_ID;
  }
  public QueryResult with_DMPE_CUS_ID(String DMPE_CUS_ID) {
    this.DMPE_CUS_ID = DMPE_CUS_ID;
    return this;
  }
  private java.sql.Timestamp EIH_LDG_DTM;
  public java.sql.Timestamp get_EIH_LDG_DTM() {
    return EIH_LDG_DTM;
  }
  public void set_EIH_LDG_DTM(java.sql.Timestamp EIH_LDG_DTM) {
    this.EIH_LDG_DTM = EIH_LDG_DTM;
  }
  public QueryResult with_EIH_LDG_DTM(java.sql.Timestamp EIH_LDG_DTM) {
    this.EIH_LDG_DTM = EIH_LDG_DTM;
    return this;
  }
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (!(o instanceof QueryResult)) {
      return false;
    }
    QueryResult that = (QueryResult) o;
    boolean equal = true;
    equal = equal && (this.STD_YYMM == null ? that.STD_YYMM == null : this.STD_YYMM.equals(that.STD_YYMM));
    equal = equal && (this.ACD_NO_YY == null ? that.ACD_NO_YY == null : this.ACD_NO_YY.equals(that.ACD_NO_YY));
    equal = equal && (this.ACD_NO_SEQ == null ? that.ACD_NO_SEQ == null : this.ACD_NO_SEQ.equals(that.ACD_NO_SEQ));
    equal = equal && (this.POL_NO == null ? that.POL_NO == null : this.POL_NO.equals(that.POL_NO));
    equal = equal && (this.CLM_TP_CD == null ? that.CLM_TP_CD == null : this.CLM_TP_CD.equals(that.CLM_TP_CD));
    equal = equal && (this.DAM_ORD == null ? that.DAM_ORD == null : this.DAM_ORD.equals(that.DAM_ORD));
    equal = equal && (this.COV_CD == null ? that.COV_CD == null : this.COV_CD.equals(that.COV_CD));
    equal = equal && (this.ORIG_INS_AMT == null ? that.ORIG_INS_AMT == null : this.ORIG_INS_AMT.equals(that.ORIG_INS_AMT));
    equal = equal && (this.ORIG_OS_INS_AMT == null ? that.ORIG_OS_INS_AMT == null : this.ORIG_OS_INS_AMT.equals(that.ORIG_OS_INS_AMT));
    equal = equal && (this.PRPD_ORIG_OINS_AMT == null ? that.PRPD_ORIG_OINS_AMT == null : this.PRPD_ORIG_OINS_AMT.equals(that.PRPD_ORIG_OINS_AMT));
    equal = equal && (this.ORIG_DMG_AMT == null ? that.ORIG_DMG_AMT == null : this.ORIG_DMG_AMT.equals(that.ORIG_DMG_AMT));
    equal = equal && (this.PSSE_INS_AMT == null ? that.PSSE_INS_AMT == null : this.PSSE_INS_AMT.equals(that.PSSE_INS_AMT));
    equal = equal && (this.PSSE_OINS_AMT == null ? that.PSSE_OINS_AMT == null : this.PSSE_OINS_AMT.equals(that.PSSE_OINS_AMT));
    equal = equal && (this.PRPD_PSSE_OINS_AMT == null ? that.PRPD_PSSE_OINS_AMT == null : this.PRPD_PSSE_OINS_AMT.equals(that.PRPD_PSSE_OINS_AMT));
    equal = equal && (this.PSSE_DMG_AMT == null ? that.PSSE_DMG_AMT == null : this.PSSE_DMG_AMT.equals(that.PSSE_DMG_AMT));
    equal = equal && (this.ADD_PCS_YN == null ? that.ADD_PCS_YN == null : this.ADD_PCS_YN.equals(that.ADD_PCS_YN));
    equal = equal && (this.ACD_RCT_PTH_CD == null ? that.ACD_RCT_PTH_CD == null : this.ACD_RCT_PTH_CD.equals(that.ACD_RCT_PTH_CD));
    equal = equal && (this.UNT_PD_CD == null ? that.UNT_PD_CD == null : this.UNT_PD_CD.equals(that.UNT_PD_CD));
    equal = equal && (this.SBCP_DT == null ? that.SBCP_DT == null : this.SBCP_DT.equals(that.SBCP_DT));
    equal = equal && (this.TACD_DMPE_JOB_CD == null ? that.TACD_DMPE_JOB_CD == null : this.TACD_DMPE_JOB_CD.equals(that.TACD_DMPE_JOB_CD));
    equal = equal && (this.TACD_DMPE_JOB_GRD_CD == null ? that.TACD_DMPE_JOB_GRD_CD == null : this.TACD_DMPE_JOB_GRD_CD.equals(that.TACD_DMPE_JOB_GRD_CD));
    equal = equal && (this.TACD_DMPE_GNDR_CD == null ? that.TACD_DMPE_GNDR_CD == null : this.TACD_DMPE_GNDR_CD.equals(that.TACD_DMPE_GNDR_CD));
    equal = equal && (this.TACD_DMPE_AGE == null ? that.TACD_DMPE_AGE == null : this.TACD_DMPE_AGE.equals(that.TACD_DMPE_AGE));
    equal = equal && (this.ACD_DT == null ? that.ACD_DT == null : this.ACD_DT.equals(that.ACD_DT));
    equal = equal && (this.ACD_DT_HOLI_YN == null ? that.ACD_DT_HOLI_YN == null : this.ACD_DT_HOLI_YN.equals(that.ACD_DT_HOLI_YN));
    equal = equal && (this.ACD_PLC_ZPCD == null ? that.ACD_PLC_ZPCD == null : this.ACD_PLC_ZPCD.equals(that.ACD_PLC_ZPCD));
    equal = equal && (this.ACD_PLC_SIDO_CD == null ? that.ACD_PLC_SIDO_CD == null : this.ACD_PLC_SIDO_CD.equals(that.ACD_PLC_SIDO_CD));
    equal = equal && (this.ACD_CAUS_LCTG_CD == null ? that.ACD_CAUS_LCTG_CD == null : this.ACD_CAUS_LCTG_CD.equals(that.ACD_CAUS_LCTG_CD));
    equal = equal && (this.ACD_CAUS_MCTG_CD == null ? that.ACD_CAUS_MCTG_CD == null : this.ACD_CAUS_MCTG_CD.equals(that.ACD_CAUS_MCTG_CD));
    equal = equal && (this.ACD_CAUS_SCTG_CD == null ? that.ACD_CAUS_SCTG_CD == null : this.ACD_CAUS_SCTG_CD.equals(that.ACD_CAUS_SCTG_CD));
    equal = equal && (this.OVSE_MET_YN == null ? that.OVSE_MET_YN == null : this.OVSE_MET_YN.equals(that.OVSE_MET_YN));
    equal = equal && (this.KR_DISZ_CD == null ? that.KR_DISZ_CD == null : this.KR_DISZ_CD.equals(that.KR_DISZ_CD));
    equal = equal && (this.RCPR_INST_CD == null ? that.RCPR_INST_CD == null : this.RCPR_INST_CD.equals(that.RCPR_INST_CD));
    equal = equal && (this.HSP_DD_NUM == null ? that.HSP_DD_NUM == null : this.HSP_DD_NUM.equals(that.HSP_DD_NUM));
    equal = equal && (this.GHR_DD_NUM == null ? that.GHR_DD_NUM == null : this.GHR_DD_NUM.equals(that.GHR_DD_NUM));
    equal = equal && (this.PSC_DD_NUM == null ? that.PSC_DD_NUM == null : this.PSC_DD_NUM.equals(that.PSC_DD_NUM));
    equal = equal && (this.DDPY_DD_NUM == null ? that.DDPY_DD_NUM == null : this.DDPY_DD_NUM.equals(that.DDPY_DD_NUM));
    equal = equal && (this.OBST_RT == null ? that.OBST_RT == null : this.OBST_RT.equals(that.OBST_RT));
    equal = equal && (this.DTH_DT == null ? that.DTH_DT == null : this.DTH_DT.equals(that.DTH_DT));
    equal = equal && (this.DMG_RDUC_AMT == null ? that.DMG_RDUC_AMT == null : this.DMG_RDUC_AMT.equals(that.DMG_RDUC_AMT));
    equal = equal && (this.CLADJ_DAMR_LCTG_CD == null ? that.CLADJ_DAMR_LCTG_CD == null : this.CLADJ_DAMR_LCTG_CD.equals(that.CLADJ_DAMR_LCTG_CD));
    equal = equal && (this.CLADJ_DAMR_MCTG_CD == null ? that.CLADJ_DAMR_MCTG_CD == null : this.CLADJ_DAMR_MCTG_CD.equals(that.CLADJ_DAMR_MCTG_CD));
    equal = equal && (this.SIU_SVY_RQS_YN == null ? that.SIU_SVY_RQS_YN == null : this.SIU_SVY_RQS_YN.equals(that.SIU_SVY_RQS_YN));
    equal = equal && (this.DAMR_GRDE_CD == null ? that.DAMR_GRDE_CD == null : this.DAMR_GRDE_CD.equals(that.DAMR_GRDE_CD));
    equal = equal && (this.DLG_YN == null ? that.DLG_YN == null : this.DLG_YN.equals(that.DLG_YN));
    equal = equal && (this.DLG_CON_CD_NM == null ? that.DLG_CON_CD_NM == null : this.DLG_CON_CD_NM.equals(that.DLG_CON_CD_NM));
    equal = equal && (this.DLG_CO_NM == null ? that.DLG_CO_NM == null : this.DLG_CO_NM.equals(that.DLG_CO_NM));
    equal = equal && (this.SVY_INST_NM == null ? that.SVY_INST_NM == null : this.SVY_INST_NM.equals(that.SVY_INST_NM));
    equal = equal && (this.TRT_HDQT_ORG_CD == null ? that.TRT_HDQT_ORG_CD == null : this.TRT_HDQT_ORG_CD.equals(that.TRT_HDQT_ORG_CD));
    equal = equal && (this.TRT_BRCH_ORG_CD == null ? that.TRT_BRCH_ORG_CD == null : this.TRT_BRCH_ORG_CD.equals(that.TRT_BRCH_ORG_CD));
    equal = equal && (this.TRT_BCH_ORG_CD == null ? that.TRT_BCH_ORG_CD == null : this.TRT_BCH_ORG_CD.equals(that.TRT_BCH_ORG_CD));
    equal = equal && (this.TRTPE_ORG_CD == null ? that.TRTPE_ORG_CD == null : this.TRTPE_ORG_CD.equals(that.TRTPE_ORG_CD));
    equal = equal && (this.PCS_COMS_TEM_ORG_CD == null ? that.PCS_COMS_TEM_ORG_CD == null : this.PCS_COMS_TEM_ORG_CD.equals(that.PCS_COMS_TEM_ORG_CD));
    equal = equal && (this.PCS_COMS_PART_ORG_CD == null ? that.PCS_COMS_PART_ORG_CD == null : this.PCS_COMS_PART_ORG_CD.equals(that.PCS_COMS_PART_ORG_CD));
    equal = equal && (this.CHRPE_ORG_CD == null ? that.CHRPE_ORG_CD == null : this.CHRPE_ORG_CD.equals(that.CHRPE_ORG_CD));
    equal = equal && (this.RCT_DT == null ? that.RCT_DT == null : this.RCT_DT.equals(that.RCT_DT));
    equal = equal && (this.FRS_OS_DT == null ? that.FRS_OS_DT == null : this.FRS_OS_DT.equals(that.FRS_OS_DT));
    equal = equal && (this.LAST_OS_DT == null ? that.LAST_OS_DT == null : this.LAST_OS_DT.equals(that.LAST_OS_DT));
    equal = equal && (this.APVL_DT == null ? that.APVL_DT == null : this.APVL_DT.equals(that.APVL_DT));
    equal = equal && (this.LAST_RCT_DT == null ? that.LAST_RCT_DT == null : this.LAST_RCT_DT.equals(that.LAST_RCT_DT));
    equal = equal && (this.FRS_RCTPE_ORG_CD == null ? that.FRS_RCTPE_ORG_CD == null : this.FRS_RCTPE_ORG_CD.equals(that.FRS_RCTPE_ORG_CD));
    equal = equal && (this.CTR_OBJ_ID == null ? that.CTR_OBJ_ID == null : this.CTR_OBJ_ID.equals(that.CTR_OBJ_ID));
    equal = equal && (this.DMPE_CUS_ID == null ? that.DMPE_CUS_ID == null : this.DMPE_CUS_ID.equals(that.DMPE_CUS_ID));
    equal = equal && (this.EIH_LDG_DTM == null ? that.EIH_LDG_DTM == null : this.EIH_LDG_DTM.equals(that.EIH_LDG_DTM));
    return equal;
  }
  public boolean equals0(Object o) {
    if (this == o) {
      return true;
    }
    if (!(o instanceof QueryResult)) {
      return false;
    }
    QueryResult that = (QueryResult) o;
    boolean equal = true;
    equal = equal && (this.STD_YYMM == null ? that.STD_YYMM == null : this.STD_YYMM.equals(that.STD_YYMM));
    equal = equal && (this.ACD_NO_YY == null ? that.ACD_NO_YY == null : this.ACD_NO_YY.equals(that.ACD_NO_YY));
    equal = equal && (this.ACD_NO_SEQ == null ? that.ACD_NO_SEQ == null : this.ACD_NO_SEQ.equals(that.ACD_NO_SEQ));
    equal = equal && (this.POL_NO == null ? that.POL_NO == null : this.POL_NO.equals(that.POL_NO));
    equal = equal && (this.CLM_TP_CD == null ? that.CLM_TP_CD == null : this.CLM_TP_CD.equals(that.CLM_TP_CD));
    equal = equal && (this.DAM_ORD == null ? that.DAM_ORD == null : this.DAM_ORD.equals(that.DAM_ORD));
    equal = equal && (this.COV_CD == null ? that.COV_CD == null : this.COV_CD.equals(that.COV_CD));
    equal = equal && (this.ORIG_INS_AMT == null ? that.ORIG_INS_AMT == null : this.ORIG_INS_AMT.equals(that.ORIG_INS_AMT));
    equal = equal && (this.ORIG_OS_INS_AMT == null ? that.ORIG_OS_INS_AMT == null : this.ORIG_OS_INS_AMT.equals(that.ORIG_OS_INS_AMT));
    equal = equal && (this.PRPD_ORIG_OINS_AMT == null ? that.PRPD_ORIG_OINS_AMT == null : this.PRPD_ORIG_OINS_AMT.equals(that.PRPD_ORIG_OINS_AMT));
    equal = equal && (this.ORIG_DMG_AMT == null ? that.ORIG_DMG_AMT == null : this.ORIG_DMG_AMT.equals(that.ORIG_DMG_AMT));
    equal = equal && (this.PSSE_INS_AMT == null ? that.PSSE_INS_AMT == null : this.PSSE_INS_AMT.equals(that.PSSE_INS_AMT));
    equal = equal && (this.PSSE_OINS_AMT == null ? that.PSSE_OINS_AMT == null : this.PSSE_OINS_AMT.equals(that.PSSE_OINS_AMT));
    equal = equal && (this.PRPD_PSSE_OINS_AMT == null ? that.PRPD_PSSE_OINS_AMT == null : this.PRPD_PSSE_OINS_AMT.equals(that.PRPD_PSSE_OINS_AMT));
    equal = equal && (this.PSSE_DMG_AMT == null ? that.PSSE_DMG_AMT == null : this.PSSE_DMG_AMT.equals(that.PSSE_DMG_AMT));
    equal = equal && (this.ADD_PCS_YN == null ? that.ADD_PCS_YN == null : this.ADD_PCS_YN.equals(that.ADD_PCS_YN));
    equal = equal && (this.ACD_RCT_PTH_CD == null ? that.ACD_RCT_PTH_CD == null : this.ACD_RCT_PTH_CD.equals(that.ACD_RCT_PTH_CD));
    equal = equal && (this.UNT_PD_CD == null ? that.UNT_PD_CD == null : this.UNT_PD_CD.equals(that.UNT_PD_CD));
    equal = equal && (this.SBCP_DT == null ? that.SBCP_DT == null : this.SBCP_DT.equals(that.SBCP_DT));
    equal = equal && (this.TACD_DMPE_JOB_CD == null ? that.TACD_DMPE_JOB_CD == null : this.TACD_DMPE_JOB_CD.equals(that.TACD_DMPE_JOB_CD));
    equal = equal && (this.TACD_DMPE_JOB_GRD_CD == null ? that.TACD_DMPE_JOB_GRD_CD == null : this.TACD_DMPE_JOB_GRD_CD.equals(that.TACD_DMPE_JOB_GRD_CD));
    equal = equal && (this.TACD_DMPE_GNDR_CD == null ? that.TACD_DMPE_GNDR_CD == null : this.TACD_DMPE_GNDR_CD.equals(that.TACD_DMPE_GNDR_CD));
    equal = equal && (this.TACD_DMPE_AGE == null ? that.TACD_DMPE_AGE == null : this.TACD_DMPE_AGE.equals(that.TACD_DMPE_AGE));
    equal = equal && (this.ACD_DT == null ? that.ACD_DT == null : this.ACD_DT.equals(that.ACD_DT));
    equal = equal && (this.ACD_DT_HOLI_YN == null ? that.ACD_DT_HOLI_YN == null : this.ACD_DT_HOLI_YN.equals(that.ACD_DT_HOLI_YN));
    equal = equal && (this.ACD_PLC_ZPCD == null ? that.ACD_PLC_ZPCD == null : this.ACD_PLC_ZPCD.equals(that.ACD_PLC_ZPCD));
    equal = equal && (this.ACD_PLC_SIDO_CD == null ? that.ACD_PLC_SIDO_CD == null : this.ACD_PLC_SIDO_CD.equals(that.ACD_PLC_SIDO_CD));
    equal = equal && (this.ACD_CAUS_LCTG_CD == null ? that.ACD_CAUS_LCTG_CD == null : this.ACD_CAUS_LCTG_CD.equals(that.ACD_CAUS_LCTG_CD));
    equal = equal && (this.ACD_CAUS_MCTG_CD == null ? that.ACD_CAUS_MCTG_CD == null : this.ACD_CAUS_MCTG_CD.equals(that.ACD_CAUS_MCTG_CD));
    equal = equal && (this.ACD_CAUS_SCTG_CD == null ? that.ACD_CAUS_SCTG_CD == null : this.ACD_CAUS_SCTG_CD.equals(that.ACD_CAUS_SCTG_CD));
    equal = equal && (this.OVSE_MET_YN == null ? that.OVSE_MET_YN == null : this.OVSE_MET_YN.equals(that.OVSE_MET_YN));
    equal = equal && (this.KR_DISZ_CD == null ? that.KR_DISZ_CD == null : this.KR_DISZ_CD.equals(that.KR_DISZ_CD));
    equal = equal && (this.RCPR_INST_CD == null ? that.RCPR_INST_CD == null : this.RCPR_INST_CD.equals(that.RCPR_INST_CD));
    equal = equal && (this.HSP_DD_NUM == null ? that.HSP_DD_NUM == null : this.HSP_DD_NUM.equals(that.HSP_DD_NUM));
    equal = equal && (this.GHR_DD_NUM == null ? that.GHR_DD_NUM == null : this.GHR_DD_NUM.equals(that.GHR_DD_NUM));
    equal = equal && (this.PSC_DD_NUM == null ? that.PSC_DD_NUM == null : this.PSC_DD_NUM.equals(that.PSC_DD_NUM));
    equal = equal && (this.DDPY_DD_NUM == null ? that.DDPY_DD_NUM == null : this.DDPY_DD_NUM.equals(that.DDPY_DD_NUM));
    equal = equal && (this.OBST_RT == null ? that.OBST_RT == null : this.OBST_RT.equals(that.OBST_RT));
    equal = equal && (this.DTH_DT == null ? that.DTH_DT == null : this.DTH_DT.equals(that.DTH_DT));
    equal = equal && (this.DMG_RDUC_AMT == null ? that.DMG_RDUC_AMT == null : this.DMG_RDUC_AMT.equals(that.DMG_RDUC_AMT));
    equal = equal && (this.CLADJ_DAMR_LCTG_CD == null ? that.CLADJ_DAMR_LCTG_CD == null : this.CLADJ_DAMR_LCTG_CD.equals(that.CLADJ_DAMR_LCTG_CD));
    equal = equal && (this.CLADJ_DAMR_MCTG_CD == null ? that.CLADJ_DAMR_MCTG_CD == null : this.CLADJ_DAMR_MCTG_CD.equals(that.CLADJ_DAMR_MCTG_CD));
    equal = equal && (this.SIU_SVY_RQS_YN == null ? that.SIU_SVY_RQS_YN == null : this.SIU_SVY_RQS_YN.equals(that.SIU_SVY_RQS_YN));
    equal = equal && (this.DAMR_GRDE_CD == null ? that.DAMR_GRDE_CD == null : this.DAMR_GRDE_CD.equals(that.DAMR_GRDE_CD));
    equal = equal && (this.DLG_YN == null ? that.DLG_YN == null : this.DLG_YN.equals(that.DLG_YN));
    equal = equal && (this.DLG_CON_CD_NM == null ? that.DLG_CON_CD_NM == null : this.DLG_CON_CD_NM.equals(that.DLG_CON_CD_NM));
    equal = equal && (this.DLG_CO_NM == null ? that.DLG_CO_NM == null : this.DLG_CO_NM.equals(that.DLG_CO_NM));
    equal = equal && (this.SVY_INST_NM == null ? that.SVY_INST_NM == null : this.SVY_INST_NM.equals(that.SVY_INST_NM));
    equal = equal && (this.TRT_HDQT_ORG_CD == null ? that.TRT_HDQT_ORG_CD == null : this.TRT_HDQT_ORG_CD.equals(that.TRT_HDQT_ORG_CD));
    equal = equal && (this.TRT_BRCH_ORG_CD == null ? that.TRT_BRCH_ORG_CD == null : this.TRT_BRCH_ORG_CD.equals(that.TRT_BRCH_ORG_CD));
    equal = equal && (this.TRT_BCH_ORG_CD == null ? that.TRT_BCH_ORG_CD == null : this.TRT_BCH_ORG_CD.equals(that.TRT_BCH_ORG_CD));
    equal = equal && (this.TRTPE_ORG_CD == null ? that.TRTPE_ORG_CD == null : this.TRTPE_ORG_CD.equals(that.TRTPE_ORG_CD));
    equal = equal && (this.PCS_COMS_TEM_ORG_CD == null ? that.PCS_COMS_TEM_ORG_CD == null : this.PCS_COMS_TEM_ORG_CD.equals(that.PCS_COMS_TEM_ORG_CD));
    equal = equal && (this.PCS_COMS_PART_ORG_CD == null ? that.PCS_COMS_PART_ORG_CD == null : this.PCS_COMS_PART_ORG_CD.equals(that.PCS_COMS_PART_ORG_CD));
    equal = equal && (this.CHRPE_ORG_CD == null ? that.CHRPE_ORG_CD == null : this.CHRPE_ORG_CD.equals(that.CHRPE_ORG_CD));
    equal = equal && (this.RCT_DT == null ? that.RCT_DT == null : this.RCT_DT.equals(that.RCT_DT));
    equal = equal && (this.FRS_OS_DT == null ? that.FRS_OS_DT == null : this.FRS_OS_DT.equals(that.FRS_OS_DT));
    equal = equal && (this.LAST_OS_DT == null ? that.LAST_OS_DT == null : this.LAST_OS_DT.equals(that.LAST_OS_DT));
    equal = equal && (this.APVL_DT == null ? that.APVL_DT == null : this.APVL_DT.equals(that.APVL_DT));
    equal = equal && (this.LAST_RCT_DT == null ? that.LAST_RCT_DT == null : this.LAST_RCT_DT.equals(that.LAST_RCT_DT));
    equal = equal && (this.FRS_RCTPE_ORG_CD == null ? that.FRS_RCTPE_ORG_CD == null : this.FRS_RCTPE_ORG_CD.equals(that.FRS_RCTPE_ORG_CD));
    equal = equal && (this.CTR_OBJ_ID == null ? that.CTR_OBJ_ID == null : this.CTR_OBJ_ID.equals(that.CTR_OBJ_ID));
    equal = equal && (this.DMPE_CUS_ID == null ? that.DMPE_CUS_ID == null : this.DMPE_CUS_ID.equals(that.DMPE_CUS_ID));
    equal = equal && (this.EIH_LDG_DTM == null ? that.EIH_LDG_DTM == null : this.EIH_LDG_DTM.equals(that.EIH_LDG_DTM));
    return equal;
  }
  public void readFields(ResultSet __dbResults) throws SQLException {
    this.__cur_result_set = __dbResults;
    this.STD_YYMM = JdbcWritableBridge.readString(1, __dbResults);
    this.ACD_NO_YY = JdbcWritableBridge.readString(2, __dbResults);
    this.ACD_NO_SEQ = JdbcWritableBridge.readBigDecimal(3, __dbResults);
    this.POL_NO = JdbcWritableBridge.readString(4, __dbResults);
    this.CLM_TP_CD = JdbcWritableBridge.readString(5, __dbResults);
    this.DAM_ORD = JdbcWritableBridge.readBigDecimal(6, __dbResults);
    this.COV_CD = JdbcWritableBridge.readString(7, __dbResults);
    this.ORIG_INS_AMT = JdbcWritableBridge.readBigDecimal(8, __dbResults);
    this.ORIG_OS_INS_AMT = JdbcWritableBridge.readBigDecimal(9, __dbResults);
    this.PRPD_ORIG_OINS_AMT = JdbcWritableBridge.readBigDecimal(10, __dbResults);
    this.ORIG_DMG_AMT = JdbcWritableBridge.readBigDecimal(11, __dbResults);
    this.PSSE_INS_AMT = JdbcWritableBridge.readBigDecimal(12, __dbResults);
    this.PSSE_OINS_AMT = JdbcWritableBridge.readBigDecimal(13, __dbResults);
    this.PRPD_PSSE_OINS_AMT = JdbcWritableBridge.readBigDecimal(14, __dbResults);
    this.PSSE_DMG_AMT = JdbcWritableBridge.readBigDecimal(15, __dbResults);
    this.ADD_PCS_YN = JdbcWritableBridge.readString(16, __dbResults);
    this.ACD_RCT_PTH_CD = JdbcWritableBridge.readString(17, __dbResults);
    this.UNT_PD_CD = JdbcWritableBridge.readString(18, __dbResults);
    this.SBCP_DT = JdbcWritableBridge.readTimestamp(19, __dbResults);
    this.TACD_DMPE_JOB_CD = JdbcWritableBridge.readString(20, __dbResults);
    this.TACD_DMPE_JOB_GRD_CD = JdbcWritableBridge.readString(21, __dbResults);
    this.TACD_DMPE_GNDR_CD = JdbcWritableBridge.readString(22, __dbResults);
    this.TACD_DMPE_AGE = JdbcWritableBridge.readBigDecimal(23, __dbResults);
    this.ACD_DT = JdbcWritableBridge.readTimestamp(24, __dbResults);
    this.ACD_DT_HOLI_YN = JdbcWritableBridge.readString(25, __dbResults);
    this.ACD_PLC_ZPCD = JdbcWritableBridge.readString(26, __dbResults);
    this.ACD_PLC_SIDO_CD = JdbcWritableBridge.readString(27, __dbResults);
    this.ACD_CAUS_LCTG_CD = JdbcWritableBridge.readString(28, __dbResults);
    this.ACD_CAUS_MCTG_CD = JdbcWritableBridge.readString(29, __dbResults);
    this.ACD_CAUS_SCTG_CD = JdbcWritableBridge.readString(30, __dbResults);
    this.OVSE_MET_YN = JdbcWritableBridge.readString(31, __dbResults);
    this.KR_DISZ_CD = JdbcWritableBridge.readString(32, __dbResults);
    this.RCPR_INST_CD = JdbcWritableBridge.readString(33, __dbResults);
    this.HSP_DD_NUM = JdbcWritableBridge.readBigDecimal(34, __dbResults);
    this.GHR_DD_NUM = JdbcWritableBridge.readBigDecimal(35, __dbResults);
    this.PSC_DD_NUM = JdbcWritableBridge.readBigDecimal(36, __dbResults);
    this.DDPY_DD_NUM = JdbcWritableBridge.readBigDecimal(37, __dbResults);
    this.OBST_RT = JdbcWritableBridge.readBigDecimal(38, __dbResults);
    this.DTH_DT = JdbcWritableBridge.readTimestamp(39, __dbResults);
    this.DMG_RDUC_AMT = JdbcWritableBridge.readBigDecimal(40, __dbResults);
    this.CLADJ_DAMR_LCTG_CD = JdbcWritableBridge.readString(41, __dbResults);
    this.CLADJ_DAMR_MCTG_CD = JdbcWritableBridge.readString(42, __dbResults);
    this.SIU_SVY_RQS_YN = JdbcWritableBridge.readString(43, __dbResults);
    this.DAMR_GRDE_CD = JdbcWritableBridge.readString(44, __dbResults);
    this.DLG_YN = JdbcWritableBridge.readString(45, __dbResults);
    this.DLG_CON_CD_NM = JdbcWritableBridge.readString(46, __dbResults);
    this.DLG_CO_NM = JdbcWritableBridge.readString(47, __dbResults);
    this.SVY_INST_NM = JdbcWritableBridge.readString(48, __dbResults);
    this.TRT_HDQT_ORG_CD = JdbcWritableBridge.readString(49, __dbResults);
    this.TRT_BRCH_ORG_CD = JdbcWritableBridge.readString(50, __dbResults);
    this.TRT_BCH_ORG_CD = JdbcWritableBridge.readString(51, __dbResults);
    this.TRTPE_ORG_CD = JdbcWritableBridge.readString(52, __dbResults);
    this.PCS_COMS_TEM_ORG_CD = JdbcWritableBridge.readString(53, __dbResults);
    this.PCS_COMS_PART_ORG_CD = JdbcWritableBridge.readString(54, __dbResults);
    this.CHRPE_ORG_CD = JdbcWritableBridge.readString(55, __dbResults);
    this.RCT_DT = JdbcWritableBridge.readTimestamp(56, __dbResults);
    this.FRS_OS_DT = JdbcWritableBridge.readTimestamp(57, __dbResults);
    this.LAST_OS_DT = JdbcWritableBridge.readTimestamp(58, __dbResults);
    this.APVL_DT = JdbcWritableBridge.readTimestamp(59, __dbResults);
    this.LAST_RCT_DT = JdbcWritableBridge.readTimestamp(60, __dbResults);
    this.FRS_RCTPE_ORG_CD = JdbcWritableBridge.readString(61, __dbResults);
    this.CTR_OBJ_ID = JdbcWritableBridge.readString(62, __dbResults);
    this.DMPE_CUS_ID = JdbcWritableBridge.readString(63, __dbResults);
    this.EIH_LDG_DTM = JdbcWritableBridge.readTimestamp(64, __dbResults);
  }
  public void readFields0(ResultSet __dbResults) throws SQLException {
    this.STD_YYMM = JdbcWritableBridge.readString(1, __dbResults);
    this.ACD_NO_YY = JdbcWritableBridge.readString(2, __dbResults);
    this.ACD_NO_SEQ = JdbcWritableBridge.readBigDecimal(3, __dbResults);
    this.POL_NO = JdbcWritableBridge.readString(4, __dbResults);
    this.CLM_TP_CD = JdbcWritableBridge.readString(5, __dbResults);
    this.DAM_ORD = JdbcWritableBridge.readBigDecimal(6, __dbResults);
    this.COV_CD = JdbcWritableBridge.readString(7, __dbResults);
    this.ORIG_INS_AMT = JdbcWritableBridge.readBigDecimal(8, __dbResults);
    this.ORIG_OS_INS_AMT = JdbcWritableBridge.readBigDecimal(9, __dbResults);
    this.PRPD_ORIG_OINS_AMT = JdbcWritableBridge.readBigDecimal(10, __dbResults);
    this.ORIG_DMG_AMT = JdbcWritableBridge.readBigDecimal(11, __dbResults);
    this.PSSE_INS_AMT = JdbcWritableBridge.readBigDecimal(12, __dbResults);
    this.PSSE_OINS_AMT = JdbcWritableBridge.readBigDecimal(13, __dbResults);
    this.PRPD_PSSE_OINS_AMT = JdbcWritableBridge.readBigDecimal(14, __dbResults);
    this.PSSE_DMG_AMT = JdbcWritableBridge.readBigDecimal(15, __dbResults);
    this.ADD_PCS_YN = JdbcWritableBridge.readString(16, __dbResults);
    this.ACD_RCT_PTH_CD = JdbcWritableBridge.readString(17, __dbResults);
    this.UNT_PD_CD = JdbcWritableBridge.readString(18, __dbResults);
    this.SBCP_DT = JdbcWritableBridge.readTimestamp(19, __dbResults);
    this.TACD_DMPE_JOB_CD = JdbcWritableBridge.readString(20, __dbResults);
    this.TACD_DMPE_JOB_GRD_CD = JdbcWritableBridge.readString(21, __dbResults);
    this.TACD_DMPE_GNDR_CD = JdbcWritableBridge.readString(22, __dbResults);
    this.TACD_DMPE_AGE = JdbcWritableBridge.readBigDecimal(23, __dbResults);
    this.ACD_DT = JdbcWritableBridge.readTimestamp(24, __dbResults);
    this.ACD_DT_HOLI_YN = JdbcWritableBridge.readString(25, __dbResults);
    this.ACD_PLC_ZPCD = JdbcWritableBridge.readString(26, __dbResults);
    this.ACD_PLC_SIDO_CD = JdbcWritableBridge.readString(27, __dbResults);
    this.ACD_CAUS_LCTG_CD = JdbcWritableBridge.readString(28, __dbResults);
    this.ACD_CAUS_MCTG_CD = JdbcWritableBridge.readString(29, __dbResults);
    this.ACD_CAUS_SCTG_CD = JdbcWritableBridge.readString(30, __dbResults);
    this.OVSE_MET_YN = JdbcWritableBridge.readString(31, __dbResults);
    this.KR_DISZ_CD = JdbcWritableBridge.readString(32, __dbResults);
    this.RCPR_INST_CD = JdbcWritableBridge.readString(33, __dbResults);
    this.HSP_DD_NUM = JdbcWritableBridge.readBigDecimal(34, __dbResults);
    this.GHR_DD_NUM = JdbcWritableBridge.readBigDecimal(35, __dbResults);
    this.PSC_DD_NUM = JdbcWritableBridge.readBigDecimal(36, __dbResults);
    this.DDPY_DD_NUM = JdbcWritableBridge.readBigDecimal(37, __dbResults);
    this.OBST_RT = JdbcWritableBridge.readBigDecimal(38, __dbResults);
    this.DTH_DT = JdbcWritableBridge.readTimestamp(39, __dbResults);
    this.DMG_RDUC_AMT = JdbcWritableBridge.readBigDecimal(40, __dbResults);
    this.CLADJ_DAMR_LCTG_CD = JdbcWritableBridge.readString(41, __dbResults);
    this.CLADJ_DAMR_MCTG_CD = JdbcWritableBridge.readString(42, __dbResults);
    this.SIU_SVY_RQS_YN = JdbcWritableBridge.readString(43, __dbResults);
    this.DAMR_GRDE_CD = JdbcWritableBridge.readString(44, __dbResults);
    this.DLG_YN = JdbcWritableBridge.readString(45, __dbResults);
    this.DLG_CON_CD_NM = JdbcWritableBridge.readString(46, __dbResults);
    this.DLG_CO_NM = JdbcWritableBridge.readString(47, __dbResults);
    this.SVY_INST_NM = JdbcWritableBridge.readString(48, __dbResults);
    this.TRT_HDQT_ORG_CD = JdbcWritableBridge.readString(49, __dbResults);
    this.TRT_BRCH_ORG_CD = JdbcWritableBridge.readString(50, __dbResults);
    this.TRT_BCH_ORG_CD = JdbcWritableBridge.readString(51, __dbResults);
    this.TRTPE_ORG_CD = JdbcWritableBridge.readString(52, __dbResults);
    this.PCS_COMS_TEM_ORG_CD = JdbcWritableBridge.readString(53, __dbResults);
    this.PCS_COMS_PART_ORG_CD = JdbcWritableBridge.readString(54, __dbResults);
    this.CHRPE_ORG_CD = JdbcWritableBridge.readString(55, __dbResults);
    this.RCT_DT = JdbcWritableBridge.readTimestamp(56, __dbResults);
    this.FRS_OS_DT = JdbcWritableBridge.readTimestamp(57, __dbResults);
    this.LAST_OS_DT = JdbcWritableBridge.readTimestamp(58, __dbResults);
    this.APVL_DT = JdbcWritableBridge.readTimestamp(59, __dbResults);
    this.LAST_RCT_DT = JdbcWritableBridge.readTimestamp(60, __dbResults);
    this.FRS_RCTPE_ORG_CD = JdbcWritableBridge.readString(61, __dbResults);
    this.CTR_OBJ_ID = JdbcWritableBridge.readString(62, __dbResults);
    this.DMPE_CUS_ID = JdbcWritableBridge.readString(63, __dbResults);
    this.EIH_LDG_DTM = JdbcWritableBridge.readTimestamp(64, __dbResults);
  }
  public void loadLargeObjects(LargeObjectLoader __loader)
      throws SQLException, IOException, InterruptedException {
  }
  public void loadLargeObjects0(LargeObjectLoader __loader)
      throws SQLException, IOException, InterruptedException {
  }
  public void write(PreparedStatement __dbStmt) throws SQLException {
    write(__dbStmt, 0);
  }

  public int write(PreparedStatement __dbStmt, int __off) throws SQLException {
    JdbcWritableBridge.writeString(STD_YYMM, 1 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(ACD_NO_YY, 2 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(ACD_NO_SEQ, 3 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(POL_NO, 4 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(CLM_TP_CD, 5 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(DAM_ORD, 6 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(COV_CD, 7 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(ORIG_INS_AMT, 8 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(ORIG_OS_INS_AMT, 9 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(PRPD_ORIG_OINS_AMT, 10 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(ORIG_DMG_AMT, 11 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(PSSE_INS_AMT, 12 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(PSSE_OINS_AMT, 13 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(PRPD_PSSE_OINS_AMT, 14 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(PSSE_DMG_AMT, 15 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(ADD_PCS_YN, 16 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(ACD_RCT_PTH_CD, 17 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(UNT_PD_CD, 18 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeTimestamp(SBCP_DT, 19 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeString(TACD_DMPE_JOB_CD, 20 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(TACD_DMPE_JOB_GRD_CD, 21 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(TACD_DMPE_GNDR_CD, 22 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(TACD_DMPE_AGE, 23 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeTimestamp(ACD_DT, 24 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeString(ACD_DT_HOLI_YN, 25 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(ACD_PLC_ZPCD, 26 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(ACD_PLC_SIDO_CD, 27 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(ACD_CAUS_LCTG_CD, 28 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(ACD_CAUS_MCTG_CD, 29 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(ACD_CAUS_SCTG_CD, 30 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(OVSE_MET_YN, 31 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(KR_DISZ_CD, 32 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(RCPR_INST_CD, 33 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(HSP_DD_NUM, 34 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(GHR_DD_NUM, 35 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(PSC_DD_NUM, 36 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(DDPY_DD_NUM, 37 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(OBST_RT, 38 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeTimestamp(DTH_DT, 39 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(DMG_RDUC_AMT, 40 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(CLADJ_DAMR_LCTG_CD, 41 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(CLADJ_DAMR_MCTG_CD, 42 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(SIU_SVY_RQS_YN, 43 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(DAMR_GRDE_CD, 44 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(DLG_YN, 45 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(DLG_CON_CD_NM, 46 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(DLG_CO_NM, 47 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(SVY_INST_NM, 48 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(TRT_HDQT_ORG_CD, 49 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(TRT_BRCH_ORG_CD, 50 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(TRT_BCH_ORG_CD, 51 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(TRTPE_ORG_CD, 52 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(PCS_COMS_TEM_ORG_CD, 53 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(PCS_COMS_PART_ORG_CD, 54 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(CHRPE_ORG_CD, 55 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeTimestamp(RCT_DT, 56 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeTimestamp(FRS_OS_DT, 57 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeTimestamp(LAST_OS_DT, 58 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeTimestamp(APVL_DT, 59 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeTimestamp(LAST_RCT_DT, 60 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeString(FRS_RCTPE_ORG_CD, 61 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(CTR_OBJ_ID, 62 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(DMPE_CUS_ID, 63 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeTimestamp(EIH_LDG_DTM, 64 + __off, 93, __dbStmt);
    return 64;
  }
  public void write0(PreparedStatement __dbStmt, int __off) throws SQLException {
    JdbcWritableBridge.writeString(STD_YYMM, 1 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(ACD_NO_YY, 2 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(ACD_NO_SEQ, 3 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(POL_NO, 4 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(CLM_TP_CD, 5 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(DAM_ORD, 6 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(COV_CD, 7 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(ORIG_INS_AMT, 8 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(ORIG_OS_INS_AMT, 9 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(PRPD_ORIG_OINS_AMT, 10 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(ORIG_DMG_AMT, 11 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(PSSE_INS_AMT, 12 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(PSSE_OINS_AMT, 13 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(PRPD_PSSE_OINS_AMT, 14 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(PSSE_DMG_AMT, 15 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(ADD_PCS_YN, 16 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(ACD_RCT_PTH_CD, 17 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(UNT_PD_CD, 18 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeTimestamp(SBCP_DT, 19 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeString(TACD_DMPE_JOB_CD, 20 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(TACD_DMPE_JOB_GRD_CD, 21 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(TACD_DMPE_GNDR_CD, 22 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(TACD_DMPE_AGE, 23 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeTimestamp(ACD_DT, 24 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeString(ACD_DT_HOLI_YN, 25 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(ACD_PLC_ZPCD, 26 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(ACD_PLC_SIDO_CD, 27 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(ACD_CAUS_LCTG_CD, 28 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(ACD_CAUS_MCTG_CD, 29 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(ACD_CAUS_SCTG_CD, 30 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(OVSE_MET_YN, 31 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(KR_DISZ_CD, 32 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(RCPR_INST_CD, 33 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(HSP_DD_NUM, 34 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(GHR_DD_NUM, 35 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(PSC_DD_NUM, 36 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(DDPY_DD_NUM, 37 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(OBST_RT, 38 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeTimestamp(DTH_DT, 39 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(DMG_RDUC_AMT, 40 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(CLADJ_DAMR_LCTG_CD, 41 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(CLADJ_DAMR_MCTG_CD, 42 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(SIU_SVY_RQS_YN, 43 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(DAMR_GRDE_CD, 44 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(DLG_YN, 45 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(DLG_CON_CD_NM, 46 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(DLG_CO_NM, 47 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(SVY_INST_NM, 48 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(TRT_HDQT_ORG_CD, 49 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(TRT_BRCH_ORG_CD, 50 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(TRT_BCH_ORG_CD, 51 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(TRTPE_ORG_CD, 52 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(PCS_COMS_TEM_ORG_CD, 53 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(PCS_COMS_PART_ORG_CD, 54 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(CHRPE_ORG_CD, 55 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeTimestamp(RCT_DT, 56 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeTimestamp(FRS_OS_DT, 57 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeTimestamp(LAST_OS_DT, 58 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeTimestamp(APVL_DT, 59 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeTimestamp(LAST_RCT_DT, 60 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeString(FRS_RCTPE_ORG_CD, 61 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(CTR_OBJ_ID, 62 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(DMPE_CUS_ID, 63 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeTimestamp(EIH_LDG_DTM, 64 + __off, 93, __dbStmt);
  }
  public void readFields(DataInput __dataIn) throws IOException {
this.readFields0(__dataIn);  }
  public void readFields0(DataInput __dataIn) throws IOException {
    if (__dataIn.readBoolean()) { 
        this.STD_YYMM = null;
    } else {
    this.STD_YYMM = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.ACD_NO_YY = null;
    } else {
    this.ACD_NO_YY = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.ACD_NO_SEQ = null;
    } else {
    this.ACD_NO_SEQ = com.cloudera.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.POL_NO = null;
    } else {
    this.POL_NO = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.CLM_TP_CD = null;
    } else {
    this.CLM_TP_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.DAM_ORD = null;
    } else {
    this.DAM_ORD = com.cloudera.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.COV_CD = null;
    } else {
    this.COV_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.ORIG_INS_AMT = null;
    } else {
    this.ORIG_INS_AMT = com.cloudera.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.ORIG_OS_INS_AMT = null;
    } else {
    this.ORIG_OS_INS_AMT = com.cloudera.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.PRPD_ORIG_OINS_AMT = null;
    } else {
    this.PRPD_ORIG_OINS_AMT = com.cloudera.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.ORIG_DMG_AMT = null;
    } else {
    this.ORIG_DMG_AMT = com.cloudera.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.PSSE_INS_AMT = null;
    } else {
    this.PSSE_INS_AMT = com.cloudera.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.PSSE_OINS_AMT = null;
    } else {
    this.PSSE_OINS_AMT = com.cloudera.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.PRPD_PSSE_OINS_AMT = null;
    } else {
    this.PRPD_PSSE_OINS_AMT = com.cloudera.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.PSSE_DMG_AMT = null;
    } else {
    this.PSSE_DMG_AMT = com.cloudera.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.ADD_PCS_YN = null;
    } else {
    this.ADD_PCS_YN = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.ACD_RCT_PTH_CD = null;
    } else {
    this.ACD_RCT_PTH_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.UNT_PD_CD = null;
    } else {
    this.UNT_PD_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.SBCP_DT = null;
    } else {
    this.SBCP_DT = new Timestamp(__dataIn.readLong());
    this.SBCP_DT.setNanos(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.TACD_DMPE_JOB_CD = null;
    } else {
    this.TACD_DMPE_JOB_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.TACD_DMPE_JOB_GRD_CD = null;
    } else {
    this.TACD_DMPE_JOB_GRD_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.TACD_DMPE_GNDR_CD = null;
    } else {
    this.TACD_DMPE_GNDR_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.TACD_DMPE_AGE = null;
    } else {
    this.TACD_DMPE_AGE = com.cloudera.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.ACD_DT = null;
    } else {
    this.ACD_DT = new Timestamp(__dataIn.readLong());
    this.ACD_DT.setNanos(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.ACD_DT_HOLI_YN = null;
    } else {
    this.ACD_DT_HOLI_YN = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.ACD_PLC_ZPCD = null;
    } else {
    this.ACD_PLC_ZPCD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.ACD_PLC_SIDO_CD = null;
    } else {
    this.ACD_PLC_SIDO_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.ACD_CAUS_LCTG_CD = null;
    } else {
    this.ACD_CAUS_LCTG_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.ACD_CAUS_MCTG_CD = null;
    } else {
    this.ACD_CAUS_MCTG_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.ACD_CAUS_SCTG_CD = null;
    } else {
    this.ACD_CAUS_SCTG_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.OVSE_MET_YN = null;
    } else {
    this.OVSE_MET_YN = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.KR_DISZ_CD = null;
    } else {
    this.KR_DISZ_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RCPR_INST_CD = null;
    } else {
    this.RCPR_INST_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.HSP_DD_NUM = null;
    } else {
    this.HSP_DD_NUM = com.cloudera.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.GHR_DD_NUM = null;
    } else {
    this.GHR_DD_NUM = com.cloudera.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.PSC_DD_NUM = null;
    } else {
    this.PSC_DD_NUM = com.cloudera.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.DDPY_DD_NUM = null;
    } else {
    this.DDPY_DD_NUM = com.cloudera.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.OBST_RT = null;
    } else {
    this.OBST_RT = com.cloudera.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.DTH_DT = null;
    } else {
    this.DTH_DT = new Timestamp(__dataIn.readLong());
    this.DTH_DT.setNanos(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.DMG_RDUC_AMT = null;
    } else {
    this.DMG_RDUC_AMT = com.cloudera.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.CLADJ_DAMR_LCTG_CD = null;
    } else {
    this.CLADJ_DAMR_LCTG_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.CLADJ_DAMR_MCTG_CD = null;
    } else {
    this.CLADJ_DAMR_MCTG_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.SIU_SVY_RQS_YN = null;
    } else {
    this.SIU_SVY_RQS_YN = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.DAMR_GRDE_CD = null;
    } else {
    this.DAMR_GRDE_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.DLG_YN = null;
    } else {
    this.DLG_YN = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.DLG_CON_CD_NM = null;
    } else {
    this.DLG_CON_CD_NM = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.DLG_CO_NM = null;
    } else {
    this.DLG_CO_NM = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.SVY_INST_NM = null;
    } else {
    this.SVY_INST_NM = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.TRT_HDQT_ORG_CD = null;
    } else {
    this.TRT_HDQT_ORG_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.TRT_BRCH_ORG_CD = null;
    } else {
    this.TRT_BRCH_ORG_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.TRT_BCH_ORG_CD = null;
    } else {
    this.TRT_BCH_ORG_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.TRTPE_ORG_CD = null;
    } else {
    this.TRTPE_ORG_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.PCS_COMS_TEM_ORG_CD = null;
    } else {
    this.PCS_COMS_TEM_ORG_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.PCS_COMS_PART_ORG_CD = null;
    } else {
    this.PCS_COMS_PART_ORG_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.CHRPE_ORG_CD = null;
    } else {
    this.CHRPE_ORG_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RCT_DT = null;
    } else {
    this.RCT_DT = new Timestamp(__dataIn.readLong());
    this.RCT_DT.setNanos(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.FRS_OS_DT = null;
    } else {
    this.FRS_OS_DT = new Timestamp(__dataIn.readLong());
    this.FRS_OS_DT.setNanos(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.LAST_OS_DT = null;
    } else {
    this.LAST_OS_DT = new Timestamp(__dataIn.readLong());
    this.LAST_OS_DT.setNanos(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.APVL_DT = null;
    } else {
    this.APVL_DT = new Timestamp(__dataIn.readLong());
    this.APVL_DT.setNanos(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.LAST_RCT_DT = null;
    } else {
    this.LAST_RCT_DT = new Timestamp(__dataIn.readLong());
    this.LAST_RCT_DT.setNanos(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.FRS_RCTPE_ORG_CD = null;
    } else {
    this.FRS_RCTPE_ORG_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.CTR_OBJ_ID = null;
    } else {
    this.CTR_OBJ_ID = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.DMPE_CUS_ID = null;
    } else {
    this.DMPE_CUS_ID = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.EIH_LDG_DTM = null;
    } else {
    this.EIH_LDG_DTM = new Timestamp(__dataIn.readLong());
    this.EIH_LDG_DTM.setNanos(__dataIn.readInt());
    }
  }
  public void write(DataOutput __dataOut) throws IOException {
    if (null == this.STD_YYMM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, STD_YYMM);
    }
    if (null == this.ACD_NO_YY) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ACD_NO_YY);
    }
    if (null == this.ACD_NO_SEQ) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.ACD_NO_SEQ, __dataOut);
    }
    if (null == this.POL_NO) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, POL_NO);
    }
    if (null == this.CLM_TP_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CLM_TP_CD);
    }
    if (null == this.DAM_ORD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.DAM_ORD, __dataOut);
    }
    if (null == this.COV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, COV_CD);
    }
    if (null == this.ORIG_INS_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.ORIG_INS_AMT, __dataOut);
    }
    if (null == this.ORIG_OS_INS_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.ORIG_OS_INS_AMT, __dataOut);
    }
    if (null == this.PRPD_ORIG_OINS_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.PRPD_ORIG_OINS_AMT, __dataOut);
    }
    if (null == this.ORIG_DMG_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.ORIG_DMG_AMT, __dataOut);
    }
    if (null == this.PSSE_INS_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.PSSE_INS_AMT, __dataOut);
    }
    if (null == this.PSSE_OINS_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.PSSE_OINS_AMT, __dataOut);
    }
    if (null == this.PRPD_PSSE_OINS_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.PRPD_PSSE_OINS_AMT, __dataOut);
    }
    if (null == this.PSSE_DMG_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.PSSE_DMG_AMT, __dataOut);
    }
    if (null == this.ADD_PCS_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ADD_PCS_YN);
    }
    if (null == this.ACD_RCT_PTH_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ACD_RCT_PTH_CD);
    }
    if (null == this.UNT_PD_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, UNT_PD_CD);
    }
    if (null == this.SBCP_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.SBCP_DT.getTime());
    __dataOut.writeInt(this.SBCP_DT.getNanos());
    }
    if (null == this.TACD_DMPE_JOB_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, TACD_DMPE_JOB_CD);
    }
    if (null == this.TACD_DMPE_JOB_GRD_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, TACD_DMPE_JOB_GRD_CD);
    }
    if (null == this.TACD_DMPE_GNDR_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, TACD_DMPE_GNDR_CD);
    }
    if (null == this.TACD_DMPE_AGE) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.TACD_DMPE_AGE, __dataOut);
    }
    if (null == this.ACD_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.ACD_DT.getTime());
    __dataOut.writeInt(this.ACD_DT.getNanos());
    }
    if (null == this.ACD_DT_HOLI_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ACD_DT_HOLI_YN);
    }
    if (null == this.ACD_PLC_ZPCD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ACD_PLC_ZPCD);
    }
    if (null == this.ACD_PLC_SIDO_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ACD_PLC_SIDO_CD);
    }
    if (null == this.ACD_CAUS_LCTG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ACD_CAUS_LCTG_CD);
    }
    if (null == this.ACD_CAUS_MCTG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ACD_CAUS_MCTG_CD);
    }
    if (null == this.ACD_CAUS_SCTG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ACD_CAUS_SCTG_CD);
    }
    if (null == this.OVSE_MET_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, OVSE_MET_YN);
    }
    if (null == this.KR_DISZ_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, KR_DISZ_CD);
    }
    if (null == this.RCPR_INST_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RCPR_INST_CD);
    }
    if (null == this.HSP_DD_NUM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.HSP_DD_NUM, __dataOut);
    }
    if (null == this.GHR_DD_NUM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.GHR_DD_NUM, __dataOut);
    }
    if (null == this.PSC_DD_NUM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.PSC_DD_NUM, __dataOut);
    }
    if (null == this.DDPY_DD_NUM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.DDPY_DD_NUM, __dataOut);
    }
    if (null == this.OBST_RT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.OBST_RT, __dataOut);
    }
    if (null == this.DTH_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.DTH_DT.getTime());
    __dataOut.writeInt(this.DTH_DT.getNanos());
    }
    if (null == this.DMG_RDUC_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.DMG_RDUC_AMT, __dataOut);
    }
    if (null == this.CLADJ_DAMR_LCTG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CLADJ_DAMR_LCTG_CD);
    }
    if (null == this.CLADJ_DAMR_MCTG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CLADJ_DAMR_MCTG_CD);
    }
    if (null == this.SIU_SVY_RQS_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, SIU_SVY_RQS_YN);
    }
    if (null == this.DAMR_GRDE_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, DAMR_GRDE_CD);
    }
    if (null == this.DLG_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, DLG_YN);
    }
    if (null == this.DLG_CON_CD_NM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, DLG_CON_CD_NM);
    }
    if (null == this.DLG_CO_NM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, DLG_CO_NM);
    }
    if (null == this.SVY_INST_NM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, SVY_INST_NM);
    }
    if (null == this.TRT_HDQT_ORG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, TRT_HDQT_ORG_CD);
    }
    if (null == this.TRT_BRCH_ORG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, TRT_BRCH_ORG_CD);
    }
    if (null == this.TRT_BCH_ORG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, TRT_BCH_ORG_CD);
    }
    if (null == this.TRTPE_ORG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, TRTPE_ORG_CD);
    }
    if (null == this.PCS_COMS_TEM_ORG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, PCS_COMS_TEM_ORG_CD);
    }
    if (null == this.PCS_COMS_PART_ORG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, PCS_COMS_PART_ORG_CD);
    }
    if (null == this.CHRPE_ORG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CHRPE_ORG_CD);
    }
    if (null == this.RCT_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.RCT_DT.getTime());
    __dataOut.writeInt(this.RCT_DT.getNanos());
    }
    if (null == this.FRS_OS_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.FRS_OS_DT.getTime());
    __dataOut.writeInt(this.FRS_OS_DT.getNanos());
    }
    if (null == this.LAST_OS_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.LAST_OS_DT.getTime());
    __dataOut.writeInt(this.LAST_OS_DT.getNanos());
    }
    if (null == this.APVL_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.APVL_DT.getTime());
    __dataOut.writeInt(this.APVL_DT.getNanos());
    }
    if (null == this.LAST_RCT_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.LAST_RCT_DT.getTime());
    __dataOut.writeInt(this.LAST_RCT_DT.getNanos());
    }
    if (null == this.FRS_RCTPE_ORG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, FRS_RCTPE_ORG_CD);
    }
    if (null == this.CTR_OBJ_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CTR_OBJ_ID);
    }
    if (null == this.DMPE_CUS_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, DMPE_CUS_ID);
    }
    if (null == this.EIH_LDG_DTM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.EIH_LDG_DTM.getTime());
    __dataOut.writeInt(this.EIH_LDG_DTM.getNanos());
    }
  }
  public void write0(DataOutput __dataOut) throws IOException {
    if (null == this.STD_YYMM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, STD_YYMM);
    }
    if (null == this.ACD_NO_YY) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ACD_NO_YY);
    }
    if (null == this.ACD_NO_SEQ) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.ACD_NO_SEQ, __dataOut);
    }
    if (null == this.POL_NO) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, POL_NO);
    }
    if (null == this.CLM_TP_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CLM_TP_CD);
    }
    if (null == this.DAM_ORD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.DAM_ORD, __dataOut);
    }
    if (null == this.COV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, COV_CD);
    }
    if (null == this.ORIG_INS_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.ORIG_INS_AMT, __dataOut);
    }
    if (null == this.ORIG_OS_INS_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.ORIG_OS_INS_AMT, __dataOut);
    }
    if (null == this.PRPD_ORIG_OINS_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.PRPD_ORIG_OINS_AMT, __dataOut);
    }
    if (null == this.ORIG_DMG_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.ORIG_DMG_AMT, __dataOut);
    }
    if (null == this.PSSE_INS_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.PSSE_INS_AMT, __dataOut);
    }
    if (null == this.PSSE_OINS_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.PSSE_OINS_AMT, __dataOut);
    }
    if (null == this.PRPD_PSSE_OINS_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.PRPD_PSSE_OINS_AMT, __dataOut);
    }
    if (null == this.PSSE_DMG_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.PSSE_DMG_AMT, __dataOut);
    }
    if (null == this.ADD_PCS_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ADD_PCS_YN);
    }
    if (null == this.ACD_RCT_PTH_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ACD_RCT_PTH_CD);
    }
    if (null == this.UNT_PD_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, UNT_PD_CD);
    }
    if (null == this.SBCP_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.SBCP_DT.getTime());
    __dataOut.writeInt(this.SBCP_DT.getNanos());
    }
    if (null == this.TACD_DMPE_JOB_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, TACD_DMPE_JOB_CD);
    }
    if (null == this.TACD_DMPE_JOB_GRD_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, TACD_DMPE_JOB_GRD_CD);
    }
    if (null == this.TACD_DMPE_GNDR_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, TACD_DMPE_GNDR_CD);
    }
    if (null == this.TACD_DMPE_AGE) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.TACD_DMPE_AGE, __dataOut);
    }
    if (null == this.ACD_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.ACD_DT.getTime());
    __dataOut.writeInt(this.ACD_DT.getNanos());
    }
    if (null == this.ACD_DT_HOLI_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ACD_DT_HOLI_YN);
    }
    if (null == this.ACD_PLC_ZPCD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ACD_PLC_ZPCD);
    }
    if (null == this.ACD_PLC_SIDO_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ACD_PLC_SIDO_CD);
    }
    if (null == this.ACD_CAUS_LCTG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ACD_CAUS_LCTG_CD);
    }
    if (null == this.ACD_CAUS_MCTG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ACD_CAUS_MCTG_CD);
    }
    if (null == this.ACD_CAUS_SCTG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ACD_CAUS_SCTG_CD);
    }
    if (null == this.OVSE_MET_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, OVSE_MET_YN);
    }
    if (null == this.KR_DISZ_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, KR_DISZ_CD);
    }
    if (null == this.RCPR_INST_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RCPR_INST_CD);
    }
    if (null == this.HSP_DD_NUM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.HSP_DD_NUM, __dataOut);
    }
    if (null == this.GHR_DD_NUM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.GHR_DD_NUM, __dataOut);
    }
    if (null == this.PSC_DD_NUM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.PSC_DD_NUM, __dataOut);
    }
    if (null == this.DDPY_DD_NUM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.DDPY_DD_NUM, __dataOut);
    }
    if (null == this.OBST_RT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.OBST_RT, __dataOut);
    }
    if (null == this.DTH_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.DTH_DT.getTime());
    __dataOut.writeInt(this.DTH_DT.getNanos());
    }
    if (null == this.DMG_RDUC_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    com.cloudera.sqoop.lib.BigDecimalSerializer.write(this.DMG_RDUC_AMT, __dataOut);
    }
    if (null == this.CLADJ_DAMR_LCTG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CLADJ_DAMR_LCTG_CD);
    }
    if (null == this.CLADJ_DAMR_MCTG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CLADJ_DAMR_MCTG_CD);
    }
    if (null == this.SIU_SVY_RQS_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, SIU_SVY_RQS_YN);
    }
    if (null == this.DAMR_GRDE_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, DAMR_GRDE_CD);
    }
    if (null == this.DLG_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, DLG_YN);
    }
    if (null == this.DLG_CON_CD_NM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, DLG_CON_CD_NM);
    }
    if (null == this.DLG_CO_NM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, DLG_CO_NM);
    }
    if (null == this.SVY_INST_NM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, SVY_INST_NM);
    }
    if (null == this.TRT_HDQT_ORG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, TRT_HDQT_ORG_CD);
    }
    if (null == this.TRT_BRCH_ORG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, TRT_BRCH_ORG_CD);
    }
    if (null == this.TRT_BCH_ORG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, TRT_BCH_ORG_CD);
    }
    if (null == this.TRTPE_ORG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, TRTPE_ORG_CD);
    }
    if (null == this.PCS_COMS_TEM_ORG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, PCS_COMS_TEM_ORG_CD);
    }
    if (null == this.PCS_COMS_PART_ORG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, PCS_COMS_PART_ORG_CD);
    }
    if (null == this.CHRPE_ORG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CHRPE_ORG_CD);
    }
    if (null == this.RCT_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.RCT_DT.getTime());
    __dataOut.writeInt(this.RCT_DT.getNanos());
    }
    if (null == this.FRS_OS_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.FRS_OS_DT.getTime());
    __dataOut.writeInt(this.FRS_OS_DT.getNanos());
    }
    if (null == this.LAST_OS_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.LAST_OS_DT.getTime());
    __dataOut.writeInt(this.LAST_OS_DT.getNanos());
    }
    if (null == this.APVL_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.APVL_DT.getTime());
    __dataOut.writeInt(this.APVL_DT.getNanos());
    }
    if (null == this.LAST_RCT_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.LAST_RCT_DT.getTime());
    __dataOut.writeInt(this.LAST_RCT_DT.getNanos());
    }
    if (null == this.FRS_RCTPE_ORG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, FRS_RCTPE_ORG_CD);
    }
    if (null == this.CTR_OBJ_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CTR_OBJ_ID);
    }
    if (null == this.DMPE_CUS_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, DMPE_CUS_ID);
    }
    if (null == this.EIH_LDG_DTM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.EIH_LDG_DTM.getTime());
    __dataOut.writeInt(this.EIH_LDG_DTM.getNanos());
    }
  }
  private static final DelimiterSet __outputDelimiters = new DelimiterSet((char) 1, (char) 10, (char) 0, (char) 0, false);
  public String toString() {
    return toString(__outputDelimiters, true);
  }
  public String toString(DelimiterSet delimiters) {
    return toString(delimiters, true);
  }
  public String toString(boolean useRecordDelim) {
    return toString(__outputDelimiters, useRecordDelim);
  }
  public String toString(DelimiterSet delimiters, boolean useRecordDelim) {
    StringBuilder __sb = new StringBuilder();
    char fieldDelim = delimiters.getFieldsTerminatedBy();
    __sb.append(FieldFormatter.escapeAndEnclose(STD_YYMM==null?"null":STD_YYMM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ACD_NO_YY==null?"null":ACD_NO_YY, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ACD_NO_SEQ==null?"null":ACD_NO_SEQ.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(POL_NO==null?"null":POL_NO, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CLM_TP_CD==null?"null":CLM_TP_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DAM_ORD==null?"null":DAM_ORD.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(COV_CD==null?"null":COV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ORIG_INS_AMT==null?"null":ORIG_INS_AMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ORIG_OS_INS_AMT==null?"null":ORIG_OS_INS_AMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PRPD_ORIG_OINS_AMT==null?"null":PRPD_ORIG_OINS_AMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ORIG_DMG_AMT==null?"null":ORIG_DMG_AMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PSSE_INS_AMT==null?"null":PSSE_INS_AMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PSSE_OINS_AMT==null?"null":PSSE_OINS_AMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PRPD_PSSE_OINS_AMT==null?"null":PRPD_PSSE_OINS_AMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PSSE_DMG_AMT==null?"null":PSSE_DMG_AMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ADD_PCS_YN==null?"null":ADD_PCS_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ACD_RCT_PTH_CD==null?"null":ACD_RCT_PTH_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(UNT_PD_CD==null?"null":UNT_PD_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SBCP_DT==null?"null":"" + SBCP_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(TACD_DMPE_JOB_CD==null?"null":TACD_DMPE_JOB_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(TACD_DMPE_JOB_GRD_CD==null?"null":TACD_DMPE_JOB_GRD_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(TACD_DMPE_GNDR_CD==null?"null":TACD_DMPE_GNDR_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(TACD_DMPE_AGE==null?"null":TACD_DMPE_AGE.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ACD_DT==null?"null":"" + ACD_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ACD_DT_HOLI_YN==null?"null":ACD_DT_HOLI_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ACD_PLC_ZPCD==null?"null":ACD_PLC_ZPCD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ACD_PLC_SIDO_CD==null?"null":ACD_PLC_SIDO_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ACD_CAUS_LCTG_CD==null?"null":ACD_CAUS_LCTG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ACD_CAUS_MCTG_CD==null?"null":ACD_CAUS_MCTG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ACD_CAUS_SCTG_CD==null?"null":ACD_CAUS_SCTG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(OVSE_MET_YN==null?"null":OVSE_MET_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(KR_DISZ_CD==null?"null":KR_DISZ_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RCPR_INST_CD==null?"null":RCPR_INST_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(HSP_DD_NUM==null?"null":HSP_DD_NUM.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(GHR_DD_NUM==null?"null":GHR_DD_NUM.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PSC_DD_NUM==null?"null":PSC_DD_NUM.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DDPY_DD_NUM==null?"null":DDPY_DD_NUM.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(OBST_RT==null?"null":OBST_RT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DTH_DT==null?"null":"" + DTH_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DMG_RDUC_AMT==null?"null":DMG_RDUC_AMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CLADJ_DAMR_LCTG_CD==null?"null":CLADJ_DAMR_LCTG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CLADJ_DAMR_MCTG_CD==null?"null":CLADJ_DAMR_MCTG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SIU_SVY_RQS_YN==null?"null":SIU_SVY_RQS_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DAMR_GRDE_CD==null?"null":DAMR_GRDE_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DLG_YN==null?"null":DLG_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DLG_CON_CD_NM==null?"null":DLG_CON_CD_NM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DLG_CO_NM==null?"null":DLG_CO_NM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SVY_INST_NM==null?"null":SVY_INST_NM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(TRT_HDQT_ORG_CD==null?"null":TRT_HDQT_ORG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(TRT_BRCH_ORG_CD==null?"null":TRT_BRCH_ORG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(TRT_BCH_ORG_CD==null?"null":TRT_BCH_ORG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(TRTPE_ORG_CD==null?"null":TRTPE_ORG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PCS_COMS_TEM_ORG_CD==null?"null":PCS_COMS_TEM_ORG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PCS_COMS_PART_ORG_CD==null?"null":PCS_COMS_PART_ORG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CHRPE_ORG_CD==null?"null":CHRPE_ORG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RCT_DT==null?"null":"" + RCT_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(FRS_OS_DT==null?"null":"" + FRS_OS_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(LAST_OS_DT==null?"null":"" + LAST_OS_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(APVL_DT==null?"null":"" + APVL_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(LAST_RCT_DT==null?"null":"" + LAST_RCT_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(FRS_RCTPE_ORG_CD==null?"null":FRS_RCTPE_ORG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CTR_OBJ_ID==null?"null":CTR_OBJ_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DMPE_CUS_ID==null?"null":DMPE_CUS_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(EIH_LDG_DTM==null?"null":"" + EIH_LDG_DTM, delimiters));
    if (useRecordDelim) {
      __sb.append(delimiters.getLinesTerminatedBy());
    }
    return __sb.toString();
  }
  public void toString0(DelimiterSet delimiters, StringBuilder __sb, char fieldDelim) {
    __sb.append(FieldFormatter.escapeAndEnclose(STD_YYMM==null?"null":STD_YYMM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ACD_NO_YY==null?"null":ACD_NO_YY, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ACD_NO_SEQ==null?"null":ACD_NO_SEQ.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(POL_NO==null?"null":POL_NO, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CLM_TP_CD==null?"null":CLM_TP_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DAM_ORD==null?"null":DAM_ORD.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(COV_CD==null?"null":COV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ORIG_INS_AMT==null?"null":ORIG_INS_AMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ORIG_OS_INS_AMT==null?"null":ORIG_OS_INS_AMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PRPD_ORIG_OINS_AMT==null?"null":PRPD_ORIG_OINS_AMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ORIG_DMG_AMT==null?"null":ORIG_DMG_AMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PSSE_INS_AMT==null?"null":PSSE_INS_AMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PSSE_OINS_AMT==null?"null":PSSE_OINS_AMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PRPD_PSSE_OINS_AMT==null?"null":PRPD_PSSE_OINS_AMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PSSE_DMG_AMT==null?"null":PSSE_DMG_AMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ADD_PCS_YN==null?"null":ADD_PCS_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ACD_RCT_PTH_CD==null?"null":ACD_RCT_PTH_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(UNT_PD_CD==null?"null":UNT_PD_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SBCP_DT==null?"null":"" + SBCP_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(TACD_DMPE_JOB_CD==null?"null":TACD_DMPE_JOB_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(TACD_DMPE_JOB_GRD_CD==null?"null":TACD_DMPE_JOB_GRD_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(TACD_DMPE_GNDR_CD==null?"null":TACD_DMPE_GNDR_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(TACD_DMPE_AGE==null?"null":TACD_DMPE_AGE.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ACD_DT==null?"null":"" + ACD_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ACD_DT_HOLI_YN==null?"null":ACD_DT_HOLI_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ACD_PLC_ZPCD==null?"null":ACD_PLC_ZPCD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ACD_PLC_SIDO_CD==null?"null":ACD_PLC_SIDO_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ACD_CAUS_LCTG_CD==null?"null":ACD_CAUS_LCTG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ACD_CAUS_MCTG_CD==null?"null":ACD_CAUS_MCTG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ACD_CAUS_SCTG_CD==null?"null":ACD_CAUS_SCTG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(OVSE_MET_YN==null?"null":OVSE_MET_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(KR_DISZ_CD==null?"null":KR_DISZ_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RCPR_INST_CD==null?"null":RCPR_INST_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(HSP_DD_NUM==null?"null":HSP_DD_NUM.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(GHR_DD_NUM==null?"null":GHR_DD_NUM.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PSC_DD_NUM==null?"null":PSC_DD_NUM.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DDPY_DD_NUM==null?"null":DDPY_DD_NUM.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(OBST_RT==null?"null":OBST_RT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DTH_DT==null?"null":"" + DTH_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DMG_RDUC_AMT==null?"null":DMG_RDUC_AMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CLADJ_DAMR_LCTG_CD==null?"null":CLADJ_DAMR_LCTG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CLADJ_DAMR_MCTG_CD==null?"null":CLADJ_DAMR_MCTG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SIU_SVY_RQS_YN==null?"null":SIU_SVY_RQS_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DAMR_GRDE_CD==null?"null":DAMR_GRDE_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DLG_YN==null?"null":DLG_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DLG_CON_CD_NM==null?"null":DLG_CON_CD_NM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DLG_CO_NM==null?"null":DLG_CO_NM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SVY_INST_NM==null?"null":SVY_INST_NM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(TRT_HDQT_ORG_CD==null?"null":TRT_HDQT_ORG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(TRT_BRCH_ORG_CD==null?"null":TRT_BRCH_ORG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(TRT_BCH_ORG_CD==null?"null":TRT_BCH_ORG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(TRTPE_ORG_CD==null?"null":TRTPE_ORG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PCS_COMS_TEM_ORG_CD==null?"null":PCS_COMS_TEM_ORG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PCS_COMS_PART_ORG_CD==null?"null":PCS_COMS_PART_ORG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CHRPE_ORG_CD==null?"null":CHRPE_ORG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RCT_DT==null?"null":"" + RCT_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(FRS_OS_DT==null?"null":"" + FRS_OS_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(LAST_OS_DT==null?"null":"" + LAST_OS_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(APVL_DT==null?"null":"" + APVL_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(LAST_RCT_DT==null?"null":"" + LAST_RCT_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(FRS_RCTPE_ORG_CD==null?"null":FRS_RCTPE_ORG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CTR_OBJ_ID==null?"null":CTR_OBJ_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DMPE_CUS_ID==null?"null":DMPE_CUS_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(EIH_LDG_DTM==null?"null":"" + EIH_LDG_DTM, delimiters));
  }
  private static final DelimiterSet __inputDelimiters = new DelimiterSet((char) 1, (char) 10, (char) 0, (char) 0, false);
  private RecordParser __parser;
  public void parse(Text __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(CharSequence __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(byte [] __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(char [] __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(ByteBuffer __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(CharBuffer __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  private void __loadFromFields(List<String> fields) {
    Iterator<String> __it = fields.listIterator();
    String __cur_str = null;
    try {
    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.STD_YYMM = null; } else {
      this.STD_YYMM = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.ACD_NO_YY = null; } else {
      this.ACD_NO_YY = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.ACD_NO_SEQ = null; } else {
      this.ACD_NO_SEQ = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.POL_NO = null; } else {
      this.POL_NO = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.CLM_TP_CD = null; } else {
      this.CLM_TP_CD = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.DAM_ORD = null; } else {
      this.DAM_ORD = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.COV_CD = null; } else {
      this.COV_CD = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.ORIG_INS_AMT = null; } else {
      this.ORIG_INS_AMT = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.ORIG_OS_INS_AMT = null; } else {
      this.ORIG_OS_INS_AMT = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.PRPD_ORIG_OINS_AMT = null; } else {
      this.PRPD_ORIG_OINS_AMT = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.ORIG_DMG_AMT = null; } else {
      this.ORIG_DMG_AMT = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.PSSE_INS_AMT = null; } else {
      this.PSSE_INS_AMT = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.PSSE_OINS_AMT = null; } else {
      this.PSSE_OINS_AMT = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.PRPD_PSSE_OINS_AMT = null; } else {
      this.PRPD_PSSE_OINS_AMT = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.PSSE_DMG_AMT = null; } else {
      this.PSSE_DMG_AMT = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.ADD_PCS_YN = null; } else {
      this.ADD_PCS_YN = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.ACD_RCT_PTH_CD = null; } else {
      this.ACD_RCT_PTH_CD = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.UNT_PD_CD = null; } else {
      this.UNT_PD_CD = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.SBCP_DT = null; } else {
      this.SBCP_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.TACD_DMPE_JOB_CD = null; } else {
      this.TACD_DMPE_JOB_CD = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.TACD_DMPE_JOB_GRD_CD = null; } else {
      this.TACD_DMPE_JOB_GRD_CD = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.TACD_DMPE_GNDR_CD = null; } else {
      this.TACD_DMPE_GNDR_CD = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.TACD_DMPE_AGE = null; } else {
      this.TACD_DMPE_AGE = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.ACD_DT = null; } else {
      this.ACD_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.ACD_DT_HOLI_YN = null; } else {
      this.ACD_DT_HOLI_YN = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.ACD_PLC_ZPCD = null; } else {
      this.ACD_PLC_ZPCD = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.ACD_PLC_SIDO_CD = null; } else {
      this.ACD_PLC_SIDO_CD = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.ACD_CAUS_LCTG_CD = null; } else {
      this.ACD_CAUS_LCTG_CD = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.ACD_CAUS_MCTG_CD = null; } else {
      this.ACD_CAUS_MCTG_CD = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.ACD_CAUS_SCTG_CD = null; } else {
      this.ACD_CAUS_SCTG_CD = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.OVSE_MET_YN = null; } else {
      this.OVSE_MET_YN = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.KR_DISZ_CD = null; } else {
      this.KR_DISZ_CD = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.RCPR_INST_CD = null; } else {
      this.RCPR_INST_CD = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.HSP_DD_NUM = null; } else {
      this.HSP_DD_NUM = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.GHR_DD_NUM = null; } else {
      this.GHR_DD_NUM = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.PSC_DD_NUM = null; } else {
      this.PSC_DD_NUM = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.DDPY_DD_NUM = null; } else {
      this.DDPY_DD_NUM = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.OBST_RT = null; } else {
      this.OBST_RT = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.DTH_DT = null; } else {
      this.DTH_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.DMG_RDUC_AMT = null; } else {
      this.DMG_RDUC_AMT = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.CLADJ_DAMR_LCTG_CD = null; } else {
      this.CLADJ_DAMR_LCTG_CD = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.CLADJ_DAMR_MCTG_CD = null; } else {
      this.CLADJ_DAMR_MCTG_CD = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.SIU_SVY_RQS_YN = null; } else {
      this.SIU_SVY_RQS_YN = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.DAMR_GRDE_CD = null; } else {
      this.DAMR_GRDE_CD = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.DLG_YN = null; } else {
      this.DLG_YN = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.DLG_CON_CD_NM = null; } else {
      this.DLG_CON_CD_NM = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.DLG_CO_NM = null; } else {
      this.DLG_CO_NM = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.SVY_INST_NM = null; } else {
      this.SVY_INST_NM = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.TRT_HDQT_ORG_CD = null; } else {
      this.TRT_HDQT_ORG_CD = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.TRT_BRCH_ORG_CD = null; } else {
      this.TRT_BRCH_ORG_CD = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.TRT_BCH_ORG_CD = null; } else {
      this.TRT_BCH_ORG_CD = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.TRTPE_ORG_CD = null; } else {
      this.TRTPE_ORG_CD = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.PCS_COMS_TEM_ORG_CD = null; } else {
      this.PCS_COMS_TEM_ORG_CD = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.PCS_COMS_PART_ORG_CD = null; } else {
      this.PCS_COMS_PART_ORG_CD = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.CHRPE_ORG_CD = null; } else {
      this.CHRPE_ORG_CD = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RCT_DT = null; } else {
      this.RCT_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.FRS_OS_DT = null; } else {
      this.FRS_OS_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.LAST_OS_DT = null; } else {
      this.LAST_OS_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.APVL_DT = null; } else {
      this.APVL_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.LAST_RCT_DT = null; } else {
      this.LAST_RCT_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.FRS_RCTPE_ORG_CD = null; } else {
      this.FRS_RCTPE_ORG_CD = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.CTR_OBJ_ID = null; } else {
      this.CTR_OBJ_ID = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.DMPE_CUS_ID = null; } else {
      this.DMPE_CUS_ID = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.EIH_LDG_DTM = null; } else {
      this.EIH_LDG_DTM = java.sql.Timestamp.valueOf(__cur_str);
    }

    } catch (RuntimeException e) {    throw new RuntimeException("Can't parse input data: '" + __cur_str + "'", e);    }  }

  private void __loadFromFields0(Iterator<String> __it) {
    String __cur_str = null;
    try {
    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.STD_YYMM = null; } else {
      this.STD_YYMM = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.ACD_NO_YY = null; } else {
      this.ACD_NO_YY = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.ACD_NO_SEQ = null; } else {
      this.ACD_NO_SEQ = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.POL_NO = null; } else {
      this.POL_NO = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.CLM_TP_CD = null; } else {
      this.CLM_TP_CD = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.DAM_ORD = null; } else {
      this.DAM_ORD = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.COV_CD = null; } else {
      this.COV_CD = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.ORIG_INS_AMT = null; } else {
      this.ORIG_INS_AMT = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.ORIG_OS_INS_AMT = null; } else {
      this.ORIG_OS_INS_AMT = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.PRPD_ORIG_OINS_AMT = null; } else {
      this.PRPD_ORIG_OINS_AMT = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.ORIG_DMG_AMT = null; } else {
      this.ORIG_DMG_AMT = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.PSSE_INS_AMT = null; } else {
      this.PSSE_INS_AMT = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.PSSE_OINS_AMT = null; } else {
      this.PSSE_OINS_AMT = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.PRPD_PSSE_OINS_AMT = null; } else {
      this.PRPD_PSSE_OINS_AMT = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.PSSE_DMG_AMT = null; } else {
      this.PSSE_DMG_AMT = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.ADD_PCS_YN = null; } else {
      this.ADD_PCS_YN = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.ACD_RCT_PTH_CD = null; } else {
      this.ACD_RCT_PTH_CD = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.UNT_PD_CD = null; } else {
      this.UNT_PD_CD = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.SBCP_DT = null; } else {
      this.SBCP_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.TACD_DMPE_JOB_CD = null; } else {
      this.TACD_DMPE_JOB_CD = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.TACD_DMPE_JOB_GRD_CD = null; } else {
      this.TACD_DMPE_JOB_GRD_CD = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.TACD_DMPE_GNDR_CD = null; } else {
      this.TACD_DMPE_GNDR_CD = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.TACD_DMPE_AGE = null; } else {
      this.TACD_DMPE_AGE = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.ACD_DT = null; } else {
      this.ACD_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.ACD_DT_HOLI_YN = null; } else {
      this.ACD_DT_HOLI_YN = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.ACD_PLC_ZPCD = null; } else {
      this.ACD_PLC_ZPCD = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.ACD_PLC_SIDO_CD = null; } else {
      this.ACD_PLC_SIDO_CD = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.ACD_CAUS_LCTG_CD = null; } else {
      this.ACD_CAUS_LCTG_CD = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.ACD_CAUS_MCTG_CD = null; } else {
      this.ACD_CAUS_MCTG_CD = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.ACD_CAUS_SCTG_CD = null; } else {
      this.ACD_CAUS_SCTG_CD = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.OVSE_MET_YN = null; } else {
      this.OVSE_MET_YN = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.KR_DISZ_CD = null; } else {
      this.KR_DISZ_CD = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.RCPR_INST_CD = null; } else {
      this.RCPR_INST_CD = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.HSP_DD_NUM = null; } else {
      this.HSP_DD_NUM = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.GHR_DD_NUM = null; } else {
      this.GHR_DD_NUM = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.PSC_DD_NUM = null; } else {
      this.PSC_DD_NUM = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.DDPY_DD_NUM = null; } else {
      this.DDPY_DD_NUM = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.OBST_RT = null; } else {
      this.OBST_RT = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.DTH_DT = null; } else {
      this.DTH_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.DMG_RDUC_AMT = null; } else {
      this.DMG_RDUC_AMT = new java.math.BigDecimal(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.CLADJ_DAMR_LCTG_CD = null; } else {
      this.CLADJ_DAMR_LCTG_CD = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.CLADJ_DAMR_MCTG_CD = null; } else {
      this.CLADJ_DAMR_MCTG_CD = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.SIU_SVY_RQS_YN = null; } else {
      this.SIU_SVY_RQS_YN = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.DAMR_GRDE_CD = null; } else {
      this.DAMR_GRDE_CD = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.DLG_YN = null; } else {
      this.DLG_YN = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.DLG_CON_CD_NM = null; } else {
      this.DLG_CON_CD_NM = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.DLG_CO_NM = null; } else {
      this.DLG_CO_NM = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.SVY_INST_NM = null; } else {
      this.SVY_INST_NM = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.TRT_HDQT_ORG_CD = null; } else {
      this.TRT_HDQT_ORG_CD = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.TRT_BRCH_ORG_CD = null; } else {
      this.TRT_BRCH_ORG_CD = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.TRT_BCH_ORG_CD = null; } else {
      this.TRT_BCH_ORG_CD = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.TRTPE_ORG_CD = null; } else {
      this.TRTPE_ORG_CD = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.PCS_COMS_TEM_ORG_CD = null; } else {
      this.PCS_COMS_TEM_ORG_CD = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.PCS_COMS_PART_ORG_CD = null; } else {
      this.PCS_COMS_PART_ORG_CD = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.CHRPE_ORG_CD = null; } else {
      this.CHRPE_ORG_CD = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RCT_DT = null; } else {
      this.RCT_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.FRS_OS_DT = null; } else {
      this.FRS_OS_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.LAST_OS_DT = null; } else {
      this.LAST_OS_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.APVL_DT = null; } else {
      this.APVL_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.LAST_RCT_DT = null; } else {
      this.LAST_RCT_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.FRS_RCTPE_ORG_CD = null; } else {
      this.FRS_RCTPE_ORG_CD = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.CTR_OBJ_ID = null; } else {
      this.CTR_OBJ_ID = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.DMPE_CUS_ID = null; } else {
      this.DMPE_CUS_ID = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.EIH_LDG_DTM = null; } else {
      this.EIH_LDG_DTM = java.sql.Timestamp.valueOf(__cur_str);
    }

    } catch (RuntimeException e) {    throw new RuntimeException("Can't parse input data: '" + __cur_str + "'", e);    }  }

  public Object clone() throws CloneNotSupportedException {
    QueryResult o = (QueryResult) super.clone();
    o.SBCP_DT = (o.SBCP_DT != null) ? (java.sql.Timestamp) o.SBCP_DT.clone() : null;
    o.ACD_DT = (o.ACD_DT != null) ? (java.sql.Timestamp) o.ACD_DT.clone() : null;
    o.DTH_DT = (o.DTH_DT != null) ? (java.sql.Timestamp) o.DTH_DT.clone() : null;
    o.RCT_DT = (o.RCT_DT != null) ? (java.sql.Timestamp) o.RCT_DT.clone() : null;
    o.FRS_OS_DT = (o.FRS_OS_DT != null) ? (java.sql.Timestamp) o.FRS_OS_DT.clone() : null;
    o.LAST_OS_DT = (o.LAST_OS_DT != null) ? (java.sql.Timestamp) o.LAST_OS_DT.clone() : null;
    o.APVL_DT = (o.APVL_DT != null) ? (java.sql.Timestamp) o.APVL_DT.clone() : null;
    o.LAST_RCT_DT = (o.LAST_RCT_DT != null) ? (java.sql.Timestamp) o.LAST_RCT_DT.clone() : null;
    o.EIH_LDG_DTM = (o.EIH_LDG_DTM != null) ? (java.sql.Timestamp) o.EIH_LDG_DTM.clone() : null;
    return o;
  }

  public void clone0(QueryResult o) throws CloneNotSupportedException {
    o.SBCP_DT = (o.SBCP_DT != null) ? (java.sql.Timestamp) o.SBCP_DT.clone() : null;
    o.ACD_DT = (o.ACD_DT != null) ? (java.sql.Timestamp) o.ACD_DT.clone() : null;
    o.DTH_DT = (o.DTH_DT != null) ? (java.sql.Timestamp) o.DTH_DT.clone() : null;
    o.RCT_DT = (o.RCT_DT != null) ? (java.sql.Timestamp) o.RCT_DT.clone() : null;
    o.FRS_OS_DT = (o.FRS_OS_DT != null) ? (java.sql.Timestamp) o.FRS_OS_DT.clone() : null;
    o.LAST_OS_DT = (o.LAST_OS_DT != null) ? (java.sql.Timestamp) o.LAST_OS_DT.clone() : null;
    o.APVL_DT = (o.APVL_DT != null) ? (java.sql.Timestamp) o.APVL_DT.clone() : null;
    o.LAST_RCT_DT = (o.LAST_RCT_DT != null) ? (java.sql.Timestamp) o.LAST_RCT_DT.clone() : null;
    o.EIH_LDG_DTM = (o.EIH_LDG_DTM != null) ? (java.sql.Timestamp) o.EIH_LDG_DTM.clone() : null;
  }

  public Map<String, Object> getFieldMap() {
    Map<String, Object> __sqoop$field_map = new HashMap<String, Object>();
    __sqoop$field_map.put("STD_YYMM", this.STD_YYMM);
    __sqoop$field_map.put("ACD_NO_YY", this.ACD_NO_YY);
    __sqoop$field_map.put("ACD_NO_SEQ", this.ACD_NO_SEQ);
    __sqoop$field_map.put("POL_NO", this.POL_NO);
    __sqoop$field_map.put("CLM_TP_CD", this.CLM_TP_CD);
    __sqoop$field_map.put("DAM_ORD", this.DAM_ORD);
    __sqoop$field_map.put("COV_CD", this.COV_CD);
    __sqoop$field_map.put("ORIG_INS_AMT", this.ORIG_INS_AMT);
    __sqoop$field_map.put("ORIG_OS_INS_AMT", this.ORIG_OS_INS_AMT);
    __sqoop$field_map.put("PRPD_ORIG_OINS_AMT", this.PRPD_ORIG_OINS_AMT);
    __sqoop$field_map.put("ORIG_DMG_AMT", this.ORIG_DMG_AMT);
    __sqoop$field_map.put("PSSE_INS_AMT", this.PSSE_INS_AMT);
    __sqoop$field_map.put("PSSE_OINS_AMT", this.PSSE_OINS_AMT);
    __sqoop$field_map.put("PRPD_PSSE_OINS_AMT", this.PRPD_PSSE_OINS_AMT);
    __sqoop$field_map.put("PSSE_DMG_AMT", this.PSSE_DMG_AMT);
    __sqoop$field_map.put("ADD_PCS_YN", this.ADD_PCS_YN);
    __sqoop$field_map.put("ACD_RCT_PTH_CD", this.ACD_RCT_PTH_CD);
    __sqoop$field_map.put("UNT_PD_CD", this.UNT_PD_CD);
    __sqoop$field_map.put("SBCP_DT", this.SBCP_DT);
    __sqoop$field_map.put("TACD_DMPE_JOB_CD", this.TACD_DMPE_JOB_CD);
    __sqoop$field_map.put("TACD_DMPE_JOB_GRD_CD", this.TACD_DMPE_JOB_GRD_CD);
    __sqoop$field_map.put("TACD_DMPE_GNDR_CD", this.TACD_DMPE_GNDR_CD);
    __sqoop$field_map.put("TACD_DMPE_AGE", this.TACD_DMPE_AGE);
    __sqoop$field_map.put("ACD_DT", this.ACD_DT);
    __sqoop$field_map.put("ACD_DT_HOLI_YN", this.ACD_DT_HOLI_YN);
    __sqoop$field_map.put("ACD_PLC_ZPCD", this.ACD_PLC_ZPCD);
    __sqoop$field_map.put("ACD_PLC_SIDO_CD", this.ACD_PLC_SIDO_CD);
    __sqoop$field_map.put("ACD_CAUS_LCTG_CD", this.ACD_CAUS_LCTG_CD);
    __sqoop$field_map.put("ACD_CAUS_MCTG_CD", this.ACD_CAUS_MCTG_CD);
    __sqoop$field_map.put("ACD_CAUS_SCTG_CD", this.ACD_CAUS_SCTG_CD);
    __sqoop$field_map.put("OVSE_MET_YN", this.OVSE_MET_YN);
    __sqoop$field_map.put("KR_DISZ_CD", this.KR_DISZ_CD);
    __sqoop$field_map.put("RCPR_INST_CD", this.RCPR_INST_CD);
    __sqoop$field_map.put("HSP_DD_NUM", this.HSP_DD_NUM);
    __sqoop$field_map.put("GHR_DD_NUM", this.GHR_DD_NUM);
    __sqoop$field_map.put("PSC_DD_NUM", this.PSC_DD_NUM);
    __sqoop$field_map.put("DDPY_DD_NUM", this.DDPY_DD_NUM);
    __sqoop$field_map.put("OBST_RT", this.OBST_RT);
    __sqoop$field_map.put("DTH_DT", this.DTH_DT);
    __sqoop$field_map.put("DMG_RDUC_AMT", this.DMG_RDUC_AMT);
    __sqoop$field_map.put("CLADJ_DAMR_LCTG_CD", this.CLADJ_DAMR_LCTG_CD);
    __sqoop$field_map.put("CLADJ_DAMR_MCTG_CD", this.CLADJ_DAMR_MCTG_CD);
    __sqoop$field_map.put("SIU_SVY_RQS_YN", this.SIU_SVY_RQS_YN);
    __sqoop$field_map.put("DAMR_GRDE_CD", this.DAMR_GRDE_CD);
    __sqoop$field_map.put("DLG_YN", this.DLG_YN);
    __sqoop$field_map.put("DLG_CON_CD_NM", this.DLG_CON_CD_NM);
    __sqoop$field_map.put("DLG_CO_NM", this.DLG_CO_NM);
    __sqoop$field_map.put("SVY_INST_NM", this.SVY_INST_NM);
    __sqoop$field_map.put("TRT_HDQT_ORG_CD", this.TRT_HDQT_ORG_CD);
    __sqoop$field_map.put("TRT_BRCH_ORG_CD", this.TRT_BRCH_ORG_CD);
    __sqoop$field_map.put("TRT_BCH_ORG_CD", this.TRT_BCH_ORG_CD);
    __sqoop$field_map.put("TRTPE_ORG_CD", this.TRTPE_ORG_CD);
    __sqoop$field_map.put("PCS_COMS_TEM_ORG_CD", this.PCS_COMS_TEM_ORG_CD);
    __sqoop$field_map.put("PCS_COMS_PART_ORG_CD", this.PCS_COMS_PART_ORG_CD);
    __sqoop$field_map.put("CHRPE_ORG_CD", this.CHRPE_ORG_CD);
    __sqoop$field_map.put("RCT_DT", this.RCT_DT);
    __sqoop$field_map.put("FRS_OS_DT", this.FRS_OS_DT);
    __sqoop$field_map.put("LAST_OS_DT", this.LAST_OS_DT);
    __sqoop$field_map.put("APVL_DT", this.APVL_DT);
    __sqoop$field_map.put("LAST_RCT_DT", this.LAST_RCT_DT);
    __sqoop$field_map.put("FRS_RCTPE_ORG_CD", this.FRS_RCTPE_ORG_CD);
    __sqoop$field_map.put("CTR_OBJ_ID", this.CTR_OBJ_ID);
    __sqoop$field_map.put("DMPE_CUS_ID", this.DMPE_CUS_ID);
    __sqoop$field_map.put("EIH_LDG_DTM", this.EIH_LDG_DTM);
    return __sqoop$field_map;
  }

  public void getFieldMap0(Map<String, Object> __sqoop$field_map) {
    __sqoop$field_map.put("STD_YYMM", this.STD_YYMM);
    __sqoop$field_map.put("ACD_NO_YY", this.ACD_NO_YY);
    __sqoop$field_map.put("ACD_NO_SEQ", this.ACD_NO_SEQ);
    __sqoop$field_map.put("POL_NO", this.POL_NO);
    __sqoop$field_map.put("CLM_TP_CD", this.CLM_TP_CD);
    __sqoop$field_map.put("DAM_ORD", this.DAM_ORD);
    __sqoop$field_map.put("COV_CD", this.COV_CD);
    __sqoop$field_map.put("ORIG_INS_AMT", this.ORIG_INS_AMT);
    __sqoop$field_map.put("ORIG_OS_INS_AMT", this.ORIG_OS_INS_AMT);
    __sqoop$field_map.put("PRPD_ORIG_OINS_AMT", this.PRPD_ORIG_OINS_AMT);
    __sqoop$field_map.put("ORIG_DMG_AMT", this.ORIG_DMG_AMT);
    __sqoop$field_map.put("PSSE_INS_AMT", this.PSSE_INS_AMT);
    __sqoop$field_map.put("PSSE_OINS_AMT", this.PSSE_OINS_AMT);
    __sqoop$field_map.put("PRPD_PSSE_OINS_AMT", this.PRPD_PSSE_OINS_AMT);
    __sqoop$field_map.put("PSSE_DMG_AMT", this.PSSE_DMG_AMT);
    __sqoop$field_map.put("ADD_PCS_YN", this.ADD_PCS_YN);
    __sqoop$field_map.put("ACD_RCT_PTH_CD", this.ACD_RCT_PTH_CD);
    __sqoop$field_map.put("UNT_PD_CD", this.UNT_PD_CD);
    __sqoop$field_map.put("SBCP_DT", this.SBCP_DT);
    __sqoop$field_map.put("TACD_DMPE_JOB_CD", this.TACD_DMPE_JOB_CD);
    __sqoop$field_map.put("TACD_DMPE_JOB_GRD_CD", this.TACD_DMPE_JOB_GRD_CD);
    __sqoop$field_map.put("TACD_DMPE_GNDR_CD", this.TACD_DMPE_GNDR_CD);
    __sqoop$field_map.put("TACD_DMPE_AGE", this.TACD_DMPE_AGE);
    __sqoop$field_map.put("ACD_DT", this.ACD_DT);
    __sqoop$field_map.put("ACD_DT_HOLI_YN", this.ACD_DT_HOLI_YN);
    __sqoop$field_map.put("ACD_PLC_ZPCD", this.ACD_PLC_ZPCD);
    __sqoop$field_map.put("ACD_PLC_SIDO_CD", this.ACD_PLC_SIDO_CD);
    __sqoop$field_map.put("ACD_CAUS_LCTG_CD", this.ACD_CAUS_LCTG_CD);
    __sqoop$field_map.put("ACD_CAUS_MCTG_CD", this.ACD_CAUS_MCTG_CD);
    __sqoop$field_map.put("ACD_CAUS_SCTG_CD", this.ACD_CAUS_SCTG_CD);
    __sqoop$field_map.put("OVSE_MET_YN", this.OVSE_MET_YN);
    __sqoop$field_map.put("KR_DISZ_CD", this.KR_DISZ_CD);
    __sqoop$field_map.put("RCPR_INST_CD", this.RCPR_INST_CD);
    __sqoop$field_map.put("HSP_DD_NUM", this.HSP_DD_NUM);
    __sqoop$field_map.put("GHR_DD_NUM", this.GHR_DD_NUM);
    __sqoop$field_map.put("PSC_DD_NUM", this.PSC_DD_NUM);
    __sqoop$field_map.put("DDPY_DD_NUM", this.DDPY_DD_NUM);
    __sqoop$field_map.put("OBST_RT", this.OBST_RT);
    __sqoop$field_map.put("DTH_DT", this.DTH_DT);
    __sqoop$field_map.put("DMG_RDUC_AMT", this.DMG_RDUC_AMT);
    __sqoop$field_map.put("CLADJ_DAMR_LCTG_CD", this.CLADJ_DAMR_LCTG_CD);
    __sqoop$field_map.put("CLADJ_DAMR_MCTG_CD", this.CLADJ_DAMR_MCTG_CD);
    __sqoop$field_map.put("SIU_SVY_RQS_YN", this.SIU_SVY_RQS_YN);
    __sqoop$field_map.put("DAMR_GRDE_CD", this.DAMR_GRDE_CD);
    __sqoop$field_map.put("DLG_YN", this.DLG_YN);
    __sqoop$field_map.put("DLG_CON_CD_NM", this.DLG_CON_CD_NM);
    __sqoop$field_map.put("DLG_CO_NM", this.DLG_CO_NM);
    __sqoop$field_map.put("SVY_INST_NM", this.SVY_INST_NM);
    __sqoop$field_map.put("TRT_HDQT_ORG_CD", this.TRT_HDQT_ORG_CD);
    __sqoop$field_map.put("TRT_BRCH_ORG_CD", this.TRT_BRCH_ORG_CD);
    __sqoop$field_map.put("TRT_BCH_ORG_CD", this.TRT_BCH_ORG_CD);
    __sqoop$field_map.put("TRTPE_ORG_CD", this.TRTPE_ORG_CD);
    __sqoop$field_map.put("PCS_COMS_TEM_ORG_CD", this.PCS_COMS_TEM_ORG_CD);
    __sqoop$field_map.put("PCS_COMS_PART_ORG_CD", this.PCS_COMS_PART_ORG_CD);
    __sqoop$field_map.put("CHRPE_ORG_CD", this.CHRPE_ORG_CD);
    __sqoop$field_map.put("RCT_DT", this.RCT_DT);
    __sqoop$field_map.put("FRS_OS_DT", this.FRS_OS_DT);
    __sqoop$field_map.put("LAST_OS_DT", this.LAST_OS_DT);
    __sqoop$field_map.put("APVL_DT", this.APVL_DT);
    __sqoop$field_map.put("LAST_RCT_DT", this.LAST_RCT_DT);
    __sqoop$field_map.put("FRS_RCTPE_ORG_CD", this.FRS_RCTPE_ORG_CD);
    __sqoop$field_map.put("CTR_OBJ_ID", this.CTR_OBJ_ID);
    __sqoop$field_map.put("DMPE_CUS_ID", this.DMPE_CUS_ID);
    __sqoop$field_map.put("EIH_LDG_DTM", this.EIH_LDG_DTM);
  }

  public void setField(String __fieldName, Object __fieldVal) {
    if (!setters.containsKey(__fieldName)) {
      throw new RuntimeException("No such field:"+__fieldName);
    }
    setters.get(__fieldName).setField(__fieldVal);
  }

}
