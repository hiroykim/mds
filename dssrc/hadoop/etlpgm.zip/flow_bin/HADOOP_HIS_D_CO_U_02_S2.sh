#!/bin/bash

/sqoopbin/scripts/etlpgm/bin/THDDH_TCLCOVCMPT.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TCOPTYCOTR.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TCTMSMDLOG.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TCTPCOTATT.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TCTTCOTLOL.sh
/sqoopbin/scripts/etlpgm/bin/UTIL_TCTPCOTDEL.sh
