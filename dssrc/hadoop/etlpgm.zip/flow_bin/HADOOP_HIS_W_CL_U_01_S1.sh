#!/bin/bash

/sqoopbin/scripts/etlpgm/bin/THFMH_SSMCLOG.sh 
