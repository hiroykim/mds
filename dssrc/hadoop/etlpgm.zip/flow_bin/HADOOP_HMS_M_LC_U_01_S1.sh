#!/bin/bash

/sqoopbin/scripts/etlpgm/bin/THDDH_TCTDMGRCLG.sh
/sqoopbin/scripts/etlpgm/bin/TMLMB_LCMNRT.sh
