#!/bin/bash

/sqoopbin/scripts/etlpgm/bin/THDDH_TCLACDREL.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TCLCOV.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TCLPSBILL.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TCOORGPTY.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TCTPCOT.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TCTPINSPE.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TCTTCOTAIR.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TCTTCOTCVL.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TCTTCOTPTY.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TCUCUST.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TSASLZORG.sh 
/sqoopbin/scripts/etlpgm/bin/THDDH_TCTTPYRDTL.sh
