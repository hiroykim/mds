#!/bin/bash

/sqoopbin/scripts/etlpgm/bin/TMAMB_CSTPIGRDRT.sh 
