#!/bin/bash

/sqoopbin/scripts/etlpgm/bin/THDDH_PCTICPSQYH.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_ICPSISPQRY.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_KCISDZCDAD.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_KCSICPSMPD.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TCTCTORCLG.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TCTDCOMPCV.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TCTIACCSCG.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TCTSNCDTL.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TCTDCOMP.sh
