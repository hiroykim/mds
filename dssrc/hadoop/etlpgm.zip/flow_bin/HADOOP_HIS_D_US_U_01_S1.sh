#!/bin/bash

/sqoopbin/scripts/etlpgm/bin/THFDH_DNCNSHIS.sh 
/sqoopbin/scripts/etlpgm/bin/THDDH_TCTRDYLCTR.sh 
/sqoopbin/scripts/etlpgm/bin/THDDH_TCLDGN.sh 
/sqoopbin/scripts/etlpgm/bin/THDDH_TCLSROP.sh 
/sqoopbin/scripts/etlpgm/bin/THDDH_TCLDAMPRD.sh 

