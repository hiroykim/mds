#!/bin/bash

/sqoopbin/scripts/etlpgm/bin/THDDH_TCTLCOTL1.sh
