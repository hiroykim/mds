#!/bin/bash

/sqoopbin/scripts/etlpgm/bin/THDDH_TCLACDCTR.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TCLCNC.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TCLPAY.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TCOORGPST.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TCTPCAR.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TCTPCOTPTY.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TCTTCOT.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TCTTCOTCV.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TCTTCOTORG.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TCTUW.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TSASLZIDST.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TCTTCOTATT.sh 
