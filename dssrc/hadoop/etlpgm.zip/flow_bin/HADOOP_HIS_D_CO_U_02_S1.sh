#!/bin/bash

/sqoopbin/scripts/etlpgm/bin/THDDH_TCLACDPRS.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TCLSIUCON.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TCTMSMDHIS.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TCTNTFVAL.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TCTTCOTLOC.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TCLOS.sh 
/sqoopbin/scripts/etlpgm/bin/THDDH_TCTDRUPCLG.sh
