#!/bin/bash

/sqoopbin/scripts/etlpgm/bin/TMIDB_INJRDISZDGN.sh
/sqoopbin/scripts/etlpgm/bin/TMIDS_CLADMPELST.sh
/sqoopbin/scripts/etlpgm/bin/TMIDS_CLMDIVDPST.sh
/sqoopbin/scripts/etlpgm/bin/TMIDS_CLMOSPST.sh
/sqoopbin/scripts/etlpgm/bin/TMIDS_LGTDDMGAMT.sh
/sqoopbin/scripts/etlpgm/bin/TMIDS_PCSPRMPANL.sh
/sqoopbin/scripts/etlpgm/bin/TMIDS_TCLPSINS.sh
/sqoopbin/scripts/etlpgm/bin/TMIDS_CLABIZLAST.sh 
