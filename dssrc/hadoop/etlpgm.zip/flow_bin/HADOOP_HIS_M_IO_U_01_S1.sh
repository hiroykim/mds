#!/bin/bash

/sqoopbin/scripts/etlpgm/bin/THDDH_POLTPNPOAT.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_SOEADEAEXP.sh
