#!/bin/bash

/sqoopbin/scripts/etlpgm/flow_bin/HADOOP_HIS_D_CO_U_01_S1.sh &
/sqoopbin/scripts/etlpgm/flow_bin/HADOOP_HIS_D_CO_U_01_S2.sh &
/sqoopbin/scripts/etlpgm/flow_bin/HADOOP_HIS_D_CO_U_01_S3.sh &
/sqoopbin/scripts/etlpgm/flow_bin/HADOOP_HIS_D_CO_U_01_S4.sh &
/sqoopbin/scripts/etlpgm/flow_bin/HADOOP_HIS_D_CO_U_01_S5.sh &
wait
/sqoopbin/scripts/etlpgm/flow_bin/HADOOP_HIS_D_CO_U_02_S1.sh &
/sqoopbin/scripts/etlpgm/flow_bin/HADOOP_HIS_D_CO_U_02_S2.sh &
/sqoopbin/scripts/etlpgm/flow_bin/HADOOP_HIS_D_CO_U_02_S3.sh &
/sqoopbin/scripts/etlpgm/flow_bin/HADOOP_HIS_D_CO_U_02_S4.sh &
/sqoopbin/scripts/etlpgm/flow_bin/HADOOP_HIS_D_CO_U_02_S5.sh &
wait
/sqoopbin/scripts/etlpgm/flow_bin/HADOOP_HIS_D_CL_U_01_S1.sh &
/sqoopbin/scripts/etlpgm/flow_bin/HADOOP_HIS_D_CO_T_01_S1.sh &
/sqoopbin/scripts/etlpgm/flow_bin/HADOOP_HIS_D_CT_U_01_S1.sh &
/sqoopbin/scripts/etlpgm/flow_bin/HADOOP_HIS_D_PD_U_01_S1.sh &
/sqoopbin/scripts/etlpgm/flow_bin/HADOOP_HIS_D_SA_U_01_S1.sh &
wait
/sqoopbin/scripts/etlpgm/flow_bin/HADOOP_HIS_D_US_U_01_S1.sh &
/sqoopbin/scripts/etlpgm/flow_bin/HADOOP_HIS_W_CL_U_01_S1.sh &
/sqoopbin/scripts/etlpgm/flow_bin/HADOOP_HIS_W_CL_U_02_S1.sh &
/sqoopbin/scripts/etlpgm/flow_bin/HADOOP_HMS_M_LC_U_01_S1.sh &
wait
/sqoopbin/scripts/etlpgm/flow_bin/HADOOP_MDI_D_CC_U_01_S1.sh &
/sqoopbin/scripts/etlpgm/flow_bin/HADOOP_MDI_D_CL_U_02_S1.sh &
/sqoopbin/scripts/etlpgm/flow_bin/HADOOP_MDI_D_CO_U_01_S1.sh &
/sqoopbin/scripts/etlpgm/flow_bin/HADOOP_MDI_D_CU_U_01_S1.sh &
/sqoopbin/scripts/etlpgm/flow_bin/HADOOP_MDI_D_LC_U_01_S1.sh &
wait
/sqoopbin/scripts/etlpgm/flow_bin/HADOOP_MDI_M_CL_U_01_S1.sh &
/sqoopbin/scripts/etlpgm/flow_bin/HADOOP_MDI_M_CL_U_02_S1.sh &
/sqoopbin/scripts/etlpgm/flow_bin/HADOOP_HIS_M_CT_U_02_S1.sh &
/sqoopbin/scripts/etlpgm/flow_bin/HADOOP_HIS_M_IO_U_01_S1.sh &
/sqoopbin/scripts/etlpgm/flow_bin/HADOOP_HMS_M_MV_U_01_S1.sh &
wait
/sqoopbin/scripts/etlpgm/flow_bin/HADOOP_ITG_M_MV_U_01_S1.sh &
/sqoopbin/scripts/etlpgm/flow_bin/HADOOP_HIS_D_RI_U_01_S1.sh &
/sqoopbin/scripts/etlpgm/flow_bin/HADOOP_HIS_M_CT_U_05_S1.sh &
/sqoopbin/scripts/etlpgm/bin/THDDH_TCTDCOMPCV_R.sh &
/sqoopbin/scripts/etlpgm/bin/THFDH_SSDCLOG_R.sh &
