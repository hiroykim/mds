#!/bin/bash

/sqoopbin/scripts/etlpgm/bin/THDDH_TRICSSCTCV.sh
