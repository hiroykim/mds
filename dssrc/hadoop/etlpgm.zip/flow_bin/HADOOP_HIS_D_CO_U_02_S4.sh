#!/bin/bash

/sqoopbin/scripts/etlpgm/bin/THDDH_TCLSIU.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TCTCRDAREG.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TCTNTFREL.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TCTTCOTASS.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TCTTCRDTRS.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TCTRCALCCV.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TCTTEDRADJ.sh
