#!/bin/bash

/sqoopbin/scripts/etlpgm/bin/TMIMS_LGTMDMGAMT.sh
