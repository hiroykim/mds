#!/bin/bash

/sqoopbin/scripts/etlpgm/bin/THDDH_TCTEWPYCLG.sh
