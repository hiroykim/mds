#!/bin/bash

/sqoopbin/scripts/etlpgm/bin/THDDH_TCOORGMMCL.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TCORDNZPCD.sh 
