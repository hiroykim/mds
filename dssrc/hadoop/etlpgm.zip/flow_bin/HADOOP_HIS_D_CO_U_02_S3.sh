#!/bin/bash

/sqoopbin/scripts/etlpgm/bin/THDDH_TCLKRDISZ.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TCTATTNTGR.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TCTNTF.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TCTSNCUWDD.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TCTTCOTOBD.sh 
/sqoopbin/scripts/etlpgm/bin/THDDH_TCTRCALCD.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TCTTEDRBAS.sh
