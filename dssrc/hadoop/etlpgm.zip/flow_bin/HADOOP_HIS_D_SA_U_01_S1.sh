#!/bin/bash

/sqoopbin/scripts/etlpgm/bin/THDDH_TSACRORGNU.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TSAFNCACRC.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TSAINCPSCL.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TSALNCTRFE.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TSALTCCTFE.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TSALTCCTON.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TSAOGICARL.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TSAOVRCSFE.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TSASLZCPCL.sh 
