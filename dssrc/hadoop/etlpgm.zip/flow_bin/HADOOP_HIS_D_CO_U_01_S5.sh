#!/bin/bash

/sqoopbin/scripts/etlpgm/bin/THDDH_TCLCLM.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TCLDGN.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TCOJOB.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TCOPTARCTC.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TCTPCOTOBJ.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TCTSNCUWD.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TCTTCOTCGO.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TCTTCOTHUL.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TCTTPRM.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TRICSSCOV.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TSASZPARON.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TCTRFDPYRD.sh 
