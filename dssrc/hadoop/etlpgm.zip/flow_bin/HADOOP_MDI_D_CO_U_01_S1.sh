#!/bin/bash

/sqoopbin/scripts/etlpgm/bin/TMMDD_CALENDAR.sh
/sqoopbin/scripts/etlpgm/bin/TMMDD_CDDIM.sh
/sqoopbin/scripts/etlpgm/bin/TMMDD_MCCOVDIM.sh
/sqoopbin/scripts/etlpgm/bin/TMMDD_MCRSKDIM.sh 
/sqoopbin/scripts/etlpgm/bin/TMMDB_MCLOGORGLT.sh
/sqoopbin/scripts/etlpgm/bin/TMLMB_MLONCTRCLG.sh
