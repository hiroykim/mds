#!/bin/bash

/sqoopbin/scripts/etlpgm/bin/THFDH_DACANDAT.sh
/sqoopbin/scripts/etlpgm/bin/THFDH_SSDCLOG.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TCLHOSP.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TCLSCRGDIV.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TCLPSINS.sh 
