#!/bin/bash

/sqoopbin/scripts/etlpgm/bin/THDDH_RLTCHRVCTP.sh 
