#!/bin/bash

/sqoopbin/scripts/etlpgm/bin/TMADB_NWCOTACPST.sh
/sqoopbin/scripts/etlpgm/bin/TMADB_NWCOTINFO.sh
/sqoopbin/scripts/etlpgm/bin/TMAMB_CSTPMKPRM.sh 
