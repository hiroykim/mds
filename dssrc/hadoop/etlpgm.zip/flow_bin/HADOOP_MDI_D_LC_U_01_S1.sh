#!/bin/bash

/sqoopbin/scripts/etlpgm/bin/TMLDB_LGUWSTATMG.sh
/sqoopbin/scripts/etlpgm/bin/TMLDB_ICPSISPQRY.sh
/sqoopbin/scripts/etlpgm/bin/TMLDB_KCISISPDSZ.sh
/sqoopbin/scripts/etlpgm/bin/TMLDB_KCSISPICPM.sh
/sqoopbin/scripts/etlpgm/bin/TMLDB_LCOTOBJ.sh
/sqoopbin/scripts/etlpgm/bin/TMLDB_LCUW.sh
/sqoopbin/scripts/etlpgm/bin/TMLMB_CUSPRSMINC.sh
/sqoopbin/scripts/etlpgm/bin/TMLMB_NWCOTSNCDL.sh
/sqoopbin/scripts/etlpgm/bin/TMLMB_NWCOTUWISP.sh
/sqoopbin/scripts/etlpgm/bin/TMLMB_NWCTOBJNTD.sh 
/sqoopbin/scripts/etlpgm/bin/TMLDB_PCTRICPSQY.sh
/sqoopbin/scripts/etlpgm/bin/TMLMS_OBJTYPDGRT.sh
