#!/bin/bash

/sqoopbin/scripts/etlpgm/bin/THDDH_TCLSIUCNC.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TCTMDSCCAL.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TCTNTFTBL.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TCTTCOTCON.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TSALTCCOFE.sh 
/sqoopbin/scripts/etlpgm/bin/THDDH_LTCHRVCSTP.sh
/sqoopbin/scripts/etlpgm/bin/TMMDB_SLZFMLM.sh
