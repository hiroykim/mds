#!/bin/bash

/sqoopbin/scripts/etlpgm/bin/THDDH_LPSCTMVCTP.sh 
