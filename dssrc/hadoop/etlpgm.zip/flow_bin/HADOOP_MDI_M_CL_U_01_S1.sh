#!/bin/bash

/sqoopbin/scripts/etlpgm/bin/TMIMS_ORGINFOBM.sh
/sqoopbin/scripts/etlpgm/bin/TMIMS_ORGMDEPISP.sh 
