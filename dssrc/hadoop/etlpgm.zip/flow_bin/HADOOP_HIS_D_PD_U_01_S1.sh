#!/bin/bash

/sqoopbin/scripts/etlpgm/bin/THDDH_VPDCOV.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_VPDUNTPD.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_VPDPDCOV.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_VPDPDCOVX.sh 
/sqoopbin/scripts/etlpgm/bin/THDDH_VPDRSKUNT.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_VPDUNTPDX.sh
