#!/bin/bash

/sqoopbin/scripts/etlpgm/bin/TMMDB_CUSLAST.sh
/sqoopbin/scripts/etlpgm/bin/TMMDB_INSCTRLAST.sh
/sqoopbin/scripts/etlpgm/bin/TMMDB_LGTMCTRLAST.sh
/sqoopbin/scripts/etlpgm/bin/TMMDB_SLZFMLLAST.sh 
