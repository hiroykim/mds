#!/bin/bash

/sqoopbin/scripts/etlpgm/bin/THDDH_TCLBZAC.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TCLDAMPE.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TCLPSBILLD.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TCOPTADTL.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TCTPCOTCV.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TCTSNCUW.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TCTTCOTBLD.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TCTTCOTDED.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TCTTINSPE.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TCUCUSTNM.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TSASZFMLGR.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TCTRFDPYRC.sh 
