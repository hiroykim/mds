#!/bin/bash

/sqoopbin/scripts/etlpgm/bin/THDDH_TCLACD.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TCLCLMOBJ.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TCLINJRDGN.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TCOORG.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TCTISPPE.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TCTPCOTORG.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TCTTATTRS.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TCTTCOTCSS.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TCTTCOTOBJ.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TCTTPRMDTL.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TSASLZCUST.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TCTTPYRXPT.sh 
