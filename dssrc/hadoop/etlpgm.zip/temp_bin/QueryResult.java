// ORM class for table 'null'
// WARNING: This class is AUTO-GENERATED. Modify at your own risk.
//
// Debug information:
// Generated date: Thu Dec 05 08:31:24 GMT 2019
// For connector: org.apache.sqoop.manager.OracleManager
import org.apache.hadoop.io.BytesWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.mapred.lib.db.DBWritable;
import org.apache.sqoop.lib.JdbcWritableBridge;
import org.apache.sqoop.lib.DelimiterSet;
import org.apache.sqoop.lib.FieldFormatter;
import org.apache.sqoop.lib.RecordParser;
import org.apache.sqoop.lib.BooleanParser;
import org.apache.sqoop.lib.BlobRef;
import org.apache.sqoop.lib.ClobRef;
import org.apache.sqoop.lib.LargeObjectLoader;
import org.apache.sqoop.lib.SqoopRecord;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.sql.Date;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

public class QueryResult extends SqoopRecord  implements DBWritable, Writable {
  private final int PROTOCOL_VERSION = 3;
  public int getClassFormatVersion() { return PROTOCOL_VERSION; }
  public static interface FieldSetterCommand {    void setField(Object value);  }  protected ResultSet __cur_result_set;
  private Map<String, FieldSetterCommand> setters = new HashMap<String, FieldSetterCommand>();
  private void init0() {
    setters.put("CLOG_YYMM", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.CLOG_YYMM = (String)value;
      }
    });
    setters.put("CTR_ID", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.CTR_ID = (String)value;
      }
    });
    setters.put("CTR_COV_ID", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.CTR_COV_ID = (String)value;
      }
    });
    setters.put("POL_NO", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.POL_NO = (String)value;
      }
    });
    setters.put("CTR_OBJ_ID", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.CTR_OBJ_ID = (String)value;
      }
    });
    setters.put("PD_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.PD_CD = (String)value;
      }
    });
    setters.put("COV_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.COV_CD = (String)value;
      }
    });
    setters.put("LAST_PY_YYMM", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.LAST_PY_YYMM = (String)value;
      }
    });
    setters.put("CTR_STAT_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.CTR_STAT_CD = (String)value;
      }
    });
    setters.put("CTR_STAT_DTL_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.CTR_STAT_DTL_CD = (String)value;
      }
    });
    setters.put("GURT_ACU_DIV_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.GURT_ACU_DIV_CD = (String)value;
      }
    });
    setters.put("CTR_COV_STAT_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.CTR_COV_STAT_CD = (String)value;
      }
    });
    setters.put("CTR_COV_STAT_DTL_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.CTR_COV_STAT_DTL_CD = (String)value;
      }
    });
    setters.put("COV_BGN_DT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.COV_BGN_DT = (java.sql.Timestamp)value;
      }
    });
    setters.put("COV_ED_DT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.COV_ED_DT = (java.sql.Timestamp)value;
      }
    });
    setters.put("COV_PY_ST_DT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.COV_PY_ST_DT = (java.sql.Timestamp)value;
      }
    });
    setters.put("COV_PY_ED_DT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.COV_PY_ED_DT = (java.sql.Timestamp)value;
      }
    });
    setters.put("COV_PY_CYC_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.COV_PY_CYC_CD = (String)value;
      }
    });
    setters.put("COV_INS_PRD_TP_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.COV_INS_PRD_TP_CD = (String)value;
      }
    });
    setters.put("COV_PY_PRD_TP_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.COV_PY_PRD_TP_CD = (String)value;
      }
    });
    setters.put("COV_INS_PRD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.COV_INS_PRD = (java.math.BigDecimal)value;
      }
    });
    setters.put("COV_PY_PRD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.COV_PY_PRD = (java.math.BigDecimal)value;
      }
    });
    setters.put("INS_AGE", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.INS_AGE = (java.math.BigDecimal)value;
      }
    });
    setters.put("FULL_AGE", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.FULL_AGE = (java.math.BigDecimal)value;
      }
    });
    setters.put("PY_ED_AGE", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.PY_ED_AGE = (java.math.BigDecimal)value;
      }
    });
    setters.put("INS_ED_AGE", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.INS_ED_AGE = (java.math.BigDecimal)value;
      }
    });
    setters.put("MOM_PD_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.MOM_PD_CD = (String)value;
      }
    });
    setters.put("MOM_COV_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.MOM_COV_CD = (String)value;
      }
    });
    setters.put("INSD_AMT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.INSD_AMT = (java.math.BigDecimal)value;
      }
    });
    setters.put("APL_PREM", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.APL_PREM = (java.math.BigDecimal)value;
      }
    });
    setters.put("BAS_PREM", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.BAS_PREM = (java.math.BigDecimal)value;
      }
    });
    setters.put("KEY_COV_SEQ", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.KEY_COV_SEQ = (java.math.BigDecimal)value;
      }
    });
    setters.put("KEY_HIS_SEQ", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.KEY_HIS_SEQ = (java.math.BigDecimal)value;
      }
    });
    setters.put("RKEY_CNFG_CHT_VAL", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.RKEY_CNFG_CHT_VAL = (String)value;
      }
    });
    setters.put("BKEY_CNFG_CHT_VAL", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.BKEY_CNFG_CHT_VAL = (String)value;
      }
    });
    setters.put("XCHG_CF1", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.XCHG_CF1 = (java.math.BigDecimal)value;
      }
    });
    setters.put("XCHG_CF2", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.XCHG_CF2 = (java.math.BigDecimal)value;
      }
    });
    setters.put("XCHG_CF3", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.XCHG_CF3 = (java.math.BigDecimal)value;
      }
    });
    setters.put("XCHG_CF4", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.XCHG_CF4 = (java.math.BigDecimal)value;
      }
    });
    setters.put("XCHG_CF5", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.XCHG_CF5 = (java.math.BigDecimal)value;
      }
    });
    setters.put("ACU_PREM_DIV_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.ACU_PREM_DIV_CD = (String)value;
      }
    });
    setters.put("PY_EXEM_ST_DT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.PY_EXEM_ST_DT = (java.sql.Timestamp)value;
      }
    });
    setters.put("ELP_YR_NUM", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.ELP_YR_NUM = (java.math.BigDecimal)value;
      }
    });
    setters.put("ELP_MM_NUM", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.ELP_MM_NUM = (java.math.BigDecimal)value;
      }
    });
    setters.put("TT_ELP_MM_NUM", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.TT_ELP_MM_NUM = (java.math.BigDecimal)value;
      }
    });
    setters.put("UNPSS_MM_NUM", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.UNPSS_MM_NUM = (java.math.BigDecimal)value;
      }
    });
    setters.put("CMPT_STD_DT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.CMPT_STD_DT = (java.sql.Timestamp)value;
      }
    });
    setters.put("PRPY_TIMS", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.PRPY_TIMS = (java.math.BigDecimal)value;
      }
    });
    setters.put("LPS_DT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.LPS_DT = (java.sql.Timestamp)value;
      }
    });
    setters.put("EXPC_LPS_DT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.EXPC_LPS_DT = (java.sql.Timestamp)value;
      }
    });
    setters.put("PRDCH_ENDR_HIS_STD_NO", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.PRDCH_ENDR_HIS_STD_NO = (java.math.BigDecimal)value;
      }
    });
    setters.put("PREM_ENDR_HIS_STD_NO", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.PREM_ENDR_HIS_STD_NO = (java.math.BigDecimal)value;
      }
    });
    setters.put("APL_NPTD_RDY_AMT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.APL_NPTD_RDY_AMT = (java.math.BigDecimal)value;
      }
    });
    setters.put("STND_NPTD_RDY_AMT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.STND_NPTD_RDY_AMT = (java.math.BigDecimal)value;
      }
    });
    setters.put("APL_TMTD_RDY_AMT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.APL_TMTD_RDY_AMT = (java.math.BigDecimal)value;
      }
    });
    setters.put("STND_TMTD_RDY_AMT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.STND_TMTD_RDY_AMT = (java.math.BigDecimal)value;
      }
    });
    setters.put("UNPSS_PREM", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.UNPSS_PREM = (java.math.BigDecimal)value;
      }
    });
    setters.put("GURT_UNRPD_ACQ_EXP", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.GURT_UNRPD_ACQ_EXP = (java.math.BigDecimal)value;
      }
    });
    setters.put("XPT_ACQ_EXP_TAMT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.XPT_ACQ_EXP_TAMT = (java.math.BigDecimal)value;
      }
    });
    setters.put("STND_ACQ_EXP_TAMT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.STND_ACQ_EXP_TAMT = (java.math.BigDecimal)value;
      }
    });
    setters.put("NRM_INTR_ACU_AMT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.NRM_INTR_ACU_AMT = (java.math.BigDecimal)value;
      }
    });
    setters.put("GRAD_INTR_ACU_AMT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.GRAD_INTR_ACU_AMT = (java.math.BigDecimal)value;
      }
    });
    setters.put("DFR_BGN_RDY_AMT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.DFR_BGN_RDY_AMT = (java.math.BigDecimal)value;
      }
    });
    setters.put("ACU_UNRPD_ACQ_EXP", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.ACU_UNRPD_ACQ_EXP = (java.math.BigDecimal)value;
      }
    });
    setters.put("PAY_TT_FINC_AMT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.PAY_TT_FINC_AMT = (java.math.BigDecimal)value;
      }
    });
    setters.put("NRM_INTR_MID_AMT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.NRM_INTR_MID_AMT = (java.math.BigDecimal)value;
      }
    });
    setters.put("GRAD_INTR_MID_AMT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.GRAD_INTR_MID_AMT = (java.math.BigDecimal)value;
      }
    });
    setters.put("NRM_INTR_ALTN_PY_PREM", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.NRM_INTR_ALTN_PY_PREM = (java.math.BigDecimal)value;
      }
    });
    setters.put("GRAD_INTR_ALTN_PY_PREM", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.GRAD_INTR_ALTN_PY_PREM = (java.math.BigDecimal)value;
      }
    });
    setters.put("LPS_IAMT_RT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.LPS_IAMT_RT = (java.math.BigDecimal)value;
      }
    });
    setters.put("LPS_IAMT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.LPS_IAMT = (java.math.BigDecimal)value;
      }
    });
    setters.put("PRPY_RDY_AMT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.PRPY_RDY_AMT = (java.math.BigDecimal)value;
      }
    });
    setters.put("PRPY_IAMT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.PRPY_IAMT = (java.math.BigDecimal)value;
      }
    });
    setters.put("PVCTR_RDY_AMT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.PVCTR_RDY_AMT = (java.math.BigDecimal)value;
      }
    });
    setters.put("NPTD_RDY_AMT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.NPTD_RDY_AMT = (java.math.BigDecimal)value;
      }
    });
    setters.put("TMTD_RDY_AMT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.TMTD_RDY_AMT = (java.math.BigDecimal)value;
      }
    });
    setters.put("CNTD_RDY_AMT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.CNTD_RDY_AMT = (java.math.BigDecimal)value;
      }
    });
    setters.put("APL_CNTD_RDY_AMT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.APL_CNTD_RDY_AMT = (java.math.BigDecimal)value;
      }
    });
    setters.put("STND_CNTD_RDY_AMT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.STND_CNTD_RDY_AMT = (java.math.BigDecimal)value;
      }
    });
    setters.put("COV_SLZ_PREM", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.COV_SLZ_PREM = (java.math.BigDecimal)value;
      }
    });
    setters.put("CAL_DT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.CAL_DT = (java.sql.Timestamp)value;
      }
    });
    setters.put("NITR_ACU_COV_PPI", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.NITR_ACU_COV_PPI = (java.math.BigDecimal)value;
      }
    });
    setters.put("GITR_ACU_COV_PPI", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.GITR_ACU_COV_PPI = (java.math.BigDecimal)value;
      }
    });
    setters.put("LWRT_TMN_RFD_RT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.LWRT_TMN_RFD_RT = (java.math.BigDecimal)value;
      }
    });
    setters.put("STY_XACQ_EXP_TAMT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.STY_XACQ_EXP_TAMT = (java.math.BigDecimal)value;
      }
    });
    setters.put("STY_STND_ACQ_EXP_TAMT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.STY_STND_ACQ_EXP_TAMT = (java.math.BigDecimal)value;
      }
    });
    setters.put("STY_GURT_URPAE", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.STY_GURT_URPAE = (java.math.BigDecimal)value;
      }
    });
    setters.put("STY_STND_URPAE", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.STY_STND_URPAE = (java.math.BigDecimal)value;
      }
    });
    setters.put("TMTD_LPS_IAMT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.TMTD_LPS_IAMT = (java.math.BigDecimal)value;
      }
    });
    setters.put("RNWL_ED_PRD_DIV_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.RNWL_ED_PRD_DIV_CD = (String)value;
      }
    });
    setters.put("RNWL_ED_PRD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.RNWL_ED_PRD = (java.math.BigDecimal)value;
      }
    });
    setters.put("RNWL_ED_AGE", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.RNWL_ED_AGE = (java.math.BigDecimal)value;
      }
    });
    setters.put("RNWL_ED_DT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.RNWL_ED_DT = (java.sql.Timestamp)value;
      }
    });
    setters.put("RNWL_TMS", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.RNWL_TMS = (java.math.BigDecimal)value;
      }
    });
    setters.put("STD_SBC_AMT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.STD_SBC_AMT = (java.math.BigDecimal)value;
      }
    });
    setters.put("EIH_LDG_DTM", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.EIH_LDG_DTM = (java.sql.Timestamp)value;
      }
    });
  }
  public QueryResult() {
    init0();
  }
  private String CLOG_YYMM;
  public String get_CLOG_YYMM() {
    return CLOG_YYMM;
  }
  public void set_CLOG_YYMM(String CLOG_YYMM) {
    this.CLOG_YYMM = CLOG_YYMM;
  }
  public QueryResult with_CLOG_YYMM(String CLOG_YYMM) {
    this.CLOG_YYMM = CLOG_YYMM;
    return this;
  }
  private String CTR_ID;
  public String get_CTR_ID() {
    return CTR_ID;
  }
  public void set_CTR_ID(String CTR_ID) {
    this.CTR_ID = CTR_ID;
  }
  public QueryResult with_CTR_ID(String CTR_ID) {
    this.CTR_ID = CTR_ID;
    return this;
  }
  private String CTR_COV_ID;
  public String get_CTR_COV_ID() {
    return CTR_COV_ID;
  }
  public void set_CTR_COV_ID(String CTR_COV_ID) {
    this.CTR_COV_ID = CTR_COV_ID;
  }
  public QueryResult with_CTR_COV_ID(String CTR_COV_ID) {
    this.CTR_COV_ID = CTR_COV_ID;
    return this;
  }
  private String POL_NO;
  public String get_POL_NO() {
    return POL_NO;
  }
  public void set_POL_NO(String POL_NO) {
    this.POL_NO = POL_NO;
  }
  public QueryResult with_POL_NO(String POL_NO) {
    this.POL_NO = POL_NO;
    return this;
  }
  private String CTR_OBJ_ID;
  public String get_CTR_OBJ_ID() {
    return CTR_OBJ_ID;
  }
  public void set_CTR_OBJ_ID(String CTR_OBJ_ID) {
    this.CTR_OBJ_ID = CTR_OBJ_ID;
  }
  public QueryResult with_CTR_OBJ_ID(String CTR_OBJ_ID) {
    this.CTR_OBJ_ID = CTR_OBJ_ID;
    return this;
  }
  private String PD_CD;
  public String get_PD_CD() {
    return PD_CD;
  }
  public void set_PD_CD(String PD_CD) {
    this.PD_CD = PD_CD;
  }
  public QueryResult with_PD_CD(String PD_CD) {
    this.PD_CD = PD_CD;
    return this;
  }
  private String COV_CD;
  public String get_COV_CD() {
    return COV_CD;
  }
  public void set_COV_CD(String COV_CD) {
    this.COV_CD = COV_CD;
  }
  public QueryResult with_COV_CD(String COV_CD) {
    this.COV_CD = COV_CD;
    return this;
  }
  private String LAST_PY_YYMM;
  public String get_LAST_PY_YYMM() {
    return LAST_PY_YYMM;
  }
  public void set_LAST_PY_YYMM(String LAST_PY_YYMM) {
    this.LAST_PY_YYMM = LAST_PY_YYMM;
  }
  public QueryResult with_LAST_PY_YYMM(String LAST_PY_YYMM) {
    this.LAST_PY_YYMM = LAST_PY_YYMM;
    return this;
  }
  private String CTR_STAT_CD;
  public String get_CTR_STAT_CD() {
    return CTR_STAT_CD;
  }
  public void set_CTR_STAT_CD(String CTR_STAT_CD) {
    this.CTR_STAT_CD = CTR_STAT_CD;
  }
  public QueryResult with_CTR_STAT_CD(String CTR_STAT_CD) {
    this.CTR_STAT_CD = CTR_STAT_CD;
    return this;
  }
  private String CTR_STAT_DTL_CD;
  public String get_CTR_STAT_DTL_CD() {
    return CTR_STAT_DTL_CD;
  }
  public void set_CTR_STAT_DTL_CD(String CTR_STAT_DTL_CD) {
    this.CTR_STAT_DTL_CD = CTR_STAT_DTL_CD;
  }
  public QueryResult with_CTR_STAT_DTL_CD(String CTR_STAT_DTL_CD) {
    this.CTR_STAT_DTL_CD = CTR_STAT_DTL_CD;
    return this;
  }
  private String GURT_ACU_DIV_CD;
  public String get_GURT_ACU_DIV_CD() {
    return GURT_ACU_DIV_CD;
  }
  public void set_GURT_ACU_DIV_CD(String GURT_ACU_DIV_CD) {
    this.GURT_ACU_DIV_CD = GURT_ACU_DIV_CD;
  }
  public QueryResult with_GURT_ACU_DIV_CD(String GURT_ACU_DIV_CD) {
    this.GURT_ACU_DIV_CD = GURT_ACU_DIV_CD;
    return this;
  }
  private String CTR_COV_STAT_CD;
  public String get_CTR_COV_STAT_CD() {
    return CTR_COV_STAT_CD;
  }
  public void set_CTR_COV_STAT_CD(String CTR_COV_STAT_CD) {
    this.CTR_COV_STAT_CD = CTR_COV_STAT_CD;
  }
  public QueryResult with_CTR_COV_STAT_CD(String CTR_COV_STAT_CD) {
    this.CTR_COV_STAT_CD = CTR_COV_STAT_CD;
    return this;
  }
  private String CTR_COV_STAT_DTL_CD;
  public String get_CTR_COV_STAT_DTL_CD() {
    return CTR_COV_STAT_DTL_CD;
  }
  public void set_CTR_COV_STAT_DTL_CD(String CTR_COV_STAT_DTL_CD) {
    this.CTR_COV_STAT_DTL_CD = CTR_COV_STAT_DTL_CD;
  }
  public QueryResult with_CTR_COV_STAT_DTL_CD(String CTR_COV_STAT_DTL_CD) {
    this.CTR_COV_STAT_DTL_CD = CTR_COV_STAT_DTL_CD;
    return this;
  }
  private java.sql.Timestamp COV_BGN_DT;
  public java.sql.Timestamp get_COV_BGN_DT() {
    return COV_BGN_DT;
  }
  public void set_COV_BGN_DT(java.sql.Timestamp COV_BGN_DT) {
    this.COV_BGN_DT = COV_BGN_DT;
  }
  public QueryResult with_COV_BGN_DT(java.sql.Timestamp COV_BGN_DT) {
    this.COV_BGN_DT = COV_BGN_DT;
    return this;
  }
  private java.sql.Timestamp COV_ED_DT;
  public java.sql.Timestamp get_COV_ED_DT() {
    return COV_ED_DT;
  }
  public void set_COV_ED_DT(java.sql.Timestamp COV_ED_DT) {
    this.COV_ED_DT = COV_ED_DT;
  }
  public QueryResult with_COV_ED_DT(java.sql.Timestamp COV_ED_DT) {
    this.COV_ED_DT = COV_ED_DT;
    return this;
  }
  private java.sql.Timestamp COV_PY_ST_DT;
  public java.sql.Timestamp get_COV_PY_ST_DT() {
    return COV_PY_ST_DT;
  }
  public void set_COV_PY_ST_DT(java.sql.Timestamp COV_PY_ST_DT) {
    this.COV_PY_ST_DT = COV_PY_ST_DT;
  }
  public QueryResult with_COV_PY_ST_DT(java.sql.Timestamp COV_PY_ST_DT) {
    this.COV_PY_ST_DT = COV_PY_ST_DT;
    return this;
  }
  private java.sql.Timestamp COV_PY_ED_DT;
  public java.sql.Timestamp get_COV_PY_ED_DT() {
    return COV_PY_ED_DT;
  }
  public void set_COV_PY_ED_DT(java.sql.Timestamp COV_PY_ED_DT) {
    this.COV_PY_ED_DT = COV_PY_ED_DT;
  }
  public QueryResult with_COV_PY_ED_DT(java.sql.Timestamp COV_PY_ED_DT) {
    this.COV_PY_ED_DT = COV_PY_ED_DT;
    return this;
  }
  private String COV_PY_CYC_CD;
  public String get_COV_PY_CYC_CD() {
    return COV_PY_CYC_CD;
  }
  public void set_COV_PY_CYC_CD(String COV_PY_CYC_CD) {
    this.COV_PY_CYC_CD = COV_PY_CYC_CD;
  }
  public QueryResult with_COV_PY_CYC_CD(String COV_PY_CYC_CD) {
    this.COV_PY_CYC_CD = COV_PY_CYC_CD;
    return this;
  }
  private String COV_INS_PRD_TP_CD;
  public String get_COV_INS_PRD_TP_CD() {
    return COV_INS_PRD_TP_CD;
  }
  public void set_COV_INS_PRD_TP_CD(String COV_INS_PRD_TP_CD) {
    this.COV_INS_PRD_TP_CD = COV_INS_PRD_TP_CD;
  }
  public QueryResult with_COV_INS_PRD_TP_CD(String COV_INS_PRD_TP_CD) {
    this.COV_INS_PRD_TP_CD = COV_INS_PRD_TP_CD;
    return this;
  }
  private String COV_PY_PRD_TP_CD;
  public String get_COV_PY_PRD_TP_CD() {
    return COV_PY_PRD_TP_CD;
  }
  public void set_COV_PY_PRD_TP_CD(String COV_PY_PRD_TP_CD) {
    this.COV_PY_PRD_TP_CD = COV_PY_PRD_TP_CD;
  }
  public QueryResult with_COV_PY_PRD_TP_CD(String COV_PY_PRD_TP_CD) {
    this.COV_PY_PRD_TP_CD = COV_PY_PRD_TP_CD;
    return this;
  }
  private java.math.BigDecimal COV_INS_PRD;
  public java.math.BigDecimal get_COV_INS_PRD() {
    return COV_INS_PRD;
  }
  public void set_COV_INS_PRD(java.math.BigDecimal COV_INS_PRD) {
    this.COV_INS_PRD = COV_INS_PRD;
  }
  public QueryResult with_COV_INS_PRD(java.math.BigDecimal COV_INS_PRD) {
    this.COV_INS_PRD = COV_INS_PRD;
    return this;
  }
  private java.math.BigDecimal COV_PY_PRD;
  public java.math.BigDecimal get_COV_PY_PRD() {
    return COV_PY_PRD;
  }
  public void set_COV_PY_PRD(java.math.BigDecimal COV_PY_PRD) {
    this.COV_PY_PRD = COV_PY_PRD;
  }
  public QueryResult with_COV_PY_PRD(java.math.BigDecimal COV_PY_PRD) {
    this.COV_PY_PRD = COV_PY_PRD;
    return this;
  }
  private java.math.BigDecimal INS_AGE;
  public java.math.BigDecimal get_INS_AGE() {
    return INS_AGE;
  }
  public void set_INS_AGE(java.math.BigDecimal INS_AGE) {
    this.INS_AGE = INS_AGE;
  }
  public QueryResult with_INS_AGE(java.math.BigDecimal INS_AGE) {
    this.INS_AGE = INS_AGE;
    return this;
  }
  private java.math.BigDecimal FULL_AGE;
  public java.math.BigDecimal get_FULL_AGE() {
    return FULL_AGE;
  }
  public void set_FULL_AGE(java.math.BigDecimal FULL_AGE) {
    this.FULL_AGE = FULL_AGE;
  }
  public QueryResult with_FULL_AGE(java.math.BigDecimal FULL_AGE) {
    this.FULL_AGE = FULL_AGE;
    return this;
  }
  private java.math.BigDecimal PY_ED_AGE;
  public java.math.BigDecimal get_PY_ED_AGE() {
    return PY_ED_AGE;
  }
  public void set_PY_ED_AGE(java.math.BigDecimal PY_ED_AGE) {
    this.PY_ED_AGE = PY_ED_AGE;
  }
  public QueryResult with_PY_ED_AGE(java.math.BigDecimal PY_ED_AGE) {
    this.PY_ED_AGE = PY_ED_AGE;
    return this;
  }
  private java.math.BigDecimal INS_ED_AGE;
  public java.math.BigDecimal get_INS_ED_AGE() {
    return INS_ED_AGE;
  }
  public void set_INS_ED_AGE(java.math.BigDecimal INS_ED_AGE) {
    this.INS_ED_AGE = INS_ED_AGE;
  }
  public QueryResult with_INS_ED_AGE(java.math.BigDecimal INS_ED_AGE) {
    this.INS_ED_AGE = INS_ED_AGE;
    return this;
  }
  private String MOM_PD_CD;
  public String get_MOM_PD_CD() {
    return MOM_PD_CD;
  }
  public void set_MOM_PD_CD(String MOM_PD_CD) {
    this.MOM_PD_CD = MOM_PD_CD;
  }
  public QueryResult with_MOM_PD_CD(String MOM_PD_CD) {
    this.MOM_PD_CD = MOM_PD_CD;
    return this;
  }
  private String MOM_COV_CD;
  public String get_MOM_COV_CD() {
    return MOM_COV_CD;
  }
  public void set_MOM_COV_CD(String MOM_COV_CD) {
    this.MOM_COV_CD = MOM_COV_CD;
  }
  public QueryResult with_MOM_COV_CD(String MOM_COV_CD) {
    this.MOM_COV_CD = MOM_COV_CD;
    return this;
  }
  private java.math.BigDecimal INSD_AMT;
  public java.math.BigDecimal get_INSD_AMT() {
    return INSD_AMT;
  }
  public void set_INSD_AMT(java.math.BigDecimal INSD_AMT) {
    this.INSD_AMT = INSD_AMT;
  }
  public QueryResult with_INSD_AMT(java.math.BigDecimal INSD_AMT) {
    this.INSD_AMT = INSD_AMT;
    return this;
  }
  private java.math.BigDecimal APL_PREM;
  public java.math.BigDecimal get_APL_PREM() {
    return APL_PREM;
  }
  public void set_APL_PREM(java.math.BigDecimal APL_PREM) {
    this.APL_PREM = APL_PREM;
  }
  public QueryResult with_APL_PREM(java.math.BigDecimal APL_PREM) {
    this.APL_PREM = APL_PREM;
    return this;
  }
  private java.math.BigDecimal BAS_PREM;
  public java.math.BigDecimal get_BAS_PREM() {
    return BAS_PREM;
  }
  public void set_BAS_PREM(java.math.BigDecimal BAS_PREM) {
    this.BAS_PREM = BAS_PREM;
  }
  public QueryResult with_BAS_PREM(java.math.BigDecimal BAS_PREM) {
    this.BAS_PREM = BAS_PREM;
    return this;
  }
  private java.math.BigDecimal KEY_COV_SEQ;
  public java.math.BigDecimal get_KEY_COV_SEQ() {
    return KEY_COV_SEQ;
  }
  public void set_KEY_COV_SEQ(java.math.BigDecimal KEY_COV_SEQ) {
    this.KEY_COV_SEQ = KEY_COV_SEQ;
  }
  public QueryResult with_KEY_COV_SEQ(java.math.BigDecimal KEY_COV_SEQ) {
    this.KEY_COV_SEQ = KEY_COV_SEQ;
    return this;
  }
  private java.math.BigDecimal KEY_HIS_SEQ;
  public java.math.BigDecimal get_KEY_HIS_SEQ() {
    return KEY_HIS_SEQ;
  }
  public void set_KEY_HIS_SEQ(java.math.BigDecimal KEY_HIS_SEQ) {
    this.KEY_HIS_SEQ = KEY_HIS_SEQ;
  }
  public QueryResult with_KEY_HIS_SEQ(java.math.BigDecimal KEY_HIS_SEQ) {
    this.KEY_HIS_SEQ = KEY_HIS_SEQ;
    return this;
  }
  private String RKEY_CNFG_CHT_VAL;
  public String get_RKEY_CNFG_CHT_VAL() {
    return RKEY_CNFG_CHT_VAL;
  }
  public void set_RKEY_CNFG_CHT_VAL(String RKEY_CNFG_CHT_VAL) {
    this.RKEY_CNFG_CHT_VAL = RKEY_CNFG_CHT_VAL;
  }
  public QueryResult with_RKEY_CNFG_CHT_VAL(String RKEY_CNFG_CHT_VAL) {
    this.RKEY_CNFG_CHT_VAL = RKEY_CNFG_CHT_VAL;
    return this;
  }
  private String BKEY_CNFG_CHT_VAL;
  public String get_BKEY_CNFG_CHT_VAL() {
    return BKEY_CNFG_CHT_VAL;
  }
  public void set_BKEY_CNFG_CHT_VAL(String BKEY_CNFG_CHT_VAL) {
    this.BKEY_CNFG_CHT_VAL = BKEY_CNFG_CHT_VAL;
  }
  public QueryResult with_BKEY_CNFG_CHT_VAL(String BKEY_CNFG_CHT_VAL) {
    this.BKEY_CNFG_CHT_VAL = BKEY_CNFG_CHT_VAL;
    return this;
  }
  private java.math.BigDecimal XCHG_CF1;
  public java.math.BigDecimal get_XCHG_CF1() {
    return XCHG_CF1;
  }
  public void set_XCHG_CF1(java.math.BigDecimal XCHG_CF1) {
    this.XCHG_CF1 = XCHG_CF1;
  }
  public QueryResult with_XCHG_CF1(java.math.BigDecimal XCHG_CF1) {
    this.XCHG_CF1 = XCHG_CF1;
    return this;
  }
  private java.math.BigDecimal XCHG_CF2;
  public java.math.BigDecimal get_XCHG_CF2() {
    return XCHG_CF2;
  }
  public void set_XCHG_CF2(java.math.BigDecimal XCHG_CF2) {
    this.XCHG_CF2 = XCHG_CF2;
  }
  public QueryResult with_XCHG_CF2(java.math.BigDecimal XCHG_CF2) {
    this.XCHG_CF2 = XCHG_CF2;
    return this;
  }
  private java.math.BigDecimal XCHG_CF3;
  public java.math.BigDecimal get_XCHG_CF3() {
    return XCHG_CF3;
  }
  public void set_XCHG_CF3(java.math.BigDecimal XCHG_CF3) {
    this.XCHG_CF3 = XCHG_CF3;
  }
  public QueryResult with_XCHG_CF3(java.math.BigDecimal XCHG_CF3) {
    this.XCHG_CF3 = XCHG_CF3;
    return this;
  }
  private java.math.BigDecimal XCHG_CF4;
  public java.math.BigDecimal get_XCHG_CF4() {
    return XCHG_CF4;
  }
  public void set_XCHG_CF4(java.math.BigDecimal XCHG_CF4) {
    this.XCHG_CF4 = XCHG_CF4;
  }
  public QueryResult with_XCHG_CF4(java.math.BigDecimal XCHG_CF4) {
    this.XCHG_CF4 = XCHG_CF4;
    return this;
  }
  private java.math.BigDecimal XCHG_CF5;
  public java.math.BigDecimal get_XCHG_CF5() {
    return XCHG_CF5;
  }
  public void set_XCHG_CF5(java.math.BigDecimal XCHG_CF5) {
    this.XCHG_CF5 = XCHG_CF5;
  }
  public QueryResult with_XCHG_CF5(java.math.BigDecimal XCHG_CF5) {
    this.XCHG_CF5 = XCHG_CF5;
    return this;
  }
  private String ACU_PREM_DIV_CD;
  public String get_ACU_PREM_DIV_CD() {
    return ACU_PREM_DIV_CD;
  }
  public void set_ACU_PREM_DIV_CD(String ACU_PREM_DIV_CD) {
    this.ACU_PREM_DIV_CD = ACU_PREM_DIV_CD;
  }
  public QueryResult with_ACU_PREM_DIV_CD(String ACU_PREM_DIV_CD) {
    this.ACU_PREM_DIV_CD = ACU_PREM_DIV_CD;
    return this;
  }
  private java.sql.Timestamp PY_EXEM_ST_DT;
  public java.sql.Timestamp get_PY_EXEM_ST_DT() {
    return PY_EXEM_ST_DT;
  }
  public void set_PY_EXEM_ST_DT(java.sql.Timestamp PY_EXEM_ST_DT) {
    this.PY_EXEM_ST_DT = PY_EXEM_ST_DT;
  }
  public QueryResult with_PY_EXEM_ST_DT(java.sql.Timestamp PY_EXEM_ST_DT) {
    this.PY_EXEM_ST_DT = PY_EXEM_ST_DT;
    return this;
  }
  private java.math.BigDecimal ELP_YR_NUM;
  public java.math.BigDecimal get_ELP_YR_NUM() {
    return ELP_YR_NUM;
  }
  public void set_ELP_YR_NUM(java.math.BigDecimal ELP_YR_NUM) {
    this.ELP_YR_NUM = ELP_YR_NUM;
  }
  public QueryResult with_ELP_YR_NUM(java.math.BigDecimal ELP_YR_NUM) {
    this.ELP_YR_NUM = ELP_YR_NUM;
    return this;
  }
  private java.math.BigDecimal ELP_MM_NUM;
  public java.math.BigDecimal get_ELP_MM_NUM() {
    return ELP_MM_NUM;
  }
  public void set_ELP_MM_NUM(java.math.BigDecimal ELP_MM_NUM) {
    this.ELP_MM_NUM = ELP_MM_NUM;
  }
  public QueryResult with_ELP_MM_NUM(java.math.BigDecimal ELP_MM_NUM) {
    this.ELP_MM_NUM = ELP_MM_NUM;
    return this;
  }
  private java.math.BigDecimal TT_ELP_MM_NUM;
  public java.math.BigDecimal get_TT_ELP_MM_NUM() {
    return TT_ELP_MM_NUM;
  }
  public void set_TT_ELP_MM_NUM(java.math.BigDecimal TT_ELP_MM_NUM) {
    this.TT_ELP_MM_NUM = TT_ELP_MM_NUM;
  }
  public QueryResult with_TT_ELP_MM_NUM(java.math.BigDecimal TT_ELP_MM_NUM) {
    this.TT_ELP_MM_NUM = TT_ELP_MM_NUM;
    return this;
  }
  private java.math.BigDecimal UNPSS_MM_NUM;
  public java.math.BigDecimal get_UNPSS_MM_NUM() {
    return UNPSS_MM_NUM;
  }
  public void set_UNPSS_MM_NUM(java.math.BigDecimal UNPSS_MM_NUM) {
    this.UNPSS_MM_NUM = UNPSS_MM_NUM;
  }
  public QueryResult with_UNPSS_MM_NUM(java.math.BigDecimal UNPSS_MM_NUM) {
    this.UNPSS_MM_NUM = UNPSS_MM_NUM;
    return this;
  }
  private java.sql.Timestamp CMPT_STD_DT;
  public java.sql.Timestamp get_CMPT_STD_DT() {
    return CMPT_STD_DT;
  }
  public void set_CMPT_STD_DT(java.sql.Timestamp CMPT_STD_DT) {
    this.CMPT_STD_DT = CMPT_STD_DT;
  }
  public QueryResult with_CMPT_STD_DT(java.sql.Timestamp CMPT_STD_DT) {
    this.CMPT_STD_DT = CMPT_STD_DT;
    return this;
  }
  private java.math.BigDecimal PRPY_TIMS;
  public java.math.BigDecimal get_PRPY_TIMS() {
    return PRPY_TIMS;
  }
  public void set_PRPY_TIMS(java.math.BigDecimal PRPY_TIMS) {
    this.PRPY_TIMS = PRPY_TIMS;
  }
  public QueryResult with_PRPY_TIMS(java.math.BigDecimal PRPY_TIMS) {
    this.PRPY_TIMS = PRPY_TIMS;
    return this;
  }
  private java.sql.Timestamp LPS_DT;
  public java.sql.Timestamp get_LPS_DT() {
    return LPS_DT;
  }
  public void set_LPS_DT(java.sql.Timestamp LPS_DT) {
    this.LPS_DT = LPS_DT;
  }
  public QueryResult with_LPS_DT(java.sql.Timestamp LPS_DT) {
    this.LPS_DT = LPS_DT;
    return this;
  }
  private java.sql.Timestamp EXPC_LPS_DT;
  public java.sql.Timestamp get_EXPC_LPS_DT() {
    return EXPC_LPS_DT;
  }
  public void set_EXPC_LPS_DT(java.sql.Timestamp EXPC_LPS_DT) {
    this.EXPC_LPS_DT = EXPC_LPS_DT;
  }
  public QueryResult with_EXPC_LPS_DT(java.sql.Timestamp EXPC_LPS_DT) {
    this.EXPC_LPS_DT = EXPC_LPS_DT;
    return this;
  }
  private java.math.BigDecimal PRDCH_ENDR_HIS_STD_NO;
  public java.math.BigDecimal get_PRDCH_ENDR_HIS_STD_NO() {
    return PRDCH_ENDR_HIS_STD_NO;
  }
  public void set_PRDCH_ENDR_HIS_STD_NO(java.math.BigDecimal PRDCH_ENDR_HIS_STD_NO) {
    this.PRDCH_ENDR_HIS_STD_NO = PRDCH_ENDR_HIS_STD_NO;
  }
  public QueryResult with_PRDCH_ENDR_HIS_STD_NO(java.math.BigDecimal PRDCH_ENDR_HIS_STD_NO) {
    this.PRDCH_ENDR_HIS_STD_NO = PRDCH_ENDR_HIS_STD_NO;
    return this;
  }
  private java.math.BigDecimal PREM_ENDR_HIS_STD_NO;
  public java.math.BigDecimal get_PREM_ENDR_HIS_STD_NO() {
    return PREM_ENDR_HIS_STD_NO;
  }
  public void set_PREM_ENDR_HIS_STD_NO(java.math.BigDecimal PREM_ENDR_HIS_STD_NO) {
    this.PREM_ENDR_HIS_STD_NO = PREM_ENDR_HIS_STD_NO;
  }
  public QueryResult with_PREM_ENDR_HIS_STD_NO(java.math.BigDecimal PREM_ENDR_HIS_STD_NO) {
    this.PREM_ENDR_HIS_STD_NO = PREM_ENDR_HIS_STD_NO;
    return this;
  }
  private java.math.BigDecimal APL_NPTD_RDY_AMT;
  public java.math.BigDecimal get_APL_NPTD_RDY_AMT() {
    return APL_NPTD_RDY_AMT;
  }
  public void set_APL_NPTD_RDY_AMT(java.math.BigDecimal APL_NPTD_RDY_AMT) {
    this.APL_NPTD_RDY_AMT = APL_NPTD_RDY_AMT;
  }
  public QueryResult with_APL_NPTD_RDY_AMT(java.math.BigDecimal APL_NPTD_RDY_AMT) {
    this.APL_NPTD_RDY_AMT = APL_NPTD_RDY_AMT;
    return this;
  }
  private java.math.BigDecimal STND_NPTD_RDY_AMT;
  public java.math.BigDecimal get_STND_NPTD_RDY_AMT() {
    return STND_NPTD_RDY_AMT;
  }
  public void set_STND_NPTD_RDY_AMT(java.math.BigDecimal STND_NPTD_RDY_AMT) {
    this.STND_NPTD_RDY_AMT = STND_NPTD_RDY_AMT;
  }
  public QueryResult with_STND_NPTD_RDY_AMT(java.math.BigDecimal STND_NPTD_RDY_AMT) {
    this.STND_NPTD_RDY_AMT = STND_NPTD_RDY_AMT;
    return this;
  }
  private java.math.BigDecimal APL_TMTD_RDY_AMT;
  public java.math.BigDecimal get_APL_TMTD_RDY_AMT() {
    return APL_TMTD_RDY_AMT;
  }
  public void set_APL_TMTD_RDY_AMT(java.math.BigDecimal APL_TMTD_RDY_AMT) {
    this.APL_TMTD_RDY_AMT = APL_TMTD_RDY_AMT;
  }
  public QueryResult with_APL_TMTD_RDY_AMT(java.math.BigDecimal APL_TMTD_RDY_AMT) {
    this.APL_TMTD_RDY_AMT = APL_TMTD_RDY_AMT;
    return this;
  }
  private java.math.BigDecimal STND_TMTD_RDY_AMT;
  public java.math.BigDecimal get_STND_TMTD_RDY_AMT() {
    return STND_TMTD_RDY_AMT;
  }
  public void set_STND_TMTD_RDY_AMT(java.math.BigDecimal STND_TMTD_RDY_AMT) {
    this.STND_TMTD_RDY_AMT = STND_TMTD_RDY_AMT;
  }
  public QueryResult with_STND_TMTD_RDY_AMT(java.math.BigDecimal STND_TMTD_RDY_AMT) {
    this.STND_TMTD_RDY_AMT = STND_TMTD_RDY_AMT;
    return this;
  }
  private java.math.BigDecimal UNPSS_PREM;
  public java.math.BigDecimal get_UNPSS_PREM() {
    return UNPSS_PREM;
  }
  public void set_UNPSS_PREM(java.math.BigDecimal UNPSS_PREM) {
    this.UNPSS_PREM = UNPSS_PREM;
  }
  public QueryResult with_UNPSS_PREM(java.math.BigDecimal UNPSS_PREM) {
    this.UNPSS_PREM = UNPSS_PREM;
    return this;
  }
  private java.math.BigDecimal GURT_UNRPD_ACQ_EXP;
  public java.math.BigDecimal get_GURT_UNRPD_ACQ_EXP() {
    return GURT_UNRPD_ACQ_EXP;
  }
  public void set_GURT_UNRPD_ACQ_EXP(java.math.BigDecimal GURT_UNRPD_ACQ_EXP) {
    this.GURT_UNRPD_ACQ_EXP = GURT_UNRPD_ACQ_EXP;
  }
  public QueryResult with_GURT_UNRPD_ACQ_EXP(java.math.BigDecimal GURT_UNRPD_ACQ_EXP) {
    this.GURT_UNRPD_ACQ_EXP = GURT_UNRPD_ACQ_EXP;
    return this;
  }
  private java.math.BigDecimal XPT_ACQ_EXP_TAMT;
  public java.math.BigDecimal get_XPT_ACQ_EXP_TAMT() {
    return XPT_ACQ_EXP_TAMT;
  }
  public void set_XPT_ACQ_EXP_TAMT(java.math.BigDecimal XPT_ACQ_EXP_TAMT) {
    this.XPT_ACQ_EXP_TAMT = XPT_ACQ_EXP_TAMT;
  }
  public QueryResult with_XPT_ACQ_EXP_TAMT(java.math.BigDecimal XPT_ACQ_EXP_TAMT) {
    this.XPT_ACQ_EXP_TAMT = XPT_ACQ_EXP_TAMT;
    return this;
  }
  private java.math.BigDecimal STND_ACQ_EXP_TAMT;
  public java.math.BigDecimal get_STND_ACQ_EXP_TAMT() {
    return STND_ACQ_EXP_TAMT;
  }
  public void set_STND_ACQ_EXP_TAMT(java.math.BigDecimal STND_ACQ_EXP_TAMT) {
    this.STND_ACQ_EXP_TAMT = STND_ACQ_EXP_TAMT;
  }
  public QueryResult with_STND_ACQ_EXP_TAMT(java.math.BigDecimal STND_ACQ_EXP_TAMT) {
    this.STND_ACQ_EXP_TAMT = STND_ACQ_EXP_TAMT;
    return this;
  }
  private java.math.BigDecimal NRM_INTR_ACU_AMT;
  public java.math.BigDecimal get_NRM_INTR_ACU_AMT() {
    return NRM_INTR_ACU_AMT;
  }
  public void set_NRM_INTR_ACU_AMT(java.math.BigDecimal NRM_INTR_ACU_AMT) {
    this.NRM_INTR_ACU_AMT = NRM_INTR_ACU_AMT;
  }
  public QueryResult with_NRM_INTR_ACU_AMT(java.math.BigDecimal NRM_INTR_ACU_AMT) {
    this.NRM_INTR_ACU_AMT = NRM_INTR_ACU_AMT;
    return this;
  }
  private java.math.BigDecimal GRAD_INTR_ACU_AMT;
  public java.math.BigDecimal get_GRAD_INTR_ACU_AMT() {
    return GRAD_INTR_ACU_AMT;
  }
  public void set_GRAD_INTR_ACU_AMT(java.math.BigDecimal GRAD_INTR_ACU_AMT) {
    this.GRAD_INTR_ACU_AMT = GRAD_INTR_ACU_AMT;
  }
  public QueryResult with_GRAD_INTR_ACU_AMT(java.math.BigDecimal GRAD_INTR_ACU_AMT) {
    this.GRAD_INTR_ACU_AMT = GRAD_INTR_ACU_AMT;
    return this;
  }
  private java.math.BigDecimal DFR_BGN_RDY_AMT;
  public java.math.BigDecimal get_DFR_BGN_RDY_AMT() {
    return DFR_BGN_RDY_AMT;
  }
  public void set_DFR_BGN_RDY_AMT(java.math.BigDecimal DFR_BGN_RDY_AMT) {
    this.DFR_BGN_RDY_AMT = DFR_BGN_RDY_AMT;
  }
  public QueryResult with_DFR_BGN_RDY_AMT(java.math.BigDecimal DFR_BGN_RDY_AMT) {
    this.DFR_BGN_RDY_AMT = DFR_BGN_RDY_AMT;
    return this;
  }
  private java.math.BigDecimal ACU_UNRPD_ACQ_EXP;
  public java.math.BigDecimal get_ACU_UNRPD_ACQ_EXP() {
    return ACU_UNRPD_ACQ_EXP;
  }
  public void set_ACU_UNRPD_ACQ_EXP(java.math.BigDecimal ACU_UNRPD_ACQ_EXP) {
    this.ACU_UNRPD_ACQ_EXP = ACU_UNRPD_ACQ_EXP;
  }
  public QueryResult with_ACU_UNRPD_ACQ_EXP(java.math.BigDecimal ACU_UNRPD_ACQ_EXP) {
    this.ACU_UNRPD_ACQ_EXP = ACU_UNRPD_ACQ_EXP;
    return this;
  }
  private java.math.BigDecimal PAY_TT_FINC_AMT;
  public java.math.BigDecimal get_PAY_TT_FINC_AMT() {
    return PAY_TT_FINC_AMT;
  }
  public void set_PAY_TT_FINC_AMT(java.math.BigDecimal PAY_TT_FINC_AMT) {
    this.PAY_TT_FINC_AMT = PAY_TT_FINC_AMT;
  }
  public QueryResult with_PAY_TT_FINC_AMT(java.math.BigDecimal PAY_TT_FINC_AMT) {
    this.PAY_TT_FINC_AMT = PAY_TT_FINC_AMT;
    return this;
  }
  private java.math.BigDecimal NRM_INTR_MID_AMT;
  public java.math.BigDecimal get_NRM_INTR_MID_AMT() {
    return NRM_INTR_MID_AMT;
  }
  public void set_NRM_INTR_MID_AMT(java.math.BigDecimal NRM_INTR_MID_AMT) {
    this.NRM_INTR_MID_AMT = NRM_INTR_MID_AMT;
  }
  public QueryResult with_NRM_INTR_MID_AMT(java.math.BigDecimal NRM_INTR_MID_AMT) {
    this.NRM_INTR_MID_AMT = NRM_INTR_MID_AMT;
    return this;
  }
  private java.math.BigDecimal GRAD_INTR_MID_AMT;
  public java.math.BigDecimal get_GRAD_INTR_MID_AMT() {
    return GRAD_INTR_MID_AMT;
  }
  public void set_GRAD_INTR_MID_AMT(java.math.BigDecimal GRAD_INTR_MID_AMT) {
    this.GRAD_INTR_MID_AMT = GRAD_INTR_MID_AMT;
  }
  public QueryResult with_GRAD_INTR_MID_AMT(java.math.BigDecimal GRAD_INTR_MID_AMT) {
    this.GRAD_INTR_MID_AMT = GRAD_INTR_MID_AMT;
    return this;
  }
  private java.math.BigDecimal NRM_INTR_ALTN_PY_PREM;
  public java.math.BigDecimal get_NRM_INTR_ALTN_PY_PREM() {
    return NRM_INTR_ALTN_PY_PREM;
  }
  public void set_NRM_INTR_ALTN_PY_PREM(java.math.BigDecimal NRM_INTR_ALTN_PY_PREM) {
    this.NRM_INTR_ALTN_PY_PREM = NRM_INTR_ALTN_PY_PREM;
  }
  public QueryResult with_NRM_INTR_ALTN_PY_PREM(java.math.BigDecimal NRM_INTR_ALTN_PY_PREM) {
    this.NRM_INTR_ALTN_PY_PREM = NRM_INTR_ALTN_PY_PREM;
    return this;
  }
  private java.math.BigDecimal GRAD_INTR_ALTN_PY_PREM;
  public java.math.BigDecimal get_GRAD_INTR_ALTN_PY_PREM() {
    return GRAD_INTR_ALTN_PY_PREM;
  }
  public void set_GRAD_INTR_ALTN_PY_PREM(java.math.BigDecimal GRAD_INTR_ALTN_PY_PREM) {
    this.GRAD_INTR_ALTN_PY_PREM = GRAD_INTR_ALTN_PY_PREM;
  }
  public QueryResult with_GRAD_INTR_ALTN_PY_PREM(java.math.BigDecimal GRAD_INTR_ALTN_PY_PREM) {
    this.GRAD_INTR_ALTN_PY_PREM = GRAD_INTR_ALTN_PY_PREM;
    return this;
  }
  private java.math.BigDecimal LPS_IAMT_RT;
  public java.math.BigDecimal get_LPS_IAMT_RT() {
    return LPS_IAMT_RT;
  }
  public void set_LPS_IAMT_RT(java.math.BigDecimal LPS_IAMT_RT) {
    this.LPS_IAMT_RT = LPS_IAMT_RT;
  }
  public QueryResult with_LPS_IAMT_RT(java.math.BigDecimal LPS_IAMT_RT) {
    this.LPS_IAMT_RT = LPS_IAMT_RT;
    return this;
  }
  private java.math.BigDecimal LPS_IAMT;
  public java.math.BigDecimal get_LPS_IAMT() {
    return LPS_IAMT;
  }
  public void set_LPS_IAMT(java.math.BigDecimal LPS_IAMT) {
    this.LPS_IAMT = LPS_IAMT;
  }
  public QueryResult with_LPS_IAMT(java.math.BigDecimal LPS_IAMT) {
    this.LPS_IAMT = LPS_IAMT;
    return this;
  }
  private java.math.BigDecimal PRPY_RDY_AMT;
  public java.math.BigDecimal get_PRPY_RDY_AMT() {
    return PRPY_RDY_AMT;
  }
  public void set_PRPY_RDY_AMT(java.math.BigDecimal PRPY_RDY_AMT) {
    this.PRPY_RDY_AMT = PRPY_RDY_AMT;
  }
  public QueryResult with_PRPY_RDY_AMT(java.math.BigDecimal PRPY_RDY_AMT) {
    this.PRPY_RDY_AMT = PRPY_RDY_AMT;
    return this;
  }
  private java.math.BigDecimal PRPY_IAMT;
  public java.math.BigDecimal get_PRPY_IAMT() {
    return PRPY_IAMT;
  }
  public void set_PRPY_IAMT(java.math.BigDecimal PRPY_IAMT) {
    this.PRPY_IAMT = PRPY_IAMT;
  }
  public QueryResult with_PRPY_IAMT(java.math.BigDecimal PRPY_IAMT) {
    this.PRPY_IAMT = PRPY_IAMT;
    return this;
  }
  private java.math.BigDecimal PVCTR_RDY_AMT;
  public java.math.BigDecimal get_PVCTR_RDY_AMT() {
    return PVCTR_RDY_AMT;
  }
  public void set_PVCTR_RDY_AMT(java.math.BigDecimal PVCTR_RDY_AMT) {
    this.PVCTR_RDY_AMT = PVCTR_RDY_AMT;
  }
  public QueryResult with_PVCTR_RDY_AMT(java.math.BigDecimal PVCTR_RDY_AMT) {
    this.PVCTR_RDY_AMT = PVCTR_RDY_AMT;
    return this;
  }
  private java.math.BigDecimal NPTD_RDY_AMT;
  public java.math.BigDecimal get_NPTD_RDY_AMT() {
    return NPTD_RDY_AMT;
  }
  public void set_NPTD_RDY_AMT(java.math.BigDecimal NPTD_RDY_AMT) {
    this.NPTD_RDY_AMT = NPTD_RDY_AMT;
  }
  public QueryResult with_NPTD_RDY_AMT(java.math.BigDecimal NPTD_RDY_AMT) {
    this.NPTD_RDY_AMT = NPTD_RDY_AMT;
    return this;
  }
  private java.math.BigDecimal TMTD_RDY_AMT;
  public java.math.BigDecimal get_TMTD_RDY_AMT() {
    return TMTD_RDY_AMT;
  }
  public void set_TMTD_RDY_AMT(java.math.BigDecimal TMTD_RDY_AMT) {
    this.TMTD_RDY_AMT = TMTD_RDY_AMT;
  }
  public QueryResult with_TMTD_RDY_AMT(java.math.BigDecimal TMTD_RDY_AMT) {
    this.TMTD_RDY_AMT = TMTD_RDY_AMT;
    return this;
  }
  private java.math.BigDecimal CNTD_RDY_AMT;
  public java.math.BigDecimal get_CNTD_RDY_AMT() {
    return CNTD_RDY_AMT;
  }
  public void set_CNTD_RDY_AMT(java.math.BigDecimal CNTD_RDY_AMT) {
    this.CNTD_RDY_AMT = CNTD_RDY_AMT;
  }
  public QueryResult with_CNTD_RDY_AMT(java.math.BigDecimal CNTD_RDY_AMT) {
    this.CNTD_RDY_AMT = CNTD_RDY_AMT;
    return this;
  }
  private java.math.BigDecimal APL_CNTD_RDY_AMT;
  public java.math.BigDecimal get_APL_CNTD_RDY_AMT() {
    return APL_CNTD_RDY_AMT;
  }
  public void set_APL_CNTD_RDY_AMT(java.math.BigDecimal APL_CNTD_RDY_AMT) {
    this.APL_CNTD_RDY_AMT = APL_CNTD_RDY_AMT;
  }
  public QueryResult with_APL_CNTD_RDY_AMT(java.math.BigDecimal APL_CNTD_RDY_AMT) {
    this.APL_CNTD_RDY_AMT = APL_CNTD_RDY_AMT;
    return this;
  }
  private java.math.BigDecimal STND_CNTD_RDY_AMT;
  public java.math.BigDecimal get_STND_CNTD_RDY_AMT() {
    return STND_CNTD_RDY_AMT;
  }
  public void set_STND_CNTD_RDY_AMT(java.math.BigDecimal STND_CNTD_RDY_AMT) {
    this.STND_CNTD_RDY_AMT = STND_CNTD_RDY_AMT;
  }
  public QueryResult with_STND_CNTD_RDY_AMT(java.math.BigDecimal STND_CNTD_RDY_AMT) {
    this.STND_CNTD_RDY_AMT = STND_CNTD_RDY_AMT;
    return this;
  }
  private java.math.BigDecimal COV_SLZ_PREM;
  public java.math.BigDecimal get_COV_SLZ_PREM() {
    return COV_SLZ_PREM;
  }
  public void set_COV_SLZ_PREM(java.math.BigDecimal COV_SLZ_PREM) {
    this.COV_SLZ_PREM = COV_SLZ_PREM;
  }
  public QueryResult with_COV_SLZ_PREM(java.math.BigDecimal COV_SLZ_PREM) {
    this.COV_SLZ_PREM = COV_SLZ_PREM;
    return this;
  }
  private java.sql.Timestamp CAL_DT;
  public java.sql.Timestamp get_CAL_DT() {
    return CAL_DT;
  }
  public void set_CAL_DT(java.sql.Timestamp CAL_DT) {
    this.CAL_DT = CAL_DT;
  }
  public QueryResult with_CAL_DT(java.sql.Timestamp CAL_DT) {
    this.CAL_DT = CAL_DT;
    return this;
  }
  private java.math.BigDecimal NITR_ACU_COV_PPI;
  public java.math.BigDecimal get_NITR_ACU_COV_PPI() {
    return NITR_ACU_COV_PPI;
  }
  public void set_NITR_ACU_COV_PPI(java.math.BigDecimal NITR_ACU_COV_PPI) {
    this.NITR_ACU_COV_PPI = NITR_ACU_COV_PPI;
  }
  public QueryResult with_NITR_ACU_COV_PPI(java.math.BigDecimal NITR_ACU_COV_PPI) {
    this.NITR_ACU_COV_PPI = NITR_ACU_COV_PPI;
    return this;
  }
  private java.math.BigDecimal GITR_ACU_COV_PPI;
  public java.math.BigDecimal get_GITR_ACU_COV_PPI() {
    return GITR_ACU_COV_PPI;
  }
  public void set_GITR_ACU_COV_PPI(java.math.BigDecimal GITR_ACU_COV_PPI) {
    this.GITR_ACU_COV_PPI = GITR_ACU_COV_PPI;
  }
  public QueryResult with_GITR_ACU_COV_PPI(java.math.BigDecimal GITR_ACU_COV_PPI) {
    this.GITR_ACU_COV_PPI = GITR_ACU_COV_PPI;
    return this;
  }
  private java.math.BigDecimal LWRT_TMN_RFD_RT;
  public java.math.BigDecimal get_LWRT_TMN_RFD_RT() {
    return LWRT_TMN_RFD_RT;
  }
  public void set_LWRT_TMN_RFD_RT(java.math.BigDecimal LWRT_TMN_RFD_RT) {
    this.LWRT_TMN_RFD_RT = LWRT_TMN_RFD_RT;
  }
  public QueryResult with_LWRT_TMN_RFD_RT(java.math.BigDecimal LWRT_TMN_RFD_RT) {
    this.LWRT_TMN_RFD_RT = LWRT_TMN_RFD_RT;
    return this;
  }
  private java.math.BigDecimal STY_XACQ_EXP_TAMT;
  public java.math.BigDecimal get_STY_XACQ_EXP_TAMT() {
    return STY_XACQ_EXP_TAMT;
  }
  public void set_STY_XACQ_EXP_TAMT(java.math.BigDecimal STY_XACQ_EXP_TAMT) {
    this.STY_XACQ_EXP_TAMT = STY_XACQ_EXP_TAMT;
  }
  public QueryResult with_STY_XACQ_EXP_TAMT(java.math.BigDecimal STY_XACQ_EXP_TAMT) {
    this.STY_XACQ_EXP_TAMT = STY_XACQ_EXP_TAMT;
    return this;
  }
  private java.math.BigDecimal STY_STND_ACQ_EXP_TAMT;
  public java.math.BigDecimal get_STY_STND_ACQ_EXP_TAMT() {
    return STY_STND_ACQ_EXP_TAMT;
  }
  public void set_STY_STND_ACQ_EXP_TAMT(java.math.BigDecimal STY_STND_ACQ_EXP_TAMT) {
    this.STY_STND_ACQ_EXP_TAMT = STY_STND_ACQ_EXP_TAMT;
  }
  public QueryResult with_STY_STND_ACQ_EXP_TAMT(java.math.BigDecimal STY_STND_ACQ_EXP_TAMT) {
    this.STY_STND_ACQ_EXP_TAMT = STY_STND_ACQ_EXP_TAMT;
    return this;
  }
  private java.math.BigDecimal STY_GURT_URPAE;
  public java.math.BigDecimal get_STY_GURT_URPAE() {
    return STY_GURT_URPAE;
  }
  public void set_STY_GURT_URPAE(java.math.BigDecimal STY_GURT_URPAE) {
    this.STY_GURT_URPAE = STY_GURT_URPAE;
  }
  public QueryResult with_STY_GURT_URPAE(java.math.BigDecimal STY_GURT_URPAE) {
    this.STY_GURT_URPAE = STY_GURT_URPAE;
    return this;
  }
  private java.math.BigDecimal STY_STND_URPAE;
  public java.math.BigDecimal get_STY_STND_URPAE() {
    return STY_STND_URPAE;
  }
  public void set_STY_STND_URPAE(java.math.BigDecimal STY_STND_URPAE) {
    this.STY_STND_URPAE = STY_STND_URPAE;
  }
  public QueryResult with_STY_STND_URPAE(java.math.BigDecimal STY_STND_URPAE) {
    this.STY_STND_URPAE = STY_STND_URPAE;
    return this;
  }
  private java.math.BigDecimal TMTD_LPS_IAMT;
  public java.math.BigDecimal get_TMTD_LPS_IAMT() {
    return TMTD_LPS_IAMT;
  }
  public void set_TMTD_LPS_IAMT(java.math.BigDecimal TMTD_LPS_IAMT) {
    this.TMTD_LPS_IAMT = TMTD_LPS_IAMT;
  }
  public QueryResult with_TMTD_LPS_IAMT(java.math.BigDecimal TMTD_LPS_IAMT) {
    this.TMTD_LPS_IAMT = TMTD_LPS_IAMT;
    return this;
  }
  private String RNWL_ED_PRD_DIV_CD;
  public String get_RNWL_ED_PRD_DIV_CD() {
    return RNWL_ED_PRD_DIV_CD;
  }
  public void set_RNWL_ED_PRD_DIV_CD(String RNWL_ED_PRD_DIV_CD) {
    this.RNWL_ED_PRD_DIV_CD = RNWL_ED_PRD_DIV_CD;
  }
  public QueryResult with_RNWL_ED_PRD_DIV_CD(String RNWL_ED_PRD_DIV_CD) {
    this.RNWL_ED_PRD_DIV_CD = RNWL_ED_PRD_DIV_CD;
    return this;
  }
  private java.math.BigDecimal RNWL_ED_PRD;
  public java.math.BigDecimal get_RNWL_ED_PRD() {
    return RNWL_ED_PRD;
  }
  public void set_RNWL_ED_PRD(java.math.BigDecimal RNWL_ED_PRD) {
    this.RNWL_ED_PRD = RNWL_ED_PRD;
  }
  public QueryResult with_RNWL_ED_PRD(java.math.BigDecimal RNWL_ED_PRD) {
    this.RNWL_ED_PRD = RNWL_ED_PRD;
    return this;
  }
  private java.math.BigDecimal RNWL_ED_AGE;
  public java.math.BigDecimal get_RNWL_ED_AGE() {
    return RNWL_ED_AGE;
  }
  public void set_RNWL_ED_AGE(java.math.BigDecimal RNWL_ED_AGE) {
    this.RNWL_ED_AGE = RNWL_ED_AGE;
  }
  public QueryResult with_RNWL_ED_AGE(java.math.BigDecimal RNWL_ED_AGE) {
    this.RNWL_ED_AGE = RNWL_ED_AGE;
    return this;
  }
  private java.sql.Timestamp RNWL_ED_DT;
  public java.sql.Timestamp get_RNWL_ED_DT() {
    return RNWL_ED_DT;
  }
  public void set_RNWL_ED_DT(java.sql.Timestamp RNWL_ED_DT) {
    this.RNWL_ED_DT = RNWL_ED_DT;
  }
  public QueryResult with_RNWL_ED_DT(java.sql.Timestamp RNWL_ED_DT) {
    this.RNWL_ED_DT = RNWL_ED_DT;
    return this;
  }
  private java.math.BigDecimal RNWL_TMS;
  public java.math.BigDecimal get_RNWL_TMS() {
    return RNWL_TMS;
  }
  public void set_RNWL_TMS(java.math.BigDecimal RNWL_TMS) {
    this.RNWL_TMS = RNWL_TMS;
  }
  public QueryResult with_RNWL_TMS(java.math.BigDecimal RNWL_TMS) {
    this.RNWL_TMS = RNWL_TMS;
    return this;
  }
  private java.math.BigDecimal STD_SBC_AMT;
  public java.math.BigDecimal get_STD_SBC_AMT() {
    return STD_SBC_AMT;
  }
  public void set_STD_SBC_AMT(java.math.BigDecimal STD_SBC_AMT) {
    this.STD_SBC_AMT = STD_SBC_AMT;
  }
  public QueryResult with_STD_SBC_AMT(java.math.BigDecimal STD_SBC_AMT) {
    this.STD_SBC_AMT = STD_SBC_AMT;
    return this;
  }
  private java.sql.Timestamp EIH_LDG_DTM;
  public java.sql.Timestamp get_EIH_LDG_DTM() {
    return EIH_LDG_DTM;
  }
  public void set_EIH_LDG_DTM(java.sql.Timestamp EIH_LDG_DTM) {
    this.EIH_LDG_DTM = EIH_LDG_DTM;
  }
  public QueryResult with_EIH_LDG_DTM(java.sql.Timestamp EIH_LDG_DTM) {
    this.EIH_LDG_DTM = EIH_LDG_DTM;
    return this;
  }
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (!(o instanceof QueryResult)) {
      return false;
    }
    QueryResult that = (QueryResult) o;
    boolean equal = true;
    equal = equal && (this.CLOG_YYMM == null ? that.CLOG_YYMM == null : this.CLOG_YYMM.equals(that.CLOG_YYMM));
    equal = equal && (this.CTR_ID == null ? that.CTR_ID == null : this.CTR_ID.equals(that.CTR_ID));
    equal = equal && (this.CTR_COV_ID == null ? that.CTR_COV_ID == null : this.CTR_COV_ID.equals(that.CTR_COV_ID));
    equal = equal && (this.POL_NO == null ? that.POL_NO == null : this.POL_NO.equals(that.POL_NO));
    equal = equal && (this.CTR_OBJ_ID == null ? that.CTR_OBJ_ID == null : this.CTR_OBJ_ID.equals(that.CTR_OBJ_ID));
    equal = equal && (this.PD_CD == null ? that.PD_CD == null : this.PD_CD.equals(that.PD_CD));
    equal = equal && (this.COV_CD == null ? that.COV_CD == null : this.COV_CD.equals(that.COV_CD));
    equal = equal && (this.LAST_PY_YYMM == null ? that.LAST_PY_YYMM == null : this.LAST_PY_YYMM.equals(that.LAST_PY_YYMM));
    equal = equal && (this.CTR_STAT_CD == null ? that.CTR_STAT_CD == null : this.CTR_STAT_CD.equals(that.CTR_STAT_CD));
    equal = equal && (this.CTR_STAT_DTL_CD == null ? that.CTR_STAT_DTL_CD == null : this.CTR_STAT_DTL_CD.equals(that.CTR_STAT_DTL_CD));
    equal = equal && (this.GURT_ACU_DIV_CD == null ? that.GURT_ACU_DIV_CD == null : this.GURT_ACU_DIV_CD.equals(that.GURT_ACU_DIV_CD));
    equal = equal && (this.CTR_COV_STAT_CD == null ? that.CTR_COV_STAT_CD == null : this.CTR_COV_STAT_CD.equals(that.CTR_COV_STAT_CD));
    equal = equal && (this.CTR_COV_STAT_DTL_CD == null ? that.CTR_COV_STAT_DTL_CD == null : this.CTR_COV_STAT_DTL_CD.equals(that.CTR_COV_STAT_DTL_CD));
    equal = equal && (this.COV_BGN_DT == null ? that.COV_BGN_DT == null : this.COV_BGN_DT.equals(that.COV_BGN_DT));
    equal = equal && (this.COV_ED_DT == null ? that.COV_ED_DT == null : this.COV_ED_DT.equals(that.COV_ED_DT));
    equal = equal && (this.COV_PY_ST_DT == null ? that.COV_PY_ST_DT == null : this.COV_PY_ST_DT.equals(that.COV_PY_ST_DT));
    equal = equal && (this.COV_PY_ED_DT == null ? that.COV_PY_ED_DT == null : this.COV_PY_ED_DT.equals(that.COV_PY_ED_DT));
    equal = equal && (this.COV_PY_CYC_CD == null ? that.COV_PY_CYC_CD == null : this.COV_PY_CYC_CD.equals(that.COV_PY_CYC_CD));
    equal = equal && (this.COV_INS_PRD_TP_CD == null ? that.COV_INS_PRD_TP_CD == null : this.COV_INS_PRD_TP_CD.equals(that.COV_INS_PRD_TP_CD));
    equal = equal && (this.COV_PY_PRD_TP_CD == null ? that.COV_PY_PRD_TP_CD == null : this.COV_PY_PRD_TP_CD.equals(that.COV_PY_PRD_TP_CD));
    equal = equal && (this.COV_INS_PRD == null ? that.COV_INS_PRD == null : this.COV_INS_PRD.equals(that.COV_INS_PRD));
    equal = equal && (this.COV_PY_PRD == null ? that.COV_PY_PRD == null : this.COV_PY_PRD.equals(that.COV_PY_PRD));
    equal = equal && (this.INS_AGE == null ? that.INS_AGE == null : this.INS_AGE.equals(that.INS_AGE));
    equal = equal && (this.FULL_AGE == null ? that.FULL_AGE == null : this.FULL_AGE.equals(that.FULL_AGE));
    equal = equal && (this.PY_ED_AGE == null ? that.PY_ED_AGE == null : this.PY_ED_AGE.equals(that.PY_ED_AGE));
    equal = equal && (this.INS_ED_AGE == null ? that.INS_ED_AGE == null : this.INS_ED_AGE.equals(that.INS_ED_AGE));
    equal = equal && (this.MOM_PD_CD == null ? that.MOM_PD_CD == null : this.MOM_PD_CD.equals(that.MOM_PD_CD));
    equal = equal && (this.MOM_COV_CD == null ? that.MOM_COV_CD == null : this.MOM_COV_CD.equals(that.MOM_COV_CD));
    equal = equal && (this.INSD_AMT == null ? that.INSD_AMT == null : this.INSD_AMT.equals(that.INSD_AMT));
    equal = equal && (this.APL_PREM == null ? that.APL_PREM == null : this.APL_PREM.equals(that.APL_PREM));
    equal = equal && (this.BAS_PREM == null ? that.BAS_PREM == null : this.BAS_PREM.equals(that.BAS_PREM));
    equal = equal && (this.KEY_COV_SEQ == null ? that.KEY_COV_SEQ == null : this.KEY_COV_SEQ.equals(that.KEY_COV_SEQ));
    equal = equal && (this.KEY_HIS_SEQ == null ? that.KEY_HIS_SEQ == null : this.KEY_HIS_SEQ.equals(that.KEY_HIS_SEQ));
    equal = equal && (this.RKEY_CNFG_CHT_VAL == null ? that.RKEY_CNFG_CHT_VAL == null : this.RKEY_CNFG_CHT_VAL.equals(that.RKEY_CNFG_CHT_VAL));
    equal = equal && (this.BKEY_CNFG_CHT_VAL == null ? that.BKEY_CNFG_CHT_VAL == null : this.BKEY_CNFG_CHT_VAL.equals(that.BKEY_CNFG_CHT_VAL));
    equal = equal && (this.XCHG_CF1 == null ? that.XCHG_CF1 == null : this.XCHG_CF1.equals(that.XCHG_CF1));
    equal = equal && (this.XCHG_CF2 == null ? that.XCHG_CF2 == null : this.XCHG_CF2.equals(that.XCHG_CF2));
    equal = equal && (this.XCHG_CF3 == null ? that.XCHG_CF3 == null : this.XCHG_CF3.equals(that.XCHG_CF3));
    equal = equal && (this.XCHG_CF4 == null ? that.XCHG_CF4 == null : this.XCHG_CF4.equals(that.XCHG_CF4));
    equal = equal && (this.XCHG_CF5 == null ? that.XCHG_CF5 == null : this.XCHG_CF5.equals(that.XCHG_CF5));
    equal = equal && (this.ACU_PREM_DIV_CD == null ? that.ACU_PREM_DIV_CD == null : this.ACU_PREM_DIV_CD.equals(that.ACU_PREM_DIV_CD));
    equal = equal && (this.PY_EXEM_ST_DT == null ? that.PY_EXEM_ST_DT == null : this.PY_EXEM_ST_DT.equals(that.PY_EXEM_ST_DT));
    equal = equal && (this.ELP_YR_NUM == null ? that.ELP_YR_NUM == null : this.ELP_YR_NUM.equals(that.ELP_YR_NUM));
    equal = equal && (this.ELP_MM_NUM == null ? that.ELP_MM_NUM == null : this.ELP_MM_NUM.equals(that.ELP_MM_NUM));
    equal = equal && (this.TT_ELP_MM_NUM == null ? that.TT_ELP_MM_NUM == null : this.TT_ELP_MM_NUM.equals(that.TT_ELP_MM_NUM));
    equal = equal && (this.UNPSS_MM_NUM == null ? that.UNPSS_MM_NUM == null : this.UNPSS_MM_NUM.equals(that.UNPSS_MM_NUM));
    equal = equal && (this.CMPT_STD_DT == null ? that.CMPT_STD_DT == null : this.CMPT_STD_DT.equals(that.CMPT_STD_DT));
    equal = equal && (this.PRPY_TIMS == null ? that.PRPY_TIMS == null : this.PRPY_TIMS.equals(that.PRPY_TIMS));
    equal = equal && (this.LPS_DT == null ? that.LPS_DT == null : this.LPS_DT.equals(that.LPS_DT));
    equal = equal && (this.EXPC_LPS_DT == null ? that.EXPC_LPS_DT == null : this.EXPC_LPS_DT.equals(that.EXPC_LPS_DT));
    equal = equal && (this.PRDCH_ENDR_HIS_STD_NO == null ? that.PRDCH_ENDR_HIS_STD_NO == null : this.PRDCH_ENDR_HIS_STD_NO.equals(that.PRDCH_ENDR_HIS_STD_NO));
    equal = equal && (this.PREM_ENDR_HIS_STD_NO == null ? that.PREM_ENDR_HIS_STD_NO == null : this.PREM_ENDR_HIS_STD_NO.equals(that.PREM_ENDR_HIS_STD_NO));
    equal = equal && (this.APL_NPTD_RDY_AMT == null ? that.APL_NPTD_RDY_AMT == null : this.APL_NPTD_RDY_AMT.equals(that.APL_NPTD_RDY_AMT));
    equal = equal && (this.STND_NPTD_RDY_AMT == null ? that.STND_NPTD_RDY_AMT == null : this.STND_NPTD_RDY_AMT.equals(that.STND_NPTD_RDY_AMT));
    equal = equal && (this.APL_TMTD_RDY_AMT == null ? that.APL_TMTD_RDY_AMT == null : this.APL_TMTD_RDY_AMT.equals(that.APL_TMTD_RDY_AMT));
    equal = equal && (this.STND_TMTD_RDY_AMT == null ? that.STND_TMTD_RDY_AMT == null : this.STND_TMTD_RDY_AMT.equals(that.STND_TMTD_RDY_AMT));
    equal = equal && (this.UNPSS_PREM == null ? that.UNPSS_PREM == null : this.UNPSS_PREM.equals(that.UNPSS_PREM));
    equal = equal && (this.GURT_UNRPD_ACQ_EXP == null ? that.GURT_UNRPD_ACQ_EXP == null : this.GURT_UNRPD_ACQ_EXP.equals(that.GURT_UNRPD_ACQ_EXP));
    equal = equal && (this.XPT_ACQ_EXP_TAMT == null ? that.XPT_ACQ_EXP_TAMT == null : this.XPT_ACQ_EXP_TAMT.equals(that.XPT_ACQ_EXP_TAMT));
    equal = equal && (this.STND_ACQ_EXP_TAMT == null ? that.STND_ACQ_EXP_TAMT == null : this.STND_ACQ_EXP_TAMT.equals(that.STND_ACQ_EXP_TAMT));
    equal = equal && (this.NRM_INTR_ACU_AMT == null ? that.NRM_INTR_ACU_AMT == null : this.NRM_INTR_ACU_AMT.equals(that.NRM_INTR_ACU_AMT));
    equal = equal && (this.GRAD_INTR_ACU_AMT == null ? that.GRAD_INTR_ACU_AMT == null : this.GRAD_INTR_ACU_AMT.equals(that.GRAD_INTR_ACU_AMT));
    equal = equal && (this.DFR_BGN_RDY_AMT == null ? that.DFR_BGN_RDY_AMT == null : this.DFR_BGN_RDY_AMT.equals(that.DFR_BGN_RDY_AMT));
    equal = equal && (this.ACU_UNRPD_ACQ_EXP == null ? that.ACU_UNRPD_ACQ_EXP == null : this.ACU_UNRPD_ACQ_EXP.equals(that.ACU_UNRPD_ACQ_EXP));
    equal = equal && (this.PAY_TT_FINC_AMT == null ? that.PAY_TT_FINC_AMT == null : this.PAY_TT_FINC_AMT.equals(that.PAY_TT_FINC_AMT));
    equal = equal && (this.NRM_INTR_MID_AMT == null ? that.NRM_INTR_MID_AMT == null : this.NRM_INTR_MID_AMT.equals(that.NRM_INTR_MID_AMT));
    equal = equal && (this.GRAD_INTR_MID_AMT == null ? that.GRAD_INTR_MID_AMT == null : this.GRAD_INTR_MID_AMT.equals(that.GRAD_INTR_MID_AMT));
    equal = equal && (this.NRM_INTR_ALTN_PY_PREM == null ? that.NRM_INTR_ALTN_PY_PREM == null : this.NRM_INTR_ALTN_PY_PREM.equals(that.NRM_INTR_ALTN_PY_PREM));
    equal = equal && (this.GRAD_INTR_ALTN_PY_PREM == null ? that.GRAD_INTR_ALTN_PY_PREM == null : this.GRAD_INTR_ALTN_PY_PREM.equals(that.GRAD_INTR_ALTN_PY_PREM));
    equal = equal && (this.LPS_IAMT_RT == null ? that.LPS_IAMT_RT == null : this.LPS_IAMT_RT.equals(that.LPS_IAMT_RT));
    equal = equal && (this.LPS_IAMT == null ? that.LPS_IAMT == null : this.LPS_IAMT.equals(that.LPS_IAMT));
    equal = equal && (this.PRPY_RDY_AMT == null ? that.PRPY_RDY_AMT == null : this.PRPY_RDY_AMT.equals(that.PRPY_RDY_AMT));
    equal = equal && (this.PRPY_IAMT == null ? that.PRPY_IAMT == null : this.PRPY_IAMT.equals(that.PRPY_IAMT));
    equal = equal && (this.PVCTR_RDY_AMT == null ? that.PVCTR_RDY_AMT == null : this.PVCTR_RDY_AMT.equals(that.PVCTR_RDY_AMT));
    equal = equal && (this.NPTD_RDY_AMT == null ? that.NPTD_RDY_AMT == null : this.NPTD_RDY_AMT.equals(that.NPTD_RDY_AMT));
    equal = equal && (this.TMTD_RDY_AMT == null ? that.TMTD_RDY_AMT == null : this.TMTD_RDY_AMT.equals(that.TMTD_RDY_AMT));
    equal = equal && (this.CNTD_RDY_AMT == null ? that.CNTD_RDY_AMT == null : this.CNTD_RDY_AMT.equals(that.CNTD_RDY_AMT));
    equal = equal && (this.APL_CNTD_RDY_AMT == null ? that.APL_CNTD_RDY_AMT == null : this.APL_CNTD_RDY_AMT.equals(that.APL_CNTD_RDY_AMT));
    equal = equal && (this.STND_CNTD_RDY_AMT == null ? that.STND_CNTD_RDY_AMT == null : this.STND_CNTD_RDY_AMT.equals(that.STND_CNTD_RDY_AMT));
    equal = equal && (this.COV_SLZ_PREM == null ? that.COV_SLZ_PREM == null : this.COV_SLZ_PREM.equals(that.COV_SLZ_PREM));
    equal = equal && (this.CAL_DT == null ? that.CAL_DT == null : this.CAL_DT.equals(that.CAL_DT));
    equal = equal && (this.NITR_ACU_COV_PPI == null ? that.NITR_ACU_COV_PPI == null : this.NITR_ACU_COV_PPI.equals(that.NITR_ACU_COV_PPI));
    equal = equal && (this.GITR_ACU_COV_PPI == null ? that.GITR_ACU_COV_PPI == null : this.GITR_ACU_COV_PPI.equals(that.GITR_ACU_COV_PPI));
    equal = equal && (this.LWRT_TMN_RFD_RT == null ? that.LWRT_TMN_RFD_RT == null : this.LWRT_TMN_RFD_RT.equals(that.LWRT_TMN_RFD_RT));
    equal = equal && (this.STY_XACQ_EXP_TAMT == null ? that.STY_XACQ_EXP_TAMT == null : this.STY_XACQ_EXP_TAMT.equals(that.STY_XACQ_EXP_TAMT));
    equal = equal && (this.STY_STND_ACQ_EXP_TAMT == null ? that.STY_STND_ACQ_EXP_TAMT == null : this.STY_STND_ACQ_EXP_TAMT.equals(that.STY_STND_ACQ_EXP_TAMT));
    equal = equal && (this.STY_GURT_URPAE == null ? that.STY_GURT_URPAE == null : this.STY_GURT_URPAE.equals(that.STY_GURT_URPAE));
    equal = equal && (this.STY_STND_URPAE == null ? that.STY_STND_URPAE == null : this.STY_STND_URPAE.equals(that.STY_STND_URPAE));
    equal = equal && (this.TMTD_LPS_IAMT == null ? that.TMTD_LPS_IAMT == null : this.TMTD_LPS_IAMT.equals(that.TMTD_LPS_IAMT));
    equal = equal && (this.RNWL_ED_PRD_DIV_CD == null ? that.RNWL_ED_PRD_DIV_CD == null : this.RNWL_ED_PRD_DIV_CD.equals(that.RNWL_ED_PRD_DIV_CD));
    equal = equal && (this.RNWL_ED_PRD == null ? that.RNWL_ED_PRD == null : this.RNWL_ED_PRD.equals(that.RNWL_ED_PRD));
    equal = equal && (this.RNWL_ED_AGE == null ? that.RNWL_ED_AGE == null : this.RNWL_ED_AGE.equals(that.RNWL_ED_AGE));
    equal = equal && (this.RNWL_ED_DT == null ? that.RNWL_ED_DT == null : this.RNWL_ED_DT.equals(that.RNWL_ED_DT));
    equal = equal && (this.RNWL_TMS == null ? that.RNWL_TMS == null : this.RNWL_TMS.equals(that.RNWL_TMS));
    equal = equal && (this.STD_SBC_AMT == null ? that.STD_SBC_AMT == null : this.STD_SBC_AMT.equals(that.STD_SBC_AMT));
    equal = equal && (this.EIH_LDG_DTM == null ? that.EIH_LDG_DTM == null : this.EIH_LDG_DTM.equals(that.EIH_LDG_DTM));
    return equal;
  }
  public boolean equals0(Object o) {
    if (this == o) {
      return true;
    }
    if (!(o instanceof QueryResult)) {
      return false;
    }
    QueryResult that = (QueryResult) o;
    boolean equal = true;
    equal = equal && (this.CLOG_YYMM == null ? that.CLOG_YYMM == null : this.CLOG_YYMM.equals(that.CLOG_YYMM));
    equal = equal && (this.CTR_ID == null ? that.CTR_ID == null : this.CTR_ID.equals(that.CTR_ID));
    equal = equal && (this.CTR_COV_ID == null ? that.CTR_COV_ID == null : this.CTR_COV_ID.equals(that.CTR_COV_ID));
    equal = equal && (this.POL_NO == null ? that.POL_NO == null : this.POL_NO.equals(that.POL_NO));
    equal = equal && (this.CTR_OBJ_ID == null ? that.CTR_OBJ_ID == null : this.CTR_OBJ_ID.equals(that.CTR_OBJ_ID));
    equal = equal && (this.PD_CD == null ? that.PD_CD == null : this.PD_CD.equals(that.PD_CD));
    equal = equal && (this.COV_CD == null ? that.COV_CD == null : this.COV_CD.equals(that.COV_CD));
    equal = equal && (this.LAST_PY_YYMM == null ? that.LAST_PY_YYMM == null : this.LAST_PY_YYMM.equals(that.LAST_PY_YYMM));
    equal = equal && (this.CTR_STAT_CD == null ? that.CTR_STAT_CD == null : this.CTR_STAT_CD.equals(that.CTR_STAT_CD));
    equal = equal && (this.CTR_STAT_DTL_CD == null ? that.CTR_STAT_DTL_CD == null : this.CTR_STAT_DTL_CD.equals(that.CTR_STAT_DTL_CD));
    equal = equal && (this.GURT_ACU_DIV_CD == null ? that.GURT_ACU_DIV_CD == null : this.GURT_ACU_DIV_CD.equals(that.GURT_ACU_DIV_CD));
    equal = equal && (this.CTR_COV_STAT_CD == null ? that.CTR_COV_STAT_CD == null : this.CTR_COV_STAT_CD.equals(that.CTR_COV_STAT_CD));
    equal = equal && (this.CTR_COV_STAT_DTL_CD == null ? that.CTR_COV_STAT_DTL_CD == null : this.CTR_COV_STAT_DTL_CD.equals(that.CTR_COV_STAT_DTL_CD));
    equal = equal && (this.COV_BGN_DT == null ? that.COV_BGN_DT == null : this.COV_BGN_DT.equals(that.COV_BGN_DT));
    equal = equal && (this.COV_ED_DT == null ? that.COV_ED_DT == null : this.COV_ED_DT.equals(that.COV_ED_DT));
    equal = equal && (this.COV_PY_ST_DT == null ? that.COV_PY_ST_DT == null : this.COV_PY_ST_DT.equals(that.COV_PY_ST_DT));
    equal = equal && (this.COV_PY_ED_DT == null ? that.COV_PY_ED_DT == null : this.COV_PY_ED_DT.equals(that.COV_PY_ED_DT));
    equal = equal && (this.COV_PY_CYC_CD == null ? that.COV_PY_CYC_CD == null : this.COV_PY_CYC_CD.equals(that.COV_PY_CYC_CD));
    equal = equal && (this.COV_INS_PRD_TP_CD == null ? that.COV_INS_PRD_TP_CD == null : this.COV_INS_PRD_TP_CD.equals(that.COV_INS_PRD_TP_CD));
    equal = equal && (this.COV_PY_PRD_TP_CD == null ? that.COV_PY_PRD_TP_CD == null : this.COV_PY_PRD_TP_CD.equals(that.COV_PY_PRD_TP_CD));
    equal = equal && (this.COV_INS_PRD == null ? that.COV_INS_PRD == null : this.COV_INS_PRD.equals(that.COV_INS_PRD));
    equal = equal && (this.COV_PY_PRD == null ? that.COV_PY_PRD == null : this.COV_PY_PRD.equals(that.COV_PY_PRD));
    equal = equal && (this.INS_AGE == null ? that.INS_AGE == null : this.INS_AGE.equals(that.INS_AGE));
    equal = equal && (this.FULL_AGE == null ? that.FULL_AGE == null : this.FULL_AGE.equals(that.FULL_AGE));
    equal = equal && (this.PY_ED_AGE == null ? that.PY_ED_AGE == null : this.PY_ED_AGE.equals(that.PY_ED_AGE));
    equal = equal && (this.INS_ED_AGE == null ? that.INS_ED_AGE == null : this.INS_ED_AGE.equals(that.INS_ED_AGE));
    equal = equal && (this.MOM_PD_CD == null ? that.MOM_PD_CD == null : this.MOM_PD_CD.equals(that.MOM_PD_CD));
    equal = equal && (this.MOM_COV_CD == null ? that.MOM_COV_CD == null : this.MOM_COV_CD.equals(that.MOM_COV_CD));
    equal = equal && (this.INSD_AMT == null ? that.INSD_AMT == null : this.INSD_AMT.equals(that.INSD_AMT));
    equal = equal && (this.APL_PREM == null ? that.APL_PREM == null : this.APL_PREM.equals(that.APL_PREM));
    equal = equal && (this.BAS_PREM == null ? that.BAS_PREM == null : this.BAS_PREM.equals(that.BAS_PREM));
    equal = equal && (this.KEY_COV_SEQ == null ? that.KEY_COV_SEQ == null : this.KEY_COV_SEQ.equals(that.KEY_COV_SEQ));
    equal = equal && (this.KEY_HIS_SEQ == null ? that.KEY_HIS_SEQ == null : this.KEY_HIS_SEQ.equals(that.KEY_HIS_SEQ));
    equal = equal && (this.RKEY_CNFG_CHT_VAL == null ? that.RKEY_CNFG_CHT_VAL == null : this.RKEY_CNFG_CHT_VAL.equals(that.RKEY_CNFG_CHT_VAL));
    equal = equal && (this.BKEY_CNFG_CHT_VAL == null ? that.BKEY_CNFG_CHT_VAL == null : this.BKEY_CNFG_CHT_VAL.equals(that.BKEY_CNFG_CHT_VAL));
    equal = equal && (this.XCHG_CF1 == null ? that.XCHG_CF1 == null : this.XCHG_CF1.equals(that.XCHG_CF1));
    equal = equal && (this.XCHG_CF2 == null ? that.XCHG_CF2 == null : this.XCHG_CF2.equals(that.XCHG_CF2));
    equal = equal && (this.XCHG_CF3 == null ? that.XCHG_CF3 == null : this.XCHG_CF3.equals(that.XCHG_CF3));
    equal = equal && (this.XCHG_CF4 == null ? that.XCHG_CF4 == null : this.XCHG_CF4.equals(that.XCHG_CF4));
    equal = equal && (this.XCHG_CF5 == null ? that.XCHG_CF5 == null : this.XCHG_CF5.equals(that.XCHG_CF5));
    equal = equal && (this.ACU_PREM_DIV_CD == null ? that.ACU_PREM_DIV_CD == null : this.ACU_PREM_DIV_CD.equals(that.ACU_PREM_DIV_CD));
    equal = equal && (this.PY_EXEM_ST_DT == null ? that.PY_EXEM_ST_DT == null : this.PY_EXEM_ST_DT.equals(that.PY_EXEM_ST_DT));
    equal = equal && (this.ELP_YR_NUM == null ? that.ELP_YR_NUM == null : this.ELP_YR_NUM.equals(that.ELP_YR_NUM));
    equal = equal && (this.ELP_MM_NUM == null ? that.ELP_MM_NUM == null : this.ELP_MM_NUM.equals(that.ELP_MM_NUM));
    equal = equal && (this.TT_ELP_MM_NUM == null ? that.TT_ELP_MM_NUM == null : this.TT_ELP_MM_NUM.equals(that.TT_ELP_MM_NUM));
    equal = equal && (this.UNPSS_MM_NUM == null ? that.UNPSS_MM_NUM == null : this.UNPSS_MM_NUM.equals(that.UNPSS_MM_NUM));
    equal = equal && (this.CMPT_STD_DT == null ? that.CMPT_STD_DT == null : this.CMPT_STD_DT.equals(that.CMPT_STD_DT));
    equal = equal && (this.PRPY_TIMS == null ? that.PRPY_TIMS == null : this.PRPY_TIMS.equals(that.PRPY_TIMS));
    equal = equal && (this.LPS_DT == null ? that.LPS_DT == null : this.LPS_DT.equals(that.LPS_DT));
    equal = equal && (this.EXPC_LPS_DT == null ? that.EXPC_LPS_DT == null : this.EXPC_LPS_DT.equals(that.EXPC_LPS_DT));
    equal = equal && (this.PRDCH_ENDR_HIS_STD_NO == null ? that.PRDCH_ENDR_HIS_STD_NO == null : this.PRDCH_ENDR_HIS_STD_NO.equals(that.PRDCH_ENDR_HIS_STD_NO));
    equal = equal && (this.PREM_ENDR_HIS_STD_NO == null ? that.PREM_ENDR_HIS_STD_NO == null : this.PREM_ENDR_HIS_STD_NO.equals(that.PREM_ENDR_HIS_STD_NO));
    equal = equal && (this.APL_NPTD_RDY_AMT == null ? that.APL_NPTD_RDY_AMT == null : this.APL_NPTD_RDY_AMT.equals(that.APL_NPTD_RDY_AMT));
    equal = equal && (this.STND_NPTD_RDY_AMT == null ? that.STND_NPTD_RDY_AMT == null : this.STND_NPTD_RDY_AMT.equals(that.STND_NPTD_RDY_AMT));
    equal = equal && (this.APL_TMTD_RDY_AMT == null ? that.APL_TMTD_RDY_AMT == null : this.APL_TMTD_RDY_AMT.equals(that.APL_TMTD_RDY_AMT));
    equal = equal && (this.STND_TMTD_RDY_AMT == null ? that.STND_TMTD_RDY_AMT == null : this.STND_TMTD_RDY_AMT.equals(that.STND_TMTD_RDY_AMT));
    equal = equal && (this.UNPSS_PREM == null ? that.UNPSS_PREM == null : this.UNPSS_PREM.equals(that.UNPSS_PREM));
    equal = equal && (this.GURT_UNRPD_ACQ_EXP == null ? that.GURT_UNRPD_ACQ_EXP == null : this.GURT_UNRPD_ACQ_EXP.equals(that.GURT_UNRPD_ACQ_EXP));
    equal = equal && (this.XPT_ACQ_EXP_TAMT == null ? that.XPT_ACQ_EXP_TAMT == null : this.XPT_ACQ_EXP_TAMT.equals(that.XPT_ACQ_EXP_TAMT));
    equal = equal && (this.STND_ACQ_EXP_TAMT == null ? that.STND_ACQ_EXP_TAMT == null : this.STND_ACQ_EXP_TAMT.equals(that.STND_ACQ_EXP_TAMT));
    equal = equal && (this.NRM_INTR_ACU_AMT == null ? that.NRM_INTR_ACU_AMT == null : this.NRM_INTR_ACU_AMT.equals(that.NRM_INTR_ACU_AMT));
    equal = equal && (this.GRAD_INTR_ACU_AMT == null ? that.GRAD_INTR_ACU_AMT == null : this.GRAD_INTR_ACU_AMT.equals(that.GRAD_INTR_ACU_AMT));
    equal = equal && (this.DFR_BGN_RDY_AMT == null ? that.DFR_BGN_RDY_AMT == null : this.DFR_BGN_RDY_AMT.equals(that.DFR_BGN_RDY_AMT));
    equal = equal && (this.ACU_UNRPD_ACQ_EXP == null ? that.ACU_UNRPD_ACQ_EXP == null : this.ACU_UNRPD_ACQ_EXP.equals(that.ACU_UNRPD_ACQ_EXP));
    equal = equal && (this.PAY_TT_FINC_AMT == null ? that.PAY_TT_FINC_AMT == null : this.PAY_TT_FINC_AMT.equals(that.PAY_TT_FINC_AMT));
    equal = equal && (this.NRM_INTR_MID_AMT == null ? that.NRM_INTR_MID_AMT == null : this.NRM_INTR_MID_AMT.equals(that.NRM_INTR_MID_AMT));
    equal = equal && (this.GRAD_INTR_MID_AMT == null ? that.GRAD_INTR_MID_AMT == null : this.GRAD_INTR_MID_AMT.equals(that.GRAD_INTR_MID_AMT));
    equal = equal && (this.NRM_INTR_ALTN_PY_PREM == null ? that.NRM_INTR_ALTN_PY_PREM == null : this.NRM_INTR_ALTN_PY_PREM.equals(that.NRM_INTR_ALTN_PY_PREM));
    equal = equal && (this.GRAD_INTR_ALTN_PY_PREM == null ? that.GRAD_INTR_ALTN_PY_PREM == null : this.GRAD_INTR_ALTN_PY_PREM.equals(that.GRAD_INTR_ALTN_PY_PREM));
    equal = equal && (this.LPS_IAMT_RT == null ? that.LPS_IAMT_RT == null : this.LPS_IAMT_RT.equals(that.LPS_IAMT_RT));
    equal = equal && (this.LPS_IAMT == null ? that.LPS_IAMT == null : this.LPS_IAMT.equals(that.LPS_IAMT));
    equal = equal && (this.PRPY_RDY_AMT == null ? that.PRPY_RDY_AMT == null : this.PRPY_RDY_AMT.equals(that.PRPY_RDY_AMT));
    equal = equal && (this.PRPY_IAMT == null ? that.PRPY_IAMT == null : this.PRPY_IAMT.equals(that.PRPY_IAMT));
    equal = equal && (this.PVCTR_RDY_AMT == null ? that.PVCTR_RDY_AMT == null : this.PVCTR_RDY_AMT.equals(that.PVCTR_RDY_AMT));
    equal = equal && (this.NPTD_RDY_AMT == null ? that.NPTD_RDY_AMT == null : this.NPTD_RDY_AMT.equals(that.NPTD_RDY_AMT));
    equal = equal && (this.TMTD_RDY_AMT == null ? that.TMTD_RDY_AMT == null : this.TMTD_RDY_AMT.equals(that.TMTD_RDY_AMT));
    equal = equal && (this.CNTD_RDY_AMT == null ? that.CNTD_RDY_AMT == null : this.CNTD_RDY_AMT.equals(that.CNTD_RDY_AMT));
    equal = equal && (this.APL_CNTD_RDY_AMT == null ? that.APL_CNTD_RDY_AMT == null : this.APL_CNTD_RDY_AMT.equals(that.APL_CNTD_RDY_AMT));
    equal = equal && (this.STND_CNTD_RDY_AMT == null ? that.STND_CNTD_RDY_AMT == null : this.STND_CNTD_RDY_AMT.equals(that.STND_CNTD_RDY_AMT));
    equal = equal && (this.COV_SLZ_PREM == null ? that.COV_SLZ_PREM == null : this.COV_SLZ_PREM.equals(that.COV_SLZ_PREM));
    equal = equal && (this.CAL_DT == null ? that.CAL_DT == null : this.CAL_DT.equals(that.CAL_DT));
    equal = equal && (this.NITR_ACU_COV_PPI == null ? that.NITR_ACU_COV_PPI == null : this.NITR_ACU_COV_PPI.equals(that.NITR_ACU_COV_PPI));
    equal = equal && (this.GITR_ACU_COV_PPI == null ? that.GITR_ACU_COV_PPI == null : this.GITR_ACU_COV_PPI.equals(that.GITR_ACU_COV_PPI));
    equal = equal && (this.LWRT_TMN_RFD_RT == null ? that.LWRT_TMN_RFD_RT == null : this.LWRT_TMN_RFD_RT.equals(that.LWRT_TMN_RFD_RT));
    equal = equal && (this.STY_XACQ_EXP_TAMT == null ? that.STY_XACQ_EXP_TAMT == null : this.STY_XACQ_EXP_TAMT.equals(that.STY_XACQ_EXP_TAMT));
    equal = equal && (this.STY_STND_ACQ_EXP_TAMT == null ? that.STY_STND_ACQ_EXP_TAMT == null : this.STY_STND_ACQ_EXP_TAMT.equals(that.STY_STND_ACQ_EXP_TAMT));
    equal = equal && (this.STY_GURT_URPAE == null ? that.STY_GURT_URPAE == null : this.STY_GURT_URPAE.equals(that.STY_GURT_URPAE));
    equal = equal && (this.STY_STND_URPAE == null ? that.STY_STND_URPAE == null : this.STY_STND_URPAE.equals(that.STY_STND_URPAE));
    equal = equal && (this.TMTD_LPS_IAMT == null ? that.TMTD_LPS_IAMT == null : this.TMTD_LPS_IAMT.equals(that.TMTD_LPS_IAMT));
    equal = equal && (this.RNWL_ED_PRD_DIV_CD == null ? that.RNWL_ED_PRD_DIV_CD == null : this.RNWL_ED_PRD_DIV_CD.equals(that.RNWL_ED_PRD_DIV_CD));
    equal = equal && (this.RNWL_ED_PRD == null ? that.RNWL_ED_PRD == null : this.RNWL_ED_PRD.equals(that.RNWL_ED_PRD));
    equal = equal && (this.RNWL_ED_AGE == null ? that.RNWL_ED_AGE == null : this.RNWL_ED_AGE.equals(that.RNWL_ED_AGE));
    equal = equal && (this.RNWL_ED_DT == null ? that.RNWL_ED_DT == null : this.RNWL_ED_DT.equals(that.RNWL_ED_DT));
    equal = equal && (this.RNWL_TMS == null ? that.RNWL_TMS == null : this.RNWL_TMS.equals(that.RNWL_TMS));
    equal = equal && (this.STD_SBC_AMT == null ? that.STD_SBC_AMT == null : this.STD_SBC_AMT.equals(that.STD_SBC_AMT));
    equal = equal && (this.EIH_LDG_DTM == null ? that.EIH_LDG_DTM == null : this.EIH_LDG_DTM.equals(that.EIH_LDG_DTM));
    return equal;
  }
  public void readFields(ResultSet __dbResults) throws SQLException {
    this.__cur_result_set = __dbResults;
    this.CLOG_YYMM = JdbcWritableBridge.readString(1, __dbResults);
    this.CTR_ID = JdbcWritableBridge.readString(2, __dbResults);
    this.CTR_COV_ID = JdbcWritableBridge.readString(3, __dbResults);
    this.POL_NO = JdbcWritableBridge.readString(4, __dbResults);
    this.CTR_OBJ_ID = JdbcWritableBridge.readString(5, __dbResults);
    this.PD_CD = JdbcWritableBridge.readString(6, __dbResults);
    this.COV_CD = JdbcWritableBridge.readString(7, __dbResults);
    this.LAST_PY_YYMM = JdbcWritableBridge.readString(8, __dbResults);
    this.CTR_STAT_CD = JdbcWritableBridge.readString(9, __dbResults);
    this.CTR_STAT_DTL_CD = JdbcWritableBridge.readString(10, __dbResults);
    this.GURT_ACU_DIV_CD = JdbcWritableBridge.readString(11, __dbResults);
    this.CTR_COV_STAT_CD = JdbcWritableBridge.readString(12, __dbResults);
    this.CTR_COV_STAT_DTL_CD = JdbcWritableBridge.readString(13, __dbResults);
    this.COV_BGN_DT = JdbcWritableBridge.readTimestamp(14, __dbResults);
    this.COV_ED_DT = JdbcWritableBridge.readTimestamp(15, __dbResults);
    this.COV_PY_ST_DT = JdbcWritableBridge.readTimestamp(16, __dbResults);
    this.COV_PY_ED_DT = JdbcWritableBridge.readTimestamp(17, __dbResults);
    this.COV_PY_CYC_CD = JdbcWritableBridge.readString(18, __dbResults);
    this.COV_INS_PRD_TP_CD = JdbcWritableBridge.readString(19, __dbResults);
    this.COV_PY_PRD_TP_CD = JdbcWritableBridge.readString(20, __dbResults);
    this.COV_INS_PRD = JdbcWritableBridge.readBigDecimal(21, __dbResults);
    this.COV_PY_PRD = JdbcWritableBridge.readBigDecimal(22, __dbResults);
    this.INS_AGE = JdbcWritableBridge.readBigDecimal(23, __dbResults);
    this.FULL_AGE = JdbcWritableBridge.readBigDecimal(24, __dbResults);
    this.PY_ED_AGE = JdbcWritableBridge.readBigDecimal(25, __dbResults);
    this.INS_ED_AGE = JdbcWritableBridge.readBigDecimal(26, __dbResults);
    this.MOM_PD_CD = JdbcWritableBridge.readString(27, __dbResults);
    this.MOM_COV_CD = JdbcWritableBridge.readString(28, __dbResults);
    this.INSD_AMT = JdbcWritableBridge.readBigDecimal(29, __dbResults);
    this.APL_PREM = JdbcWritableBridge.readBigDecimal(30, __dbResults);
    this.BAS_PREM = JdbcWritableBridge.readBigDecimal(31, __dbResults);
    this.KEY_COV_SEQ = JdbcWritableBridge.readBigDecimal(32, __dbResults);
    this.KEY_HIS_SEQ = JdbcWritableBridge.readBigDecimal(33, __dbResults);
    this.RKEY_CNFG_CHT_VAL = JdbcWritableBridge.readString(34, __dbResults);
    this.BKEY_CNFG_CHT_VAL = JdbcWritableBridge.readString(35, __dbResults);
    this.XCHG_CF1 = JdbcWritableBridge.readBigDecimal(36, __dbResults);
    this.XCHG_CF2 = JdbcWritableBridge.readBigDecimal(37, __dbResults);
    this.XCHG_CF3 = JdbcWritableBridge.readBigDecimal(38, __dbResults);
    this.XCHG_CF4 = JdbcWritableBridge.readBigDecimal(39, __dbResults);
    this.XCHG_CF5 = JdbcWritableBridge.readBigDecimal(40, __dbResults);
    this.ACU_PREM_DIV_CD = JdbcWritableBridge.readString(41, __dbResults);
    this.PY_EXEM_ST_DT = JdbcWritableBridge.readTimestamp(42, __dbResults);
    this.ELP_YR_NUM = JdbcWritableBridge.readBigDecimal(43, __dbResults);
    this.ELP_MM_NUM = JdbcWritableBridge.readBigDecimal(44, __dbResults);
    this.TT_ELP_MM_NUM = JdbcWritableBridge.readBigDecimal(45, __dbResults);
    this.UNPSS_MM_NUM = JdbcWritableBridge.readBigDecimal(46, __dbResults);
    this.CMPT_STD_DT = JdbcWritableBridge.readTimestamp(47, __dbResults);
    this.PRPY_TIMS = JdbcWritableBridge.readBigDecimal(48, __dbResults);
    this.LPS_DT = JdbcWritableBridge.readTimestamp(49, __dbResults);
    this.EXPC_LPS_DT = JdbcWritableBridge.readTimestamp(50, __dbResults);
    this.PRDCH_ENDR_HIS_STD_NO = JdbcWritableBridge.readBigDecimal(51, __dbResults);
    this.PREM_ENDR_HIS_STD_NO = JdbcWritableBridge.readBigDecimal(52, __dbResults);
    this.APL_NPTD_RDY_AMT = JdbcWritableBridge.readBigDecimal(53, __dbResults);
    this.STND_NPTD_RDY_AMT = JdbcWritableBridge.readBigDecimal(54, __dbResults);
    this.APL_TMTD_RDY_AMT = JdbcWritableBridge.readBigDecimal(55, __dbResults);
    this.STND_TMTD_RDY_AMT = JdbcWritableBridge.readBigDecimal(56, __dbResults);
    this.UNPSS_PREM = JdbcWritableBridge.readBigDecimal(57, __dbResults);
    this.GURT_UNRPD_ACQ_EXP = JdbcWritableBridge.readBigDecimal(58, __dbResults);
    this.XPT_ACQ_EXP_TAMT = JdbcWritableBridge.readBigDecimal(59, __dbResults);
    this.STND_ACQ_EXP_TAMT = JdbcWritableBridge.readBigDecimal(60, __dbResults);
    this.NRM_INTR_ACU_AMT = JdbcWritableBridge.readBigDecimal(61, __dbResults);
    this.GRAD_INTR_ACU_AMT = JdbcWritableBridge.readBigDecimal(62, __dbResults);
    this.DFR_BGN_RDY_AMT = JdbcWritableBridge.readBigDecimal(63, __dbResults);
    this.ACU_UNRPD_ACQ_EXP = JdbcWritableBridge.readBigDecimal(64, __dbResults);
    this.PAY_TT_FINC_AMT = JdbcWritableBridge.readBigDecimal(65, __dbResults);
    this.NRM_INTR_MID_AMT = JdbcWritableBridge.readBigDecimal(66, __dbResults);
    this.GRAD_INTR_MID_AMT = JdbcWritableBridge.readBigDecimal(67, __dbResults);
    this.NRM_INTR_ALTN_PY_PREM = JdbcWritableBridge.readBigDecimal(68, __dbResults);
    this.GRAD_INTR_ALTN_PY_PREM = JdbcWritableBridge.readBigDecimal(69, __dbResults);
    this.LPS_IAMT_RT = JdbcWritableBridge.readBigDecimal(70, __dbResults);
    this.LPS_IAMT = JdbcWritableBridge.readBigDecimal(71, __dbResults);
    this.PRPY_RDY_AMT = JdbcWritableBridge.readBigDecimal(72, __dbResults);
    this.PRPY_IAMT = JdbcWritableBridge.readBigDecimal(73, __dbResults);
    this.PVCTR_RDY_AMT = JdbcWritableBridge.readBigDecimal(74, __dbResults);
    this.NPTD_RDY_AMT = JdbcWritableBridge.readBigDecimal(75, __dbResults);
    this.TMTD_RDY_AMT = JdbcWritableBridge.readBigDecimal(76, __dbResults);
    this.CNTD_RDY_AMT = JdbcWritableBridge.readBigDecimal(77, __dbResults);
    this.APL_CNTD_RDY_AMT = JdbcWritableBridge.readBigDecimal(78, __dbResults);
    this.STND_CNTD_RDY_AMT = JdbcWritableBridge.readBigDecimal(79, __dbResults);
    this.COV_SLZ_PREM = JdbcWritableBridge.readBigDecimal(80, __dbResults);
    this.CAL_DT = JdbcWritableBridge.readTimestamp(81, __dbResults);
    this.NITR_ACU_COV_PPI = JdbcWritableBridge.readBigDecimal(82, __dbResults);
    this.GITR_ACU_COV_PPI = JdbcWritableBridge.readBigDecimal(83, __dbResults);
    this.LWRT_TMN_RFD_RT = JdbcWritableBridge.readBigDecimal(84, __dbResults);
    this.STY_XACQ_EXP_TAMT = JdbcWritableBridge.readBigDecimal(85, __dbResults);
    this.STY_STND_ACQ_EXP_TAMT = JdbcWritableBridge.readBigDecimal(86, __dbResults);
    this.STY_GURT_URPAE = JdbcWritableBridge.readBigDecimal(87, __dbResults);
    this.STY_STND_URPAE = JdbcWritableBridge.readBigDecimal(88, __dbResults);
    this.TMTD_LPS_IAMT = JdbcWritableBridge.readBigDecimal(89, __dbResults);
    this.RNWL_ED_PRD_DIV_CD = JdbcWritableBridge.readString(90, __dbResults);
    this.RNWL_ED_PRD = JdbcWritableBridge.readBigDecimal(91, __dbResults);
    this.RNWL_ED_AGE = JdbcWritableBridge.readBigDecimal(92, __dbResults);
    this.RNWL_ED_DT = JdbcWritableBridge.readTimestamp(93, __dbResults);
    this.RNWL_TMS = JdbcWritableBridge.readBigDecimal(94, __dbResults);
    this.STD_SBC_AMT = JdbcWritableBridge.readBigDecimal(95, __dbResults);
    this.EIH_LDG_DTM = JdbcWritableBridge.readTimestamp(96, __dbResults);
  }
  public void readFields0(ResultSet __dbResults) throws SQLException {
    this.CLOG_YYMM = JdbcWritableBridge.readString(1, __dbResults);
    this.CTR_ID = JdbcWritableBridge.readString(2, __dbResults);
    this.CTR_COV_ID = JdbcWritableBridge.readString(3, __dbResults);
    this.POL_NO = JdbcWritableBridge.readString(4, __dbResults);
    this.CTR_OBJ_ID = JdbcWritableBridge.readString(5, __dbResults);
    this.PD_CD = JdbcWritableBridge.readString(6, __dbResults);
    this.COV_CD = JdbcWritableBridge.readString(7, __dbResults);
    this.LAST_PY_YYMM = JdbcWritableBridge.readString(8, __dbResults);
    this.CTR_STAT_CD = JdbcWritableBridge.readString(9, __dbResults);
    this.CTR_STAT_DTL_CD = JdbcWritableBridge.readString(10, __dbResults);
    this.GURT_ACU_DIV_CD = JdbcWritableBridge.readString(11, __dbResults);
    this.CTR_COV_STAT_CD = JdbcWritableBridge.readString(12, __dbResults);
    this.CTR_COV_STAT_DTL_CD = JdbcWritableBridge.readString(13, __dbResults);
    this.COV_BGN_DT = JdbcWritableBridge.readTimestamp(14, __dbResults);
    this.COV_ED_DT = JdbcWritableBridge.readTimestamp(15, __dbResults);
    this.COV_PY_ST_DT = JdbcWritableBridge.readTimestamp(16, __dbResults);
    this.COV_PY_ED_DT = JdbcWritableBridge.readTimestamp(17, __dbResults);
    this.COV_PY_CYC_CD = JdbcWritableBridge.readString(18, __dbResults);
    this.COV_INS_PRD_TP_CD = JdbcWritableBridge.readString(19, __dbResults);
    this.COV_PY_PRD_TP_CD = JdbcWritableBridge.readString(20, __dbResults);
    this.COV_INS_PRD = JdbcWritableBridge.readBigDecimal(21, __dbResults);
    this.COV_PY_PRD = JdbcWritableBridge.readBigDecimal(22, __dbResults);
    this.INS_AGE = JdbcWritableBridge.readBigDecimal(23, __dbResults);
    this.FULL_AGE = JdbcWritableBridge.readBigDecimal(24, __dbResults);
    this.PY_ED_AGE = JdbcWritableBridge.readBigDecimal(25, __dbResults);
    this.INS_ED_AGE = JdbcWritableBridge.readBigDecimal(26, __dbResults);
    this.MOM_PD_CD = JdbcWritableBridge.readString(27, __dbResults);
    this.MOM_COV_CD = JdbcWritableBridge.readString(28, __dbResults);
    this.INSD_AMT = JdbcWritableBridge.readBigDecimal(29, __dbResults);
    this.APL_PREM = JdbcWritableBridge.readBigDecimal(30, __dbResults);
    this.BAS_PREM = JdbcWritableBridge.readBigDecimal(31, __dbResults);
    this.KEY_COV_SEQ = JdbcWritableBridge.readBigDecimal(32, __dbResults);
    this.KEY_HIS_SEQ = JdbcWritableBridge.readBigDecimal(33, __dbResults);
    this.RKEY_CNFG_CHT_VAL = JdbcWritableBridge.readString(34, __dbResults);
    this.BKEY_CNFG_CHT_VAL = JdbcWritableBridge.readString(35, __dbResults);
    this.XCHG_CF1 = JdbcWritableBridge.readBigDecimal(36, __dbResults);
    this.XCHG_CF2 = JdbcWritableBridge.readBigDecimal(37, __dbResults);
    this.XCHG_CF3 = JdbcWritableBridge.readBigDecimal(38, __dbResults);
    this.XCHG_CF4 = JdbcWritableBridge.readBigDecimal(39, __dbResults);
    this.XCHG_CF5 = JdbcWritableBridge.readBigDecimal(40, __dbResults);
    this.ACU_PREM_DIV_CD = JdbcWritableBridge.readString(41, __dbResults);
    this.PY_EXEM_ST_DT = JdbcWritableBridge.readTimestamp(42, __dbResults);
    this.ELP_YR_NUM = JdbcWritableBridge.readBigDecimal(43, __dbResults);
    this.ELP_MM_NUM = JdbcWritableBridge.readBigDecimal(44, __dbResults);
    this.TT_ELP_MM_NUM = JdbcWritableBridge.readBigDecimal(45, __dbResults);
    this.UNPSS_MM_NUM = JdbcWritableBridge.readBigDecimal(46, __dbResults);
    this.CMPT_STD_DT = JdbcWritableBridge.readTimestamp(47, __dbResults);
    this.PRPY_TIMS = JdbcWritableBridge.readBigDecimal(48, __dbResults);
    this.LPS_DT = JdbcWritableBridge.readTimestamp(49, __dbResults);
    this.EXPC_LPS_DT = JdbcWritableBridge.readTimestamp(50, __dbResults);
    this.PRDCH_ENDR_HIS_STD_NO = JdbcWritableBridge.readBigDecimal(51, __dbResults);
    this.PREM_ENDR_HIS_STD_NO = JdbcWritableBridge.readBigDecimal(52, __dbResults);
    this.APL_NPTD_RDY_AMT = JdbcWritableBridge.readBigDecimal(53, __dbResults);
    this.STND_NPTD_RDY_AMT = JdbcWritableBridge.readBigDecimal(54, __dbResults);
    this.APL_TMTD_RDY_AMT = JdbcWritableBridge.readBigDecimal(55, __dbResults);
    this.STND_TMTD_RDY_AMT = JdbcWritableBridge.readBigDecimal(56, __dbResults);
    this.UNPSS_PREM = JdbcWritableBridge.readBigDecimal(57, __dbResults);
    this.GURT_UNRPD_ACQ_EXP = JdbcWritableBridge.readBigDecimal(58, __dbResults);
    this.XPT_ACQ_EXP_TAMT = JdbcWritableBridge.readBigDecimal(59, __dbResults);
    this.STND_ACQ_EXP_TAMT = JdbcWritableBridge.readBigDecimal(60, __dbResults);
    this.NRM_INTR_ACU_AMT = JdbcWritableBridge.readBigDecimal(61, __dbResults);
    this.GRAD_INTR_ACU_AMT = JdbcWritableBridge.readBigDecimal(62, __dbResults);
    this.DFR_BGN_RDY_AMT = JdbcWritableBridge.readBigDecimal(63, __dbResults);
    this.ACU_UNRPD_ACQ_EXP = JdbcWritableBridge.readBigDecimal(64, __dbResults);
    this.PAY_TT_FINC_AMT = JdbcWritableBridge.readBigDecimal(65, __dbResults);
    this.NRM_INTR_MID_AMT = JdbcWritableBridge.readBigDecimal(66, __dbResults);
    this.GRAD_INTR_MID_AMT = JdbcWritableBridge.readBigDecimal(67, __dbResults);
    this.NRM_INTR_ALTN_PY_PREM = JdbcWritableBridge.readBigDecimal(68, __dbResults);
    this.GRAD_INTR_ALTN_PY_PREM = JdbcWritableBridge.readBigDecimal(69, __dbResults);
    this.LPS_IAMT_RT = JdbcWritableBridge.readBigDecimal(70, __dbResults);
    this.LPS_IAMT = JdbcWritableBridge.readBigDecimal(71, __dbResults);
    this.PRPY_RDY_AMT = JdbcWritableBridge.readBigDecimal(72, __dbResults);
    this.PRPY_IAMT = JdbcWritableBridge.readBigDecimal(73, __dbResults);
    this.PVCTR_RDY_AMT = JdbcWritableBridge.readBigDecimal(74, __dbResults);
    this.NPTD_RDY_AMT = JdbcWritableBridge.readBigDecimal(75, __dbResults);
    this.TMTD_RDY_AMT = JdbcWritableBridge.readBigDecimal(76, __dbResults);
    this.CNTD_RDY_AMT = JdbcWritableBridge.readBigDecimal(77, __dbResults);
    this.APL_CNTD_RDY_AMT = JdbcWritableBridge.readBigDecimal(78, __dbResults);
    this.STND_CNTD_RDY_AMT = JdbcWritableBridge.readBigDecimal(79, __dbResults);
    this.COV_SLZ_PREM = JdbcWritableBridge.readBigDecimal(80, __dbResults);
    this.CAL_DT = JdbcWritableBridge.readTimestamp(81, __dbResults);
    this.NITR_ACU_COV_PPI = JdbcWritableBridge.readBigDecimal(82, __dbResults);
    this.GITR_ACU_COV_PPI = JdbcWritableBridge.readBigDecimal(83, __dbResults);
    this.LWRT_TMN_RFD_RT = JdbcWritableBridge.readBigDecimal(84, __dbResults);
    this.STY_XACQ_EXP_TAMT = JdbcWritableBridge.readBigDecimal(85, __dbResults);
    this.STY_STND_ACQ_EXP_TAMT = JdbcWritableBridge.readBigDecimal(86, __dbResults);
    this.STY_GURT_URPAE = JdbcWritableBridge.readBigDecimal(87, __dbResults);
    this.STY_STND_URPAE = JdbcWritableBridge.readBigDecimal(88, __dbResults);
    this.TMTD_LPS_IAMT = JdbcWritableBridge.readBigDecimal(89, __dbResults);
    this.RNWL_ED_PRD_DIV_CD = JdbcWritableBridge.readString(90, __dbResults);
    this.RNWL_ED_PRD = JdbcWritableBridge.readBigDecimal(91, __dbResults);
    this.RNWL_ED_AGE = JdbcWritableBridge.readBigDecimal(92, __dbResults);
    this.RNWL_ED_DT = JdbcWritableBridge.readTimestamp(93, __dbResults);
    this.RNWL_TMS = JdbcWritableBridge.readBigDecimal(94, __dbResults);
    this.STD_SBC_AMT = JdbcWritableBridge.readBigDecimal(95, __dbResults);
    this.EIH_LDG_DTM = JdbcWritableBridge.readTimestamp(96, __dbResults);
  }
  public void loadLargeObjects(LargeObjectLoader __loader)
      throws SQLException, IOException, InterruptedException {
  }
  public void loadLargeObjects0(LargeObjectLoader __loader)
      throws SQLException, IOException, InterruptedException {
  }
  public void write(PreparedStatement __dbStmt) throws SQLException {
    write(__dbStmt, 0);
  }

  public int write(PreparedStatement __dbStmt, int __off) throws SQLException {
    JdbcWritableBridge.writeString(CLOG_YYMM, 1 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(CTR_ID, 2 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(CTR_COV_ID, 3 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(POL_NO, 4 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(CTR_OBJ_ID, 5 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(PD_CD, 6 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(COV_CD, 7 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(LAST_PY_YYMM, 8 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(CTR_STAT_CD, 9 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(CTR_STAT_DTL_CD, 10 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(GURT_ACU_DIV_CD, 11 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(CTR_COV_STAT_CD, 12 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(CTR_COV_STAT_DTL_CD, 13 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeTimestamp(COV_BGN_DT, 14 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeTimestamp(COV_ED_DT, 15 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeTimestamp(COV_PY_ST_DT, 16 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeTimestamp(COV_PY_ED_DT, 17 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeString(COV_PY_CYC_CD, 18 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(COV_INS_PRD_TP_CD, 19 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(COV_PY_PRD_TP_CD, 20 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(COV_INS_PRD, 21 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(COV_PY_PRD, 22 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(INS_AGE, 23 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(FULL_AGE, 24 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(PY_ED_AGE, 25 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(INS_ED_AGE, 26 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(MOM_PD_CD, 27 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(MOM_COV_CD, 28 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(INSD_AMT, 29 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(APL_PREM, 30 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(BAS_PREM, 31 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(KEY_COV_SEQ, 32 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(KEY_HIS_SEQ, 33 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(RKEY_CNFG_CHT_VAL, 34 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(BKEY_CNFG_CHT_VAL, 35 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(XCHG_CF1, 36 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(XCHG_CF2, 37 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(XCHG_CF3, 38 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(XCHG_CF4, 39 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(XCHG_CF5, 40 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(ACU_PREM_DIV_CD, 41 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeTimestamp(PY_EXEM_ST_DT, 42 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(ELP_YR_NUM, 43 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(ELP_MM_NUM, 44 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(TT_ELP_MM_NUM, 45 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(UNPSS_MM_NUM, 46 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeTimestamp(CMPT_STD_DT, 47 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(PRPY_TIMS, 48 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeTimestamp(LPS_DT, 49 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeTimestamp(EXPC_LPS_DT, 50 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(PRDCH_ENDR_HIS_STD_NO, 51 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(PREM_ENDR_HIS_STD_NO, 52 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(APL_NPTD_RDY_AMT, 53 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(STND_NPTD_RDY_AMT, 54 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(APL_TMTD_RDY_AMT, 55 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(STND_TMTD_RDY_AMT, 56 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(UNPSS_PREM, 57 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(GURT_UNRPD_ACQ_EXP, 58 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(XPT_ACQ_EXP_TAMT, 59 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(STND_ACQ_EXP_TAMT, 60 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(NRM_INTR_ACU_AMT, 61 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(GRAD_INTR_ACU_AMT, 62 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(DFR_BGN_RDY_AMT, 63 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(ACU_UNRPD_ACQ_EXP, 64 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(PAY_TT_FINC_AMT, 65 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(NRM_INTR_MID_AMT, 66 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(GRAD_INTR_MID_AMT, 67 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(NRM_INTR_ALTN_PY_PREM, 68 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(GRAD_INTR_ALTN_PY_PREM, 69 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(LPS_IAMT_RT, 70 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(LPS_IAMT, 71 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(PRPY_RDY_AMT, 72 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(PRPY_IAMT, 73 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(PVCTR_RDY_AMT, 74 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(NPTD_RDY_AMT, 75 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(TMTD_RDY_AMT, 76 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(CNTD_RDY_AMT, 77 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(APL_CNTD_RDY_AMT, 78 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(STND_CNTD_RDY_AMT, 79 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(COV_SLZ_PREM, 80 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeTimestamp(CAL_DT, 81 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(NITR_ACU_COV_PPI, 82 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(GITR_ACU_COV_PPI, 83 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(LWRT_TMN_RFD_RT, 84 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(STY_XACQ_EXP_TAMT, 85 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(STY_STND_ACQ_EXP_TAMT, 86 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(STY_GURT_URPAE, 87 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(STY_STND_URPAE, 88 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(TMTD_LPS_IAMT, 89 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(RNWL_ED_PRD_DIV_CD, 90 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(RNWL_ED_PRD, 91 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(RNWL_ED_AGE, 92 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeTimestamp(RNWL_ED_DT, 93 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(RNWL_TMS, 94 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(STD_SBC_AMT, 95 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeTimestamp(EIH_LDG_DTM, 96 + __off, 93, __dbStmt);
    return 96;
  }
  public void write0(PreparedStatement __dbStmt, int __off) throws SQLException {
    JdbcWritableBridge.writeString(CLOG_YYMM, 1 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(CTR_ID, 2 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(CTR_COV_ID, 3 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(POL_NO, 4 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(CTR_OBJ_ID, 5 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(PD_CD, 6 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(COV_CD, 7 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(LAST_PY_YYMM, 8 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(CTR_STAT_CD, 9 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(CTR_STAT_DTL_CD, 10 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(GURT_ACU_DIV_CD, 11 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(CTR_COV_STAT_CD, 12 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(CTR_COV_STAT_DTL_CD, 13 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeTimestamp(COV_BGN_DT, 14 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeTimestamp(COV_ED_DT, 15 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeTimestamp(COV_PY_ST_DT, 16 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeTimestamp(COV_PY_ED_DT, 17 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeString(COV_PY_CYC_CD, 18 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(COV_INS_PRD_TP_CD, 19 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(COV_PY_PRD_TP_CD, 20 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(COV_INS_PRD, 21 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(COV_PY_PRD, 22 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(INS_AGE, 23 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(FULL_AGE, 24 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(PY_ED_AGE, 25 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(INS_ED_AGE, 26 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(MOM_PD_CD, 27 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(MOM_COV_CD, 28 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(INSD_AMT, 29 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(APL_PREM, 30 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(BAS_PREM, 31 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(KEY_COV_SEQ, 32 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(KEY_HIS_SEQ, 33 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(RKEY_CNFG_CHT_VAL, 34 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(BKEY_CNFG_CHT_VAL, 35 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(XCHG_CF1, 36 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(XCHG_CF2, 37 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(XCHG_CF3, 38 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(XCHG_CF4, 39 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(XCHG_CF5, 40 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(ACU_PREM_DIV_CD, 41 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeTimestamp(PY_EXEM_ST_DT, 42 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(ELP_YR_NUM, 43 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(ELP_MM_NUM, 44 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(TT_ELP_MM_NUM, 45 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(UNPSS_MM_NUM, 46 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeTimestamp(CMPT_STD_DT, 47 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(PRPY_TIMS, 48 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeTimestamp(LPS_DT, 49 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeTimestamp(EXPC_LPS_DT, 50 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(PRDCH_ENDR_HIS_STD_NO, 51 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(PREM_ENDR_HIS_STD_NO, 52 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(APL_NPTD_RDY_AMT, 53 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(STND_NPTD_RDY_AMT, 54 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(APL_TMTD_RDY_AMT, 55 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(STND_TMTD_RDY_AMT, 56 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(UNPSS_PREM, 57 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(GURT_UNRPD_ACQ_EXP, 58 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(XPT_ACQ_EXP_TAMT, 59 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(STND_ACQ_EXP_TAMT, 60 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(NRM_INTR_ACU_AMT, 61 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(GRAD_INTR_ACU_AMT, 62 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(DFR_BGN_RDY_AMT, 63 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(ACU_UNRPD_ACQ_EXP, 64 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(PAY_TT_FINC_AMT, 65 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(NRM_INTR_MID_AMT, 66 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(GRAD_INTR_MID_AMT, 67 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(NRM_INTR_ALTN_PY_PREM, 68 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(GRAD_INTR_ALTN_PY_PREM, 69 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(LPS_IAMT_RT, 70 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(LPS_IAMT, 71 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(PRPY_RDY_AMT, 72 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(PRPY_IAMT, 73 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(PVCTR_RDY_AMT, 74 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(NPTD_RDY_AMT, 75 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(TMTD_RDY_AMT, 76 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(CNTD_RDY_AMT, 77 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(APL_CNTD_RDY_AMT, 78 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(STND_CNTD_RDY_AMT, 79 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(COV_SLZ_PREM, 80 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeTimestamp(CAL_DT, 81 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(NITR_ACU_COV_PPI, 82 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(GITR_ACU_COV_PPI, 83 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(LWRT_TMN_RFD_RT, 84 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(STY_XACQ_EXP_TAMT, 85 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(STY_STND_ACQ_EXP_TAMT, 86 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(STY_GURT_URPAE, 87 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(STY_STND_URPAE, 88 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(TMTD_LPS_IAMT, 89 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(RNWL_ED_PRD_DIV_CD, 90 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(RNWL_ED_PRD, 91 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(RNWL_ED_AGE, 92 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeTimestamp(RNWL_ED_DT, 93 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(RNWL_TMS, 94 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(STD_SBC_AMT, 95 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeTimestamp(EIH_LDG_DTM, 96 + __off, 93, __dbStmt);
  }
  public void readFields(DataInput __dataIn) throws IOException {
this.readFields0(__dataIn);  }
  public void readFields0(DataInput __dataIn) throws IOException {
    if (__dataIn.readBoolean()) { 
        this.CLOG_YYMM = null;
    } else {
    this.CLOG_YYMM = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.CTR_ID = null;
    } else {
    this.CTR_ID = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.CTR_COV_ID = null;
    } else {
    this.CTR_COV_ID = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.POL_NO = null;
    } else {
    this.POL_NO = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.CTR_OBJ_ID = null;
    } else {
    this.CTR_OBJ_ID = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.PD_CD = null;
    } else {
    this.PD_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.COV_CD = null;
    } else {
    this.COV_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.LAST_PY_YYMM = null;
    } else {
    this.LAST_PY_YYMM = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.CTR_STAT_CD = null;
    } else {
    this.CTR_STAT_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.CTR_STAT_DTL_CD = null;
    } else {
    this.CTR_STAT_DTL_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.GURT_ACU_DIV_CD = null;
    } else {
    this.GURT_ACU_DIV_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.CTR_COV_STAT_CD = null;
    } else {
    this.CTR_COV_STAT_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.CTR_COV_STAT_DTL_CD = null;
    } else {
    this.CTR_COV_STAT_DTL_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.COV_BGN_DT = null;
    } else {
    this.COV_BGN_DT = new Timestamp(__dataIn.readLong());
    this.COV_BGN_DT.setNanos(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.COV_ED_DT = null;
    } else {
    this.COV_ED_DT = new Timestamp(__dataIn.readLong());
    this.COV_ED_DT.setNanos(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.COV_PY_ST_DT = null;
    } else {
    this.COV_PY_ST_DT = new Timestamp(__dataIn.readLong());
    this.COV_PY_ST_DT.setNanos(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.COV_PY_ED_DT = null;
    } else {
    this.COV_PY_ED_DT = new Timestamp(__dataIn.readLong());
    this.COV_PY_ED_DT.setNanos(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.COV_PY_CYC_CD = null;
    } else {
    this.COV_PY_CYC_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.COV_INS_PRD_TP_CD = null;
    } else {
    this.COV_INS_PRD_TP_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.COV_PY_PRD_TP_CD = null;
    } else {
    this.COV_PY_PRD_TP_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.COV_INS_PRD = null;
    } else {
    this.COV_INS_PRD = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.COV_PY_PRD = null;
    } else {
    this.COV_PY_PRD = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.INS_AGE = null;
    } else {
    this.INS_AGE = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.FULL_AGE = null;
    } else {
    this.FULL_AGE = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.PY_ED_AGE = null;
    } else {
    this.PY_ED_AGE = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.INS_ED_AGE = null;
    } else {
    this.INS_ED_AGE = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.MOM_PD_CD = null;
    } else {
    this.MOM_PD_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.MOM_COV_CD = null;
    } else {
    this.MOM_COV_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.INSD_AMT = null;
    } else {
    this.INSD_AMT = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.APL_PREM = null;
    } else {
    this.APL_PREM = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.BAS_PREM = null;
    } else {
    this.BAS_PREM = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.KEY_COV_SEQ = null;
    } else {
    this.KEY_COV_SEQ = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.KEY_HIS_SEQ = null;
    } else {
    this.KEY_HIS_SEQ = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RKEY_CNFG_CHT_VAL = null;
    } else {
    this.RKEY_CNFG_CHT_VAL = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.BKEY_CNFG_CHT_VAL = null;
    } else {
    this.BKEY_CNFG_CHT_VAL = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.XCHG_CF1 = null;
    } else {
    this.XCHG_CF1 = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.XCHG_CF2 = null;
    } else {
    this.XCHG_CF2 = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.XCHG_CF3 = null;
    } else {
    this.XCHG_CF3 = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.XCHG_CF4 = null;
    } else {
    this.XCHG_CF4 = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.XCHG_CF5 = null;
    } else {
    this.XCHG_CF5 = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.ACU_PREM_DIV_CD = null;
    } else {
    this.ACU_PREM_DIV_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.PY_EXEM_ST_DT = null;
    } else {
    this.PY_EXEM_ST_DT = new Timestamp(__dataIn.readLong());
    this.PY_EXEM_ST_DT.setNanos(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.ELP_YR_NUM = null;
    } else {
    this.ELP_YR_NUM = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.ELP_MM_NUM = null;
    } else {
    this.ELP_MM_NUM = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.TT_ELP_MM_NUM = null;
    } else {
    this.TT_ELP_MM_NUM = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.UNPSS_MM_NUM = null;
    } else {
    this.UNPSS_MM_NUM = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.CMPT_STD_DT = null;
    } else {
    this.CMPT_STD_DT = new Timestamp(__dataIn.readLong());
    this.CMPT_STD_DT.setNanos(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.PRPY_TIMS = null;
    } else {
    this.PRPY_TIMS = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.LPS_DT = null;
    } else {
    this.LPS_DT = new Timestamp(__dataIn.readLong());
    this.LPS_DT.setNanos(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.EXPC_LPS_DT = null;
    } else {
    this.EXPC_LPS_DT = new Timestamp(__dataIn.readLong());
    this.EXPC_LPS_DT.setNanos(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.PRDCH_ENDR_HIS_STD_NO = null;
    } else {
    this.PRDCH_ENDR_HIS_STD_NO = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.PREM_ENDR_HIS_STD_NO = null;
    } else {
    this.PREM_ENDR_HIS_STD_NO = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.APL_NPTD_RDY_AMT = null;
    } else {
    this.APL_NPTD_RDY_AMT = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.STND_NPTD_RDY_AMT = null;
    } else {
    this.STND_NPTD_RDY_AMT = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.APL_TMTD_RDY_AMT = null;
    } else {
    this.APL_TMTD_RDY_AMT = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.STND_TMTD_RDY_AMT = null;
    } else {
    this.STND_TMTD_RDY_AMT = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.UNPSS_PREM = null;
    } else {
    this.UNPSS_PREM = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.GURT_UNRPD_ACQ_EXP = null;
    } else {
    this.GURT_UNRPD_ACQ_EXP = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.XPT_ACQ_EXP_TAMT = null;
    } else {
    this.XPT_ACQ_EXP_TAMT = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.STND_ACQ_EXP_TAMT = null;
    } else {
    this.STND_ACQ_EXP_TAMT = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.NRM_INTR_ACU_AMT = null;
    } else {
    this.NRM_INTR_ACU_AMT = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.GRAD_INTR_ACU_AMT = null;
    } else {
    this.GRAD_INTR_ACU_AMT = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.DFR_BGN_RDY_AMT = null;
    } else {
    this.DFR_BGN_RDY_AMT = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.ACU_UNRPD_ACQ_EXP = null;
    } else {
    this.ACU_UNRPD_ACQ_EXP = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.PAY_TT_FINC_AMT = null;
    } else {
    this.PAY_TT_FINC_AMT = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.NRM_INTR_MID_AMT = null;
    } else {
    this.NRM_INTR_MID_AMT = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.GRAD_INTR_MID_AMT = null;
    } else {
    this.GRAD_INTR_MID_AMT = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.NRM_INTR_ALTN_PY_PREM = null;
    } else {
    this.NRM_INTR_ALTN_PY_PREM = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.GRAD_INTR_ALTN_PY_PREM = null;
    } else {
    this.GRAD_INTR_ALTN_PY_PREM = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.LPS_IAMT_RT = null;
    } else {
    this.LPS_IAMT_RT = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.LPS_IAMT = null;
    } else {
    this.LPS_IAMT = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.PRPY_RDY_AMT = null;
    } else {
    this.PRPY_RDY_AMT = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.PRPY_IAMT = null;
    } else {
    this.PRPY_IAMT = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.PVCTR_RDY_AMT = null;
    } else {
    this.PVCTR_RDY_AMT = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.NPTD_RDY_AMT = null;
    } else {
    this.NPTD_RDY_AMT = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.TMTD_RDY_AMT = null;
    } else {
    this.TMTD_RDY_AMT = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.CNTD_RDY_AMT = null;
    } else {
    this.CNTD_RDY_AMT = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.APL_CNTD_RDY_AMT = null;
    } else {
    this.APL_CNTD_RDY_AMT = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.STND_CNTD_RDY_AMT = null;
    } else {
    this.STND_CNTD_RDY_AMT = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.COV_SLZ_PREM = null;
    } else {
    this.COV_SLZ_PREM = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.CAL_DT = null;
    } else {
    this.CAL_DT = new Timestamp(__dataIn.readLong());
    this.CAL_DT.setNanos(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.NITR_ACU_COV_PPI = null;
    } else {
    this.NITR_ACU_COV_PPI = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.GITR_ACU_COV_PPI = null;
    } else {
    this.GITR_ACU_COV_PPI = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.LWRT_TMN_RFD_RT = null;
    } else {
    this.LWRT_TMN_RFD_RT = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.STY_XACQ_EXP_TAMT = null;
    } else {
    this.STY_XACQ_EXP_TAMT = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.STY_STND_ACQ_EXP_TAMT = null;
    } else {
    this.STY_STND_ACQ_EXP_TAMT = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.STY_GURT_URPAE = null;
    } else {
    this.STY_GURT_URPAE = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.STY_STND_URPAE = null;
    } else {
    this.STY_STND_URPAE = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.TMTD_LPS_IAMT = null;
    } else {
    this.TMTD_LPS_IAMT = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RNWL_ED_PRD_DIV_CD = null;
    } else {
    this.RNWL_ED_PRD_DIV_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RNWL_ED_PRD = null;
    } else {
    this.RNWL_ED_PRD = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RNWL_ED_AGE = null;
    } else {
    this.RNWL_ED_AGE = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RNWL_ED_DT = null;
    } else {
    this.RNWL_ED_DT = new Timestamp(__dataIn.readLong());
    this.RNWL_ED_DT.setNanos(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.RNWL_TMS = null;
    } else {
    this.RNWL_TMS = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.STD_SBC_AMT = null;
    } else {
    this.STD_SBC_AMT = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.EIH_LDG_DTM = null;
    } else {
    this.EIH_LDG_DTM = new Timestamp(__dataIn.readLong());
    this.EIH_LDG_DTM.setNanos(__dataIn.readInt());
    }
  }
  public void write(DataOutput __dataOut) throws IOException {
    if (null == this.CLOG_YYMM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CLOG_YYMM);
    }
    if (null == this.CTR_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CTR_ID);
    }
    if (null == this.CTR_COV_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CTR_COV_ID);
    }
    if (null == this.POL_NO) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, POL_NO);
    }
    if (null == this.CTR_OBJ_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CTR_OBJ_ID);
    }
    if (null == this.PD_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, PD_CD);
    }
    if (null == this.COV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, COV_CD);
    }
    if (null == this.LAST_PY_YYMM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, LAST_PY_YYMM);
    }
    if (null == this.CTR_STAT_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CTR_STAT_CD);
    }
    if (null == this.CTR_STAT_DTL_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CTR_STAT_DTL_CD);
    }
    if (null == this.GURT_ACU_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, GURT_ACU_DIV_CD);
    }
    if (null == this.CTR_COV_STAT_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CTR_COV_STAT_CD);
    }
    if (null == this.CTR_COV_STAT_DTL_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CTR_COV_STAT_DTL_CD);
    }
    if (null == this.COV_BGN_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.COV_BGN_DT.getTime());
    __dataOut.writeInt(this.COV_BGN_DT.getNanos());
    }
    if (null == this.COV_ED_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.COV_ED_DT.getTime());
    __dataOut.writeInt(this.COV_ED_DT.getNanos());
    }
    if (null == this.COV_PY_ST_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.COV_PY_ST_DT.getTime());
    __dataOut.writeInt(this.COV_PY_ST_DT.getNanos());
    }
    if (null == this.COV_PY_ED_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.COV_PY_ED_DT.getTime());
    __dataOut.writeInt(this.COV_PY_ED_DT.getNanos());
    }
    if (null == this.COV_PY_CYC_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, COV_PY_CYC_CD);
    }
    if (null == this.COV_INS_PRD_TP_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, COV_INS_PRD_TP_CD);
    }
    if (null == this.COV_PY_PRD_TP_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, COV_PY_PRD_TP_CD);
    }
    if (null == this.COV_INS_PRD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.COV_INS_PRD, __dataOut);
    }
    if (null == this.COV_PY_PRD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.COV_PY_PRD, __dataOut);
    }
    if (null == this.INS_AGE) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.INS_AGE, __dataOut);
    }
    if (null == this.FULL_AGE) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.FULL_AGE, __dataOut);
    }
    if (null == this.PY_ED_AGE) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.PY_ED_AGE, __dataOut);
    }
    if (null == this.INS_ED_AGE) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.INS_ED_AGE, __dataOut);
    }
    if (null == this.MOM_PD_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, MOM_PD_CD);
    }
    if (null == this.MOM_COV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, MOM_COV_CD);
    }
    if (null == this.INSD_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.INSD_AMT, __dataOut);
    }
    if (null == this.APL_PREM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.APL_PREM, __dataOut);
    }
    if (null == this.BAS_PREM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.BAS_PREM, __dataOut);
    }
    if (null == this.KEY_COV_SEQ) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.KEY_COV_SEQ, __dataOut);
    }
    if (null == this.KEY_HIS_SEQ) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.KEY_HIS_SEQ, __dataOut);
    }
    if (null == this.RKEY_CNFG_CHT_VAL) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RKEY_CNFG_CHT_VAL);
    }
    if (null == this.BKEY_CNFG_CHT_VAL) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, BKEY_CNFG_CHT_VAL);
    }
    if (null == this.XCHG_CF1) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.XCHG_CF1, __dataOut);
    }
    if (null == this.XCHG_CF2) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.XCHG_CF2, __dataOut);
    }
    if (null == this.XCHG_CF3) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.XCHG_CF3, __dataOut);
    }
    if (null == this.XCHG_CF4) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.XCHG_CF4, __dataOut);
    }
    if (null == this.XCHG_CF5) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.XCHG_CF5, __dataOut);
    }
    if (null == this.ACU_PREM_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ACU_PREM_DIV_CD);
    }
    if (null == this.PY_EXEM_ST_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.PY_EXEM_ST_DT.getTime());
    __dataOut.writeInt(this.PY_EXEM_ST_DT.getNanos());
    }
    if (null == this.ELP_YR_NUM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.ELP_YR_NUM, __dataOut);
    }
    if (null == this.ELP_MM_NUM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.ELP_MM_NUM, __dataOut);
    }
    if (null == this.TT_ELP_MM_NUM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.TT_ELP_MM_NUM, __dataOut);
    }
    if (null == this.UNPSS_MM_NUM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.UNPSS_MM_NUM, __dataOut);
    }
    if (null == this.CMPT_STD_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.CMPT_STD_DT.getTime());
    __dataOut.writeInt(this.CMPT_STD_DT.getNanos());
    }
    if (null == this.PRPY_TIMS) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.PRPY_TIMS, __dataOut);
    }
    if (null == this.LPS_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.LPS_DT.getTime());
    __dataOut.writeInt(this.LPS_DT.getNanos());
    }
    if (null == this.EXPC_LPS_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.EXPC_LPS_DT.getTime());
    __dataOut.writeInt(this.EXPC_LPS_DT.getNanos());
    }
    if (null == this.PRDCH_ENDR_HIS_STD_NO) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.PRDCH_ENDR_HIS_STD_NO, __dataOut);
    }
    if (null == this.PREM_ENDR_HIS_STD_NO) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.PREM_ENDR_HIS_STD_NO, __dataOut);
    }
    if (null == this.APL_NPTD_RDY_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.APL_NPTD_RDY_AMT, __dataOut);
    }
    if (null == this.STND_NPTD_RDY_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.STND_NPTD_RDY_AMT, __dataOut);
    }
    if (null == this.APL_TMTD_RDY_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.APL_TMTD_RDY_AMT, __dataOut);
    }
    if (null == this.STND_TMTD_RDY_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.STND_TMTD_RDY_AMT, __dataOut);
    }
    if (null == this.UNPSS_PREM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.UNPSS_PREM, __dataOut);
    }
    if (null == this.GURT_UNRPD_ACQ_EXP) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.GURT_UNRPD_ACQ_EXP, __dataOut);
    }
    if (null == this.XPT_ACQ_EXP_TAMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.XPT_ACQ_EXP_TAMT, __dataOut);
    }
    if (null == this.STND_ACQ_EXP_TAMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.STND_ACQ_EXP_TAMT, __dataOut);
    }
    if (null == this.NRM_INTR_ACU_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.NRM_INTR_ACU_AMT, __dataOut);
    }
    if (null == this.GRAD_INTR_ACU_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.GRAD_INTR_ACU_AMT, __dataOut);
    }
    if (null == this.DFR_BGN_RDY_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.DFR_BGN_RDY_AMT, __dataOut);
    }
    if (null == this.ACU_UNRPD_ACQ_EXP) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.ACU_UNRPD_ACQ_EXP, __dataOut);
    }
    if (null == this.PAY_TT_FINC_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.PAY_TT_FINC_AMT, __dataOut);
    }
    if (null == this.NRM_INTR_MID_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.NRM_INTR_MID_AMT, __dataOut);
    }
    if (null == this.GRAD_INTR_MID_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.GRAD_INTR_MID_AMT, __dataOut);
    }
    if (null == this.NRM_INTR_ALTN_PY_PREM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.NRM_INTR_ALTN_PY_PREM, __dataOut);
    }
    if (null == this.GRAD_INTR_ALTN_PY_PREM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.GRAD_INTR_ALTN_PY_PREM, __dataOut);
    }
    if (null == this.LPS_IAMT_RT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.LPS_IAMT_RT, __dataOut);
    }
    if (null == this.LPS_IAMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.LPS_IAMT, __dataOut);
    }
    if (null == this.PRPY_RDY_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.PRPY_RDY_AMT, __dataOut);
    }
    if (null == this.PRPY_IAMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.PRPY_IAMT, __dataOut);
    }
    if (null == this.PVCTR_RDY_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.PVCTR_RDY_AMT, __dataOut);
    }
    if (null == this.NPTD_RDY_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.NPTD_RDY_AMT, __dataOut);
    }
    if (null == this.TMTD_RDY_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.TMTD_RDY_AMT, __dataOut);
    }
    if (null == this.CNTD_RDY_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.CNTD_RDY_AMT, __dataOut);
    }
    if (null == this.APL_CNTD_RDY_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.APL_CNTD_RDY_AMT, __dataOut);
    }
    if (null == this.STND_CNTD_RDY_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.STND_CNTD_RDY_AMT, __dataOut);
    }
    if (null == this.COV_SLZ_PREM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.COV_SLZ_PREM, __dataOut);
    }
    if (null == this.CAL_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.CAL_DT.getTime());
    __dataOut.writeInt(this.CAL_DT.getNanos());
    }
    if (null == this.NITR_ACU_COV_PPI) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.NITR_ACU_COV_PPI, __dataOut);
    }
    if (null == this.GITR_ACU_COV_PPI) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.GITR_ACU_COV_PPI, __dataOut);
    }
    if (null == this.LWRT_TMN_RFD_RT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.LWRT_TMN_RFD_RT, __dataOut);
    }
    if (null == this.STY_XACQ_EXP_TAMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.STY_XACQ_EXP_TAMT, __dataOut);
    }
    if (null == this.STY_STND_ACQ_EXP_TAMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.STY_STND_ACQ_EXP_TAMT, __dataOut);
    }
    if (null == this.STY_GURT_URPAE) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.STY_GURT_URPAE, __dataOut);
    }
    if (null == this.STY_STND_URPAE) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.STY_STND_URPAE, __dataOut);
    }
    if (null == this.TMTD_LPS_IAMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.TMTD_LPS_IAMT, __dataOut);
    }
    if (null == this.RNWL_ED_PRD_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RNWL_ED_PRD_DIV_CD);
    }
    if (null == this.RNWL_ED_PRD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.RNWL_ED_PRD, __dataOut);
    }
    if (null == this.RNWL_ED_AGE) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.RNWL_ED_AGE, __dataOut);
    }
    if (null == this.RNWL_ED_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.RNWL_ED_DT.getTime());
    __dataOut.writeInt(this.RNWL_ED_DT.getNanos());
    }
    if (null == this.RNWL_TMS) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.RNWL_TMS, __dataOut);
    }
    if (null == this.STD_SBC_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.STD_SBC_AMT, __dataOut);
    }
    if (null == this.EIH_LDG_DTM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.EIH_LDG_DTM.getTime());
    __dataOut.writeInt(this.EIH_LDG_DTM.getNanos());
    }
  }
  public void write0(DataOutput __dataOut) throws IOException {
    if (null == this.CLOG_YYMM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CLOG_YYMM);
    }
    if (null == this.CTR_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CTR_ID);
    }
    if (null == this.CTR_COV_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CTR_COV_ID);
    }
    if (null == this.POL_NO) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, POL_NO);
    }
    if (null == this.CTR_OBJ_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CTR_OBJ_ID);
    }
    if (null == this.PD_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, PD_CD);
    }
    if (null == this.COV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, COV_CD);
    }
    if (null == this.LAST_PY_YYMM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, LAST_PY_YYMM);
    }
    if (null == this.CTR_STAT_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CTR_STAT_CD);
    }
    if (null == this.CTR_STAT_DTL_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CTR_STAT_DTL_CD);
    }
    if (null == this.GURT_ACU_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, GURT_ACU_DIV_CD);
    }
    if (null == this.CTR_COV_STAT_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CTR_COV_STAT_CD);
    }
    if (null == this.CTR_COV_STAT_DTL_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CTR_COV_STAT_DTL_CD);
    }
    if (null == this.COV_BGN_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.COV_BGN_DT.getTime());
    __dataOut.writeInt(this.COV_BGN_DT.getNanos());
    }
    if (null == this.COV_ED_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.COV_ED_DT.getTime());
    __dataOut.writeInt(this.COV_ED_DT.getNanos());
    }
    if (null == this.COV_PY_ST_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.COV_PY_ST_DT.getTime());
    __dataOut.writeInt(this.COV_PY_ST_DT.getNanos());
    }
    if (null == this.COV_PY_ED_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.COV_PY_ED_DT.getTime());
    __dataOut.writeInt(this.COV_PY_ED_DT.getNanos());
    }
    if (null == this.COV_PY_CYC_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, COV_PY_CYC_CD);
    }
    if (null == this.COV_INS_PRD_TP_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, COV_INS_PRD_TP_CD);
    }
    if (null == this.COV_PY_PRD_TP_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, COV_PY_PRD_TP_CD);
    }
    if (null == this.COV_INS_PRD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.COV_INS_PRD, __dataOut);
    }
    if (null == this.COV_PY_PRD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.COV_PY_PRD, __dataOut);
    }
    if (null == this.INS_AGE) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.INS_AGE, __dataOut);
    }
    if (null == this.FULL_AGE) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.FULL_AGE, __dataOut);
    }
    if (null == this.PY_ED_AGE) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.PY_ED_AGE, __dataOut);
    }
    if (null == this.INS_ED_AGE) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.INS_ED_AGE, __dataOut);
    }
    if (null == this.MOM_PD_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, MOM_PD_CD);
    }
    if (null == this.MOM_COV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, MOM_COV_CD);
    }
    if (null == this.INSD_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.INSD_AMT, __dataOut);
    }
    if (null == this.APL_PREM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.APL_PREM, __dataOut);
    }
    if (null == this.BAS_PREM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.BAS_PREM, __dataOut);
    }
    if (null == this.KEY_COV_SEQ) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.KEY_COV_SEQ, __dataOut);
    }
    if (null == this.KEY_HIS_SEQ) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.KEY_HIS_SEQ, __dataOut);
    }
    if (null == this.RKEY_CNFG_CHT_VAL) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RKEY_CNFG_CHT_VAL);
    }
    if (null == this.BKEY_CNFG_CHT_VAL) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, BKEY_CNFG_CHT_VAL);
    }
    if (null == this.XCHG_CF1) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.XCHG_CF1, __dataOut);
    }
    if (null == this.XCHG_CF2) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.XCHG_CF2, __dataOut);
    }
    if (null == this.XCHG_CF3) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.XCHG_CF3, __dataOut);
    }
    if (null == this.XCHG_CF4) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.XCHG_CF4, __dataOut);
    }
    if (null == this.XCHG_CF5) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.XCHG_CF5, __dataOut);
    }
    if (null == this.ACU_PREM_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ACU_PREM_DIV_CD);
    }
    if (null == this.PY_EXEM_ST_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.PY_EXEM_ST_DT.getTime());
    __dataOut.writeInt(this.PY_EXEM_ST_DT.getNanos());
    }
    if (null == this.ELP_YR_NUM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.ELP_YR_NUM, __dataOut);
    }
    if (null == this.ELP_MM_NUM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.ELP_MM_NUM, __dataOut);
    }
    if (null == this.TT_ELP_MM_NUM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.TT_ELP_MM_NUM, __dataOut);
    }
    if (null == this.UNPSS_MM_NUM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.UNPSS_MM_NUM, __dataOut);
    }
    if (null == this.CMPT_STD_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.CMPT_STD_DT.getTime());
    __dataOut.writeInt(this.CMPT_STD_DT.getNanos());
    }
    if (null == this.PRPY_TIMS) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.PRPY_TIMS, __dataOut);
    }
    if (null == this.LPS_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.LPS_DT.getTime());
    __dataOut.writeInt(this.LPS_DT.getNanos());
    }
    if (null == this.EXPC_LPS_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.EXPC_LPS_DT.getTime());
    __dataOut.writeInt(this.EXPC_LPS_DT.getNanos());
    }
    if (null == this.PRDCH_ENDR_HIS_STD_NO) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.PRDCH_ENDR_HIS_STD_NO, __dataOut);
    }
    if (null == this.PREM_ENDR_HIS_STD_NO) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.PREM_ENDR_HIS_STD_NO, __dataOut);
    }
    if (null == this.APL_NPTD_RDY_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.APL_NPTD_RDY_AMT, __dataOut);
    }
    if (null == this.STND_NPTD_RDY_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.STND_NPTD_RDY_AMT, __dataOut);
    }
    if (null == this.APL_TMTD_RDY_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.APL_TMTD_RDY_AMT, __dataOut);
    }
    if (null == this.STND_TMTD_RDY_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.STND_TMTD_RDY_AMT, __dataOut);
    }
    if (null == this.UNPSS_PREM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.UNPSS_PREM, __dataOut);
    }
    if (null == this.GURT_UNRPD_ACQ_EXP) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.GURT_UNRPD_ACQ_EXP, __dataOut);
    }
    if (null == this.XPT_ACQ_EXP_TAMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.XPT_ACQ_EXP_TAMT, __dataOut);
    }
    if (null == this.STND_ACQ_EXP_TAMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.STND_ACQ_EXP_TAMT, __dataOut);
    }
    if (null == this.NRM_INTR_ACU_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.NRM_INTR_ACU_AMT, __dataOut);
    }
    if (null == this.GRAD_INTR_ACU_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.GRAD_INTR_ACU_AMT, __dataOut);
    }
    if (null == this.DFR_BGN_RDY_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.DFR_BGN_RDY_AMT, __dataOut);
    }
    if (null == this.ACU_UNRPD_ACQ_EXP) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.ACU_UNRPD_ACQ_EXP, __dataOut);
    }
    if (null == this.PAY_TT_FINC_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.PAY_TT_FINC_AMT, __dataOut);
    }
    if (null == this.NRM_INTR_MID_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.NRM_INTR_MID_AMT, __dataOut);
    }
    if (null == this.GRAD_INTR_MID_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.GRAD_INTR_MID_AMT, __dataOut);
    }
    if (null == this.NRM_INTR_ALTN_PY_PREM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.NRM_INTR_ALTN_PY_PREM, __dataOut);
    }
    if (null == this.GRAD_INTR_ALTN_PY_PREM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.GRAD_INTR_ALTN_PY_PREM, __dataOut);
    }
    if (null == this.LPS_IAMT_RT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.LPS_IAMT_RT, __dataOut);
    }
    if (null == this.LPS_IAMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.LPS_IAMT, __dataOut);
    }
    if (null == this.PRPY_RDY_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.PRPY_RDY_AMT, __dataOut);
    }
    if (null == this.PRPY_IAMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.PRPY_IAMT, __dataOut);
    }
    if (null == this.PVCTR_RDY_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.PVCTR_RDY_AMT, __dataOut);
    }
    if (null == this.NPTD_RDY_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.NPTD_RDY_AMT, __dataOut);
    }
    if (null == this.TMTD_RDY_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.TMTD_RDY_AMT, __dataOut);
    }
    if (null == this.CNTD_RDY_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.CNTD_RDY_AMT, __dataOut);
    }
    if (null == this.APL_CNTD_RDY_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.APL_CNTD_RDY_AMT, __dataOut);
    }
    if (null == this.STND_CNTD_RDY_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.STND_CNTD_RDY_AMT, __dataOut);
    }
    if (null == this.COV_SLZ_PREM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.COV_SLZ_PREM, __dataOut);
    }
    if (null == this.CAL_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.CAL_DT.getTime());
    __dataOut.writeInt(this.CAL_DT.getNanos());
    }
    if (null == this.NITR_ACU_COV_PPI) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.NITR_ACU_COV_PPI, __dataOut);
    }
    if (null == this.GITR_ACU_COV_PPI) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.GITR_ACU_COV_PPI, __dataOut);
    }
    if (null == this.LWRT_TMN_RFD_RT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.LWRT_TMN_RFD_RT, __dataOut);
    }
    if (null == this.STY_XACQ_EXP_TAMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.STY_XACQ_EXP_TAMT, __dataOut);
    }
    if (null == this.STY_STND_ACQ_EXP_TAMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.STY_STND_ACQ_EXP_TAMT, __dataOut);
    }
    if (null == this.STY_GURT_URPAE) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.STY_GURT_URPAE, __dataOut);
    }
    if (null == this.STY_STND_URPAE) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.STY_STND_URPAE, __dataOut);
    }
    if (null == this.TMTD_LPS_IAMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.TMTD_LPS_IAMT, __dataOut);
    }
    if (null == this.RNWL_ED_PRD_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RNWL_ED_PRD_DIV_CD);
    }
    if (null == this.RNWL_ED_PRD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.RNWL_ED_PRD, __dataOut);
    }
    if (null == this.RNWL_ED_AGE) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.RNWL_ED_AGE, __dataOut);
    }
    if (null == this.RNWL_ED_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.RNWL_ED_DT.getTime());
    __dataOut.writeInt(this.RNWL_ED_DT.getNanos());
    }
    if (null == this.RNWL_TMS) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.RNWL_TMS, __dataOut);
    }
    if (null == this.STD_SBC_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.STD_SBC_AMT, __dataOut);
    }
    if (null == this.EIH_LDG_DTM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.EIH_LDG_DTM.getTime());
    __dataOut.writeInt(this.EIH_LDG_DTM.getNanos());
    }
  }
  private static final DelimiterSet __outputDelimiters = new DelimiterSet((char) 1, (char) 10, (char) 0, (char) 0, false);
  public String toString() {
    return toString(__outputDelimiters, true);
  }
  public String toString(DelimiterSet delimiters) {
    return toString(delimiters, true);
  }
  public String toString(boolean useRecordDelim) {
    return toString(__outputDelimiters, useRecordDelim);
  }
  public String toString(DelimiterSet delimiters, boolean useRecordDelim) {
    StringBuilder __sb = new StringBuilder();
    char fieldDelim = delimiters.getFieldsTerminatedBy();
    __sb.append(FieldFormatter.escapeAndEnclose(CLOG_YYMM==null?"null":CLOG_YYMM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CTR_ID==null?"null":CTR_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CTR_COV_ID==null?"null":CTR_COV_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(POL_NO==null?"null":POL_NO, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CTR_OBJ_ID==null?"null":CTR_OBJ_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PD_CD==null?"null":PD_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(COV_CD==null?"null":COV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(LAST_PY_YYMM==null?"null":LAST_PY_YYMM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CTR_STAT_CD==null?"null":CTR_STAT_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CTR_STAT_DTL_CD==null?"null":CTR_STAT_DTL_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(GURT_ACU_DIV_CD==null?"null":GURT_ACU_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CTR_COV_STAT_CD==null?"null":CTR_COV_STAT_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CTR_COV_STAT_DTL_CD==null?"null":CTR_COV_STAT_DTL_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(COV_BGN_DT==null?"null":"" + COV_BGN_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(COV_ED_DT==null?"null":"" + COV_ED_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(COV_PY_ST_DT==null?"null":"" + COV_PY_ST_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(COV_PY_ED_DT==null?"null":"" + COV_PY_ED_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(COV_PY_CYC_CD==null?"null":COV_PY_CYC_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(COV_INS_PRD_TP_CD==null?"null":COV_INS_PRD_TP_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(COV_PY_PRD_TP_CD==null?"null":COV_PY_PRD_TP_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(COV_INS_PRD==null?"null":COV_INS_PRD.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(COV_PY_PRD==null?"null":COV_PY_PRD.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(INS_AGE==null?"null":INS_AGE.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(FULL_AGE==null?"null":FULL_AGE.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PY_ED_AGE==null?"null":PY_ED_AGE.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(INS_ED_AGE==null?"null":INS_ED_AGE.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(MOM_PD_CD==null?"null":MOM_PD_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(MOM_COV_CD==null?"null":MOM_COV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(INSD_AMT==null?"null":INSD_AMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(APL_PREM==null?"null":APL_PREM.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(BAS_PREM==null?"null":BAS_PREM.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(KEY_COV_SEQ==null?"null":KEY_COV_SEQ.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(KEY_HIS_SEQ==null?"null":KEY_HIS_SEQ.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RKEY_CNFG_CHT_VAL==null?"null":RKEY_CNFG_CHT_VAL, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(BKEY_CNFG_CHT_VAL==null?"null":BKEY_CNFG_CHT_VAL, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(XCHG_CF1==null?"null":XCHG_CF1.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(XCHG_CF2==null?"null":XCHG_CF2.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(XCHG_CF3==null?"null":XCHG_CF3.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(XCHG_CF4==null?"null":XCHG_CF4.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(XCHG_CF5==null?"null":XCHG_CF5.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ACU_PREM_DIV_CD==null?"null":ACU_PREM_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PY_EXEM_ST_DT==null?"null":"" + PY_EXEM_ST_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ELP_YR_NUM==null?"null":ELP_YR_NUM.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ELP_MM_NUM==null?"null":ELP_MM_NUM.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(TT_ELP_MM_NUM==null?"null":TT_ELP_MM_NUM.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(UNPSS_MM_NUM==null?"null":UNPSS_MM_NUM.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CMPT_STD_DT==null?"null":"" + CMPT_STD_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PRPY_TIMS==null?"null":PRPY_TIMS.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(LPS_DT==null?"null":"" + LPS_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(EXPC_LPS_DT==null?"null":"" + EXPC_LPS_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PRDCH_ENDR_HIS_STD_NO==null?"null":PRDCH_ENDR_HIS_STD_NO.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PREM_ENDR_HIS_STD_NO==null?"null":PREM_ENDR_HIS_STD_NO.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(APL_NPTD_RDY_AMT==null?"null":APL_NPTD_RDY_AMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(STND_NPTD_RDY_AMT==null?"null":STND_NPTD_RDY_AMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(APL_TMTD_RDY_AMT==null?"null":APL_TMTD_RDY_AMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(STND_TMTD_RDY_AMT==null?"null":STND_TMTD_RDY_AMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(UNPSS_PREM==null?"null":UNPSS_PREM.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(GURT_UNRPD_ACQ_EXP==null?"null":GURT_UNRPD_ACQ_EXP.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(XPT_ACQ_EXP_TAMT==null?"null":XPT_ACQ_EXP_TAMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(STND_ACQ_EXP_TAMT==null?"null":STND_ACQ_EXP_TAMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(NRM_INTR_ACU_AMT==null?"null":NRM_INTR_ACU_AMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(GRAD_INTR_ACU_AMT==null?"null":GRAD_INTR_ACU_AMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DFR_BGN_RDY_AMT==null?"null":DFR_BGN_RDY_AMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ACU_UNRPD_ACQ_EXP==null?"null":ACU_UNRPD_ACQ_EXP.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PAY_TT_FINC_AMT==null?"null":PAY_TT_FINC_AMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(NRM_INTR_MID_AMT==null?"null":NRM_INTR_MID_AMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(GRAD_INTR_MID_AMT==null?"null":GRAD_INTR_MID_AMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(NRM_INTR_ALTN_PY_PREM==null?"null":NRM_INTR_ALTN_PY_PREM.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(GRAD_INTR_ALTN_PY_PREM==null?"null":GRAD_INTR_ALTN_PY_PREM.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(LPS_IAMT_RT==null?"null":LPS_IAMT_RT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(LPS_IAMT==null?"null":LPS_IAMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PRPY_RDY_AMT==null?"null":PRPY_RDY_AMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PRPY_IAMT==null?"null":PRPY_IAMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PVCTR_RDY_AMT==null?"null":PVCTR_RDY_AMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(NPTD_RDY_AMT==null?"null":NPTD_RDY_AMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(TMTD_RDY_AMT==null?"null":TMTD_RDY_AMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CNTD_RDY_AMT==null?"null":CNTD_RDY_AMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(APL_CNTD_RDY_AMT==null?"null":APL_CNTD_RDY_AMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(STND_CNTD_RDY_AMT==null?"null":STND_CNTD_RDY_AMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(COV_SLZ_PREM==null?"null":COV_SLZ_PREM.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CAL_DT==null?"null":"" + CAL_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(NITR_ACU_COV_PPI==null?"null":NITR_ACU_COV_PPI.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(GITR_ACU_COV_PPI==null?"null":GITR_ACU_COV_PPI.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(LWRT_TMN_RFD_RT==null?"null":LWRT_TMN_RFD_RT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(STY_XACQ_EXP_TAMT==null?"null":STY_XACQ_EXP_TAMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(STY_STND_ACQ_EXP_TAMT==null?"null":STY_STND_ACQ_EXP_TAMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(STY_GURT_URPAE==null?"null":STY_GURT_URPAE.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(STY_STND_URPAE==null?"null":STY_STND_URPAE.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(TMTD_LPS_IAMT==null?"null":TMTD_LPS_IAMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RNWL_ED_PRD_DIV_CD==null?"null":RNWL_ED_PRD_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RNWL_ED_PRD==null?"null":RNWL_ED_PRD.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RNWL_ED_AGE==null?"null":RNWL_ED_AGE.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RNWL_ED_DT==null?"null":"" + RNWL_ED_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RNWL_TMS==null?"null":RNWL_TMS.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(STD_SBC_AMT==null?"null":STD_SBC_AMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(EIH_LDG_DTM==null?"null":"" + EIH_LDG_DTM, delimiters));
    if (useRecordDelim) {
      __sb.append(delimiters.getLinesTerminatedBy());
    }
    return __sb.toString();
  }
  public void toString0(DelimiterSet delimiters, StringBuilder __sb, char fieldDelim) {
    __sb.append(FieldFormatter.escapeAndEnclose(CLOG_YYMM==null?"null":CLOG_YYMM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CTR_ID==null?"null":CTR_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CTR_COV_ID==null?"null":CTR_COV_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(POL_NO==null?"null":POL_NO, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CTR_OBJ_ID==null?"null":CTR_OBJ_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PD_CD==null?"null":PD_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(COV_CD==null?"null":COV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(LAST_PY_YYMM==null?"null":LAST_PY_YYMM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CTR_STAT_CD==null?"null":CTR_STAT_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CTR_STAT_DTL_CD==null?"null":CTR_STAT_DTL_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(GURT_ACU_DIV_CD==null?"null":GURT_ACU_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CTR_COV_STAT_CD==null?"null":CTR_COV_STAT_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CTR_COV_STAT_DTL_CD==null?"null":CTR_COV_STAT_DTL_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(COV_BGN_DT==null?"null":"" + COV_BGN_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(COV_ED_DT==null?"null":"" + COV_ED_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(COV_PY_ST_DT==null?"null":"" + COV_PY_ST_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(COV_PY_ED_DT==null?"null":"" + COV_PY_ED_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(COV_PY_CYC_CD==null?"null":COV_PY_CYC_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(COV_INS_PRD_TP_CD==null?"null":COV_INS_PRD_TP_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(COV_PY_PRD_TP_CD==null?"null":COV_PY_PRD_TP_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(COV_INS_PRD==null?"null":COV_INS_PRD.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(COV_PY_PRD==null?"null":COV_PY_PRD.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(INS_AGE==null?"null":INS_AGE.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(FULL_AGE==null?"null":FULL_AGE.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PY_ED_AGE==null?"null":PY_ED_AGE.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(INS_ED_AGE==null?"null":INS_ED_AGE.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(MOM_PD_CD==null?"null":MOM_PD_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(MOM_COV_CD==null?"null":MOM_COV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(INSD_AMT==null?"null":INSD_AMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(APL_PREM==null?"null":APL_PREM.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(BAS_PREM==null?"null":BAS_PREM.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(KEY_COV_SEQ==null?"null":KEY_COV_SEQ.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(KEY_HIS_SEQ==null?"null":KEY_HIS_SEQ.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RKEY_CNFG_CHT_VAL==null?"null":RKEY_CNFG_CHT_VAL, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(BKEY_CNFG_CHT_VAL==null?"null":BKEY_CNFG_CHT_VAL, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(XCHG_CF1==null?"null":XCHG_CF1.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(XCHG_CF2==null?"null":XCHG_CF2.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(XCHG_CF3==null?"null":XCHG_CF3.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(XCHG_CF4==null?"null":XCHG_CF4.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(XCHG_CF5==null?"null":XCHG_CF5.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ACU_PREM_DIV_CD==null?"null":ACU_PREM_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PY_EXEM_ST_DT==null?"null":"" + PY_EXEM_ST_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ELP_YR_NUM==null?"null":ELP_YR_NUM.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ELP_MM_NUM==null?"null":ELP_MM_NUM.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(TT_ELP_MM_NUM==null?"null":TT_ELP_MM_NUM.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(UNPSS_MM_NUM==null?"null":UNPSS_MM_NUM.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CMPT_STD_DT==null?"null":"" + CMPT_STD_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PRPY_TIMS==null?"null":PRPY_TIMS.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(LPS_DT==null?"null":"" + LPS_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(EXPC_LPS_DT==null?"null":"" + EXPC_LPS_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PRDCH_ENDR_HIS_STD_NO==null?"null":PRDCH_ENDR_HIS_STD_NO.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PREM_ENDR_HIS_STD_NO==null?"null":PREM_ENDR_HIS_STD_NO.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(APL_NPTD_RDY_AMT==null?"null":APL_NPTD_RDY_AMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(STND_NPTD_RDY_AMT==null?"null":STND_NPTD_RDY_AMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(APL_TMTD_RDY_AMT==null?"null":APL_TMTD_RDY_AMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(STND_TMTD_RDY_AMT==null?"null":STND_TMTD_RDY_AMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(UNPSS_PREM==null?"null":UNPSS_PREM.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(GURT_UNRPD_ACQ_EXP==null?"null":GURT_UNRPD_ACQ_EXP.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(XPT_ACQ_EXP_TAMT==null?"null":XPT_ACQ_EXP_TAMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(STND_ACQ_EXP_TAMT==null?"null":STND_ACQ_EXP_TAMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(NRM_INTR_ACU_AMT==null?"null":NRM_INTR_ACU_AMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(GRAD_INTR_ACU_AMT==null?"null":GRAD_INTR_ACU_AMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DFR_BGN_RDY_AMT==null?"null":DFR_BGN_RDY_AMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ACU_UNRPD_ACQ_EXP==null?"null":ACU_UNRPD_ACQ_EXP.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PAY_TT_FINC_AMT==null?"null":PAY_TT_FINC_AMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(NRM_INTR_MID_AMT==null?"null":NRM_INTR_MID_AMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(GRAD_INTR_MID_AMT==null?"null":GRAD_INTR_MID_AMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(NRM_INTR_ALTN_PY_PREM==null?"null":NRM_INTR_ALTN_PY_PREM.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(GRAD_INTR_ALTN_PY_PREM==null?"null":GRAD_INTR_ALTN_PY_PREM.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(LPS_IAMT_RT==null?"null":LPS_IAMT_RT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(LPS_IAMT==null?"null":LPS_IAMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PRPY_RDY_AMT==null?"null":PRPY_RDY_AMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PRPY_IAMT==null?"null":PRPY_IAMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PVCTR_RDY_AMT==null?"null":PVCTR_RDY_AMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(NPTD_RDY_AMT==null?"null":NPTD_RDY_AMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(TMTD_RDY_AMT==null?"null":TMTD_RDY_AMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CNTD_RDY_AMT==null?"null":CNTD_RDY_AMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(APL_CNTD_RDY_AMT==null?"null":APL_CNTD_RDY_AMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(STND_CNTD_RDY_AMT==null?"null":STND_CNTD_RDY_AMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(COV_SLZ_PREM==null?"null":COV_SLZ_PREM.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CAL_DT==null?"null":"" + CAL_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(NITR_ACU_COV_PPI==null?"null":NITR_ACU_COV_PPI.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(GITR_ACU_COV_PPI==null?"null":GITR_ACU_COV_PPI.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(LWRT_TMN_RFD_RT==null?"null":LWRT_TMN_RFD_RT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(STY_XACQ_EXP_TAMT==null?"null":STY_XACQ_EXP_TAMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(STY_STND_ACQ_EXP_TAMT==null?"null":STY_STND_ACQ_EXP_TAMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(STY_GURT_URPAE==null?"null":STY_GURT_URPAE.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(STY_STND_URPAE==null?"null":STY_STND_URPAE.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(TMTD_LPS_IAMT==null?"null":TMTD_LPS_IAMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RNWL_ED_PRD_DIV_CD==null?"null":RNWL_ED_PRD_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RNWL_ED_PRD==null?"null":RNWL_ED_PRD.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RNWL_ED_AGE==null?"null":RNWL_ED_AGE.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RNWL_ED_DT==null?"null":"" + RNWL_ED_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RNWL_TMS==null?"null":RNWL_TMS.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(STD_SBC_AMT==null?"null":STD_SBC_AMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(EIH_LDG_DTM==null?"null":"" + EIH_LDG_DTM, delimiters));
  }
  private static final DelimiterSet __inputDelimiters = new DelimiterSet((char) 1, (char) 10, (char) 0, (char) 0, false);
  private RecordParser __parser;
  public void parse(Text __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(CharSequence __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(byte [] __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(char [] __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(ByteBuffer __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(CharBuffer __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  private void __loadFromFields(List<String> fields) {
    Iterator<String> __it = fields.listIterator();
    String __cur_str = null;
    try {
    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CLOG_YYMM = null; } else {
      this.CLOG_YYMM = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CTR_ID = null; } else {
      this.CTR_ID = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CTR_COV_ID = null; } else {
      this.CTR_COV_ID = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.POL_NO = null; } else {
      this.POL_NO = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CTR_OBJ_ID = null; } else {
      this.CTR_OBJ_ID = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.PD_CD = null; } else {
      this.PD_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.COV_CD = null; } else {
      this.COV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.LAST_PY_YYMM = null; } else {
      this.LAST_PY_YYMM = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CTR_STAT_CD = null; } else {
      this.CTR_STAT_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CTR_STAT_DTL_CD = null; } else {
      this.CTR_STAT_DTL_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.GURT_ACU_DIV_CD = null; } else {
      this.GURT_ACU_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CTR_COV_STAT_CD = null; } else {
      this.CTR_COV_STAT_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CTR_COV_STAT_DTL_CD = null; } else {
      this.CTR_COV_STAT_DTL_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.COV_BGN_DT = null; } else {
      this.COV_BGN_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.COV_ED_DT = null; } else {
      this.COV_ED_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.COV_PY_ST_DT = null; } else {
      this.COV_PY_ST_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.COV_PY_ED_DT = null; } else {
      this.COV_PY_ED_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.COV_PY_CYC_CD = null; } else {
      this.COV_PY_CYC_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.COV_INS_PRD_TP_CD = null; } else {
      this.COV_INS_PRD_TP_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.COV_PY_PRD_TP_CD = null; } else {
      this.COV_PY_PRD_TP_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.COV_INS_PRD = null; } else {
      this.COV_INS_PRD = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.COV_PY_PRD = null; } else {
      this.COV_PY_PRD = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.INS_AGE = null; } else {
      this.INS_AGE = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.FULL_AGE = null; } else {
      this.FULL_AGE = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.PY_ED_AGE = null; } else {
      this.PY_ED_AGE = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.INS_ED_AGE = null; } else {
      this.INS_ED_AGE = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.MOM_PD_CD = null; } else {
      this.MOM_PD_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.MOM_COV_CD = null; } else {
      this.MOM_COV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.INSD_AMT = null; } else {
      this.INSD_AMT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.APL_PREM = null; } else {
      this.APL_PREM = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.BAS_PREM = null; } else {
      this.BAS_PREM = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.KEY_COV_SEQ = null; } else {
      this.KEY_COV_SEQ = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.KEY_HIS_SEQ = null; } else {
      this.KEY_HIS_SEQ = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.RKEY_CNFG_CHT_VAL = null; } else {
      this.RKEY_CNFG_CHT_VAL = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.BKEY_CNFG_CHT_VAL = null; } else {
      this.BKEY_CNFG_CHT_VAL = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.XCHG_CF1 = null; } else {
      this.XCHG_CF1 = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.XCHG_CF2 = null; } else {
      this.XCHG_CF2 = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.XCHG_CF3 = null; } else {
      this.XCHG_CF3 = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.XCHG_CF4 = null; } else {
      this.XCHG_CF4 = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.XCHG_CF5 = null; } else {
      this.XCHG_CF5 = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.ACU_PREM_DIV_CD = null; } else {
      this.ACU_PREM_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.PY_EXEM_ST_DT = null; } else {
      this.PY_EXEM_ST_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.ELP_YR_NUM = null; } else {
      this.ELP_YR_NUM = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.ELP_MM_NUM = null; } else {
      this.ELP_MM_NUM = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.TT_ELP_MM_NUM = null; } else {
      this.TT_ELP_MM_NUM = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.UNPSS_MM_NUM = null; } else {
      this.UNPSS_MM_NUM = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.CMPT_STD_DT = null; } else {
      this.CMPT_STD_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.PRPY_TIMS = null; } else {
      this.PRPY_TIMS = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.LPS_DT = null; } else {
      this.LPS_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.EXPC_LPS_DT = null; } else {
      this.EXPC_LPS_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.PRDCH_ENDR_HIS_STD_NO = null; } else {
      this.PRDCH_ENDR_HIS_STD_NO = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.PREM_ENDR_HIS_STD_NO = null; } else {
      this.PREM_ENDR_HIS_STD_NO = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.APL_NPTD_RDY_AMT = null; } else {
      this.APL_NPTD_RDY_AMT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.STND_NPTD_RDY_AMT = null; } else {
      this.STND_NPTD_RDY_AMT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.APL_TMTD_RDY_AMT = null; } else {
      this.APL_TMTD_RDY_AMT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.STND_TMTD_RDY_AMT = null; } else {
      this.STND_TMTD_RDY_AMT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.UNPSS_PREM = null; } else {
      this.UNPSS_PREM = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.GURT_UNRPD_ACQ_EXP = null; } else {
      this.GURT_UNRPD_ACQ_EXP = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.XPT_ACQ_EXP_TAMT = null; } else {
      this.XPT_ACQ_EXP_TAMT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.STND_ACQ_EXP_TAMT = null; } else {
      this.STND_ACQ_EXP_TAMT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.NRM_INTR_ACU_AMT = null; } else {
      this.NRM_INTR_ACU_AMT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.GRAD_INTR_ACU_AMT = null; } else {
      this.GRAD_INTR_ACU_AMT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.DFR_BGN_RDY_AMT = null; } else {
      this.DFR_BGN_RDY_AMT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.ACU_UNRPD_ACQ_EXP = null; } else {
      this.ACU_UNRPD_ACQ_EXP = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.PAY_TT_FINC_AMT = null; } else {
      this.PAY_TT_FINC_AMT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.NRM_INTR_MID_AMT = null; } else {
      this.NRM_INTR_MID_AMT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.GRAD_INTR_MID_AMT = null; } else {
      this.GRAD_INTR_MID_AMT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.NRM_INTR_ALTN_PY_PREM = null; } else {
      this.NRM_INTR_ALTN_PY_PREM = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.GRAD_INTR_ALTN_PY_PREM = null; } else {
      this.GRAD_INTR_ALTN_PY_PREM = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.LPS_IAMT_RT = null; } else {
      this.LPS_IAMT_RT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.LPS_IAMT = null; } else {
      this.LPS_IAMT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.PRPY_RDY_AMT = null; } else {
      this.PRPY_RDY_AMT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.PRPY_IAMT = null; } else {
      this.PRPY_IAMT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.PVCTR_RDY_AMT = null; } else {
      this.PVCTR_RDY_AMT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.NPTD_RDY_AMT = null; } else {
      this.NPTD_RDY_AMT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.TMTD_RDY_AMT = null; } else {
      this.TMTD_RDY_AMT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.CNTD_RDY_AMT = null; } else {
      this.CNTD_RDY_AMT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.APL_CNTD_RDY_AMT = null; } else {
      this.APL_CNTD_RDY_AMT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.STND_CNTD_RDY_AMT = null; } else {
      this.STND_CNTD_RDY_AMT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.COV_SLZ_PREM = null; } else {
      this.COV_SLZ_PREM = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.CAL_DT = null; } else {
      this.CAL_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.NITR_ACU_COV_PPI = null; } else {
      this.NITR_ACU_COV_PPI = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.GITR_ACU_COV_PPI = null; } else {
      this.GITR_ACU_COV_PPI = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.LWRT_TMN_RFD_RT = null; } else {
      this.LWRT_TMN_RFD_RT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.STY_XACQ_EXP_TAMT = null; } else {
      this.STY_XACQ_EXP_TAMT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.STY_STND_ACQ_EXP_TAMT = null; } else {
      this.STY_STND_ACQ_EXP_TAMT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.STY_GURT_URPAE = null; } else {
      this.STY_GURT_URPAE = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.STY_STND_URPAE = null; } else {
      this.STY_STND_URPAE = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.TMTD_LPS_IAMT = null; } else {
      this.TMTD_LPS_IAMT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.RNWL_ED_PRD_DIV_CD = null; } else {
      this.RNWL_ED_PRD_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RNWL_ED_PRD = null; } else {
      this.RNWL_ED_PRD = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RNWL_ED_AGE = null; } else {
      this.RNWL_ED_AGE = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RNWL_ED_DT = null; } else {
      this.RNWL_ED_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RNWL_TMS = null; } else {
      this.RNWL_TMS = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.STD_SBC_AMT = null; } else {
      this.STD_SBC_AMT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.EIH_LDG_DTM = null; } else {
      this.EIH_LDG_DTM = java.sql.Timestamp.valueOf(__cur_str);
    }

    } catch (RuntimeException e) {    throw new RuntimeException("Can't parse input data: '" + __cur_str + "'", e);    }  }

  private void __loadFromFields0(Iterator<String> __it) {
    String __cur_str = null;
    try {
    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CLOG_YYMM = null; } else {
      this.CLOG_YYMM = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CTR_ID = null; } else {
      this.CTR_ID = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CTR_COV_ID = null; } else {
      this.CTR_COV_ID = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.POL_NO = null; } else {
      this.POL_NO = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CTR_OBJ_ID = null; } else {
      this.CTR_OBJ_ID = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.PD_CD = null; } else {
      this.PD_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.COV_CD = null; } else {
      this.COV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.LAST_PY_YYMM = null; } else {
      this.LAST_PY_YYMM = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CTR_STAT_CD = null; } else {
      this.CTR_STAT_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CTR_STAT_DTL_CD = null; } else {
      this.CTR_STAT_DTL_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.GURT_ACU_DIV_CD = null; } else {
      this.GURT_ACU_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CTR_COV_STAT_CD = null; } else {
      this.CTR_COV_STAT_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CTR_COV_STAT_DTL_CD = null; } else {
      this.CTR_COV_STAT_DTL_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.COV_BGN_DT = null; } else {
      this.COV_BGN_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.COV_ED_DT = null; } else {
      this.COV_ED_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.COV_PY_ST_DT = null; } else {
      this.COV_PY_ST_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.COV_PY_ED_DT = null; } else {
      this.COV_PY_ED_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.COV_PY_CYC_CD = null; } else {
      this.COV_PY_CYC_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.COV_INS_PRD_TP_CD = null; } else {
      this.COV_INS_PRD_TP_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.COV_PY_PRD_TP_CD = null; } else {
      this.COV_PY_PRD_TP_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.COV_INS_PRD = null; } else {
      this.COV_INS_PRD = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.COV_PY_PRD = null; } else {
      this.COV_PY_PRD = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.INS_AGE = null; } else {
      this.INS_AGE = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.FULL_AGE = null; } else {
      this.FULL_AGE = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.PY_ED_AGE = null; } else {
      this.PY_ED_AGE = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.INS_ED_AGE = null; } else {
      this.INS_ED_AGE = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.MOM_PD_CD = null; } else {
      this.MOM_PD_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.MOM_COV_CD = null; } else {
      this.MOM_COV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.INSD_AMT = null; } else {
      this.INSD_AMT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.APL_PREM = null; } else {
      this.APL_PREM = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.BAS_PREM = null; } else {
      this.BAS_PREM = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.KEY_COV_SEQ = null; } else {
      this.KEY_COV_SEQ = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.KEY_HIS_SEQ = null; } else {
      this.KEY_HIS_SEQ = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.RKEY_CNFG_CHT_VAL = null; } else {
      this.RKEY_CNFG_CHT_VAL = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.BKEY_CNFG_CHT_VAL = null; } else {
      this.BKEY_CNFG_CHT_VAL = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.XCHG_CF1 = null; } else {
      this.XCHG_CF1 = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.XCHG_CF2 = null; } else {
      this.XCHG_CF2 = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.XCHG_CF3 = null; } else {
      this.XCHG_CF3 = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.XCHG_CF4 = null; } else {
      this.XCHG_CF4 = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.XCHG_CF5 = null; } else {
      this.XCHG_CF5 = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.ACU_PREM_DIV_CD = null; } else {
      this.ACU_PREM_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.PY_EXEM_ST_DT = null; } else {
      this.PY_EXEM_ST_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.ELP_YR_NUM = null; } else {
      this.ELP_YR_NUM = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.ELP_MM_NUM = null; } else {
      this.ELP_MM_NUM = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.TT_ELP_MM_NUM = null; } else {
      this.TT_ELP_MM_NUM = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.UNPSS_MM_NUM = null; } else {
      this.UNPSS_MM_NUM = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.CMPT_STD_DT = null; } else {
      this.CMPT_STD_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.PRPY_TIMS = null; } else {
      this.PRPY_TIMS = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.LPS_DT = null; } else {
      this.LPS_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.EXPC_LPS_DT = null; } else {
      this.EXPC_LPS_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.PRDCH_ENDR_HIS_STD_NO = null; } else {
      this.PRDCH_ENDR_HIS_STD_NO = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.PREM_ENDR_HIS_STD_NO = null; } else {
      this.PREM_ENDR_HIS_STD_NO = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.APL_NPTD_RDY_AMT = null; } else {
      this.APL_NPTD_RDY_AMT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.STND_NPTD_RDY_AMT = null; } else {
      this.STND_NPTD_RDY_AMT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.APL_TMTD_RDY_AMT = null; } else {
      this.APL_TMTD_RDY_AMT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.STND_TMTD_RDY_AMT = null; } else {
      this.STND_TMTD_RDY_AMT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.UNPSS_PREM = null; } else {
      this.UNPSS_PREM = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.GURT_UNRPD_ACQ_EXP = null; } else {
      this.GURT_UNRPD_ACQ_EXP = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.XPT_ACQ_EXP_TAMT = null; } else {
      this.XPT_ACQ_EXP_TAMT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.STND_ACQ_EXP_TAMT = null; } else {
      this.STND_ACQ_EXP_TAMT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.NRM_INTR_ACU_AMT = null; } else {
      this.NRM_INTR_ACU_AMT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.GRAD_INTR_ACU_AMT = null; } else {
      this.GRAD_INTR_ACU_AMT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.DFR_BGN_RDY_AMT = null; } else {
      this.DFR_BGN_RDY_AMT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.ACU_UNRPD_ACQ_EXP = null; } else {
      this.ACU_UNRPD_ACQ_EXP = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.PAY_TT_FINC_AMT = null; } else {
      this.PAY_TT_FINC_AMT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.NRM_INTR_MID_AMT = null; } else {
      this.NRM_INTR_MID_AMT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.GRAD_INTR_MID_AMT = null; } else {
      this.GRAD_INTR_MID_AMT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.NRM_INTR_ALTN_PY_PREM = null; } else {
      this.NRM_INTR_ALTN_PY_PREM = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.GRAD_INTR_ALTN_PY_PREM = null; } else {
      this.GRAD_INTR_ALTN_PY_PREM = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.LPS_IAMT_RT = null; } else {
      this.LPS_IAMT_RT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.LPS_IAMT = null; } else {
      this.LPS_IAMT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.PRPY_RDY_AMT = null; } else {
      this.PRPY_RDY_AMT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.PRPY_IAMT = null; } else {
      this.PRPY_IAMT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.PVCTR_RDY_AMT = null; } else {
      this.PVCTR_RDY_AMT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.NPTD_RDY_AMT = null; } else {
      this.NPTD_RDY_AMT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.TMTD_RDY_AMT = null; } else {
      this.TMTD_RDY_AMT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.CNTD_RDY_AMT = null; } else {
      this.CNTD_RDY_AMT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.APL_CNTD_RDY_AMT = null; } else {
      this.APL_CNTD_RDY_AMT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.STND_CNTD_RDY_AMT = null; } else {
      this.STND_CNTD_RDY_AMT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.COV_SLZ_PREM = null; } else {
      this.COV_SLZ_PREM = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.CAL_DT = null; } else {
      this.CAL_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.NITR_ACU_COV_PPI = null; } else {
      this.NITR_ACU_COV_PPI = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.GITR_ACU_COV_PPI = null; } else {
      this.GITR_ACU_COV_PPI = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.LWRT_TMN_RFD_RT = null; } else {
      this.LWRT_TMN_RFD_RT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.STY_XACQ_EXP_TAMT = null; } else {
      this.STY_XACQ_EXP_TAMT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.STY_STND_ACQ_EXP_TAMT = null; } else {
      this.STY_STND_ACQ_EXP_TAMT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.STY_GURT_URPAE = null; } else {
      this.STY_GURT_URPAE = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.STY_STND_URPAE = null; } else {
      this.STY_STND_URPAE = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.TMTD_LPS_IAMT = null; } else {
      this.TMTD_LPS_IAMT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.RNWL_ED_PRD_DIV_CD = null; } else {
      this.RNWL_ED_PRD_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RNWL_ED_PRD = null; } else {
      this.RNWL_ED_PRD = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RNWL_ED_AGE = null; } else {
      this.RNWL_ED_AGE = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RNWL_ED_DT = null; } else {
      this.RNWL_ED_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RNWL_TMS = null; } else {
      this.RNWL_TMS = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.STD_SBC_AMT = null; } else {
      this.STD_SBC_AMT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.EIH_LDG_DTM = null; } else {
      this.EIH_LDG_DTM = java.sql.Timestamp.valueOf(__cur_str);
    }

    } catch (RuntimeException e) {    throw new RuntimeException("Can't parse input data: '" + __cur_str + "'", e);    }  }

  public Object clone() throws CloneNotSupportedException {
    QueryResult o = (QueryResult) super.clone();
    o.COV_BGN_DT = (o.COV_BGN_DT != null) ? (java.sql.Timestamp) o.COV_BGN_DT.clone() : null;
    o.COV_ED_DT = (o.COV_ED_DT != null) ? (java.sql.Timestamp) o.COV_ED_DT.clone() : null;
    o.COV_PY_ST_DT = (o.COV_PY_ST_DT != null) ? (java.sql.Timestamp) o.COV_PY_ST_DT.clone() : null;
    o.COV_PY_ED_DT = (o.COV_PY_ED_DT != null) ? (java.sql.Timestamp) o.COV_PY_ED_DT.clone() : null;
    o.PY_EXEM_ST_DT = (o.PY_EXEM_ST_DT != null) ? (java.sql.Timestamp) o.PY_EXEM_ST_DT.clone() : null;
    o.CMPT_STD_DT = (o.CMPT_STD_DT != null) ? (java.sql.Timestamp) o.CMPT_STD_DT.clone() : null;
    o.LPS_DT = (o.LPS_DT != null) ? (java.sql.Timestamp) o.LPS_DT.clone() : null;
    o.EXPC_LPS_DT = (o.EXPC_LPS_DT != null) ? (java.sql.Timestamp) o.EXPC_LPS_DT.clone() : null;
    o.CAL_DT = (o.CAL_DT != null) ? (java.sql.Timestamp) o.CAL_DT.clone() : null;
    o.RNWL_ED_DT = (o.RNWL_ED_DT != null) ? (java.sql.Timestamp) o.RNWL_ED_DT.clone() : null;
    o.EIH_LDG_DTM = (o.EIH_LDG_DTM != null) ? (java.sql.Timestamp) o.EIH_LDG_DTM.clone() : null;
    return o;
  }

  public void clone0(QueryResult o) throws CloneNotSupportedException {
    o.COV_BGN_DT = (o.COV_BGN_DT != null) ? (java.sql.Timestamp) o.COV_BGN_DT.clone() : null;
    o.COV_ED_DT = (o.COV_ED_DT != null) ? (java.sql.Timestamp) o.COV_ED_DT.clone() : null;
    o.COV_PY_ST_DT = (o.COV_PY_ST_DT != null) ? (java.sql.Timestamp) o.COV_PY_ST_DT.clone() : null;
    o.COV_PY_ED_DT = (o.COV_PY_ED_DT != null) ? (java.sql.Timestamp) o.COV_PY_ED_DT.clone() : null;
    o.PY_EXEM_ST_DT = (o.PY_EXEM_ST_DT != null) ? (java.sql.Timestamp) o.PY_EXEM_ST_DT.clone() : null;
    o.CMPT_STD_DT = (o.CMPT_STD_DT != null) ? (java.sql.Timestamp) o.CMPT_STD_DT.clone() : null;
    o.LPS_DT = (o.LPS_DT != null) ? (java.sql.Timestamp) o.LPS_DT.clone() : null;
    o.EXPC_LPS_DT = (o.EXPC_LPS_DT != null) ? (java.sql.Timestamp) o.EXPC_LPS_DT.clone() : null;
    o.CAL_DT = (o.CAL_DT != null) ? (java.sql.Timestamp) o.CAL_DT.clone() : null;
    o.RNWL_ED_DT = (o.RNWL_ED_DT != null) ? (java.sql.Timestamp) o.RNWL_ED_DT.clone() : null;
    o.EIH_LDG_DTM = (o.EIH_LDG_DTM != null) ? (java.sql.Timestamp) o.EIH_LDG_DTM.clone() : null;
  }

  public Map<String, Object> getFieldMap() {
    Map<String, Object> __sqoop$field_map = new HashMap<String, Object>();
    __sqoop$field_map.put("CLOG_YYMM", this.CLOG_YYMM);
    __sqoop$field_map.put("CTR_ID", this.CTR_ID);
    __sqoop$field_map.put("CTR_COV_ID", this.CTR_COV_ID);
    __sqoop$field_map.put("POL_NO", this.POL_NO);
    __sqoop$field_map.put("CTR_OBJ_ID", this.CTR_OBJ_ID);
    __sqoop$field_map.put("PD_CD", this.PD_CD);
    __sqoop$field_map.put("COV_CD", this.COV_CD);
    __sqoop$field_map.put("LAST_PY_YYMM", this.LAST_PY_YYMM);
    __sqoop$field_map.put("CTR_STAT_CD", this.CTR_STAT_CD);
    __sqoop$field_map.put("CTR_STAT_DTL_CD", this.CTR_STAT_DTL_CD);
    __sqoop$field_map.put("GURT_ACU_DIV_CD", this.GURT_ACU_DIV_CD);
    __sqoop$field_map.put("CTR_COV_STAT_CD", this.CTR_COV_STAT_CD);
    __sqoop$field_map.put("CTR_COV_STAT_DTL_CD", this.CTR_COV_STAT_DTL_CD);
    __sqoop$field_map.put("COV_BGN_DT", this.COV_BGN_DT);
    __sqoop$field_map.put("COV_ED_DT", this.COV_ED_DT);
    __sqoop$field_map.put("COV_PY_ST_DT", this.COV_PY_ST_DT);
    __sqoop$field_map.put("COV_PY_ED_DT", this.COV_PY_ED_DT);
    __sqoop$field_map.put("COV_PY_CYC_CD", this.COV_PY_CYC_CD);
    __sqoop$field_map.put("COV_INS_PRD_TP_CD", this.COV_INS_PRD_TP_CD);
    __sqoop$field_map.put("COV_PY_PRD_TP_CD", this.COV_PY_PRD_TP_CD);
    __sqoop$field_map.put("COV_INS_PRD", this.COV_INS_PRD);
    __sqoop$field_map.put("COV_PY_PRD", this.COV_PY_PRD);
    __sqoop$field_map.put("INS_AGE", this.INS_AGE);
    __sqoop$field_map.put("FULL_AGE", this.FULL_AGE);
    __sqoop$field_map.put("PY_ED_AGE", this.PY_ED_AGE);
    __sqoop$field_map.put("INS_ED_AGE", this.INS_ED_AGE);
    __sqoop$field_map.put("MOM_PD_CD", this.MOM_PD_CD);
    __sqoop$field_map.put("MOM_COV_CD", this.MOM_COV_CD);
    __sqoop$field_map.put("INSD_AMT", this.INSD_AMT);
    __sqoop$field_map.put("APL_PREM", this.APL_PREM);
    __sqoop$field_map.put("BAS_PREM", this.BAS_PREM);
    __sqoop$field_map.put("KEY_COV_SEQ", this.KEY_COV_SEQ);
    __sqoop$field_map.put("KEY_HIS_SEQ", this.KEY_HIS_SEQ);
    __sqoop$field_map.put("RKEY_CNFG_CHT_VAL", this.RKEY_CNFG_CHT_VAL);
    __sqoop$field_map.put("BKEY_CNFG_CHT_VAL", this.BKEY_CNFG_CHT_VAL);
    __sqoop$field_map.put("XCHG_CF1", this.XCHG_CF1);
    __sqoop$field_map.put("XCHG_CF2", this.XCHG_CF2);
    __sqoop$field_map.put("XCHG_CF3", this.XCHG_CF3);
    __sqoop$field_map.put("XCHG_CF4", this.XCHG_CF4);
    __sqoop$field_map.put("XCHG_CF5", this.XCHG_CF5);
    __sqoop$field_map.put("ACU_PREM_DIV_CD", this.ACU_PREM_DIV_CD);
    __sqoop$field_map.put("PY_EXEM_ST_DT", this.PY_EXEM_ST_DT);
    __sqoop$field_map.put("ELP_YR_NUM", this.ELP_YR_NUM);
    __sqoop$field_map.put("ELP_MM_NUM", this.ELP_MM_NUM);
    __sqoop$field_map.put("TT_ELP_MM_NUM", this.TT_ELP_MM_NUM);
    __sqoop$field_map.put("UNPSS_MM_NUM", this.UNPSS_MM_NUM);
    __sqoop$field_map.put("CMPT_STD_DT", this.CMPT_STD_DT);
    __sqoop$field_map.put("PRPY_TIMS", this.PRPY_TIMS);
    __sqoop$field_map.put("LPS_DT", this.LPS_DT);
    __sqoop$field_map.put("EXPC_LPS_DT", this.EXPC_LPS_DT);
    __sqoop$field_map.put("PRDCH_ENDR_HIS_STD_NO", this.PRDCH_ENDR_HIS_STD_NO);
    __sqoop$field_map.put("PREM_ENDR_HIS_STD_NO", this.PREM_ENDR_HIS_STD_NO);
    __sqoop$field_map.put("APL_NPTD_RDY_AMT", this.APL_NPTD_RDY_AMT);
    __sqoop$field_map.put("STND_NPTD_RDY_AMT", this.STND_NPTD_RDY_AMT);
    __sqoop$field_map.put("APL_TMTD_RDY_AMT", this.APL_TMTD_RDY_AMT);
    __sqoop$field_map.put("STND_TMTD_RDY_AMT", this.STND_TMTD_RDY_AMT);
    __sqoop$field_map.put("UNPSS_PREM", this.UNPSS_PREM);
    __sqoop$field_map.put("GURT_UNRPD_ACQ_EXP", this.GURT_UNRPD_ACQ_EXP);
    __sqoop$field_map.put("XPT_ACQ_EXP_TAMT", this.XPT_ACQ_EXP_TAMT);
    __sqoop$field_map.put("STND_ACQ_EXP_TAMT", this.STND_ACQ_EXP_TAMT);
    __sqoop$field_map.put("NRM_INTR_ACU_AMT", this.NRM_INTR_ACU_AMT);
    __sqoop$field_map.put("GRAD_INTR_ACU_AMT", this.GRAD_INTR_ACU_AMT);
    __sqoop$field_map.put("DFR_BGN_RDY_AMT", this.DFR_BGN_RDY_AMT);
    __sqoop$field_map.put("ACU_UNRPD_ACQ_EXP", this.ACU_UNRPD_ACQ_EXP);
    __sqoop$field_map.put("PAY_TT_FINC_AMT", this.PAY_TT_FINC_AMT);
    __sqoop$field_map.put("NRM_INTR_MID_AMT", this.NRM_INTR_MID_AMT);
    __sqoop$field_map.put("GRAD_INTR_MID_AMT", this.GRAD_INTR_MID_AMT);
    __sqoop$field_map.put("NRM_INTR_ALTN_PY_PREM", this.NRM_INTR_ALTN_PY_PREM);
    __sqoop$field_map.put("GRAD_INTR_ALTN_PY_PREM", this.GRAD_INTR_ALTN_PY_PREM);
    __sqoop$field_map.put("LPS_IAMT_RT", this.LPS_IAMT_RT);
    __sqoop$field_map.put("LPS_IAMT", this.LPS_IAMT);
    __sqoop$field_map.put("PRPY_RDY_AMT", this.PRPY_RDY_AMT);
    __sqoop$field_map.put("PRPY_IAMT", this.PRPY_IAMT);
    __sqoop$field_map.put("PVCTR_RDY_AMT", this.PVCTR_RDY_AMT);
    __sqoop$field_map.put("NPTD_RDY_AMT", this.NPTD_RDY_AMT);
    __sqoop$field_map.put("TMTD_RDY_AMT", this.TMTD_RDY_AMT);
    __sqoop$field_map.put("CNTD_RDY_AMT", this.CNTD_RDY_AMT);
    __sqoop$field_map.put("APL_CNTD_RDY_AMT", this.APL_CNTD_RDY_AMT);
    __sqoop$field_map.put("STND_CNTD_RDY_AMT", this.STND_CNTD_RDY_AMT);
    __sqoop$field_map.put("COV_SLZ_PREM", this.COV_SLZ_PREM);
    __sqoop$field_map.put("CAL_DT", this.CAL_DT);
    __sqoop$field_map.put("NITR_ACU_COV_PPI", this.NITR_ACU_COV_PPI);
    __sqoop$field_map.put("GITR_ACU_COV_PPI", this.GITR_ACU_COV_PPI);
    __sqoop$field_map.put("LWRT_TMN_RFD_RT", this.LWRT_TMN_RFD_RT);
    __sqoop$field_map.put("STY_XACQ_EXP_TAMT", this.STY_XACQ_EXP_TAMT);
    __sqoop$field_map.put("STY_STND_ACQ_EXP_TAMT", this.STY_STND_ACQ_EXP_TAMT);
    __sqoop$field_map.put("STY_GURT_URPAE", this.STY_GURT_URPAE);
    __sqoop$field_map.put("STY_STND_URPAE", this.STY_STND_URPAE);
    __sqoop$field_map.put("TMTD_LPS_IAMT", this.TMTD_LPS_IAMT);
    __sqoop$field_map.put("RNWL_ED_PRD_DIV_CD", this.RNWL_ED_PRD_DIV_CD);
    __sqoop$field_map.put("RNWL_ED_PRD", this.RNWL_ED_PRD);
    __sqoop$field_map.put("RNWL_ED_AGE", this.RNWL_ED_AGE);
    __sqoop$field_map.put("RNWL_ED_DT", this.RNWL_ED_DT);
    __sqoop$field_map.put("RNWL_TMS", this.RNWL_TMS);
    __sqoop$field_map.put("STD_SBC_AMT", this.STD_SBC_AMT);
    __sqoop$field_map.put("EIH_LDG_DTM", this.EIH_LDG_DTM);
    return __sqoop$field_map;
  }

  public void getFieldMap0(Map<String, Object> __sqoop$field_map) {
    __sqoop$field_map.put("CLOG_YYMM", this.CLOG_YYMM);
    __sqoop$field_map.put("CTR_ID", this.CTR_ID);
    __sqoop$field_map.put("CTR_COV_ID", this.CTR_COV_ID);
    __sqoop$field_map.put("POL_NO", this.POL_NO);
    __sqoop$field_map.put("CTR_OBJ_ID", this.CTR_OBJ_ID);
    __sqoop$field_map.put("PD_CD", this.PD_CD);
    __sqoop$field_map.put("COV_CD", this.COV_CD);
    __sqoop$field_map.put("LAST_PY_YYMM", this.LAST_PY_YYMM);
    __sqoop$field_map.put("CTR_STAT_CD", this.CTR_STAT_CD);
    __sqoop$field_map.put("CTR_STAT_DTL_CD", this.CTR_STAT_DTL_CD);
    __sqoop$field_map.put("GURT_ACU_DIV_CD", this.GURT_ACU_DIV_CD);
    __sqoop$field_map.put("CTR_COV_STAT_CD", this.CTR_COV_STAT_CD);
    __sqoop$field_map.put("CTR_COV_STAT_DTL_CD", this.CTR_COV_STAT_DTL_CD);
    __sqoop$field_map.put("COV_BGN_DT", this.COV_BGN_DT);
    __sqoop$field_map.put("COV_ED_DT", this.COV_ED_DT);
    __sqoop$field_map.put("COV_PY_ST_DT", this.COV_PY_ST_DT);
    __sqoop$field_map.put("COV_PY_ED_DT", this.COV_PY_ED_DT);
    __sqoop$field_map.put("COV_PY_CYC_CD", this.COV_PY_CYC_CD);
    __sqoop$field_map.put("COV_INS_PRD_TP_CD", this.COV_INS_PRD_TP_CD);
    __sqoop$field_map.put("COV_PY_PRD_TP_CD", this.COV_PY_PRD_TP_CD);
    __sqoop$field_map.put("COV_INS_PRD", this.COV_INS_PRD);
    __sqoop$field_map.put("COV_PY_PRD", this.COV_PY_PRD);
    __sqoop$field_map.put("INS_AGE", this.INS_AGE);
    __sqoop$field_map.put("FULL_AGE", this.FULL_AGE);
    __sqoop$field_map.put("PY_ED_AGE", this.PY_ED_AGE);
    __sqoop$field_map.put("INS_ED_AGE", this.INS_ED_AGE);
    __sqoop$field_map.put("MOM_PD_CD", this.MOM_PD_CD);
    __sqoop$field_map.put("MOM_COV_CD", this.MOM_COV_CD);
    __sqoop$field_map.put("INSD_AMT", this.INSD_AMT);
    __sqoop$field_map.put("APL_PREM", this.APL_PREM);
    __sqoop$field_map.put("BAS_PREM", this.BAS_PREM);
    __sqoop$field_map.put("KEY_COV_SEQ", this.KEY_COV_SEQ);
    __sqoop$field_map.put("KEY_HIS_SEQ", this.KEY_HIS_SEQ);
    __sqoop$field_map.put("RKEY_CNFG_CHT_VAL", this.RKEY_CNFG_CHT_VAL);
    __sqoop$field_map.put("BKEY_CNFG_CHT_VAL", this.BKEY_CNFG_CHT_VAL);
    __sqoop$field_map.put("XCHG_CF1", this.XCHG_CF1);
    __sqoop$field_map.put("XCHG_CF2", this.XCHG_CF2);
    __sqoop$field_map.put("XCHG_CF3", this.XCHG_CF3);
    __sqoop$field_map.put("XCHG_CF4", this.XCHG_CF4);
    __sqoop$field_map.put("XCHG_CF5", this.XCHG_CF5);
    __sqoop$field_map.put("ACU_PREM_DIV_CD", this.ACU_PREM_DIV_CD);
    __sqoop$field_map.put("PY_EXEM_ST_DT", this.PY_EXEM_ST_DT);
    __sqoop$field_map.put("ELP_YR_NUM", this.ELP_YR_NUM);
    __sqoop$field_map.put("ELP_MM_NUM", this.ELP_MM_NUM);
    __sqoop$field_map.put("TT_ELP_MM_NUM", this.TT_ELP_MM_NUM);
    __sqoop$field_map.put("UNPSS_MM_NUM", this.UNPSS_MM_NUM);
    __sqoop$field_map.put("CMPT_STD_DT", this.CMPT_STD_DT);
    __sqoop$field_map.put("PRPY_TIMS", this.PRPY_TIMS);
    __sqoop$field_map.put("LPS_DT", this.LPS_DT);
    __sqoop$field_map.put("EXPC_LPS_DT", this.EXPC_LPS_DT);
    __sqoop$field_map.put("PRDCH_ENDR_HIS_STD_NO", this.PRDCH_ENDR_HIS_STD_NO);
    __sqoop$field_map.put("PREM_ENDR_HIS_STD_NO", this.PREM_ENDR_HIS_STD_NO);
    __sqoop$field_map.put("APL_NPTD_RDY_AMT", this.APL_NPTD_RDY_AMT);
    __sqoop$field_map.put("STND_NPTD_RDY_AMT", this.STND_NPTD_RDY_AMT);
    __sqoop$field_map.put("APL_TMTD_RDY_AMT", this.APL_TMTD_RDY_AMT);
    __sqoop$field_map.put("STND_TMTD_RDY_AMT", this.STND_TMTD_RDY_AMT);
    __sqoop$field_map.put("UNPSS_PREM", this.UNPSS_PREM);
    __sqoop$field_map.put("GURT_UNRPD_ACQ_EXP", this.GURT_UNRPD_ACQ_EXP);
    __sqoop$field_map.put("XPT_ACQ_EXP_TAMT", this.XPT_ACQ_EXP_TAMT);
    __sqoop$field_map.put("STND_ACQ_EXP_TAMT", this.STND_ACQ_EXP_TAMT);
    __sqoop$field_map.put("NRM_INTR_ACU_AMT", this.NRM_INTR_ACU_AMT);
    __sqoop$field_map.put("GRAD_INTR_ACU_AMT", this.GRAD_INTR_ACU_AMT);
    __sqoop$field_map.put("DFR_BGN_RDY_AMT", this.DFR_BGN_RDY_AMT);
    __sqoop$field_map.put("ACU_UNRPD_ACQ_EXP", this.ACU_UNRPD_ACQ_EXP);
    __sqoop$field_map.put("PAY_TT_FINC_AMT", this.PAY_TT_FINC_AMT);
    __sqoop$field_map.put("NRM_INTR_MID_AMT", this.NRM_INTR_MID_AMT);
    __sqoop$field_map.put("GRAD_INTR_MID_AMT", this.GRAD_INTR_MID_AMT);
    __sqoop$field_map.put("NRM_INTR_ALTN_PY_PREM", this.NRM_INTR_ALTN_PY_PREM);
    __sqoop$field_map.put("GRAD_INTR_ALTN_PY_PREM", this.GRAD_INTR_ALTN_PY_PREM);
    __sqoop$field_map.put("LPS_IAMT_RT", this.LPS_IAMT_RT);
    __sqoop$field_map.put("LPS_IAMT", this.LPS_IAMT);
    __sqoop$field_map.put("PRPY_RDY_AMT", this.PRPY_RDY_AMT);
    __sqoop$field_map.put("PRPY_IAMT", this.PRPY_IAMT);
    __sqoop$field_map.put("PVCTR_RDY_AMT", this.PVCTR_RDY_AMT);
    __sqoop$field_map.put("NPTD_RDY_AMT", this.NPTD_RDY_AMT);
    __sqoop$field_map.put("TMTD_RDY_AMT", this.TMTD_RDY_AMT);
    __sqoop$field_map.put("CNTD_RDY_AMT", this.CNTD_RDY_AMT);
    __sqoop$field_map.put("APL_CNTD_RDY_AMT", this.APL_CNTD_RDY_AMT);
    __sqoop$field_map.put("STND_CNTD_RDY_AMT", this.STND_CNTD_RDY_AMT);
    __sqoop$field_map.put("COV_SLZ_PREM", this.COV_SLZ_PREM);
    __sqoop$field_map.put("CAL_DT", this.CAL_DT);
    __sqoop$field_map.put("NITR_ACU_COV_PPI", this.NITR_ACU_COV_PPI);
    __sqoop$field_map.put("GITR_ACU_COV_PPI", this.GITR_ACU_COV_PPI);
    __sqoop$field_map.put("LWRT_TMN_RFD_RT", this.LWRT_TMN_RFD_RT);
    __sqoop$field_map.put("STY_XACQ_EXP_TAMT", this.STY_XACQ_EXP_TAMT);
    __sqoop$field_map.put("STY_STND_ACQ_EXP_TAMT", this.STY_STND_ACQ_EXP_TAMT);
    __sqoop$field_map.put("STY_GURT_URPAE", this.STY_GURT_URPAE);
    __sqoop$field_map.put("STY_STND_URPAE", this.STY_STND_URPAE);
    __sqoop$field_map.put("TMTD_LPS_IAMT", this.TMTD_LPS_IAMT);
    __sqoop$field_map.put("RNWL_ED_PRD_DIV_CD", this.RNWL_ED_PRD_DIV_CD);
    __sqoop$field_map.put("RNWL_ED_PRD", this.RNWL_ED_PRD);
    __sqoop$field_map.put("RNWL_ED_AGE", this.RNWL_ED_AGE);
    __sqoop$field_map.put("RNWL_ED_DT", this.RNWL_ED_DT);
    __sqoop$field_map.put("RNWL_TMS", this.RNWL_TMS);
    __sqoop$field_map.put("STD_SBC_AMT", this.STD_SBC_AMT);
    __sqoop$field_map.put("EIH_LDG_DTM", this.EIH_LDG_DTM);
  }

  public void setField(String __fieldName, Object __fieldVal) {
    if (!setters.containsKey(__fieldName)) {
      throw new RuntimeException("No such field:"+__fieldName);
    }
    setters.get(__fieldName).setField(__fieldVal);
  }

}
