#!/bin/bash

if [ $# -eq 0 ]
then           
    ARGS=N    
else           
    ARGS=$1
fi             

NOW=$(date +"+%Y-%m-%d_%T")
SHLOG_DIR=/sqoopbin/scripts/etlpgm/cur_log
HISLOG_DIR=/sqoopbin/scripts/etlpgm/his_log

export HADOOP_OPTS=-Djava.security.egd=file:/dev/../dev/urandom
export ORACLE_BASE=/sw/oracle
export ORACLE_HOME=/sw/oracle/product/11.2.0.4/client_1
export LD_LIBRARY_PATH=/sw/oracle/product/11.2.0.4/client_1/lib:/sw/oracle/product/11.2.0.4/client_1/lib:
export PATH=/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/usr/lib64/qt-3.3/bin:/usr/hdp/3.0.0.0-1634/spark2/bin/:/var/opt/node/bin/:/opt/maven/bin:/usr/local/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/home/hdpapp/workspace/data-science-at-the-command-line/tools:/home/hdpapp/.local/bin:/home/hdpapp/bin
export TNS_ADMIN=/sw/oracle/product/11.2.0.4/client_1/network/admin
export ORACLE_SID=DBEDWP2
export NLS_LANG=American_America.KO16MSWIN949

#----------------------------------------------------#
# 작업내용 : THDDH_TCTCTORCLG 테이블 sqoop 복제 작업
# 작업주기 :  
#----------------------------------------------------#

    echo " "
    echo "*-----------[ THDDH_TCTCTORCLG.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TCTCTORCLG.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`  >  ${SHLOG_DIR}/THDDH_TCTCTORCLG.shlog

#----------------------------------------------------#
# 테이블별 전체 데이터를 받아 오는 부분
#----------------------------------------------------#
    /usr/bin/hadoop fs -rm -r -f  /tmp2/LAST_THDDH_TCTCTORCLG  >> ${SHLOG_DIR}/THDDH_TCTCTORCLG.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.LAST_THDDH_TCTCTORCLG ; " >> ${SHLOG_DIR}/THDDH_TCTCTORCLG.shlog 2>&1 &&
    /usr/hdp/3.0.0.0-1634/sqoop/bin/sqoop import -D mapred.child.java.opts="-Djava.security.egd=file:/dev/../dev/urandom" \
    --connect jdbc:oracle:thin:EDWHADOOP/wjdqhrP\!23@10.91.41.172:12560:DBEDWP2 \
    --username  EDWHADOOP \
    --password wjdqhrP\!23 \
    --query "SELECT /*+ FULL(THDDH_TCTCTORCLG) */ REPLACE(REPLACE(CTR_ID,CHR(13),''),CHR(10),'') CTR_ID
, REPLACE(REPLACE(CLOG_YYMM,CHR(13),''),CHR(10),'') CLOG_YYMM
, REPLACE(REPLACE(PRTN_NO,CHR(13),''),CHR(10),'') PRTN_NO
, REPLACE(REPLACE(POL_NO,CHR(13),''),CHR(10),'') POL_NO
, REPLACE(REPLACE(UNT_PD_CD,CHR(13),''),CHR(10),'') UNT_PD_CD
, REPLACE(REPLACE(SAL_PD_CD,CHR(13),''),CHR(10),'') SAL_PD_CD
, REPLACE(REPLACE(SBCP_CHN_DIV_CD,CHR(13),''),CHR(10),'') SBCP_CHN_DIV_CD
, REPLACE(REPLACE(SAL_CHN_DIV_CD,CHR(13),''),CHR(10),'') SAL_CHN_DIV_CD
, REPLACE(REPLACE(SALPE_ORG_DIV_CD,CHR(13),''),CHR(10),'') SALPE_ORG_DIV_CD
, REPLACE(REPLACE(PY_CYC_CD,CHR(13),''),CHR(10),'') PY_CYC_CD
, REPLACE(REPLACE(MNCL_MD_CD,CHR(13),''),CHR(10),'') MNCL_MD_CD
, REPLACE(REPLACE(CTR_STAT_CD,CHR(13),''),CHR(10),'') CTR_STAT_CD
, REPLACE(REPLACE(CTR_STAT_DTL_CD,CHR(13),''),CHR(10),'') CTR_STAT_DTL_CD
, SBCP_DT
, INS_BGN_DT
, INS_ED_DT
, REPLACE(REPLACE(OWN_CTR_YN,CHR(13),''),CHR(10),'') OWN_CTR_YN
, REPLACE(REPLACE(RCRT_TRTPE_ORG_ID,CHR(13),''),CHR(10),'') RCRT_TRTPE_ORG_ID
, REPLACE(REPLACE(RCRT_AGC_BROF_ORG_ID,CHR(13),''),CHR(10),'') RCRT_AGC_BROF_ORG_ID
, REPLACE(REPLACE(RCRT_AGPLR_ORG_ID,CHR(13),''),CHR(10),'') RCRT_AGPLR_ORG_ID
, REPLACE(REPLACE(SMRZ_ORG_ID,CHR(13),''),CHR(10),'') SMRZ_ORG_ID
, REPLACE(REPLACE(BZ_SB_THNK_CMTT_ORG_ID,CHR(13),''),CHR(10),'') BZ_SB_THNK_CMTT_ORG_ID
, REPLACE(REPLACE(HDQT_ORG_ID,CHR(13),''),CHR(10),'') HDQT_ORG_ID
, REPLACE(REPLACE(BRCH_ORG_ID,CHR(13),''),CHR(10),'') BRCH_ORG_ID
, REPLACE(REPLACE(BCH_ORG_ID,CHR(13),''),CHR(10),'') BCH_ORG_ID
, REPLACE(REPLACE(BCH_DRBG_TEM_ORG_ID,CHR(13),''),CHR(10),'') BCH_DRBG_TEM_ORG_ID
, REPLACE(REPLACE(TRTPE_ORG_ID,CHR(13),''),CHR(10),'') TRTPE_ORG_ID
, REPLACE(REPLACE(AGC_BROF_ORG_ID,CHR(13),''),CHR(10),'') AGC_BROF_ORG_ID
, REPLACE(REPLACE(AGPLR_ORG_ID,CHR(13),''),CHR(10),'') AGPLR_ORG_ID
, REPLACE(REPLACE(RLMR_ORG_ID,CHR(13),''),CHR(10),'') RLMR_ORG_ID
, REPLACE(REPLACE(RLMR_HGRK_ORG_ID,CHR(13),''),CHR(10),'') RLMR_HGRK_ORG_ID
, SYS_OCC_DTM
, REPLACE(REPLACE(APP_ID,CHR(13),''),CHR(10),'') APP_ID
, EIH_LDG_DTM
, REPLACE(REPLACE(LAST_PY_YYMM,CHR(13),''),CHR(10),'') LAST_PY_YYMM
, REPLACE(REPLACE(RPS_PD_CD,CHR(13),''),CHR(10),'') RPS_PD_CD
, REPLACE(REPLACE(STIC_IDC_PD_CTG_CD,CHR(13),''),CHR(10),'') STIC_IDC_PD_CTG_CD
, REPLACE(REPLACE(SMRZ_ORG_DIV_CD,CHR(13),''),CHR(10),'') SMRZ_ORG_DIV_CD
, REPLACE(REPLACE(SMRZ_ORG_STAT_CD,CHR(13),''),CHR(10),'') SMRZ_ORG_STAT_CD
, REPLACE(REPLACE(BSAC_ORG_DIV_CD,CHR(13),''),CHR(10),'') BSAC_ORG_DIV_CD
, REPLACE(REPLACE(BSAC_ORG_STAT_CD,CHR(13),''),CHR(10),'') BSAC_ORG_STAT_CD
, REPLACE(REPLACE(HDQT_ORG_DIV_CD,CHR(13),''),CHR(10),'') HDQT_ORG_DIV_CD
, REPLACE(REPLACE(HDQT_ORG_STAT_CD,CHR(13),''),CHR(10),'') HDQT_ORG_STAT_CD
, REPLACE(REPLACE(BRCH_ORG_DIV_CD,CHR(13),''),CHR(10),'') BRCH_ORG_DIV_CD
, REPLACE(REPLACE(BRCH_ORG_STAT_CD,CHR(13),''),CHR(10),'') BRCH_ORG_STAT_CD
, REPLACE(REPLACE(BCH_ORG_DIV_CD,CHR(13),''),CHR(10),'') BCH_ORG_DIV_CD
, REPLACE(REPLACE(BCH_ORG_STAT_CD,CHR(13),''),CHR(10),'') BCH_ORG_STAT_CD
, REPLACE(REPLACE(BCDT_ORG_DIV_CD,CHR(13),''),CHR(10),'') BCDT_ORG_DIV_CD
, REPLACE(REPLACE(BCDT_ORG_STAT_CD,CHR(13),''),CHR(10),'') BCDT_ORG_STAT_CD
, REPLACE(REPLACE(TRTPE_ORG_DIV_CD,CHR(13),''),CHR(10),'') TRTPE_ORG_DIV_CD
, REPLACE(REPLACE(TRTPE_ORG_STAT_CD,CHR(13),''),CHR(10),'') TRTPE_ORG_STAT_CD
, REPLACE(REPLACE(AGC_BROF_ORG_DIV_CD,CHR(13),''),CHR(10),'') AGC_BROF_ORG_DIV_CD
, REPLACE(REPLACE(AGC_BROF_ORG_STAT_CD,CHR(13),''),CHR(10),'') AGC_BROF_ORG_STAT_CD
, REPLACE(REPLACE(AGPLR_ORG_DIV_CD,CHR(13),''),CHR(10),'') AGPLR_ORG_DIV_CD
, REPLACE(REPLACE(AGPLR_ORG_STAT_CD,CHR(13),''),CHR(10),'') AGPLR_ORG_STAT_CD
, REPLACE(REPLACE(CTR_STAT_CD2,CHR(13),''),CHR(10),'') CTR_STAT_CD2
, REPLACE(REPLACE(CTR_STAT_DTL_CD2,CHR(13),''),CHR(10),'') CTR_STAT_DTL_CD2
, SLZ_PREM
, LAST_PY_TMS
, REPLACE(REPLACE(ACQ_EXP_AMTZ_YN,CHR(13),''),CHR(10),'') ACQ_EXP_AMTZ_YN
, REPLACE(REPLACE(ICDC_NOCC_YN,CHR(13),''),CHR(10),'') ICDC_NOCC_YN
, PPAT_APL_PREM
, PPAT_SLZ_PREM
, REPLACE(REPLACE(PPAT_LAST_PY_YYMM,CHR(13),''),CHR(10),'') PPAT_LAST_PY_YYMM
, PPAT_LAST_PY_TMS
, PPAT_PY_ST_DT
, PPAT_PY_ED_DT
, REPLACE(REPLACE(ISP_TP_DIV_CD,CHR(13),''),CHR(10),'') ISP_TP_DIV_CD
, REPLACE(REPLACE(POLHD_CUS_ID,CHR(13),''),CHR(10),'') POLHD_CUS_ID
, LPS_DT
, REVV_DT
, EXTNC_DT
, EXTNC_CNC_DT
, REPLACE(REPLACE(DIVD_PD_YN,CHR(13),''),CHR(10),'') DIVD_PD_YN
, ENDR_HIS_STD_NO FROM THDDH_TCTCTORCLG
                       WHERE \$CONDITIONS "\
    --m 8 \
    --boundary-query "SELECT 0, 7 FROM DUAL"\
    --split-by "ORA_HASH(CTR_ID, 7)"\
    --target-dir /tmp2/LAST_THDDH_TCTCTORCLG \
    --hive-import \
    --external-table-dir hdfs:///tmp2/temp_tbl/LAST_THDDH_TCTCTORCLG \
    --hive-overwrite \
    --hive-table DEFAULT.LAST_THDDH_TCTCTORCLG  >> ${SHLOG_DIR}/THDDH_TCTCTORCLG.shlog 2>&1 &&

#----------------------------------------------------#
# Hadoop 원본테이블에 변경분 최종 적용
#----------------------------------------------------#
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TCTCTORCLG_TMP ; " >> ${SHLOG_DIR}/THDDH_TCTCTORCLG.shlog 2>&1 &&
    /usr/bin/hive -e "CREATE EXTERNAL TABLE MERITZ.THDDH_TCTCTORCLG_TMP STORED AS PARQUET TBLPROPERTIES ('PARQUET.COMPRESS'='SNAPPY') AS
                                SELECT *
                                FROM DEFAULT.LAST_THDDH_TCTCTORCLG ;" >> ${SHLOG_DIR}/THDDH_TCTCTORCLG.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.LAST_THDDH_TCTCTORCLG ;" >> ${SHLOG_DIR}/THDDH_TCTCTORCLG.shlog 2>&1 &&
    /usr/bin/hdfs dfs -rm -r -f -skipTrash /warehouse/tablespace/external/hive/last_thddh_tctctorclg >> ${SHLOG_DIR}/THDDH_TCTCTORCLG.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TCTCTORCLG ;" >> ${SHLOG_DIR}/THDDH_TCTCTORCLG.shlog 2>&1 &&
    /usr/bin/hive -e "ALTER TABLE MERITZ.THDDH_TCTCTORCLG_TMP RENAME TO MERITZ.THDDH_TCTCTORCLG ;" >> ${SHLOG_DIR}/THDDH_TCTCTORCLG.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TCTCTORCLG_TMP ;" >> ${SHLOG_DIR}/THDDH_TCTCTORCLG.shlog 2>&1 

if [ $? -ne 0 ]
then             
    echo "*-----------[ THDDH_TCTCTORCLG.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/THDDH_TCTCTORCLG.shlog"
    echo "*-----------[ THDDH_TCTCTORCLG.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/THDDH_TCTCTORCLG.shlog"  >>  ${SHLOG_DIR}/THDDH_TCTCTORCLG.shlog
    echo "*-----------[ THDDH_TCTCTORCLG.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TCTCTORCLG.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/THDDH_TCTCTORCLG.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/THDDH_TCTCTORCLG.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCTCTORCLG.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCTCTORCLG.shlog /sqoopbin/scripts/etlpgm/his_log/THDDH_TCTCTORCLG_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  THDDH_TCTCTORCLG.sh cmd command error !! ***
    fi               

    exit -1      

else             
    echo "*-----------[ THDDH_TCTCTORCLG.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TCTCTORCLG.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/THDDH_TCTCTORCLG.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/THDDH_TCTCTORCLG.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCTCTORCLG.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCTCTORCLG.shlog /sqoopbin/scripts/etlpgm/his_log/THDDH_TCTCTORCLG_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  THDDH_TCTCTORCLG.sh cmd command error !! ***
        exit -1      
    else             
        exit 0       
    fi               
fi               
