#!/bin/bash

if [ $# -eq 0 ]
then           
    ARGS=N    
else           
    ARGS=$1
fi             

NOW=$(date +"+%Y-%m-%d_%T")
SHLOG_DIR=/sqoopbin/scripts/etlpgm/cur_log
HISLOG_DIR=/sqoopbin/scripts/etlpgm/his_log

export HADOOP_OPTS=-Djava.security.egd=file:/dev/../dev/urandom
export ORACLE_BASE=/sw/oracle
export ORACLE_HOME=/sw/oracle/product/11.2.0.4/client_1
export LD_LIBRARY_PATH=/sw/oracle/product/11.2.0.4/client_1/lib:/sw/oracle/product/11.2.0.4/client_1/lib:
export PATH=/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/usr/lib64/qt-3.3/bin:/usr/hdp/3.0.0.0-1634/spark2/bin/:/var/opt/node/bin/:/opt/maven/bin:/usr/local/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/home/hdpapp/workspace/data-science-at-the-command-line/tools:/home/hdpapp/.local/bin:/home/hdpapp/bin
export TNS_ADMIN=/sw/oracle/product/11.2.0.4/client_1/network/admin
export ORACLE_SID=DBEDWP2
export NLS_LANG=American_America.KO16MSWIN949

#----------------------------------------------------#
# 작업내용 : THDDH_TSACRORGNU 테이블 sqoop 복제 작업
# 작업주기 :  
#----------------------------------------------------#

    echo " "
    echo "*-----------[ THDDH_TSACRORGNU.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TSACRORGNU.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`  >  ${SHLOG_DIR}/THDDH_TSACRORGNU.shlog

#----------------------------------------------------#
# 테이블별 전체 데이터를 받아 오는 부분
#----------------------------------------------------#
    /usr/bin/hadoop fs -rm -r -f  /tmp2/LAST_THDDH_TSACRORGNU  >> ${SHLOG_DIR}/THDDH_TSACRORGNU.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.LAST_THDDH_TSACRORGNU ; " >> ${SHLOG_DIR}/THDDH_TSACRORGNU.shlog 2>&1 &&
    /usr/hdp/3.0.0.0-1634/sqoop/bin/sqoop import -D mapred.child.java.opts="-Djava.security.egd=file:/dev/../dev/urandom" \
    --connect jdbc:oracle:thin:EDWHADOOP/wjdqhrP\!23@10.91.41.172:12560:DBEDWP2 \
    --username  EDWHADOOP \
    --password wjdqhrP\!23 \
    --query "SELECT /*+ FULL(THDDH_TSACRORGNU) */ REPLACE(REPLACE(SLZ_CTR_ORIG_ID,CHR(13),''),CHR(10),'') SLZ_CTR_ORIG_ID
, REPLACE(REPLACE(STD_YYMM,CHR(13),''),CHR(10),'') STD_YYMM
, STD_DNO
, REPLACE(REPLACE(DATA_PCS_DIV_CD,CHR(13),''),CHR(10),'') DATA_PCS_DIV_CD
, REPLACE(REPLACE(POL_NO,CHR(13),''),CHR(10),'') POL_NO
, ENDR_NO
, REPLACE(REPLACE(PREM_PYRC_XPT_ID,CHR(13),''),CHR(10),'') PREM_PYRC_XPT_ID
, REPLACE(REPLACE(FEE_RCRD_KD_CD,CHR(13),''),CHR(10),'') FEE_RCRD_KD_CD
, REPLACE(REPLACE(TRTPE_ORG_ID,CHR(13),''),CHR(10),'') TRTPE_ORG_ID
, REPLACE(REPLACE(PY_YYMM,CHR(13),''),CHR(10),'') PY_YYMM
, PY_TMS
, NMPY_SEQ
, REPLACE(REPLACE(FEE_SLZ_FML_DIV_CD,CHR(13),''),CHR(10),'') FEE_SLZ_FML_DIV_CD
, REPLACE(REPLACE(PREM_PYRC_ID,CHR(13),''),CHR(10),'') PREM_PYRC_ID
, REPLACE(REPLACE(ETPY_PCS_ACRSL_DIV_CD,CHR(13),''),CHR(10),'') ETPY_PCS_ACRSL_DIV_CD
, SUMUP_DT
, RCPT_DT
, SBCP_DT
, ENDR_DT
, REPLACE(REPLACE(SLZ_ACRSL_BIZ_DIV_CD,CHR(13),''),CHR(10),'') SLZ_ACRSL_BIZ_DIV_CD
, REPLACE(REPLACE(SLZ_ACRSL_PD_CTG_CD,CHR(13),''),CHR(10),'') SLZ_ACRSL_PD_CTG_CD
, REPLACE(REPLACE(PD_CD,CHR(13),''),CHR(10),'') PD_CD
, REPLACE(REPLACE(SAL_PD_CD,CHR(13),''),CHR(10),'') SAL_PD_CD
, REPLACE(REPLACE(RCIP_NO,CHR(13),''),CHR(10),'') RCIP_NO
, REPLACE(REPLACE(PYRC_DIV_CD,CHR(13),''),CHR(10),'') PYRC_DIV_CD
, REPLACE(REPLACE(MNCL_MD_CD,CHR(13),''),CHR(10),'') MNCL_MD_CD
, REPLACE(REPLACE(HDQT_ORG_ID,CHR(13),''),CHR(10),'') HDQT_ORG_ID
, REPLACE(REPLACE(BRCH_ORG_ID,CHR(13),''),CHR(10),'') BRCH_ORG_ID
, REPLACE(REPLACE(BCH_ORG_ID,CHR(13),''),CHR(10),'') BCH_ORG_ID
, REPLACE(REPLACE(TEM_ORG_ID,CHR(13),''),CHR(10),'') TEM_ORG_ID
, REPLACE(REPLACE(AGC_BROF_ORG_ID,CHR(13),''),CHR(10),'') AGC_BROF_ORG_ID
, REPLACE(REPLACE(BNCA_COPR_FNC_INST_CD,CHR(13),''),CHR(10),'') BNCA_COPR_FNC_INST_CD
, REPLACE(REPLACE(BNCA_PD_CD,CHR(13),''),CHR(10),'') BNCA_PD_CD
, REPLACE(REPLACE(BNCA_AFLCO_MNG_NO,CHR(13),''),CHR(10),'') BNCA_AFLCO_MNG_NO
, REPLACE(REPLACE(BNCA_INP_MBDY_DIV_CD,CHR(13),''),CHR(10),'') BNCA_INP_MBDY_DIV_CD
, REPLACE(REPLACE(GUEMP_ORG_ID,CHR(13),''),CHR(10),'') GUEMP_ORG_ID
, REPLACE(REPLACE(CLLPE_ORG_ID,CHR(13),''),CHR(10),'') CLLPE_ORG_ID
, REPLACE(REPLACE(AGPLR_ORG_ID,CHR(13),''),CHR(10),'') AGPLR_ORG_ID
, RCPT_PREM
, REPLACE(REPLACE(INDV_CRP_DIV_CD,CHR(13),''),CHR(10),'') INDV_CRP_DIV_CD
, REPLACE(REPLACE(POLHD_PTY_ID,CHR(13),''),CHR(10),'') POLHD_PTY_ID
, REPLACE(REPLACE(POLHD_NM,CHR(13),''),CHR(10),'') POLHD_NM
, REPLACE(REPLACE(SOLIC_ORG_ID,CHR(13),''),CHR(10),'') SOLIC_ORG_ID
, REPLACE(REPLACE(GRPCO_YN,CHR(13),''),CHR(10),'') GRPCO_YN
, REPLACE(REPLACE(PY_CYC_CD,CHR(13),''),CHR(10),'') PY_CYC_CD
, INS_BGN_DT
, INS_ED_DT
, REPLACE(REPLACE(CTR_STAT_CD,CHR(13),''),CHR(10),'') CTR_STAT_CD
, CTR_INP_DT
, REPLACE(REPLACE(CTR_INP_TM,CHR(13),''),CHR(10),'') CTR_INP_TM
, REPLACE(REPLACE(SOFF_PCS_DIV_CD,CHR(13),''),CHR(10),'') SOFF_PCS_DIV_CD
, REPLACE(REPLACE(ZPCD,CHR(13),''),CHR(10),'') ZPCD
, REPLACE(REPLACE(AMT_KD_CD,CHR(13),''),CHR(10),'') AMT_KD_CD
, EXRT
, REPLACE(REPLACE(CUR_CD,CHR(13),''),CHR(10),'') CUR_CD
, REPLACE(REPLACE(FEE_CAL_EXPT_DIV_CD,CHR(13),''),CHR(10),'') FEE_CAL_EXPT_DIV_CD
, REPLACE(REPLACE(PYRC_XPT_CD,CHR(13),''),CHR(10),'') PYRC_XPT_CD
, REPLACE(REPLACE(ORGN_SLZ_CTR_ORIG_ID,CHR(13),''),CHR(10),'') ORGN_SLZ_CTR_ORIG_ID
, REPLACE(REPLACE(INPPE_ORG_ID,CHR(13),''),CHR(10),'') INPPE_ORG_ID
, SYS_OCC_DTM
, REPLACE(REPLACE(SYS_DEL_DIV_CD,CHR(13),''),CHR(10),'') SYS_DEL_DIV_CD
, REPLACE(REPLACE(APP_ID,CHR(13),''),CHR(10),'') APP_ID
, REPLACE(REPLACE(OCC_IP,CHR(13),''),CHR(10),'') OCC_IP
, DATA_CHNG_DTM
, REPLACE(REPLACE(FB_AT_TRS_YN,CHR(13),''),CHR(10),'') FB_AT_TRS_YN
, FB_AT_TRS_DT
, REPLACE(REPLACE(FB_AT_TRS_PCS_YN,CHR(13),''),CHR(10),'') FB_AT_TRS_PCS_YN
, REPLACE(REPLACE(BNCA_BCH_CD,CHR(13),''),CHR(10),'') BNCA_BCH_CD
, REPLACE(REPLACE(PMNT_NO,CHR(13),''),CHR(10),'') PMNT_NO
, EIH_LDG_DTM FROM THDDH_TSACRORGNU
                       WHERE \$CONDITIONS "\
    --m 8 \
    --boundary-query "SELECT 0, 7 FROM DUAL"\
    --split-by "ORA_HASH(SLZ_CTR_ORIG_ID, 7)"\
    --target-dir /tmp2/LAST_THDDH_TSACRORGNU \
    --hive-import \
    --external-table-dir hdfs:///tmp2/temp_tbl/LAST_THDDH_TSACRORGNU \
    --hive-overwrite \
    --hive-table DEFAULT.LAST_THDDH_TSACRORGNU  >> ${SHLOG_DIR}/THDDH_TSACRORGNU.shlog 2>&1 &&

#----------------------------------------------------#
# Hadoop 원본테이블에 변경분 최종 적용
#----------------------------------------------------#
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TSACRORGNU_TMP ; " >> ${SHLOG_DIR}/THDDH_TSACRORGNU.shlog 2>&1 &&
    /usr/bin/hive -e "CREATE EXTERNAL TABLE MERITZ.THDDH_TSACRORGNU_TMP STORED AS PARQUET TBLPROPERTIES ('PARQUET.COMPRESS'='SNAPPY') AS
                                SELECT *
                                FROM DEFAULT.LAST_THDDH_TSACRORGNU ;" >> ${SHLOG_DIR}/THDDH_TSACRORGNU.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.LAST_THDDH_TSACRORGNU ;" >> ${SHLOG_DIR}/THDDH_TSACRORGNU.shlog 2>&1 &&
    /usr/bin/hdfs dfs -rm -r -f -skipTrash /warehouse/tablespace/external/hive/last_thddh_tsacrorgnu >> ${SHLOG_DIR}/THDDH_TSACRORGNU.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TSACRORGNU ;" >> ${SHLOG_DIR}/THDDH_TSACRORGNU.shlog 2>&1 &&
    /usr/bin/hive -e "ALTER TABLE MERITZ.THDDH_TSACRORGNU_TMP RENAME TO MERITZ.THDDH_TSACRORGNU ;" >> ${SHLOG_DIR}/THDDH_TSACRORGNU.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TSACRORGNU_TMP ;" >> ${SHLOG_DIR}/THDDH_TSACRORGNU.shlog 2>&1 

if [ $? -ne 0 ]
then             
    echo "*-----------[ THDDH_TSACRORGNU.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/THDDH_TSACRORGNU.shlog"
    echo "*-----------[ THDDH_TSACRORGNU.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/THDDH_TSACRORGNU.shlog"  >>  ${SHLOG_DIR}/THDDH_TSACRORGNU.shlog
    echo "*-----------[ THDDH_TSACRORGNU.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TSACRORGNU.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/THDDH_TSACRORGNU.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/THDDH_TSACRORGNU.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TSACRORGNU.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TSACRORGNU.shlog /sqoopbin/scripts/etlpgm/his_log/THDDH_TSACRORGNU_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  THDDH_TSACRORGNU.sh cmd command error !! ***
    fi               

    exit -1      

else             
    echo "*-----------[ THDDH_TSACRORGNU.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TSACRORGNU.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/THDDH_TSACRORGNU.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/THDDH_TSACRORGNU.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TSACRORGNU.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TSACRORGNU.shlog /sqoopbin/scripts/etlpgm/his_log/THDDH_TSACRORGNU_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  THDDH_TSACRORGNU.sh cmd command error !! ***
        exit -1      
    else             
        exit 0       
    fi               
fi               
