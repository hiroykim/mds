#!/bin/bash

if [ $# -eq 0 ]
then           
    ARGS=N    
else           
    ARGS=$1
fi             

NOW=$(date +"+%Y-%m-%d_%T")
SHLOG_DIR=/sqoopbin/scripts/etlpgm/cur_log
HISLOG_DIR=/sqoopbin/scripts/etlpgm/his_log

export HADOOP_OPTS=-Djava.security.egd=file:/dev/../dev/urandom
export ORACLE_BASE=/sw/oracle
export ORACLE_HOME=/sw/oracle/product/11.2.0.4/client_1
export LD_LIBRARY_PATH=/sw/oracle/product/11.2.0.4/client_1/lib:/sw/oracle/product/11.2.0.4/client_1/lib:
export PATH=/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/usr/lib64/qt-3.3/bin:/usr/hdp/3.0.0.0-1634/spark2/bin/:/var/opt/node/bin/:/opt/maven/bin:/usr/local/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/home/hdpapp/workspace/data-science-at-the-command-line/tools:/home/hdpapp/.local/bin:/home/hdpapp/bin
export TNS_ADMIN=/sw/oracle/product/11.2.0.4/client_1/network/admin
export ORACLE_SID=DBEDWP2
export NLS_LANG=American_America.KO16MSWIN949

#----------------------------------------------------#
# 작업내용 : THDDH_TSALTCCTON 테이블 sqoop 복제 작업
# 작업주기 :  
#----------------------------------------------------#

    echo " "
    echo "*-----------[ THDDH_TSALTCCTON.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TSALTCCTON.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`  >  ${SHLOG_DIR}/THDDH_TSALTCCTON.shlog

#----------------------------------------------------#
# 테이블별 전체 데이터를 받아 오는 부분
#----------------------------------------------------#
    /usr/bin/hadoop fs -rm -r -f  /tmp2/LAST_THDDH_TSALTCCTON  >> ${SHLOG_DIR}/THDDH_TSALTCCTON.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.LAST_THDDH_TSALTCCTON ; " >> ${SHLOG_DIR}/THDDH_TSALTCCTON.shlog 2>&1 &&
    /usr/hdp/3.0.0.0-1634/sqoop/bin/sqoop import -D mapred.child.java.opts="-Djava.security.egd=file:/dev/../dev/urandom" \
    --connect jdbc:oracle:thin:EDWHADOOP/wjdqhrP\!23@10.91.41.172:12560:DBEDWP2 \
    --username  EDWHADOOP \
    --password wjdqhrP\!23 \
    --query "SELECT /*+ FULL(THDDH_TSALTCCTON) */ REPLACE(REPLACE(SLZ_CTR_ORIG_ID,CHR(13),''),CHR(10),'') SLZ_CTR_ORIG_ID
, REPLACE(REPLACE(STD_YYMM,CHR(13),''),CHR(10),'') STD_YYMM
, STD_DNO
, REPLACE(REPLACE(DATA_PCS_DIV_CD,CHR(13),''),CHR(10),'') DATA_PCS_DIV_CD
, REPLACE(REPLACE(POL_NO,CHR(13),''),CHR(10),'') POL_NO
, ENDR_NO
, REPLACE(REPLACE(PREM_PYRC_XPT_ID,CHR(13),''),CHR(10),'') PREM_PYRC_XPT_ID
, REPLACE(REPLACE(FEE_RCRD_KD_CD,CHR(13),''),CHR(10),'') FEE_RCRD_KD_CD
, REPLACE(REPLACE(TRTPE_ORG_ID,CHR(13),''),CHR(10),'') TRTPE_ORG_ID
, REPLACE(REPLACE(PY_YYMM,CHR(13),''),CHR(10),'') PY_YYMM
, PY_TMS
, NMPY_SEQ
, REPLACE(REPLACE(FEE_SLZ_FML_DIV_CD,CHR(13),''),CHR(10),'') FEE_SLZ_FML_DIV_CD
, REPLACE(REPLACE(NW_STIC_PD_CTG_CD,CHR(13),''),CHR(10),'') NW_STIC_PD_CTG_CD
, REPLACE(REPLACE(RCPT_TPT_TRT_ORG_ID,CHR(13),''),CHR(10),'') RCPT_TPT_TRT_ORG_ID
, MNCPE_CHNG_DT
, FTM_SUMUP_DT
, PY_PRD_YR_NUM
, INS_PRD_YR_NUM
, PRPY_ARRG_TIMS
, MDF_PREM
, GRUP_PE_NUM
, SBC_AGE
, REPLACE(REPLACE(CLF_DIV_CD,CHR(13),''),CHR(10),'') CLF_DIV_CD
, INSD_AMT
, REPLACE(REPLACE(INDV_GRUP_DIV_CD,CHR(13),''),CHR(10),'') INDV_GRUP_DIV_CD
, INDT_SBC_AMT
, TRF_DTH_SBC_AMT
, DIDT_SBC_AMT
, REPLACE(REPLACE(CHAN_DIV_CD,CHR(13),''),CHR(10),'') CHAN_DIV_CD
, NTLY_DT
, CAL1_PREM
, CAL2_PREM
, REPLACE(REPLACE(FEE_DC_XCHG_DIV_CD,CHR(13),''),CHR(10),'') FEE_DC_XCHG_DIV_CD
, REPLACE(REPLACE(CLUS_LON_YN,CHR(13),''),CHR(10),'') CLUS_LON_YN
, CLLPE_CTR_ENTCO_DMM
, REPLACE(REPLACE(PRPY_ARRG_DIV_CD,CHR(13),''),CHR(10),'') PRPY_ARRG_DIV_CD
, REPLACE(REPLACE(PLAN_CD,CHR(13),''),CHR(10),'') PLAN_CD
, REPLACE(REPLACE(TMSTP_NMNT_DIV_CD,CHR(13),''),CHR(10),'') TMSTP_NMNT_DIV_CD
, NMNT_TMS
, REPLACE(REPLACE(LGTM_FEE_TMS_DIV_CD,CHR(13),''),CHR(10),'') LGTM_FEE_TMS_DIV_CD
, INS_EXPR_AGE
, REPLACE(REPLACE(CHAN_CTR_YN,CHR(13),''),CHR(10),'') CHAN_CTR_YN
, REPLACE(REPLACE(ALTN_PY_YN,CHR(13),''),CHR(10),'') ALTN_PY_YN
, APL_PREM
, MMPY_CNVS_PREM
, REPLACE(REPLACE(INPPE_ORG_ID,CHR(13),''),CHR(10),'') INPPE_ORG_ID
, SYS_OCC_DTM
, REPLACE(REPLACE(SYS_DEL_DIV_CD,CHR(13),''),CHR(10),'') SYS_DEL_DIV_CD
, REPLACE(REPLACE(APP_ID,CHR(13),''),CHR(10),'') APP_ID
, REPLACE(REPLACE(OCC_IP,CHR(13),''),CHR(10),'') OCC_IP
, DATA_CHNG_DTM
, EIH_LDG_DTM
, REPLACE(REPLACE(RNWL_DIV_CD,CHR(13),''),CHR(10),'') RNWL_DIV_CD
, REPLACE(REPLACE(ELC_SBCP_YN,CHR(13),''),CHR(10),'') ELC_SBCP_YN
, GURT_PREM
, ACU_PREM
, CNOR_RCPTPT_SUMUP_DT
, MNCL_RCPT_PREM
, SAV_RCPT_PREM
, REPLACE(REPLACE(BTH_BF_PREM_YN,CHR(13),''),CHR(10),'') BTH_BF_PREM_YN
, BTH_AF_PY_TMS FROM THDDH_TSALTCCTON
                       WHERE \$CONDITIONS "\
    --m 8 \
    --boundary-query "SELECT 0, 7 FROM DUAL"\
    --split-by "ORA_HASH(SLZ_CTR_ORIG_ID, 7)"\
    --target-dir /tmp2/LAST_THDDH_TSALTCCTON \
    --hive-import \
    --external-table-dir hdfs:///tmp2/temp_tbl/LAST_THDDH_TSALTCCTON \
    --hive-overwrite \
    --hive-table DEFAULT.LAST_THDDH_TSALTCCTON  >> ${SHLOG_DIR}/THDDH_TSALTCCTON.shlog 2>&1 &&

#----------------------------------------------------#
# Hadoop 원본테이블에 변경분 최종 적용
#----------------------------------------------------#
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TSALTCCTON_TMP ; " >> ${SHLOG_DIR}/THDDH_TSALTCCTON.shlog 2>&1 &&
    /usr/bin/hive -e "CREATE EXTERNAL TABLE MERITZ.THDDH_TSALTCCTON_TMP STORED AS PARQUET TBLPROPERTIES ('PARQUET.COMPRESS'='SNAPPY') AS
                                SELECT *
                                FROM DEFAULT.LAST_THDDH_TSALTCCTON ;" >> ${SHLOG_DIR}/THDDH_TSALTCCTON.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.LAST_THDDH_TSALTCCTON ;" >> ${SHLOG_DIR}/THDDH_TSALTCCTON.shlog 2>&1 &&
    /usr/bin/hdfs dfs -rm -r -f -skipTrash /warehouse/tablespace/external/hive/last_thddh_tsaltccton >> ${SHLOG_DIR}/THDDH_TSALTCCTON.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TSALTCCTON ;" >> ${SHLOG_DIR}/THDDH_TSALTCCTON.shlog 2>&1 &&
    /usr/bin/hive -e "ALTER TABLE MERITZ.THDDH_TSALTCCTON_TMP RENAME TO MERITZ.THDDH_TSALTCCTON ;" >> ${SHLOG_DIR}/THDDH_TSALTCCTON.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TSALTCCTON_TMP ;" >> ${SHLOG_DIR}/THDDH_TSALTCCTON.shlog 2>&1 

if [ $? -ne 0 ]
then             
    echo "*-----------[ THDDH_TSALTCCTON.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/THDDH_TSALTCCTON.shlog"
    echo "*-----------[ THDDH_TSALTCCTON.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/THDDH_TSALTCCTON.shlog"  >>  ${SHLOG_DIR}/THDDH_TSALTCCTON.shlog
    echo "*-----------[ THDDH_TSALTCCTON.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TSALTCCTON.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/THDDH_TSALTCCTON.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/THDDH_TSALTCCTON.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TSALTCCTON.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TSALTCCTON.shlog /sqoopbin/scripts/etlpgm/his_log/THDDH_TSALTCCTON_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  THDDH_TSALTCCTON.sh cmd command error !! ***
    fi               

    exit -1      

else             
    echo "*-----------[ THDDH_TSALTCCTON.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TSALTCCTON.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/THDDH_TSALTCCTON.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/THDDH_TSALTCCTON.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TSALTCCTON.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TSALTCCTON.shlog /sqoopbin/scripts/etlpgm/his_log/THDDH_TSALTCCTON_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  THDDH_TSALTCCTON.sh cmd command error !! ***
        exit -1      
    else             
        exit 0       
    fi               
fi               
