#!/bin/bash

if [ $# -eq 0 ]
then           
    ARGS=N    
else           
    ARGS=$1
fi             

NOW=$(date +"+%Y-%m-%d_%T")
SHLOG_DIR=/sqoopbin/scripts/etlpgm/cur_log
HISLOG_DIR=/sqoopbin/scripts/etlpgm/his_log

export HADOOP_OPTS=-Djava.security.egd=file:/dev/../dev/urandom
export ORACLE_BASE=/sw/oracle
export ORACLE_HOME=/sw/oracle/product/11.2.0.4/client_1
export LD_LIBRARY_PATH=/sw/oracle/product/11.2.0.4/client_1/lib:/sw/oracle/product/11.2.0.4/client_1/lib:
export PATH=/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/usr/lib64/qt-3.3/bin:/usr/hdp/3.0.0.0-1634/spark2/bin/:/var/opt/node/bin/:/opt/maven/bin:/usr/local/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/home/hdpapp/workspace/data-science-at-the-command-line/tools:/home/hdpapp/.local/bin:/home/hdpapp/bin
export TNS_ADMIN=/sw/oracle/product/11.2.0.4/client_1/network/admin
export ORACLE_SID=DBEDWP2
export NLS_LANG=American_America.KO16MSWIN949

#----------------------------------------------------#
# 작업내용 : THDDH_TCLPSBILLD 테이블 sqoop 복제 작업
# 작업주기 :  
#----------------------------------------------------#

    echo " "
    echo "*-----------[ THDDH_TCLPSBILLD.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TCLPSBILLD.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`  >  ${SHLOG_DIR}/THDDH_TCLPSBILLD.shlog

#----------------------------------------------------#
# 테이블별 전체 데이터를 받아 오는 부분
#----------------------------------------------------#
    /usr/bin/hadoop fs -rm -r -f  /tmp2/LAST_THDDH_TCLPSBILLD  >> ${SHLOG_DIR}/THDDH_TCLPSBILLD.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.LAST_THDDH_TCLPSBILLD ; " >> ${SHLOG_DIR}/THDDH_TCLPSBILLD.shlog 2>&1 &&
    /usr/hdp/3.0.0.0-1634/sqoop/bin/sqoop import -D mapred.child.java.opts="-Djava.security.egd=file:/dev/../dev/urandom" \
    --connect jdbc:oracle:thin:EDWHADOOP/wjdqhrP\!23@10.91.41.172:12560:DBEDWP2 \
    --username  EDWHADOOP \
    --password wjdqhrP\!23 \
    --query "SELECT /*+ FULL(THDDH_TCLPSBILLD) */ REPLACE(REPLACE(PSBLL_ID,CHR(13),''),CHR(10),'') PSBLL_ID
, PSBLL_DTL_SEQ
, HIS_SEQ
, REPLACE(REPLACE(MDI_EXP_DIV_CD,CHR(13),''),CHR(10),'') MDI_EXP_DIV_CD
, REPLACE(REPLACE(MDI_EXP_TRM_CD,CHR(13),''),CHR(10),'') MDI_EXP_TRM_CD
, REPLACE(REPLACE(MED_MCHY_LCTG_CD,CHR(13),''),CHR(10),'') MED_MCHY_LCTG_CD
, REPLACE(REPLACE(MED_MCHY_ITM_CD,CHR(13),''),CHR(10),'') MED_MCHY_ITM_CD
, REPLACE(REPLACE(CMOD_NM,CHR(13),''),CHR(10),'') CMOD_NM
, REPLACE(REPLACE(GURT_EXPT_YN,CHR(13),''),CHR(10),'') GURT_EXPT_YN
, CLM_SLPT_SELF_BRD_AMT
, CLM_SLPT_IDP_BRD_AMT
, CLM_SLAT_SELF_BRD_AMT
, CLM_NSRY_CMD_AMT
, CLM_NSRY_CMDX_AMT
, CLM_AMT
, MDT_SLPT_SELF_BRD_AMT
, MDT_SLPT_IDP_BRD_AMT
, MDT_SLAT_SELF_BRD_AMT
, MDT_NSRY_CMD_AMT
, MDT_NSRY_CMDX_AMT
, MDT_AMT
, ACKN_SLPT_SELF_BRD_AMT
, ACKN_SLPT_IDP_BRD_AMT
, ACKN_SLAT_SELF_BRD_AMT
, ACKN_NSRY_CMD_AMT
, ACKN_NSRY_CMDX_AMT
, ACKN_AMT
, CLM_MDC_EXP
, CLM_ACT_FEE
, CLM_ADDT_ACT_FEE
, ACKN_MDC_EXP
, ACKN_ACT_FEE
, ACKN_ADDT_ACT_FEE
, SOFF_AF_MDC_EXP
, SOFF_AF_ACT_FEE
, SOFF_AF_ADDT_ACT_FEE
, SOFF_AF_AMT
, MDT_MDC_EXP
, MDT_ACT_FEE
, MDT_ADDT_ACT_FEE
, DSPT_MDC_EXP
, DSPT_ACT_FEE
, DSPT_ADDT_ACT_FEE
, DSPT_AMT
, QT
, REPLACE(REPLACE(MDI_EXP_MDT_RSN_CD,CHR(13),''),CHR(10),'') MDI_EXP_MDT_RSN_CD
, REPLACE(REPLACE(FIXT_DGN_RGN_CD,CHR(13),''),CHR(10),'') FIXT_DGN_RGN_CD
, REPLACE(REPLACE(MDT_OPIN_CON,CHR(13),''),CHR(10),'') MDT_OPIN_CON
, HIS_ST_DTM
, HIS_ED_DTM
, REPLACE(REPLACE(INPPE_ORG_ID,CHR(13),''),CHR(10),'') INPPE_ORG_ID
, SYS_OCC_DTM
, REPLACE(REPLACE(SYS_DEL_DIV_CD,CHR(13),''),CHR(10),'') SYS_DEL_DIV_CD
, REPLACE(REPLACE(OCC_IP,CHR(13),''),CHR(10),'') OCC_IP
, REPLACE(REPLACE(APP_ID,CHR(13),''),CHR(10),'') APP_ID
, DATA_CHNG_DTM
, EIH_LDG_DTM
, FIX_SLPT_SELF_BRD_AMT
, FIX_SLPT_IDP_BRD_AMT
, FIX_SLAT_SELF_BRD_AMT
, FIX_NSRY_CMD_AMT
, FIX_NSRY_CMDX_AMT
, FIX_AMT
, CTG_SLPT_SELF_BRD_AMT
, CTG_SLPT_IDP_BRD_AMT
, CTG_SLAT_SELF_BRD_AMT
, CTG_NSRY_CMD_AMT
, CTG_NSRY_CMDX_AMT
, CTG_AMT
, CMDT_SLPT_SELF_BRD_AMT
, CMDT_SLPT_IDP_BRD_AMT
, CMDT_SLAT_SELF_BRD_AMT
, CMDT_NSRY_CMD_AMT
, CMDT_NSRY_CMDX_AMT
, CMDT_AMT
, CFIX_SLPT_SELF_BRD_AMT
, CFIX_SLPT_IDP_BRD_AMT
, CFIX_SLAT_SELF_BRD_AMT
, CFIX_NSRY_CMD_AMT
, CFIX_NSRY_CMDX_AMT
, CFIX_AMT
, CAKN_SLPT_SELF_BRD_AMT
, CAKN_SLPT_IDP_BRD_AMT
, CAKN_SLAT_SELF_BRD_AMT
, CAKN_NSRY_CMD_AMT
, CAKN_NSRY_CMDX_AMT
, CAKN_AMT FROM THDDH_TCLPSBILLD
                       WHERE \$CONDITIONS "\
    --m 8 \
    --boundary-query "SELECT 0, 7 FROM DUAL"\
    --split-by "ORA_HASH(PSBLL_ID, 7)"\
    --target-dir /tmp2/LAST_THDDH_TCLPSBILLD \
    --hive-import \
    --external-table-dir hdfs:///tmp2/temp_tbl/LAST_THDDH_TCLPSBILLD \
    --hive-overwrite \
    --hive-table DEFAULT.LAST_THDDH_TCLPSBILLD  >> ${SHLOG_DIR}/THDDH_TCLPSBILLD.shlog 2>&1 &&

#----------------------------------------------------#
# Hadoop 원본테이블에 변경분 최종 적용
#----------------------------------------------------#
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TCLPSBILLD_TMP ; " >> ${SHLOG_DIR}/THDDH_TCLPSBILLD.shlog 2>&1 &&
    /usr/bin/hive -e "CREATE EXTERNAL TABLE MERITZ.THDDH_TCLPSBILLD_TMP STORED AS PARQUET TBLPROPERTIES ('PARQUET.COMPRESS'='SNAPPY') AS
                                SELECT *
                                FROM DEFAULT.LAST_THDDH_TCLPSBILLD ;" >> ${SHLOG_DIR}/THDDH_TCLPSBILLD.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.LAST_THDDH_TCLPSBILLD ;" >> ${SHLOG_DIR}/THDDH_TCLPSBILLD.shlog 2>&1 &&
    /usr/bin/hdfs dfs -rm -r -f -skipTrash /warehouse/tablespace/external/hive/last_thddh_tclpsbilld >> ${SHLOG_DIR}/THDDH_TCLPSBILLD.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TCLPSBILLD ;" >> ${SHLOG_DIR}/THDDH_TCLPSBILLD.shlog 2>&1 &&
    /usr/bin/hive -e "ALTER TABLE MERITZ.THDDH_TCLPSBILLD_TMP RENAME TO MERITZ.THDDH_TCLPSBILLD ;" >> ${SHLOG_DIR}/THDDH_TCLPSBILLD.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TCLPSBILLD_TMP ;" >> ${SHLOG_DIR}/THDDH_TCLPSBILLD.shlog 2>&1 

if [ $? -ne 0 ]
then             
    echo "*-----------[ THDDH_TCLPSBILLD.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/THDDH_TCLPSBILLD.shlog"
    echo "*-----------[ THDDH_TCLPSBILLD.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/THDDH_TCLPSBILLD.shlog"  >>  ${SHLOG_DIR}/THDDH_TCLPSBILLD.shlog
    echo "*-----------[ THDDH_TCLPSBILLD.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TCLPSBILLD.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/THDDH_TCLPSBILLD.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/THDDH_TCLPSBILLD.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCLPSBILLD.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCLPSBILLD.shlog /sqoopbin/scripts/etlpgm/his_log/THDDH_TCLPSBILLD_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  THDDH_TCLPSBILLD.sh cmd command error !! ***
    fi               

    exit -1      

else             
    echo "*-----------[ THDDH_TCLPSBILLD.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TCLPSBILLD.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/THDDH_TCLPSBILLD.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/THDDH_TCLPSBILLD.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCLPSBILLD.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCLPSBILLD.shlog /sqoopbin/scripts/etlpgm/his_log/THDDH_TCLPSBILLD_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  THDDH_TCLPSBILLD.sh cmd command error !! ***
        exit -1      
    else             
        exit 0       
    fi               
fi               
