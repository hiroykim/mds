#!/bin/bash

if [ $# -eq 0 ]
then           
    ARGS=N    
else           
    ARGS=$1
fi             

NOW=$(date +"+%Y-%m-%d_%T")
SHLOG_DIR=/sqoopbin/scripts/etlpgm/cur_log
HISLOG_DIR=/sqoopbin/scripts/etlpgm/his_log

export HADOOP_OPTS=-Djava.security.egd=file:/dev/../dev/urandom
export ORACLE_BASE=/sw/oracle
export ORACLE_HOME=/sw/oracle/product/11.2.0.4/client_1
export LD_LIBRARY_PATH=/sw/oracle/product/11.2.0.4/client_1/lib:/sw/oracle/product/11.2.0.4/client_1/lib:
export PATH=/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/usr/lib64/qt-3.3/bin:/usr/hdp/3.0.0.0-1634/spark2/bin/:/var/opt/node/bin/:/opt/maven/bin:/usr/local/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/home/hdpapp/workspace/data-science-at-the-command-line/tools:/home/hdpapp/.local/bin:/home/hdpapp/bin
export TNS_ADMIN=/sw/oracle/product/11.2.0.4/client_1/network/admin
export ORACLE_SID=DBEDWP2
export NLS_LANG=American_America.KO16MSWIN949

#----------------------------------------------------#
# 작업내용 : THDDH_TCLSCRGDIV 테이블 sqoop 복제 작업
# 작업주기 :  
#----------------------------------------------------#

    echo " "
    echo "*-----------[ THDDH_TCLSCRGDIV.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TCLSCRGDIV.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`  >  ${SHLOG_DIR}/THDDH_TCLSCRGDIV.shlog

#----------------------------------------------------#
# 테이블별 전체 데이터를 받아 오는 부분
#----------------------------------------------------#
    /usr/bin/hadoop fs -rm -r -f  /tmp2/LAST_THDDH_TCLSCRGDIV  >> ${SHLOG_DIR}/THDDH_TCLSCRGDIV.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.LAST_THDDH_TCLSCRGDIV ; " >> ${SHLOG_DIR}/THDDH_TCLSCRGDIV.shlog 2>&1 &&
    /usr/hdp/3.0.0.0-1634/sqoop/bin/sqoop import -D mapred.child.java.opts="-Djava.security.egd=file:/dev/../dev/urandom" \
    --connect jdbc:oracle:thin:EDWHADOOP/wjdqhrP\!23@10.91.41.172:12560:DBEDWP2 \
    --username  EDWHADOOP \
    --password wjdqhrP\!23 \
    --query "SELECT /*+ FULL(THDDH_TCLSCRGDIV) */ REPLACE(REPLACE(CLM_ID,CHR(13),''),CHR(10),'') CLM_ID
, REPLACE(REPLACE(DMPE_ID,CHR(13),''),CHR(10),'') DMPE_ID
, INF_OBM_FIX_SEQ
, HIS_SEQ
, REPLACE(REPLACE(ACD_RCT_ID,CHR(13),''),CHR(10),'') ACD_RCT_ID
, REPLACE(REPLACE(SPFC_DIVD_DIV_CD,CHR(13),''),CHR(10),'') SPFC_DIVD_DIV_CD
, REPLACE(REPLACE(MORL_DIVD_DIV_CD,CHR(13),''),CHR(10),'') MORL_DIVD_DIV_CD
, SCRG_SCR
, REPLACE(REPLACE(CLUNIT_CD,CHR(13),''),CHR(10),'') CLUNIT_CD
, REPLACE(REPLACE(DTH_YN,CHR(13),''),CHR(10),'') DTH_YN
, REPLACE(REPLACE(AFOBS_YN,CHR(13),''),CHR(10),'') AFOBS_YN
, PRSM_INS_AMT
, ACCM_DCN_INS_AMT
, REPLACE(REPLACE(MD_EXP_CUS_GRDE_CD,CHR(13),''),CHR(10),'') MD_EXP_CUS_GRDE_CD
, REPLACE(REPLACE(DDPY_CUS_GRDE_CD,CHR(13),''),CHR(10),'') DDPY_CUS_GRDE_CD
, REPLACE(REPLACE(QUES_HOSP_YN,CHR(13),''),CHR(10),'') QUES_HOSP_YN
, REPLACE(REPLACE(OBST_MORL_HOSP_YN,CHR(13),''),CHR(10),'') OBST_MORL_HOSP_YN
, REPLACE(REPLACE(DDPY_ATTN_HOSP_YN,CHR(13),''),CHR(10),'') DDPY_ATTN_HOSP_YN
, REPLACE(REPLACE(NSRY_ATTN_HOSP_YN,CHR(13),''),CHR(10),'') NSRY_ATTN_HOSP_YN
, REPLACE(REPLACE(OWN_CTR_YN,CHR(13),''),CHR(10),'') OWN_CTR_YN
, REPLACE(REPLACE(ACD_OCFQ_CUS_YN,CHR(13),''),CHR(10),'') ACD_OCFQ_CUS_YN
, REPLACE(REPLACE(APPR_ACD_DD_DIV_CD,CHR(13),''),CHR(10),'') APPR_ACD_DD_DIV_CD
, REPLACE(REPLACE(MORL_KR_DISZ_CD,CHR(13),''),CHR(10),'') MORL_KR_DISZ_CD
, REPLACE(REPLACE(DISZ_CD_LST,CHR(13),''),CHR(10),'') DISZ_CD_LST
, REPLACE(REPLACE(SPFC_TRTPE_YN,CHR(13),''),CHR(10),'') SPFC_TRTPE_YN
, HIS_ST_DTM
, HIS_ED_DTM
, REPLACE(REPLACE(INPPE_ORG_ID,CHR(13),''),CHR(10),'') INPPE_ORG_ID
, SYS_OCC_DTM
, REPLACE(REPLACE(SYS_DEL_DIV_CD,CHR(13),''),CHR(10),'') SYS_DEL_DIV_CD
, REPLACE(REPLACE(OCC_IP,CHR(13),''),CHR(10),'') OCC_IP
, REPLACE(REPLACE(APP_ID,CHR(13),''),CHR(10),'') APP_ID
, DATA_CHNG_DTM
, DGN_FEE1
, DGN_FEE2
, REPLACE(REPLACE(LAW_VLT_YN,CHR(13),''),CHR(10),'') LAW_VLT_YN
, BAS_SCR
, REPLACE(REPLACE(CHRPE_ORG_ID,CHR(13),''),CHR(10),'') CHRPE_ORG_ID
, REPLACE(REPLACE(CHRPE_PART_ORG_ID,CHR(13),''),CHR(10),'') CHRPE_PART_ORG_ID
, REPLACE(REPLACE(CHRPE_TEM_ORG_ID,CHR(13),''),CHR(10),'') CHRPE_TEM_ORG_ID
, REPLACE(REPLACE(MORL_DIVD_DTL_CD,CHR(13),''),CHR(10),'') MORL_DIVD_DTL_CD
, REPLACE(REPLACE(SPFC_DGN_MORL_YN,CHR(13),''),CHR(10),'') SPFC_DGN_MORL_YN
, REPLACE(REPLACE(ETC_CON,CHR(13),''),CHR(10),'') ETC_CON
, EIH_LDG_DTM
, REPLACE(REPLACE(NURPE_SVC_RQE_YN,CHR(13),''),CHR(10),'') NURPE_SVC_RQE_YN
, REPLACE(REPLACE(RULE_SQ_VAL,CHR(13),''),CHR(10),'') RULE_SQ_VAL
, RULE_TRM_RSL_LST_CON20
, RULE_TRM_RSL_LST_CON26
, RULE_TRM_RSL_LST_CON27
, RULE_TRM_RSL_LST_CON28
, RULE_TRM_RSL_LST_CON29
, RULE_TRM_RSL_LST_CON30
, RULE_TRM_RSL_LST_CON32
, REPLACE(REPLACE(MDEL_APL_TRG_YN,CHR(13),''),CHR(10),'') MDEL_APL_TRG_YN
, REPLACE(REPLACE(APL_BF_FLTR_TRM_VAL,CHR(13),''),CHR(10),'') APL_BF_FLTR_TRM_VAL
, REPLACE(REPLACE(MDEL_APL_DIV_CD,CHR(13),''),CHR(10),'') MDEL_APL_DIV_CD
, MDEL_TRM_APL_RSL_VAL
, REPLACE(REPLACE(MDEL_DIV_CD_STD_VAL,CHR(13),''),CHR(10),'') MDEL_DIV_CD_STD_VAL
, REPLACE(REPLACE(MDEL_CMPT_RSL_VAL,CHR(13),''),CHR(10),'') MDEL_CMPT_RSL_VAL
, REPLACE(REPLACE(CMPT_SQ_CLUNIT_CD,CHR(13),''),CHR(10),'') CMPT_SQ_CLUNIT_CD
, REPLACE(REPLACE(CMPT_SQ_DIVD_DIV_VAL,CHR(13),''),CHR(10),'') CMPT_SQ_DIVD_DIV_VAL
, REPLACE(REPLACE(OS_ID,CHR(13),''),CHR(10),'') OS_ID FROM THDDH_TCLSCRGDIV
                       WHERE \$CONDITIONS "\
    --m 8 \
    --boundary-query "SELECT 0, 7 FROM DUAL"\
    --split-by "ORA_HASH(CLM_ID, 7)"\
    --target-dir /tmp2/LAST_THDDH_TCLSCRGDIV \
    --hive-import \
    --external-table-dir hdfs:///tmp2/temp_tbl/LAST_THDDH_TCLSCRGDIV \
    --hive-overwrite \
    --hive-table DEFAULT.LAST_THDDH_TCLSCRGDIV  >> ${SHLOG_DIR}/THDDH_TCLSCRGDIV.shlog 2>&1 &&

#----------------------------------------------------#
# Hadoop 원본테이블에 변경분 최종 적용
#----------------------------------------------------#
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TCLSCRGDIV_TMP ; " >> ${SHLOG_DIR}/THDDH_TCLSCRGDIV.shlog 2>&1 &&
    /usr/bin/hive -e "CREATE EXTERNAL TABLE MERITZ.THDDH_TCLSCRGDIV_TMP STORED AS PARQUET TBLPROPERTIES ('PARQUET.COMPRESS'='SNAPPY') AS
                                SELECT *
                                FROM DEFAULT.LAST_THDDH_TCLSCRGDIV ;" >> ${SHLOG_DIR}/THDDH_TCLSCRGDIV.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.LAST_THDDH_TCLSCRGDIV ;" >> ${SHLOG_DIR}/THDDH_TCLSCRGDIV.shlog 2>&1 &&
    /usr/bin/hdfs dfs -rm -r -f -skipTrash /warehouse/tablespace/external/hive/last_thddh_tclscrgdiv >> ${SHLOG_DIR}/THDDH_TCLSCRGDIV.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TCLSCRGDIV ;" >> ${SHLOG_DIR}/THDDH_TCLSCRGDIV.shlog 2>&1 &&
    /usr/bin/hive -e "ALTER TABLE MERITZ.THDDH_TCLSCRGDIV_TMP RENAME TO MERITZ.THDDH_TCLSCRGDIV ;" >> ${SHLOG_DIR}/THDDH_TCLSCRGDIV.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TCLSCRGDIV_TMP ;" >> ${SHLOG_DIR}/THDDH_TCLSCRGDIV.shlog 2>&1 

if [ $? -ne 0 ]
then             
    echo "*-----------[ THDDH_TCLSCRGDIV.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/THDDH_TCLSCRGDIV.shlog"
    echo "*-----------[ THDDH_TCLSCRGDIV.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/THDDH_TCLSCRGDIV.shlog"  >>  ${SHLOG_DIR}/THDDH_TCLSCRGDIV.shlog
    echo "*-----------[ THDDH_TCLSCRGDIV.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TCLSCRGDIV.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/THDDH_TCLSCRGDIV.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/THDDH_TCLSCRGDIV.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCLSCRGDIV.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCLSCRGDIV.shlog /sqoopbin/scripts/etlpgm/his_log/THDDH_TCLSCRGDIV_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  THDDH_TCLSCRGDIV.sh cmd command error !! ***
    fi               

    exit -1      

else             
    echo "*-----------[ THDDH_TCLSCRGDIV.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TCLSCRGDIV.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/THDDH_TCLSCRGDIV.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/THDDH_TCLSCRGDIV.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCLSCRGDIV.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCLSCRGDIV.shlog /sqoopbin/scripts/etlpgm/his_log/THDDH_TCLSCRGDIV_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  THDDH_TCLSCRGDIV.sh cmd command error !! ***
        exit -1      
    else             
        exit 0       
    fi               
fi               
