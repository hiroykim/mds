#!/bin/bash

if [ $# -eq 0 ]
then           
    ARGS=N    
else           
    ARGS=$1
fi             

NOW=$(date +"+%Y-%m-%d_%T")
SHLOG_DIR=/sqoopbin/scripts/etlpgm/cur_log
HISLOG_DIR=/sqoopbin/scripts/etlpgm/his_log

export HADOOP_OPTS=-Djava.security.egd=file:/dev/../dev/urandom
export ORACLE_BASE=/sw/oracle
export ORACLE_HOME=/sw/oracle/product/11.2.0.4/client_1
export LD_LIBRARY_PATH=/sw/oracle/product/11.2.0.4/client_1/lib:/sw/oracle/product/11.2.0.4/client_1/lib:
export PATH=/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/usr/lib64/qt-3.3/bin:/usr/hdp/3.0.0.0-1634/spark2/bin/:/var/opt/node/bin/:/opt/maven/bin:/usr/local/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/home/hdpapp/workspace/data-science-at-the-command-line/tools:/home/hdpapp/.local/bin:/home/hdpapp/bin
export TNS_ADMIN=/sw/oracle/product/11.2.0.4/client_1/network/admin
export ORACLE_SID=DBEDWP2
export NLS_LANG=American_America.KO16MSWIN949

#----------------------------------------------------#
# 작업내용 : THDDH_TSALTCCTFE 테이블 sqoop 복제 작업
# 작업주기 :  
#----------------------------------------------------#

    echo " "
    echo "*-----------[ THDDH_TSALTCCTFE.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TSALTCCTFE.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`  >  ${SHLOG_DIR}/THDDH_TSALTCCTFE.shlog

#----------------------------------------------------#
# 테이블별 전체 데이터를 받아 오는 부분
#----------------------------------------------------#
    /usr/bin/hadoop fs -rm -r -f  /tmp2/LAST_THDDH_TSALTCCTFE  >> ${SHLOG_DIR}/THDDH_TSALTCCTFE.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.LAST_THDDH_TSALTCCTFE ; " >> ${SHLOG_DIR}/THDDH_TSALTCCTFE.shlog 2>&1 &&
    /usr/hdp/3.0.0.0-1634/sqoop/bin/sqoop import -D mapred.child.java.opts="-Djava.security.egd=file:/dev/../dev/urandom" \
    --connect jdbc:oracle:thin:EDWHADOOP/wjdqhrP\!23@10.91.41.172:12560:DBEDWP2 \
    --username  EDWHADOOP \
    --password wjdqhrP\!23 \
    --query "SELECT /*+ FULL(THDDH_TSALTCCTFE) */ REPLACE(REPLACE(LGTM_CSTP_FEE_ID,CHR(13),''),CHR(10),'') LGTM_CSTP_FEE_ID
, REPLACE(REPLACE(STD_YYMM,CHR(13),''),CHR(10),'') STD_YYMM
, STD_DNO
, REPLACE(REPLACE(DATA_PCS_DIV_CD,CHR(13),''),CHR(10),'') DATA_PCS_DIV_CD
, REPLACE(REPLACE(POL_NO,CHR(13),''),CHR(10),'') POL_NO
, ENDR_NO
, REPLACE(REPLACE(PREM_PYRC_XPT_ID,CHR(13),''),CHR(10),'') PREM_PYRC_XPT_ID
, REPLACE(REPLACE(FEE_RCRD_KD_CD,CHR(13),''),CHR(10),'') FEE_RCRD_KD_CD
, REPLACE(REPLACE(SLZ_FML_ORG_ID,CHR(13),''),CHR(10),'') SLZ_FML_ORG_ID
, REPLACE(REPLACE(PY_YYMM,CHR(13),''),CHR(10),'') PY_YYMM
, PY_TMS
, NMPY_SEQ
, REPLACE(REPLACE(SLZ_CTR_ORIG_ID,CHR(13),''),CHR(10),'') SLZ_CTR_ORIG_ID
, REPLACE(REPLACE(FEE_SLZ_FML_DIV_CD,CHR(13),''),CHR(10),'') FEE_SLZ_FML_DIV_CD
, REPLACE(REPLACE(RCIP_NO,CHR(13),''),CHR(10),'') RCIP_NO
, REPLACE(REPLACE(HDQT_ORG_ID,CHR(13),''),CHR(10),'') HDQT_ORG_ID
, REPLACE(REPLACE(BRCH_ORG_ID,CHR(13),''),CHR(10),'') BRCH_ORG_ID
, REPLACE(REPLACE(BCH_ORG_ID,CHR(13),''),CHR(10),'') BCH_ORG_ID
, CTR_ENTCO_DMM
, REPLACE(REPLACE(CTR_DMM_CD,CHR(13),''),CHR(10),'') CTR_DMM_CD
, REPLACE(REPLACE(CHAN_CTR_YN,CHR(13),''),CHR(10),'') CHAN_CTR_YN
, NCTMPCV_ADJT_RCPT_PREM
, NCTMPCV_ADJT_MDF_PREM
, TM1_YR_MDF_PREM
, TM1_YR_ADJT_MDF_PREM
, TM2_YR_ADJT_RCPT_PREM
, TMSTP_NMNT_CNV1_PREM
, TMSTP_NMNT_APL_RT
, TMSTP_NMNT_CNV2_PREM
, TMSTP_NMNT_RDMP_RT
, TMSTP_NMNT_CNV3_PREM
, RCRT_PAY_RT
, RCRT_PAY_AMT
, MTN_PAY_RT
, MTN_PAY_AMT
, MNCL_PAY_RT
, MNCL_PAY_AMT
, REPLACE(REPLACE(PAY_TRG_ORG_ID,CHR(13),''),CHR(10),'') PAY_TRG_ORG_ID
, TRTPE_CHNG_DT
, REPLACE(REPLACE(TRTPE_CHNG_CD,CHR(13),''),CHR(10),'') TRTPE_CHNG_CD
, REPLACE(REPLACE(SCPOS_CONV_APL_CD,CHR(13),''),CHR(10),'') SCPOS_CONV_APL_CD
, REPLACE(REPLACE(PRPY_ARRG_DIV_CD,CHR(13),''),CHR(10),'') PRPY_ARRG_DIV_CD
, REPLACE(REPLACE(CTR_TPT_FEE_PAY_TP_CD,CHR(13),''),CHR(10),'') CTR_TPT_FEE_PAY_TP_CD
, NW_CTR_RSLT_FEE
, NW_CTR_RSLT_FEE_PAY_RT
, SUINS_NW_CTR_MDF_PREM
, CBZG_BKGR_CNVS_PREM
, REPLACE(REPLACE(FEE_CSTP_WRK_ERR_CD,CHR(13),''),CHR(10),'') FEE_CSTP_WRK_ERR_CD
, REPLACE(REPLACE(INPPE_ORG_ID,CHR(13),''),CHR(10),'') INPPE_ORG_ID
, SYS_OCC_DTM
, REPLACE(REPLACE(SYS_DEL_DIV_CD,CHR(13),''),CHR(10),'') SYS_DEL_DIV_CD
, REPLACE(REPLACE(APP_ID,CHR(13),''),CHR(10),'') APP_ID
, REPLACE(REPLACE(OCC_IP,CHR(13),''),CHR(10),'') OCC_IP
, DATA_CHNG_DTM
, MTN_RMNR_PAY_AMT
, MTN_RMNR_PAY_RT
, EIH_LDG_DTM
, RNWL_MTN_RMNR_PAY_AMT
, RNWL_MTN_RMNR_PAY_RT
, REPLACE(REPLACE(RNWL_DIV_CD,CHR(13),''),CHR(10),'') RNWL_DIV_CD
, TM2_YR_ADJT_MDF_PREM
, ACU_RCRT_PAY_AMT
, ACU_RCRT_PAY_RT
, ACU_MTN_PAY_AMT
, ACU_MTN_PAY_RT
, GURT_RCRT_PAY_AMT
, GURT_RCRT_PAY_RT
, GURT_MTN_PAY_AMT
, GURT_MTN_PAY_RT
, REPLACE(REPLACE(AT_MI_GR_CTR_YN,CHR(13),''),CHR(10),'') AT_MI_GR_CTR_YN
, REPLACE(REPLACE(CHAN_CTR_CMPT_EXPT_YN,CHR(13),''),CHR(10),'') CHAN_CTR_CMPT_EXPT_YN FROM THDDH_TSALTCCTFE
                       WHERE \$CONDITIONS "\
    --m 8 \
    --boundary-query "SELECT 0, 7 FROM DUAL"\
    --split-by "ORA_HASH(LGTM_CSTP_FEE_ID, 7)"\
    --target-dir /tmp2/LAST_THDDH_TSALTCCTFE \
    --hive-import \
    --external-table-dir hdfs:///tmp2/temp_tbl/LAST_THDDH_TSALTCCTFE \
    --hive-overwrite \
    --hive-table DEFAULT.LAST_THDDH_TSALTCCTFE  >> ${SHLOG_DIR}/THDDH_TSALTCCTFE.shlog 2>&1 &&

#----------------------------------------------------#
# Hadoop 원본테이블에 변경분 최종 적용
#----------------------------------------------------#
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TSALTCCTFE_TMP ; " >> ${SHLOG_DIR}/THDDH_TSALTCCTFE.shlog 2>&1 &&
    /usr/bin/hive -e "CREATE EXTERNAL TABLE MERITZ.THDDH_TSALTCCTFE_TMP STORED AS PARQUET TBLPROPERTIES ('PARQUET.COMPRESS'='SNAPPY') AS
                                SELECT *
                                FROM DEFAULT.LAST_THDDH_TSALTCCTFE ;" >> ${SHLOG_DIR}/THDDH_TSALTCCTFE.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.LAST_THDDH_TSALTCCTFE ;" >> ${SHLOG_DIR}/THDDH_TSALTCCTFE.shlog 2>&1 &&
    /usr/bin/hdfs dfs -rm -r -f -skipTrash /warehouse/tablespace/external/hive/last_thddh_tsaltcctfe >> ${SHLOG_DIR}/THDDH_TSALTCCTFE.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TSALTCCTFE ;" >> ${SHLOG_DIR}/THDDH_TSALTCCTFE.shlog 2>&1 &&
    /usr/bin/hive -e "ALTER TABLE MERITZ.THDDH_TSALTCCTFE_TMP RENAME TO MERITZ.THDDH_TSALTCCTFE ;" >> ${SHLOG_DIR}/THDDH_TSALTCCTFE.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TSALTCCTFE_TMP ;" >> ${SHLOG_DIR}/THDDH_TSALTCCTFE.shlog 2>&1 

if [ $? -ne 0 ]
then             
    echo "*-----------[ THDDH_TSALTCCTFE.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/THDDH_TSALTCCTFE.shlog"
    echo "*-----------[ THDDH_TSALTCCTFE.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/THDDH_TSALTCCTFE.shlog"  >>  ${SHLOG_DIR}/THDDH_TSALTCCTFE.shlog
    echo "*-----------[ THDDH_TSALTCCTFE.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TSALTCCTFE.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/THDDH_TSALTCCTFE.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/THDDH_TSALTCCTFE.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TSALTCCTFE.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TSALTCCTFE.shlog /sqoopbin/scripts/etlpgm/his_log/THDDH_TSALTCCTFE_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  THDDH_TSALTCCTFE.sh cmd command error !! ***
    fi               

    exit -1      

else             
    echo "*-----------[ THDDH_TSALTCCTFE.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TSALTCCTFE.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/THDDH_TSALTCCTFE.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/THDDH_TSALTCCTFE.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TSALTCCTFE.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TSALTCCTFE.shlog /sqoopbin/scripts/etlpgm/his_log/THDDH_TSALTCCTFE_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  THDDH_TSALTCCTFE.sh cmd command error !! ***
        exit -1      
    else             
        exit 0       
    fi               
fi               
