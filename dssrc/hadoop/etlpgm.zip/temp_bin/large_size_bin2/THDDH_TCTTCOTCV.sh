#!/bin/bash

if [ $# -eq 0 ]
then           
    ARGS=N    
else           
    ARGS=$1
fi             

NOW=$(date +"+%Y-%m-%d_%T")
SHLOG_DIR=/sqoopbin/scripts/etlpgm/cur_log
HISLOG_DIR=/sqoopbin/scripts/etlpgm/his_log

export HADOOP_OPTS=-Djava.security.egd=file:/dev/../dev/urandom
export ORACLE_BASE=/sw/oracle
export ORACLE_HOME=/sw/oracle/product/11.2.0.4/client_1
export LD_LIBRARY_PATH=/sw/oracle/product/11.2.0.4/client_1/lib:/sw/oracle/product/11.2.0.4/client_1/lib:
export PATH=/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/usr/lib64/qt-3.3/bin:/usr/hdp/3.0.0.0-1634/spark2/bin/:/var/opt/node/bin/:/opt/maven/bin:/usr/local/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/home/hdpapp/workspace/data-science-at-the-command-line/tools:/home/hdpapp/.local/bin:/home/hdpapp/bin
export TNS_ADMIN=/sw/oracle/product/11.2.0.4/client_1/network/admin
export ORACLE_SID=DBEDWP2
export NLS_LANG=American_America.KO16MSWIN949

#----------------------------------------------------#
# 작업내용 : THDDH_TCTTCOTCV 테이블 sqoop 복제 작업
# 작업주기 :  
#----------------------------------------------------#

    echo " "
    echo "*-----------[ THDDH_TCTTCOTCV.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TCTTCOTCV.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`  >  ${SHLOG_DIR}/THDDH_TCTTCOTCV.shlog

#----------------------------------------------------#
# 테이블별 전체 데이터를 받아 오는 부분
#----------------------------------------------------#
    /usr/bin/hadoop fs -rm -r -f  /tmp2/LAST_THDDH_TCTTCOTCV  >> ${SHLOG_DIR}/THDDH_TCTTCOTCV.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.LAST_THDDH_TCTTCOTCV ; " >> ${SHLOG_DIR}/THDDH_TCTTCOTCV.shlog 2>&1 &&
    /usr/hdp/3.0.0.0-1634/sqoop/bin/sqoop import -D mapred.child.java.opts="-Djava.security.egd=file:/dev/../dev/urandom" \
    --connect jdbc:oracle:thin:EDWHADOOP/wjdqhrP\!23@10.91.41.172:12560:DBEDWP2 \
    --username  EDWHADOOP \
    --password wjdqhrP\!23 \
    --query "SELECT /*+ FULL(THDDH_TCTTCOTCV) */ REPLACE(REPLACE(CTR_COV_ID,CHR(13),''),CHR(10),'') CTR_COV_ID
, HIS_SEQ
, REPLACE(REPLACE(BIZ_SYS_CD,CHR(13),''),CHR(10),'') BIZ_SYS_CD
, REPLACE(REPLACE(CTR_ID,CHR(13),''),CHR(10),'') CTR_ID
, REPLACE(REPLACE(CTR_COV_DIV_CD,CHR(13),''),CHR(10),'') CTR_COV_DIV_CD
, REPLACE(REPLACE(CTR_OBJ_ID,CHR(13),''),CHR(10),'') CTR_OBJ_ID
, REPLACE(REPLACE(COV_CD,CHR(13),''),CHR(10),'') COV_CD
, CTR_COV_SEQ
, REPLACE(REPLACE(PD_CD,CHR(13),''),CHR(10),'') PD_CD
, REPLACE(REPLACE(UNT_PD_CD,CHR(13),''),CHR(10),'') UNT_PD_CD
, REPLACE(REPLACE(POL_NO,CHR(13),''),CHR(10),'') POL_NO
, REPLACE(REPLACE(BAS_SIC_DIV_CD,CHR(13),''),CHR(10),'') BAS_SIC_DIV_CD
, REPLACE(REPLACE(COV_CND_SEQ_CD,CHR(13),''),CHR(10),'') COV_CND_SEQ_CD
, REPLACE(REPLACE(CTR_COV_STAT_CD,CHR(13),''),CHR(10),'') CTR_COV_STAT_CD
, REPLACE(REPLACE(CTR_COV_STAT_DTL_CD,CHR(13),''),CHR(10),'') CTR_COV_STAT_DTL_CD
, PY_EXEM_ST_DT
, REPLACE(REPLACE(INS_PRD_TP_CD,CHR(13),''),CHR(10),'') INS_PRD_TP_CD
, REPLACE(REPLACE(PY_PRD_TP_CD,CHR(13),''),CHR(10),'') PY_PRD_TP_CD
, INS_PRD
, PY_PRD
, INS_ED_AGE
, PY_ED_AGE
, INSD_AMT
, PPS_INSD_AMT
, INS_BGN_DT
, REPLACE(REPLACE(INS_BGN_TM,CHR(13),''),CHR(10),'') INS_BGN_TM
, INS_ED_DT
, REPLACE(REPLACE(INS_ED_TM,CHR(13),''),CHR(10),'') INS_ED_TM
, REPLACE(REPLACE(INSD_AMT_CUR_CD,CHR(13),''),CHR(10),'') INSD_AMT_CUR_CD
, INSD_AMT_APL_EXRT
, INSD_RTO
, ACNT_NUM
, BAS_PREM
, APL_PREM
, CUR_BAS_PREM
, CUR_APL_PREM
, REPLACE(REPLACE(PREM_CUR_CD,CHR(13),''),CHR(10),'') PREM_CUR_CD
, PREM_APL_EXRT
, APL_PREM_RT
, LAST_PREM_RT
, MDF_PREM_RT
, MDF_PREM
, PO_ETPY_FEE
, TT_CR_GRP_APL_PREM
, REPLACE(REPLACE(COV_CHRC_CD,CHR(13),''),CHR(10),'') COV_CHRC_CD
, REPLACE(REPLACE(COV_GRP_CD,CHR(13),''),CHR(10),'') COV_GRP_CD
, REPLACE(REPLACE(COV_CTG_CD,CHR(13),''),CHR(10),'') COV_CTG_CD
, TT_CR_GRP_LSAP_PREM
, PY_ST_DT
, PY_ED_DT
, FULL_AGE
, INS_AGE
, REPLACE(REPLACE(RNWL_ED_PRD_DIV_CD,CHR(13),''),CHR(10),'') RNWL_ED_PRD_DIV_CD
, RNWL_ED_PRD
, RNWL_ED_AGE
, RNWL_ED_DT
, RNWL_TMS
, REPLACE(REPLACE(MOM_PD_CD,CHR(13),''),CHR(10),'') MOM_PD_CD
, REPLACE(REPLACE(AGE_APL_DIV_CD,CHR(13),''),CHR(10),'') AGE_APL_DIV_CD
, REPLACE(REPLACE(PREM_AT_CMPT_YN,CHR(13),''),CHR(10),'') PREM_AT_CMPT_YN
, REPLACE(REPLACE(WRD_NPRN_YN,CHR(13),''),CHR(10),'') WRD_NPRN_YN
, KEY_COV_SEQ
, KEY_HIS_SEQ
, REPLACE(REPLACE(PKEY_CNFG_CHT_VAL,CHR(13),''),CHR(10),'') PKEY_CNFG_CHT_VAL
, REPLACE(REPLACE(RKEY_CNFG_CHT_VAL,CHR(13),''),CHR(10),'') RKEY_CNFG_CHT_VAL
, REPLACE(REPLACE(BKEY_CNFG_CHT_VAL,CHR(13),''),CHR(10),'') BKEY_CNFG_CHT_VAL
, CUR_INSD_AMT
, CHGDV_INSD_AMT
, CUR_CHGDV_INSD_AMT
, KIDI_BAS_PREM
, CHGDV_APL_PREM
, CUR_CHGDV_APL_PREM
, REPLACE(REPLACE(DSC_CON,CHR(13),''),CHR(10),'') DSC_CON
, REPLACE(REPLACE(MRIN_COV_DTL_CD,CHR(13),''),CHR(10),'') MRIN_COV_DTL_CD
, REPLACE(REPLACE(CAL_MD_CD,CHR(13),''),CHR(10),'') CAL_MD_CD
, REPLACE(REPLACE(TT_COMS_LM_AMT_OCC_YN,CHR(13),''),CHR(10),'') TT_COMS_LM_AMT_OCC_YN
, STD_BAS_PREM
, STD_APL_PREM
, ENDR_NO
, RTRO_ENDR_NO
, ENDR_HIS_ST_NO
, ENDR_HIS_ED_NO
, SUMUP_DT
, HIS_ST_DT
, HIS_ED_DT
, REPLACE(REPLACE(INPPE_ORG_ID,CHR(13),''),CHR(10),'') INPPE_ORG_ID
, SYS_OCC_DTM
, REPLACE(REPLACE(SYS_DEL_DIV_CD,CHR(13),''),CHR(10),'') SYS_DEL_DIV_CD
, REPLACE(REPLACE(OCC_IP,CHR(13),''),CHR(10),'') OCC_IP
, REPLACE(REPLACE(APP_ID,CHR(13),''),CHR(10),'') APP_ID
, DATA_CHNG_DTM
, SLZ_PREM
, EIH_LDG_DTM
, GAIN_UNI_SEQ
, GAIN_UNI_DTL_SEQ
, REPLACE(REPLACE(GRP_COV_YN,CHR(13),''),CHR(10),'') GRP_COV_YN
, ALTN_PY_PREM
, PORTN_ADD_PY_APL_PREM
, RSK_PREM
, TMN_PREM_RT
, STND_BAS_PREM
, AVG_AGE
, REPLACE(REPLACE(CTR_COV_TP_ID,CHR(13),''),CHR(10),'') CTR_COV_TP_ID
, REPLACE(REPLACE(ENG_DSC_CON,CHR(13),''),CHR(10),'') ENG_DSC_CON
, INDI_SEQ FROM THDDH_TCTTCOTCV
                       WHERE \$CONDITIONS "\
    --m 8 \
    --boundary-query "SELECT 0, 7 FROM DUAL"\
    --split-by "ORA_HASH(CTR_COV_ID, 7)"\
    --target-dir /tmp2/LAST_THDDH_TCTTCOTCV \
    --hive-import \
    --external-table-dir hdfs:///tmp2/temp_tbl/LAST_THDDH_TCTTCOTCV \
    --hive-overwrite \
    --hive-table DEFAULT.LAST_THDDH_TCTTCOTCV  >> ${SHLOG_DIR}/THDDH_TCTTCOTCV.shlog 2>&1 &&

#----------------------------------------------------#
# Hadoop 원본테이블에 변경분 최종 적용
#----------------------------------------------------#
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TCTTCOTCV_TMP ; " >> ${SHLOG_DIR}/THDDH_TCTTCOTCV.shlog 2>&1 &&
    /usr/bin/hive -e "CREATE EXTERNAL TABLE MERITZ.THDDH_TCTTCOTCV_TMP STORED AS PARQUET TBLPROPERTIES ('PARQUET.COMPRESS'='SNAPPY') AS
                                SELECT *
                                FROM DEFAULT.LAST_THDDH_TCTTCOTCV ;" >> ${SHLOG_DIR}/THDDH_TCTTCOTCV.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.LAST_THDDH_TCTTCOTCV ;" >> ${SHLOG_DIR}/THDDH_TCTTCOTCV.shlog 2>&1 &&
    /usr/bin/hdfs dfs -rm -r -f -skipTrash /warehouse/tablespace/external/hive/last_thddh_tcttcotcv >> ${SHLOG_DIR}/THDDH_TCTTCOTCV.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TCTTCOTCV ;" >> ${SHLOG_DIR}/THDDH_TCTTCOTCV.shlog 2>&1 &&
    /usr/bin/hive -e "ALTER TABLE MERITZ.THDDH_TCTTCOTCV_TMP RENAME TO MERITZ.THDDH_TCTTCOTCV ;" >> ${SHLOG_DIR}/THDDH_TCTTCOTCV.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TCTTCOTCV_TMP ;" >> ${SHLOG_DIR}/THDDH_TCTTCOTCV.shlog 2>&1 

if [ $? -ne 0 ]
then             
    echo "*-----------[ THDDH_TCTTCOTCV.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/THDDH_TCTTCOTCV.shlog"
    echo "*-----------[ THDDH_TCTTCOTCV.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/THDDH_TCTTCOTCV.shlog"  >>  ${SHLOG_DIR}/THDDH_TCTTCOTCV.shlog
    echo "*-----------[ THDDH_TCTTCOTCV.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TCTTCOTCV.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/THDDH_TCTTCOTCV.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/THDDH_TCTTCOTCV.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCTTCOTCV.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCTTCOTCV.shlog /sqoopbin/scripts/etlpgm/his_log/THDDH_TCTTCOTCV_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  THDDH_TCTTCOTCV.sh cmd command error !! ***
    fi               

    exit -1      

else             
    echo "*-----------[ THDDH_TCTTCOTCV.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TCTTCOTCV.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/THDDH_TCTTCOTCV.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/THDDH_TCTTCOTCV.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCTTCOTCV.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCTTCOTCV.shlog /sqoopbin/scripts/etlpgm/his_log/THDDH_TCTTCOTCV_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  THDDH_TCTTCOTCV.sh cmd command error !! ***
        exit -1      
    else             
        exit 0       
    fi               
fi               
