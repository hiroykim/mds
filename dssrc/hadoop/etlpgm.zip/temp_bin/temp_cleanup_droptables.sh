#!/bin/bash

CURRENT_PROCESS_CNT=`ps -ef | grep /sqoopbin/scripts/etlpgm/bin/ | grep -v grep | wc -l`

if [ $CURRENT_PROCESS_CNT -eq 0 ]
then
    hdfs dfs -rm -r -f -skipTrash /warehouse/tablespace/external/hive/last_*
    hdfs dfs -rm -r -f -skipTrash /warehouse/tablespace/external/hive/except_*
    hdfs dfs -rm -r -f -skipTrash /tmp2/temp_tbl/STG_*
    hdfs dfs -rm -r -f -skipTrash /tmp2/temp_tbl/LAST_*
else
    echo "not yet"
fi

