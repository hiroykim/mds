#!/bin/bash

#/usr/bin/hive -e "CREATE EXTERNAL TABLE DEFAULT.THDDH_TCTLCOTL1_UPDATE STORED AS PARQUET TBLPROPERTIES ('PARQUET.COMPRESS'='SNAPPY') AS
#                                SELECT DISTINCT *
#                                FROM MERITZ.THDDH_TCTLCOTL1 WHERE CLOG_ST_YYMM = '202011'
#				UNION ALL
#				SELECT * 
#				FROM MERITZ.THDDH_TCTLCOTL1 WHERE CLOG_ST_YYMM != '202011'"

#/usr/bin/hive -e "CREATE EXTERNAL TABLE MERITZ.THDDH_TCTLCOTL1_UPDATE STORED AS PARQUET TBLPROPERTIES ('PARQUET.COMPRESS'='SNAPPY') AS
#				SELECT *
#				FROM DEFAULT.THDDH_TCTLCOTL1_UPDATE;"

#/usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TCTLCOTL1 ;"
#hdfs dfs -rm -r -f -skipTrash /warehouse/tablespace/external/hive/meritz.db/thddh_tctlcotl1_tmp

#/usr/bin/hive -e "ALTER TABLE MERITZ.THDDH_TCTLCOTL1_UPDATE RENAME TO MERITZ.THDDH_TCTLCOTL1 ;"
#hdfs dfs -mv /warehouse/tablespace/external/hive/meritz.db/thddh_tctlcotl1_update /warehouse/tablespace/external/hive/meritz.db/thddh_tctlcotl1_tmp

/usr/bin/hive -e "ALTER TABLE MERITZ.THDDH_TCTLCOTL1 SET LOCATION 'hdfs:///warehouse/tablespace/external/hive/meritz.db/thddh_tctlcotl1_tmp';"

#/usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TCTLCOTL1_TMP ;"
