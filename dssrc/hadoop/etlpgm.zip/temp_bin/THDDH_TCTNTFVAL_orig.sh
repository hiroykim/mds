#!/bin/bash

if [ $# -eq 0 ]
then           
    ARGS=N    
else           
    ARGS=$1
fi             

NOW=$(date +"+%Y-%m-%d_%T")
SHLOG_DIR=/sqoopbin/scripts/etlpgm/cur_log
HISLOG_DIR=/sqoopbin/scripts/etlpgm/his_log

export HADOOP_OPTS=-Djava.security.egd=file:/dev/../dev/urandom
export ORACLE_BASE=/sw/oracle
export ORACLE_HOME=/sw/oracle/product/11.2.0.4/client_1
export LD_LIBRARY_PATH=/sw/oracle/product/11.2.0.4/client_1/lib:/sw/oracle/product/11.2.0.4/client_1/lib:
export PATH=/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/usr/lib64/qt-3.3/bin:/var/opt/node/bin/:/usr/hdp/3.0.0.0-1634/spark2/bin/:/opt/maven/bin:/usr/local/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/home/hdpapp/.local/bin:/home/hdpapp/bin
export TNS_ADMIN=/sw/oracle/product/11.2.0.4/client_1/network/admin
export ORACLE_SID=DBEDWP2
export NLS_LANG=American_America.KO16MSWIN949

#----------------------------------------------------#
# 작업내용 : THDDH_TCTNTFVAL 테이블 sqoop 복제 작업
# 작업주기 : D 
#----------------------------------------------------#

    echo " "
    echo "*-----------[ THDDH_TCTNTFVAL.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TCTNTFVAL.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`  >  ${SHLOG_DIR}/THDDH_TCTNTFVAL.shlog

#----------------------------------------------------#
# 테이블별 데이터변경LOG 데이터를 받아 오는 부분
#----------------------------------------------------#
    /usr/bin/hadoop fs -rm -r -f  /tmp2/TXLOG_THDDH_TCTNTFVAL  >> ${SHLOG_DIR}/THDDH_TCTNTFVAL.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.TXLOG_THDDH_TCTNTFVAL ; " >> ${SHLOG_DIR}/THDDH_TCTNTFVAL.shlog 2>&1 &&
    /usr/hdp/3.0.0.0-1634/sqoop/bin/sqoop import -D mapred.child.java.opts="-Djava.security.egd=file:/dev/../dev/urandom" \
    --connect jdbc:oracle:thin:EDWHADOOP/wjdqhrP\!23@10.91.41.172:12560:DBEDWP2 \
    --username  EDWHADOOP \
    --password wjdqhrP\!23 \
    --query "SELECT * FROM THDDH_TCOTXLOG
                       WHERE \$CONDITIONS 
                         AND DATA_CHNG_DTM >= TO_TIMESTAMP(TO_CHAR(CURRENT_DATE -16 ,'YYYYMMDD')||' 00:00:00','YYYYMMDD HH24:MI:SS')
                         AND TBL_NM IN ( UPPER('TCTNTFVAL'), LOWER('TCTNTFVAL')) "\
    --m 1 \
    --target-dir /tmp2/TXLOG_THDDH_TCTNTFVAL \
    --hive-import \
    --external-table-dir hdfs:///tmp2/temp_tbl/TXLOG_THDDH_TCTNTFVAL \
    --hive-overwrite \
    --hive-table DEFAULT.TXLOG_THDDH_TCTNTFVAL  >> ${SHLOG_DIR}/THDDH_TCTNTFVAL.shlog 2>&1 &&

#----------------------------------------------------#
# 테이블별 데이터강제수정LOG 데이터를 받아 오는 부분
#----------------------------------------------------#
    /usr/bin/hadoop fs -rm -r -f  /tmp2/BTXLOG_THDDH_TCTNTFVAL  >> ${SHLOG_DIR}/THDDH_TCTNTFVAL.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.BTXLOG_THDDH_TCTNTFVAL ; " >> ${SHLOG_DIR}/THDDH_TCTNTFVAL.shlog 2>&1 &&
    /usr/hdp/3.0.0.0-1634/sqoop/bin/sqoop import -D mapred.child.java.opts="-Djava.security.egd=file:/dev/../dev/urandom" \
    --connect jdbc:oracle:thin:EDWHADOOP/wjdqhrP\!23@10.91.41.172:12560:DBEDWP2 \
    --username  EDWHADOOP \
    --password wjdqhrP\!23 \
    --query "SELECT * FROM THDDH_TCODBTXLOG
                       WHERE \$CONDITIONS 
                         AND DATA_CHNG_DTM >= TO_TIMESTAMP(TO_CHAR(CURRENT_DATE -16 ,'YYYYMMDD')||' 00:00:00','YYYYMMDD HH24:MI:SS')
                         AND TBL_NM IN ( UPPER('TCTNTFVAL'), LOWER('TCTNTFVAL')) "\
    --m 1 \
    --target-dir /tmp2/BTXLOG_THDDH_TCTNTFVAL \
    --hive-import \
    --external-table-dir hdfs:///tmp2/temp_tbl/BTXLOG_THDDH_TCTNTFVAL \
    --hive-overwrite \
    --hive-table DEFAULT.BTXLOG_THDDH_TCTNTFVAL  >> ${SHLOG_DIR}/THDDH_TCTNTFVAL.shlog 2>&1 &&

#----------------------------------------------------#
# 테이블별 일변경 데이터를 받아 오는 부분
#----------------------------------------------------#
    /usr/bin/hadoop fs -rm -r -f  /tmp2/STG_THDDH_TCTNTFVAL {SHLOG_DIR}/THDDH_TCTNTFVAL.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.STG_THDDH_TCTNTFVAL ; " >> ${SHLOG_DIR}/THDDH_TCTNTFVAL.shlog 2>&1 &&
    /usr/hdp/3.0.0.0-1634/sqoop/bin/sqoop import -D mapred.child.java.opts="-Djava.security.egd=file:/dev/../dev/urandom" \
    --connect jdbc:oracle:thin:EDWHADOOP/wjdqhrP\!23@10.91.41.172:12560:DBEDWP2 \
    --username  EDWHADOOP \
    --password wjdqhrP\!23 \
    --query "SELECT REPLACE(REPLACE(NTDT_ID,CHR(13),''),CHR(10),'') NTDT_ID
, QSITM_VAL_SEQ
, HIS_SEQ
, REPLACE(REPLACE(BIZ_SYS_CD,CHR(13),''),CHR(10),'') BIZ_SYS_CD
, REPLACE(REPLACE(QSITM_CD,CHR(13),''),CHR(10),'') QSITM_CD
, REPLACE(REPLACE(QSITM_VAL,CHR(13),''),CHR(10),'') QSITM_VAL
, REPLACE(REPLACE(QSITM_CNF_VAL,CHR(13),''),CHR(10),'') QSITM_CNF_VAL
, REPLACE(REPLACE(QSITM_VAL_FCT_YN,CHR(13),''),CHR(10),'') QSITM_VAL_FCT_YN
, ST_HIS_NO
, ED_HIS_NO
, HIS_ST_DT
, HIS_ED_DT
, REPLACE(REPLACE(INPPE_ORG_ID,CHR(13),''),CHR(10),'') INPPE_ORG_ID
, SYS_OCC_DTM
, REPLACE(REPLACE(SYS_DEL_DIV_CD,CHR(13),''),CHR(10),'') SYS_DEL_DIV_CD
, REPLACE(REPLACE(OCC_IP,CHR(13),''),CHR(10),'') OCC_IP
, REPLACE(REPLACE(APP_ID,CHR(13),''),CHR(10),'') APP_ID
, DATA_CHNG_DTM
, EIH_LDG_DTM FROM THDDH_TCTNTFVAL
                       WHERE \$CONDITIONS 
                         AND DATA_CHNG_DTM >= TO_TIMESTAMP(TO_CHAR(CURRENT_DATE -16 ,'YYYYMMDD')||' 00:00:00','YYYYMMDD HH24:MI:SS') "\
    --m 1 \
    --target-dir /tmp2/STG_THDDH_TCTNTFVAL \
    --hive-import \
    --external-table-dir hdfs:///tmp2/temp_tbl/STG_THDDH_TCTNTFVAL \
    --hive-overwrite \
    --hive-table DEFAULT.STG_THDDH_TCTNTFVAL  >> ${SHLOG_DIR}/THDDH_TCTNTFVAL.shlog 2>&1 &&

#----------------------------------------------------#
# 이전 테이블에 일변경 데이터 OR 삭제로그 적용
#----------------------------------------------------#
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.EXCEPT_THDDH_TCTNTFVAL ; " >> ${SHLOG_DIR}/THDDH_TCTNTFVAL.shlog 2>&1 &&
    /usr/bin/hive -e "CREATE EXTERNAL TABLE DEFAULT.EXCEPT_THDDH_TCTNTFVAL STORED AS PARQUET AS 
                                    SELECT NTDT_ID,QSITM_VAL_SEQ,HIS_SEQ FROM DEFAULT.STG_THDDH_TCTNTFVAL
                                    UNION ALL
                                    SELECT KEY_VAL1 AS NTDT_ID,CAST(KEY_VAL2 AS DOUBLE) AS QSITM_VAL_SEQ,CAST(KEY_VAL3 AS DOUBLE) AS HIS_SEQ FROM DEFAULT.TXLOG_THDDH_TCTNTFVAL
                                    UNION ALL
                                    SELECT KEY_VAL1 AS NTDT_ID,CAST(KEY_VAL2 AS DOUBLE) AS QSITM_VAL_SEQ,CAST(KEY_VAL3 AS DOUBLE) AS HIS_SEQ FROM DEFAULT.BTXLOG_THDDH_TCTNTFVAL ;" >> ${SHLOG_DIR}/THDDH_TCTNTFVAL.shlog 2>&1 &&

#----------------------------------------------------#
# Hadoop 테이블에 변경분 적용
# RENAME할 테이블 생성(오류 작업시 ROLLBACK)
#----------------------------------------------------#
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.LAST_THDDH_TCTNTFVAL ; " >> ${SHLOG_DIR}/THDDH_TCTNTFVAL.shlog 2>&1 &&
    /usr/bin/hive -e "CREATE EXTERNAL TABLE DEFAULT.LAST_THDDH_TCTNTFVAL STORED AS PARQUET TBLPROPERTIES ('PARQUET.COMPRESS'='SNAPPY') AS
                                    SELECT T1.*
                                    FROM MERITZ.THDDH_TCTNTFVAL AS T1
                                        LEFT JOIN DEFAULT.EXCEPT_THDDH_TCTNTFVAL AS T2
                                          ON 1 = 1
                                          AND T1.NTDT_ID = T2.NTDT_ID AND T1.QSITM_VAL_SEQ = T2.QSITM_VAL_SEQ AND T1.HIS_SEQ = T2.HIS_SEQ
                                    WHERE 1 = 1
                                      AND T2.NTDT_ID IS NULL
                                    UNION ALL
                                    SELECT *
                                    FROM DEFAULT.STG_THDDH_TCTNTFVAL ;" >> ${SHLOG_DIR}/THDDH_TCTNTFVAL.shlog 2>&1 &&
#----------------------------------------------------#
# Hadoop 원본테이블에 변경분 최종 적용
#----------------------------------------------------#
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TCTNTFVAL_TMP ; " >> ${SHLOG_DIR}/THDDH_TCTNTFVAL.shlog 2>&1 &&
    /usr/bin/hive -e "CREATE EXTERNAL TABLE MERITZ.THDDH_TCTNTFVAL_TMP STORED AS PARQUET TBLPROPERTIES ('PARQUET.COMPRESS'='SNAPPY') AS
                                SELECT *
                                FROM DEFAULT.LAST_THDDH_TCTNTFVAL ;" >> ${SHLOG_DIR}/THDDH_TCTNTFVAL.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.LAST_THDDH_TCTNTFVAL ;" >> ${SHLOG_DIR}/THDDH_TCTNTFVAL.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TCTNTFVAL ;" >> ${SHLOG_DIR}/THDDH_TCTNTFVAL.shlog 2>&1 &&
    /usr/bin/hive -e "ALTER TABLE MERITZ.THDDH_TCTNTFVAL_TMP RENAME TO MERITZ.THDDH_TCTNTFVAL ;" >> ${SHLOG_DIR}/THDDH_TCTNTFVAL.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TCTNTFVAL_TMP ;" >> ${SHLOG_DIR}/THDDH_TCTNTFVAL.shlog 2>&1 

if [ $? -ne 0 ]
then             
    echo "*-----------[ THDDH_TCTNTFVAL.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/THDDH_TCTNTFVAL.shlog"
    echo "*-----------[ THDDH_TCTNTFVAL.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/THDDH_TCTNTFVAL.shlog"  >>  ${SHLOG_DIR}/THDDH_TCTNTFVAL.shlog
    echo "*-----------[ THDDH_TCTNTFVAL.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TCTNTFVAL.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/THDDH_TCTNTFVAL.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/THDDH_TCTNTFVAL.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCTNTFVAL.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCTNTFVAL.shlog /sqoopbin/scripts/etlpgm/his_log/THDDH_TCTNTFVAL_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  THDDH_TCTNTFVAL.sh cmd command error !! ***
    fi               

    exit -1      

else             
    echo "*-----------[ THDDH_TCTNTFVAL.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TCTNTFVAL.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/THDDH_TCTNTFVAL.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/THDDH_TCTNTFVAL.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCTNTFVAL.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCTNTFVAL.shlog /sqoopbin/scripts/etlpgm/his_log/THDDH_TCTNTFVAL_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  THDDH_TCTNTFVAL.sh cmd command error !! ***
        exit -1      
    else             
        exit 0       
    fi               
fi               
