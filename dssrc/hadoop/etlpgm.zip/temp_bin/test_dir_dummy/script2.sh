#!/bin/bash

sleep 3

echo $0 " complete"
