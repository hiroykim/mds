#!/bin/bash

if [ $# -eq 0 ]
then           
    ARGS=N    
else           
    ARGS=$1
fi             

NOW=$(date +"+%Y-%m-%d_%T")
SHLOG_DIR=/sqoopbin/scripts/etlpgm/cur_log
HISLOG_DIR=/sqoopbin/scripts/etlpgm/his_log

export HADOOP_OPTS=-Djava.security.egd=file:/dev/../dev/urandom
export ORACLE_BASE=/sw/oracle
export ORACLE_HOME=/sw/oracle/product/11.2.0.4/client_1
export LD_LIBRARY_PATH=/sw/oracle/product/11.2.0.4/client_1/lib:/sw/oracle/product/11.2.0.4/client_1/lib:
export PATH=/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/usr/lib64/qt-3.3/bin:/usr/hdp/3.0.0.0-1634/spark2/bin/:/var/opt/node/bin/:/opt/maven/bin:/usr/local/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/home/hdpapp/workspace/data-science-at-the-command-line/tools:/home/hdpapp/.local/bin:/home/hdpapp/bin
export TNS_ADMIN=/sw/oracle/product/11.2.0.4/client_1/network/admin
export ORACLE_SID=DBEDWP2
export NLS_LANG=American_America.KO16MSWIN949

#----------------------------------------------------#
# 작업내용 : THDDH_TCLCOV 테이블 sqoop 복제 작업
# 작업주기 :  
#----------------------------------------------------#

    echo " "
    echo "*-----------[ THDDH_TCLCOV.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TCLCOV.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`  >  ${SHLOG_DIR}/THDDH_TCLCOV.shlog

#----------------------------------------------------#
# 테이블별 전체 데이터를 받아 오는 부분
#----------------------------------------------------#
    /usr/bin/hadoop fs -rm -r -f  /tmp2/LAST_THDDH_TCLCOV  >> ${SHLOG_DIR}/THDDH_TCLCOV.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.LAST_THDDH_TCLCOV ; " >> ${SHLOG_DIR}/THDDH_TCLCOV.shlog 2>&1 &&
    /usr/hdp/3.0.0.0-1634/sqoop/bin/sqoop import -D mapred.child.java.opts="-Djava.security.egd=file:/dev/../dev/urandom" \
    --connect jdbc:oracle:thin:EDWHADOOP/wjdqhrP\!23@10.91.41.172:12560:DBEDWP2 \
    --username  EDWHADOOP \
    --password wjdqhrP\!23 \
    --query "SELECT /*+ FULL(THDDH_TCLCOV) */ REPLACE(REPLACE(COV_INS_AMT_ID,CHR(13),''),CHR(10),'') COV_INS_AMT_ID
, HIS_SEQ
, REPLACE(REPLACE(COV_INS_DATA_DIV_CD,CHR(13),''),CHR(10),'') COV_INS_DATA_DIV_CD
, REPLACE(REPLACE(DATA_ID,CHR(13),''),CHR(10),'') DATA_ID
, COV_INS_AMT_SEQ
, REPLACE(REPLACE(COMS_BIZ_DIV_CD,CHR(13),''),CHR(10),'') COMS_BIZ_DIV_CD
, REPLACE(REPLACE(CLM_ID,CHR(13),''),CHR(10),'') CLM_ID
, ISD_PCS_SEQ
, REPLACE(REPLACE(ACD_OBJ_DIV_CD,CHR(13),''),CHR(10),'') ACD_OBJ_DIV_CD
, REPLACE(REPLACE(ACD_OBJ_ID,CHR(13),''),CHR(10),'') ACD_OBJ_ID
, REPLACE(REPLACE(COV_CD,CHR(13),''),CHR(10),'') COV_CD
, REPLACE(REPLACE(RSK_UNT_CD,CHR(13),''),CHR(10),'') RSK_UNT_CD
, REPLACE(REPLACE(COMS_DIV_DTL_CD,CHR(13),''),CHR(10),'') COMS_DIV_DTL_CD
, REPLACE(REPLACE(GURT_UNT_CD,CHR(13),''),CHR(10),'') GURT_UNT_CD
, REPLACE(REPLACE(SIC_CD,CHR(13),''),CHR(10),'') SIC_CD
, REPLACE(REPLACE(INS_AMT_EXT_EXP_DIV_CD,CHR(13),''),CHR(10),'') INS_AMT_EXT_EXP_DIV_CD
, REPLACE(REPLACE(CLADJ_DIV_CTG_CD,CHR(13),''),CHR(10),'') CLADJ_DIV_CTG_CD
, REPLACE(REPLACE(COMS_DIV_CTG_CD,CHR(13),''),CHR(10),'') COMS_DIV_CTG_CD
, INS_AMT_APVL_DT
, REPLACE(REPLACE(CUR_CD,CHR(13),''),CHR(10),'') CUR_CD
, REPLACE(REPLACE(TLSS_PTLS_DIV_CD,CHR(13),''),CHR(10),'') TLSS_PTLS_DIV_CD
, OS_INS_AMT
, OPTN_INS_AMT
, RPSB_INS_AMT
, OS_CHGE_AMT
, DCN_INS_AMT
, ETC_RETR_INS_AMT
, ACCM_DCN_INS_AMT
, REPLACE(REPLACE(OS_CHGE_RSN_CD,CHR(13),''),CHR(10),'') OS_CHGE_RSN_CD
, REPLACE(REPLACE(CMPT_CON,CHR(13),''),CHR(10),'') CMPT_CON
, KW_CNVS_DCN_INS_AMT
, OCC_DMG_AMT
, OWN_BRD_AMT
, REPLACE(REPLACE(OWN_BRD_AMT_DDC_YN,CHR(13),''),CHR(10),'') OWN_BRD_AMT_DDC_YN
, SVV_VAMT
, INS_VAMT
, HIS_ST_DTM
, HIS_ED_DTM
, REPLACE(REPLACE(INPPE_ORG_ID,CHR(13),''),CHR(10),'') INPPE_ORG_ID
, SYS_OCC_DTM
, REPLACE(REPLACE(SYS_DEL_DIV_CD,CHR(13),''),CHR(10),'') SYS_DEL_DIV_CD
, REPLACE(REPLACE(OCC_IP,CHR(13),''),CHR(10),'') OCC_IP
, REPLACE(REPLACE(APP_ID,CHR(13),''),CHR(10),'') APP_ID
, DATA_CHNG_DTM
, EIH_LDG_DTM
, SLRY_OS_INS_AMT
, NSRY_OS_INS_AMT
, SLRY_OS_CHGE_AMT
, NSRY_OS_CHGE_AMT
, SLRY_DCN_INS_AMT
, NSRY_DCN_INS_AMT
, SLRY_KWCV_DCN_INS_AMT
, NSRY_KWCV_DCN_INS_AMT
, SLRY_ACCM_DCN_INS_AMT
, NSRY_ACCM_DCN_INS_AMT
, SLRY_OCC_DMG_AMT
, NSRY_OCC_DMG_AMT FROM THDDH_TCLCOV
                       WHERE \$CONDITIONS "\
    --m 8 \
    --boundary-query "SELECT 0, 7 FROM DUAL"\
    --split-by "ORA_HASH(COV_INS_AMT_ID, 7)"\
    --target-dir /tmp2/LAST_THDDH_TCLCOV \
    --hive-import \
    --external-table-dir hdfs:///tmp2/temp_tbl/LAST_THDDH_TCLCOV \
    --hive-overwrite \
    --hive-table DEFAULT.LAST_THDDH_TCLCOV  >> ${SHLOG_DIR}/THDDH_TCLCOV.shlog 2>&1 &&

#----------------------------------------------------#
# Hadoop 원본테이블에 변경분 최종 적용
#----------------------------------------------------#
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TCLCOV_TMP ; " >> ${SHLOG_DIR}/THDDH_TCLCOV.shlog 2>&1 &&
    /usr/bin/hive -e "CREATE EXTERNAL TABLE MERITZ.THDDH_TCLCOV_TMP STORED AS PARQUET TBLPROPERTIES ('PARQUET.COMPRESS'='SNAPPY') AS
                                SELECT *
                                FROM DEFAULT.LAST_THDDH_TCLCOV ;" >> ${SHLOG_DIR}/THDDH_TCLCOV.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.LAST_THDDH_TCLCOV ;" >> ${SHLOG_DIR}/THDDH_TCLCOV.shlog 2>&1 &&
    /usr/bin/hdfs dfs -rm -r -f -skipTrash /warehouse/tablespace/external/hive/last_thddh_tclcov >> ${SHLOG_DIR}/THDDH_TCLCOV.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TCLCOV ;" >> ${SHLOG_DIR}/THDDH_TCLCOV.shlog 2>&1 &&
    /usr/bin/hive -e "ALTER TABLE MERITZ.THDDH_TCLCOV_TMP RENAME TO MERITZ.THDDH_TCLCOV ;" >> ${SHLOG_DIR}/THDDH_TCLCOV.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TCLCOV_TMP ;" >> ${SHLOG_DIR}/THDDH_TCLCOV.shlog 2>&1 

if [ $? -ne 0 ]
then             
    echo "*-----------[ THDDH_TCLCOV.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/THDDH_TCLCOV.shlog"
    echo "*-----------[ THDDH_TCLCOV.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/THDDH_TCLCOV.shlog"  >>  ${SHLOG_DIR}/THDDH_TCLCOV.shlog
    echo "*-----------[ THDDH_TCLCOV.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TCLCOV.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/THDDH_TCLCOV.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/THDDH_TCLCOV.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCLCOV.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCLCOV.shlog /sqoopbin/scripts/etlpgm/his_log/THDDH_TCLCOV_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  THDDH_TCLCOV.sh cmd command error !! ***
    fi               

    exit -1      

else             
    echo "*-----------[ THDDH_TCLCOV.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TCLCOV.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/THDDH_TCLCOV.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/THDDH_TCLCOV.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCLCOV.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCLCOV.shlog /sqoopbin/scripts/etlpgm/his_log/THDDH_TCLCOV_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  THDDH_TCLCOV.sh cmd command error !! ***
        exit -1      
    else             
        exit 0       
    fi               
fi               
