// ORM class for table 'null'
// WARNING: This class is AUTO-GENERATED. Modify at your own risk.
//
// Debug information:
// Generated date: Tue Jan 21 23:22:53 GMT 2020
// For connector: org.apache.sqoop.manager.OracleManager
import org.apache.hadoop.io.BytesWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.mapred.lib.db.DBWritable;
import org.apache.sqoop.lib.JdbcWritableBridge;
import org.apache.sqoop.lib.DelimiterSet;
import org.apache.sqoop.lib.FieldFormatter;
import org.apache.sqoop.lib.RecordParser;
import org.apache.sqoop.lib.BooleanParser;
import org.apache.sqoop.lib.BlobRef;
import org.apache.sqoop.lib.ClobRef;
import org.apache.sqoop.lib.LargeObjectLoader;
import org.apache.sqoop.lib.SqoopRecord;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.sql.Date;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

public class QueryResult extends SqoopRecord  implements DBWritable, Writable {
  private final int PROTOCOL_VERSION = 3;
  public int getClassFormatVersion() { return PROTOCOL_VERSION; }
  public static interface FieldSetterCommand {    void setField(Object value);  }  protected ResultSet __cur_result_set;
  private Map<String, FieldSetterCommand> setters = new HashMap<String, FieldSetterCommand>();
  private void init0() {
    setters.put("CLM_ID", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.CLM_ID = (String)value;
      }
    });
    setters.put("DMPE_ID", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.DMPE_ID = (String)value;
      }
    });
    setters.put("INF_OBM_FIX_SEQ", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.INF_OBM_FIX_SEQ = (java.math.BigDecimal)value;
      }
    });
    setters.put("HIS_SEQ", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.HIS_SEQ = (java.math.BigDecimal)value;
      }
    });
    setters.put("ACD_RCT_ID", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.ACD_RCT_ID = (String)value;
      }
    });
    setters.put("SPFC_DIVD_DIV_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.SPFC_DIVD_DIV_CD = (String)value;
      }
    });
    setters.put("MORL_DIVD_DIV_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.MORL_DIVD_DIV_CD = (String)value;
      }
    });
    setters.put("SCRG_SCR", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.SCRG_SCR = (java.math.BigDecimal)value;
      }
    });
    setters.put("CLUNIT_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.CLUNIT_CD = (String)value;
      }
    });
    setters.put("DTH_YN", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.DTH_YN = (String)value;
      }
    });
    setters.put("AFOBS_YN", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.AFOBS_YN = (String)value;
      }
    });
    setters.put("PRSM_INS_AMT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.PRSM_INS_AMT = (java.math.BigDecimal)value;
      }
    });
    setters.put("ACCM_DCN_INS_AMT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.ACCM_DCN_INS_AMT = (java.math.BigDecimal)value;
      }
    });
    setters.put("MD_EXP_CUS_GRDE_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.MD_EXP_CUS_GRDE_CD = (String)value;
      }
    });
    setters.put("DDPY_CUS_GRDE_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.DDPY_CUS_GRDE_CD = (String)value;
      }
    });
    setters.put("QUES_HOSP_YN", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.QUES_HOSP_YN = (String)value;
      }
    });
    setters.put("OBST_MORL_HOSP_YN", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.OBST_MORL_HOSP_YN = (String)value;
      }
    });
    setters.put("DDPY_ATTN_HOSP_YN", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.DDPY_ATTN_HOSP_YN = (String)value;
      }
    });
    setters.put("NSRY_ATTN_HOSP_YN", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.NSRY_ATTN_HOSP_YN = (String)value;
      }
    });
    setters.put("OWN_CTR_YN", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.OWN_CTR_YN = (String)value;
      }
    });
    setters.put("ACD_OCFQ_CUS_YN", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.ACD_OCFQ_CUS_YN = (String)value;
      }
    });
    setters.put("APPR_ACD_DD_DIV_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.APPR_ACD_DD_DIV_CD = (String)value;
      }
    });
    setters.put("MORL_KR_DISZ_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.MORL_KR_DISZ_CD = (String)value;
      }
    });
    setters.put("DISZ_CD_LST", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.DISZ_CD_LST = (String)value;
      }
    });
    setters.put("SPFC_TRTPE_YN", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.SPFC_TRTPE_YN = (String)value;
      }
    });
    setters.put("HIS_ST_DTM", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.HIS_ST_DTM = (java.sql.Timestamp)value;
      }
    });
    setters.put("HIS_ED_DTM", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.HIS_ED_DTM = (java.sql.Timestamp)value;
      }
    });
    setters.put("INPPE_ORG_ID", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.INPPE_ORG_ID = (String)value;
      }
    });
    setters.put("SYS_OCC_DTM", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.SYS_OCC_DTM = (java.sql.Timestamp)value;
      }
    });
    setters.put("SYS_DEL_DIV_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.SYS_DEL_DIV_CD = (String)value;
      }
    });
    setters.put("OCC_IP", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.OCC_IP = (String)value;
      }
    });
    setters.put("APP_ID", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.APP_ID = (String)value;
      }
    });
    setters.put("DATA_CHNG_DTM", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.DATA_CHNG_DTM = (java.sql.Timestamp)value;
      }
    });
    setters.put("DGN_FEE1", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.DGN_FEE1 = (java.math.BigDecimal)value;
      }
    });
    setters.put("DGN_FEE2", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.DGN_FEE2 = (java.math.BigDecimal)value;
      }
    });
    setters.put("LAW_VLT_YN", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.LAW_VLT_YN = (String)value;
      }
    });
    setters.put("BAS_SCR", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.BAS_SCR = (java.math.BigDecimal)value;
      }
    });
    setters.put("CHRPE_ORG_ID", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.CHRPE_ORG_ID = (String)value;
      }
    });
    setters.put("CHRPE_PART_ORG_ID", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.CHRPE_PART_ORG_ID = (String)value;
      }
    });
    setters.put("CHRPE_TEM_ORG_ID", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.CHRPE_TEM_ORG_ID = (String)value;
      }
    });
    setters.put("MORL_DIVD_DTL_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.MORL_DIVD_DTL_CD = (String)value;
      }
    });
    setters.put("SPFC_DGN_MORL_YN", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.SPFC_DGN_MORL_YN = (String)value;
      }
    });
    setters.put("ETC_CON", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.ETC_CON = (String)value;
      }
    });
    setters.put("EIH_LDG_DTM", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.EIH_LDG_DTM = (java.sql.Timestamp)value;
      }
    });
    setters.put("NURPE_SVC_RQE_YN", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.NURPE_SVC_RQE_YN = (String)value;
      }
    });
    setters.put("RULE_SQ_VAL", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.RULE_SQ_VAL = (String)value;
      }
    });
    setters.put("RULE_TRM_RSL_LST_CON20", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.RULE_TRM_RSL_LST_CON20 = (org.apache.sqoop.lib.ClobRef)value;
      }
    });
    setters.put("RULE_TRM_RSL_LST_CON26", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.RULE_TRM_RSL_LST_CON26 = (org.apache.sqoop.lib.ClobRef)value;
      }
    });
    setters.put("RULE_TRM_RSL_LST_CON27", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.RULE_TRM_RSL_LST_CON27 = (org.apache.sqoop.lib.ClobRef)value;
      }
    });
    setters.put("RULE_TRM_RSL_LST_CON28", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.RULE_TRM_RSL_LST_CON28 = (org.apache.sqoop.lib.ClobRef)value;
      }
    });
    setters.put("RULE_TRM_RSL_LST_CON29", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.RULE_TRM_RSL_LST_CON29 = (org.apache.sqoop.lib.ClobRef)value;
      }
    });
    setters.put("RULE_TRM_RSL_LST_CON30", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.RULE_TRM_RSL_LST_CON30 = (org.apache.sqoop.lib.ClobRef)value;
      }
    });
    setters.put("RULE_TRM_RSL_LST_CON32", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.RULE_TRM_RSL_LST_CON32 = (org.apache.sqoop.lib.ClobRef)value;
      }
    });
    setters.put("MDEL_APL_TRG_YN", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.MDEL_APL_TRG_YN = (String)value;
      }
    });
    setters.put("APL_BF_FLTR_TRM_VAL", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.APL_BF_FLTR_TRM_VAL = (String)value;
      }
    });
    setters.put("MDEL_APL_DIV_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.MDEL_APL_DIV_CD = (String)value;
      }
    });
    setters.put("MDEL_TRM_APL_RSL_VAL", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.MDEL_TRM_APL_RSL_VAL = (org.apache.sqoop.lib.ClobRef)value;
      }
    });
    setters.put("MDEL_DIV_CD_STD_VAL", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.MDEL_DIV_CD_STD_VAL = (String)value;
      }
    });
    setters.put("MDEL_CMPT_RSL_VAL", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.MDEL_CMPT_RSL_VAL = (String)value;
      }
    });
    setters.put("CMPT_SQ_CLUNIT_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.CMPT_SQ_CLUNIT_CD = (String)value;
      }
    });
    setters.put("CMPT_SQ_DIVD_DIV_VAL", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.CMPT_SQ_DIVD_DIV_VAL = (String)value;
      }
    });
    setters.put("OS_ID", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.OS_ID = (String)value;
      }
    });
  }
  public QueryResult() {
    init0();
  }
  private String CLM_ID;
  public String get_CLM_ID() {
    return CLM_ID;
  }
  public void set_CLM_ID(String CLM_ID) {
    this.CLM_ID = CLM_ID;
  }
  public QueryResult with_CLM_ID(String CLM_ID) {
    this.CLM_ID = CLM_ID;
    return this;
  }
  private String DMPE_ID;
  public String get_DMPE_ID() {
    return DMPE_ID;
  }
  public void set_DMPE_ID(String DMPE_ID) {
    this.DMPE_ID = DMPE_ID;
  }
  public QueryResult with_DMPE_ID(String DMPE_ID) {
    this.DMPE_ID = DMPE_ID;
    return this;
  }
  private java.math.BigDecimal INF_OBM_FIX_SEQ;
  public java.math.BigDecimal get_INF_OBM_FIX_SEQ() {
    return INF_OBM_FIX_SEQ;
  }
  public void set_INF_OBM_FIX_SEQ(java.math.BigDecimal INF_OBM_FIX_SEQ) {
    this.INF_OBM_FIX_SEQ = INF_OBM_FIX_SEQ;
  }
  public QueryResult with_INF_OBM_FIX_SEQ(java.math.BigDecimal INF_OBM_FIX_SEQ) {
    this.INF_OBM_FIX_SEQ = INF_OBM_FIX_SEQ;
    return this;
  }
  private java.math.BigDecimal HIS_SEQ;
  public java.math.BigDecimal get_HIS_SEQ() {
    return HIS_SEQ;
  }
  public void set_HIS_SEQ(java.math.BigDecimal HIS_SEQ) {
    this.HIS_SEQ = HIS_SEQ;
  }
  public QueryResult with_HIS_SEQ(java.math.BigDecimal HIS_SEQ) {
    this.HIS_SEQ = HIS_SEQ;
    return this;
  }
  private String ACD_RCT_ID;
  public String get_ACD_RCT_ID() {
    return ACD_RCT_ID;
  }
  public void set_ACD_RCT_ID(String ACD_RCT_ID) {
    this.ACD_RCT_ID = ACD_RCT_ID;
  }
  public QueryResult with_ACD_RCT_ID(String ACD_RCT_ID) {
    this.ACD_RCT_ID = ACD_RCT_ID;
    return this;
  }
  private String SPFC_DIVD_DIV_CD;
  public String get_SPFC_DIVD_DIV_CD() {
    return SPFC_DIVD_DIV_CD;
  }
  public void set_SPFC_DIVD_DIV_CD(String SPFC_DIVD_DIV_CD) {
    this.SPFC_DIVD_DIV_CD = SPFC_DIVD_DIV_CD;
  }
  public QueryResult with_SPFC_DIVD_DIV_CD(String SPFC_DIVD_DIV_CD) {
    this.SPFC_DIVD_DIV_CD = SPFC_DIVD_DIV_CD;
    return this;
  }
  private String MORL_DIVD_DIV_CD;
  public String get_MORL_DIVD_DIV_CD() {
    return MORL_DIVD_DIV_CD;
  }
  public void set_MORL_DIVD_DIV_CD(String MORL_DIVD_DIV_CD) {
    this.MORL_DIVD_DIV_CD = MORL_DIVD_DIV_CD;
  }
  public QueryResult with_MORL_DIVD_DIV_CD(String MORL_DIVD_DIV_CD) {
    this.MORL_DIVD_DIV_CD = MORL_DIVD_DIV_CD;
    return this;
  }
  private java.math.BigDecimal SCRG_SCR;
  public java.math.BigDecimal get_SCRG_SCR() {
    return SCRG_SCR;
  }
  public void set_SCRG_SCR(java.math.BigDecimal SCRG_SCR) {
    this.SCRG_SCR = SCRG_SCR;
  }
  public QueryResult with_SCRG_SCR(java.math.BigDecimal SCRG_SCR) {
    this.SCRG_SCR = SCRG_SCR;
    return this;
  }
  private String CLUNIT_CD;
  public String get_CLUNIT_CD() {
    return CLUNIT_CD;
  }
  public void set_CLUNIT_CD(String CLUNIT_CD) {
    this.CLUNIT_CD = CLUNIT_CD;
  }
  public QueryResult with_CLUNIT_CD(String CLUNIT_CD) {
    this.CLUNIT_CD = CLUNIT_CD;
    return this;
  }
  private String DTH_YN;
  public String get_DTH_YN() {
    return DTH_YN;
  }
  public void set_DTH_YN(String DTH_YN) {
    this.DTH_YN = DTH_YN;
  }
  public QueryResult with_DTH_YN(String DTH_YN) {
    this.DTH_YN = DTH_YN;
    return this;
  }
  private String AFOBS_YN;
  public String get_AFOBS_YN() {
    return AFOBS_YN;
  }
  public void set_AFOBS_YN(String AFOBS_YN) {
    this.AFOBS_YN = AFOBS_YN;
  }
  public QueryResult with_AFOBS_YN(String AFOBS_YN) {
    this.AFOBS_YN = AFOBS_YN;
    return this;
  }
  private java.math.BigDecimal PRSM_INS_AMT;
  public java.math.BigDecimal get_PRSM_INS_AMT() {
    return PRSM_INS_AMT;
  }
  public void set_PRSM_INS_AMT(java.math.BigDecimal PRSM_INS_AMT) {
    this.PRSM_INS_AMT = PRSM_INS_AMT;
  }
  public QueryResult with_PRSM_INS_AMT(java.math.BigDecimal PRSM_INS_AMT) {
    this.PRSM_INS_AMT = PRSM_INS_AMT;
    return this;
  }
  private java.math.BigDecimal ACCM_DCN_INS_AMT;
  public java.math.BigDecimal get_ACCM_DCN_INS_AMT() {
    return ACCM_DCN_INS_AMT;
  }
  public void set_ACCM_DCN_INS_AMT(java.math.BigDecimal ACCM_DCN_INS_AMT) {
    this.ACCM_DCN_INS_AMT = ACCM_DCN_INS_AMT;
  }
  public QueryResult with_ACCM_DCN_INS_AMT(java.math.BigDecimal ACCM_DCN_INS_AMT) {
    this.ACCM_DCN_INS_AMT = ACCM_DCN_INS_AMT;
    return this;
  }
  private String MD_EXP_CUS_GRDE_CD;
  public String get_MD_EXP_CUS_GRDE_CD() {
    return MD_EXP_CUS_GRDE_CD;
  }
  public void set_MD_EXP_CUS_GRDE_CD(String MD_EXP_CUS_GRDE_CD) {
    this.MD_EXP_CUS_GRDE_CD = MD_EXP_CUS_GRDE_CD;
  }
  public QueryResult with_MD_EXP_CUS_GRDE_CD(String MD_EXP_CUS_GRDE_CD) {
    this.MD_EXP_CUS_GRDE_CD = MD_EXP_CUS_GRDE_CD;
    return this;
  }
  private String DDPY_CUS_GRDE_CD;
  public String get_DDPY_CUS_GRDE_CD() {
    return DDPY_CUS_GRDE_CD;
  }
  public void set_DDPY_CUS_GRDE_CD(String DDPY_CUS_GRDE_CD) {
    this.DDPY_CUS_GRDE_CD = DDPY_CUS_GRDE_CD;
  }
  public QueryResult with_DDPY_CUS_GRDE_CD(String DDPY_CUS_GRDE_CD) {
    this.DDPY_CUS_GRDE_CD = DDPY_CUS_GRDE_CD;
    return this;
  }
  private String QUES_HOSP_YN;
  public String get_QUES_HOSP_YN() {
    return QUES_HOSP_YN;
  }
  public void set_QUES_HOSP_YN(String QUES_HOSP_YN) {
    this.QUES_HOSP_YN = QUES_HOSP_YN;
  }
  public QueryResult with_QUES_HOSP_YN(String QUES_HOSP_YN) {
    this.QUES_HOSP_YN = QUES_HOSP_YN;
    return this;
  }
  private String OBST_MORL_HOSP_YN;
  public String get_OBST_MORL_HOSP_YN() {
    return OBST_MORL_HOSP_YN;
  }
  public void set_OBST_MORL_HOSP_YN(String OBST_MORL_HOSP_YN) {
    this.OBST_MORL_HOSP_YN = OBST_MORL_HOSP_YN;
  }
  public QueryResult with_OBST_MORL_HOSP_YN(String OBST_MORL_HOSP_YN) {
    this.OBST_MORL_HOSP_YN = OBST_MORL_HOSP_YN;
    return this;
  }
  private String DDPY_ATTN_HOSP_YN;
  public String get_DDPY_ATTN_HOSP_YN() {
    return DDPY_ATTN_HOSP_YN;
  }
  public void set_DDPY_ATTN_HOSP_YN(String DDPY_ATTN_HOSP_YN) {
    this.DDPY_ATTN_HOSP_YN = DDPY_ATTN_HOSP_YN;
  }
  public QueryResult with_DDPY_ATTN_HOSP_YN(String DDPY_ATTN_HOSP_YN) {
    this.DDPY_ATTN_HOSP_YN = DDPY_ATTN_HOSP_YN;
    return this;
  }
  private String NSRY_ATTN_HOSP_YN;
  public String get_NSRY_ATTN_HOSP_YN() {
    return NSRY_ATTN_HOSP_YN;
  }
  public void set_NSRY_ATTN_HOSP_YN(String NSRY_ATTN_HOSP_YN) {
    this.NSRY_ATTN_HOSP_YN = NSRY_ATTN_HOSP_YN;
  }
  public QueryResult with_NSRY_ATTN_HOSP_YN(String NSRY_ATTN_HOSP_YN) {
    this.NSRY_ATTN_HOSP_YN = NSRY_ATTN_HOSP_YN;
    return this;
  }
  private String OWN_CTR_YN;
  public String get_OWN_CTR_YN() {
    return OWN_CTR_YN;
  }
  public void set_OWN_CTR_YN(String OWN_CTR_YN) {
    this.OWN_CTR_YN = OWN_CTR_YN;
  }
  public QueryResult with_OWN_CTR_YN(String OWN_CTR_YN) {
    this.OWN_CTR_YN = OWN_CTR_YN;
    return this;
  }
  private String ACD_OCFQ_CUS_YN;
  public String get_ACD_OCFQ_CUS_YN() {
    return ACD_OCFQ_CUS_YN;
  }
  public void set_ACD_OCFQ_CUS_YN(String ACD_OCFQ_CUS_YN) {
    this.ACD_OCFQ_CUS_YN = ACD_OCFQ_CUS_YN;
  }
  public QueryResult with_ACD_OCFQ_CUS_YN(String ACD_OCFQ_CUS_YN) {
    this.ACD_OCFQ_CUS_YN = ACD_OCFQ_CUS_YN;
    return this;
  }
  private String APPR_ACD_DD_DIV_CD;
  public String get_APPR_ACD_DD_DIV_CD() {
    return APPR_ACD_DD_DIV_CD;
  }
  public void set_APPR_ACD_DD_DIV_CD(String APPR_ACD_DD_DIV_CD) {
    this.APPR_ACD_DD_DIV_CD = APPR_ACD_DD_DIV_CD;
  }
  public QueryResult with_APPR_ACD_DD_DIV_CD(String APPR_ACD_DD_DIV_CD) {
    this.APPR_ACD_DD_DIV_CD = APPR_ACD_DD_DIV_CD;
    return this;
  }
  private String MORL_KR_DISZ_CD;
  public String get_MORL_KR_DISZ_CD() {
    return MORL_KR_DISZ_CD;
  }
  public void set_MORL_KR_DISZ_CD(String MORL_KR_DISZ_CD) {
    this.MORL_KR_DISZ_CD = MORL_KR_DISZ_CD;
  }
  public QueryResult with_MORL_KR_DISZ_CD(String MORL_KR_DISZ_CD) {
    this.MORL_KR_DISZ_CD = MORL_KR_DISZ_CD;
    return this;
  }
  private String DISZ_CD_LST;
  public String get_DISZ_CD_LST() {
    return DISZ_CD_LST;
  }
  public void set_DISZ_CD_LST(String DISZ_CD_LST) {
    this.DISZ_CD_LST = DISZ_CD_LST;
  }
  public QueryResult with_DISZ_CD_LST(String DISZ_CD_LST) {
    this.DISZ_CD_LST = DISZ_CD_LST;
    return this;
  }
  private String SPFC_TRTPE_YN;
  public String get_SPFC_TRTPE_YN() {
    return SPFC_TRTPE_YN;
  }
  public void set_SPFC_TRTPE_YN(String SPFC_TRTPE_YN) {
    this.SPFC_TRTPE_YN = SPFC_TRTPE_YN;
  }
  public QueryResult with_SPFC_TRTPE_YN(String SPFC_TRTPE_YN) {
    this.SPFC_TRTPE_YN = SPFC_TRTPE_YN;
    return this;
  }
  private java.sql.Timestamp HIS_ST_DTM;
  public java.sql.Timestamp get_HIS_ST_DTM() {
    return HIS_ST_DTM;
  }
  public void set_HIS_ST_DTM(java.sql.Timestamp HIS_ST_DTM) {
    this.HIS_ST_DTM = HIS_ST_DTM;
  }
  public QueryResult with_HIS_ST_DTM(java.sql.Timestamp HIS_ST_DTM) {
    this.HIS_ST_DTM = HIS_ST_DTM;
    return this;
  }
  private java.sql.Timestamp HIS_ED_DTM;
  public java.sql.Timestamp get_HIS_ED_DTM() {
    return HIS_ED_DTM;
  }
  public void set_HIS_ED_DTM(java.sql.Timestamp HIS_ED_DTM) {
    this.HIS_ED_DTM = HIS_ED_DTM;
  }
  public QueryResult with_HIS_ED_DTM(java.sql.Timestamp HIS_ED_DTM) {
    this.HIS_ED_DTM = HIS_ED_DTM;
    return this;
  }
  private String INPPE_ORG_ID;
  public String get_INPPE_ORG_ID() {
    return INPPE_ORG_ID;
  }
  public void set_INPPE_ORG_ID(String INPPE_ORG_ID) {
    this.INPPE_ORG_ID = INPPE_ORG_ID;
  }
  public QueryResult with_INPPE_ORG_ID(String INPPE_ORG_ID) {
    this.INPPE_ORG_ID = INPPE_ORG_ID;
    return this;
  }
  private java.sql.Timestamp SYS_OCC_DTM;
  public java.sql.Timestamp get_SYS_OCC_DTM() {
    return SYS_OCC_DTM;
  }
  public void set_SYS_OCC_DTM(java.sql.Timestamp SYS_OCC_DTM) {
    this.SYS_OCC_DTM = SYS_OCC_DTM;
  }
  public QueryResult with_SYS_OCC_DTM(java.sql.Timestamp SYS_OCC_DTM) {
    this.SYS_OCC_DTM = SYS_OCC_DTM;
    return this;
  }
  private String SYS_DEL_DIV_CD;
  public String get_SYS_DEL_DIV_CD() {
    return SYS_DEL_DIV_CD;
  }
  public void set_SYS_DEL_DIV_CD(String SYS_DEL_DIV_CD) {
    this.SYS_DEL_DIV_CD = SYS_DEL_DIV_CD;
  }
  public QueryResult with_SYS_DEL_DIV_CD(String SYS_DEL_DIV_CD) {
    this.SYS_DEL_DIV_CD = SYS_DEL_DIV_CD;
    return this;
  }
  private String OCC_IP;
  public String get_OCC_IP() {
    return OCC_IP;
  }
  public void set_OCC_IP(String OCC_IP) {
    this.OCC_IP = OCC_IP;
  }
  public QueryResult with_OCC_IP(String OCC_IP) {
    this.OCC_IP = OCC_IP;
    return this;
  }
  private String APP_ID;
  public String get_APP_ID() {
    return APP_ID;
  }
  public void set_APP_ID(String APP_ID) {
    this.APP_ID = APP_ID;
  }
  public QueryResult with_APP_ID(String APP_ID) {
    this.APP_ID = APP_ID;
    return this;
  }
  private java.sql.Timestamp DATA_CHNG_DTM;
  public java.sql.Timestamp get_DATA_CHNG_DTM() {
    return DATA_CHNG_DTM;
  }
  public void set_DATA_CHNG_DTM(java.sql.Timestamp DATA_CHNG_DTM) {
    this.DATA_CHNG_DTM = DATA_CHNG_DTM;
  }
  public QueryResult with_DATA_CHNG_DTM(java.sql.Timestamp DATA_CHNG_DTM) {
    this.DATA_CHNG_DTM = DATA_CHNG_DTM;
    return this;
  }
  private java.math.BigDecimal DGN_FEE1;
  public java.math.BigDecimal get_DGN_FEE1() {
    return DGN_FEE1;
  }
  public void set_DGN_FEE1(java.math.BigDecimal DGN_FEE1) {
    this.DGN_FEE1 = DGN_FEE1;
  }
  public QueryResult with_DGN_FEE1(java.math.BigDecimal DGN_FEE1) {
    this.DGN_FEE1 = DGN_FEE1;
    return this;
  }
  private java.math.BigDecimal DGN_FEE2;
  public java.math.BigDecimal get_DGN_FEE2() {
    return DGN_FEE2;
  }
  public void set_DGN_FEE2(java.math.BigDecimal DGN_FEE2) {
    this.DGN_FEE2 = DGN_FEE2;
  }
  public QueryResult with_DGN_FEE2(java.math.BigDecimal DGN_FEE2) {
    this.DGN_FEE2 = DGN_FEE2;
    return this;
  }
  private String LAW_VLT_YN;
  public String get_LAW_VLT_YN() {
    return LAW_VLT_YN;
  }
  public void set_LAW_VLT_YN(String LAW_VLT_YN) {
    this.LAW_VLT_YN = LAW_VLT_YN;
  }
  public QueryResult with_LAW_VLT_YN(String LAW_VLT_YN) {
    this.LAW_VLT_YN = LAW_VLT_YN;
    return this;
  }
  private java.math.BigDecimal BAS_SCR;
  public java.math.BigDecimal get_BAS_SCR() {
    return BAS_SCR;
  }
  public void set_BAS_SCR(java.math.BigDecimal BAS_SCR) {
    this.BAS_SCR = BAS_SCR;
  }
  public QueryResult with_BAS_SCR(java.math.BigDecimal BAS_SCR) {
    this.BAS_SCR = BAS_SCR;
    return this;
  }
  private String CHRPE_ORG_ID;
  public String get_CHRPE_ORG_ID() {
    return CHRPE_ORG_ID;
  }
  public void set_CHRPE_ORG_ID(String CHRPE_ORG_ID) {
    this.CHRPE_ORG_ID = CHRPE_ORG_ID;
  }
  public QueryResult with_CHRPE_ORG_ID(String CHRPE_ORG_ID) {
    this.CHRPE_ORG_ID = CHRPE_ORG_ID;
    return this;
  }
  private String CHRPE_PART_ORG_ID;
  public String get_CHRPE_PART_ORG_ID() {
    return CHRPE_PART_ORG_ID;
  }
  public void set_CHRPE_PART_ORG_ID(String CHRPE_PART_ORG_ID) {
    this.CHRPE_PART_ORG_ID = CHRPE_PART_ORG_ID;
  }
  public QueryResult with_CHRPE_PART_ORG_ID(String CHRPE_PART_ORG_ID) {
    this.CHRPE_PART_ORG_ID = CHRPE_PART_ORG_ID;
    return this;
  }
  private String CHRPE_TEM_ORG_ID;
  public String get_CHRPE_TEM_ORG_ID() {
    return CHRPE_TEM_ORG_ID;
  }
  public void set_CHRPE_TEM_ORG_ID(String CHRPE_TEM_ORG_ID) {
    this.CHRPE_TEM_ORG_ID = CHRPE_TEM_ORG_ID;
  }
  public QueryResult with_CHRPE_TEM_ORG_ID(String CHRPE_TEM_ORG_ID) {
    this.CHRPE_TEM_ORG_ID = CHRPE_TEM_ORG_ID;
    return this;
  }
  private String MORL_DIVD_DTL_CD;
  public String get_MORL_DIVD_DTL_CD() {
    return MORL_DIVD_DTL_CD;
  }
  public void set_MORL_DIVD_DTL_CD(String MORL_DIVD_DTL_CD) {
    this.MORL_DIVD_DTL_CD = MORL_DIVD_DTL_CD;
  }
  public QueryResult with_MORL_DIVD_DTL_CD(String MORL_DIVD_DTL_CD) {
    this.MORL_DIVD_DTL_CD = MORL_DIVD_DTL_CD;
    return this;
  }
  private String SPFC_DGN_MORL_YN;
  public String get_SPFC_DGN_MORL_YN() {
    return SPFC_DGN_MORL_YN;
  }
  public void set_SPFC_DGN_MORL_YN(String SPFC_DGN_MORL_YN) {
    this.SPFC_DGN_MORL_YN = SPFC_DGN_MORL_YN;
  }
  public QueryResult with_SPFC_DGN_MORL_YN(String SPFC_DGN_MORL_YN) {
    this.SPFC_DGN_MORL_YN = SPFC_DGN_MORL_YN;
    return this;
  }
  private String ETC_CON;
  public String get_ETC_CON() {
    return ETC_CON;
  }
  public void set_ETC_CON(String ETC_CON) {
    this.ETC_CON = ETC_CON;
  }
  public QueryResult with_ETC_CON(String ETC_CON) {
    this.ETC_CON = ETC_CON;
    return this;
  }
  private java.sql.Timestamp EIH_LDG_DTM;
  public java.sql.Timestamp get_EIH_LDG_DTM() {
    return EIH_LDG_DTM;
  }
  public void set_EIH_LDG_DTM(java.sql.Timestamp EIH_LDG_DTM) {
    this.EIH_LDG_DTM = EIH_LDG_DTM;
  }
  public QueryResult with_EIH_LDG_DTM(java.sql.Timestamp EIH_LDG_DTM) {
    this.EIH_LDG_DTM = EIH_LDG_DTM;
    return this;
  }
  private String NURPE_SVC_RQE_YN;
  public String get_NURPE_SVC_RQE_YN() {
    return NURPE_SVC_RQE_YN;
  }
  public void set_NURPE_SVC_RQE_YN(String NURPE_SVC_RQE_YN) {
    this.NURPE_SVC_RQE_YN = NURPE_SVC_RQE_YN;
  }
  public QueryResult with_NURPE_SVC_RQE_YN(String NURPE_SVC_RQE_YN) {
    this.NURPE_SVC_RQE_YN = NURPE_SVC_RQE_YN;
    return this;
  }
  private String RULE_SQ_VAL;
  public String get_RULE_SQ_VAL() {
    return RULE_SQ_VAL;
  }
  public void set_RULE_SQ_VAL(String RULE_SQ_VAL) {
    this.RULE_SQ_VAL = RULE_SQ_VAL;
  }
  public QueryResult with_RULE_SQ_VAL(String RULE_SQ_VAL) {
    this.RULE_SQ_VAL = RULE_SQ_VAL;
    return this;
  }
  private org.apache.sqoop.lib.ClobRef RULE_TRM_RSL_LST_CON20;
  public org.apache.sqoop.lib.ClobRef get_RULE_TRM_RSL_LST_CON20() {
    return RULE_TRM_RSL_LST_CON20;
  }
  public void set_RULE_TRM_RSL_LST_CON20(org.apache.sqoop.lib.ClobRef RULE_TRM_RSL_LST_CON20) {
    this.RULE_TRM_RSL_LST_CON20 = RULE_TRM_RSL_LST_CON20;
  }
  public QueryResult with_RULE_TRM_RSL_LST_CON20(org.apache.sqoop.lib.ClobRef RULE_TRM_RSL_LST_CON20) {
    this.RULE_TRM_RSL_LST_CON20 = RULE_TRM_RSL_LST_CON20;
    return this;
  }
  private org.apache.sqoop.lib.ClobRef RULE_TRM_RSL_LST_CON26;
  public org.apache.sqoop.lib.ClobRef get_RULE_TRM_RSL_LST_CON26() {
    return RULE_TRM_RSL_LST_CON26;
  }
  public void set_RULE_TRM_RSL_LST_CON26(org.apache.sqoop.lib.ClobRef RULE_TRM_RSL_LST_CON26) {
    this.RULE_TRM_RSL_LST_CON26 = RULE_TRM_RSL_LST_CON26;
  }
  public QueryResult with_RULE_TRM_RSL_LST_CON26(org.apache.sqoop.lib.ClobRef RULE_TRM_RSL_LST_CON26) {
    this.RULE_TRM_RSL_LST_CON26 = RULE_TRM_RSL_LST_CON26;
    return this;
  }
  private org.apache.sqoop.lib.ClobRef RULE_TRM_RSL_LST_CON27;
  public org.apache.sqoop.lib.ClobRef get_RULE_TRM_RSL_LST_CON27() {
    return RULE_TRM_RSL_LST_CON27;
  }
  public void set_RULE_TRM_RSL_LST_CON27(org.apache.sqoop.lib.ClobRef RULE_TRM_RSL_LST_CON27) {
    this.RULE_TRM_RSL_LST_CON27 = RULE_TRM_RSL_LST_CON27;
  }
  public QueryResult with_RULE_TRM_RSL_LST_CON27(org.apache.sqoop.lib.ClobRef RULE_TRM_RSL_LST_CON27) {
    this.RULE_TRM_RSL_LST_CON27 = RULE_TRM_RSL_LST_CON27;
    return this;
  }
  private org.apache.sqoop.lib.ClobRef RULE_TRM_RSL_LST_CON28;
  public org.apache.sqoop.lib.ClobRef get_RULE_TRM_RSL_LST_CON28() {
    return RULE_TRM_RSL_LST_CON28;
  }
  public void set_RULE_TRM_RSL_LST_CON28(org.apache.sqoop.lib.ClobRef RULE_TRM_RSL_LST_CON28) {
    this.RULE_TRM_RSL_LST_CON28 = RULE_TRM_RSL_LST_CON28;
  }
  public QueryResult with_RULE_TRM_RSL_LST_CON28(org.apache.sqoop.lib.ClobRef RULE_TRM_RSL_LST_CON28) {
    this.RULE_TRM_RSL_LST_CON28 = RULE_TRM_RSL_LST_CON28;
    return this;
  }
  private org.apache.sqoop.lib.ClobRef RULE_TRM_RSL_LST_CON29;
  public org.apache.sqoop.lib.ClobRef get_RULE_TRM_RSL_LST_CON29() {
    return RULE_TRM_RSL_LST_CON29;
  }
  public void set_RULE_TRM_RSL_LST_CON29(org.apache.sqoop.lib.ClobRef RULE_TRM_RSL_LST_CON29) {
    this.RULE_TRM_RSL_LST_CON29 = RULE_TRM_RSL_LST_CON29;
  }
  public QueryResult with_RULE_TRM_RSL_LST_CON29(org.apache.sqoop.lib.ClobRef RULE_TRM_RSL_LST_CON29) {
    this.RULE_TRM_RSL_LST_CON29 = RULE_TRM_RSL_LST_CON29;
    return this;
  }
  private org.apache.sqoop.lib.ClobRef RULE_TRM_RSL_LST_CON30;
  public org.apache.sqoop.lib.ClobRef get_RULE_TRM_RSL_LST_CON30() {
    return RULE_TRM_RSL_LST_CON30;
  }
  public void set_RULE_TRM_RSL_LST_CON30(org.apache.sqoop.lib.ClobRef RULE_TRM_RSL_LST_CON30) {
    this.RULE_TRM_RSL_LST_CON30 = RULE_TRM_RSL_LST_CON30;
  }
  public QueryResult with_RULE_TRM_RSL_LST_CON30(org.apache.sqoop.lib.ClobRef RULE_TRM_RSL_LST_CON30) {
    this.RULE_TRM_RSL_LST_CON30 = RULE_TRM_RSL_LST_CON30;
    return this;
  }
  private org.apache.sqoop.lib.ClobRef RULE_TRM_RSL_LST_CON32;
  public org.apache.sqoop.lib.ClobRef get_RULE_TRM_RSL_LST_CON32() {
    return RULE_TRM_RSL_LST_CON32;
  }
  public void set_RULE_TRM_RSL_LST_CON32(org.apache.sqoop.lib.ClobRef RULE_TRM_RSL_LST_CON32) {
    this.RULE_TRM_RSL_LST_CON32 = RULE_TRM_RSL_LST_CON32;
  }
  public QueryResult with_RULE_TRM_RSL_LST_CON32(org.apache.sqoop.lib.ClobRef RULE_TRM_RSL_LST_CON32) {
    this.RULE_TRM_RSL_LST_CON32 = RULE_TRM_RSL_LST_CON32;
    return this;
  }
  private String MDEL_APL_TRG_YN;
  public String get_MDEL_APL_TRG_YN() {
    return MDEL_APL_TRG_YN;
  }
  public void set_MDEL_APL_TRG_YN(String MDEL_APL_TRG_YN) {
    this.MDEL_APL_TRG_YN = MDEL_APL_TRG_YN;
  }
  public QueryResult with_MDEL_APL_TRG_YN(String MDEL_APL_TRG_YN) {
    this.MDEL_APL_TRG_YN = MDEL_APL_TRG_YN;
    return this;
  }
  private String APL_BF_FLTR_TRM_VAL;
  public String get_APL_BF_FLTR_TRM_VAL() {
    return APL_BF_FLTR_TRM_VAL;
  }
  public void set_APL_BF_FLTR_TRM_VAL(String APL_BF_FLTR_TRM_VAL) {
    this.APL_BF_FLTR_TRM_VAL = APL_BF_FLTR_TRM_VAL;
  }
  public QueryResult with_APL_BF_FLTR_TRM_VAL(String APL_BF_FLTR_TRM_VAL) {
    this.APL_BF_FLTR_TRM_VAL = APL_BF_FLTR_TRM_VAL;
    return this;
  }
  private String MDEL_APL_DIV_CD;
  public String get_MDEL_APL_DIV_CD() {
    return MDEL_APL_DIV_CD;
  }
  public void set_MDEL_APL_DIV_CD(String MDEL_APL_DIV_CD) {
    this.MDEL_APL_DIV_CD = MDEL_APL_DIV_CD;
  }
  public QueryResult with_MDEL_APL_DIV_CD(String MDEL_APL_DIV_CD) {
    this.MDEL_APL_DIV_CD = MDEL_APL_DIV_CD;
    return this;
  }
  private org.apache.sqoop.lib.ClobRef MDEL_TRM_APL_RSL_VAL;
  public org.apache.sqoop.lib.ClobRef get_MDEL_TRM_APL_RSL_VAL() {
    return MDEL_TRM_APL_RSL_VAL;
  }
  public void set_MDEL_TRM_APL_RSL_VAL(org.apache.sqoop.lib.ClobRef MDEL_TRM_APL_RSL_VAL) {
    this.MDEL_TRM_APL_RSL_VAL = MDEL_TRM_APL_RSL_VAL;
  }
  public QueryResult with_MDEL_TRM_APL_RSL_VAL(org.apache.sqoop.lib.ClobRef MDEL_TRM_APL_RSL_VAL) {
    this.MDEL_TRM_APL_RSL_VAL = MDEL_TRM_APL_RSL_VAL;
    return this;
  }
  private String MDEL_DIV_CD_STD_VAL;
  public String get_MDEL_DIV_CD_STD_VAL() {
    return MDEL_DIV_CD_STD_VAL;
  }
  public void set_MDEL_DIV_CD_STD_VAL(String MDEL_DIV_CD_STD_VAL) {
    this.MDEL_DIV_CD_STD_VAL = MDEL_DIV_CD_STD_VAL;
  }
  public QueryResult with_MDEL_DIV_CD_STD_VAL(String MDEL_DIV_CD_STD_VAL) {
    this.MDEL_DIV_CD_STD_VAL = MDEL_DIV_CD_STD_VAL;
    return this;
  }
  private String MDEL_CMPT_RSL_VAL;
  public String get_MDEL_CMPT_RSL_VAL() {
    return MDEL_CMPT_RSL_VAL;
  }
  public void set_MDEL_CMPT_RSL_VAL(String MDEL_CMPT_RSL_VAL) {
    this.MDEL_CMPT_RSL_VAL = MDEL_CMPT_RSL_VAL;
  }
  public QueryResult with_MDEL_CMPT_RSL_VAL(String MDEL_CMPT_RSL_VAL) {
    this.MDEL_CMPT_RSL_VAL = MDEL_CMPT_RSL_VAL;
    return this;
  }
  private String CMPT_SQ_CLUNIT_CD;
  public String get_CMPT_SQ_CLUNIT_CD() {
    return CMPT_SQ_CLUNIT_CD;
  }
  public void set_CMPT_SQ_CLUNIT_CD(String CMPT_SQ_CLUNIT_CD) {
    this.CMPT_SQ_CLUNIT_CD = CMPT_SQ_CLUNIT_CD;
  }
  public QueryResult with_CMPT_SQ_CLUNIT_CD(String CMPT_SQ_CLUNIT_CD) {
    this.CMPT_SQ_CLUNIT_CD = CMPT_SQ_CLUNIT_CD;
    return this;
  }
  private String CMPT_SQ_DIVD_DIV_VAL;
  public String get_CMPT_SQ_DIVD_DIV_VAL() {
    return CMPT_SQ_DIVD_DIV_VAL;
  }
  public void set_CMPT_SQ_DIVD_DIV_VAL(String CMPT_SQ_DIVD_DIV_VAL) {
    this.CMPT_SQ_DIVD_DIV_VAL = CMPT_SQ_DIVD_DIV_VAL;
  }
  public QueryResult with_CMPT_SQ_DIVD_DIV_VAL(String CMPT_SQ_DIVD_DIV_VAL) {
    this.CMPT_SQ_DIVD_DIV_VAL = CMPT_SQ_DIVD_DIV_VAL;
    return this;
  }
  private String OS_ID;
  public String get_OS_ID() {
    return OS_ID;
  }
  public void set_OS_ID(String OS_ID) {
    this.OS_ID = OS_ID;
  }
  public QueryResult with_OS_ID(String OS_ID) {
    this.OS_ID = OS_ID;
    return this;
  }
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (!(o instanceof QueryResult)) {
      return false;
    }
    QueryResult that = (QueryResult) o;
    boolean equal = true;
    equal = equal && (this.CLM_ID == null ? that.CLM_ID == null : this.CLM_ID.equals(that.CLM_ID));
    equal = equal && (this.DMPE_ID == null ? that.DMPE_ID == null : this.DMPE_ID.equals(that.DMPE_ID));
    equal = equal && (this.INF_OBM_FIX_SEQ == null ? that.INF_OBM_FIX_SEQ == null : this.INF_OBM_FIX_SEQ.equals(that.INF_OBM_FIX_SEQ));
    equal = equal && (this.HIS_SEQ == null ? that.HIS_SEQ == null : this.HIS_SEQ.equals(that.HIS_SEQ));
    equal = equal && (this.ACD_RCT_ID == null ? that.ACD_RCT_ID == null : this.ACD_RCT_ID.equals(that.ACD_RCT_ID));
    equal = equal && (this.SPFC_DIVD_DIV_CD == null ? that.SPFC_DIVD_DIV_CD == null : this.SPFC_DIVD_DIV_CD.equals(that.SPFC_DIVD_DIV_CD));
    equal = equal && (this.MORL_DIVD_DIV_CD == null ? that.MORL_DIVD_DIV_CD == null : this.MORL_DIVD_DIV_CD.equals(that.MORL_DIVD_DIV_CD));
    equal = equal && (this.SCRG_SCR == null ? that.SCRG_SCR == null : this.SCRG_SCR.equals(that.SCRG_SCR));
    equal = equal && (this.CLUNIT_CD == null ? that.CLUNIT_CD == null : this.CLUNIT_CD.equals(that.CLUNIT_CD));
    equal = equal && (this.DTH_YN == null ? that.DTH_YN == null : this.DTH_YN.equals(that.DTH_YN));
    equal = equal && (this.AFOBS_YN == null ? that.AFOBS_YN == null : this.AFOBS_YN.equals(that.AFOBS_YN));
    equal = equal && (this.PRSM_INS_AMT == null ? that.PRSM_INS_AMT == null : this.PRSM_INS_AMT.equals(that.PRSM_INS_AMT));
    equal = equal && (this.ACCM_DCN_INS_AMT == null ? that.ACCM_DCN_INS_AMT == null : this.ACCM_DCN_INS_AMT.equals(that.ACCM_DCN_INS_AMT));
    equal = equal && (this.MD_EXP_CUS_GRDE_CD == null ? that.MD_EXP_CUS_GRDE_CD == null : this.MD_EXP_CUS_GRDE_CD.equals(that.MD_EXP_CUS_GRDE_CD));
    equal = equal && (this.DDPY_CUS_GRDE_CD == null ? that.DDPY_CUS_GRDE_CD == null : this.DDPY_CUS_GRDE_CD.equals(that.DDPY_CUS_GRDE_CD));
    equal = equal && (this.QUES_HOSP_YN == null ? that.QUES_HOSP_YN == null : this.QUES_HOSP_YN.equals(that.QUES_HOSP_YN));
    equal = equal && (this.OBST_MORL_HOSP_YN == null ? that.OBST_MORL_HOSP_YN == null : this.OBST_MORL_HOSP_YN.equals(that.OBST_MORL_HOSP_YN));
    equal = equal && (this.DDPY_ATTN_HOSP_YN == null ? that.DDPY_ATTN_HOSP_YN == null : this.DDPY_ATTN_HOSP_YN.equals(that.DDPY_ATTN_HOSP_YN));
    equal = equal && (this.NSRY_ATTN_HOSP_YN == null ? that.NSRY_ATTN_HOSP_YN == null : this.NSRY_ATTN_HOSP_YN.equals(that.NSRY_ATTN_HOSP_YN));
    equal = equal && (this.OWN_CTR_YN == null ? that.OWN_CTR_YN == null : this.OWN_CTR_YN.equals(that.OWN_CTR_YN));
    equal = equal && (this.ACD_OCFQ_CUS_YN == null ? that.ACD_OCFQ_CUS_YN == null : this.ACD_OCFQ_CUS_YN.equals(that.ACD_OCFQ_CUS_YN));
    equal = equal && (this.APPR_ACD_DD_DIV_CD == null ? that.APPR_ACD_DD_DIV_CD == null : this.APPR_ACD_DD_DIV_CD.equals(that.APPR_ACD_DD_DIV_CD));
    equal = equal && (this.MORL_KR_DISZ_CD == null ? that.MORL_KR_DISZ_CD == null : this.MORL_KR_DISZ_CD.equals(that.MORL_KR_DISZ_CD));
    equal = equal && (this.DISZ_CD_LST == null ? that.DISZ_CD_LST == null : this.DISZ_CD_LST.equals(that.DISZ_CD_LST));
    equal = equal && (this.SPFC_TRTPE_YN == null ? that.SPFC_TRTPE_YN == null : this.SPFC_TRTPE_YN.equals(that.SPFC_TRTPE_YN));
    equal = equal && (this.HIS_ST_DTM == null ? that.HIS_ST_DTM == null : this.HIS_ST_DTM.equals(that.HIS_ST_DTM));
    equal = equal && (this.HIS_ED_DTM == null ? that.HIS_ED_DTM == null : this.HIS_ED_DTM.equals(that.HIS_ED_DTM));
    equal = equal && (this.INPPE_ORG_ID == null ? that.INPPE_ORG_ID == null : this.INPPE_ORG_ID.equals(that.INPPE_ORG_ID));
    equal = equal && (this.SYS_OCC_DTM == null ? that.SYS_OCC_DTM == null : this.SYS_OCC_DTM.equals(that.SYS_OCC_DTM));
    equal = equal && (this.SYS_DEL_DIV_CD == null ? that.SYS_DEL_DIV_CD == null : this.SYS_DEL_DIV_CD.equals(that.SYS_DEL_DIV_CD));
    equal = equal && (this.OCC_IP == null ? that.OCC_IP == null : this.OCC_IP.equals(that.OCC_IP));
    equal = equal && (this.APP_ID == null ? that.APP_ID == null : this.APP_ID.equals(that.APP_ID));
    equal = equal && (this.DATA_CHNG_DTM == null ? that.DATA_CHNG_DTM == null : this.DATA_CHNG_DTM.equals(that.DATA_CHNG_DTM));
    equal = equal && (this.DGN_FEE1 == null ? that.DGN_FEE1 == null : this.DGN_FEE1.equals(that.DGN_FEE1));
    equal = equal && (this.DGN_FEE2 == null ? that.DGN_FEE2 == null : this.DGN_FEE2.equals(that.DGN_FEE2));
    equal = equal && (this.LAW_VLT_YN == null ? that.LAW_VLT_YN == null : this.LAW_VLT_YN.equals(that.LAW_VLT_YN));
    equal = equal && (this.BAS_SCR == null ? that.BAS_SCR == null : this.BAS_SCR.equals(that.BAS_SCR));
    equal = equal && (this.CHRPE_ORG_ID == null ? that.CHRPE_ORG_ID == null : this.CHRPE_ORG_ID.equals(that.CHRPE_ORG_ID));
    equal = equal && (this.CHRPE_PART_ORG_ID == null ? that.CHRPE_PART_ORG_ID == null : this.CHRPE_PART_ORG_ID.equals(that.CHRPE_PART_ORG_ID));
    equal = equal && (this.CHRPE_TEM_ORG_ID == null ? that.CHRPE_TEM_ORG_ID == null : this.CHRPE_TEM_ORG_ID.equals(that.CHRPE_TEM_ORG_ID));
    equal = equal && (this.MORL_DIVD_DTL_CD == null ? that.MORL_DIVD_DTL_CD == null : this.MORL_DIVD_DTL_CD.equals(that.MORL_DIVD_DTL_CD));
    equal = equal && (this.SPFC_DGN_MORL_YN == null ? that.SPFC_DGN_MORL_YN == null : this.SPFC_DGN_MORL_YN.equals(that.SPFC_DGN_MORL_YN));
    equal = equal && (this.ETC_CON == null ? that.ETC_CON == null : this.ETC_CON.equals(that.ETC_CON));
    equal = equal && (this.EIH_LDG_DTM == null ? that.EIH_LDG_DTM == null : this.EIH_LDG_DTM.equals(that.EIH_LDG_DTM));
    equal = equal && (this.NURPE_SVC_RQE_YN == null ? that.NURPE_SVC_RQE_YN == null : this.NURPE_SVC_RQE_YN.equals(that.NURPE_SVC_RQE_YN));
    equal = equal && (this.RULE_SQ_VAL == null ? that.RULE_SQ_VAL == null : this.RULE_SQ_VAL.equals(that.RULE_SQ_VAL));
    equal = equal && (this.RULE_TRM_RSL_LST_CON20 == null ? that.RULE_TRM_RSL_LST_CON20 == null : this.RULE_TRM_RSL_LST_CON20.equals(that.RULE_TRM_RSL_LST_CON20));
    equal = equal && (this.RULE_TRM_RSL_LST_CON26 == null ? that.RULE_TRM_RSL_LST_CON26 == null : this.RULE_TRM_RSL_LST_CON26.equals(that.RULE_TRM_RSL_LST_CON26));
    equal = equal && (this.RULE_TRM_RSL_LST_CON27 == null ? that.RULE_TRM_RSL_LST_CON27 == null : this.RULE_TRM_RSL_LST_CON27.equals(that.RULE_TRM_RSL_LST_CON27));
    equal = equal && (this.RULE_TRM_RSL_LST_CON28 == null ? that.RULE_TRM_RSL_LST_CON28 == null : this.RULE_TRM_RSL_LST_CON28.equals(that.RULE_TRM_RSL_LST_CON28));
    equal = equal && (this.RULE_TRM_RSL_LST_CON29 == null ? that.RULE_TRM_RSL_LST_CON29 == null : this.RULE_TRM_RSL_LST_CON29.equals(that.RULE_TRM_RSL_LST_CON29));
    equal = equal && (this.RULE_TRM_RSL_LST_CON30 == null ? that.RULE_TRM_RSL_LST_CON30 == null : this.RULE_TRM_RSL_LST_CON30.equals(that.RULE_TRM_RSL_LST_CON30));
    equal = equal && (this.RULE_TRM_RSL_LST_CON32 == null ? that.RULE_TRM_RSL_LST_CON32 == null : this.RULE_TRM_RSL_LST_CON32.equals(that.RULE_TRM_RSL_LST_CON32));
    equal = equal && (this.MDEL_APL_TRG_YN == null ? that.MDEL_APL_TRG_YN == null : this.MDEL_APL_TRG_YN.equals(that.MDEL_APL_TRG_YN));
    equal = equal && (this.APL_BF_FLTR_TRM_VAL == null ? that.APL_BF_FLTR_TRM_VAL == null : this.APL_BF_FLTR_TRM_VAL.equals(that.APL_BF_FLTR_TRM_VAL));
    equal = equal && (this.MDEL_APL_DIV_CD == null ? that.MDEL_APL_DIV_CD == null : this.MDEL_APL_DIV_CD.equals(that.MDEL_APL_DIV_CD));
    equal = equal && (this.MDEL_TRM_APL_RSL_VAL == null ? that.MDEL_TRM_APL_RSL_VAL == null : this.MDEL_TRM_APL_RSL_VAL.equals(that.MDEL_TRM_APL_RSL_VAL));
    equal = equal && (this.MDEL_DIV_CD_STD_VAL == null ? that.MDEL_DIV_CD_STD_VAL == null : this.MDEL_DIV_CD_STD_VAL.equals(that.MDEL_DIV_CD_STD_VAL));
    equal = equal && (this.MDEL_CMPT_RSL_VAL == null ? that.MDEL_CMPT_RSL_VAL == null : this.MDEL_CMPT_RSL_VAL.equals(that.MDEL_CMPT_RSL_VAL));
    equal = equal && (this.CMPT_SQ_CLUNIT_CD == null ? that.CMPT_SQ_CLUNIT_CD == null : this.CMPT_SQ_CLUNIT_CD.equals(that.CMPT_SQ_CLUNIT_CD));
    equal = equal && (this.CMPT_SQ_DIVD_DIV_VAL == null ? that.CMPT_SQ_DIVD_DIV_VAL == null : this.CMPT_SQ_DIVD_DIV_VAL.equals(that.CMPT_SQ_DIVD_DIV_VAL));
    equal = equal && (this.OS_ID == null ? that.OS_ID == null : this.OS_ID.equals(that.OS_ID));
    return equal;
  }
  public boolean equals0(Object o) {
    if (this == o) {
      return true;
    }
    if (!(o instanceof QueryResult)) {
      return false;
    }
    QueryResult that = (QueryResult) o;
    boolean equal = true;
    equal = equal && (this.CLM_ID == null ? that.CLM_ID == null : this.CLM_ID.equals(that.CLM_ID));
    equal = equal && (this.DMPE_ID == null ? that.DMPE_ID == null : this.DMPE_ID.equals(that.DMPE_ID));
    equal = equal && (this.INF_OBM_FIX_SEQ == null ? that.INF_OBM_FIX_SEQ == null : this.INF_OBM_FIX_SEQ.equals(that.INF_OBM_FIX_SEQ));
    equal = equal && (this.HIS_SEQ == null ? that.HIS_SEQ == null : this.HIS_SEQ.equals(that.HIS_SEQ));
    equal = equal && (this.ACD_RCT_ID == null ? that.ACD_RCT_ID == null : this.ACD_RCT_ID.equals(that.ACD_RCT_ID));
    equal = equal && (this.SPFC_DIVD_DIV_CD == null ? that.SPFC_DIVD_DIV_CD == null : this.SPFC_DIVD_DIV_CD.equals(that.SPFC_DIVD_DIV_CD));
    equal = equal && (this.MORL_DIVD_DIV_CD == null ? that.MORL_DIVD_DIV_CD == null : this.MORL_DIVD_DIV_CD.equals(that.MORL_DIVD_DIV_CD));
    equal = equal && (this.SCRG_SCR == null ? that.SCRG_SCR == null : this.SCRG_SCR.equals(that.SCRG_SCR));
    equal = equal && (this.CLUNIT_CD == null ? that.CLUNIT_CD == null : this.CLUNIT_CD.equals(that.CLUNIT_CD));
    equal = equal && (this.DTH_YN == null ? that.DTH_YN == null : this.DTH_YN.equals(that.DTH_YN));
    equal = equal && (this.AFOBS_YN == null ? that.AFOBS_YN == null : this.AFOBS_YN.equals(that.AFOBS_YN));
    equal = equal && (this.PRSM_INS_AMT == null ? that.PRSM_INS_AMT == null : this.PRSM_INS_AMT.equals(that.PRSM_INS_AMT));
    equal = equal && (this.ACCM_DCN_INS_AMT == null ? that.ACCM_DCN_INS_AMT == null : this.ACCM_DCN_INS_AMT.equals(that.ACCM_DCN_INS_AMT));
    equal = equal && (this.MD_EXP_CUS_GRDE_CD == null ? that.MD_EXP_CUS_GRDE_CD == null : this.MD_EXP_CUS_GRDE_CD.equals(that.MD_EXP_CUS_GRDE_CD));
    equal = equal && (this.DDPY_CUS_GRDE_CD == null ? that.DDPY_CUS_GRDE_CD == null : this.DDPY_CUS_GRDE_CD.equals(that.DDPY_CUS_GRDE_CD));
    equal = equal && (this.QUES_HOSP_YN == null ? that.QUES_HOSP_YN == null : this.QUES_HOSP_YN.equals(that.QUES_HOSP_YN));
    equal = equal && (this.OBST_MORL_HOSP_YN == null ? that.OBST_MORL_HOSP_YN == null : this.OBST_MORL_HOSP_YN.equals(that.OBST_MORL_HOSP_YN));
    equal = equal && (this.DDPY_ATTN_HOSP_YN == null ? that.DDPY_ATTN_HOSP_YN == null : this.DDPY_ATTN_HOSP_YN.equals(that.DDPY_ATTN_HOSP_YN));
    equal = equal && (this.NSRY_ATTN_HOSP_YN == null ? that.NSRY_ATTN_HOSP_YN == null : this.NSRY_ATTN_HOSP_YN.equals(that.NSRY_ATTN_HOSP_YN));
    equal = equal && (this.OWN_CTR_YN == null ? that.OWN_CTR_YN == null : this.OWN_CTR_YN.equals(that.OWN_CTR_YN));
    equal = equal && (this.ACD_OCFQ_CUS_YN == null ? that.ACD_OCFQ_CUS_YN == null : this.ACD_OCFQ_CUS_YN.equals(that.ACD_OCFQ_CUS_YN));
    equal = equal && (this.APPR_ACD_DD_DIV_CD == null ? that.APPR_ACD_DD_DIV_CD == null : this.APPR_ACD_DD_DIV_CD.equals(that.APPR_ACD_DD_DIV_CD));
    equal = equal && (this.MORL_KR_DISZ_CD == null ? that.MORL_KR_DISZ_CD == null : this.MORL_KR_DISZ_CD.equals(that.MORL_KR_DISZ_CD));
    equal = equal && (this.DISZ_CD_LST == null ? that.DISZ_CD_LST == null : this.DISZ_CD_LST.equals(that.DISZ_CD_LST));
    equal = equal && (this.SPFC_TRTPE_YN == null ? that.SPFC_TRTPE_YN == null : this.SPFC_TRTPE_YN.equals(that.SPFC_TRTPE_YN));
    equal = equal && (this.HIS_ST_DTM == null ? that.HIS_ST_DTM == null : this.HIS_ST_DTM.equals(that.HIS_ST_DTM));
    equal = equal && (this.HIS_ED_DTM == null ? that.HIS_ED_DTM == null : this.HIS_ED_DTM.equals(that.HIS_ED_DTM));
    equal = equal && (this.INPPE_ORG_ID == null ? that.INPPE_ORG_ID == null : this.INPPE_ORG_ID.equals(that.INPPE_ORG_ID));
    equal = equal && (this.SYS_OCC_DTM == null ? that.SYS_OCC_DTM == null : this.SYS_OCC_DTM.equals(that.SYS_OCC_DTM));
    equal = equal && (this.SYS_DEL_DIV_CD == null ? that.SYS_DEL_DIV_CD == null : this.SYS_DEL_DIV_CD.equals(that.SYS_DEL_DIV_CD));
    equal = equal && (this.OCC_IP == null ? that.OCC_IP == null : this.OCC_IP.equals(that.OCC_IP));
    equal = equal && (this.APP_ID == null ? that.APP_ID == null : this.APP_ID.equals(that.APP_ID));
    equal = equal && (this.DATA_CHNG_DTM == null ? that.DATA_CHNG_DTM == null : this.DATA_CHNG_DTM.equals(that.DATA_CHNG_DTM));
    equal = equal && (this.DGN_FEE1 == null ? that.DGN_FEE1 == null : this.DGN_FEE1.equals(that.DGN_FEE1));
    equal = equal && (this.DGN_FEE2 == null ? that.DGN_FEE2 == null : this.DGN_FEE2.equals(that.DGN_FEE2));
    equal = equal && (this.LAW_VLT_YN == null ? that.LAW_VLT_YN == null : this.LAW_VLT_YN.equals(that.LAW_VLT_YN));
    equal = equal && (this.BAS_SCR == null ? that.BAS_SCR == null : this.BAS_SCR.equals(that.BAS_SCR));
    equal = equal && (this.CHRPE_ORG_ID == null ? that.CHRPE_ORG_ID == null : this.CHRPE_ORG_ID.equals(that.CHRPE_ORG_ID));
    equal = equal && (this.CHRPE_PART_ORG_ID == null ? that.CHRPE_PART_ORG_ID == null : this.CHRPE_PART_ORG_ID.equals(that.CHRPE_PART_ORG_ID));
    equal = equal && (this.CHRPE_TEM_ORG_ID == null ? that.CHRPE_TEM_ORG_ID == null : this.CHRPE_TEM_ORG_ID.equals(that.CHRPE_TEM_ORG_ID));
    equal = equal && (this.MORL_DIVD_DTL_CD == null ? that.MORL_DIVD_DTL_CD == null : this.MORL_DIVD_DTL_CD.equals(that.MORL_DIVD_DTL_CD));
    equal = equal && (this.SPFC_DGN_MORL_YN == null ? that.SPFC_DGN_MORL_YN == null : this.SPFC_DGN_MORL_YN.equals(that.SPFC_DGN_MORL_YN));
    equal = equal && (this.ETC_CON == null ? that.ETC_CON == null : this.ETC_CON.equals(that.ETC_CON));
    equal = equal && (this.EIH_LDG_DTM == null ? that.EIH_LDG_DTM == null : this.EIH_LDG_DTM.equals(that.EIH_LDG_DTM));
    equal = equal && (this.NURPE_SVC_RQE_YN == null ? that.NURPE_SVC_RQE_YN == null : this.NURPE_SVC_RQE_YN.equals(that.NURPE_SVC_RQE_YN));
    equal = equal && (this.RULE_SQ_VAL == null ? that.RULE_SQ_VAL == null : this.RULE_SQ_VAL.equals(that.RULE_SQ_VAL));
    equal = equal && (this.RULE_TRM_RSL_LST_CON20 == null ? that.RULE_TRM_RSL_LST_CON20 == null : this.RULE_TRM_RSL_LST_CON20.equals(that.RULE_TRM_RSL_LST_CON20));
    equal = equal && (this.RULE_TRM_RSL_LST_CON26 == null ? that.RULE_TRM_RSL_LST_CON26 == null : this.RULE_TRM_RSL_LST_CON26.equals(that.RULE_TRM_RSL_LST_CON26));
    equal = equal && (this.RULE_TRM_RSL_LST_CON27 == null ? that.RULE_TRM_RSL_LST_CON27 == null : this.RULE_TRM_RSL_LST_CON27.equals(that.RULE_TRM_RSL_LST_CON27));
    equal = equal && (this.RULE_TRM_RSL_LST_CON28 == null ? that.RULE_TRM_RSL_LST_CON28 == null : this.RULE_TRM_RSL_LST_CON28.equals(that.RULE_TRM_RSL_LST_CON28));
    equal = equal && (this.RULE_TRM_RSL_LST_CON29 == null ? that.RULE_TRM_RSL_LST_CON29 == null : this.RULE_TRM_RSL_LST_CON29.equals(that.RULE_TRM_RSL_LST_CON29));
    equal = equal && (this.RULE_TRM_RSL_LST_CON30 == null ? that.RULE_TRM_RSL_LST_CON30 == null : this.RULE_TRM_RSL_LST_CON30.equals(that.RULE_TRM_RSL_LST_CON30));
    equal = equal && (this.RULE_TRM_RSL_LST_CON32 == null ? that.RULE_TRM_RSL_LST_CON32 == null : this.RULE_TRM_RSL_LST_CON32.equals(that.RULE_TRM_RSL_LST_CON32));
    equal = equal && (this.MDEL_APL_TRG_YN == null ? that.MDEL_APL_TRG_YN == null : this.MDEL_APL_TRG_YN.equals(that.MDEL_APL_TRG_YN));
    equal = equal && (this.APL_BF_FLTR_TRM_VAL == null ? that.APL_BF_FLTR_TRM_VAL == null : this.APL_BF_FLTR_TRM_VAL.equals(that.APL_BF_FLTR_TRM_VAL));
    equal = equal && (this.MDEL_APL_DIV_CD == null ? that.MDEL_APL_DIV_CD == null : this.MDEL_APL_DIV_CD.equals(that.MDEL_APL_DIV_CD));
    equal = equal && (this.MDEL_TRM_APL_RSL_VAL == null ? that.MDEL_TRM_APL_RSL_VAL == null : this.MDEL_TRM_APL_RSL_VAL.equals(that.MDEL_TRM_APL_RSL_VAL));
    equal = equal && (this.MDEL_DIV_CD_STD_VAL == null ? that.MDEL_DIV_CD_STD_VAL == null : this.MDEL_DIV_CD_STD_VAL.equals(that.MDEL_DIV_CD_STD_VAL));
    equal = equal && (this.MDEL_CMPT_RSL_VAL == null ? that.MDEL_CMPT_RSL_VAL == null : this.MDEL_CMPT_RSL_VAL.equals(that.MDEL_CMPT_RSL_VAL));
    equal = equal && (this.CMPT_SQ_CLUNIT_CD == null ? that.CMPT_SQ_CLUNIT_CD == null : this.CMPT_SQ_CLUNIT_CD.equals(that.CMPT_SQ_CLUNIT_CD));
    equal = equal && (this.CMPT_SQ_DIVD_DIV_VAL == null ? that.CMPT_SQ_DIVD_DIV_VAL == null : this.CMPT_SQ_DIVD_DIV_VAL.equals(that.CMPT_SQ_DIVD_DIV_VAL));
    equal = equal && (this.OS_ID == null ? that.OS_ID == null : this.OS_ID.equals(that.OS_ID));
    return equal;
  }
  public void readFields(ResultSet __dbResults) throws SQLException {
    this.__cur_result_set = __dbResults;
    this.CLM_ID = JdbcWritableBridge.readString(1, __dbResults);
    this.DMPE_ID = JdbcWritableBridge.readString(2, __dbResults);
    this.INF_OBM_FIX_SEQ = JdbcWritableBridge.readBigDecimal(3, __dbResults);
    this.HIS_SEQ = JdbcWritableBridge.readBigDecimal(4, __dbResults);
    this.ACD_RCT_ID = JdbcWritableBridge.readString(5, __dbResults);
    this.SPFC_DIVD_DIV_CD = JdbcWritableBridge.readString(6, __dbResults);
    this.MORL_DIVD_DIV_CD = JdbcWritableBridge.readString(7, __dbResults);
    this.SCRG_SCR = JdbcWritableBridge.readBigDecimal(8, __dbResults);
    this.CLUNIT_CD = JdbcWritableBridge.readString(9, __dbResults);
    this.DTH_YN = JdbcWritableBridge.readString(10, __dbResults);
    this.AFOBS_YN = JdbcWritableBridge.readString(11, __dbResults);
    this.PRSM_INS_AMT = JdbcWritableBridge.readBigDecimal(12, __dbResults);
    this.ACCM_DCN_INS_AMT = JdbcWritableBridge.readBigDecimal(13, __dbResults);
    this.MD_EXP_CUS_GRDE_CD = JdbcWritableBridge.readString(14, __dbResults);
    this.DDPY_CUS_GRDE_CD = JdbcWritableBridge.readString(15, __dbResults);
    this.QUES_HOSP_YN = JdbcWritableBridge.readString(16, __dbResults);
    this.OBST_MORL_HOSP_YN = JdbcWritableBridge.readString(17, __dbResults);
    this.DDPY_ATTN_HOSP_YN = JdbcWritableBridge.readString(18, __dbResults);
    this.NSRY_ATTN_HOSP_YN = JdbcWritableBridge.readString(19, __dbResults);
    this.OWN_CTR_YN = JdbcWritableBridge.readString(20, __dbResults);
    this.ACD_OCFQ_CUS_YN = JdbcWritableBridge.readString(21, __dbResults);
    this.APPR_ACD_DD_DIV_CD = JdbcWritableBridge.readString(22, __dbResults);
    this.MORL_KR_DISZ_CD = JdbcWritableBridge.readString(23, __dbResults);
    this.DISZ_CD_LST = JdbcWritableBridge.readString(24, __dbResults);
    this.SPFC_TRTPE_YN = JdbcWritableBridge.readString(25, __dbResults);
    this.HIS_ST_DTM = JdbcWritableBridge.readTimestamp(26, __dbResults);
    this.HIS_ED_DTM = JdbcWritableBridge.readTimestamp(27, __dbResults);
    this.INPPE_ORG_ID = JdbcWritableBridge.readString(28, __dbResults);
    this.SYS_OCC_DTM = JdbcWritableBridge.readTimestamp(29, __dbResults);
    this.SYS_DEL_DIV_CD = JdbcWritableBridge.readString(30, __dbResults);
    this.OCC_IP = JdbcWritableBridge.readString(31, __dbResults);
    this.APP_ID = JdbcWritableBridge.readString(32, __dbResults);
    this.DATA_CHNG_DTM = JdbcWritableBridge.readTimestamp(33, __dbResults);
    this.DGN_FEE1 = JdbcWritableBridge.readBigDecimal(34, __dbResults);
    this.DGN_FEE2 = JdbcWritableBridge.readBigDecimal(35, __dbResults);
    this.LAW_VLT_YN = JdbcWritableBridge.readString(36, __dbResults);
    this.BAS_SCR = JdbcWritableBridge.readBigDecimal(37, __dbResults);
    this.CHRPE_ORG_ID = JdbcWritableBridge.readString(38, __dbResults);
    this.CHRPE_PART_ORG_ID = JdbcWritableBridge.readString(39, __dbResults);
    this.CHRPE_TEM_ORG_ID = JdbcWritableBridge.readString(40, __dbResults);
    this.MORL_DIVD_DTL_CD = JdbcWritableBridge.readString(41, __dbResults);
    this.SPFC_DGN_MORL_YN = JdbcWritableBridge.readString(42, __dbResults);
    this.ETC_CON = JdbcWritableBridge.readString(43, __dbResults);
    this.EIH_LDG_DTM = JdbcWritableBridge.readTimestamp(44, __dbResults);
    this.NURPE_SVC_RQE_YN = JdbcWritableBridge.readString(45, __dbResults);
    this.RULE_SQ_VAL = JdbcWritableBridge.readString(46, __dbResults);
    this.RULE_TRM_RSL_LST_CON20 = JdbcWritableBridge.readClobRef(47, __dbResults);
    this.RULE_TRM_RSL_LST_CON26 = JdbcWritableBridge.readClobRef(48, __dbResults);
    this.RULE_TRM_RSL_LST_CON27 = JdbcWritableBridge.readClobRef(49, __dbResults);
    this.RULE_TRM_RSL_LST_CON28 = JdbcWritableBridge.readClobRef(50, __dbResults);
    this.RULE_TRM_RSL_LST_CON29 = JdbcWritableBridge.readClobRef(51, __dbResults);
    this.RULE_TRM_RSL_LST_CON30 = JdbcWritableBridge.readClobRef(52, __dbResults);
    this.RULE_TRM_RSL_LST_CON32 = JdbcWritableBridge.readClobRef(53, __dbResults);
    this.MDEL_APL_TRG_YN = JdbcWritableBridge.readString(54, __dbResults);
    this.APL_BF_FLTR_TRM_VAL = JdbcWritableBridge.readString(55, __dbResults);
    this.MDEL_APL_DIV_CD = JdbcWritableBridge.readString(56, __dbResults);
    this.MDEL_TRM_APL_RSL_VAL = JdbcWritableBridge.readClobRef(57, __dbResults);
    this.MDEL_DIV_CD_STD_VAL = JdbcWritableBridge.readString(58, __dbResults);
    this.MDEL_CMPT_RSL_VAL = JdbcWritableBridge.readString(59, __dbResults);
    this.CMPT_SQ_CLUNIT_CD = JdbcWritableBridge.readString(60, __dbResults);
    this.CMPT_SQ_DIVD_DIV_VAL = JdbcWritableBridge.readString(61, __dbResults);
    this.OS_ID = JdbcWritableBridge.readString(62, __dbResults);
  }
  public void readFields0(ResultSet __dbResults) throws SQLException {
    this.CLM_ID = JdbcWritableBridge.readString(1, __dbResults);
    this.DMPE_ID = JdbcWritableBridge.readString(2, __dbResults);
    this.INF_OBM_FIX_SEQ = JdbcWritableBridge.readBigDecimal(3, __dbResults);
    this.HIS_SEQ = JdbcWritableBridge.readBigDecimal(4, __dbResults);
    this.ACD_RCT_ID = JdbcWritableBridge.readString(5, __dbResults);
    this.SPFC_DIVD_DIV_CD = JdbcWritableBridge.readString(6, __dbResults);
    this.MORL_DIVD_DIV_CD = JdbcWritableBridge.readString(7, __dbResults);
    this.SCRG_SCR = JdbcWritableBridge.readBigDecimal(8, __dbResults);
    this.CLUNIT_CD = JdbcWritableBridge.readString(9, __dbResults);
    this.DTH_YN = JdbcWritableBridge.readString(10, __dbResults);
    this.AFOBS_YN = JdbcWritableBridge.readString(11, __dbResults);
    this.PRSM_INS_AMT = JdbcWritableBridge.readBigDecimal(12, __dbResults);
    this.ACCM_DCN_INS_AMT = JdbcWritableBridge.readBigDecimal(13, __dbResults);
    this.MD_EXP_CUS_GRDE_CD = JdbcWritableBridge.readString(14, __dbResults);
    this.DDPY_CUS_GRDE_CD = JdbcWritableBridge.readString(15, __dbResults);
    this.QUES_HOSP_YN = JdbcWritableBridge.readString(16, __dbResults);
    this.OBST_MORL_HOSP_YN = JdbcWritableBridge.readString(17, __dbResults);
    this.DDPY_ATTN_HOSP_YN = JdbcWritableBridge.readString(18, __dbResults);
    this.NSRY_ATTN_HOSP_YN = JdbcWritableBridge.readString(19, __dbResults);
    this.OWN_CTR_YN = JdbcWritableBridge.readString(20, __dbResults);
    this.ACD_OCFQ_CUS_YN = JdbcWritableBridge.readString(21, __dbResults);
    this.APPR_ACD_DD_DIV_CD = JdbcWritableBridge.readString(22, __dbResults);
    this.MORL_KR_DISZ_CD = JdbcWritableBridge.readString(23, __dbResults);
    this.DISZ_CD_LST = JdbcWritableBridge.readString(24, __dbResults);
    this.SPFC_TRTPE_YN = JdbcWritableBridge.readString(25, __dbResults);
    this.HIS_ST_DTM = JdbcWritableBridge.readTimestamp(26, __dbResults);
    this.HIS_ED_DTM = JdbcWritableBridge.readTimestamp(27, __dbResults);
    this.INPPE_ORG_ID = JdbcWritableBridge.readString(28, __dbResults);
    this.SYS_OCC_DTM = JdbcWritableBridge.readTimestamp(29, __dbResults);
    this.SYS_DEL_DIV_CD = JdbcWritableBridge.readString(30, __dbResults);
    this.OCC_IP = JdbcWritableBridge.readString(31, __dbResults);
    this.APP_ID = JdbcWritableBridge.readString(32, __dbResults);
    this.DATA_CHNG_DTM = JdbcWritableBridge.readTimestamp(33, __dbResults);
    this.DGN_FEE1 = JdbcWritableBridge.readBigDecimal(34, __dbResults);
    this.DGN_FEE2 = JdbcWritableBridge.readBigDecimal(35, __dbResults);
    this.LAW_VLT_YN = JdbcWritableBridge.readString(36, __dbResults);
    this.BAS_SCR = JdbcWritableBridge.readBigDecimal(37, __dbResults);
    this.CHRPE_ORG_ID = JdbcWritableBridge.readString(38, __dbResults);
    this.CHRPE_PART_ORG_ID = JdbcWritableBridge.readString(39, __dbResults);
    this.CHRPE_TEM_ORG_ID = JdbcWritableBridge.readString(40, __dbResults);
    this.MORL_DIVD_DTL_CD = JdbcWritableBridge.readString(41, __dbResults);
    this.SPFC_DGN_MORL_YN = JdbcWritableBridge.readString(42, __dbResults);
    this.ETC_CON = JdbcWritableBridge.readString(43, __dbResults);
    this.EIH_LDG_DTM = JdbcWritableBridge.readTimestamp(44, __dbResults);
    this.NURPE_SVC_RQE_YN = JdbcWritableBridge.readString(45, __dbResults);
    this.RULE_SQ_VAL = JdbcWritableBridge.readString(46, __dbResults);
    this.RULE_TRM_RSL_LST_CON20 = JdbcWritableBridge.readClobRef(47, __dbResults);
    this.RULE_TRM_RSL_LST_CON26 = JdbcWritableBridge.readClobRef(48, __dbResults);
    this.RULE_TRM_RSL_LST_CON27 = JdbcWritableBridge.readClobRef(49, __dbResults);
    this.RULE_TRM_RSL_LST_CON28 = JdbcWritableBridge.readClobRef(50, __dbResults);
    this.RULE_TRM_RSL_LST_CON29 = JdbcWritableBridge.readClobRef(51, __dbResults);
    this.RULE_TRM_RSL_LST_CON30 = JdbcWritableBridge.readClobRef(52, __dbResults);
    this.RULE_TRM_RSL_LST_CON32 = JdbcWritableBridge.readClobRef(53, __dbResults);
    this.MDEL_APL_TRG_YN = JdbcWritableBridge.readString(54, __dbResults);
    this.APL_BF_FLTR_TRM_VAL = JdbcWritableBridge.readString(55, __dbResults);
    this.MDEL_APL_DIV_CD = JdbcWritableBridge.readString(56, __dbResults);
    this.MDEL_TRM_APL_RSL_VAL = JdbcWritableBridge.readClobRef(57, __dbResults);
    this.MDEL_DIV_CD_STD_VAL = JdbcWritableBridge.readString(58, __dbResults);
    this.MDEL_CMPT_RSL_VAL = JdbcWritableBridge.readString(59, __dbResults);
    this.CMPT_SQ_CLUNIT_CD = JdbcWritableBridge.readString(60, __dbResults);
    this.CMPT_SQ_DIVD_DIV_VAL = JdbcWritableBridge.readString(61, __dbResults);
    this.OS_ID = JdbcWritableBridge.readString(62, __dbResults);
  }
  public void loadLargeObjects(LargeObjectLoader __loader)
      throws SQLException, IOException, InterruptedException {
    this.RULE_TRM_RSL_LST_CON20 = __loader.readClobRef(47, this.__cur_result_set);
    this.RULE_TRM_RSL_LST_CON26 = __loader.readClobRef(48, this.__cur_result_set);
    this.RULE_TRM_RSL_LST_CON27 = __loader.readClobRef(49, this.__cur_result_set);
    this.RULE_TRM_RSL_LST_CON28 = __loader.readClobRef(50, this.__cur_result_set);
    this.RULE_TRM_RSL_LST_CON29 = __loader.readClobRef(51, this.__cur_result_set);
    this.RULE_TRM_RSL_LST_CON30 = __loader.readClobRef(52, this.__cur_result_set);
    this.RULE_TRM_RSL_LST_CON32 = __loader.readClobRef(53, this.__cur_result_set);
    this.MDEL_TRM_APL_RSL_VAL = __loader.readClobRef(57, this.__cur_result_set);
  }
  public void loadLargeObjects0(LargeObjectLoader __loader)
      throws SQLException, IOException, InterruptedException {
    this.RULE_TRM_RSL_LST_CON20 = __loader.readClobRef(47, this.__cur_result_set);
    this.RULE_TRM_RSL_LST_CON26 = __loader.readClobRef(48, this.__cur_result_set);
    this.RULE_TRM_RSL_LST_CON27 = __loader.readClobRef(49, this.__cur_result_set);
    this.RULE_TRM_RSL_LST_CON28 = __loader.readClobRef(50, this.__cur_result_set);
    this.RULE_TRM_RSL_LST_CON29 = __loader.readClobRef(51, this.__cur_result_set);
    this.RULE_TRM_RSL_LST_CON30 = __loader.readClobRef(52, this.__cur_result_set);
    this.RULE_TRM_RSL_LST_CON32 = __loader.readClobRef(53, this.__cur_result_set);
    this.MDEL_TRM_APL_RSL_VAL = __loader.readClobRef(57, this.__cur_result_set);
  }
  public void write(PreparedStatement __dbStmt) throws SQLException {
    write(__dbStmt, 0);
  }

  public int write(PreparedStatement __dbStmt, int __off) throws SQLException {
    JdbcWritableBridge.writeString(CLM_ID, 1 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(DMPE_ID, 2 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(INF_OBM_FIX_SEQ, 3 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(HIS_SEQ, 4 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(ACD_RCT_ID, 5 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(SPFC_DIVD_DIV_CD, 6 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(MORL_DIVD_DIV_CD, 7 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(SCRG_SCR, 8 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(CLUNIT_CD, 9 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(DTH_YN, 10 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(AFOBS_YN, 11 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(PRSM_INS_AMT, 12 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(ACCM_DCN_INS_AMT, 13 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(MD_EXP_CUS_GRDE_CD, 14 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(DDPY_CUS_GRDE_CD, 15 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(QUES_HOSP_YN, 16 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(OBST_MORL_HOSP_YN, 17 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(DDPY_ATTN_HOSP_YN, 18 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(NSRY_ATTN_HOSP_YN, 19 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(OWN_CTR_YN, 20 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(ACD_OCFQ_CUS_YN, 21 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(APPR_ACD_DD_DIV_CD, 22 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(MORL_KR_DISZ_CD, 23 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(DISZ_CD_LST, 24 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(SPFC_TRTPE_YN, 25 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeTimestamp(HIS_ST_DTM, 26 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeTimestamp(HIS_ED_DTM, 27 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeString(INPPE_ORG_ID, 28 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeTimestamp(SYS_OCC_DTM, 29 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeString(SYS_DEL_DIV_CD, 30 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(OCC_IP, 31 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(APP_ID, 32 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeTimestamp(DATA_CHNG_DTM, 33 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(DGN_FEE1, 34 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(DGN_FEE2, 35 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(LAW_VLT_YN, 36 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(BAS_SCR, 37 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(CHRPE_ORG_ID, 38 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(CHRPE_PART_ORG_ID, 39 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(CHRPE_TEM_ORG_ID, 40 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(MORL_DIVD_DTL_CD, 41 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(SPFC_DGN_MORL_YN, 42 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(ETC_CON, 43 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeTimestamp(EIH_LDG_DTM, 44 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeString(NURPE_SVC_RQE_YN, 45 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(RULE_SQ_VAL, 46 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeClobRef(RULE_TRM_RSL_LST_CON20, 47 + __off, 2005, __dbStmt);
    JdbcWritableBridge.writeClobRef(RULE_TRM_RSL_LST_CON26, 48 + __off, 2005, __dbStmt);
    JdbcWritableBridge.writeClobRef(RULE_TRM_RSL_LST_CON27, 49 + __off, 2005, __dbStmt);
    JdbcWritableBridge.writeClobRef(RULE_TRM_RSL_LST_CON28, 50 + __off, 2005, __dbStmt);
    JdbcWritableBridge.writeClobRef(RULE_TRM_RSL_LST_CON29, 51 + __off, 2005, __dbStmt);
    JdbcWritableBridge.writeClobRef(RULE_TRM_RSL_LST_CON30, 52 + __off, 2005, __dbStmt);
    JdbcWritableBridge.writeClobRef(RULE_TRM_RSL_LST_CON32, 53 + __off, 2005, __dbStmt);
    JdbcWritableBridge.writeString(MDEL_APL_TRG_YN, 54 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(APL_BF_FLTR_TRM_VAL, 55 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(MDEL_APL_DIV_CD, 56 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeClobRef(MDEL_TRM_APL_RSL_VAL, 57 + __off, 2005, __dbStmt);
    JdbcWritableBridge.writeString(MDEL_DIV_CD_STD_VAL, 58 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(MDEL_CMPT_RSL_VAL, 59 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(CMPT_SQ_CLUNIT_CD, 60 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(CMPT_SQ_DIVD_DIV_VAL, 61 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(OS_ID, 62 + __off, 12, __dbStmt);
    return 62;
  }
  public void write0(PreparedStatement __dbStmt, int __off) throws SQLException {
    JdbcWritableBridge.writeString(CLM_ID, 1 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(DMPE_ID, 2 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(INF_OBM_FIX_SEQ, 3 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(HIS_SEQ, 4 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(ACD_RCT_ID, 5 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(SPFC_DIVD_DIV_CD, 6 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(MORL_DIVD_DIV_CD, 7 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(SCRG_SCR, 8 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(CLUNIT_CD, 9 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(DTH_YN, 10 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(AFOBS_YN, 11 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(PRSM_INS_AMT, 12 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(ACCM_DCN_INS_AMT, 13 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(MD_EXP_CUS_GRDE_CD, 14 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(DDPY_CUS_GRDE_CD, 15 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(QUES_HOSP_YN, 16 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(OBST_MORL_HOSP_YN, 17 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(DDPY_ATTN_HOSP_YN, 18 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(NSRY_ATTN_HOSP_YN, 19 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(OWN_CTR_YN, 20 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(ACD_OCFQ_CUS_YN, 21 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(APPR_ACD_DD_DIV_CD, 22 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(MORL_KR_DISZ_CD, 23 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(DISZ_CD_LST, 24 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(SPFC_TRTPE_YN, 25 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeTimestamp(HIS_ST_DTM, 26 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeTimestamp(HIS_ED_DTM, 27 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeString(INPPE_ORG_ID, 28 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeTimestamp(SYS_OCC_DTM, 29 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeString(SYS_DEL_DIV_CD, 30 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(OCC_IP, 31 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(APP_ID, 32 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeTimestamp(DATA_CHNG_DTM, 33 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(DGN_FEE1, 34 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(DGN_FEE2, 35 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(LAW_VLT_YN, 36 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(BAS_SCR, 37 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(CHRPE_ORG_ID, 38 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(CHRPE_PART_ORG_ID, 39 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(CHRPE_TEM_ORG_ID, 40 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(MORL_DIVD_DTL_CD, 41 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(SPFC_DGN_MORL_YN, 42 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(ETC_CON, 43 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeTimestamp(EIH_LDG_DTM, 44 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeString(NURPE_SVC_RQE_YN, 45 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(RULE_SQ_VAL, 46 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeClobRef(RULE_TRM_RSL_LST_CON20, 47 + __off, 2005, __dbStmt);
    JdbcWritableBridge.writeClobRef(RULE_TRM_RSL_LST_CON26, 48 + __off, 2005, __dbStmt);
    JdbcWritableBridge.writeClobRef(RULE_TRM_RSL_LST_CON27, 49 + __off, 2005, __dbStmt);
    JdbcWritableBridge.writeClobRef(RULE_TRM_RSL_LST_CON28, 50 + __off, 2005, __dbStmt);
    JdbcWritableBridge.writeClobRef(RULE_TRM_RSL_LST_CON29, 51 + __off, 2005, __dbStmt);
    JdbcWritableBridge.writeClobRef(RULE_TRM_RSL_LST_CON30, 52 + __off, 2005, __dbStmt);
    JdbcWritableBridge.writeClobRef(RULE_TRM_RSL_LST_CON32, 53 + __off, 2005, __dbStmt);
    JdbcWritableBridge.writeString(MDEL_APL_TRG_YN, 54 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(APL_BF_FLTR_TRM_VAL, 55 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(MDEL_APL_DIV_CD, 56 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeClobRef(MDEL_TRM_APL_RSL_VAL, 57 + __off, 2005, __dbStmt);
    JdbcWritableBridge.writeString(MDEL_DIV_CD_STD_VAL, 58 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(MDEL_CMPT_RSL_VAL, 59 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(CMPT_SQ_CLUNIT_CD, 60 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(CMPT_SQ_DIVD_DIV_VAL, 61 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(OS_ID, 62 + __off, 12, __dbStmt);
  }
  public void readFields(DataInput __dataIn) throws IOException {
this.readFields0(__dataIn);  }
  public void readFields0(DataInput __dataIn) throws IOException {
    if (__dataIn.readBoolean()) { 
        this.CLM_ID = null;
    } else {
    this.CLM_ID = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.DMPE_ID = null;
    } else {
    this.DMPE_ID = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.INF_OBM_FIX_SEQ = null;
    } else {
    this.INF_OBM_FIX_SEQ = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.HIS_SEQ = null;
    } else {
    this.HIS_SEQ = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.ACD_RCT_ID = null;
    } else {
    this.ACD_RCT_ID = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.SPFC_DIVD_DIV_CD = null;
    } else {
    this.SPFC_DIVD_DIV_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.MORL_DIVD_DIV_CD = null;
    } else {
    this.MORL_DIVD_DIV_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.SCRG_SCR = null;
    } else {
    this.SCRG_SCR = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.CLUNIT_CD = null;
    } else {
    this.CLUNIT_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.DTH_YN = null;
    } else {
    this.DTH_YN = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.AFOBS_YN = null;
    } else {
    this.AFOBS_YN = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.PRSM_INS_AMT = null;
    } else {
    this.PRSM_INS_AMT = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.ACCM_DCN_INS_AMT = null;
    } else {
    this.ACCM_DCN_INS_AMT = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.MD_EXP_CUS_GRDE_CD = null;
    } else {
    this.MD_EXP_CUS_GRDE_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.DDPY_CUS_GRDE_CD = null;
    } else {
    this.DDPY_CUS_GRDE_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.QUES_HOSP_YN = null;
    } else {
    this.QUES_HOSP_YN = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.OBST_MORL_HOSP_YN = null;
    } else {
    this.OBST_MORL_HOSP_YN = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.DDPY_ATTN_HOSP_YN = null;
    } else {
    this.DDPY_ATTN_HOSP_YN = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.NSRY_ATTN_HOSP_YN = null;
    } else {
    this.NSRY_ATTN_HOSP_YN = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.OWN_CTR_YN = null;
    } else {
    this.OWN_CTR_YN = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.ACD_OCFQ_CUS_YN = null;
    } else {
    this.ACD_OCFQ_CUS_YN = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.APPR_ACD_DD_DIV_CD = null;
    } else {
    this.APPR_ACD_DD_DIV_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.MORL_KR_DISZ_CD = null;
    } else {
    this.MORL_KR_DISZ_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.DISZ_CD_LST = null;
    } else {
    this.DISZ_CD_LST = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.SPFC_TRTPE_YN = null;
    } else {
    this.SPFC_TRTPE_YN = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.HIS_ST_DTM = null;
    } else {
    this.HIS_ST_DTM = new Timestamp(__dataIn.readLong());
    this.HIS_ST_DTM.setNanos(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.HIS_ED_DTM = null;
    } else {
    this.HIS_ED_DTM = new Timestamp(__dataIn.readLong());
    this.HIS_ED_DTM.setNanos(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.INPPE_ORG_ID = null;
    } else {
    this.INPPE_ORG_ID = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.SYS_OCC_DTM = null;
    } else {
    this.SYS_OCC_DTM = new Timestamp(__dataIn.readLong());
    this.SYS_OCC_DTM.setNanos(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.SYS_DEL_DIV_CD = null;
    } else {
    this.SYS_DEL_DIV_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.OCC_IP = null;
    } else {
    this.OCC_IP = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.APP_ID = null;
    } else {
    this.APP_ID = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.DATA_CHNG_DTM = null;
    } else {
    this.DATA_CHNG_DTM = new Timestamp(__dataIn.readLong());
    this.DATA_CHNG_DTM.setNanos(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.DGN_FEE1 = null;
    } else {
    this.DGN_FEE1 = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.DGN_FEE2 = null;
    } else {
    this.DGN_FEE2 = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.LAW_VLT_YN = null;
    } else {
    this.LAW_VLT_YN = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.BAS_SCR = null;
    } else {
    this.BAS_SCR = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.CHRPE_ORG_ID = null;
    } else {
    this.CHRPE_ORG_ID = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.CHRPE_PART_ORG_ID = null;
    } else {
    this.CHRPE_PART_ORG_ID = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.CHRPE_TEM_ORG_ID = null;
    } else {
    this.CHRPE_TEM_ORG_ID = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.MORL_DIVD_DTL_CD = null;
    } else {
    this.MORL_DIVD_DTL_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.SPFC_DGN_MORL_YN = null;
    } else {
    this.SPFC_DGN_MORL_YN = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.ETC_CON = null;
    } else {
    this.ETC_CON = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.EIH_LDG_DTM = null;
    } else {
    this.EIH_LDG_DTM = new Timestamp(__dataIn.readLong());
    this.EIH_LDG_DTM.setNanos(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.NURPE_SVC_RQE_YN = null;
    } else {
    this.NURPE_SVC_RQE_YN = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RULE_SQ_VAL = null;
    } else {
    this.RULE_SQ_VAL = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RULE_TRM_RSL_LST_CON20 = null;
    } else {
    this.RULE_TRM_RSL_LST_CON20 = org.apache.sqoop.lib.LobSerializer.readClobFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RULE_TRM_RSL_LST_CON26 = null;
    } else {
    this.RULE_TRM_RSL_LST_CON26 = org.apache.sqoop.lib.LobSerializer.readClobFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RULE_TRM_RSL_LST_CON27 = null;
    } else {
    this.RULE_TRM_RSL_LST_CON27 = org.apache.sqoop.lib.LobSerializer.readClobFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RULE_TRM_RSL_LST_CON28 = null;
    } else {
    this.RULE_TRM_RSL_LST_CON28 = org.apache.sqoop.lib.LobSerializer.readClobFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RULE_TRM_RSL_LST_CON29 = null;
    } else {
    this.RULE_TRM_RSL_LST_CON29 = org.apache.sqoop.lib.LobSerializer.readClobFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RULE_TRM_RSL_LST_CON30 = null;
    } else {
    this.RULE_TRM_RSL_LST_CON30 = org.apache.sqoop.lib.LobSerializer.readClobFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RULE_TRM_RSL_LST_CON32 = null;
    } else {
    this.RULE_TRM_RSL_LST_CON32 = org.apache.sqoop.lib.LobSerializer.readClobFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.MDEL_APL_TRG_YN = null;
    } else {
    this.MDEL_APL_TRG_YN = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.APL_BF_FLTR_TRM_VAL = null;
    } else {
    this.APL_BF_FLTR_TRM_VAL = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.MDEL_APL_DIV_CD = null;
    } else {
    this.MDEL_APL_DIV_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.MDEL_TRM_APL_RSL_VAL = null;
    } else {
    this.MDEL_TRM_APL_RSL_VAL = org.apache.sqoop.lib.LobSerializer.readClobFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.MDEL_DIV_CD_STD_VAL = null;
    } else {
    this.MDEL_DIV_CD_STD_VAL = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.MDEL_CMPT_RSL_VAL = null;
    } else {
    this.MDEL_CMPT_RSL_VAL = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.CMPT_SQ_CLUNIT_CD = null;
    } else {
    this.CMPT_SQ_CLUNIT_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.CMPT_SQ_DIVD_DIV_VAL = null;
    } else {
    this.CMPT_SQ_DIVD_DIV_VAL = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.OS_ID = null;
    } else {
    this.OS_ID = Text.readString(__dataIn);
    }
  }
  public void write(DataOutput __dataOut) throws IOException {
    if (null == this.CLM_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CLM_ID);
    }
    if (null == this.DMPE_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, DMPE_ID);
    }
    if (null == this.INF_OBM_FIX_SEQ) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.INF_OBM_FIX_SEQ, __dataOut);
    }
    if (null == this.HIS_SEQ) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.HIS_SEQ, __dataOut);
    }
    if (null == this.ACD_RCT_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ACD_RCT_ID);
    }
    if (null == this.SPFC_DIVD_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, SPFC_DIVD_DIV_CD);
    }
    if (null == this.MORL_DIVD_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, MORL_DIVD_DIV_CD);
    }
    if (null == this.SCRG_SCR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.SCRG_SCR, __dataOut);
    }
    if (null == this.CLUNIT_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CLUNIT_CD);
    }
    if (null == this.DTH_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, DTH_YN);
    }
    if (null == this.AFOBS_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, AFOBS_YN);
    }
    if (null == this.PRSM_INS_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.PRSM_INS_AMT, __dataOut);
    }
    if (null == this.ACCM_DCN_INS_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.ACCM_DCN_INS_AMT, __dataOut);
    }
    if (null == this.MD_EXP_CUS_GRDE_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, MD_EXP_CUS_GRDE_CD);
    }
    if (null == this.DDPY_CUS_GRDE_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, DDPY_CUS_GRDE_CD);
    }
    if (null == this.QUES_HOSP_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, QUES_HOSP_YN);
    }
    if (null == this.OBST_MORL_HOSP_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, OBST_MORL_HOSP_YN);
    }
    if (null == this.DDPY_ATTN_HOSP_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, DDPY_ATTN_HOSP_YN);
    }
    if (null == this.NSRY_ATTN_HOSP_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, NSRY_ATTN_HOSP_YN);
    }
    if (null == this.OWN_CTR_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, OWN_CTR_YN);
    }
    if (null == this.ACD_OCFQ_CUS_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ACD_OCFQ_CUS_YN);
    }
    if (null == this.APPR_ACD_DD_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, APPR_ACD_DD_DIV_CD);
    }
    if (null == this.MORL_KR_DISZ_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, MORL_KR_DISZ_CD);
    }
    if (null == this.DISZ_CD_LST) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, DISZ_CD_LST);
    }
    if (null == this.SPFC_TRTPE_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, SPFC_TRTPE_YN);
    }
    if (null == this.HIS_ST_DTM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.HIS_ST_DTM.getTime());
    __dataOut.writeInt(this.HIS_ST_DTM.getNanos());
    }
    if (null == this.HIS_ED_DTM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.HIS_ED_DTM.getTime());
    __dataOut.writeInt(this.HIS_ED_DTM.getNanos());
    }
    if (null == this.INPPE_ORG_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, INPPE_ORG_ID);
    }
    if (null == this.SYS_OCC_DTM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.SYS_OCC_DTM.getTime());
    __dataOut.writeInt(this.SYS_OCC_DTM.getNanos());
    }
    if (null == this.SYS_DEL_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, SYS_DEL_DIV_CD);
    }
    if (null == this.OCC_IP) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, OCC_IP);
    }
    if (null == this.APP_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, APP_ID);
    }
    if (null == this.DATA_CHNG_DTM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.DATA_CHNG_DTM.getTime());
    __dataOut.writeInt(this.DATA_CHNG_DTM.getNanos());
    }
    if (null == this.DGN_FEE1) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.DGN_FEE1, __dataOut);
    }
    if (null == this.DGN_FEE2) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.DGN_FEE2, __dataOut);
    }
    if (null == this.LAW_VLT_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, LAW_VLT_YN);
    }
    if (null == this.BAS_SCR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.BAS_SCR, __dataOut);
    }
    if (null == this.CHRPE_ORG_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CHRPE_ORG_ID);
    }
    if (null == this.CHRPE_PART_ORG_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CHRPE_PART_ORG_ID);
    }
    if (null == this.CHRPE_TEM_ORG_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CHRPE_TEM_ORG_ID);
    }
    if (null == this.MORL_DIVD_DTL_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, MORL_DIVD_DTL_CD);
    }
    if (null == this.SPFC_DGN_MORL_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, SPFC_DGN_MORL_YN);
    }
    if (null == this.ETC_CON) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ETC_CON);
    }
    if (null == this.EIH_LDG_DTM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.EIH_LDG_DTM.getTime());
    __dataOut.writeInt(this.EIH_LDG_DTM.getNanos());
    }
    if (null == this.NURPE_SVC_RQE_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, NURPE_SVC_RQE_YN);
    }
    if (null == this.RULE_SQ_VAL) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RULE_SQ_VAL);
    }
    if (null == this.RULE_TRM_RSL_LST_CON20) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.LobSerializer.writeClob(this.RULE_TRM_RSL_LST_CON20, __dataOut);
    }
    if (null == this.RULE_TRM_RSL_LST_CON26) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.LobSerializer.writeClob(this.RULE_TRM_RSL_LST_CON26, __dataOut);
    }
    if (null == this.RULE_TRM_RSL_LST_CON27) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.LobSerializer.writeClob(this.RULE_TRM_RSL_LST_CON27, __dataOut);
    }
    if (null == this.RULE_TRM_RSL_LST_CON28) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.LobSerializer.writeClob(this.RULE_TRM_RSL_LST_CON28, __dataOut);
    }
    if (null == this.RULE_TRM_RSL_LST_CON29) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.LobSerializer.writeClob(this.RULE_TRM_RSL_LST_CON29, __dataOut);
    }
    if (null == this.RULE_TRM_RSL_LST_CON30) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.LobSerializer.writeClob(this.RULE_TRM_RSL_LST_CON30, __dataOut);
    }
    if (null == this.RULE_TRM_RSL_LST_CON32) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.LobSerializer.writeClob(this.RULE_TRM_RSL_LST_CON32, __dataOut);
    }
    if (null == this.MDEL_APL_TRG_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, MDEL_APL_TRG_YN);
    }
    if (null == this.APL_BF_FLTR_TRM_VAL) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, APL_BF_FLTR_TRM_VAL);
    }
    if (null == this.MDEL_APL_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, MDEL_APL_DIV_CD);
    }
    if (null == this.MDEL_TRM_APL_RSL_VAL) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.LobSerializer.writeClob(this.MDEL_TRM_APL_RSL_VAL, __dataOut);
    }
    if (null == this.MDEL_DIV_CD_STD_VAL) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, MDEL_DIV_CD_STD_VAL);
    }
    if (null == this.MDEL_CMPT_RSL_VAL) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, MDEL_CMPT_RSL_VAL);
    }
    if (null == this.CMPT_SQ_CLUNIT_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CMPT_SQ_CLUNIT_CD);
    }
    if (null == this.CMPT_SQ_DIVD_DIV_VAL) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CMPT_SQ_DIVD_DIV_VAL);
    }
    if (null == this.OS_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, OS_ID);
    }
  }
  public void write0(DataOutput __dataOut) throws IOException {
    if (null == this.CLM_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CLM_ID);
    }
    if (null == this.DMPE_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, DMPE_ID);
    }
    if (null == this.INF_OBM_FIX_SEQ) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.INF_OBM_FIX_SEQ, __dataOut);
    }
    if (null == this.HIS_SEQ) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.HIS_SEQ, __dataOut);
    }
    if (null == this.ACD_RCT_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ACD_RCT_ID);
    }
    if (null == this.SPFC_DIVD_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, SPFC_DIVD_DIV_CD);
    }
    if (null == this.MORL_DIVD_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, MORL_DIVD_DIV_CD);
    }
    if (null == this.SCRG_SCR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.SCRG_SCR, __dataOut);
    }
    if (null == this.CLUNIT_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CLUNIT_CD);
    }
    if (null == this.DTH_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, DTH_YN);
    }
    if (null == this.AFOBS_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, AFOBS_YN);
    }
    if (null == this.PRSM_INS_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.PRSM_INS_AMT, __dataOut);
    }
    if (null == this.ACCM_DCN_INS_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.ACCM_DCN_INS_AMT, __dataOut);
    }
    if (null == this.MD_EXP_CUS_GRDE_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, MD_EXP_CUS_GRDE_CD);
    }
    if (null == this.DDPY_CUS_GRDE_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, DDPY_CUS_GRDE_CD);
    }
    if (null == this.QUES_HOSP_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, QUES_HOSP_YN);
    }
    if (null == this.OBST_MORL_HOSP_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, OBST_MORL_HOSP_YN);
    }
    if (null == this.DDPY_ATTN_HOSP_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, DDPY_ATTN_HOSP_YN);
    }
    if (null == this.NSRY_ATTN_HOSP_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, NSRY_ATTN_HOSP_YN);
    }
    if (null == this.OWN_CTR_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, OWN_CTR_YN);
    }
    if (null == this.ACD_OCFQ_CUS_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ACD_OCFQ_CUS_YN);
    }
    if (null == this.APPR_ACD_DD_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, APPR_ACD_DD_DIV_CD);
    }
    if (null == this.MORL_KR_DISZ_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, MORL_KR_DISZ_CD);
    }
    if (null == this.DISZ_CD_LST) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, DISZ_CD_LST);
    }
    if (null == this.SPFC_TRTPE_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, SPFC_TRTPE_YN);
    }
    if (null == this.HIS_ST_DTM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.HIS_ST_DTM.getTime());
    __dataOut.writeInt(this.HIS_ST_DTM.getNanos());
    }
    if (null == this.HIS_ED_DTM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.HIS_ED_DTM.getTime());
    __dataOut.writeInt(this.HIS_ED_DTM.getNanos());
    }
    if (null == this.INPPE_ORG_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, INPPE_ORG_ID);
    }
    if (null == this.SYS_OCC_DTM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.SYS_OCC_DTM.getTime());
    __dataOut.writeInt(this.SYS_OCC_DTM.getNanos());
    }
    if (null == this.SYS_DEL_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, SYS_DEL_DIV_CD);
    }
    if (null == this.OCC_IP) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, OCC_IP);
    }
    if (null == this.APP_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, APP_ID);
    }
    if (null == this.DATA_CHNG_DTM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.DATA_CHNG_DTM.getTime());
    __dataOut.writeInt(this.DATA_CHNG_DTM.getNanos());
    }
    if (null == this.DGN_FEE1) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.DGN_FEE1, __dataOut);
    }
    if (null == this.DGN_FEE2) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.DGN_FEE2, __dataOut);
    }
    if (null == this.LAW_VLT_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, LAW_VLT_YN);
    }
    if (null == this.BAS_SCR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.BAS_SCR, __dataOut);
    }
    if (null == this.CHRPE_ORG_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CHRPE_ORG_ID);
    }
    if (null == this.CHRPE_PART_ORG_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CHRPE_PART_ORG_ID);
    }
    if (null == this.CHRPE_TEM_ORG_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CHRPE_TEM_ORG_ID);
    }
    if (null == this.MORL_DIVD_DTL_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, MORL_DIVD_DTL_CD);
    }
    if (null == this.SPFC_DGN_MORL_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, SPFC_DGN_MORL_YN);
    }
    if (null == this.ETC_CON) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ETC_CON);
    }
    if (null == this.EIH_LDG_DTM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.EIH_LDG_DTM.getTime());
    __dataOut.writeInt(this.EIH_LDG_DTM.getNanos());
    }
    if (null == this.NURPE_SVC_RQE_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, NURPE_SVC_RQE_YN);
    }
    if (null == this.RULE_SQ_VAL) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RULE_SQ_VAL);
    }
    if (null == this.RULE_TRM_RSL_LST_CON20) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.LobSerializer.writeClob(this.RULE_TRM_RSL_LST_CON20, __dataOut);
    }
    if (null == this.RULE_TRM_RSL_LST_CON26) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.LobSerializer.writeClob(this.RULE_TRM_RSL_LST_CON26, __dataOut);
    }
    if (null == this.RULE_TRM_RSL_LST_CON27) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.LobSerializer.writeClob(this.RULE_TRM_RSL_LST_CON27, __dataOut);
    }
    if (null == this.RULE_TRM_RSL_LST_CON28) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.LobSerializer.writeClob(this.RULE_TRM_RSL_LST_CON28, __dataOut);
    }
    if (null == this.RULE_TRM_RSL_LST_CON29) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.LobSerializer.writeClob(this.RULE_TRM_RSL_LST_CON29, __dataOut);
    }
    if (null == this.RULE_TRM_RSL_LST_CON30) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.LobSerializer.writeClob(this.RULE_TRM_RSL_LST_CON30, __dataOut);
    }
    if (null == this.RULE_TRM_RSL_LST_CON32) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.LobSerializer.writeClob(this.RULE_TRM_RSL_LST_CON32, __dataOut);
    }
    if (null == this.MDEL_APL_TRG_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, MDEL_APL_TRG_YN);
    }
    if (null == this.APL_BF_FLTR_TRM_VAL) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, APL_BF_FLTR_TRM_VAL);
    }
    if (null == this.MDEL_APL_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, MDEL_APL_DIV_CD);
    }
    if (null == this.MDEL_TRM_APL_RSL_VAL) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.LobSerializer.writeClob(this.MDEL_TRM_APL_RSL_VAL, __dataOut);
    }
    if (null == this.MDEL_DIV_CD_STD_VAL) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, MDEL_DIV_CD_STD_VAL);
    }
    if (null == this.MDEL_CMPT_RSL_VAL) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, MDEL_CMPT_RSL_VAL);
    }
    if (null == this.CMPT_SQ_CLUNIT_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CMPT_SQ_CLUNIT_CD);
    }
    if (null == this.CMPT_SQ_DIVD_DIV_VAL) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CMPT_SQ_DIVD_DIV_VAL);
    }
    if (null == this.OS_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, OS_ID);
    }
  }
  private static final DelimiterSet __outputDelimiters = new DelimiterSet((char) 1, (char) 10, (char) 0, (char) 0, false);
  public String toString() {
    return toString(__outputDelimiters, true);
  }
  public String toString(DelimiterSet delimiters) {
    return toString(delimiters, true);
  }
  public String toString(boolean useRecordDelim) {
    return toString(__outputDelimiters, useRecordDelim);
  }
  public String toString(DelimiterSet delimiters, boolean useRecordDelim) {
    StringBuilder __sb = new StringBuilder();
    char fieldDelim = delimiters.getFieldsTerminatedBy();
    __sb.append(FieldFormatter.escapeAndEnclose(CLM_ID==null?"null":CLM_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DMPE_ID==null?"null":DMPE_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(INF_OBM_FIX_SEQ==null?"null":INF_OBM_FIX_SEQ.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(HIS_SEQ==null?"null":HIS_SEQ.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ACD_RCT_ID==null?"null":ACD_RCT_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SPFC_DIVD_DIV_CD==null?"null":SPFC_DIVD_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(MORL_DIVD_DIV_CD==null?"null":MORL_DIVD_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SCRG_SCR==null?"null":SCRG_SCR.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CLUNIT_CD==null?"null":CLUNIT_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DTH_YN==null?"null":DTH_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(AFOBS_YN==null?"null":AFOBS_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PRSM_INS_AMT==null?"null":PRSM_INS_AMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ACCM_DCN_INS_AMT==null?"null":ACCM_DCN_INS_AMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(MD_EXP_CUS_GRDE_CD==null?"null":MD_EXP_CUS_GRDE_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DDPY_CUS_GRDE_CD==null?"null":DDPY_CUS_GRDE_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(QUES_HOSP_YN==null?"null":QUES_HOSP_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(OBST_MORL_HOSP_YN==null?"null":OBST_MORL_HOSP_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DDPY_ATTN_HOSP_YN==null?"null":DDPY_ATTN_HOSP_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(NSRY_ATTN_HOSP_YN==null?"null":NSRY_ATTN_HOSP_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(OWN_CTR_YN==null?"null":OWN_CTR_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ACD_OCFQ_CUS_YN==null?"null":ACD_OCFQ_CUS_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(APPR_ACD_DD_DIV_CD==null?"null":APPR_ACD_DD_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(MORL_KR_DISZ_CD==null?"null":MORL_KR_DISZ_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DISZ_CD_LST==null?"null":DISZ_CD_LST, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SPFC_TRTPE_YN==null?"null":SPFC_TRTPE_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(HIS_ST_DTM==null?"null":"" + HIS_ST_DTM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(HIS_ED_DTM==null?"null":"" + HIS_ED_DTM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(INPPE_ORG_ID==null?"null":INPPE_ORG_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SYS_OCC_DTM==null?"null":"" + SYS_OCC_DTM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SYS_DEL_DIV_CD==null?"null":SYS_DEL_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(OCC_IP==null?"null":OCC_IP, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(APP_ID==null?"null":APP_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DATA_CHNG_DTM==null?"null":"" + DATA_CHNG_DTM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DGN_FEE1==null?"null":DGN_FEE1.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DGN_FEE2==null?"null":DGN_FEE2.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(LAW_VLT_YN==null?"null":LAW_VLT_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(BAS_SCR==null?"null":BAS_SCR.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CHRPE_ORG_ID==null?"null":CHRPE_ORG_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CHRPE_PART_ORG_ID==null?"null":CHRPE_PART_ORG_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CHRPE_TEM_ORG_ID==null?"null":CHRPE_TEM_ORG_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(MORL_DIVD_DTL_CD==null?"null":MORL_DIVD_DTL_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SPFC_DGN_MORL_YN==null?"null":SPFC_DGN_MORL_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ETC_CON==null?"null":ETC_CON, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(EIH_LDG_DTM==null?"null":"" + EIH_LDG_DTM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(NURPE_SVC_RQE_YN==null?"null":NURPE_SVC_RQE_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RULE_SQ_VAL==null?"null":RULE_SQ_VAL, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RULE_TRM_RSL_LST_CON20==null?"null":"" + RULE_TRM_RSL_LST_CON20, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RULE_TRM_RSL_LST_CON26==null?"null":"" + RULE_TRM_RSL_LST_CON26, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RULE_TRM_RSL_LST_CON27==null?"null":"" + RULE_TRM_RSL_LST_CON27, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RULE_TRM_RSL_LST_CON28==null?"null":"" + RULE_TRM_RSL_LST_CON28, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RULE_TRM_RSL_LST_CON29==null?"null":"" + RULE_TRM_RSL_LST_CON29, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RULE_TRM_RSL_LST_CON30==null?"null":"" + RULE_TRM_RSL_LST_CON30, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RULE_TRM_RSL_LST_CON32==null?"null":"" + RULE_TRM_RSL_LST_CON32, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(MDEL_APL_TRG_YN==null?"null":MDEL_APL_TRG_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(APL_BF_FLTR_TRM_VAL==null?"null":APL_BF_FLTR_TRM_VAL, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(MDEL_APL_DIV_CD==null?"null":MDEL_APL_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(MDEL_TRM_APL_RSL_VAL==null?"null":"" + MDEL_TRM_APL_RSL_VAL, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(MDEL_DIV_CD_STD_VAL==null?"null":MDEL_DIV_CD_STD_VAL, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(MDEL_CMPT_RSL_VAL==null?"null":MDEL_CMPT_RSL_VAL, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CMPT_SQ_CLUNIT_CD==null?"null":CMPT_SQ_CLUNIT_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CMPT_SQ_DIVD_DIV_VAL==null?"null":CMPT_SQ_DIVD_DIV_VAL, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(OS_ID==null?"null":OS_ID, delimiters));
    if (useRecordDelim) {
      __sb.append(delimiters.getLinesTerminatedBy());
    }
    return __sb.toString();
  }
  public void toString0(DelimiterSet delimiters, StringBuilder __sb, char fieldDelim) {
    __sb.append(FieldFormatter.escapeAndEnclose(CLM_ID==null?"null":CLM_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DMPE_ID==null?"null":DMPE_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(INF_OBM_FIX_SEQ==null?"null":INF_OBM_FIX_SEQ.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(HIS_SEQ==null?"null":HIS_SEQ.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ACD_RCT_ID==null?"null":ACD_RCT_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SPFC_DIVD_DIV_CD==null?"null":SPFC_DIVD_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(MORL_DIVD_DIV_CD==null?"null":MORL_DIVD_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SCRG_SCR==null?"null":SCRG_SCR.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CLUNIT_CD==null?"null":CLUNIT_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DTH_YN==null?"null":DTH_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(AFOBS_YN==null?"null":AFOBS_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PRSM_INS_AMT==null?"null":PRSM_INS_AMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ACCM_DCN_INS_AMT==null?"null":ACCM_DCN_INS_AMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(MD_EXP_CUS_GRDE_CD==null?"null":MD_EXP_CUS_GRDE_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DDPY_CUS_GRDE_CD==null?"null":DDPY_CUS_GRDE_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(QUES_HOSP_YN==null?"null":QUES_HOSP_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(OBST_MORL_HOSP_YN==null?"null":OBST_MORL_HOSP_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DDPY_ATTN_HOSP_YN==null?"null":DDPY_ATTN_HOSP_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(NSRY_ATTN_HOSP_YN==null?"null":NSRY_ATTN_HOSP_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(OWN_CTR_YN==null?"null":OWN_CTR_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ACD_OCFQ_CUS_YN==null?"null":ACD_OCFQ_CUS_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(APPR_ACD_DD_DIV_CD==null?"null":APPR_ACD_DD_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(MORL_KR_DISZ_CD==null?"null":MORL_KR_DISZ_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DISZ_CD_LST==null?"null":DISZ_CD_LST, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SPFC_TRTPE_YN==null?"null":SPFC_TRTPE_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(HIS_ST_DTM==null?"null":"" + HIS_ST_DTM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(HIS_ED_DTM==null?"null":"" + HIS_ED_DTM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(INPPE_ORG_ID==null?"null":INPPE_ORG_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SYS_OCC_DTM==null?"null":"" + SYS_OCC_DTM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SYS_DEL_DIV_CD==null?"null":SYS_DEL_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(OCC_IP==null?"null":OCC_IP, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(APP_ID==null?"null":APP_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DATA_CHNG_DTM==null?"null":"" + DATA_CHNG_DTM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DGN_FEE1==null?"null":DGN_FEE1.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DGN_FEE2==null?"null":DGN_FEE2.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(LAW_VLT_YN==null?"null":LAW_VLT_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(BAS_SCR==null?"null":BAS_SCR.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CHRPE_ORG_ID==null?"null":CHRPE_ORG_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CHRPE_PART_ORG_ID==null?"null":CHRPE_PART_ORG_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CHRPE_TEM_ORG_ID==null?"null":CHRPE_TEM_ORG_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(MORL_DIVD_DTL_CD==null?"null":MORL_DIVD_DTL_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SPFC_DGN_MORL_YN==null?"null":SPFC_DGN_MORL_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ETC_CON==null?"null":ETC_CON, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(EIH_LDG_DTM==null?"null":"" + EIH_LDG_DTM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(NURPE_SVC_RQE_YN==null?"null":NURPE_SVC_RQE_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RULE_SQ_VAL==null?"null":RULE_SQ_VAL, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RULE_TRM_RSL_LST_CON20==null?"null":"" + RULE_TRM_RSL_LST_CON20, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RULE_TRM_RSL_LST_CON26==null?"null":"" + RULE_TRM_RSL_LST_CON26, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RULE_TRM_RSL_LST_CON27==null?"null":"" + RULE_TRM_RSL_LST_CON27, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RULE_TRM_RSL_LST_CON28==null?"null":"" + RULE_TRM_RSL_LST_CON28, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RULE_TRM_RSL_LST_CON29==null?"null":"" + RULE_TRM_RSL_LST_CON29, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RULE_TRM_RSL_LST_CON30==null?"null":"" + RULE_TRM_RSL_LST_CON30, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RULE_TRM_RSL_LST_CON32==null?"null":"" + RULE_TRM_RSL_LST_CON32, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(MDEL_APL_TRG_YN==null?"null":MDEL_APL_TRG_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(APL_BF_FLTR_TRM_VAL==null?"null":APL_BF_FLTR_TRM_VAL, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(MDEL_APL_DIV_CD==null?"null":MDEL_APL_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(MDEL_TRM_APL_RSL_VAL==null?"null":"" + MDEL_TRM_APL_RSL_VAL, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(MDEL_DIV_CD_STD_VAL==null?"null":MDEL_DIV_CD_STD_VAL, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(MDEL_CMPT_RSL_VAL==null?"null":MDEL_CMPT_RSL_VAL, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CMPT_SQ_CLUNIT_CD==null?"null":CMPT_SQ_CLUNIT_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CMPT_SQ_DIVD_DIV_VAL==null?"null":CMPT_SQ_DIVD_DIV_VAL, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(OS_ID==null?"null":OS_ID, delimiters));
  }
  private static final DelimiterSet __inputDelimiters = new DelimiterSet((char) 1, (char) 10, (char) 0, (char) 0, false);
  private RecordParser __parser;
  public void parse(Text __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(CharSequence __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(byte [] __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(char [] __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(ByteBuffer __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(CharBuffer __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  private void __loadFromFields(List<String> fields) {
    Iterator<String> __it = fields.listIterator();
    String __cur_str = null;
    try {
    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CLM_ID = null; } else {
      this.CLM_ID = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.DMPE_ID = null; } else {
      this.DMPE_ID = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.INF_OBM_FIX_SEQ = null; } else {
      this.INF_OBM_FIX_SEQ = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.HIS_SEQ = null; } else {
      this.HIS_SEQ = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.ACD_RCT_ID = null; } else {
      this.ACD_RCT_ID = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.SPFC_DIVD_DIV_CD = null; } else {
      this.SPFC_DIVD_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.MORL_DIVD_DIV_CD = null; } else {
      this.MORL_DIVD_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.SCRG_SCR = null; } else {
      this.SCRG_SCR = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CLUNIT_CD = null; } else {
      this.CLUNIT_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.DTH_YN = null; } else {
      this.DTH_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.AFOBS_YN = null; } else {
      this.AFOBS_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.PRSM_INS_AMT = null; } else {
      this.PRSM_INS_AMT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.ACCM_DCN_INS_AMT = null; } else {
      this.ACCM_DCN_INS_AMT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.MD_EXP_CUS_GRDE_CD = null; } else {
      this.MD_EXP_CUS_GRDE_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.DDPY_CUS_GRDE_CD = null; } else {
      this.DDPY_CUS_GRDE_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.QUES_HOSP_YN = null; } else {
      this.QUES_HOSP_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.OBST_MORL_HOSP_YN = null; } else {
      this.OBST_MORL_HOSP_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.DDPY_ATTN_HOSP_YN = null; } else {
      this.DDPY_ATTN_HOSP_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.NSRY_ATTN_HOSP_YN = null; } else {
      this.NSRY_ATTN_HOSP_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.OWN_CTR_YN = null; } else {
      this.OWN_CTR_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.ACD_OCFQ_CUS_YN = null; } else {
      this.ACD_OCFQ_CUS_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.APPR_ACD_DD_DIV_CD = null; } else {
      this.APPR_ACD_DD_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.MORL_KR_DISZ_CD = null; } else {
      this.MORL_KR_DISZ_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.DISZ_CD_LST = null; } else {
      this.DISZ_CD_LST = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.SPFC_TRTPE_YN = null; } else {
      this.SPFC_TRTPE_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.HIS_ST_DTM = null; } else {
      this.HIS_ST_DTM = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.HIS_ED_DTM = null; } else {
      this.HIS_ED_DTM = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.INPPE_ORG_ID = null; } else {
      this.INPPE_ORG_ID = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.SYS_OCC_DTM = null; } else {
      this.SYS_OCC_DTM = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.SYS_DEL_DIV_CD = null; } else {
      this.SYS_DEL_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.OCC_IP = null; } else {
      this.OCC_IP = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.APP_ID = null; } else {
      this.APP_ID = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.DATA_CHNG_DTM = null; } else {
      this.DATA_CHNG_DTM = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.DGN_FEE1 = null; } else {
      this.DGN_FEE1 = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.DGN_FEE2 = null; } else {
      this.DGN_FEE2 = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.LAW_VLT_YN = null; } else {
      this.LAW_VLT_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.BAS_SCR = null; } else {
      this.BAS_SCR = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CHRPE_ORG_ID = null; } else {
      this.CHRPE_ORG_ID = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CHRPE_PART_ORG_ID = null; } else {
      this.CHRPE_PART_ORG_ID = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CHRPE_TEM_ORG_ID = null; } else {
      this.CHRPE_TEM_ORG_ID = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.MORL_DIVD_DTL_CD = null; } else {
      this.MORL_DIVD_DTL_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.SPFC_DGN_MORL_YN = null; } else {
      this.SPFC_DGN_MORL_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.ETC_CON = null; } else {
      this.ETC_CON = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.EIH_LDG_DTM = null; } else {
      this.EIH_LDG_DTM = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.NURPE_SVC_RQE_YN = null; } else {
      this.NURPE_SVC_RQE_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.RULE_SQ_VAL = null; } else {
      this.RULE_SQ_VAL = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RULE_TRM_RSL_LST_CON20 = null; } else {
      this.RULE_TRM_RSL_LST_CON20 = ClobRef.parse(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RULE_TRM_RSL_LST_CON26 = null; } else {
      this.RULE_TRM_RSL_LST_CON26 = ClobRef.parse(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RULE_TRM_RSL_LST_CON27 = null; } else {
      this.RULE_TRM_RSL_LST_CON27 = ClobRef.parse(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RULE_TRM_RSL_LST_CON28 = null; } else {
      this.RULE_TRM_RSL_LST_CON28 = ClobRef.parse(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RULE_TRM_RSL_LST_CON29 = null; } else {
      this.RULE_TRM_RSL_LST_CON29 = ClobRef.parse(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RULE_TRM_RSL_LST_CON30 = null; } else {
      this.RULE_TRM_RSL_LST_CON30 = ClobRef.parse(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RULE_TRM_RSL_LST_CON32 = null; } else {
      this.RULE_TRM_RSL_LST_CON32 = ClobRef.parse(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.MDEL_APL_TRG_YN = null; } else {
      this.MDEL_APL_TRG_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.APL_BF_FLTR_TRM_VAL = null; } else {
      this.APL_BF_FLTR_TRM_VAL = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.MDEL_APL_DIV_CD = null; } else {
      this.MDEL_APL_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.MDEL_TRM_APL_RSL_VAL = null; } else {
      this.MDEL_TRM_APL_RSL_VAL = ClobRef.parse(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.MDEL_DIV_CD_STD_VAL = null; } else {
      this.MDEL_DIV_CD_STD_VAL = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.MDEL_CMPT_RSL_VAL = null; } else {
      this.MDEL_CMPT_RSL_VAL = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CMPT_SQ_CLUNIT_CD = null; } else {
      this.CMPT_SQ_CLUNIT_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CMPT_SQ_DIVD_DIV_VAL = null; } else {
      this.CMPT_SQ_DIVD_DIV_VAL = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.OS_ID = null; } else {
      this.OS_ID = __cur_str;
    }

    } catch (RuntimeException e) {    throw new RuntimeException("Can't parse input data: '" + __cur_str + "'", e);    }  }

  private void __loadFromFields0(Iterator<String> __it) {
    String __cur_str = null;
    try {
    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CLM_ID = null; } else {
      this.CLM_ID = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.DMPE_ID = null; } else {
      this.DMPE_ID = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.INF_OBM_FIX_SEQ = null; } else {
      this.INF_OBM_FIX_SEQ = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.HIS_SEQ = null; } else {
      this.HIS_SEQ = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.ACD_RCT_ID = null; } else {
      this.ACD_RCT_ID = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.SPFC_DIVD_DIV_CD = null; } else {
      this.SPFC_DIVD_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.MORL_DIVD_DIV_CD = null; } else {
      this.MORL_DIVD_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.SCRG_SCR = null; } else {
      this.SCRG_SCR = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CLUNIT_CD = null; } else {
      this.CLUNIT_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.DTH_YN = null; } else {
      this.DTH_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.AFOBS_YN = null; } else {
      this.AFOBS_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.PRSM_INS_AMT = null; } else {
      this.PRSM_INS_AMT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.ACCM_DCN_INS_AMT = null; } else {
      this.ACCM_DCN_INS_AMT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.MD_EXP_CUS_GRDE_CD = null; } else {
      this.MD_EXP_CUS_GRDE_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.DDPY_CUS_GRDE_CD = null; } else {
      this.DDPY_CUS_GRDE_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.QUES_HOSP_YN = null; } else {
      this.QUES_HOSP_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.OBST_MORL_HOSP_YN = null; } else {
      this.OBST_MORL_HOSP_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.DDPY_ATTN_HOSP_YN = null; } else {
      this.DDPY_ATTN_HOSP_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.NSRY_ATTN_HOSP_YN = null; } else {
      this.NSRY_ATTN_HOSP_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.OWN_CTR_YN = null; } else {
      this.OWN_CTR_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.ACD_OCFQ_CUS_YN = null; } else {
      this.ACD_OCFQ_CUS_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.APPR_ACD_DD_DIV_CD = null; } else {
      this.APPR_ACD_DD_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.MORL_KR_DISZ_CD = null; } else {
      this.MORL_KR_DISZ_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.DISZ_CD_LST = null; } else {
      this.DISZ_CD_LST = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.SPFC_TRTPE_YN = null; } else {
      this.SPFC_TRTPE_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.HIS_ST_DTM = null; } else {
      this.HIS_ST_DTM = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.HIS_ED_DTM = null; } else {
      this.HIS_ED_DTM = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.INPPE_ORG_ID = null; } else {
      this.INPPE_ORG_ID = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.SYS_OCC_DTM = null; } else {
      this.SYS_OCC_DTM = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.SYS_DEL_DIV_CD = null; } else {
      this.SYS_DEL_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.OCC_IP = null; } else {
      this.OCC_IP = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.APP_ID = null; } else {
      this.APP_ID = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.DATA_CHNG_DTM = null; } else {
      this.DATA_CHNG_DTM = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.DGN_FEE1 = null; } else {
      this.DGN_FEE1 = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.DGN_FEE2 = null; } else {
      this.DGN_FEE2 = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.LAW_VLT_YN = null; } else {
      this.LAW_VLT_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.BAS_SCR = null; } else {
      this.BAS_SCR = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CHRPE_ORG_ID = null; } else {
      this.CHRPE_ORG_ID = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CHRPE_PART_ORG_ID = null; } else {
      this.CHRPE_PART_ORG_ID = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CHRPE_TEM_ORG_ID = null; } else {
      this.CHRPE_TEM_ORG_ID = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.MORL_DIVD_DTL_CD = null; } else {
      this.MORL_DIVD_DTL_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.SPFC_DGN_MORL_YN = null; } else {
      this.SPFC_DGN_MORL_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.ETC_CON = null; } else {
      this.ETC_CON = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.EIH_LDG_DTM = null; } else {
      this.EIH_LDG_DTM = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.NURPE_SVC_RQE_YN = null; } else {
      this.NURPE_SVC_RQE_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.RULE_SQ_VAL = null; } else {
      this.RULE_SQ_VAL = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RULE_TRM_RSL_LST_CON20 = null; } else {
      this.RULE_TRM_RSL_LST_CON20 = ClobRef.parse(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RULE_TRM_RSL_LST_CON26 = null; } else {
      this.RULE_TRM_RSL_LST_CON26 = ClobRef.parse(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RULE_TRM_RSL_LST_CON27 = null; } else {
      this.RULE_TRM_RSL_LST_CON27 = ClobRef.parse(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RULE_TRM_RSL_LST_CON28 = null; } else {
      this.RULE_TRM_RSL_LST_CON28 = ClobRef.parse(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RULE_TRM_RSL_LST_CON29 = null; } else {
      this.RULE_TRM_RSL_LST_CON29 = ClobRef.parse(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RULE_TRM_RSL_LST_CON30 = null; } else {
      this.RULE_TRM_RSL_LST_CON30 = ClobRef.parse(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RULE_TRM_RSL_LST_CON32 = null; } else {
      this.RULE_TRM_RSL_LST_CON32 = ClobRef.parse(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.MDEL_APL_TRG_YN = null; } else {
      this.MDEL_APL_TRG_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.APL_BF_FLTR_TRM_VAL = null; } else {
      this.APL_BF_FLTR_TRM_VAL = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.MDEL_APL_DIV_CD = null; } else {
      this.MDEL_APL_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.MDEL_TRM_APL_RSL_VAL = null; } else {
      this.MDEL_TRM_APL_RSL_VAL = ClobRef.parse(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.MDEL_DIV_CD_STD_VAL = null; } else {
      this.MDEL_DIV_CD_STD_VAL = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.MDEL_CMPT_RSL_VAL = null; } else {
      this.MDEL_CMPT_RSL_VAL = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CMPT_SQ_CLUNIT_CD = null; } else {
      this.CMPT_SQ_CLUNIT_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CMPT_SQ_DIVD_DIV_VAL = null; } else {
      this.CMPT_SQ_DIVD_DIV_VAL = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.OS_ID = null; } else {
      this.OS_ID = __cur_str;
    }

    } catch (RuntimeException e) {    throw new RuntimeException("Can't parse input data: '" + __cur_str + "'", e);    }  }

  public Object clone() throws CloneNotSupportedException {
    QueryResult o = (QueryResult) super.clone();
    o.HIS_ST_DTM = (o.HIS_ST_DTM != null) ? (java.sql.Timestamp) o.HIS_ST_DTM.clone() : null;
    o.HIS_ED_DTM = (o.HIS_ED_DTM != null) ? (java.sql.Timestamp) o.HIS_ED_DTM.clone() : null;
    o.SYS_OCC_DTM = (o.SYS_OCC_DTM != null) ? (java.sql.Timestamp) o.SYS_OCC_DTM.clone() : null;
    o.DATA_CHNG_DTM = (o.DATA_CHNG_DTM != null) ? (java.sql.Timestamp) o.DATA_CHNG_DTM.clone() : null;
    o.EIH_LDG_DTM = (o.EIH_LDG_DTM != null) ? (java.sql.Timestamp) o.EIH_LDG_DTM.clone() : null;
    o.RULE_TRM_RSL_LST_CON20 = (o.RULE_TRM_RSL_LST_CON20 != null) ? (org.apache.sqoop.lib.ClobRef) o.RULE_TRM_RSL_LST_CON20.clone() : null;
    o.RULE_TRM_RSL_LST_CON26 = (o.RULE_TRM_RSL_LST_CON26 != null) ? (org.apache.sqoop.lib.ClobRef) o.RULE_TRM_RSL_LST_CON26.clone() : null;
    o.RULE_TRM_RSL_LST_CON27 = (o.RULE_TRM_RSL_LST_CON27 != null) ? (org.apache.sqoop.lib.ClobRef) o.RULE_TRM_RSL_LST_CON27.clone() : null;
    o.RULE_TRM_RSL_LST_CON28 = (o.RULE_TRM_RSL_LST_CON28 != null) ? (org.apache.sqoop.lib.ClobRef) o.RULE_TRM_RSL_LST_CON28.clone() : null;
    o.RULE_TRM_RSL_LST_CON29 = (o.RULE_TRM_RSL_LST_CON29 != null) ? (org.apache.sqoop.lib.ClobRef) o.RULE_TRM_RSL_LST_CON29.clone() : null;
    o.RULE_TRM_RSL_LST_CON30 = (o.RULE_TRM_RSL_LST_CON30 != null) ? (org.apache.sqoop.lib.ClobRef) o.RULE_TRM_RSL_LST_CON30.clone() : null;
    o.RULE_TRM_RSL_LST_CON32 = (o.RULE_TRM_RSL_LST_CON32 != null) ? (org.apache.sqoop.lib.ClobRef) o.RULE_TRM_RSL_LST_CON32.clone() : null;
    o.MDEL_TRM_APL_RSL_VAL = (o.MDEL_TRM_APL_RSL_VAL != null) ? (org.apache.sqoop.lib.ClobRef) o.MDEL_TRM_APL_RSL_VAL.clone() : null;
    return o;
  }

  public void clone0(QueryResult o) throws CloneNotSupportedException {
    o.HIS_ST_DTM = (o.HIS_ST_DTM != null) ? (java.sql.Timestamp) o.HIS_ST_DTM.clone() : null;
    o.HIS_ED_DTM = (o.HIS_ED_DTM != null) ? (java.sql.Timestamp) o.HIS_ED_DTM.clone() : null;
    o.SYS_OCC_DTM = (o.SYS_OCC_DTM != null) ? (java.sql.Timestamp) o.SYS_OCC_DTM.clone() : null;
    o.DATA_CHNG_DTM = (o.DATA_CHNG_DTM != null) ? (java.sql.Timestamp) o.DATA_CHNG_DTM.clone() : null;
    o.EIH_LDG_DTM = (o.EIH_LDG_DTM != null) ? (java.sql.Timestamp) o.EIH_LDG_DTM.clone() : null;
    o.RULE_TRM_RSL_LST_CON20 = (o.RULE_TRM_RSL_LST_CON20 != null) ? (org.apache.sqoop.lib.ClobRef) o.RULE_TRM_RSL_LST_CON20.clone() : null;
    o.RULE_TRM_RSL_LST_CON26 = (o.RULE_TRM_RSL_LST_CON26 != null) ? (org.apache.sqoop.lib.ClobRef) o.RULE_TRM_RSL_LST_CON26.clone() : null;
    o.RULE_TRM_RSL_LST_CON27 = (o.RULE_TRM_RSL_LST_CON27 != null) ? (org.apache.sqoop.lib.ClobRef) o.RULE_TRM_RSL_LST_CON27.clone() : null;
    o.RULE_TRM_RSL_LST_CON28 = (o.RULE_TRM_RSL_LST_CON28 != null) ? (org.apache.sqoop.lib.ClobRef) o.RULE_TRM_RSL_LST_CON28.clone() : null;
    o.RULE_TRM_RSL_LST_CON29 = (o.RULE_TRM_RSL_LST_CON29 != null) ? (org.apache.sqoop.lib.ClobRef) o.RULE_TRM_RSL_LST_CON29.clone() : null;
    o.RULE_TRM_RSL_LST_CON30 = (o.RULE_TRM_RSL_LST_CON30 != null) ? (org.apache.sqoop.lib.ClobRef) o.RULE_TRM_RSL_LST_CON30.clone() : null;
    o.RULE_TRM_RSL_LST_CON32 = (o.RULE_TRM_RSL_LST_CON32 != null) ? (org.apache.sqoop.lib.ClobRef) o.RULE_TRM_RSL_LST_CON32.clone() : null;
    o.MDEL_TRM_APL_RSL_VAL = (o.MDEL_TRM_APL_RSL_VAL != null) ? (org.apache.sqoop.lib.ClobRef) o.MDEL_TRM_APL_RSL_VAL.clone() : null;
  }

  public Map<String, Object> getFieldMap() {
    Map<String, Object> __sqoop$field_map = new HashMap<String, Object>();
    __sqoop$field_map.put("CLM_ID", this.CLM_ID);
    __sqoop$field_map.put("DMPE_ID", this.DMPE_ID);
    __sqoop$field_map.put("INF_OBM_FIX_SEQ", this.INF_OBM_FIX_SEQ);
    __sqoop$field_map.put("HIS_SEQ", this.HIS_SEQ);
    __sqoop$field_map.put("ACD_RCT_ID", this.ACD_RCT_ID);
    __sqoop$field_map.put("SPFC_DIVD_DIV_CD", this.SPFC_DIVD_DIV_CD);
    __sqoop$field_map.put("MORL_DIVD_DIV_CD", this.MORL_DIVD_DIV_CD);
    __sqoop$field_map.put("SCRG_SCR", this.SCRG_SCR);
    __sqoop$field_map.put("CLUNIT_CD", this.CLUNIT_CD);
    __sqoop$field_map.put("DTH_YN", this.DTH_YN);
    __sqoop$field_map.put("AFOBS_YN", this.AFOBS_YN);
    __sqoop$field_map.put("PRSM_INS_AMT", this.PRSM_INS_AMT);
    __sqoop$field_map.put("ACCM_DCN_INS_AMT", this.ACCM_DCN_INS_AMT);
    __sqoop$field_map.put("MD_EXP_CUS_GRDE_CD", this.MD_EXP_CUS_GRDE_CD);
    __sqoop$field_map.put("DDPY_CUS_GRDE_CD", this.DDPY_CUS_GRDE_CD);
    __sqoop$field_map.put("QUES_HOSP_YN", this.QUES_HOSP_YN);
    __sqoop$field_map.put("OBST_MORL_HOSP_YN", this.OBST_MORL_HOSP_YN);
    __sqoop$field_map.put("DDPY_ATTN_HOSP_YN", this.DDPY_ATTN_HOSP_YN);
    __sqoop$field_map.put("NSRY_ATTN_HOSP_YN", this.NSRY_ATTN_HOSP_YN);
    __sqoop$field_map.put("OWN_CTR_YN", this.OWN_CTR_YN);
    __sqoop$field_map.put("ACD_OCFQ_CUS_YN", this.ACD_OCFQ_CUS_YN);
    __sqoop$field_map.put("APPR_ACD_DD_DIV_CD", this.APPR_ACD_DD_DIV_CD);
    __sqoop$field_map.put("MORL_KR_DISZ_CD", this.MORL_KR_DISZ_CD);
    __sqoop$field_map.put("DISZ_CD_LST", this.DISZ_CD_LST);
    __sqoop$field_map.put("SPFC_TRTPE_YN", this.SPFC_TRTPE_YN);
    __sqoop$field_map.put("HIS_ST_DTM", this.HIS_ST_DTM);
    __sqoop$field_map.put("HIS_ED_DTM", this.HIS_ED_DTM);
    __sqoop$field_map.put("INPPE_ORG_ID", this.INPPE_ORG_ID);
    __sqoop$field_map.put("SYS_OCC_DTM", this.SYS_OCC_DTM);
    __sqoop$field_map.put("SYS_DEL_DIV_CD", this.SYS_DEL_DIV_CD);
    __sqoop$field_map.put("OCC_IP", this.OCC_IP);
    __sqoop$field_map.put("APP_ID", this.APP_ID);
    __sqoop$field_map.put("DATA_CHNG_DTM", this.DATA_CHNG_DTM);
    __sqoop$field_map.put("DGN_FEE1", this.DGN_FEE1);
    __sqoop$field_map.put("DGN_FEE2", this.DGN_FEE2);
    __sqoop$field_map.put("LAW_VLT_YN", this.LAW_VLT_YN);
    __sqoop$field_map.put("BAS_SCR", this.BAS_SCR);
    __sqoop$field_map.put("CHRPE_ORG_ID", this.CHRPE_ORG_ID);
    __sqoop$field_map.put("CHRPE_PART_ORG_ID", this.CHRPE_PART_ORG_ID);
    __sqoop$field_map.put("CHRPE_TEM_ORG_ID", this.CHRPE_TEM_ORG_ID);
    __sqoop$field_map.put("MORL_DIVD_DTL_CD", this.MORL_DIVD_DTL_CD);
    __sqoop$field_map.put("SPFC_DGN_MORL_YN", this.SPFC_DGN_MORL_YN);
    __sqoop$field_map.put("ETC_CON", this.ETC_CON);
    __sqoop$field_map.put("EIH_LDG_DTM", this.EIH_LDG_DTM);
    __sqoop$field_map.put("NURPE_SVC_RQE_YN", this.NURPE_SVC_RQE_YN);
    __sqoop$field_map.put("RULE_SQ_VAL", this.RULE_SQ_VAL);
    __sqoop$field_map.put("RULE_TRM_RSL_LST_CON20", this.RULE_TRM_RSL_LST_CON20);
    __sqoop$field_map.put("RULE_TRM_RSL_LST_CON26", this.RULE_TRM_RSL_LST_CON26);
    __sqoop$field_map.put("RULE_TRM_RSL_LST_CON27", this.RULE_TRM_RSL_LST_CON27);
    __sqoop$field_map.put("RULE_TRM_RSL_LST_CON28", this.RULE_TRM_RSL_LST_CON28);
    __sqoop$field_map.put("RULE_TRM_RSL_LST_CON29", this.RULE_TRM_RSL_LST_CON29);
    __sqoop$field_map.put("RULE_TRM_RSL_LST_CON30", this.RULE_TRM_RSL_LST_CON30);
    __sqoop$field_map.put("RULE_TRM_RSL_LST_CON32", this.RULE_TRM_RSL_LST_CON32);
    __sqoop$field_map.put("MDEL_APL_TRG_YN", this.MDEL_APL_TRG_YN);
    __sqoop$field_map.put("APL_BF_FLTR_TRM_VAL", this.APL_BF_FLTR_TRM_VAL);
    __sqoop$field_map.put("MDEL_APL_DIV_CD", this.MDEL_APL_DIV_CD);
    __sqoop$field_map.put("MDEL_TRM_APL_RSL_VAL", this.MDEL_TRM_APL_RSL_VAL);
    __sqoop$field_map.put("MDEL_DIV_CD_STD_VAL", this.MDEL_DIV_CD_STD_VAL);
    __sqoop$field_map.put("MDEL_CMPT_RSL_VAL", this.MDEL_CMPT_RSL_VAL);
    __sqoop$field_map.put("CMPT_SQ_CLUNIT_CD", this.CMPT_SQ_CLUNIT_CD);
    __sqoop$field_map.put("CMPT_SQ_DIVD_DIV_VAL", this.CMPT_SQ_DIVD_DIV_VAL);
    __sqoop$field_map.put("OS_ID", this.OS_ID);
    return __sqoop$field_map;
  }

  public void getFieldMap0(Map<String, Object> __sqoop$field_map) {
    __sqoop$field_map.put("CLM_ID", this.CLM_ID);
    __sqoop$field_map.put("DMPE_ID", this.DMPE_ID);
    __sqoop$field_map.put("INF_OBM_FIX_SEQ", this.INF_OBM_FIX_SEQ);
    __sqoop$field_map.put("HIS_SEQ", this.HIS_SEQ);
    __sqoop$field_map.put("ACD_RCT_ID", this.ACD_RCT_ID);
    __sqoop$field_map.put("SPFC_DIVD_DIV_CD", this.SPFC_DIVD_DIV_CD);
    __sqoop$field_map.put("MORL_DIVD_DIV_CD", this.MORL_DIVD_DIV_CD);
    __sqoop$field_map.put("SCRG_SCR", this.SCRG_SCR);
    __sqoop$field_map.put("CLUNIT_CD", this.CLUNIT_CD);
    __sqoop$field_map.put("DTH_YN", this.DTH_YN);
    __sqoop$field_map.put("AFOBS_YN", this.AFOBS_YN);
    __sqoop$field_map.put("PRSM_INS_AMT", this.PRSM_INS_AMT);
    __sqoop$field_map.put("ACCM_DCN_INS_AMT", this.ACCM_DCN_INS_AMT);
    __sqoop$field_map.put("MD_EXP_CUS_GRDE_CD", this.MD_EXP_CUS_GRDE_CD);
    __sqoop$field_map.put("DDPY_CUS_GRDE_CD", this.DDPY_CUS_GRDE_CD);
    __sqoop$field_map.put("QUES_HOSP_YN", this.QUES_HOSP_YN);
    __sqoop$field_map.put("OBST_MORL_HOSP_YN", this.OBST_MORL_HOSP_YN);
    __sqoop$field_map.put("DDPY_ATTN_HOSP_YN", this.DDPY_ATTN_HOSP_YN);
    __sqoop$field_map.put("NSRY_ATTN_HOSP_YN", this.NSRY_ATTN_HOSP_YN);
    __sqoop$field_map.put("OWN_CTR_YN", this.OWN_CTR_YN);
    __sqoop$field_map.put("ACD_OCFQ_CUS_YN", this.ACD_OCFQ_CUS_YN);
    __sqoop$field_map.put("APPR_ACD_DD_DIV_CD", this.APPR_ACD_DD_DIV_CD);
    __sqoop$field_map.put("MORL_KR_DISZ_CD", this.MORL_KR_DISZ_CD);
    __sqoop$field_map.put("DISZ_CD_LST", this.DISZ_CD_LST);
    __sqoop$field_map.put("SPFC_TRTPE_YN", this.SPFC_TRTPE_YN);
    __sqoop$field_map.put("HIS_ST_DTM", this.HIS_ST_DTM);
    __sqoop$field_map.put("HIS_ED_DTM", this.HIS_ED_DTM);
    __sqoop$field_map.put("INPPE_ORG_ID", this.INPPE_ORG_ID);
    __sqoop$field_map.put("SYS_OCC_DTM", this.SYS_OCC_DTM);
    __sqoop$field_map.put("SYS_DEL_DIV_CD", this.SYS_DEL_DIV_CD);
    __sqoop$field_map.put("OCC_IP", this.OCC_IP);
    __sqoop$field_map.put("APP_ID", this.APP_ID);
    __sqoop$field_map.put("DATA_CHNG_DTM", this.DATA_CHNG_DTM);
    __sqoop$field_map.put("DGN_FEE1", this.DGN_FEE1);
    __sqoop$field_map.put("DGN_FEE2", this.DGN_FEE2);
    __sqoop$field_map.put("LAW_VLT_YN", this.LAW_VLT_YN);
    __sqoop$field_map.put("BAS_SCR", this.BAS_SCR);
    __sqoop$field_map.put("CHRPE_ORG_ID", this.CHRPE_ORG_ID);
    __sqoop$field_map.put("CHRPE_PART_ORG_ID", this.CHRPE_PART_ORG_ID);
    __sqoop$field_map.put("CHRPE_TEM_ORG_ID", this.CHRPE_TEM_ORG_ID);
    __sqoop$field_map.put("MORL_DIVD_DTL_CD", this.MORL_DIVD_DTL_CD);
    __sqoop$field_map.put("SPFC_DGN_MORL_YN", this.SPFC_DGN_MORL_YN);
    __sqoop$field_map.put("ETC_CON", this.ETC_CON);
    __sqoop$field_map.put("EIH_LDG_DTM", this.EIH_LDG_DTM);
    __sqoop$field_map.put("NURPE_SVC_RQE_YN", this.NURPE_SVC_RQE_YN);
    __sqoop$field_map.put("RULE_SQ_VAL", this.RULE_SQ_VAL);
    __sqoop$field_map.put("RULE_TRM_RSL_LST_CON20", this.RULE_TRM_RSL_LST_CON20);
    __sqoop$field_map.put("RULE_TRM_RSL_LST_CON26", this.RULE_TRM_RSL_LST_CON26);
    __sqoop$field_map.put("RULE_TRM_RSL_LST_CON27", this.RULE_TRM_RSL_LST_CON27);
    __sqoop$field_map.put("RULE_TRM_RSL_LST_CON28", this.RULE_TRM_RSL_LST_CON28);
    __sqoop$field_map.put("RULE_TRM_RSL_LST_CON29", this.RULE_TRM_RSL_LST_CON29);
    __sqoop$field_map.put("RULE_TRM_RSL_LST_CON30", this.RULE_TRM_RSL_LST_CON30);
    __sqoop$field_map.put("RULE_TRM_RSL_LST_CON32", this.RULE_TRM_RSL_LST_CON32);
    __sqoop$field_map.put("MDEL_APL_TRG_YN", this.MDEL_APL_TRG_YN);
    __sqoop$field_map.put("APL_BF_FLTR_TRM_VAL", this.APL_BF_FLTR_TRM_VAL);
    __sqoop$field_map.put("MDEL_APL_DIV_CD", this.MDEL_APL_DIV_CD);
    __sqoop$field_map.put("MDEL_TRM_APL_RSL_VAL", this.MDEL_TRM_APL_RSL_VAL);
    __sqoop$field_map.put("MDEL_DIV_CD_STD_VAL", this.MDEL_DIV_CD_STD_VAL);
    __sqoop$field_map.put("MDEL_CMPT_RSL_VAL", this.MDEL_CMPT_RSL_VAL);
    __sqoop$field_map.put("CMPT_SQ_CLUNIT_CD", this.CMPT_SQ_CLUNIT_CD);
    __sqoop$field_map.put("CMPT_SQ_DIVD_DIV_VAL", this.CMPT_SQ_DIVD_DIV_VAL);
    __sqoop$field_map.put("OS_ID", this.OS_ID);
  }

  public void setField(String __fieldName, Object __fieldVal) {
    if (!setters.containsKey(__fieldName)) {
      throw new RuntimeException("No such field:"+__fieldName);
    }
    setters.get(__fieldName).setField(__fieldVal);
  }

}
