#!/bin/bash

if [ $# -eq 0 ]
then           
    ARGS=N    
else           
    ARGS=$1
fi             

NOW=$(date +"+%Y-%m-%d_%T")
SHLOG_DIR=/sqoopbin/scripts/etlpgm/cur_log
HISLOG_DIR=/sqoopbin/scripts/etlpgm/his_log

export HADOOP_OPTS=-Djava.security.egd=file:/dev/../dev/urandom
export ORACLE_BASE=/sw/oracle
export ORACLE_HOME=/sw/oracle/product/11.2.0.4/client_1
export LD_LIBRARY_PATH=/sw/oracle/product/11.2.0.4/client_1/lib:/sw/oracle/product/11.2.0.4/client_1/lib:
export PATH=/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/usr/lib64/qt-3.3/bin:/usr/hdp/3.0.0.0-1634/spark2/bin/:/var/opt/node/bin/:/opt/maven/bin:/usr/local/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/home/hdpapp/workspace/data-science-at-the-command-line/tools:/home/hdpapp/.local/bin:/home/hdpapp/bin
export TNS_ADMIN=/sw/oracle/product/11.2.0.4/client_1/network/admin
export ORACLE_SID=DBEDWP2
export NLS_LANG=American_America.KO16MSWIN949

#----------------------------------------------------#
# 작업내용 : TMLMB_LCMNRT 테이블 sqoop 복제 작업
# 작업주기 :  
#----------------------------------------------------#

    echo " "
    echo "*-----------[ TMLMB_LCMNRT.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ TMLMB_LCMNRT.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`  >  ${SHLOG_DIR}/TMLMB_LCMNRT.shlog

#----------------------------------------------------#
# 테이블별 전체 데이터를 받아 오는 부분
#----------------------------------------------------#
    /usr/bin/hadoop fs -rm -r -f  /tmp2/LAST_TMLMB_LCMNRT  >> ${SHLOG_DIR}/TMLMB_LCMNRT.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.LAST_TMLMB_LCMNRT ; " >> ${SHLOG_DIR}/TMLMB_LCMNRT.shlog 2>&1 &&
    /usr/hdp/3.0.0.0-1634/sqoop/bin/sqoop import -D mapred.child.java.opts="-Djava.security.egd=file:/dev/../dev/urandom" \
    --connect jdbc:oracle:thin:EDWHADOOP/wjdqhrP\!23@10.91.41.172:12560:DBEDWP2 \
    --username  EDWHADOOP \
    --password wjdqhrP\!23 \
    --query "SELECT /*+ FULL(TMLMB_LCMNRT) */ REPLACE(REPLACE(STD_YYMM,CHR(13),''),CHR(10),'') STD_YYMM
, REPLACE(REPLACE(CTR_ID,CHR(13),''),CHR(10),'') CTR_ID
, CTR_MTN_TMS
, REPLACE(REPLACE(DATA_DIV_CD,CHR(13),''),CHR(10),'') DATA_DIV_CD
, REPLACE(REPLACE(DATA_ID,CHR(13),''),CHR(10),'') DATA_ID
, REPLACE(REPLACE(CTR_OBJ_ID,CHR(13),''),CHR(10),'') CTR_OBJ_ID
, REPLACE(REPLACE(COV_CD,CHR(13),''),CHR(10),'') COV_CD
, REPLACE(REPLACE(POL_NO,CHR(13),''),CHR(10),'') POL_NO
, REPLACE(REPLACE(SAL_PD_CD,CHR(13),''),CHR(10),'') SAL_PD_CD
, REPLACE(REPLACE(UNT_PD_CD,CHR(13),''),CHR(10),'') UNT_PD_CD
, REPLACE(REPLACE(RPS_PD_CD,CHR(13),''),CHR(10),'') RPS_PD_CD
, REPLACE(REPLACE(LANN_DIV_CD,CHR(13),''),CHR(10),'') LANN_DIV_CD
, REPLACE(REPLACE(OD_STIC_PD_CTG_CD,CHR(13),''),CHR(10),'') OD_STIC_PD_CTG_CD
, REPLACE(REPLACE(NW_STIC_PD_CTG_CD,CHR(13),''),CHR(10),'') NW_STIC_PD_CTG_CD
, REPLACE(REPLACE(GURT_SAV_DIV_CD,CHR(13),''),CHR(10),'') GURT_SAV_DIV_CD
, REPLACE(REPLACE(STIC_IDC_PD_CTG_CD,CHR(13),''),CHR(10),'') STIC_IDC_PD_CTG_CD
, INS_BGN_DT
, INS_ED_DT
, REPLACE(REPLACE(CTR_STAT_CD,CHR(13),''),CHR(10),'') CTR_STAT_CD
, REPLACE(REPLACE(CTR_STAT_DTL_CD,CHR(13),''),CHR(10),'') CTR_STAT_DTL_CD
, REPLACE(REPLACE(PY_CYC_CD,CHR(13),''),CHR(10),'') PY_CYC_CD
, REPLACE(REPLACE(MNCL_MD_CD,CHR(13),''),CHR(10),'') MNCL_MD_CD
, LAST_PY_TMS
, REPLACE(REPLACE(LAST_PY_YYMM,CHR(13),''),CHR(10),'') LAST_PY_YYMM
, REPLACE(REPLACE(CLLPE_ORG_ID,CHR(13),''),CHR(10),'') CLLPE_ORG_ID
, REPLACE(REPLACE(CLLPE_ORG_CD,CHR(13),''),CHR(10),'') CLLPE_ORG_CD
, REPLACE(REPLACE(CLLPE_UW_APL_GRDE_CD,CHR(13),''),CHR(10),'') CLLPE_UW_APL_GRDE_CD
, CLLPE_ENTCO_DMM
, REPLACE(REPLACE(CLLPE_FRD_YN,CHR(13),''),CHR(10),'') CLLPE_FRD_YN
, REPLACE(REPLACE(TRT_SMRZ_ORG_ID,CHR(13),''),CHR(10),'') TRT_SMRZ_ORG_ID
, REPLACE(REPLACE(TRT_SMRZ_ORG_CD,CHR(13),''),CHR(10),'') TRT_SMRZ_ORG_CD
, REPLACE(REPLACE(TRT_HDQT_ORG_ID,CHR(13),''),CHR(10),'') TRT_HDQT_ORG_ID
, REPLACE(REPLACE(TRT_HDQT_ORG_CD,CHR(13),''),CHR(10),'') TRT_HDQT_ORG_CD
, REPLACE(REPLACE(TRT_BRCH_ORG_ID,CHR(13),''),CHR(10),'') TRT_BRCH_ORG_ID
, REPLACE(REPLACE(TRT_BRCH_ORG_CD,CHR(13),''),CHR(10),'') TRT_BRCH_ORG_CD
, REPLACE(REPLACE(TBCHDR_TEM_ORG_ID,CHR(13),''),CHR(10),'') TBCHDR_TEM_ORG_ID
, REPLACE(REPLACE(TBCHDR_TEM_ORG_CD,CHR(13),''),CHR(10),'') TBCHDR_TEM_ORG_CD
, REPLACE(REPLACE(TRT_BCH_ORG_ID,CHR(13),''),CHR(10),'') TRT_BCH_ORG_ID
, REPLACE(REPLACE(TRT_BCH_ORG_CD,CHR(13),''),CHR(10),'') TRT_BCH_ORG_CD
, REPLACE(REPLACE(TRTPE_ORG_ID,CHR(13),''),CHR(10),'') TRTPE_ORG_ID
, REPLACE(REPLACE(TRTPE_ORG_CD,CHR(13),''),CHR(10),'') TRTPE_ORG_CD
, REPLACE(REPLACE(TRT_RLMR_ORG_ID,CHR(13),''),CHR(10),'') TRT_RLMR_ORG_ID
, REPLACE(REPLACE(TRT_RLMR_ORG_CD,CHR(13),''),CHR(10),'') TRT_RLMR_ORG_CD
, REPLACE(REPLACE(TRT_AGC_BROF_ORG_ID,CHR(13),''),CHR(10),'') TRT_AGC_BROF_ORG_ID
, REPLACE(REPLACE(TRT_AGC_BROF_ORG_CD,CHR(13),''),CHR(10),'') TRT_AGC_BROF_ORG_CD
, REPLACE(REPLACE(TRT_AGPLR_ORG_ID,CHR(13),''),CHR(10),'') TRT_AGPLR_ORG_ID
, REPLACE(REPLACE(TRT_AGPLR_ORG_CD,CHR(13),''),CHR(10),'') TRT_AGPLR_ORG_CD
, REPLACE(REPLACE(CHN_DIV_CD,CHR(13),''),CHR(10),'') CHN_DIV_CD
, REPLACE(REPLACE(SBCP_CHN_DIV_CD,CHR(13),''),CHR(10),'') SBCP_CHN_DIV_CD
, REPLACE(REPLACE(TRTPE_UW_APL_GRDE_CD,CHR(13),''),CHR(10),'') TRTPE_UW_APL_GRDE_CD
, REPLACE(REPLACE(OWN_CTR_YN,CHR(13),''),CHR(10),'') OWN_CTR_YN
, REPLACE(REPLACE(TRTPE_CHNG_YN,CHR(13),''),CHR(10),'') TRTPE_CHNG_YN
, REPLACE(REPLACE(NMNT_RSN_CD,CHR(13),''),CHR(10),'') NMNT_RSN_CD
, INS_PRD_YR_NUM
, MTN_DMM
, NW_CTR_CNT
, MTN_CTR_CNT
, NW_CTR_PREM
, NW_CTR_GURT_PREM
, NCTYC_PREM
, MTN_CTR_PREM
, MTN_CTR_GURT_PREM
, MCTYC_PREM
, EIH_LDG_DTM FROM TMLMB_LCMNRT
                       WHERE \$CONDITIONS "\
    --m 8 \
    --boundary-query "SELECT 0, 7 FROM DUAL"\
    --split-by "ORA_HASH(CTR_ID, 7)"\
    --target-dir /tmp2/LAST_TMLMB_LCMNRT \
    --hive-import \
    --external-table-dir hdfs:///tmp2/temp_tbl/LAST_TMLMB_LCMNRT \
    --hive-overwrite \
    --hive-table DEFAULT.LAST_TMLMB_LCMNRT  >> ${SHLOG_DIR}/TMLMB_LCMNRT.shlog 2>&1 &&

#----------------------------------------------------#
# Hadoop 원본테이블에 변경분 최종 적용
#----------------------------------------------------#
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.TMLMB_LCMNRT_TMP ; " >> ${SHLOG_DIR}/TMLMB_LCMNRT.shlog 2>&1 &&
    /usr/bin/hive -e "CREATE EXTERNAL TABLE MERITZ.TMLMB_LCMNRT_TMP STORED AS PARQUET TBLPROPERTIES ('PARQUET.COMPRESS'='SNAPPY') AS
                                SELECT *
                                FROM DEFAULT.LAST_TMLMB_LCMNRT ;" >> ${SHLOG_DIR}/TMLMB_LCMNRT.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.LAST_TMLMB_LCMNRT ;" >> ${SHLOG_DIR}/TMLMB_LCMNRT.shlog 2>&1 &&
    /usr/bin/hdfs dfs -rm -r -f -skipTrash /warehouse/tablespace/external/hive/last_tmlmb_lcmnrt >> ${SHLOG_DIR}/TMLMB_LCMNRT.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.TMLMB_LCMNRT ;" >> ${SHLOG_DIR}/TMLMB_LCMNRT.shlog 2>&1 &&
    /usr/bin/hive -e "ALTER TABLE MERITZ.TMLMB_LCMNRT_TMP RENAME TO MERITZ.TMLMB_LCMNRT ;" >> ${SHLOG_DIR}/TMLMB_LCMNRT.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.TMLMB_LCMNRT_TMP ;" >> ${SHLOG_DIR}/TMLMB_LCMNRT.shlog 2>&1 

if [ $? -ne 0 ]
then             
    echo "*-----------[ TMLMB_LCMNRT.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/TMLMB_LCMNRT.shlog"
    echo "*-----------[ TMLMB_LCMNRT.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/TMLMB_LCMNRT.shlog"  >>  ${SHLOG_DIR}/TMLMB_LCMNRT.shlog
    echo "*-----------[ TMLMB_LCMNRT.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ TMLMB_LCMNRT.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/TMLMB_LCMNRT.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/TMLMB_LCMNRT.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/TMLMB_LCMNRT.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/TMLMB_LCMNRT.shlog /sqoopbin/scripts/etlpgm/his_log/TMLMB_LCMNRT_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  TMLMB_LCMNRT.sh cmd command error !! ***
    fi               

    exit -1      

else             
    echo "*-----------[ TMLMB_LCMNRT.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ TMLMB_LCMNRT.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/TMLMB_LCMNRT.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/TMLMB_LCMNRT.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/TMLMB_LCMNRT.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/TMLMB_LCMNRT.shlog /sqoopbin/scripts/etlpgm/his_log/TMLMB_LCMNRT_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  TMLMB_LCMNRT.sh cmd command error !! ***
        exit -1      
    else             
        exit 0       
    fi               
fi               
