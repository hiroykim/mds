#!/bin/bash

if [ $# -eq 0 ]
then           
    ARGS=N    
else           
    ARGS=$1
fi             

NOW=$(date +"+%Y-%m-%d_%T")
SHLOG_DIR=/sqoopbin/scripts/etlpgm/cur_log
HISLOG_DIR=/sqoopbin/scripts/etlpgm/his_log

export HADOOP_OPTS=-Djava.security.egd=file:/dev/../dev/urandom
export ORACLE_BASE=/sw/oracle
export ORACLE_HOME=/sw/oracle/product/11.2.0.4/client_1
export LD_LIBRARY_PATH=/sw/oracle/product/11.2.0.4/client_1/lib:/sw/oracle/product/11.2.0.4/client_1/lib:
export PATH=/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/usr/lib64/qt-3.3/bin:/usr/hdp/3.0.0.0-1634/spark2/bin/:/var/opt/node/bin/:/opt/maven/bin:/usr/local/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/home/hdpapp/workspace/data-science-at-the-command-line/tools:/home/hdpapp/.local/bin:/home/hdpapp/bin
export TNS_ADMIN=/sw/oracle/product/11.2.0.4/client_1/network/admin
export ORACLE_SID=DBEDWP2
export NLS_LANG=American_America.KO16MSWIN949

#----------------------------------------------------#
# 작업내용 : THDDH_TCTSNCDTL 테이블 sqoop 복제 작업
# 작업주기 :  
#----------------------------------------------------#

    echo " "
    echo "*-----------[ THDDH_TCTSNCDTL.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TCTSNCDTL.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`  >  ${SHLOG_DIR}/THDDH_TCTSNCDTL.shlog

#----------------------------------------------------#
# 테이블별 전체 데이터를 받아 오는 부분
#----------------------------------------------------#
    /usr/bin/hadoop fs -rm -r -f  /tmp2/LAST_THDDH_TCTSNCDTL  >> ${SHLOG_DIR}/THDDH_TCTSNCDTL.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.LAST_THDDH_TCTSNCDTL ; " >> ${SHLOG_DIR}/THDDH_TCTSNCDTL.shlog 2>&1 &&
    /usr/hdp/3.0.0.0-1634/sqoop/bin/sqoop import -D mapred.child.java.opts="-Djava.security.egd=file:/dev/../dev/urandom" \
    --connect jdbc:oracle:thin:EDWHADOOP/wjdqhrP\!23@10.91.41.172:12560:DBEDWP2 \
    --username  EDWHADOOP \
    --password wjdqhrP\!23 \
    --query "SELECT /*+ FULL(THDDH_TCTSNCDTL) */ REPLACE(REPLACE(CTR_ID,CHR(13),''),CHR(10),'') CTR_ID
, DETL_SEQ
, REPLACE(REPLACE(BIZ_SYS_CD,CHR(13),''),CHR(10),'') BIZ_SYS_CD
, REPLACE(REPLACE(CTR_OBJ_ID,CHR(13),''),CHR(10),'') CTR_OBJ_ID
, REPLACE(REPLACE(UW_ID,CHR(13),''),CHR(10),'') UW_ID
, SNC_ISP_SEQ
, REPLACE(REPLACE(ACP_RSTR_TP_CD,CHR(13),''),CHR(10),'') ACP_RSTR_TP_CD
, REPLACE(REPLACE(ACP_RSTR_CD,CHR(13),''),CHR(10),'') ACP_RSTR_CD
, REPLACE(REPLACE(ACP_RSTR_TRG_ID,CHR(13),''),CHR(10),'') ACP_RSTR_TRG_ID
, REPLACE(REPLACE(ACP_ISP_KD_CD,CHR(13),''),CHR(10),'') ACP_ISP_KD_CD
, REPLACE(REPLACE(SNC_DIV_CD,CHR(13),''),CHR(10),'') SNC_DIV_CD
, REPLACE(REPLACE(GNR_EMB_ISP_DIV_CD,CHR(13),''),CHR(10),'') GNR_EMB_ISP_DIV_CD
, REPLACE(REPLACE(ACP_RSTR_TRM_VAL,CHR(13),''),CHR(10),'') ACP_RSTR_TRM_VAL
, REPLACE(REPLACE(ACP_RSTR_CON,CHR(13),''),CHR(10),'') ACP_RSTR_CON
, REPLACE(REPLACE(ACP_RSTR_GRDE_VAL,CHR(13),''),CHR(10),'') ACP_RSTR_GRDE_VAL
, REPLACE(REPLACE(ISP_CON,CHR(13),''),CHR(10),'') ISP_CON
, REPLACE(REPLACE(ISP_CON2,CHR(13),''),CHR(10),'') ISP_CON2
, REPLACE(REPLACE(APVL_STAT_CD,CHR(13),''),CHR(10),'') APVL_STAT_CD
, APL_ST_DT
, APL_ED_DT
, REPLACE(REPLACE(INPPE_ORG_ID,CHR(13),''),CHR(10),'') INPPE_ORG_ID
, SYS_OCC_DTM
, REPLACE(REPLACE(SYS_DEL_DIV_CD,CHR(13),''),CHR(10),'') SYS_DEL_DIV_CD
, REPLACE(REPLACE(OCC_IP,CHR(13),''),CHR(10),'') OCC_IP
, REPLACE(REPLACE(APP_ID,CHR(13),''),CHR(10),'') APP_ID
, DATA_CHNG_DTM
, REPLACE(REPLACE(ATL_CTR_ID,CHR(13),''),CHR(10),'') ATL_CTR_ID
, EIH_LDG_DTM
, REPLACE(REPLACE(NTFY_RCI_ORG_ID,CHR(13),''),CHR(10),'') NTFY_RCI_ORG_ID
, REPLACE(REPLACE(ICPS_ACP_ISP_CD,CHR(13),''),CHR(10),'') ICPS_ACP_ISP_CD
, REPLACE(REPLACE(ICPS_CON,CHR(13),''),CHR(10),'') ICPS_CON
, REPLACE(REPLACE(ICIS_CON,CHR(13),''),CHR(10),'') ICIS_CON
, REPLACE(REPLACE(THCO_COMS_CON,CHR(13),''),CHR(10),'') THCO_COMS_CON
, REPLACE(REPLACE(ISP_REQ_RSN_CON,CHR(13),''),CHR(10),'') ISP_REQ_RSN_CON
, REPLACE(REPLACE(ISP_CON3,CHR(13),''),CHR(10),'') ISP_CON3
, REPLACE(REPLACE(ISP_CON4,CHR(13),''),CHR(10),'') ISP_CON4
, REPLACE(REPLACE(CAR_ISP_TP_CD,CHR(13),''),CHR(10),'') CAR_ISP_TP_CD FROM THDDH_TCTSNCDTL
                       WHERE \$CONDITIONS "\
    --m 8 \
    --boundary-query "SELECT 0, 7 FROM DUAL"\
    --split-by "ORA_HASH(CTR_ID, 7)"\
    --target-dir /tmp2/LAST_THDDH_TCTSNCDTL \
    --hive-import \
    --external-table-dir hdfs:///tmp2/temp_tbl/LAST_THDDH_TCTSNCDTL \
    --hive-overwrite \
    --hive-table DEFAULT.LAST_THDDH_TCTSNCDTL  >> ${SHLOG_DIR}/THDDH_TCTSNCDTL.shlog 2>&1 &&

#----------------------------------------------------#
# Hadoop 원본테이블에 변경분 최종 적용
#----------------------------------------------------#
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TCTSNCDTL_TMP ; " >> ${SHLOG_DIR}/THDDH_TCTSNCDTL.shlog 2>&1 &&
    /usr/bin/hive -e "CREATE EXTERNAL TABLE MERITZ.THDDH_TCTSNCDTL_TMP STORED AS PARQUET TBLPROPERTIES ('PARQUET.COMPRESS'='SNAPPY') AS
                                SELECT *
                                FROM DEFAULT.LAST_THDDH_TCTSNCDTL ;" >> ${SHLOG_DIR}/THDDH_TCTSNCDTL.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.LAST_THDDH_TCTSNCDTL ;" >> ${SHLOG_DIR}/THDDH_TCTSNCDTL.shlog 2>&1 &&
    /usr/bin/hdfs dfs -rm -r -f -skipTrash /warehouse/tablespace/external/hive/last_thddh_tctsncdtl >> ${SHLOG_DIR}/THDDH_TCTSNCDTL.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TCTSNCDTL ;" >> ${SHLOG_DIR}/THDDH_TCTSNCDTL.shlog 2>&1 &&
    /usr/bin/hive -e "ALTER TABLE MERITZ.THDDH_TCTSNCDTL_TMP RENAME TO MERITZ.THDDH_TCTSNCDTL ;" >> ${SHLOG_DIR}/THDDH_TCTSNCDTL.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TCTSNCDTL_TMP ;" >> ${SHLOG_DIR}/THDDH_TCTSNCDTL.shlog 2>&1 

if [ $? -ne 0 ]
then             
    echo "*-----------[ THDDH_TCTSNCDTL.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/THDDH_TCTSNCDTL.shlog"
    echo "*-----------[ THDDH_TCTSNCDTL.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/THDDH_TCTSNCDTL.shlog"  >>  ${SHLOG_DIR}/THDDH_TCTSNCDTL.shlog
    echo "*-----------[ THDDH_TCTSNCDTL.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TCTSNCDTL.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/THDDH_TCTSNCDTL.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/THDDH_TCTSNCDTL.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCTSNCDTL.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCTSNCDTL.shlog /sqoopbin/scripts/etlpgm/his_log/THDDH_TCTSNCDTL_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  THDDH_TCTSNCDTL.sh cmd command error !! ***
    fi               

    exit -1      

else             
    echo "*-----------[ THDDH_TCTSNCDTL.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TCTSNCDTL.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/THDDH_TCTSNCDTL.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/THDDH_TCTSNCDTL.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCTSNCDTL.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCTSNCDTL.shlog /sqoopbin/scripts/etlpgm/his_log/THDDH_TCTSNCDTL_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  THDDH_TCTSNCDTL.sh cmd command error !! ***
        exit -1      
    else             
        exit 0       
    fi               
fi               
