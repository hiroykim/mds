#!/bin/bash

if [ $# -eq 0 ]
then
  MAX_PROCESS_CNT=5
else
  MAX_PROCESS_CNT=$1
fi

NOW=$(date +"+%Y-%m-%d_%T")
FLOW_LOG_DIR=/sqoopbin/scripts/etlpgm/flow_log/
FLOW_LOG=$FLOW_LOG_DIR"execute_all_"$NOW".shlog"

echo $FLOW_LOG

i=0

SCRIPT_LIST=(`ls -l /sqoopbin/scripts/etlpgm/bin/ | awk '{print $9}'`)

TOTAL_TASK_CNT=${#SCRIPT_LIST[*]}

echo "num of script files :" $TOTAL_TASK_CNT >> ${FLOW_LOG}

while [ $i -lt $TOTAL_TASK_CNT ]
  do
    CURRENT_PROCESS_CNT=`ps -ef | grep /sqoopbin/scripts/etlpgm/bin/ | grep -v grep | wc -l`
    #echo "checking::: is new script able to execute?"		>> ${FLOW_LOG} 
    #echo "  - current task num: " $CURRENT_PROCESS_CNT		>> ${FLOW_LOG}
    #echo "  - max task num: " $MAX_PROCESS_CNT			>> ${FLOW_LOG}

    NEW_TASK_NUM=`expr $MAX_PROCESS_CNT - $CURRENT_PROCESS_CNT`
    j=0

    while [ $j -lt $NEW_TASK_NUM ] && [ $i -lt $TOTAL_TASK_CNT ]
    do
      echo "---------------------start ${SCRIPT_LIST[$i]} ----  " `date '+%Y-%m-%d %T'`	>> ${FLOW_LOG}
      /sqoopbin/scripts/etlpgm/bin/"${SCRIPT_LIST[$i]}" &
      i=$(($i+1))
      j=$(($j+1))
    done 

    sleep 60

done
