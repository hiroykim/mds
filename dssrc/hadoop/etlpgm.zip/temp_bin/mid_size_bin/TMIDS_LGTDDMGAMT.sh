#!/bin/bash

if [ $# -eq 0 ]
then           
    ARGS=N    
else           
    ARGS=$1
fi             

NOW=$(date +"+%Y-%m-%d_%T")
SHLOG_DIR=/sqoopbin/scripts/etlpgm/cur_log
HISLOG_DIR=/sqoopbin/scripts/etlpgm/his_log

export HADOOP_OPTS=-Djava.security.egd=file:/dev/../dev/urandom
export ORACLE_BASE=/sw/oracle
export ORACLE_HOME=/sw/oracle/product/11.2.0.4/client_1
export LD_LIBRARY_PATH=/sw/oracle/product/11.2.0.4/client_1/lib:/sw/oracle/product/11.2.0.4/client_1/lib:
export PATH=/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/usr/lib64/qt-3.3/bin:/usr/hdp/3.0.0.0-1634/spark2/bin/:/var/opt/node/bin/:/opt/maven/bin:/usr/local/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/home/hdpapp/workspace/data-science-at-the-command-line/tools:/home/hdpapp/.local/bin:/home/hdpapp/bin
export TNS_ADMIN=/sw/oracle/product/11.2.0.4/client_1/network/admin
export ORACLE_SID=DBEDWP2
export NLS_LANG=American_America.KO16MSWIN949

#----------------------------------------------------#
# 작업내용 : TMIDS_LGTDDMGAMT 테이블 sqoop 복제 작업
# 작업주기 :  
#----------------------------------------------------#

    echo " "
    echo "*-----------[ TMIDS_LGTDDMGAMT.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ TMIDS_LGTDDMGAMT.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`  >  ${SHLOG_DIR}/TMIDS_LGTDDMGAMT.shlog

#----------------------------------------------------#
# Hadoop 원본테이블에 변경분 최종 적용
#----------------------------------------------------#
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.TMIDS_LGTDDMGAMT_TMP ; " >> ${SHLOG_DIR}/TMIDS_LGTDDMGAMT.shlog 2>&1 &&
    /usr/bin/hive -e "CREATE EXTERNAL TABLE MERITZ.TMIDS_LGTDDMGAMT_TMP STORED AS PARQUET TBLPROPERTIES ('PARQUET.COMPRESS'='SNAPPY') AS
                                SELECT *
                                FROM DEFAULT.LAST_TMIDS_LGTDDMGAMT ;" >> ${SHLOG_DIR}/TMIDS_LGTDDMGAMT.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.LAST_TMIDS_LGTDDMGAMT ;" >> ${SHLOG_DIR}/TMIDS_LGTDDMGAMT.shlog 2>&1 &&
    /usr/bin/hdfs dfs -rm -r -f -skipTrash /warehouse/tablespace/external/hive/last_tmids_lgtddmgamt >> ${SHLOG_DIR}/TMIDS_LGTDDMGAMT.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.TMIDS_LGTDDMGAMT ;" >> ${SHLOG_DIR}/TMIDS_LGTDDMGAMT.shlog 2>&1 &&
    /usr/bin/hive -e "ALTER TABLE MERITZ.TMIDS_LGTDDMGAMT_TMP RENAME TO MERITZ.TMIDS_LGTDDMGAMT ;" >> ${SHLOG_DIR}/TMIDS_LGTDDMGAMT.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.TMIDS_LGTDDMGAMT_TMP ;" >> ${SHLOG_DIR}/TMIDS_LGTDDMGAMT.shlog 2>&1 

if [ $? -ne 0 ]
then             
    echo "*-----------[ TMIDS_LGTDDMGAMT.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/TMIDS_LGTDDMGAMT.shlog"
    echo "*-----------[ TMIDS_LGTDDMGAMT.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/TMIDS_LGTDDMGAMT.shlog"  >>  ${SHLOG_DIR}/TMIDS_LGTDDMGAMT.shlog
    echo "*-----------[ TMIDS_LGTDDMGAMT.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ TMIDS_LGTDDMGAMT.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/TMIDS_LGTDDMGAMT.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/TMIDS_LGTDDMGAMT.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/TMIDS_LGTDDMGAMT.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/TMIDS_LGTDDMGAMT.shlog /sqoopbin/scripts/etlpgm/his_log/TMIDS_LGTDDMGAMT_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  TMIDS_LGTDDMGAMT.sh cmd command error !! ***
    fi               

    exit -1      

else             
    echo "*-----------[ TMIDS_LGTDDMGAMT.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ TMIDS_LGTDDMGAMT.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/TMIDS_LGTDDMGAMT.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/TMIDS_LGTDDMGAMT.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/TMIDS_LGTDDMGAMT.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/TMIDS_LGTDDMGAMT.shlog /sqoopbin/scripts/etlpgm/his_log/TMIDS_LGTDDMGAMT_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  TMIDS_LGTDDMGAMT.sh cmd command error !! ***
        exit -1      
    else             
        exit 0       
    fi               
fi               
