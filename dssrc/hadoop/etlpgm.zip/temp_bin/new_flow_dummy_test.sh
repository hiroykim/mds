#!/bin/bash

if [ $# -eq 0 ]
then
  MAX_PROCESS=2
else
  MAX_PROCESS=$1
fi

echo $#
echo "max process = $MAX_PROCESS"

i=0

#NUM_TASK=`ls -l /sqoopbin/scripts/etlpgm/temp_bin/test_dir/ | wc -l`
#list=(`ls -l /sqoopbin/scripts/etlpgm/temp_bin/test_dir_dummy/ | awk '{print $9}'`)

list=(`ls -l /sqoopbin/scripts/etlpgm/temp_bin/test_dir_dummy/ | awk '{print $9}'`)

NUM_TASK=${#list[*]}

echo "num of script files " $NUM_TASK

while [ $i -lt $NUM_TASK ]
  do
    CURRENT_TASK_NUM=`ps -ef | grep /sqoopbin/scripts/etlpgm/temp_bin/test_dir_dummy | grep -v grep | wc -l`
    echo "current task num: " $CURRENT_TASK_NUM
    if [ $CURRENT_TASK_NUM -lt $MAX_PROCESS ]
    then
      echo "start ${list[$i]}"
      /sqoopbin/scripts/etlpgm/temp_bin/test_dir_dummy/"${list[$i]}" &
      i=$(($i+1))
    fi
    sleep 1
done
