#!/bin/bash

if [ $# -eq 0 ]
then           
    ARGS=N    
else           
    ARGS=$1
fi             

NOW=$(date +"+%Y-%m-%d_%T")
SHLOG_DIR=/sqoopbin/scripts/etlpgm/cur_log
HISLOG_DIR=/sqoopbin/scripts/etlpgm/his_log

export HADOOP_OPTS=-Djava.security.egd=file:/dev/../dev/urandom
export ORACLE_BASE=/sw/oracle
export ORACLE_HOME=/sw/oracle/product/11.2.0.4/client_1
export LD_LIBRARY_PATH=/sw/oracle/product/11.2.0.4/client_1/lib:/sw/oracle/product/11.2.0.4/client_1/lib:
export PATH=/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/usr/lib64/qt-3.3/bin:/var/opt/node/bin/:/usr/hdp/3.0.0.0-1634/spark2/bin/:/opt/maven/bin:/usr/local/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/home/hdpapp/.local/bin:/home/hdpapp/bin
export TNS_ADMIN=/sw/oracle/product/11.2.0.4/client_1/network/admin
export ORACLE_SID=DBEDWP2
export NLS_LANG=American_America.KO16MSWIN949

#----------------------------------------------------#
# 작업내용 : THDDH_TSASZPARON 테이블 sqoop 복제 작업
# 작업주기 : D 
#----------------------------------------------------#

    echo " "
    echo "*-----------[ THDDH_TSASZPARON.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TSASZPARON.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`  >  ${SHLOG_DIR}/THDDH_TSASZPARON.shlog

#----------------------------------------------------#
# 테이블별 데이터변경LOG 데이터를 받아 오는 부분
#----------------------------------------------------#
    /usr/bin/hadoop fs -rm -r -f  /tmp2/TXLOG_THDDH_TSASZPARON  >> ${SHLOG_DIR}/THDDH_TSASZPARON.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.TXLOG_THDDH_TSASZPARON ; " >> ${SHLOG_DIR}/THDDH_TSASZPARON.shlog 2>&1 &&
    /usr/hdp/3.0.0.0-1634/sqoop/bin/sqoop import -D mapred.child.java.opts="-Djava.security.egd=file:/dev/../dev/urandom" \
    --connect jdbc:oracle:thin:EDWHADOOP/wjdqhrP\!23@10.91.41.172:12560:DBEDWP2 \
    --username  EDWHADOOP \
    --password wjdqhrP\!23 \
    --query "SELECT * FROM THDDH_TCOTXLOG
                       WHERE \$CONDITIONS 
                         AND DATA_CHNG_DTM >= TO_TIMESTAMP(TO_CHAR(CURRENT_DATE -16 ,'YYYYMMDD')||' 00:00:00','YYYYMMDD HH24:MI:SS')
                         AND TBL_NM IN ( UPPER('TSASZPARON'), LOWER('TSASZPARON')) "\
    --m 1 \
    --target-dir /tmp2/TXLOG_THDDH_TSASZPARON \
    --hive-import \
    --external-table-dir hdfs:///tmp2/temp_tbl/TXLOG_THDDH_TSASZPARON \
    --hive-overwrite \
    --hive-table DEFAULT.TXLOG_THDDH_TSASZPARON  >> ${SHLOG_DIR}/THDDH_TSASZPARON.shlog 2>&1 &&

#----------------------------------------------------#
# 테이블별 데이터강제수정LOG 데이터를 받아 오는 부분
#----------------------------------------------------#
    /usr/bin/hadoop fs -rm -r -f  /tmp2/BTXLOG_THDDH_TSASZPARON  >> ${SHLOG_DIR}/THDDH_TSASZPARON.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.BTXLOG_THDDH_TSASZPARON ; " >> ${SHLOG_DIR}/THDDH_TSASZPARON.shlog 2>&1 &&
    /usr/hdp/3.0.0.0-1634/sqoop/bin/sqoop import -D mapred.child.java.opts="-Djava.security.egd=file:/dev/../dev/urandom" \
    --connect jdbc:oracle:thin:EDWHADOOP/wjdqhrP\!23@10.91.41.172:12560:DBEDWP2 \
    --username  EDWHADOOP \
    --password wjdqhrP\!23 \
    --query "SELECT * FROM THDDH_TCODBTXLOG
                       WHERE \$CONDITIONS 
                         AND DATA_CHNG_DTM >= TO_TIMESTAMP(TO_CHAR(CURRENT_DATE -16 ,'YYYYMMDD')||' 00:00:00','YYYYMMDD HH24:MI:SS')
                         AND TBL_NM IN ( UPPER('TSASZPARON'), LOWER('TSASZPARON')) "\
    --m 1 \
    --target-dir /tmp2/BTXLOG_THDDH_TSASZPARON \
    --hive-import \
    --external-table-dir hdfs:///tmp2/temp_tbl/BTXLOG_THDDH_TSASZPARON \
    --hive-overwrite \
    --hive-table DEFAULT.BTXLOG_THDDH_TSASZPARON  >> ${SHLOG_DIR}/THDDH_TSASZPARON.shlog 2>&1 &&

#----------------------------------------------------#
# 테이블별 일변경 데이터를 받아 오는 부분
#----------------------------------------------------#
    /usr/bin/hadoop fs -rm -r -f  /tmp2/STG_THDDH_TSASZPARON  >> ${SHLOG_DIR}/THDDH_TSASZPARON.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.STG_THDDH_TSASZPARON ; " >> ${SHLOG_DIR}/THDDH_TSASZPARON.shlog 2>&1 &&
    /usr/hdp/3.0.0.0-1634/sqoop/bin/sqoop import -D mapred.child.java.opts="-Djava.security.egd=file:/dev/../dev/urandom" \
    --connect jdbc:oracle:thin:EDWHADOOP/wjdqhrP\!23@10.91.41.172:12560:DBEDWP2 \
    --username  EDWHADOOP \
    --password wjdqhrP\!23 \
    --query "SELECT REPLACE(REPLACE(SLZ_CTR_ORIG_ID,CHR(13),''),CHR(10),'') SLZ_CTR_ORIG_ID
, REPLACE(REPLACE(STD_YYMM,CHR(13),''),CHR(10),'') STD_YYMM
, STD_DNO
, REPLACE(REPLACE(DATA_PCS_DIV_CD,CHR(13),''),CHR(10),'') DATA_PCS_DIV_CD
, REPLACE(REPLACE(POL_NO,CHR(13),''),CHR(10),'') POL_NO
, ENDR_NO
, REPLACE(REPLACE(PREM_PYRC_XPT_ID,CHR(13),''),CHR(10),'') PREM_PYRC_XPT_ID
, REPLACE(REPLACE(FEE_RCRD_KD_CD,CHR(13),''),CHR(10),'') FEE_RCRD_KD_CD
, REPLACE(REPLACE(TRTPE_ORG_ID,CHR(13),''),CHR(10),'') TRTPE_ORG_ID
, REPLACE(REPLACE(PY_YYMM,CHR(13),''),CHR(10),'') PY_YYMM
, PY_TMS
, NMPY_SEQ
, SUMUP_DT
, RCPT_DT
, SBCP_DT
, REPLACE(REPLACE(ORG_DIV_CD,CHR(13),''),CHR(10),'') ORG_DIV_CD
, REPLACE(REPLACE(TEM_ORG_ID,CHR(13),''),CHR(10),'') TEM_ORG_ID
, REPLACE(REPLACE(SLZ_FML_ORG_ID,CHR(13),''),CHR(10),'') SLZ_FML_ORG_ID
, REPLACE(REPLACE(RLMR_ORG_ID,CHR(13),''),CHR(10),'') RLMR_ORG_ID
, REPLACE(REPLACE(AGC_BROF_ORG_ID,CHR(13),''),CHR(10),'') AGC_BROF_ORG_ID
, REPLACE(REPLACE(PD_CD,CHR(13),''),CHR(10),'') PD_CD
, REPLACE(REPLACE(SLZ_ACRSL_BIZ_DIV_CD,CHR(13),''),CHR(10),'') SLZ_ACRSL_BIZ_DIV_CD
, REPLACE(REPLACE(SLZ_ACRSL_PD_CTG_CD,CHR(13),''),CHR(10),'') SLZ_ACRSL_PD_CTG_CD
, PREM
, PSSE_PREM
, PSSE_RT
, REPLACE(REPLACE(PY_CYC_CD,CHR(13),''),CHR(10),'') PY_CYC_CD
, PY_TIMS
, REPLACE(REPLACE(RCP_MD_CD,CHR(13),''),CHR(10),'') RCP_MD_CD
, REPLACE(REPLACE(MNCL_MD_CD,CHR(13),''),CHR(10),'') MNCL_MD_CD
, REPLACE(REPLACE(PYRC_DIV_CD,CHR(13),''),CHR(10),'') PYRC_DIV_CD
, REPLACE(REPLACE(AMT_KD_CD,CHR(13),''),CHR(10),'') AMT_KD_CD
, FTM_MDF_PREM
, REPLACE(REPLACE(POLHD_PTY_ID,CHR(13),''),CHR(10),'') POLHD_PTY_ID
, REPLACE(REPLACE(INSPE_PTY_ID,CHR(13),''),CHR(10),'') INSPE_PTY_ID
, REPLACE(REPLACE(INSPE_NM,CHR(13),''),CHR(10),'') INSPE_NM
, REPLACE(REPLACE(PRPY_YN,CHR(13),''),CHR(10),'') PRPY_YN
, REPLACE(REPLACE(NEW_DIV_CD,CHR(13),''),CHR(10),'') NEW_DIV_CD
, REPLACE(REPLACE(VEHC_NO,CHR(13),''),CHR(10),'') VEHC_NO
, REPLACE(REPLACE(RISK_BD_CD,CHR(13),''),CHR(10),'') RISK_BD_CD
, REPLACE(REPLACE(RISK_GRDE_CD,CHR(13),''),CHR(10),'') RISK_GRDE_CD
, REPLACE(REPLACE(AGPLR_ORG_ID,CHR(13),''),CHR(10),'') AGPLR_ORG_ID
, REPLACE(REPLACE(CLLPE_ORG_ID,CHR(13),''),CHR(10),'') CLLPE_ORG_ID
, REPLACE(REPLACE(NW_STIC_PD_CTG_CD,CHR(13),''),CHR(10),'') NW_STIC_PD_CTG_CD
, INS_BGN_DT
, INS_ED_DT
, REPLACE(REPLACE(FNC_INST_CD,CHR(13),''),CHR(10),'') FNC_INST_CD
, REPLACE(REPLACE(BNCA_BCH_ORG_ID,CHR(13),''),CHR(10),'') BNCA_BCH_ORG_ID
, BFT_PREM
, REPLACE(REPLACE(OD_POL_NO,CHR(13),''),CHR(10),'') OD_POL_NO
, RNWL_PREM
, FYY_MDF_PREM
, APL_PREM
, REPLACE(REPLACE(MLG_WKDS_DIV_CD,CHR(13),''),CHR(10),'') MLG_WKDS_DIV_CD
, REPLACE(REPLACE(DC_DIV_CD,CHR(13),''),CHR(10),'') DC_DIV_CD
, REPLACE(REPLACE(ENDR_CD,CHR(13),''),CHR(10),'') ENDR_CD
, REPLACE(REPLACE(ENDR_DIV_CD,CHR(13),''),CHR(10),'') ENDR_DIV_CD
, ENDR_STD_DT
, REPLACE(REPLACE(MLG_CTR_YN,CHR(13),''),CHR(10),'') MLG_CTR_YN
, REPLACE(REPLACE(PYRC_XPT_CD,CHR(13),''),CHR(10),'') PYRC_XPT_CD
, INP_DT
, REPLACE(REPLACE(INPPE_ORG_ID,CHR(13),''),CHR(10),'') INPPE_ORG_ID
, SYS_OCC_DTM
, REPLACE(REPLACE(SYS_DEL_DIV_CD,CHR(13),''),CHR(10),'') SYS_DEL_DIV_CD
, REPLACE(REPLACE(APP_ID,CHR(13),''),CHR(10),'') APP_ID
, REPLACE(REPLACE(OCC_IP,CHR(13),''),CHR(10),'') OCC_IP
, DATA_CHNG_DTM
, REPLACE(REPLACE(FB_AT_TRS_YN,CHR(13),''),CHR(10),'') FB_AT_TRS_YN
, FB_AT_TRS_DT
, REPLACE(REPLACE(FB_AT_TRS_PCS_YN,CHR(13),''),CHR(10),'') FB_AT_TRS_PCS_YN
, REPLACE(REPLACE(BNCA_BCH_CD,CHR(13),''),CHR(10),'') BNCA_BCH_CD
, IPY_DT
, REPLACE(REPLACE(JNT_TNG_DIV_CD,CHR(13),''),CHR(10),'') JNT_TNG_DIV_CD
, REPLACE(REPLACE(NECR_YN,CHR(13),''),CHR(10),'') NECR_YN
, RPSB_PREM
, OPTN_PREM
, RDYCR_SVC_PREM
, REPLACE(REPLACE(CTR_STAT_CD,CHR(13),''),CHR(10),'') CTR_STAT_CD
, MMPY_CNVS_PREM
, MDF_PREM
, DIDT_SBC_AMT
, INDT_SBC_AMT
, TRF_DTH_SBC_AMT
, REPLACE(REPLACE(FBIZ_NFBIZ_DIV_CD,CHR(13),''),CHR(10),'') FBIZ_NFBIZ_DIV_CD
, EIH_LDG_DTM
, GURT_PREM
, ACU_PREM
, REPLACE(REPLACE(HDQT_ORG_ID,CHR(13),''),CHR(10),'') HDQT_ORG_ID
, REPLACE(REPLACE(BRCH_ORG_ID,CHR(13),''),CHR(10),'') BRCH_ORG_ID
, REPLACE(REPLACE(BCH_ORG_ID,CHR(13),''),CHR(10),'') BCH_ORG_ID
, REPLACE(REPLACE(HG_RSK_CTR_YN,CHR(13),''),CHR(10),'') HG_RSK_CTR_YN
, REPLACE(REPLACE(FEE_CAL_EXPT_DIV_CD,CHR(13),''),CHR(10),'') FEE_CAL_EXPT_DIV_CD
, INS_PRD
, PY_PRD
, REPLACE(REPLACE(FETS_GURT_YN,CHR(13),''),CHR(10),'') FETS_GURT_YN
, BTH_AF_RCPT_PREM
, BTH_AF_MDF_PREM FROM THDDH_TSASZPARON
                       WHERE \$CONDITIONS 
                         AND DATA_CHNG_DTM >= TO_TIMESTAMP(TO_CHAR(CURRENT_DATE -16 ,'YYYYMMDD')||' 00:00:00','YYYYMMDD HH24:MI:SS') "\
    --m 1 \
    --target-dir /tmp2/STG_THDDH_TSASZPARON \
    --hive-import \
    --external-table-dir hdfs:///tmp2/temp_tbl/STG_THDDH_TSASZPARON \
    --hive-overwrite \
    --hive-table DEFAULT.STG_THDDH_TSASZPARON  >> ${SHLOG_DIR}/THDDH_TSASZPARON.shlog 2>&1 &&

#----------------------------------------------------#
# 이전 테이블에 일변경 데이터 OR 삭제로그 적용
#----------------------------------------------------#
    /usr/bin/hadoop fs -rm -r -f -skipTrash /warehouse/tablespace/external/hive/except_thddh_tsaszparon  >> ${SHLOG_DIR}/THDDH_TSASZPARON.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.EXCEPT_THDDH_TSASZPARON ; " >> ${SHLOG_DIR}/THDDH_TSASZPARON.shlog 2>&1 &&
    /usr/bin/hive -e "CREATE EXTERNAL TABLE DEFAULT.EXCEPT_THDDH_TSASZPARON STORED AS PARQUET AS
                                    SELECT SLZ_CTR_ORIG_ID FROM DEFAULT.STG_THDDH_TSASZPARON
                                    UNION ALL
                                    SELECT KEY_VAL1 AS SLZ_CTR_ORIG_ID FROM DEFAULT.TXLOG_THDDH_TSASZPARON
                                    UNION ALL
                                    SELECT KEY_VAL1 AS SLZ_CTR_ORIG_ID FROM DEFAULT.BTXLOG_THDDH_TSASZPARON ;" >> ${SHLOG_DIR}/THDDH_TSASZPARON.shlog 2>&1 &&

#----------------------------------------------------#
# Hadoop 테이블에 변경분 적용
# RENAME할 테이블 생성(오류 작업시 ROLLBACK)
#----------------------------------------------------#
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.LAST_THDDH_TSASZPARON ; " >> ${SHLOG_DIR}/THDDH_TSASZPARON.shlog 2>&1 &&
    /usr/bin/hive -e "CREATE EXTERNAL TABLE DEFAULT.LAST_THDDH_TSASZPARON STORED AS PARQUET TBLPROPERTIES ('PARQUET.COMPRESS'='SNAPPY') AS
                                    SELECT T1.*
                                    FROM MERITZ.THDDH_TSASZPARON AS T1
                                        LEFT JOIN DEFAULT.EXCEPT_THDDH_TSASZPARON AS T2
                                          ON 1 = 1
                                          AND T1.SLZ_CTR_ORIG_ID = T2.SLZ_CTR_ORIG_ID
                                    WHERE 1 = 1
                                      AND T2.SLZ_CTR_ORIG_ID IS NULL
                                    UNION ALL
                                    SELECT *
                                    FROM DEFAULT.STG_THDDH_TSASZPARON ;" >> ${SHLOG_DIR}/THDDH_TSASZPARON.shlog 2>&1 &&
#----------------------------------------------------#
# Hadoop 원본테이블에 변경분 최종 적용
#----------------------------------------------------#
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TSASZPARON_TMP ; " >> ${SHLOG_DIR}/THDDH_TSASZPARON.shlog 2>&1 &&
    /usr/bin/hive -e "CREATE EXTERNAL TABLE MERITZ.THDDH_TSASZPARON_TMP STORED AS PARQUET TBLPROPERTIES ('PARQUET.COMPRESS'='SNAPPY') AS
                                SELECT *
                                FROM DEFAULT.LAST_THDDH_TSASZPARON ;" >> ${SHLOG_DIR}/THDDH_TSASZPARON.shlog 2>&1 &&
    /usr/bin/hadoop fs -rm -r -f -skipTrash /warehouse/tablespace/external/hive/last_thddh_tsaszparon  >> ${SHLOG_DIR}/THDDH_TSASZPARON.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.LAST_THDDH_TSASZPARON ;" >> ${SHLOG_DIR}/THDDH_TSASZPARON.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TSASZPARON ;" >> ${SHLOG_DIR}/THDDH_TSASZPARON.shlog 2>&1 &&
    /usr/bin/hive -e "ALTER TABLE MERITZ.THDDH_TSASZPARON_TMP RENAME TO MERITZ.THDDH_TSASZPARON ;" >> ${SHLOG_DIR}/THDDH_TSASZPARON.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TSASZPARON_TMP ;" >> ${SHLOG_DIR}/THDDH_TSASZPARON.shlog 2>&1 

if [ $? -ne 0 ]
then             
    echo "*-----------[ THDDH_TSASZPARON.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/THDDH_TSASZPARON.shlog"
    echo "*-----------[ THDDH_TSASZPARON.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/THDDH_TSASZPARON.shlog"  >>  ${SHLOG_DIR}/THDDH_TSASZPARON.shlog
    echo "*-----------[ THDDH_TSASZPARON.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TSASZPARON.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/THDDH_TSASZPARON.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/THDDH_TSASZPARON.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TSASZPARON.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TSASZPARON.shlog /sqoopbin/scripts/etlpgm/his_log/THDDH_TSASZPARON_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  THDDH_TSASZPARON.sh cmd command error !! ***
    fi               

    exit -1      

else             
    echo "*-----------[ THDDH_TSASZPARON.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TSASZPARON.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/THDDH_TSASZPARON.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/THDDH_TSASZPARON.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TSASZPARON.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TSASZPARON.shlog /sqoopbin/scripts/etlpgm/his_log/THDDH_TSASZPARON_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  THDDH_TSASZPARON.sh cmd command error !! ***
        exit -1      
    else             
        exit 0       
    fi               
fi               
