#!/bin/bash

if [ $# -eq 0 ]
then           
    ARGS=N    
else           
    ARGS=$1
fi             

NOW=$(date +"+%Y-%m-%d_%T")
SHLOG_DIR=/sqoopbin/scripts/etlpgm/cur_log
HISLOG_DIR=/sqoopbin/scripts/etlpgm/his_log

export HADOOP_OPTS=-Djava.security.egd=file:/dev/../dev/urandom
export ORACLE_BASE=/sw/oracle
export ORACLE_HOME=/sw/oracle/product/11.2.0.4/client_1
export LD_LIBRARY_PATH=/sw/oracle/product/11.2.0.4/client_1/lib:/sw/oracle/product/11.2.0.4/client_1/lib:
export PATH=/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/usr/lib64/qt-3.3/bin:/usr/hdp/3.0.0.0-1634/spark2/bin/:/var/opt/node/bin/:/opt/maven/bin:/usr/local/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/home/hdpapp/workspace/data-science-at-the-command-line/tools:/home/hdpapp/.local/bin:/home/hdpapp/bin
export TNS_ADMIN=/sw/oracle/product/11.2.0.4/client_1/network/admin
export ORACLE_SID=DBEDWP2
export NLS_LANG=American_America.KO16MSWIN949

#----------------------------------------------------#
# 작업내용 : TMMDB_CUSLAST 테이블 sqoop 복제 작업
# 작업주기 :  
#----------------------------------------------------#

    echo " "
    echo "*-----------[ TMMDB_CUSLAST.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ TMMDB_CUSLAST.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`  >  ${SHLOG_DIR}/TMMDB_CUSLAST.shlog

#----------------------------------------------------#
# 테이블별 전체 데이터를 받아 오는 부분
#----------------------------------------------------#
    /usr/bin/hadoop fs -rm -r -f  /tmp2/LAST_TMMDB_CUSLAST  >> ${SHLOG_DIR}/TMMDB_CUSLAST.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.LAST_TMMDB_CUSLAST ; " >> ${SHLOG_DIR}/TMMDB_CUSLAST.shlog 2>&1 &&
    /usr/hdp/3.0.0.0-1634/sqoop/bin/sqoop import -D mapred.child.java.opts="-Djava.security.egd=file:/dev/../dev/urandom" \
    --connect jdbc:oracle:thin:EDWHADOOP/wjdqhrP\!23@10.91.41.172:12560:DBEDWP2 \
    --username  EDWHADOOP \
    --password wjdqhrP\!23 \
    --query "SELECT /*+ FULL(TMMDB_CUSLAST) */ REPLACE(REPLACE(CUS_NO,CHR(13),''),CHR(10),'') CUS_NO
, REPLACE(REPLACE(CUS_TP_CD,CHR(13),''),CHR(10),'') CUS_TP_CD
, REPLACE(REPLACE(CUS_STAT_CD,CHR(13),''),CHR(10),'') CUS_STAT_CD
, REPLACE(REPLACE(CUS_NM,CHR(13),''),CHR(10),'') CUS_NM
, REPLACE(REPLACE(CUS_ABR_NM,CHR(13),''),CHR(10),'') CUS_ABR_NM
, REPLACE(REPLACE(ENG_CUS_NM,CHR(13),''),CHR(10),'') ENG_CUS_NM
, REPLACE(REPLACE(ENG_CUS_ABR_NM,CHR(13),''),CHR(10),'') ENG_CUS_ABR_NM
, REPLACE(REPLACE(RRN_GNDR_CD,CHR(13),''),CHR(10),'') RRN_GNDR_CD
, REPLACE(REPLACE(BDT_IDF_NO,CHR(13),''),CHR(10),'') BDT_IDF_NO
, REPLACE(REPLACE(NATL_CD,CHR(13),''),CHR(10),'') NATL_CD
, CUS_ST_DT
, CUS_ED_DT
, REPLACE(REPLACE(RNM_CNF_YN,CHR(13),''),CHR(10),'') RNM_CNF_YN
, REPLACE(REPLACE(FRS_REG_CHN_CD,CHR(13),''),CHR(10),'') FRS_REG_CHN_CD
, REPLACE(REPLACE(REG_CHN_CD,CHR(13),''),CHR(10),'') REG_CHN_CD
, REPLACE(REPLACE(JOB_CD,CHR(13),''),CHR(10),'') JOB_CD
, REPLACE(REPLACE(WKPL_NM,CHR(13),''),CHR(10),'') WKPL_NM
, REPLACE(REPLACE(DPT_NM,CHR(13),''),CHR(10),'') DPT_NM
, REPLACE(REPLACE(OFPOS_CD,CHR(13),''),CHR(10),'') OFPOS_CD
, REPLACE(REPLACE(OFPOS_NM,CHR(13),''),CHR(10),'') OFPOS_NM
, REPLACE(REPLACE(DUTY_CD,CHR(13),''),CHR(10),'') DUTY_CD
, REPLACE(REPLACE(JOB_GRD_CD,CHR(13),''),CHR(10),'') JOB_GRD_CD
, REPLACE(REPLACE(MARY_DIV_CD,CHR(13),''),CHR(10),'') MARY_DIV_CD
, REPLACE(REPLACE(HBBY_CD,CHR(13),''),CHR(10),'') HBBY_CD
, REPLACE(REPLACE(SPA_CD,CHR(13),''),CHR(10),'') SPA_CD
, REPLACE(REPLACE(RLGN_CD,CHR(13),''),CHR(10),'') RLGN_CD
, REPLACE(REPLACE(BLTP_CD,CHR(13),''),CHR(10),'') BLTP_CD
, REPLACE(REPLACE(RSD_SH_CD,CHR(13),''),CHR(10),'') RSD_SH_CD
, REPLACE(REPLACE(RSD_KD_CD,CHR(13),''),CHR(10),'') RSD_KD_CD
, REPLACE(REPLACE(MM_INCM_SECT_CD,CHR(13),''),CHR(10),'') MM_INCM_SECT_CD
, REPLACE(REPLACE(SMK_QT,CHR(13),''),CHR(10),'') SMK_QT
, REPLACE(REPLACE(DRKN_QT,CHR(13),''),CHR(10),'') DRKN_QT
, REPLACE(REPLACE(WKTH_YN,CHR(13),''),CHR(10),'') WKTH_YN
, REPLACE(REPLACE(EMPM_SH_CD,CHR(13),''),CHR(10),'') EMPM_SH_CD
, REPLACE(REPLACE(HME_ZPCD,CHR(13),''),CHR(10),'') HME_ZPCD
, REPLACE(REPLACE(HME_SIDO_NM,CHR(13),''),CHR(10),'') HME_SIDO_NM
, REPLACE(REPLACE(HME_SGK_NM,CHR(13),''),CHR(10),'') HME_SGK_NM
, REPLACE(REPLACE(WKPL_SIDO_NM,CHR(13),''),CHR(10),'') WKPL_SIDO_NM
, REPLACE(REPLACE(WKPL_SGK_NM,CHR(13),''),CHR(10),'') WKPL_SGK_NM
, REPLACE(REPLACE(BIZPL_SIDO_NM,CHR(13),''),CHR(10),'') BIZPL_SIDO_NM
, REPLACE(REPLACE(BIZPL_SGK_NM,CHR(13),''),CHR(10),'') BIZPL_SGK_NM
, REPLACE(REPLACE(INPPE_ORG_CD,CHR(13),''),CHR(10),'') INPPE_ORG_CD
, REPLACE(REPLACE(CUS_ID,CHR(13),''),CHR(10),'') CUS_ID
, REPLACE(REPLACE(INPPE_ORG_ID,CHR(13),''),CHR(10),'') INPPE_ORG_ID
, DATA_CHNG_DTM
, FULL_AGE FROM TMMDB_CUSLAST
                       WHERE \$CONDITIONS "\
    --m 8 \
    --boundary-query "SELECT 0, 7 FROM DUAL"\
    --split-by "ORA_HASH(CUS_NO, 7)"\
    --target-dir /tmp2/LAST_TMMDB_CUSLAST \
    --hive-import \
    --external-table-dir hdfs:///tmp2/temp_tbl/LAST_TMMDB_CUSLAST \
    --hive-overwrite \
    --hive-table DEFAULT.LAST_TMMDB_CUSLAST  >> ${SHLOG_DIR}/TMMDB_CUSLAST.shlog 2>&1 &&

#----------------------------------------------------#
# Hadoop 원본테이블에 변경분 최종 적용
#----------------------------------------------------#
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.TMMDB_CUSLAST_TMP ; " >> ${SHLOG_DIR}/TMMDB_CUSLAST.shlog 2>&1 &&
    /usr/bin/hive -e "CREATE EXTERNAL TABLE MERITZ.TMMDB_CUSLAST_TMP STORED AS PARQUET TBLPROPERTIES ('PARQUET.COMPRESS'='SNAPPY') AS
                                SELECT *
                                FROM DEFAULT.LAST_TMMDB_CUSLAST ;" >> ${SHLOG_DIR}/TMMDB_CUSLAST.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.LAST_TMMDB_CUSLAST ;" >> ${SHLOG_DIR}/TMMDB_CUSLAST.shlog 2>&1 &&
    /usr/bin/hdfs dfs -rm -r -f -skipTrash /warehouse/tablespace/external/hive/last_tmmdb_cuslast >> ${SHLOG_DIR}/TMMDB_CUSLAST.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.TMMDB_CUSLAST ;" >> ${SHLOG_DIR}/TMMDB_CUSLAST.shlog 2>&1 &&
    /usr/bin/hive -e "ALTER TABLE MERITZ.TMMDB_CUSLAST_TMP RENAME TO MERITZ.TMMDB_CUSLAST ;" >> ${SHLOG_DIR}/TMMDB_CUSLAST.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.TMMDB_CUSLAST_TMP ;" >> ${SHLOG_DIR}/TMMDB_CUSLAST.shlog 2>&1 

if [ $? -ne 0 ]
then             
    echo "*-----------[ TMMDB_CUSLAST.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/TMMDB_CUSLAST.shlog"
    echo "*-----------[ TMMDB_CUSLAST.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/TMMDB_CUSLAST.shlog"  >>  ${SHLOG_DIR}/TMMDB_CUSLAST.shlog
    echo "*-----------[ TMMDB_CUSLAST.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ TMMDB_CUSLAST.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/TMMDB_CUSLAST.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/TMMDB_CUSLAST.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/TMMDB_CUSLAST.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/TMMDB_CUSLAST.shlog /sqoopbin/scripts/etlpgm/his_log/TMMDB_CUSLAST_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  TMMDB_CUSLAST.sh cmd command error !! ***
    fi               

    exit -1      

else             
    echo "*-----------[ TMMDB_CUSLAST.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ TMMDB_CUSLAST.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/TMMDB_CUSLAST.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/TMMDB_CUSLAST.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/TMMDB_CUSLAST.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/TMMDB_CUSLAST.shlog /sqoopbin/scripts/etlpgm/his_log/TMMDB_CUSLAST_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  TMMDB_CUSLAST.sh cmd command error !! ***
        exit -1      
    else             
        exit 0       
    fi               
fi               
