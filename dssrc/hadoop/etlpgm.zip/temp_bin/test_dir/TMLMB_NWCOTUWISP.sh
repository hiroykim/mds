#!/bin/bash

if [ $# -eq 0 ]
then           
    ARGS=N    
else           
    ARGS=$1
fi             

NOW=$(date +"+%Y-%m-%d_%T")
SHLOG_DIR=/sqoopbin/scripts/etlpgm/cur_log
HISLOG_DIR=/sqoopbin/scripts/etlpgm/his_log

export HADOOP_OPTS=-Djava.security.egd=file:/dev/../dev/urandom
export ORACLE_BASE=/sw/oracle
export ORACLE_HOME=/sw/oracle/product/11.2.0.4/client_1
export LD_LIBRARY_PATH=/sw/oracle/product/11.2.0.4/client_1/lib:/sw/oracle/product/11.2.0.4/client_1/lib:
export PATH=/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/usr/lib64/qt-3.3/bin:/usr/hdp/3.0.0.0-1634/spark2/bin/:/var/opt/node/bin/:/opt/maven/bin:/usr/local/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/home/hdpapp/workspace/data-science-at-the-command-line/tools:/home/hdpapp/.local/bin:/home/hdpapp/bin
export TNS_ADMIN=/sw/oracle/product/11.2.0.4/client_1/network/admin
export ORACLE_SID=DBEDWP2
export NLS_LANG=American_America.KO16MSWIN949

#----------------------------------------------------#
# 작업내용 : TMLMB_NWCOTUWISP 테이블 sqoop 복제 작업
# 작업주기 :  
#----------------------------------------------------#

    echo " "
    echo "*-----------[ TMLMB_NWCOTUWISP.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ TMLMB_NWCOTUWISP.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`  >  ${SHLOG_DIR}/TMLMB_NWCOTUWISP.shlog

#----------------------------------------------------#
# 테이블별 전체 데이터를 받아 오는 부분
#----------------------------------------------------#
    /usr/bin/hadoop fs -rm -r -f  /tmp2/LAST_TMLMB_NWCOTUWISP  >> ${SHLOG_DIR}/TMLMB_NWCOTUWISP.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.LAST_TMLMB_NWCOTUWISP ; " >> ${SHLOG_DIR}/TMLMB_NWCOTUWISP.shlog 2>&1 &&
    /usr/hdp/3.0.0.0-1634/sqoop/bin/sqoop import -D mapred.child.java.opts="-Djava.security.egd=file:/dev/../dev/urandom" \
    --connect jdbc:oracle:thin:EDWHADOOP/wjdqhrP\!23@10.91.41.172:12560:DBEDWP2 \
    --username  EDWHADOOP \
    --password wjdqhrP\!23 \
    --query "SELECT /*+ FULL(TMLMB_NWCOTUWISP) */ REPLACE(REPLACE(STD_YYMM,CHR(13),''),CHR(10),'') STD_YYMM
, REPLACE(REPLACE(POL_NO,CHR(13),''),CHR(10),'') POL_NO
, REPLACE(REPLACE(CTR_OBJ_ID,CHR(13),''),CHR(10),'') CTR_OBJ_ID
, REPLACE(REPLACE(PRCTR_NO,CHR(13),''),CHR(10),'') PRCTR_NO
, REPLACE(REPLACE(PRCTR_OBJ_ID,CHR(13),''),CHR(10),'') PRCTR_OBJ_ID
, REPLACE(REPLACE(NW_CTR_ISP_YN,CHR(13),''),CHR(10),'') NW_CTR_ISP_YN
, REPLACE(REPLACE(ISP_NO,CHR(13),''),CHR(10),'') ISP_NO
, REPLACE(REPLACE(NW_CTR_ISPPE_ORG_CD,CHR(13),''),CHR(10),'') NW_CTR_ISPPE_ORG_CD
, REPLACE(REPLACE(ISP_RSL_CD,CHR(13),''),CHR(10),'') ISP_RSL_CD
, REPLACE(REPLACE(ISP_RIOT_HR_SS_VAL,CHR(13),''),CHR(10),'') ISP_RIOT_HR_SS_VAL
, REPLACE(REPLACE(PRPT_YN,CHR(13),''),CHR(10),'') PRPT_YN
, REPLACE(REPLACE(DGN_YN,CHR(13),''),CHR(10),'') DGN_YN
, EIH_LDG_DTM
, REPLACE(REPLACE(NOCV_YN,CHR(13),''),CHR(10),'') NOCV_YN
, REPLACE(REPLACE(TLMK_UW_YN,CHR(13),''),CHR(10),'') TLMK_UW_YN
, REPLACE(REPLACE(XCHG_YN,CHR(13),''),CHR(10),'') XCHG_YN FROM TMLMB_NWCOTUWISP
                       WHERE \$CONDITIONS "\
    --m 1 \
    --target-dir /tmp2/LAST_TMLMB_NWCOTUWISP \
    --hive-import \
    --external-table-dir hdfs:///tmp2/temp_tbl/LAST_TMLMB_NWCOTUWISP \
    --hive-overwrite \
    --hive-table DEFAULT.LAST_TMLMB_NWCOTUWISP  >> ${SHLOG_DIR}/TMLMB_NWCOTUWISP.shlog 2>&1 &&

#----------------------------------------------------#
# Hadoop 원본테이블에 변경분 최종 적용
#----------------------------------------------------#
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.TMLMB_NWCOTUWISP_TMP ; " >> ${SHLOG_DIR}/TMLMB_NWCOTUWISP.shlog 2>&1 &&
    /usr/bin/hive -e "CREATE EXTERNAL TABLE MERITZ.TMLMB_NWCOTUWISP_TMP STORED AS PARQUET TBLPROPERTIES ('PARQUET.COMPRESS'='SNAPPY') AS
                                SELECT *
                                FROM DEFAULT.LAST_TMLMB_NWCOTUWISP ;" >> ${SHLOG_DIR}/TMLMB_NWCOTUWISP.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.LAST_TMLMB_NWCOTUWISP ;" >> ${SHLOG_DIR}/TMLMB_NWCOTUWISP.shlog 2>&1 &&
    /usr/bin/hdfs dfs -rm -r -f -skipTrash /warehouse/tablespace/external/hive/last_tmlmb_nwcotuwisp >> ${SHLOG_DIR}/TMLMB_NWCOTUWISP.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.TMLMB_NWCOTUWISP ;" >> ${SHLOG_DIR}/TMLMB_NWCOTUWISP.shlog 2>&1 &&
    /usr/bin/hive -e "ALTER TABLE MERITZ.TMLMB_NWCOTUWISP_TMP RENAME TO MERITZ.TMLMB_NWCOTUWISP ;" >> ${SHLOG_DIR}/TMLMB_NWCOTUWISP.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.TMLMB_NWCOTUWISP_TMP ;" >> ${SHLOG_DIR}/TMLMB_NWCOTUWISP.shlog 2>&1 

if [ $? -ne 0 ]
then             
    echo "*-----------[ TMLMB_NWCOTUWISP.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/TMLMB_NWCOTUWISP.shlog"
    echo "*-----------[ TMLMB_NWCOTUWISP.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/TMLMB_NWCOTUWISP.shlog"  >>  ${SHLOG_DIR}/TMLMB_NWCOTUWISP.shlog
    echo "*-----------[ TMLMB_NWCOTUWISP.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ TMLMB_NWCOTUWISP.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/TMLMB_NWCOTUWISP.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/TMLMB_NWCOTUWISP.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/TMLMB_NWCOTUWISP.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/TMLMB_NWCOTUWISP.shlog /sqoopbin/scripts/etlpgm/his_log/TMLMB_NWCOTUWISP_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  TMLMB_NWCOTUWISP.sh cmd command error !! ***
    fi               

    exit -1      

else             
    echo "*-----------[ TMLMB_NWCOTUWISP.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ TMLMB_NWCOTUWISP.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/TMLMB_NWCOTUWISP.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/TMLMB_NWCOTUWISP.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/TMLMB_NWCOTUWISP.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/TMLMB_NWCOTUWISP.shlog /sqoopbin/scripts/etlpgm/his_log/TMLMB_NWCOTUWISP_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  TMLMB_NWCOTUWISP.sh cmd command error !! ***
        exit -1      
    else             
        exit 0       
    fi               
fi               
