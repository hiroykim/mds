// ORM class for table 'null'
// WARNING: This class is AUTO-GENERATED. Modify at your own risk.
//
// Debug information:
// Generated date: Mon Dec 14 02:16:01 GMT 2020
// For connector: org.apache.sqoop.manager.OracleManager
import org.apache.hadoop.io.BytesWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.mapred.lib.db.DBWritable;
import org.apache.sqoop.lib.JdbcWritableBridge;
import org.apache.sqoop.lib.DelimiterSet;
import org.apache.sqoop.lib.FieldFormatter;
import org.apache.sqoop.lib.RecordParser;
import org.apache.sqoop.lib.BooleanParser;
import org.apache.sqoop.lib.BlobRef;
import org.apache.sqoop.lib.ClobRef;
import org.apache.sqoop.lib.LargeObjectLoader;
import org.apache.sqoop.lib.SqoopRecord;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.sql.Date;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

public class QueryResult extends SqoopRecord  implements DBWritable, Writable {
  private final int PROTOCOL_VERSION = 3;
  public int getClassFormatVersion() { return PROTOCOL_VERSION; }
  public static interface FieldSetterCommand {    void setField(Object value);  }  protected ResultSet __cur_result_set;
  private Map<String, FieldSetterCommand> setters = new HashMap<String, FieldSetterCommand>();
  private void init0() {
    setters.put("UNT_PD_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.UNT_PD_CD = (String)value;
      }
    });
    setters.put("VF_DT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.VF_DT = (java.sql.Timestamp)value;
      }
    });
    setters.put("VT_DT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.VT_DT = (java.sql.Timestamp)value;
      }
    });
    setters.put("UNT_PD_NM", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.UNT_PD_NM = (String)value;
      }
    });
    setters.put("UNT_PD_ABR_NM", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.UNT_PD_ABR_NM = (String)value;
      }
    });
    setters.put("UNT_PD_ENG_NM", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.UNT_PD_ENG_NM = (String)value;
      }
    });
    setters.put("UNT_PD_ENG_ABR_NM", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.UNT_PD_ENG_ABR_NM = (String)value;
      }
    });
    setters.put("PD_AUTH_DT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.PD_AUTH_DT = (java.sql.Timestamp)value;
      }
    });
    setters.put("PD_SAL_TMRR_SUSP_DT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.PD_SAL_TMRR_SUSP_DT = (java.sql.Timestamp)value;
      }
    });
    setters.put("SAL_BGN_DT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.SAL_BGN_DT = (java.sql.Timestamp)value;
      }
    });
    setters.put("SAL_ED_DT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.SAL_ED_DT = (java.sql.Timestamp)value;
      }
    });
    setters.put("INS_BGN_TM", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.INS_BGN_TM = (String)value;
      }
    });
    setters.put("INS_ED_TM", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.INS_ED_TM = (String)value;
      }
    });
    setters.put("RPS_PD_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.RPS_PD_CD = (String)value;
      }
    });
    setters.put("OD_PD_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.OD_PD_CD = (String)value;
      }
    });
    setters.put("INS_ITMS_DIV_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.INS_ITMS_DIV_CD = (String)value;
      }
    });
    setters.put("OD_STIC_PD_CTG_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.OD_STIC_PD_CTG_CD = (String)value;
      }
    });
    setters.put("NW_STIC_PD_CTG_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.NW_STIC_PD_CTG_CD = (String)value;
      }
    });
    setters.put("FAMT_INS_PD_CTG_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.FAMT_INS_PD_CTG_CD = (String)value;
      }
    });
    setters.put("PD_AUTH_TP_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.PD_AUTH_TP_CD = (String)value;
      }
    });
    setters.put("ISP_STD_SCR", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.ISP_STD_SCR = (java.math.BigDecimal)value;
      }
    });
    setters.put("GURT_SAV_DIV_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.GURT_SAV_DIV_CD = (String)value;
      }
    });
    setters.put("SPC_ACCT_DIV_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.SPC_ACCT_DIV_CD = (String)value;
      }
    });
    setters.put("DVND_PAY_YN", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.DVND_PAY_YN = (String)value;
      }
    });
    setters.put("BZCC_JNT_PD_YN", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.BZCC_JNT_PD_YN = (String)value;
      }
    });
    setters.put("FETS_SBC_PSB_YN", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.FETS_SBC_PSB_YN = (String)value;
      }
    });
    setters.put("ACU_GURT_SPR_YN", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.ACU_GURT_SPR_YN = (String)value;
      }
    });
    setters.put("RNWL_COV_BEIN_YN", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.RNWL_COV_BEIN_YN = (String)value;
      }
    });
    setters.put("PREM_CMPT_AGE_STD_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.PREM_CMPT_AGE_STD_CD = (String)value;
      }
    });
    setters.put("HDTL_YN", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.HDTL_YN = (String)value;
      }
    });
    setters.put("ALTN_PY_TRG_DIV_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.ALTN_PY_TRG_DIV_CD = (String)value;
      }
    });
    setters.put("PSTP_REVV_PSB_YN", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.PSTP_REVV_PSB_YN = (String)value;
      }
    });
    setters.put("AYTM_PY_PSB_YN", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.AYTM_PY_PSB_YN = (String)value;
      }
    });
    setters.put("FSS_DAT_OTPT_SEQ", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.FSS_DAT_OTPT_SEQ = (java.math.BigDecimal)value;
      }
    });
    setters.put("SAL_PLAN_INCL_YN", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.SAL_PLAN_INCL_YN = (String)value;
      }
    });
    setters.put("PPBZ_FND_CTRB_INST_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.PPBZ_FND_CTRB_INST_CD = (String)value;
      }
    });
    setters.put("PBPF_BZ_FND_CTRB_RT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.PBPF_BZ_FND_CTRB_RT = (java.math.BigDecimal)value;
      }
    });
    setters.put("APL_PREM_RDDW_UNT_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.APL_PREM_RDDW_UNT_CD = (String)value;
      }
    });
    setters.put("PD_MNDC_ISS_YN", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.PD_MNDC_ISS_YN = (String)value;
      }
    });
    setters.put("ADJT_PSB_YN", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.ADJT_PSB_YN = (String)value;
      }
    });
    setters.put("INDV_CRP_DIV_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.INDV_CRP_DIV_CD = (String)value;
      }
    });
    setters.put("GRUP_TRT_YN", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.GRUP_TRT_YN = (String)value;
      }
    });
    setters.put("SMNS_POL_PSB_YN", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.SMNS_POL_PSB_YN = (String)value;
      }
    });
    setters.put("GIRO_ISS_PSB_YN", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.GIRO_ISS_PSB_YN = (String)value;
      }
    });
    setters.put("PLR_STUP_PSB_YN", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.PLR_STUP_PSB_YN = (String)value;
      }
    });
    setters.put("HNDY_DSG_PSB_YN", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.HNDY_DSG_PSB_YN = (String)value;
      }
    });
    setters.put("CLOG_DPC_INP_YN", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.CLOG_DPC_INP_YN = (String)value;
      }
    });
    setters.put("KORE_PD_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.KORE_PD_CD = (String)value;
      }
    });
    setters.put("CLUS_DIV_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.CLUS_DIV_CD = (String)value;
      }
    });
    setters.put("LGTM_CTR_CR_XTR_MD_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.LGTM_CTR_CR_XTR_MD_CD = (String)value;
      }
    });
    setters.put("IPY_PSB_YN", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.IPY_PSB_YN = (String)value;
      }
    });
    setters.put("SRP_APL_TRG_YN", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.SRP_APL_TRG_YN = (String)value;
      }
    });
    setters.put("INCM_DDC_TRG_YN", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.INCM_DDC_TRG_YN = (String)value;
      }
    });
    setters.put("HSEC_DIV_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.HSEC_DIV_CD = (String)value;
      }
    });
    setters.put("SECT_INS_DIV_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.SECT_INS_DIV_CD = (String)value;
      }
    });
    setters.put("PVCTR_ALLW_YN", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.PVCTR_ALLW_YN = (String)value;
      }
    });
    setters.put("IPY_LPS_PRD_DIV_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.IPY_LPS_PRD_DIV_CD = (String)value;
      }
    });
    setters.put("IPY_PPN_PRD_DIV_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.IPY_PPN_PRD_DIV_CD = (String)value;
      }
    });
    setters.put("NCLAM_BNS_EN", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.NCLAM_BNS_EN = (String)value;
      }
    });
    setters.put("RVW_ITMS_CRSS_PD_YN", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.RVW_ITMS_CRSS_PD_YN = (String)value;
      }
    });
    setters.put("PRPY_PSB_TP_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.PRPY_PSB_TP_CD = (String)value;
      }
    });
    setters.put("LANN_DIV_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.LANN_DIV_CD = (String)value;
      }
    });
    setters.put("PD_GRP_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.PD_GRP_CD = (String)value;
      }
    });
    setters.put("CNCLL_DDC_AMT_SBTR_YN", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.CNCLL_DDC_AMT_SBTR_YN = (String)value;
      }
    });
    setters.put("CNCLL_DDC_YR_NUM", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.CNCLL_DDC_YR_NUM = (java.math.BigDecimal)value;
      }
    });
    setters.put("XPT_INTR", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.XPT_INTR = (java.math.BigDecimal)value;
      }
    });
    setters.put("BNCA_YN", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.BNCA_YN = (String)value;
      }
    });
    setters.put("MID_AMT_PAY_YN", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.MID_AMT_PAY_YN = (String)value;
      }
    });
    setters.put("HFWY_WDR_YN", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.HFWY_WDR_YN = (String)value;
      }
    });
    setters.put("LNK_PD_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.LNK_PD_CD = (String)value;
      }
    });
    setters.put("APL_PD_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.APL_PD_CD = (String)value;
      }
    });
    setters.put("RPT_PD_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.RPT_PD_CD = (String)value;
      }
    });
    setters.put("RPT_PD_NM", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.RPT_PD_NM = (String)value;
      }
    });
    setters.put("RMK_CON", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.RMK_CON = (String)value;
      }
    });
    setters.put("BZPLN_PD_CTG_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.BZPLN_PD_CTG_CD = (String)value;
      }
    });
    setters.put("ITGR_PD_YN", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.ITGR_PD_YN = (String)value;
      }
    });
    setters.put("EXPR_RFD_APL_DIV_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.EXPR_RFD_APL_DIV_CD = (String)value;
      }
    });
    setters.put("SLZ_PD_DIV_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.SLZ_PD_DIV_CD = (String)value;
      }
    });
    setters.put("ANN_DIV_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.ANN_DIV_CD = (String)value;
      }
    });
    setters.put("ANN_CAL_TP_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.ANN_CAL_TP_CD = (String)value;
      }
    });
    setters.put("PRPY_DC_APL_PREM_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.PRPY_DC_APL_PREM_CD = (String)value;
      }
    });
    setters.put("HFWY_WDR_RFD_STD_CON", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.HFWY_WDR_RFD_STD_CON = (String)value;
      }
    });
    setters.put("CI_PD_YN", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.CI_PD_YN = (String)value;
      }
    });
    setters.put("REGPE_NM", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.REGPE_NM = (String)value;
      }
    });
    setters.put("REG_DT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.REG_DT = (java.sql.Timestamp)value;
      }
    });
    setters.put("MME_RPT_PD_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.MME_RPT_PD_CD = (String)value;
      }
    });
    setters.put("MME_RPT_PD_CD_NM", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.MME_RPT_PD_CD_NM = (String)value;
      }
    });
    setters.put("AYTM_PY_LM_AMT_DIV_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.AYTM_PY_LM_AMT_DIV_CD = (String)value;
      }
    });
    setters.put("ICLO_PSB_YN", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.ICLO_PSB_YN = (String)value;
      }
    });
    setters.put("UNT_PD_SAL_NM", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.UNT_PD_SAL_NM = (String)value;
      }
    });
    setters.put("ISP_PD_CTG_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.ISP_PD_CTG_CD = (String)value;
      }
    });
    setters.put("LGTM_INDV_GRUP_DIV_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.LGTM_INDV_GRUP_DIV_CD = (String)value;
      }
    });
    setters.put("KIDI_PD_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.KIDI_PD_CD = (String)value;
      }
    });
    setters.put("PRDY_AMT_PD_GRP_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.PRDY_AMT_PD_GRP_CD = (String)value;
      }
    });
    setters.put("STND_INTR", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.STND_INTR = (java.math.BigDecimal)value;
      }
    });
    setters.put("MDF_RT_APL_DIV_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.MDF_RT_APL_DIV_CD = (String)value;
      }
    });
    setters.put("INDP_SIC_PD_YN", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.INDP_SIC_PD_YN = (String)value;
      }
    });
    setters.put("CKUP_TRG_PD_YN", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.CKUP_TRG_PD_YN = (String)value;
      }
    });
    setters.put("POL_OTPT_WY_DIV_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.POL_OTPT_WY_DIV_CD = (String)value;
      }
    });
    setters.put("SAL_BGN_DT1", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.SAL_BGN_DT1 = (java.sql.Timestamp)value;
      }
    });
    setters.put("NW_KIDI_PD_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.NW_KIDI_PD_CD = (String)value;
      }
    });
    setters.put("STIC_IDC_PD_CTG_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.STIC_IDC_PD_CTG_CD = (String)value;
      }
    });
    setters.put("QRCD_ADR", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.QRCD_ADR = (String)value;
      }
    });
    setters.put("AVG_PBAN_INTR", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.AVG_PBAN_INTR = (java.math.BigDecimal)value;
      }
    });
    setters.put("EIH_LDG_DTM", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.EIH_LDG_DTM = (java.sql.Timestamp)value;
      }
    });
    setters.put("NW_FAMT_INS_PD_CTG_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.NW_FAMT_INS_PD_CTG_CD = (String)value;
      }
    });
    setters.put("AT_ALTN_PY_TP_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.AT_ALTN_PY_TP_CD = (String)value;
      }
    });
    setters.put("ICLO_STD_RT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.ICLO_STD_RT = (java.math.BigDecimal)value;
      }
    });
    setters.put("MFRC_PD_YN", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.MFRC_PD_YN = (String)value;
      }
    });
    setters.put("PY_EXEM_LRG_TOP_YN", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.PY_EXEM_LRG_TOP_YN = (String)value;
      }
    });
    setters.put("SCRN_EXPS_SQ", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.SCRN_EXPS_SQ = (java.math.BigDecimal)value;
      }
    });
    setters.put("SAL_BGN_TM", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.SAL_BGN_TM = (String)value;
      }
    });
    setters.put("ITMGP_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.ITMGP_CD = (String)value;
      }
    });
    setters.put("GRUP_PREM_AGE_STD_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.GRUP_PREM_AGE_STD_CD = (String)value;
      }
    });
    setters.put("PDGP_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.PDGP_CD = (String)value;
      }
    });
    setters.put("INS_ITMS_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.INS_ITMS_CD = (String)value;
      }
    });
    setters.put("LNK_INDP_PD_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.LNK_INDP_PD_CD = (String)value;
      }
    });
    setters.put("MBL_CLUS_ADR", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.MBL_CLUS_ADR = (String)value;
      }
    });
    setters.put("MLTD_OBJ_YN", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.MLTD_OBJ_YN = (String)value;
      }
    });
    setters.put("UNT_PD_SCRN_EXPS_NM", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.UNT_PD_SCRN_EXPS_NM = (String)value;
      }
    });
    setters.put("PY_EXEM_KND_TYP_DIV_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.PY_EXEM_KND_TYP_DIV_CD = (String)value;
      }
    });
    setters.put("PY_EXEM_DIV_VAL", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.PY_EXEM_DIV_VAL = (String)value;
      }
    });
    setters.put("FETS_PRD_CAL_DIV_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.FETS_PRD_CAL_DIV_CD = (String)value;
      }
    });
    setters.put("UNT_PD_TP_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.UNT_PD_TP_CD = (String)value;
      }
    });
    setters.put("BZ_IDC_PD_LCTG_NM", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.BZ_IDC_PD_LCTG_NM = (String)value;
      }
    });
    setters.put("BZ_IDC_PD_MCTG_NM", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.BZ_IDC_PD_MCTG_NM = (String)value;
      }
    });
    setters.put("BZ_IDC_PD_CTG_NM", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.BZ_IDC_PD_CTG_NM = (String)value;
      }
    });
  }
  public QueryResult() {
    init0();
  }
  private String UNT_PD_CD;
  public String get_UNT_PD_CD() {
    return UNT_PD_CD;
  }
  public void set_UNT_PD_CD(String UNT_PD_CD) {
    this.UNT_PD_CD = UNT_PD_CD;
  }
  public QueryResult with_UNT_PD_CD(String UNT_PD_CD) {
    this.UNT_PD_CD = UNT_PD_CD;
    return this;
  }
  private java.sql.Timestamp VF_DT;
  public java.sql.Timestamp get_VF_DT() {
    return VF_DT;
  }
  public void set_VF_DT(java.sql.Timestamp VF_DT) {
    this.VF_DT = VF_DT;
  }
  public QueryResult with_VF_DT(java.sql.Timestamp VF_DT) {
    this.VF_DT = VF_DT;
    return this;
  }
  private java.sql.Timestamp VT_DT;
  public java.sql.Timestamp get_VT_DT() {
    return VT_DT;
  }
  public void set_VT_DT(java.sql.Timestamp VT_DT) {
    this.VT_DT = VT_DT;
  }
  public QueryResult with_VT_DT(java.sql.Timestamp VT_DT) {
    this.VT_DT = VT_DT;
    return this;
  }
  private String UNT_PD_NM;
  public String get_UNT_PD_NM() {
    return UNT_PD_NM;
  }
  public void set_UNT_PD_NM(String UNT_PD_NM) {
    this.UNT_PD_NM = UNT_PD_NM;
  }
  public QueryResult with_UNT_PD_NM(String UNT_PD_NM) {
    this.UNT_PD_NM = UNT_PD_NM;
    return this;
  }
  private String UNT_PD_ABR_NM;
  public String get_UNT_PD_ABR_NM() {
    return UNT_PD_ABR_NM;
  }
  public void set_UNT_PD_ABR_NM(String UNT_PD_ABR_NM) {
    this.UNT_PD_ABR_NM = UNT_PD_ABR_NM;
  }
  public QueryResult with_UNT_PD_ABR_NM(String UNT_PD_ABR_NM) {
    this.UNT_PD_ABR_NM = UNT_PD_ABR_NM;
    return this;
  }
  private String UNT_PD_ENG_NM;
  public String get_UNT_PD_ENG_NM() {
    return UNT_PD_ENG_NM;
  }
  public void set_UNT_PD_ENG_NM(String UNT_PD_ENG_NM) {
    this.UNT_PD_ENG_NM = UNT_PD_ENG_NM;
  }
  public QueryResult with_UNT_PD_ENG_NM(String UNT_PD_ENG_NM) {
    this.UNT_PD_ENG_NM = UNT_PD_ENG_NM;
    return this;
  }
  private String UNT_PD_ENG_ABR_NM;
  public String get_UNT_PD_ENG_ABR_NM() {
    return UNT_PD_ENG_ABR_NM;
  }
  public void set_UNT_PD_ENG_ABR_NM(String UNT_PD_ENG_ABR_NM) {
    this.UNT_PD_ENG_ABR_NM = UNT_PD_ENG_ABR_NM;
  }
  public QueryResult with_UNT_PD_ENG_ABR_NM(String UNT_PD_ENG_ABR_NM) {
    this.UNT_PD_ENG_ABR_NM = UNT_PD_ENG_ABR_NM;
    return this;
  }
  private java.sql.Timestamp PD_AUTH_DT;
  public java.sql.Timestamp get_PD_AUTH_DT() {
    return PD_AUTH_DT;
  }
  public void set_PD_AUTH_DT(java.sql.Timestamp PD_AUTH_DT) {
    this.PD_AUTH_DT = PD_AUTH_DT;
  }
  public QueryResult with_PD_AUTH_DT(java.sql.Timestamp PD_AUTH_DT) {
    this.PD_AUTH_DT = PD_AUTH_DT;
    return this;
  }
  private java.sql.Timestamp PD_SAL_TMRR_SUSP_DT;
  public java.sql.Timestamp get_PD_SAL_TMRR_SUSP_DT() {
    return PD_SAL_TMRR_SUSP_DT;
  }
  public void set_PD_SAL_TMRR_SUSP_DT(java.sql.Timestamp PD_SAL_TMRR_SUSP_DT) {
    this.PD_SAL_TMRR_SUSP_DT = PD_SAL_TMRR_SUSP_DT;
  }
  public QueryResult with_PD_SAL_TMRR_SUSP_DT(java.sql.Timestamp PD_SAL_TMRR_SUSP_DT) {
    this.PD_SAL_TMRR_SUSP_DT = PD_SAL_TMRR_SUSP_DT;
    return this;
  }
  private java.sql.Timestamp SAL_BGN_DT;
  public java.sql.Timestamp get_SAL_BGN_DT() {
    return SAL_BGN_DT;
  }
  public void set_SAL_BGN_DT(java.sql.Timestamp SAL_BGN_DT) {
    this.SAL_BGN_DT = SAL_BGN_DT;
  }
  public QueryResult with_SAL_BGN_DT(java.sql.Timestamp SAL_BGN_DT) {
    this.SAL_BGN_DT = SAL_BGN_DT;
    return this;
  }
  private java.sql.Timestamp SAL_ED_DT;
  public java.sql.Timestamp get_SAL_ED_DT() {
    return SAL_ED_DT;
  }
  public void set_SAL_ED_DT(java.sql.Timestamp SAL_ED_DT) {
    this.SAL_ED_DT = SAL_ED_DT;
  }
  public QueryResult with_SAL_ED_DT(java.sql.Timestamp SAL_ED_DT) {
    this.SAL_ED_DT = SAL_ED_DT;
    return this;
  }
  private String INS_BGN_TM;
  public String get_INS_BGN_TM() {
    return INS_BGN_TM;
  }
  public void set_INS_BGN_TM(String INS_BGN_TM) {
    this.INS_BGN_TM = INS_BGN_TM;
  }
  public QueryResult with_INS_BGN_TM(String INS_BGN_TM) {
    this.INS_BGN_TM = INS_BGN_TM;
    return this;
  }
  private String INS_ED_TM;
  public String get_INS_ED_TM() {
    return INS_ED_TM;
  }
  public void set_INS_ED_TM(String INS_ED_TM) {
    this.INS_ED_TM = INS_ED_TM;
  }
  public QueryResult with_INS_ED_TM(String INS_ED_TM) {
    this.INS_ED_TM = INS_ED_TM;
    return this;
  }
  private String RPS_PD_CD;
  public String get_RPS_PD_CD() {
    return RPS_PD_CD;
  }
  public void set_RPS_PD_CD(String RPS_PD_CD) {
    this.RPS_PD_CD = RPS_PD_CD;
  }
  public QueryResult with_RPS_PD_CD(String RPS_PD_CD) {
    this.RPS_PD_CD = RPS_PD_CD;
    return this;
  }
  private String OD_PD_CD;
  public String get_OD_PD_CD() {
    return OD_PD_CD;
  }
  public void set_OD_PD_CD(String OD_PD_CD) {
    this.OD_PD_CD = OD_PD_CD;
  }
  public QueryResult with_OD_PD_CD(String OD_PD_CD) {
    this.OD_PD_CD = OD_PD_CD;
    return this;
  }
  private String INS_ITMS_DIV_CD;
  public String get_INS_ITMS_DIV_CD() {
    return INS_ITMS_DIV_CD;
  }
  public void set_INS_ITMS_DIV_CD(String INS_ITMS_DIV_CD) {
    this.INS_ITMS_DIV_CD = INS_ITMS_DIV_CD;
  }
  public QueryResult with_INS_ITMS_DIV_CD(String INS_ITMS_DIV_CD) {
    this.INS_ITMS_DIV_CD = INS_ITMS_DIV_CD;
    return this;
  }
  private String OD_STIC_PD_CTG_CD;
  public String get_OD_STIC_PD_CTG_CD() {
    return OD_STIC_PD_CTG_CD;
  }
  public void set_OD_STIC_PD_CTG_CD(String OD_STIC_PD_CTG_CD) {
    this.OD_STIC_PD_CTG_CD = OD_STIC_PD_CTG_CD;
  }
  public QueryResult with_OD_STIC_PD_CTG_CD(String OD_STIC_PD_CTG_CD) {
    this.OD_STIC_PD_CTG_CD = OD_STIC_PD_CTG_CD;
    return this;
  }
  private String NW_STIC_PD_CTG_CD;
  public String get_NW_STIC_PD_CTG_CD() {
    return NW_STIC_PD_CTG_CD;
  }
  public void set_NW_STIC_PD_CTG_CD(String NW_STIC_PD_CTG_CD) {
    this.NW_STIC_PD_CTG_CD = NW_STIC_PD_CTG_CD;
  }
  public QueryResult with_NW_STIC_PD_CTG_CD(String NW_STIC_PD_CTG_CD) {
    this.NW_STIC_PD_CTG_CD = NW_STIC_PD_CTG_CD;
    return this;
  }
  private String FAMT_INS_PD_CTG_CD;
  public String get_FAMT_INS_PD_CTG_CD() {
    return FAMT_INS_PD_CTG_CD;
  }
  public void set_FAMT_INS_PD_CTG_CD(String FAMT_INS_PD_CTG_CD) {
    this.FAMT_INS_PD_CTG_CD = FAMT_INS_PD_CTG_CD;
  }
  public QueryResult with_FAMT_INS_PD_CTG_CD(String FAMT_INS_PD_CTG_CD) {
    this.FAMT_INS_PD_CTG_CD = FAMT_INS_PD_CTG_CD;
    return this;
  }
  private String PD_AUTH_TP_CD;
  public String get_PD_AUTH_TP_CD() {
    return PD_AUTH_TP_CD;
  }
  public void set_PD_AUTH_TP_CD(String PD_AUTH_TP_CD) {
    this.PD_AUTH_TP_CD = PD_AUTH_TP_CD;
  }
  public QueryResult with_PD_AUTH_TP_CD(String PD_AUTH_TP_CD) {
    this.PD_AUTH_TP_CD = PD_AUTH_TP_CD;
    return this;
  }
  private java.math.BigDecimal ISP_STD_SCR;
  public java.math.BigDecimal get_ISP_STD_SCR() {
    return ISP_STD_SCR;
  }
  public void set_ISP_STD_SCR(java.math.BigDecimal ISP_STD_SCR) {
    this.ISP_STD_SCR = ISP_STD_SCR;
  }
  public QueryResult with_ISP_STD_SCR(java.math.BigDecimal ISP_STD_SCR) {
    this.ISP_STD_SCR = ISP_STD_SCR;
    return this;
  }
  private String GURT_SAV_DIV_CD;
  public String get_GURT_SAV_DIV_CD() {
    return GURT_SAV_DIV_CD;
  }
  public void set_GURT_SAV_DIV_CD(String GURT_SAV_DIV_CD) {
    this.GURT_SAV_DIV_CD = GURT_SAV_DIV_CD;
  }
  public QueryResult with_GURT_SAV_DIV_CD(String GURT_SAV_DIV_CD) {
    this.GURT_SAV_DIV_CD = GURT_SAV_DIV_CD;
    return this;
  }
  private String SPC_ACCT_DIV_CD;
  public String get_SPC_ACCT_DIV_CD() {
    return SPC_ACCT_DIV_CD;
  }
  public void set_SPC_ACCT_DIV_CD(String SPC_ACCT_DIV_CD) {
    this.SPC_ACCT_DIV_CD = SPC_ACCT_DIV_CD;
  }
  public QueryResult with_SPC_ACCT_DIV_CD(String SPC_ACCT_DIV_CD) {
    this.SPC_ACCT_DIV_CD = SPC_ACCT_DIV_CD;
    return this;
  }
  private String DVND_PAY_YN;
  public String get_DVND_PAY_YN() {
    return DVND_PAY_YN;
  }
  public void set_DVND_PAY_YN(String DVND_PAY_YN) {
    this.DVND_PAY_YN = DVND_PAY_YN;
  }
  public QueryResult with_DVND_PAY_YN(String DVND_PAY_YN) {
    this.DVND_PAY_YN = DVND_PAY_YN;
    return this;
  }
  private String BZCC_JNT_PD_YN;
  public String get_BZCC_JNT_PD_YN() {
    return BZCC_JNT_PD_YN;
  }
  public void set_BZCC_JNT_PD_YN(String BZCC_JNT_PD_YN) {
    this.BZCC_JNT_PD_YN = BZCC_JNT_PD_YN;
  }
  public QueryResult with_BZCC_JNT_PD_YN(String BZCC_JNT_PD_YN) {
    this.BZCC_JNT_PD_YN = BZCC_JNT_PD_YN;
    return this;
  }
  private String FETS_SBC_PSB_YN;
  public String get_FETS_SBC_PSB_YN() {
    return FETS_SBC_PSB_YN;
  }
  public void set_FETS_SBC_PSB_YN(String FETS_SBC_PSB_YN) {
    this.FETS_SBC_PSB_YN = FETS_SBC_PSB_YN;
  }
  public QueryResult with_FETS_SBC_PSB_YN(String FETS_SBC_PSB_YN) {
    this.FETS_SBC_PSB_YN = FETS_SBC_PSB_YN;
    return this;
  }
  private String ACU_GURT_SPR_YN;
  public String get_ACU_GURT_SPR_YN() {
    return ACU_GURT_SPR_YN;
  }
  public void set_ACU_GURT_SPR_YN(String ACU_GURT_SPR_YN) {
    this.ACU_GURT_SPR_YN = ACU_GURT_SPR_YN;
  }
  public QueryResult with_ACU_GURT_SPR_YN(String ACU_GURT_SPR_YN) {
    this.ACU_GURT_SPR_YN = ACU_GURT_SPR_YN;
    return this;
  }
  private String RNWL_COV_BEIN_YN;
  public String get_RNWL_COV_BEIN_YN() {
    return RNWL_COV_BEIN_YN;
  }
  public void set_RNWL_COV_BEIN_YN(String RNWL_COV_BEIN_YN) {
    this.RNWL_COV_BEIN_YN = RNWL_COV_BEIN_YN;
  }
  public QueryResult with_RNWL_COV_BEIN_YN(String RNWL_COV_BEIN_YN) {
    this.RNWL_COV_BEIN_YN = RNWL_COV_BEIN_YN;
    return this;
  }
  private String PREM_CMPT_AGE_STD_CD;
  public String get_PREM_CMPT_AGE_STD_CD() {
    return PREM_CMPT_AGE_STD_CD;
  }
  public void set_PREM_CMPT_AGE_STD_CD(String PREM_CMPT_AGE_STD_CD) {
    this.PREM_CMPT_AGE_STD_CD = PREM_CMPT_AGE_STD_CD;
  }
  public QueryResult with_PREM_CMPT_AGE_STD_CD(String PREM_CMPT_AGE_STD_CD) {
    this.PREM_CMPT_AGE_STD_CD = PREM_CMPT_AGE_STD_CD;
    return this;
  }
  private String HDTL_YN;
  public String get_HDTL_YN() {
    return HDTL_YN;
  }
  public void set_HDTL_YN(String HDTL_YN) {
    this.HDTL_YN = HDTL_YN;
  }
  public QueryResult with_HDTL_YN(String HDTL_YN) {
    this.HDTL_YN = HDTL_YN;
    return this;
  }
  private String ALTN_PY_TRG_DIV_CD;
  public String get_ALTN_PY_TRG_DIV_CD() {
    return ALTN_PY_TRG_DIV_CD;
  }
  public void set_ALTN_PY_TRG_DIV_CD(String ALTN_PY_TRG_DIV_CD) {
    this.ALTN_PY_TRG_DIV_CD = ALTN_PY_TRG_DIV_CD;
  }
  public QueryResult with_ALTN_PY_TRG_DIV_CD(String ALTN_PY_TRG_DIV_CD) {
    this.ALTN_PY_TRG_DIV_CD = ALTN_PY_TRG_DIV_CD;
    return this;
  }
  private String PSTP_REVV_PSB_YN;
  public String get_PSTP_REVV_PSB_YN() {
    return PSTP_REVV_PSB_YN;
  }
  public void set_PSTP_REVV_PSB_YN(String PSTP_REVV_PSB_YN) {
    this.PSTP_REVV_PSB_YN = PSTP_REVV_PSB_YN;
  }
  public QueryResult with_PSTP_REVV_PSB_YN(String PSTP_REVV_PSB_YN) {
    this.PSTP_REVV_PSB_YN = PSTP_REVV_PSB_YN;
    return this;
  }
  private String AYTM_PY_PSB_YN;
  public String get_AYTM_PY_PSB_YN() {
    return AYTM_PY_PSB_YN;
  }
  public void set_AYTM_PY_PSB_YN(String AYTM_PY_PSB_YN) {
    this.AYTM_PY_PSB_YN = AYTM_PY_PSB_YN;
  }
  public QueryResult with_AYTM_PY_PSB_YN(String AYTM_PY_PSB_YN) {
    this.AYTM_PY_PSB_YN = AYTM_PY_PSB_YN;
    return this;
  }
  private java.math.BigDecimal FSS_DAT_OTPT_SEQ;
  public java.math.BigDecimal get_FSS_DAT_OTPT_SEQ() {
    return FSS_DAT_OTPT_SEQ;
  }
  public void set_FSS_DAT_OTPT_SEQ(java.math.BigDecimal FSS_DAT_OTPT_SEQ) {
    this.FSS_DAT_OTPT_SEQ = FSS_DAT_OTPT_SEQ;
  }
  public QueryResult with_FSS_DAT_OTPT_SEQ(java.math.BigDecimal FSS_DAT_OTPT_SEQ) {
    this.FSS_DAT_OTPT_SEQ = FSS_DAT_OTPT_SEQ;
    return this;
  }
  private String SAL_PLAN_INCL_YN;
  public String get_SAL_PLAN_INCL_YN() {
    return SAL_PLAN_INCL_YN;
  }
  public void set_SAL_PLAN_INCL_YN(String SAL_PLAN_INCL_YN) {
    this.SAL_PLAN_INCL_YN = SAL_PLAN_INCL_YN;
  }
  public QueryResult with_SAL_PLAN_INCL_YN(String SAL_PLAN_INCL_YN) {
    this.SAL_PLAN_INCL_YN = SAL_PLAN_INCL_YN;
    return this;
  }
  private String PPBZ_FND_CTRB_INST_CD;
  public String get_PPBZ_FND_CTRB_INST_CD() {
    return PPBZ_FND_CTRB_INST_CD;
  }
  public void set_PPBZ_FND_CTRB_INST_CD(String PPBZ_FND_CTRB_INST_CD) {
    this.PPBZ_FND_CTRB_INST_CD = PPBZ_FND_CTRB_INST_CD;
  }
  public QueryResult with_PPBZ_FND_CTRB_INST_CD(String PPBZ_FND_CTRB_INST_CD) {
    this.PPBZ_FND_CTRB_INST_CD = PPBZ_FND_CTRB_INST_CD;
    return this;
  }
  private java.math.BigDecimal PBPF_BZ_FND_CTRB_RT;
  public java.math.BigDecimal get_PBPF_BZ_FND_CTRB_RT() {
    return PBPF_BZ_FND_CTRB_RT;
  }
  public void set_PBPF_BZ_FND_CTRB_RT(java.math.BigDecimal PBPF_BZ_FND_CTRB_RT) {
    this.PBPF_BZ_FND_CTRB_RT = PBPF_BZ_FND_CTRB_RT;
  }
  public QueryResult with_PBPF_BZ_FND_CTRB_RT(java.math.BigDecimal PBPF_BZ_FND_CTRB_RT) {
    this.PBPF_BZ_FND_CTRB_RT = PBPF_BZ_FND_CTRB_RT;
    return this;
  }
  private String APL_PREM_RDDW_UNT_CD;
  public String get_APL_PREM_RDDW_UNT_CD() {
    return APL_PREM_RDDW_UNT_CD;
  }
  public void set_APL_PREM_RDDW_UNT_CD(String APL_PREM_RDDW_UNT_CD) {
    this.APL_PREM_RDDW_UNT_CD = APL_PREM_RDDW_UNT_CD;
  }
  public QueryResult with_APL_PREM_RDDW_UNT_CD(String APL_PREM_RDDW_UNT_CD) {
    this.APL_PREM_RDDW_UNT_CD = APL_PREM_RDDW_UNT_CD;
    return this;
  }
  private String PD_MNDC_ISS_YN;
  public String get_PD_MNDC_ISS_YN() {
    return PD_MNDC_ISS_YN;
  }
  public void set_PD_MNDC_ISS_YN(String PD_MNDC_ISS_YN) {
    this.PD_MNDC_ISS_YN = PD_MNDC_ISS_YN;
  }
  public QueryResult with_PD_MNDC_ISS_YN(String PD_MNDC_ISS_YN) {
    this.PD_MNDC_ISS_YN = PD_MNDC_ISS_YN;
    return this;
  }
  private String ADJT_PSB_YN;
  public String get_ADJT_PSB_YN() {
    return ADJT_PSB_YN;
  }
  public void set_ADJT_PSB_YN(String ADJT_PSB_YN) {
    this.ADJT_PSB_YN = ADJT_PSB_YN;
  }
  public QueryResult with_ADJT_PSB_YN(String ADJT_PSB_YN) {
    this.ADJT_PSB_YN = ADJT_PSB_YN;
    return this;
  }
  private String INDV_CRP_DIV_CD;
  public String get_INDV_CRP_DIV_CD() {
    return INDV_CRP_DIV_CD;
  }
  public void set_INDV_CRP_DIV_CD(String INDV_CRP_DIV_CD) {
    this.INDV_CRP_DIV_CD = INDV_CRP_DIV_CD;
  }
  public QueryResult with_INDV_CRP_DIV_CD(String INDV_CRP_DIV_CD) {
    this.INDV_CRP_DIV_CD = INDV_CRP_DIV_CD;
    return this;
  }
  private String GRUP_TRT_YN;
  public String get_GRUP_TRT_YN() {
    return GRUP_TRT_YN;
  }
  public void set_GRUP_TRT_YN(String GRUP_TRT_YN) {
    this.GRUP_TRT_YN = GRUP_TRT_YN;
  }
  public QueryResult with_GRUP_TRT_YN(String GRUP_TRT_YN) {
    this.GRUP_TRT_YN = GRUP_TRT_YN;
    return this;
  }
  private String SMNS_POL_PSB_YN;
  public String get_SMNS_POL_PSB_YN() {
    return SMNS_POL_PSB_YN;
  }
  public void set_SMNS_POL_PSB_YN(String SMNS_POL_PSB_YN) {
    this.SMNS_POL_PSB_YN = SMNS_POL_PSB_YN;
  }
  public QueryResult with_SMNS_POL_PSB_YN(String SMNS_POL_PSB_YN) {
    this.SMNS_POL_PSB_YN = SMNS_POL_PSB_YN;
    return this;
  }
  private String GIRO_ISS_PSB_YN;
  public String get_GIRO_ISS_PSB_YN() {
    return GIRO_ISS_PSB_YN;
  }
  public void set_GIRO_ISS_PSB_YN(String GIRO_ISS_PSB_YN) {
    this.GIRO_ISS_PSB_YN = GIRO_ISS_PSB_YN;
  }
  public QueryResult with_GIRO_ISS_PSB_YN(String GIRO_ISS_PSB_YN) {
    this.GIRO_ISS_PSB_YN = GIRO_ISS_PSB_YN;
    return this;
  }
  private String PLR_STUP_PSB_YN;
  public String get_PLR_STUP_PSB_YN() {
    return PLR_STUP_PSB_YN;
  }
  public void set_PLR_STUP_PSB_YN(String PLR_STUP_PSB_YN) {
    this.PLR_STUP_PSB_YN = PLR_STUP_PSB_YN;
  }
  public QueryResult with_PLR_STUP_PSB_YN(String PLR_STUP_PSB_YN) {
    this.PLR_STUP_PSB_YN = PLR_STUP_PSB_YN;
    return this;
  }
  private String HNDY_DSG_PSB_YN;
  public String get_HNDY_DSG_PSB_YN() {
    return HNDY_DSG_PSB_YN;
  }
  public void set_HNDY_DSG_PSB_YN(String HNDY_DSG_PSB_YN) {
    this.HNDY_DSG_PSB_YN = HNDY_DSG_PSB_YN;
  }
  public QueryResult with_HNDY_DSG_PSB_YN(String HNDY_DSG_PSB_YN) {
    this.HNDY_DSG_PSB_YN = HNDY_DSG_PSB_YN;
    return this;
  }
  private String CLOG_DPC_INP_YN;
  public String get_CLOG_DPC_INP_YN() {
    return CLOG_DPC_INP_YN;
  }
  public void set_CLOG_DPC_INP_YN(String CLOG_DPC_INP_YN) {
    this.CLOG_DPC_INP_YN = CLOG_DPC_INP_YN;
  }
  public QueryResult with_CLOG_DPC_INP_YN(String CLOG_DPC_INP_YN) {
    this.CLOG_DPC_INP_YN = CLOG_DPC_INP_YN;
    return this;
  }
  private String KORE_PD_CD;
  public String get_KORE_PD_CD() {
    return KORE_PD_CD;
  }
  public void set_KORE_PD_CD(String KORE_PD_CD) {
    this.KORE_PD_CD = KORE_PD_CD;
  }
  public QueryResult with_KORE_PD_CD(String KORE_PD_CD) {
    this.KORE_PD_CD = KORE_PD_CD;
    return this;
  }
  private String CLUS_DIV_CD;
  public String get_CLUS_DIV_CD() {
    return CLUS_DIV_CD;
  }
  public void set_CLUS_DIV_CD(String CLUS_DIV_CD) {
    this.CLUS_DIV_CD = CLUS_DIV_CD;
  }
  public QueryResult with_CLUS_DIV_CD(String CLUS_DIV_CD) {
    this.CLUS_DIV_CD = CLUS_DIV_CD;
    return this;
  }
  private String LGTM_CTR_CR_XTR_MD_CD;
  public String get_LGTM_CTR_CR_XTR_MD_CD() {
    return LGTM_CTR_CR_XTR_MD_CD;
  }
  public void set_LGTM_CTR_CR_XTR_MD_CD(String LGTM_CTR_CR_XTR_MD_CD) {
    this.LGTM_CTR_CR_XTR_MD_CD = LGTM_CTR_CR_XTR_MD_CD;
  }
  public QueryResult with_LGTM_CTR_CR_XTR_MD_CD(String LGTM_CTR_CR_XTR_MD_CD) {
    this.LGTM_CTR_CR_XTR_MD_CD = LGTM_CTR_CR_XTR_MD_CD;
    return this;
  }
  private String IPY_PSB_YN;
  public String get_IPY_PSB_YN() {
    return IPY_PSB_YN;
  }
  public void set_IPY_PSB_YN(String IPY_PSB_YN) {
    this.IPY_PSB_YN = IPY_PSB_YN;
  }
  public QueryResult with_IPY_PSB_YN(String IPY_PSB_YN) {
    this.IPY_PSB_YN = IPY_PSB_YN;
    return this;
  }
  private String SRP_APL_TRG_YN;
  public String get_SRP_APL_TRG_YN() {
    return SRP_APL_TRG_YN;
  }
  public void set_SRP_APL_TRG_YN(String SRP_APL_TRG_YN) {
    this.SRP_APL_TRG_YN = SRP_APL_TRG_YN;
  }
  public QueryResult with_SRP_APL_TRG_YN(String SRP_APL_TRG_YN) {
    this.SRP_APL_TRG_YN = SRP_APL_TRG_YN;
    return this;
  }
  private String INCM_DDC_TRG_YN;
  public String get_INCM_DDC_TRG_YN() {
    return INCM_DDC_TRG_YN;
  }
  public void set_INCM_DDC_TRG_YN(String INCM_DDC_TRG_YN) {
    this.INCM_DDC_TRG_YN = INCM_DDC_TRG_YN;
  }
  public QueryResult with_INCM_DDC_TRG_YN(String INCM_DDC_TRG_YN) {
    this.INCM_DDC_TRG_YN = INCM_DDC_TRG_YN;
    return this;
  }
  private String HSEC_DIV_CD;
  public String get_HSEC_DIV_CD() {
    return HSEC_DIV_CD;
  }
  public void set_HSEC_DIV_CD(String HSEC_DIV_CD) {
    this.HSEC_DIV_CD = HSEC_DIV_CD;
  }
  public QueryResult with_HSEC_DIV_CD(String HSEC_DIV_CD) {
    this.HSEC_DIV_CD = HSEC_DIV_CD;
    return this;
  }
  private String SECT_INS_DIV_CD;
  public String get_SECT_INS_DIV_CD() {
    return SECT_INS_DIV_CD;
  }
  public void set_SECT_INS_DIV_CD(String SECT_INS_DIV_CD) {
    this.SECT_INS_DIV_CD = SECT_INS_DIV_CD;
  }
  public QueryResult with_SECT_INS_DIV_CD(String SECT_INS_DIV_CD) {
    this.SECT_INS_DIV_CD = SECT_INS_DIV_CD;
    return this;
  }
  private String PVCTR_ALLW_YN;
  public String get_PVCTR_ALLW_YN() {
    return PVCTR_ALLW_YN;
  }
  public void set_PVCTR_ALLW_YN(String PVCTR_ALLW_YN) {
    this.PVCTR_ALLW_YN = PVCTR_ALLW_YN;
  }
  public QueryResult with_PVCTR_ALLW_YN(String PVCTR_ALLW_YN) {
    this.PVCTR_ALLW_YN = PVCTR_ALLW_YN;
    return this;
  }
  private String IPY_LPS_PRD_DIV_CD;
  public String get_IPY_LPS_PRD_DIV_CD() {
    return IPY_LPS_PRD_DIV_CD;
  }
  public void set_IPY_LPS_PRD_DIV_CD(String IPY_LPS_PRD_DIV_CD) {
    this.IPY_LPS_PRD_DIV_CD = IPY_LPS_PRD_DIV_CD;
  }
  public QueryResult with_IPY_LPS_PRD_DIV_CD(String IPY_LPS_PRD_DIV_CD) {
    this.IPY_LPS_PRD_DIV_CD = IPY_LPS_PRD_DIV_CD;
    return this;
  }
  private String IPY_PPN_PRD_DIV_CD;
  public String get_IPY_PPN_PRD_DIV_CD() {
    return IPY_PPN_PRD_DIV_CD;
  }
  public void set_IPY_PPN_PRD_DIV_CD(String IPY_PPN_PRD_DIV_CD) {
    this.IPY_PPN_PRD_DIV_CD = IPY_PPN_PRD_DIV_CD;
  }
  public QueryResult with_IPY_PPN_PRD_DIV_CD(String IPY_PPN_PRD_DIV_CD) {
    this.IPY_PPN_PRD_DIV_CD = IPY_PPN_PRD_DIV_CD;
    return this;
  }
  private String NCLAM_BNS_EN;
  public String get_NCLAM_BNS_EN() {
    return NCLAM_BNS_EN;
  }
  public void set_NCLAM_BNS_EN(String NCLAM_BNS_EN) {
    this.NCLAM_BNS_EN = NCLAM_BNS_EN;
  }
  public QueryResult with_NCLAM_BNS_EN(String NCLAM_BNS_EN) {
    this.NCLAM_BNS_EN = NCLAM_BNS_EN;
    return this;
  }
  private String RVW_ITMS_CRSS_PD_YN;
  public String get_RVW_ITMS_CRSS_PD_YN() {
    return RVW_ITMS_CRSS_PD_YN;
  }
  public void set_RVW_ITMS_CRSS_PD_YN(String RVW_ITMS_CRSS_PD_YN) {
    this.RVW_ITMS_CRSS_PD_YN = RVW_ITMS_CRSS_PD_YN;
  }
  public QueryResult with_RVW_ITMS_CRSS_PD_YN(String RVW_ITMS_CRSS_PD_YN) {
    this.RVW_ITMS_CRSS_PD_YN = RVW_ITMS_CRSS_PD_YN;
    return this;
  }
  private String PRPY_PSB_TP_CD;
  public String get_PRPY_PSB_TP_CD() {
    return PRPY_PSB_TP_CD;
  }
  public void set_PRPY_PSB_TP_CD(String PRPY_PSB_TP_CD) {
    this.PRPY_PSB_TP_CD = PRPY_PSB_TP_CD;
  }
  public QueryResult with_PRPY_PSB_TP_CD(String PRPY_PSB_TP_CD) {
    this.PRPY_PSB_TP_CD = PRPY_PSB_TP_CD;
    return this;
  }
  private String LANN_DIV_CD;
  public String get_LANN_DIV_CD() {
    return LANN_DIV_CD;
  }
  public void set_LANN_DIV_CD(String LANN_DIV_CD) {
    this.LANN_DIV_CD = LANN_DIV_CD;
  }
  public QueryResult with_LANN_DIV_CD(String LANN_DIV_CD) {
    this.LANN_DIV_CD = LANN_DIV_CD;
    return this;
  }
  private String PD_GRP_CD;
  public String get_PD_GRP_CD() {
    return PD_GRP_CD;
  }
  public void set_PD_GRP_CD(String PD_GRP_CD) {
    this.PD_GRP_CD = PD_GRP_CD;
  }
  public QueryResult with_PD_GRP_CD(String PD_GRP_CD) {
    this.PD_GRP_CD = PD_GRP_CD;
    return this;
  }
  private String CNCLL_DDC_AMT_SBTR_YN;
  public String get_CNCLL_DDC_AMT_SBTR_YN() {
    return CNCLL_DDC_AMT_SBTR_YN;
  }
  public void set_CNCLL_DDC_AMT_SBTR_YN(String CNCLL_DDC_AMT_SBTR_YN) {
    this.CNCLL_DDC_AMT_SBTR_YN = CNCLL_DDC_AMT_SBTR_YN;
  }
  public QueryResult with_CNCLL_DDC_AMT_SBTR_YN(String CNCLL_DDC_AMT_SBTR_YN) {
    this.CNCLL_DDC_AMT_SBTR_YN = CNCLL_DDC_AMT_SBTR_YN;
    return this;
  }
  private java.math.BigDecimal CNCLL_DDC_YR_NUM;
  public java.math.BigDecimal get_CNCLL_DDC_YR_NUM() {
    return CNCLL_DDC_YR_NUM;
  }
  public void set_CNCLL_DDC_YR_NUM(java.math.BigDecimal CNCLL_DDC_YR_NUM) {
    this.CNCLL_DDC_YR_NUM = CNCLL_DDC_YR_NUM;
  }
  public QueryResult with_CNCLL_DDC_YR_NUM(java.math.BigDecimal CNCLL_DDC_YR_NUM) {
    this.CNCLL_DDC_YR_NUM = CNCLL_DDC_YR_NUM;
    return this;
  }
  private java.math.BigDecimal XPT_INTR;
  public java.math.BigDecimal get_XPT_INTR() {
    return XPT_INTR;
  }
  public void set_XPT_INTR(java.math.BigDecimal XPT_INTR) {
    this.XPT_INTR = XPT_INTR;
  }
  public QueryResult with_XPT_INTR(java.math.BigDecimal XPT_INTR) {
    this.XPT_INTR = XPT_INTR;
    return this;
  }
  private String BNCA_YN;
  public String get_BNCA_YN() {
    return BNCA_YN;
  }
  public void set_BNCA_YN(String BNCA_YN) {
    this.BNCA_YN = BNCA_YN;
  }
  public QueryResult with_BNCA_YN(String BNCA_YN) {
    this.BNCA_YN = BNCA_YN;
    return this;
  }
  private String MID_AMT_PAY_YN;
  public String get_MID_AMT_PAY_YN() {
    return MID_AMT_PAY_YN;
  }
  public void set_MID_AMT_PAY_YN(String MID_AMT_PAY_YN) {
    this.MID_AMT_PAY_YN = MID_AMT_PAY_YN;
  }
  public QueryResult with_MID_AMT_PAY_YN(String MID_AMT_PAY_YN) {
    this.MID_AMT_PAY_YN = MID_AMT_PAY_YN;
    return this;
  }
  private String HFWY_WDR_YN;
  public String get_HFWY_WDR_YN() {
    return HFWY_WDR_YN;
  }
  public void set_HFWY_WDR_YN(String HFWY_WDR_YN) {
    this.HFWY_WDR_YN = HFWY_WDR_YN;
  }
  public QueryResult with_HFWY_WDR_YN(String HFWY_WDR_YN) {
    this.HFWY_WDR_YN = HFWY_WDR_YN;
    return this;
  }
  private String LNK_PD_CD;
  public String get_LNK_PD_CD() {
    return LNK_PD_CD;
  }
  public void set_LNK_PD_CD(String LNK_PD_CD) {
    this.LNK_PD_CD = LNK_PD_CD;
  }
  public QueryResult with_LNK_PD_CD(String LNK_PD_CD) {
    this.LNK_PD_CD = LNK_PD_CD;
    return this;
  }
  private String APL_PD_CD;
  public String get_APL_PD_CD() {
    return APL_PD_CD;
  }
  public void set_APL_PD_CD(String APL_PD_CD) {
    this.APL_PD_CD = APL_PD_CD;
  }
  public QueryResult with_APL_PD_CD(String APL_PD_CD) {
    this.APL_PD_CD = APL_PD_CD;
    return this;
  }
  private String RPT_PD_CD;
  public String get_RPT_PD_CD() {
    return RPT_PD_CD;
  }
  public void set_RPT_PD_CD(String RPT_PD_CD) {
    this.RPT_PD_CD = RPT_PD_CD;
  }
  public QueryResult with_RPT_PD_CD(String RPT_PD_CD) {
    this.RPT_PD_CD = RPT_PD_CD;
    return this;
  }
  private String RPT_PD_NM;
  public String get_RPT_PD_NM() {
    return RPT_PD_NM;
  }
  public void set_RPT_PD_NM(String RPT_PD_NM) {
    this.RPT_PD_NM = RPT_PD_NM;
  }
  public QueryResult with_RPT_PD_NM(String RPT_PD_NM) {
    this.RPT_PD_NM = RPT_PD_NM;
    return this;
  }
  private String RMK_CON;
  public String get_RMK_CON() {
    return RMK_CON;
  }
  public void set_RMK_CON(String RMK_CON) {
    this.RMK_CON = RMK_CON;
  }
  public QueryResult with_RMK_CON(String RMK_CON) {
    this.RMK_CON = RMK_CON;
    return this;
  }
  private String BZPLN_PD_CTG_CD;
  public String get_BZPLN_PD_CTG_CD() {
    return BZPLN_PD_CTG_CD;
  }
  public void set_BZPLN_PD_CTG_CD(String BZPLN_PD_CTG_CD) {
    this.BZPLN_PD_CTG_CD = BZPLN_PD_CTG_CD;
  }
  public QueryResult with_BZPLN_PD_CTG_CD(String BZPLN_PD_CTG_CD) {
    this.BZPLN_PD_CTG_CD = BZPLN_PD_CTG_CD;
    return this;
  }
  private String ITGR_PD_YN;
  public String get_ITGR_PD_YN() {
    return ITGR_PD_YN;
  }
  public void set_ITGR_PD_YN(String ITGR_PD_YN) {
    this.ITGR_PD_YN = ITGR_PD_YN;
  }
  public QueryResult with_ITGR_PD_YN(String ITGR_PD_YN) {
    this.ITGR_PD_YN = ITGR_PD_YN;
    return this;
  }
  private String EXPR_RFD_APL_DIV_CD;
  public String get_EXPR_RFD_APL_DIV_CD() {
    return EXPR_RFD_APL_DIV_CD;
  }
  public void set_EXPR_RFD_APL_DIV_CD(String EXPR_RFD_APL_DIV_CD) {
    this.EXPR_RFD_APL_DIV_CD = EXPR_RFD_APL_DIV_CD;
  }
  public QueryResult with_EXPR_RFD_APL_DIV_CD(String EXPR_RFD_APL_DIV_CD) {
    this.EXPR_RFD_APL_DIV_CD = EXPR_RFD_APL_DIV_CD;
    return this;
  }
  private String SLZ_PD_DIV_CD;
  public String get_SLZ_PD_DIV_CD() {
    return SLZ_PD_DIV_CD;
  }
  public void set_SLZ_PD_DIV_CD(String SLZ_PD_DIV_CD) {
    this.SLZ_PD_DIV_CD = SLZ_PD_DIV_CD;
  }
  public QueryResult with_SLZ_PD_DIV_CD(String SLZ_PD_DIV_CD) {
    this.SLZ_PD_DIV_CD = SLZ_PD_DIV_CD;
    return this;
  }
  private String ANN_DIV_CD;
  public String get_ANN_DIV_CD() {
    return ANN_DIV_CD;
  }
  public void set_ANN_DIV_CD(String ANN_DIV_CD) {
    this.ANN_DIV_CD = ANN_DIV_CD;
  }
  public QueryResult with_ANN_DIV_CD(String ANN_DIV_CD) {
    this.ANN_DIV_CD = ANN_DIV_CD;
    return this;
  }
  private String ANN_CAL_TP_CD;
  public String get_ANN_CAL_TP_CD() {
    return ANN_CAL_TP_CD;
  }
  public void set_ANN_CAL_TP_CD(String ANN_CAL_TP_CD) {
    this.ANN_CAL_TP_CD = ANN_CAL_TP_CD;
  }
  public QueryResult with_ANN_CAL_TP_CD(String ANN_CAL_TP_CD) {
    this.ANN_CAL_TP_CD = ANN_CAL_TP_CD;
    return this;
  }
  private String PRPY_DC_APL_PREM_CD;
  public String get_PRPY_DC_APL_PREM_CD() {
    return PRPY_DC_APL_PREM_CD;
  }
  public void set_PRPY_DC_APL_PREM_CD(String PRPY_DC_APL_PREM_CD) {
    this.PRPY_DC_APL_PREM_CD = PRPY_DC_APL_PREM_CD;
  }
  public QueryResult with_PRPY_DC_APL_PREM_CD(String PRPY_DC_APL_PREM_CD) {
    this.PRPY_DC_APL_PREM_CD = PRPY_DC_APL_PREM_CD;
    return this;
  }
  private String HFWY_WDR_RFD_STD_CON;
  public String get_HFWY_WDR_RFD_STD_CON() {
    return HFWY_WDR_RFD_STD_CON;
  }
  public void set_HFWY_WDR_RFD_STD_CON(String HFWY_WDR_RFD_STD_CON) {
    this.HFWY_WDR_RFD_STD_CON = HFWY_WDR_RFD_STD_CON;
  }
  public QueryResult with_HFWY_WDR_RFD_STD_CON(String HFWY_WDR_RFD_STD_CON) {
    this.HFWY_WDR_RFD_STD_CON = HFWY_WDR_RFD_STD_CON;
    return this;
  }
  private String CI_PD_YN;
  public String get_CI_PD_YN() {
    return CI_PD_YN;
  }
  public void set_CI_PD_YN(String CI_PD_YN) {
    this.CI_PD_YN = CI_PD_YN;
  }
  public QueryResult with_CI_PD_YN(String CI_PD_YN) {
    this.CI_PD_YN = CI_PD_YN;
    return this;
  }
  private String REGPE_NM;
  public String get_REGPE_NM() {
    return REGPE_NM;
  }
  public void set_REGPE_NM(String REGPE_NM) {
    this.REGPE_NM = REGPE_NM;
  }
  public QueryResult with_REGPE_NM(String REGPE_NM) {
    this.REGPE_NM = REGPE_NM;
    return this;
  }
  private java.sql.Timestamp REG_DT;
  public java.sql.Timestamp get_REG_DT() {
    return REG_DT;
  }
  public void set_REG_DT(java.sql.Timestamp REG_DT) {
    this.REG_DT = REG_DT;
  }
  public QueryResult with_REG_DT(java.sql.Timestamp REG_DT) {
    this.REG_DT = REG_DT;
    return this;
  }
  private String MME_RPT_PD_CD;
  public String get_MME_RPT_PD_CD() {
    return MME_RPT_PD_CD;
  }
  public void set_MME_RPT_PD_CD(String MME_RPT_PD_CD) {
    this.MME_RPT_PD_CD = MME_RPT_PD_CD;
  }
  public QueryResult with_MME_RPT_PD_CD(String MME_RPT_PD_CD) {
    this.MME_RPT_PD_CD = MME_RPT_PD_CD;
    return this;
  }
  private String MME_RPT_PD_CD_NM;
  public String get_MME_RPT_PD_CD_NM() {
    return MME_RPT_PD_CD_NM;
  }
  public void set_MME_RPT_PD_CD_NM(String MME_RPT_PD_CD_NM) {
    this.MME_RPT_PD_CD_NM = MME_RPT_PD_CD_NM;
  }
  public QueryResult with_MME_RPT_PD_CD_NM(String MME_RPT_PD_CD_NM) {
    this.MME_RPT_PD_CD_NM = MME_RPT_PD_CD_NM;
    return this;
  }
  private String AYTM_PY_LM_AMT_DIV_CD;
  public String get_AYTM_PY_LM_AMT_DIV_CD() {
    return AYTM_PY_LM_AMT_DIV_CD;
  }
  public void set_AYTM_PY_LM_AMT_DIV_CD(String AYTM_PY_LM_AMT_DIV_CD) {
    this.AYTM_PY_LM_AMT_DIV_CD = AYTM_PY_LM_AMT_DIV_CD;
  }
  public QueryResult with_AYTM_PY_LM_AMT_DIV_CD(String AYTM_PY_LM_AMT_DIV_CD) {
    this.AYTM_PY_LM_AMT_DIV_CD = AYTM_PY_LM_AMT_DIV_CD;
    return this;
  }
  private String ICLO_PSB_YN;
  public String get_ICLO_PSB_YN() {
    return ICLO_PSB_YN;
  }
  public void set_ICLO_PSB_YN(String ICLO_PSB_YN) {
    this.ICLO_PSB_YN = ICLO_PSB_YN;
  }
  public QueryResult with_ICLO_PSB_YN(String ICLO_PSB_YN) {
    this.ICLO_PSB_YN = ICLO_PSB_YN;
    return this;
  }
  private String UNT_PD_SAL_NM;
  public String get_UNT_PD_SAL_NM() {
    return UNT_PD_SAL_NM;
  }
  public void set_UNT_PD_SAL_NM(String UNT_PD_SAL_NM) {
    this.UNT_PD_SAL_NM = UNT_PD_SAL_NM;
  }
  public QueryResult with_UNT_PD_SAL_NM(String UNT_PD_SAL_NM) {
    this.UNT_PD_SAL_NM = UNT_PD_SAL_NM;
    return this;
  }
  private String ISP_PD_CTG_CD;
  public String get_ISP_PD_CTG_CD() {
    return ISP_PD_CTG_CD;
  }
  public void set_ISP_PD_CTG_CD(String ISP_PD_CTG_CD) {
    this.ISP_PD_CTG_CD = ISP_PD_CTG_CD;
  }
  public QueryResult with_ISP_PD_CTG_CD(String ISP_PD_CTG_CD) {
    this.ISP_PD_CTG_CD = ISP_PD_CTG_CD;
    return this;
  }
  private String LGTM_INDV_GRUP_DIV_CD;
  public String get_LGTM_INDV_GRUP_DIV_CD() {
    return LGTM_INDV_GRUP_DIV_CD;
  }
  public void set_LGTM_INDV_GRUP_DIV_CD(String LGTM_INDV_GRUP_DIV_CD) {
    this.LGTM_INDV_GRUP_DIV_CD = LGTM_INDV_GRUP_DIV_CD;
  }
  public QueryResult with_LGTM_INDV_GRUP_DIV_CD(String LGTM_INDV_GRUP_DIV_CD) {
    this.LGTM_INDV_GRUP_DIV_CD = LGTM_INDV_GRUP_DIV_CD;
    return this;
  }
  private String KIDI_PD_CD;
  public String get_KIDI_PD_CD() {
    return KIDI_PD_CD;
  }
  public void set_KIDI_PD_CD(String KIDI_PD_CD) {
    this.KIDI_PD_CD = KIDI_PD_CD;
  }
  public QueryResult with_KIDI_PD_CD(String KIDI_PD_CD) {
    this.KIDI_PD_CD = KIDI_PD_CD;
    return this;
  }
  private String PRDY_AMT_PD_GRP_CD;
  public String get_PRDY_AMT_PD_GRP_CD() {
    return PRDY_AMT_PD_GRP_CD;
  }
  public void set_PRDY_AMT_PD_GRP_CD(String PRDY_AMT_PD_GRP_CD) {
    this.PRDY_AMT_PD_GRP_CD = PRDY_AMT_PD_GRP_CD;
  }
  public QueryResult with_PRDY_AMT_PD_GRP_CD(String PRDY_AMT_PD_GRP_CD) {
    this.PRDY_AMT_PD_GRP_CD = PRDY_AMT_PD_GRP_CD;
    return this;
  }
  private java.math.BigDecimal STND_INTR;
  public java.math.BigDecimal get_STND_INTR() {
    return STND_INTR;
  }
  public void set_STND_INTR(java.math.BigDecimal STND_INTR) {
    this.STND_INTR = STND_INTR;
  }
  public QueryResult with_STND_INTR(java.math.BigDecimal STND_INTR) {
    this.STND_INTR = STND_INTR;
    return this;
  }
  private String MDF_RT_APL_DIV_CD;
  public String get_MDF_RT_APL_DIV_CD() {
    return MDF_RT_APL_DIV_CD;
  }
  public void set_MDF_RT_APL_DIV_CD(String MDF_RT_APL_DIV_CD) {
    this.MDF_RT_APL_DIV_CD = MDF_RT_APL_DIV_CD;
  }
  public QueryResult with_MDF_RT_APL_DIV_CD(String MDF_RT_APL_DIV_CD) {
    this.MDF_RT_APL_DIV_CD = MDF_RT_APL_DIV_CD;
    return this;
  }
  private String INDP_SIC_PD_YN;
  public String get_INDP_SIC_PD_YN() {
    return INDP_SIC_PD_YN;
  }
  public void set_INDP_SIC_PD_YN(String INDP_SIC_PD_YN) {
    this.INDP_SIC_PD_YN = INDP_SIC_PD_YN;
  }
  public QueryResult with_INDP_SIC_PD_YN(String INDP_SIC_PD_YN) {
    this.INDP_SIC_PD_YN = INDP_SIC_PD_YN;
    return this;
  }
  private String CKUP_TRG_PD_YN;
  public String get_CKUP_TRG_PD_YN() {
    return CKUP_TRG_PD_YN;
  }
  public void set_CKUP_TRG_PD_YN(String CKUP_TRG_PD_YN) {
    this.CKUP_TRG_PD_YN = CKUP_TRG_PD_YN;
  }
  public QueryResult with_CKUP_TRG_PD_YN(String CKUP_TRG_PD_YN) {
    this.CKUP_TRG_PD_YN = CKUP_TRG_PD_YN;
    return this;
  }
  private String POL_OTPT_WY_DIV_CD;
  public String get_POL_OTPT_WY_DIV_CD() {
    return POL_OTPT_WY_DIV_CD;
  }
  public void set_POL_OTPT_WY_DIV_CD(String POL_OTPT_WY_DIV_CD) {
    this.POL_OTPT_WY_DIV_CD = POL_OTPT_WY_DIV_CD;
  }
  public QueryResult with_POL_OTPT_WY_DIV_CD(String POL_OTPT_WY_DIV_CD) {
    this.POL_OTPT_WY_DIV_CD = POL_OTPT_WY_DIV_CD;
    return this;
  }
  private java.sql.Timestamp SAL_BGN_DT1;
  public java.sql.Timestamp get_SAL_BGN_DT1() {
    return SAL_BGN_DT1;
  }
  public void set_SAL_BGN_DT1(java.sql.Timestamp SAL_BGN_DT1) {
    this.SAL_BGN_DT1 = SAL_BGN_DT1;
  }
  public QueryResult with_SAL_BGN_DT1(java.sql.Timestamp SAL_BGN_DT1) {
    this.SAL_BGN_DT1 = SAL_BGN_DT1;
    return this;
  }
  private String NW_KIDI_PD_CD;
  public String get_NW_KIDI_PD_CD() {
    return NW_KIDI_PD_CD;
  }
  public void set_NW_KIDI_PD_CD(String NW_KIDI_PD_CD) {
    this.NW_KIDI_PD_CD = NW_KIDI_PD_CD;
  }
  public QueryResult with_NW_KIDI_PD_CD(String NW_KIDI_PD_CD) {
    this.NW_KIDI_PD_CD = NW_KIDI_PD_CD;
    return this;
  }
  private String STIC_IDC_PD_CTG_CD;
  public String get_STIC_IDC_PD_CTG_CD() {
    return STIC_IDC_PD_CTG_CD;
  }
  public void set_STIC_IDC_PD_CTG_CD(String STIC_IDC_PD_CTG_CD) {
    this.STIC_IDC_PD_CTG_CD = STIC_IDC_PD_CTG_CD;
  }
  public QueryResult with_STIC_IDC_PD_CTG_CD(String STIC_IDC_PD_CTG_CD) {
    this.STIC_IDC_PD_CTG_CD = STIC_IDC_PD_CTG_CD;
    return this;
  }
  private String QRCD_ADR;
  public String get_QRCD_ADR() {
    return QRCD_ADR;
  }
  public void set_QRCD_ADR(String QRCD_ADR) {
    this.QRCD_ADR = QRCD_ADR;
  }
  public QueryResult with_QRCD_ADR(String QRCD_ADR) {
    this.QRCD_ADR = QRCD_ADR;
    return this;
  }
  private java.math.BigDecimal AVG_PBAN_INTR;
  public java.math.BigDecimal get_AVG_PBAN_INTR() {
    return AVG_PBAN_INTR;
  }
  public void set_AVG_PBAN_INTR(java.math.BigDecimal AVG_PBAN_INTR) {
    this.AVG_PBAN_INTR = AVG_PBAN_INTR;
  }
  public QueryResult with_AVG_PBAN_INTR(java.math.BigDecimal AVG_PBAN_INTR) {
    this.AVG_PBAN_INTR = AVG_PBAN_INTR;
    return this;
  }
  private java.sql.Timestamp EIH_LDG_DTM;
  public java.sql.Timestamp get_EIH_LDG_DTM() {
    return EIH_LDG_DTM;
  }
  public void set_EIH_LDG_DTM(java.sql.Timestamp EIH_LDG_DTM) {
    this.EIH_LDG_DTM = EIH_LDG_DTM;
  }
  public QueryResult with_EIH_LDG_DTM(java.sql.Timestamp EIH_LDG_DTM) {
    this.EIH_LDG_DTM = EIH_LDG_DTM;
    return this;
  }
  private String NW_FAMT_INS_PD_CTG_CD;
  public String get_NW_FAMT_INS_PD_CTG_CD() {
    return NW_FAMT_INS_PD_CTG_CD;
  }
  public void set_NW_FAMT_INS_PD_CTG_CD(String NW_FAMT_INS_PD_CTG_CD) {
    this.NW_FAMT_INS_PD_CTG_CD = NW_FAMT_INS_PD_CTG_CD;
  }
  public QueryResult with_NW_FAMT_INS_PD_CTG_CD(String NW_FAMT_INS_PD_CTG_CD) {
    this.NW_FAMT_INS_PD_CTG_CD = NW_FAMT_INS_PD_CTG_CD;
    return this;
  }
  private String AT_ALTN_PY_TP_CD;
  public String get_AT_ALTN_PY_TP_CD() {
    return AT_ALTN_PY_TP_CD;
  }
  public void set_AT_ALTN_PY_TP_CD(String AT_ALTN_PY_TP_CD) {
    this.AT_ALTN_PY_TP_CD = AT_ALTN_PY_TP_CD;
  }
  public QueryResult with_AT_ALTN_PY_TP_CD(String AT_ALTN_PY_TP_CD) {
    this.AT_ALTN_PY_TP_CD = AT_ALTN_PY_TP_CD;
    return this;
  }
  private java.math.BigDecimal ICLO_STD_RT;
  public java.math.BigDecimal get_ICLO_STD_RT() {
    return ICLO_STD_RT;
  }
  public void set_ICLO_STD_RT(java.math.BigDecimal ICLO_STD_RT) {
    this.ICLO_STD_RT = ICLO_STD_RT;
  }
  public QueryResult with_ICLO_STD_RT(java.math.BigDecimal ICLO_STD_RT) {
    this.ICLO_STD_RT = ICLO_STD_RT;
    return this;
  }
  private String MFRC_PD_YN;
  public String get_MFRC_PD_YN() {
    return MFRC_PD_YN;
  }
  public void set_MFRC_PD_YN(String MFRC_PD_YN) {
    this.MFRC_PD_YN = MFRC_PD_YN;
  }
  public QueryResult with_MFRC_PD_YN(String MFRC_PD_YN) {
    this.MFRC_PD_YN = MFRC_PD_YN;
    return this;
  }
  private String PY_EXEM_LRG_TOP_YN;
  public String get_PY_EXEM_LRG_TOP_YN() {
    return PY_EXEM_LRG_TOP_YN;
  }
  public void set_PY_EXEM_LRG_TOP_YN(String PY_EXEM_LRG_TOP_YN) {
    this.PY_EXEM_LRG_TOP_YN = PY_EXEM_LRG_TOP_YN;
  }
  public QueryResult with_PY_EXEM_LRG_TOP_YN(String PY_EXEM_LRG_TOP_YN) {
    this.PY_EXEM_LRG_TOP_YN = PY_EXEM_LRG_TOP_YN;
    return this;
  }
  private java.math.BigDecimal SCRN_EXPS_SQ;
  public java.math.BigDecimal get_SCRN_EXPS_SQ() {
    return SCRN_EXPS_SQ;
  }
  public void set_SCRN_EXPS_SQ(java.math.BigDecimal SCRN_EXPS_SQ) {
    this.SCRN_EXPS_SQ = SCRN_EXPS_SQ;
  }
  public QueryResult with_SCRN_EXPS_SQ(java.math.BigDecimal SCRN_EXPS_SQ) {
    this.SCRN_EXPS_SQ = SCRN_EXPS_SQ;
    return this;
  }
  private String SAL_BGN_TM;
  public String get_SAL_BGN_TM() {
    return SAL_BGN_TM;
  }
  public void set_SAL_BGN_TM(String SAL_BGN_TM) {
    this.SAL_BGN_TM = SAL_BGN_TM;
  }
  public QueryResult with_SAL_BGN_TM(String SAL_BGN_TM) {
    this.SAL_BGN_TM = SAL_BGN_TM;
    return this;
  }
  private String ITMGP_CD;
  public String get_ITMGP_CD() {
    return ITMGP_CD;
  }
  public void set_ITMGP_CD(String ITMGP_CD) {
    this.ITMGP_CD = ITMGP_CD;
  }
  public QueryResult with_ITMGP_CD(String ITMGP_CD) {
    this.ITMGP_CD = ITMGP_CD;
    return this;
  }
  private String GRUP_PREM_AGE_STD_CD;
  public String get_GRUP_PREM_AGE_STD_CD() {
    return GRUP_PREM_AGE_STD_CD;
  }
  public void set_GRUP_PREM_AGE_STD_CD(String GRUP_PREM_AGE_STD_CD) {
    this.GRUP_PREM_AGE_STD_CD = GRUP_PREM_AGE_STD_CD;
  }
  public QueryResult with_GRUP_PREM_AGE_STD_CD(String GRUP_PREM_AGE_STD_CD) {
    this.GRUP_PREM_AGE_STD_CD = GRUP_PREM_AGE_STD_CD;
    return this;
  }
  private String PDGP_CD;
  public String get_PDGP_CD() {
    return PDGP_CD;
  }
  public void set_PDGP_CD(String PDGP_CD) {
    this.PDGP_CD = PDGP_CD;
  }
  public QueryResult with_PDGP_CD(String PDGP_CD) {
    this.PDGP_CD = PDGP_CD;
    return this;
  }
  private String INS_ITMS_CD;
  public String get_INS_ITMS_CD() {
    return INS_ITMS_CD;
  }
  public void set_INS_ITMS_CD(String INS_ITMS_CD) {
    this.INS_ITMS_CD = INS_ITMS_CD;
  }
  public QueryResult with_INS_ITMS_CD(String INS_ITMS_CD) {
    this.INS_ITMS_CD = INS_ITMS_CD;
    return this;
  }
  private String LNK_INDP_PD_CD;
  public String get_LNK_INDP_PD_CD() {
    return LNK_INDP_PD_CD;
  }
  public void set_LNK_INDP_PD_CD(String LNK_INDP_PD_CD) {
    this.LNK_INDP_PD_CD = LNK_INDP_PD_CD;
  }
  public QueryResult with_LNK_INDP_PD_CD(String LNK_INDP_PD_CD) {
    this.LNK_INDP_PD_CD = LNK_INDP_PD_CD;
    return this;
  }
  private String MBL_CLUS_ADR;
  public String get_MBL_CLUS_ADR() {
    return MBL_CLUS_ADR;
  }
  public void set_MBL_CLUS_ADR(String MBL_CLUS_ADR) {
    this.MBL_CLUS_ADR = MBL_CLUS_ADR;
  }
  public QueryResult with_MBL_CLUS_ADR(String MBL_CLUS_ADR) {
    this.MBL_CLUS_ADR = MBL_CLUS_ADR;
    return this;
  }
  private String MLTD_OBJ_YN;
  public String get_MLTD_OBJ_YN() {
    return MLTD_OBJ_YN;
  }
  public void set_MLTD_OBJ_YN(String MLTD_OBJ_YN) {
    this.MLTD_OBJ_YN = MLTD_OBJ_YN;
  }
  public QueryResult with_MLTD_OBJ_YN(String MLTD_OBJ_YN) {
    this.MLTD_OBJ_YN = MLTD_OBJ_YN;
    return this;
  }
  private String UNT_PD_SCRN_EXPS_NM;
  public String get_UNT_PD_SCRN_EXPS_NM() {
    return UNT_PD_SCRN_EXPS_NM;
  }
  public void set_UNT_PD_SCRN_EXPS_NM(String UNT_PD_SCRN_EXPS_NM) {
    this.UNT_PD_SCRN_EXPS_NM = UNT_PD_SCRN_EXPS_NM;
  }
  public QueryResult with_UNT_PD_SCRN_EXPS_NM(String UNT_PD_SCRN_EXPS_NM) {
    this.UNT_PD_SCRN_EXPS_NM = UNT_PD_SCRN_EXPS_NM;
    return this;
  }
  private String PY_EXEM_KND_TYP_DIV_CD;
  public String get_PY_EXEM_KND_TYP_DIV_CD() {
    return PY_EXEM_KND_TYP_DIV_CD;
  }
  public void set_PY_EXEM_KND_TYP_DIV_CD(String PY_EXEM_KND_TYP_DIV_CD) {
    this.PY_EXEM_KND_TYP_DIV_CD = PY_EXEM_KND_TYP_DIV_CD;
  }
  public QueryResult with_PY_EXEM_KND_TYP_DIV_CD(String PY_EXEM_KND_TYP_DIV_CD) {
    this.PY_EXEM_KND_TYP_DIV_CD = PY_EXEM_KND_TYP_DIV_CD;
    return this;
  }
  private String PY_EXEM_DIV_VAL;
  public String get_PY_EXEM_DIV_VAL() {
    return PY_EXEM_DIV_VAL;
  }
  public void set_PY_EXEM_DIV_VAL(String PY_EXEM_DIV_VAL) {
    this.PY_EXEM_DIV_VAL = PY_EXEM_DIV_VAL;
  }
  public QueryResult with_PY_EXEM_DIV_VAL(String PY_EXEM_DIV_VAL) {
    this.PY_EXEM_DIV_VAL = PY_EXEM_DIV_VAL;
    return this;
  }
  private String FETS_PRD_CAL_DIV_CD;
  public String get_FETS_PRD_CAL_DIV_CD() {
    return FETS_PRD_CAL_DIV_CD;
  }
  public void set_FETS_PRD_CAL_DIV_CD(String FETS_PRD_CAL_DIV_CD) {
    this.FETS_PRD_CAL_DIV_CD = FETS_PRD_CAL_DIV_CD;
  }
  public QueryResult with_FETS_PRD_CAL_DIV_CD(String FETS_PRD_CAL_DIV_CD) {
    this.FETS_PRD_CAL_DIV_CD = FETS_PRD_CAL_DIV_CD;
    return this;
  }
  private String UNT_PD_TP_CD;
  public String get_UNT_PD_TP_CD() {
    return UNT_PD_TP_CD;
  }
  public void set_UNT_PD_TP_CD(String UNT_PD_TP_CD) {
    this.UNT_PD_TP_CD = UNT_PD_TP_CD;
  }
  public QueryResult with_UNT_PD_TP_CD(String UNT_PD_TP_CD) {
    this.UNT_PD_TP_CD = UNT_PD_TP_CD;
    return this;
  }
  private String BZ_IDC_PD_LCTG_NM;
  public String get_BZ_IDC_PD_LCTG_NM() {
    return BZ_IDC_PD_LCTG_NM;
  }
  public void set_BZ_IDC_PD_LCTG_NM(String BZ_IDC_PD_LCTG_NM) {
    this.BZ_IDC_PD_LCTG_NM = BZ_IDC_PD_LCTG_NM;
  }
  public QueryResult with_BZ_IDC_PD_LCTG_NM(String BZ_IDC_PD_LCTG_NM) {
    this.BZ_IDC_PD_LCTG_NM = BZ_IDC_PD_LCTG_NM;
    return this;
  }
  private String BZ_IDC_PD_MCTG_NM;
  public String get_BZ_IDC_PD_MCTG_NM() {
    return BZ_IDC_PD_MCTG_NM;
  }
  public void set_BZ_IDC_PD_MCTG_NM(String BZ_IDC_PD_MCTG_NM) {
    this.BZ_IDC_PD_MCTG_NM = BZ_IDC_PD_MCTG_NM;
  }
  public QueryResult with_BZ_IDC_PD_MCTG_NM(String BZ_IDC_PD_MCTG_NM) {
    this.BZ_IDC_PD_MCTG_NM = BZ_IDC_PD_MCTG_NM;
    return this;
  }
  private String BZ_IDC_PD_CTG_NM;
  public String get_BZ_IDC_PD_CTG_NM() {
    return BZ_IDC_PD_CTG_NM;
  }
  public void set_BZ_IDC_PD_CTG_NM(String BZ_IDC_PD_CTG_NM) {
    this.BZ_IDC_PD_CTG_NM = BZ_IDC_PD_CTG_NM;
  }
  public QueryResult with_BZ_IDC_PD_CTG_NM(String BZ_IDC_PD_CTG_NM) {
    this.BZ_IDC_PD_CTG_NM = BZ_IDC_PD_CTG_NM;
    return this;
  }
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (!(o instanceof QueryResult)) {
      return false;
    }
    QueryResult that = (QueryResult) o;
    boolean equal = true;
    equal = equal && (this.UNT_PD_CD == null ? that.UNT_PD_CD == null : this.UNT_PD_CD.equals(that.UNT_PD_CD));
    equal = equal && (this.VF_DT == null ? that.VF_DT == null : this.VF_DT.equals(that.VF_DT));
    equal = equal && (this.VT_DT == null ? that.VT_DT == null : this.VT_DT.equals(that.VT_DT));
    equal = equal && (this.UNT_PD_NM == null ? that.UNT_PD_NM == null : this.UNT_PD_NM.equals(that.UNT_PD_NM));
    equal = equal && (this.UNT_PD_ABR_NM == null ? that.UNT_PD_ABR_NM == null : this.UNT_PD_ABR_NM.equals(that.UNT_PD_ABR_NM));
    equal = equal && (this.UNT_PD_ENG_NM == null ? that.UNT_PD_ENG_NM == null : this.UNT_PD_ENG_NM.equals(that.UNT_PD_ENG_NM));
    equal = equal && (this.UNT_PD_ENG_ABR_NM == null ? that.UNT_PD_ENG_ABR_NM == null : this.UNT_PD_ENG_ABR_NM.equals(that.UNT_PD_ENG_ABR_NM));
    equal = equal && (this.PD_AUTH_DT == null ? that.PD_AUTH_DT == null : this.PD_AUTH_DT.equals(that.PD_AUTH_DT));
    equal = equal && (this.PD_SAL_TMRR_SUSP_DT == null ? that.PD_SAL_TMRR_SUSP_DT == null : this.PD_SAL_TMRR_SUSP_DT.equals(that.PD_SAL_TMRR_SUSP_DT));
    equal = equal && (this.SAL_BGN_DT == null ? that.SAL_BGN_DT == null : this.SAL_BGN_DT.equals(that.SAL_BGN_DT));
    equal = equal && (this.SAL_ED_DT == null ? that.SAL_ED_DT == null : this.SAL_ED_DT.equals(that.SAL_ED_DT));
    equal = equal && (this.INS_BGN_TM == null ? that.INS_BGN_TM == null : this.INS_BGN_TM.equals(that.INS_BGN_TM));
    equal = equal && (this.INS_ED_TM == null ? that.INS_ED_TM == null : this.INS_ED_TM.equals(that.INS_ED_TM));
    equal = equal && (this.RPS_PD_CD == null ? that.RPS_PD_CD == null : this.RPS_PD_CD.equals(that.RPS_PD_CD));
    equal = equal && (this.OD_PD_CD == null ? that.OD_PD_CD == null : this.OD_PD_CD.equals(that.OD_PD_CD));
    equal = equal && (this.INS_ITMS_DIV_CD == null ? that.INS_ITMS_DIV_CD == null : this.INS_ITMS_DIV_CD.equals(that.INS_ITMS_DIV_CD));
    equal = equal && (this.OD_STIC_PD_CTG_CD == null ? that.OD_STIC_PD_CTG_CD == null : this.OD_STIC_PD_CTG_CD.equals(that.OD_STIC_PD_CTG_CD));
    equal = equal && (this.NW_STIC_PD_CTG_CD == null ? that.NW_STIC_PD_CTG_CD == null : this.NW_STIC_PD_CTG_CD.equals(that.NW_STIC_PD_CTG_CD));
    equal = equal && (this.FAMT_INS_PD_CTG_CD == null ? that.FAMT_INS_PD_CTG_CD == null : this.FAMT_INS_PD_CTG_CD.equals(that.FAMT_INS_PD_CTG_CD));
    equal = equal && (this.PD_AUTH_TP_CD == null ? that.PD_AUTH_TP_CD == null : this.PD_AUTH_TP_CD.equals(that.PD_AUTH_TP_CD));
    equal = equal && (this.ISP_STD_SCR == null ? that.ISP_STD_SCR == null : this.ISP_STD_SCR.equals(that.ISP_STD_SCR));
    equal = equal && (this.GURT_SAV_DIV_CD == null ? that.GURT_SAV_DIV_CD == null : this.GURT_SAV_DIV_CD.equals(that.GURT_SAV_DIV_CD));
    equal = equal && (this.SPC_ACCT_DIV_CD == null ? that.SPC_ACCT_DIV_CD == null : this.SPC_ACCT_DIV_CD.equals(that.SPC_ACCT_DIV_CD));
    equal = equal && (this.DVND_PAY_YN == null ? that.DVND_PAY_YN == null : this.DVND_PAY_YN.equals(that.DVND_PAY_YN));
    equal = equal && (this.BZCC_JNT_PD_YN == null ? that.BZCC_JNT_PD_YN == null : this.BZCC_JNT_PD_YN.equals(that.BZCC_JNT_PD_YN));
    equal = equal && (this.FETS_SBC_PSB_YN == null ? that.FETS_SBC_PSB_YN == null : this.FETS_SBC_PSB_YN.equals(that.FETS_SBC_PSB_YN));
    equal = equal && (this.ACU_GURT_SPR_YN == null ? that.ACU_GURT_SPR_YN == null : this.ACU_GURT_SPR_YN.equals(that.ACU_GURT_SPR_YN));
    equal = equal && (this.RNWL_COV_BEIN_YN == null ? that.RNWL_COV_BEIN_YN == null : this.RNWL_COV_BEIN_YN.equals(that.RNWL_COV_BEIN_YN));
    equal = equal && (this.PREM_CMPT_AGE_STD_CD == null ? that.PREM_CMPT_AGE_STD_CD == null : this.PREM_CMPT_AGE_STD_CD.equals(that.PREM_CMPT_AGE_STD_CD));
    equal = equal && (this.HDTL_YN == null ? that.HDTL_YN == null : this.HDTL_YN.equals(that.HDTL_YN));
    equal = equal && (this.ALTN_PY_TRG_DIV_CD == null ? that.ALTN_PY_TRG_DIV_CD == null : this.ALTN_PY_TRG_DIV_CD.equals(that.ALTN_PY_TRG_DIV_CD));
    equal = equal && (this.PSTP_REVV_PSB_YN == null ? that.PSTP_REVV_PSB_YN == null : this.PSTP_REVV_PSB_YN.equals(that.PSTP_REVV_PSB_YN));
    equal = equal && (this.AYTM_PY_PSB_YN == null ? that.AYTM_PY_PSB_YN == null : this.AYTM_PY_PSB_YN.equals(that.AYTM_PY_PSB_YN));
    equal = equal && (this.FSS_DAT_OTPT_SEQ == null ? that.FSS_DAT_OTPT_SEQ == null : this.FSS_DAT_OTPT_SEQ.equals(that.FSS_DAT_OTPT_SEQ));
    equal = equal && (this.SAL_PLAN_INCL_YN == null ? that.SAL_PLAN_INCL_YN == null : this.SAL_PLAN_INCL_YN.equals(that.SAL_PLAN_INCL_YN));
    equal = equal && (this.PPBZ_FND_CTRB_INST_CD == null ? that.PPBZ_FND_CTRB_INST_CD == null : this.PPBZ_FND_CTRB_INST_CD.equals(that.PPBZ_FND_CTRB_INST_CD));
    equal = equal && (this.PBPF_BZ_FND_CTRB_RT == null ? that.PBPF_BZ_FND_CTRB_RT == null : this.PBPF_BZ_FND_CTRB_RT.equals(that.PBPF_BZ_FND_CTRB_RT));
    equal = equal && (this.APL_PREM_RDDW_UNT_CD == null ? that.APL_PREM_RDDW_UNT_CD == null : this.APL_PREM_RDDW_UNT_CD.equals(that.APL_PREM_RDDW_UNT_CD));
    equal = equal && (this.PD_MNDC_ISS_YN == null ? that.PD_MNDC_ISS_YN == null : this.PD_MNDC_ISS_YN.equals(that.PD_MNDC_ISS_YN));
    equal = equal && (this.ADJT_PSB_YN == null ? that.ADJT_PSB_YN == null : this.ADJT_PSB_YN.equals(that.ADJT_PSB_YN));
    equal = equal && (this.INDV_CRP_DIV_CD == null ? that.INDV_CRP_DIV_CD == null : this.INDV_CRP_DIV_CD.equals(that.INDV_CRP_DIV_CD));
    equal = equal && (this.GRUP_TRT_YN == null ? that.GRUP_TRT_YN == null : this.GRUP_TRT_YN.equals(that.GRUP_TRT_YN));
    equal = equal && (this.SMNS_POL_PSB_YN == null ? that.SMNS_POL_PSB_YN == null : this.SMNS_POL_PSB_YN.equals(that.SMNS_POL_PSB_YN));
    equal = equal && (this.GIRO_ISS_PSB_YN == null ? that.GIRO_ISS_PSB_YN == null : this.GIRO_ISS_PSB_YN.equals(that.GIRO_ISS_PSB_YN));
    equal = equal && (this.PLR_STUP_PSB_YN == null ? that.PLR_STUP_PSB_YN == null : this.PLR_STUP_PSB_YN.equals(that.PLR_STUP_PSB_YN));
    equal = equal && (this.HNDY_DSG_PSB_YN == null ? that.HNDY_DSG_PSB_YN == null : this.HNDY_DSG_PSB_YN.equals(that.HNDY_DSG_PSB_YN));
    equal = equal && (this.CLOG_DPC_INP_YN == null ? that.CLOG_DPC_INP_YN == null : this.CLOG_DPC_INP_YN.equals(that.CLOG_DPC_INP_YN));
    equal = equal && (this.KORE_PD_CD == null ? that.KORE_PD_CD == null : this.KORE_PD_CD.equals(that.KORE_PD_CD));
    equal = equal && (this.CLUS_DIV_CD == null ? that.CLUS_DIV_CD == null : this.CLUS_DIV_CD.equals(that.CLUS_DIV_CD));
    equal = equal && (this.LGTM_CTR_CR_XTR_MD_CD == null ? that.LGTM_CTR_CR_XTR_MD_CD == null : this.LGTM_CTR_CR_XTR_MD_CD.equals(that.LGTM_CTR_CR_XTR_MD_CD));
    equal = equal && (this.IPY_PSB_YN == null ? that.IPY_PSB_YN == null : this.IPY_PSB_YN.equals(that.IPY_PSB_YN));
    equal = equal && (this.SRP_APL_TRG_YN == null ? that.SRP_APL_TRG_YN == null : this.SRP_APL_TRG_YN.equals(that.SRP_APL_TRG_YN));
    equal = equal && (this.INCM_DDC_TRG_YN == null ? that.INCM_DDC_TRG_YN == null : this.INCM_DDC_TRG_YN.equals(that.INCM_DDC_TRG_YN));
    equal = equal && (this.HSEC_DIV_CD == null ? that.HSEC_DIV_CD == null : this.HSEC_DIV_CD.equals(that.HSEC_DIV_CD));
    equal = equal && (this.SECT_INS_DIV_CD == null ? that.SECT_INS_DIV_CD == null : this.SECT_INS_DIV_CD.equals(that.SECT_INS_DIV_CD));
    equal = equal && (this.PVCTR_ALLW_YN == null ? that.PVCTR_ALLW_YN == null : this.PVCTR_ALLW_YN.equals(that.PVCTR_ALLW_YN));
    equal = equal && (this.IPY_LPS_PRD_DIV_CD == null ? that.IPY_LPS_PRD_DIV_CD == null : this.IPY_LPS_PRD_DIV_CD.equals(that.IPY_LPS_PRD_DIV_CD));
    equal = equal && (this.IPY_PPN_PRD_DIV_CD == null ? that.IPY_PPN_PRD_DIV_CD == null : this.IPY_PPN_PRD_DIV_CD.equals(that.IPY_PPN_PRD_DIV_CD));
    equal = equal && (this.NCLAM_BNS_EN == null ? that.NCLAM_BNS_EN == null : this.NCLAM_BNS_EN.equals(that.NCLAM_BNS_EN));
    equal = equal && (this.RVW_ITMS_CRSS_PD_YN == null ? that.RVW_ITMS_CRSS_PD_YN == null : this.RVW_ITMS_CRSS_PD_YN.equals(that.RVW_ITMS_CRSS_PD_YN));
    equal = equal && (this.PRPY_PSB_TP_CD == null ? that.PRPY_PSB_TP_CD == null : this.PRPY_PSB_TP_CD.equals(that.PRPY_PSB_TP_CD));
    equal = equal && (this.LANN_DIV_CD == null ? that.LANN_DIV_CD == null : this.LANN_DIV_CD.equals(that.LANN_DIV_CD));
    equal = equal && (this.PD_GRP_CD == null ? that.PD_GRP_CD == null : this.PD_GRP_CD.equals(that.PD_GRP_CD));
    equal = equal && (this.CNCLL_DDC_AMT_SBTR_YN == null ? that.CNCLL_DDC_AMT_SBTR_YN == null : this.CNCLL_DDC_AMT_SBTR_YN.equals(that.CNCLL_DDC_AMT_SBTR_YN));
    equal = equal && (this.CNCLL_DDC_YR_NUM == null ? that.CNCLL_DDC_YR_NUM == null : this.CNCLL_DDC_YR_NUM.equals(that.CNCLL_DDC_YR_NUM));
    equal = equal && (this.XPT_INTR == null ? that.XPT_INTR == null : this.XPT_INTR.equals(that.XPT_INTR));
    equal = equal && (this.BNCA_YN == null ? that.BNCA_YN == null : this.BNCA_YN.equals(that.BNCA_YN));
    equal = equal && (this.MID_AMT_PAY_YN == null ? that.MID_AMT_PAY_YN == null : this.MID_AMT_PAY_YN.equals(that.MID_AMT_PAY_YN));
    equal = equal && (this.HFWY_WDR_YN == null ? that.HFWY_WDR_YN == null : this.HFWY_WDR_YN.equals(that.HFWY_WDR_YN));
    equal = equal && (this.LNK_PD_CD == null ? that.LNK_PD_CD == null : this.LNK_PD_CD.equals(that.LNK_PD_CD));
    equal = equal && (this.APL_PD_CD == null ? that.APL_PD_CD == null : this.APL_PD_CD.equals(that.APL_PD_CD));
    equal = equal && (this.RPT_PD_CD == null ? that.RPT_PD_CD == null : this.RPT_PD_CD.equals(that.RPT_PD_CD));
    equal = equal && (this.RPT_PD_NM == null ? that.RPT_PD_NM == null : this.RPT_PD_NM.equals(that.RPT_PD_NM));
    equal = equal && (this.RMK_CON == null ? that.RMK_CON == null : this.RMK_CON.equals(that.RMK_CON));
    equal = equal && (this.BZPLN_PD_CTG_CD == null ? that.BZPLN_PD_CTG_CD == null : this.BZPLN_PD_CTG_CD.equals(that.BZPLN_PD_CTG_CD));
    equal = equal && (this.ITGR_PD_YN == null ? that.ITGR_PD_YN == null : this.ITGR_PD_YN.equals(that.ITGR_PD_YN));
    equal = equal && (this.EXPR_RFD_APL_DIV_CD == null ? that.EXPR_RFD_APL_DIV_CD == null : this.EXPR_RFD_APL_DIV_CD.equals(that.EXPR_RFD_APL_DIV_CD));
    equal = equal && (this.SLZ_PD_DIV_CD == null ? that.SLZ_PD_DIV_CD == null : this.SLZ_PD_DIV_CD.equals(that.SLZ_PD_DIV_CD));
    equal = equal && (this.ANN_DIV_CD == null ? that.ANN_DIV_CD == null : this.ANN_DIV_CD.equals(that.ANN_DIV_CD));
    equal = equal && (this.ANN_CAL_TP_CD == null ? that.ANN_CAL_TP_CD == null : this.ANN_CAL_TP_CD.equals(that.ANN_CAL_TP_CD));
    equal = equal && (this.PRPY_DC_APL_PREM_CD == null ? that.PRPY_DC_APL_PREM_CD == null : this.PRPY_DC_APL_PREM_CD.equals(that.PRPY_DC_APL_PREM_CD));
    equal = equal && (this.HFWY_WDR_RFD_STD_CON == null ? that.HFWY_WDR_RFD_STD_CON == null : this.HFWY_WDR_RFD_STD_CON.equals(that.HFWY_WDR_RFD_STD_CON));
    equal = equal && (this.CI_PD_YN == null ? that.CI_PD_YN == null : this.CI_PD_YN.equals(that.CI_PD_YN));
    equal = equal && (this.REGPE_NM == null ? that.REGPE_NM == null : this.REGPE_NM.equals(that.REGPE_NM));
    equal = equal && (this.REG_DT == null ? that.REG_DT == null : this.REG_DT.equals(that.REG_DT));
    equal = equal && (this.MME_RPT_PD_CD == null ? that.MME_RPT_PD_CD == null : this.MME_RPT_PD_CD.equals(that.MME_RPT_PD_CD));
    equal = equal && (this.MME_RPT_PD_CD_NM == null ? that.MME_RPT_PD_CD_NM == null : this.MME_RPT_PD_CD_NM.equals(that.MME_RPT_PD_CD_NM));
    equal = equal && (this.AYTM_PY_LM_AMT_DIV_CD == null ? that.AYTM_PY_LM_AMT_DIV_CD == null : this.AYTM_PY_LM_AMT_DIV_CD.equals(that.AYTM_PY_LM_AMT_DIV_CD));
    equal = equal && (this.ICLO_PSB_YN == null ? that.ICLO_PSB_YN == null : this.ICLO_PSB_YN.equals(that.ICLO_PSB_YN));
    equal = equal && (this.UNT_PD_SAL_NM == null ? that.UNT_PD_SAL_NM == null : this.UNT_PD_SAL_NM.equals(that.UNT_PD_SAL_NM));
    equal = equal && (this.ISP_PD_CTG_CD == null ? that.ISP_PD_CTG_CD == null : this.ISP_PD_CTG_CD.equals(that.ISP_PD_CTG_CD));
    equal = equal && (this.LGTM_INDV_GRUP_DIV_CD == null ? that.LGTM_INDV_GRUP_DIV_CD == null : this.LGTM_INDV_GRUP_DIV_CD.equals(that.LGTM_INDV_GRUP_DIV_CD));
    equal = equal && (this.KIDI_PD_CD == null ? that.KIDI_PD_CD == null : this.KIDI_PD_CD.equals(that.KIDI_PD_CD));
    equal = equal && (this.PRDY_AMT_PD_GRP_CD == null ? that.PRDY_AMT_PD_GRP_CD == null : this.PRDY_AMT_PD_GRP_CD.equals(that.PRDY_AMT_PD_GRP_CD));
    equal = equal && (this.STND_INTR == null ? that.STND_INTR == null : this.STND_INTR.equals(that.STND_INTR));
    equal = equal && (this.MDF_RT_APL_DIV_CD == null ? that.MDF_RT_APL_DIV_CD == null : this.MDF_RT_APL_DIV_CD.equals(that.MDF_RT_APL_DIV_CD));
    equal = equal && (this.INDP_SIC_PD_YN == null ? that.INDP_SIC_PD_YN == null : this.INDP_SIC_PD_YN.equals(that.INDP_SIC_PD_YN));
    equal = equal && (this.CKUP_TRG_PD_YN == null ? that.CKUP_TRG_PD_YN == null : this.CKUP_TRG_PD_YN.equals(that.CKUP_TRG_PD_YN));
    equal = equal && (this.POL_OTPT_WY_DIV_CD == null ? that.POL_OTPT_WY_DIV_CD == null : this.POL_OTPT_WY_DIV_CD.equals(that.POL_OTPT_WY_DIV_CD));
    equal = equal && (this.SAL_BGN_DT1 == null ? that.SAL_BGN_DT1 == null : this.SAL_BGN_DT1.equals(that.SAL_BGN_DT1));
    equal = equal && (this.NW_KIDI_PD_CD == null ? that.NW_KIDI_PD_CD == null : this.NW_KIDI_PD_CD.equals(that.NW_KIDI_PD_CD));
    equal = equal && (this.STIC_IDC_PD_CTG_CD == null ? that.STIC_IDC_PD_CTG_CD == null : this.STIC_IDC_PD_CTG_CD.equals(that.STIC_IDC_PD_CTG_CD));
    equal = equal && (this.QRCD_ADR == null ? that.QRCD_ADR == null : this.QRCD_ADR.equals(that.QRCD_ADR));
    equal = equal && (this.AVG_PBAN_INTR == null ? that.AVG_PBAN_INTR == null : this.AVG_PBAN_INTR.equals(that.AVG_PBAN_INTR));
    equal = equal && (this.EIH_LDG_DTM == null ? that.EIH_LDG_DTM == null : this.EIH_LDG_DTM.equals(that.EIH_LDG_DTM));
    equal = equal && (this.NW_FAMT_INS_PD_CTG_CD == null ? that.NW_FAMT_INS_PD_CTG_CD == null : this.NW_FAMT_INS_PD_CTG_CD.equals(that.NW_FAMT_INS_PD_CTG_CD));
    equal = equal && (this.AT_ALTN_PY_TP_CD == null ? that.AT_ALTN_PY_TP_CD == null : this.AT_ALTN_PY_TP_CD.equals(that.AT_ALTN_PY_TP_CD));
    equal = equal && (this.ICLO_STD_RT == null ? that.ICLO_STD_RT == null : this.ICLO_STD_RT.equals(that.ICLO_STD_RT));
    equal = equal && (this.MFRC_PD_YN == null ? that.MFRC_PD_YN == null : this.MFRC_PD_YN.equals(that.MFRC_PD_YN));
    equal = equal && (this.PY_EXEM_LRG_TOP_YN == null ? that.PY_EXEM_LRG_TOP_YN == null : this.PY_EXEM_LRG_TOP_YN.equals(that.PY_EXEM_LRG_TOP_YN));
    equal = equal && (this.SCRN_EXPS_SQ == null ? that.SCRN_EXPS_SQ == null : this.SCRN_EXPS_SQ.equals(that.SCRN_EXPS_SQ));
    equal = equal && (this.SAL_BGN_TM == null ? that.SAL_BGN_TM == null : this.SAL_BGN_TM.equals(that.SAL_BGN_TM));
    equal = equal && (this.ITMGP_CD == null ? that.ITMGP_CD == null : this.ITMGP_CD.equals(that.ITMGP_CD));
    equal = equal && (this.GRUP_PREM_AGE_STD_CD == null ? that.GRUP_PREM_AGE_STD_CD == null : this.GRUP_PREM_AGE_STD_CD.equals(that.GRUP_PREM_AGE_STD_CD));
    equal = equal && (this.PDGP_CD == null ? that.PDGP_CD == null : this.PDGP_CD.equals(that.PDGP_CD));
    equal = equal && (this.INS_ITMS_CD == null ? that.INS_ITMS_CD == null : this.INS_ITMS_CD.equals(that.INS_ITMS_CD));
    equal = equal && (this.LNK_INDP_PD_CD == null ? that.LNK_INDP_PD_CD == null : this.LNK_INDP_PD_CD.equals(that.LNK_INDP_PD_CD));
    equal = equal && (this.MBL_CLUS_ADR == null ? that.MBL_CLUS_ADR == null : this.MBL_CLUS_ADR.equals(that.MBL_CLUS_ADR));
    equal = equal && (this.MLTD_OBJ_YN == null ? that.MLTD_OBJ_YN == null : this.MLTD_OBJ_YN.equals(that.MLTD_OBJ_YN));
    equal = equal && (this.UNT_PD_SCRN_EXPS_NM == null ? that.UNT_PD_SCRN_EXPS_NM == null : this.UNT_PD_SCRN_EXPS_NM.equals(that.UNT_PD_SCRN_EXPS_NM));
    equal = equal && (this.PY_EXEM_KND_TYP_DIV_CD == null ? that.PY_EXEM_KND_TYP_DIV_CD == null : this.PY_EXEM_KND_TYP_DIV_CD.equals(that.PY_EXEM_KND_TYP_DIV_CD));
    equal = equal && (this.PY_EXEM_DIV_VAL == null ? that.PY_EXEM_DIV_VAL == null : this.PY_EXEM_DIV_VAL.equals(that.PY_EXEM_DIV_VAL));
    equal = equal && (this.FETS_PRD_CAL_DIV_CD == null ? that.FETS_PRD_CAL_DIV_CD == null : this.FETS_PRD_CAL_DIV_CD.equals(that.FETS_PRD_CAL_DIV_CD));
    equal = equal && (this.UNT_PD_TP_CD == null ? that.UNT_PD_TP_CD == null : this.UNT_PD_TP_CD.equals(that.UNT_PD_TP_CD));
    equal = equal && (this.BZ_IDC_PD_LCTG_NM == null ? that.BZ_IDC_PD_LCTG_NM == null : this.BZ_IDC_PD_LCTG_NM.equals(that.BZ_IDC_PD_LCTG_NM));
    equal = equal && (this.BZ_IDC_PD_MCTG_NM == null ? that.BZ_IDC_PD_MCTG_NM == null : this.BZ_IDC_PD_MCTG_NM.equals(that.BZ_IDC_PD_MCTG_NM));
    equal = equal && (this.BZ_IDC_PD_CTG_NM == null ? that.BZ_IDC_PD_CTG_NM == null : this.BZ_IDC_PD_CTG_NM.equals(that.BZ_IDC_PD_CTG_NM));
    return equal;
  }
  public boolean equals0(Object o) {
    if (this == o) {
      return true;
    }
    if (!(o instanceof QueryResult)) {
      return false;
    }
    QueryResult that = (QueryResult) o;
    boolean equal = true;
    equal = equal && (this.UNT_PD_CD == null ? that.UNT_PD_CD == null : this.UNT_PD_CD.equals(that.UNT_PD_CD));
    equal = equal && (this.VF_DT == null ? that.VF_DT == null : this.VF_DT.equals(that.VF_DT));
    equal = equal && (this.VT_DT == null ? that.VT_DT == null : this.VT_DT.equals(that.VT_DT));
    equal = equal && (this.UNT_PD_NM == null ? that.UNT_PD_NM == null : this.UNT_PD_NM.equals(that.UNT_PD_NM));
    equal = equal && (this.UNT_PD_ABR_NM == null ? that.UNT_PD_ABR_NM == null : this.UNT_PD_ABR_NM.equals(that.UNT_PD_ABR_NM));
    equal = equal && (this.UNT_PD_ENG_NM == null ? that.UNT_PD_ENG_NM == null : this.UNT_PD_ENG_NM.equals(that.UNT_PD_ENG_NM));
    equal = equal && (this.UNT_PD_ENG_ABR_NM == null ? that.UNT_PD_ENG_ABR_NM == null : this.UNT_PD_ENG_ABR_NM.equals(that.UNT_PD_ENG_ABR_NM));
    equal = equal && (this.PD_AUTH_DT == null ? that.PD_AUTH_DT == null : this.PD_AUTH_DT.equals(that.PD_AUTH_DT));
    equal = equal && (this.PD_SAL_TMRR_SUSP_DT == null ? that.PD_SAL_TMRR_SUSP_DT == null : this.PD_SAL_TMRR_SUSP_DT.equals(that.PD_SAL_TMRR_SUSP_DT));
    equal = equal && (this.SAL_BGN_DT == null ? that.SAL_BGN_DT == null : this.SAL_BGN_DT.equals(that.SAL_BGN_DT));
    equal = equal && (this.SAL_ED_DT == null ? that.SAL_ED_DT == null : this.SAL_ED_DT.equals(that.SAL_ED_DT));
    equal = equal && (this.INS_BGN_TM == null ? that.INS_BGN_TM == null : this.INS_BGN_TM.equals(that.INS_BGN_TM));
    equal = equal && (this.INS_ED_TM == null ? that.INS_ED_TM == null : this.INS_ED_TM.equals(that.INS_ED_TM));
    equal = equal && (this.RPS_PD_CD == null ? that.RPS_PD_CD == null : this.RPS_PD_CD.equals(that.RPS_PD_CD));
    equal = equal && (this.OD_PD_CD == null ? that.OD_PD_CD == null : this.OD_PD_CD.equals(that.OD_PD_CD));
    equal = equal && (this.INS_ITMS_DIV_CD == null ? that.INS_ITMS_DIV_CD == null : this.INS_ITMS_DIV_CD.equals(that.INS_ITMS_DIV_CD));
    equal = equal && (this.OD_STIC_PD_CTG_CD == null ? that.OD_STIC_PD_CTG_CD == null : this.OD_STIC_PD_CTG_CD.equals(that.OD_STIC_PD_CTG_CD));
    equal = equal && (this.NW_STIC_PD_CTG_CD == null ? that.NW_STIC_PD_CTG_CD == null : this.NW_STIC_PD_CTG_CD.equals(that.NW_STIC_PD_CTG_CD));
    equal = equal && (this.FAMT_INS_PD_CTG_CD == null ? that.FAMT_INS_PD_CTG_CD == null : this.FAMT_INS_PD_CTG_CD.equals(that.FAMT_INS_PD_CTG_CD));
    equal = equal && (this.PD_AUTH_TP_CD == null ? that.PD_AUTH_TP_CD == null : this.PD_AUTH_TP_CD.equals(that.PD_AUTH_TP_CD));
    equal = equal && (this.ISP_STD_SCR == null ? that.ISP_STD_SCR == null : this.ISP_STD_SCR.equals(that.ISP_STD_SCR));
    equal = equal && (this.GURT_SAV_DIV_CD == null ? that.GURT_SAV_DIV_CD == null : this.GURT_SAV_DIV_CD.equals(that.GURT_SAV_DIV_CD));
    equal = equal && (this.SPC_ACCT_DIV_CD == null ? that.SPC_ACCT_DIV_CD == null : this.SPC_ACCT_DIV_CD.equals(that.SPC_ACCT_DIV_CD));
    equal = equal && (this.DVND_PAY_YN == null ? that.DVND_PAY_YN == null : this.DVND_PAY_YN.equals(that.DVND_PAY_YN));
    equal = equal && (this.BZCC_JNT_PD_YN == null ? that.BZCC_JNT_PD_YN == null : this.BZCC_JNT_PD_YN.equals(that.BZCC_JNT_PD_YN));
    equal = equal && (this.FETS_SBC_PSB_YN == null ? that.FETS_SBC_PSB_YN == null : this.FETS_SBC_PSB_YN.equals(that.FETS_SBC_PSB_YN));
    equal = equal && (this.ACU_GURT_SPR_YN == null ? that.ACU_GURT_SPR_YN == null : this.ACU_GURT_SPR_YN.equals(that.ACU_GURT_SPR_YN));
    equal = equal && (this.RNWL_COV_BEIN_YN == null ? that.RNWL_COV_BEIN_YN == null : this.RNWL_COV_BEIN_YN.equals(that.RNWL_COV_BEIN_YN));
    equal = equal && (this.PREM_CMPT_AGE_STD_CD == null ? that.PREM_CMPT_AGE_STD_CD == null : this.PREM_CMPT_AGE_STD_CD.equals(that.PREM_CMPT_AGE_STD_CD));
    equal = equal && (this.HDTL_YN == null ? that.HDTL_YN == null : this.HDTL_YN.equals(that.HDTL_YN));
    equal = equal && (this.ALTN_PY_TRG_DIV_CD == null ? that.ALTN_PY_TRG_DIV_CD == null : this.ALTN_PY_TRG_DIV_CD.equals(that.ALTN_PY_TRG_DIV_CD));
    equal = equal && (this.PSTP_REVV_PSB_YN == null ? that.PSTP_REVV_PSB_YN == null : this.PSTP_REVV_PSB_YN.equals(that.PSTP_REVV_PSB_YN));
    equal = equal && (this.AYTM_PY_PSB_YN == null ? that.AYTM_PY_PSB_YN == null : this.AYTM_PY_PSB_YN.equals(that.AYTM_PY_PSB_YN));
    equal = equal && (this.FSS_DAT_OTPT_SEQ == null ? that.FSS_DAT_OTPT_SEQ == null : this.FSS_DAT_OTPT_SEQ.equals(that.FSS_DAT_OTPT_SEQ));
    equal = equal && (this.SAL_PLAN_INCL_YN == null ? that.SAL_PLAN_INCL_YN == null : this.SAL_PLAN_INCL_YN.equals(that.SAL_PLAN_INCL_YN));
    equal = equal && (this.PPBZ_FND_CTRB_INST_CD == null ? that.PPBZ_FND_CTRB_INST_CD == null : this.PPBZ_FND_CTRB_INST_CD.equals(that.PPBZ_FND_CTRB_INST_CD));
    equal = equal && (this.PBPF_BZ_FND_CTRB_RT == null ? that.PBPF_BZ_FND_CTRB_RT == null : this.PBPF_BZ_FND_CTRB_RT.equals(that.PBPF_BZ_FND_CTRB_RT));
    equal = equal && (this.APL_PREM_RDDW_UNT_CD == null ? that.APL_PREM_RDDW_UNT_CD == null : this.APL_PREM_RDDW_UNT_CD.equals(that.APL_PREM_RDDW_UNT_CD));
    equal = equal && (this.PD_MNDC_ISS_YN == null ? that.PD_MNDC_ISS_YN == null : this.PD_MNDC_ISS_YN.equals(that.PD_MNDC_ISS_YN));
    equal = equal && (this.ADJT_PSB_YN == null ? that.ADJT_PSB_YN == null : this.ADJT_PSB_YN.equals(that.ADJT_PSB_YN));
    equal = equal && (this.INDV_CRP_DIV_CD == null ? that.INDV_CRP_DIV_CD == null : this.INDV_CRP_DIV_CD.equals(that.INDV_CRP_DIV_CD));
    equal = equal && (this.GRUP_TRT_YN == null ? that.GRUP_TRT_YN == null : this.GRUP_TRT_YN.equals(that.GRUP_TRT_YN));
    equal = equal && (this.SMNS_POL_PSB_YN == null ? that.SMNS_POL_PSB_YN == null : this.SMNS_POL_PSB_YN.equals(that.SMNS_POL_PSB_YN));
    equal = equal && (this.GIRO_ISS_PSB_YN == null ? that.GIRO_ISS_PSB_YN == null : this.GIRO_ISS_PSB_YN.equals(that.GIRO_ISS_PSB_YN));
    equal = equal && (this.PLR_STUP_PSB_YN == null ? that.PLR_STUP_PSB_YN == null : this.PLR_STUP_PSB_YN.equals(that.PLR_STUP_PSB_YN));
    equal = equal && (this.HNDY_DSG_PSB_YN == null ? that.HNDY_DSG_PSB_YN == null : this.HNDY_DSG_PSB_YN.equals(that.HNDY_DSG_PSB_YN));
    equal = equal && (this.CLOG_DPC_INP_YN == null ? that.CLOG_DPC_INP_YN == null : this.CLOG_DPC_INP_YN.equals(that.CLOG_DPC_INP_YN));
    equal = equal && (this.KORE_PD_CD == null ? that.KORE_PD_CD == null : this.KORE_PD_CD.equals(that.KORE_PD_CD));
    equal = equal && (this.CLUS_DIV_CD == null ? that.CLUS_DIV_CD == null : this.CLUS_DIV_CD.equals(that.CLUS_DIV_CD));
    equal = equal && (this.LGTM_CTR_CR_XTR_MD_CD == null ? that.LGTM_CTR_CR_XTR_MD_CD == null : this.LGTM_CTR_CR_XTR_MD_CD.equals(that.LGTM_CTR_CR_XTR_MD_CD));
    equal = equal && (this.IPY_PSB_YN == null ? that.IPY_PSB_YN == null : this.IPY_PSB_YN.equals(that.IPY_PSB_YN));
    equal = equal && (this.SRP_APL_TRG_YN == null ? that.SRP_APL_TRG_YN == null : this.SRP_APL_TRG_YN.equals(that.SRP_APL_TRG_YN));
    equal = equal && (this.INCM_DDC_TRG_YN == null ? that.INCM_DDC_TRG_YN == null : this.INCM_DDC_TRG_YN.equals(that.INCM_DDC_TRG_YN));
    equal = equal && (this.HSEC_DIV_CD == null ? that.HSEC_DIV_CD == null : this.HSEC_DIV_CD.equals(that.HSEC_DIV_CD));
    equal = equal && (this.SECT_INS_DIV_CD == null ? that.SECT_INS_DIV_CD == null : this.SECT_INS_DIV_CD.equals(that.SECT_INS_DIV_CD));
    equal = equal && (this.PVCTR_ALLW_YN == null ? that.PVCTR_ALLW_YN == null : this.PVCTR_ALLW_YN.equals(that.PVCTR_ALLW_YN));
    equal = equal && (this.IPY_LPS_PRD_DIV_CD == null ? that.IPY_LPS_PRD_DIV_CD == null : this.IPY_LPS_PRD_DIV_CD.equals(that.IPY_LPS_PRD_DIV_CD));
    equal = equal && (this.IPY_PPN_PRD_DIV_CD == null ? that.IPY_PPN_PRD_DIV_CD == null : this.IPY_PPN_PRD_DIV_CD.equals(that.IPY_PPN_PRD_DIV_CD));
    equal = equal && (this.NCLAM_BNS_EN == null ? that.NCLAM_BNS_EN == null : this.NCLAM_BNS_EN.equals(that.NCLAM_BNS_EN));
    equal = equal && (this.RVW_ITMS_CRSS_PD_YN == null ? that.RVW_ITMS_CRSS_PD_YN == null : this.RVW_ITMS_CRSS_PD_YN.equals(that.RVW_ITMS_CRSS_PD_YN));
    equal = equal && (this.PRPY_PSB_TP_CD == null ? that.PRPY_PSB_TP_CD == null : this.PRPY_PSB_TP_CD.equals(that.PRPY_PSB_TP_CD));
    equal = equal && (this.LANN_DIV_CD == null ? that.LANN_DIV_CD == null : this.LANN_DIV_CD.equals(that.LANN_DIV_CD));
    equal = equal && (this.PD_GRP_CD == null ? that.PD_GRP_CD == null : this.PD_GRP_CD.equals(that.PD_GRP_CD));
    equal = equal && (this.CNCLL_DDC_AMT_SBTR_YN == null ? that.CNCLL_DDC_AMT_SBTR_YN == null : this.CNCLL_DDC_AMT_SBTR_YN.equals(that.CNCLL_DDC_AMT_SBTR_YN));
    equal = equal && (this.CNCLL_DDC_YR_NUM == null ? that.CNCLL_DDC_YR_NUM == null : this.CNCLL_DDC_YR_NUM.equals(that.CNCLL_DDC_YR_NUM));
    equal = equal && (this.XPT_INTR == null ? that.XPT_INTR == null : this.XPT_INTR.equals(that.XPT_INTR));
    equal = equal && (this.BNCA_YN == null ? that.BNCA_YN == null : this.BNCA_YN.equals(that.BNCA_YN));
    equal = equal && (this.MID_AMT_PAY_YN == null ? that.MID_AMT_PAY_YN == null : this.MID_AMT_PAY_YN.equals(that.MID_AMT_PAY_YN));
    equal = equal && (this.HFWY_WDR_YN == null ? that.HFWY_WDR_YN == null : this.HFWY_WDR_YN.equals(that.HFWY_WDR_YN));
    equal = equal && (this.LNK_PD_CD == null ? that.LNK_PD_CD == null : this.LNK_PD_CD.equals(that.LNK_PD_CD));
    equal = equal && (this.APL_PD_CD == null ? that.APL_PD_CD == null : this.APL_PD_CD.equals(that.APL_PD_CD));
    equal = equal && (this.RPT_PD_CD == null ? that.RPT_PD_CD == null : this.RPT_PD_CD.equals(that.RPT_PD_CD));
    equal = equal && (this.RPT_PD_NM == null ? that.RPT_PD_NM == null : this.RPT_PD_NM.equals(that.RPT_PD_NM));
    equal = equal && (this.RMK_CON == null ? that.RMK_CON == null : this.RMK_CON.equals(that.RMK_CON));
    equal = equal && (this.BZPLN_PD_CTG_CD == null ? that.BZPLN_PD_CTG_CD == null : this.BZPLN_PD_CTG_CD.equals(that.BZPLN_PD_CTG_CD));
    equal = equal && (this.ITGR_PD_YN == null ? that.ITGR_PD_YN == null : this.ITGR_PD_YN.equals(that.ITGR_PD_YN));
    equal = equal && (this.EXPR_RFD_APL_DIV_CD == null ? that.EXPR_RFD_APL_DIV_CD == null : this.EXPR_RFD_APL_DIV_CD.equals(that.EXPR_RFD_APL_DIV_CD));
    equal = equal && (this.SLZ_PD_DIV_CD == null ? that.SLZ_PD_DIV_CD == null : this.SLZ_PD_DIV_CD.equals(that.SLZ_PD_DIV_CD));
    equal = equal && (this.ANN_DIV_CD == null ? that.ANN_DIV_CD == null : this.ANN_DIV_CD.equals(that.ANN_DIV_CD));
    equal = equal && (this.ANN_CAL_TP_CD == null ? that.ANN_CAL_TP_CD == null : this.ANN_CAL_TP_CD.equals(that.ANN_CAL_TP_CD));
    equal = equal && (this.PRPY_DC_APL_PREM_CD == null ? that.PRPY_DC_APL_PREM_CD == null : this.PRPY_DC_APL_PREM_CD.equals(that.PRPY_DC_APL_PREM_CD));
    equal = equal && (this.HFWY_WDR_RFD_STD_CON == null ? that.HFWY_WDR_RFD_STD_CON == null : this.HFWY_WDR_RFD_STD_CON.equals(that.HFWY_WDR_RFD_STD_CON));
    equal = equal && (this.CI_PD_YN == null ? that.CI_PD_YN == null : this.CI_PD_YN.equals(that.CI_PD_YN));
    equal = equal && (this.REGPE_NM == null ? that.REGPE_NM == null : this.REGPE_NM.equals(that.REGPE_NM));
    equal = equal && (this.REG_DT == null ? that.REG_DT == null : this.REG_DT.equals(that.REG_DT));
    equal = equal && (this.MME_RPT_PD_CD == null ? that.MME_RPT_PD_CD == null : this.MME_RPT_PD_CD.equals(that.MME_RPT_PD_CD));
    equal = equal && (this.MME_RPT_PD_CD_NM == null ? that.MME_RPT_PD_CD_NM == null : this.MME_RPT_PD_CD_NM.equals(that.MME_RPT_PD_CD_NM));
    equal = equal && (this.AYTM_PY_LM_AMT_DIV_CD == null ? that.AYTM_PY_LM_AMT_DIV_CD == null : this.AYTM_PY_LM_AMT_DIV_CD.equals(that.AYTM_PY_LM_AMT_DIV_CD));
    equal = equal && (this.ICLO_PSB_YN == null ? that.ICLO_PSB_YN == null : this.ICLO_PSB_YN.equals(that.ICLO_PSB_YN));
    equal = equal && (this.UNT_PD_SAL_NM == null ? that.UNT_PD_SAL_NM == null : this.UNT_PD_SAL_NM.equals(that.UNT_PD_SAL_NM));
    equal = equal && (this.ISP_PD_CTG_CD == null ? that.ISP_PD_CTG_CD == null : this.ISP_PD_CTG_CD.equals(that.ISP_PD_CTG_CD));
    equal = equal && (this.LGTM_INDV_GRUP_DIV_CD == null ? that.LGTM_INDV_GRUP_DIV_CD == null : this.LGTM_INDV_GRUP_DIV_CD.equals(that.LGTM_INDV_GRUP_DIV_CD));
    equal = equal && (this.KIDI_PD_CD == null ? that.KIDI_PD_CD == null : this.KIDI_PD_CD.equals(that.KIDI_PD_CD));
    equal = equal && (this.PRDY_AMT_PD_GRP_CD == null ? that.PRDY_AMT_PD_GRP_CD == null : this.PRDY_AMT_PD_GRP_CD.equals(that.PRDY_AMT_PD_GRP_CD));
    equal = equal && (this.STND_INTR == null ? that.STND_INTR == null : this.STND_INTR.equals(that.STND_INTR));
    equal = equal && (this.MDF_RT_APL_DIV_CD == null ? that.MDF_RT_APL_DIV_CD == null : this.MDF_RT_APL_DIV_CD.equals(that.MDF_RT_APL_DIV_CD));
    equal = equal && (this.INDP_SIC_PD_YN == null ? that.INDP_SIC_PD_YN == null : this.INDP_SIC_PD_YN.equals(that.INDP_SIC_PD_YN));
    equal = equal && (this.CKUP_TRG_PD_YN == null ? that.CKUP_TRG_PD_YN == null : this.CKUP_TRG_PD_YN.equals(that.CKUP_TRG_PD_YN));
    equal = equal && (this.POL_OTPT_WY_DIV_CD == null ? that.POL_OTPT_WY_DIV_CD == null : this.POL_OTPT_WY_DIV_CD.equals(that.POL_OTPT_WY_DIV_CD));
    equal = equal && (this.SAL_BGN_DT1 == null ? that.SAL_BGN_DT1 == null : this.SAL_BGN_DT1.equals(that.SAL_BGN_DT1));
    equal = equal && (this.NW_KIDI_PD_CD == null ? that.NW_KIDI_PD_CD == null : this.NW_KIDI_PD_CD.equals(that.NW_KIDI_PD_CD));
    equal = equal && (this.STIC_IDC_PD_CTG_CD == null ? that.STIC_IDC_PD_CTG_CD == null : this.STIC_IDC_PD_CTG_CD.equals(that.STIC_IDC_PD_CTG_CD));
    equal = equal && (this.QRCD_ADR == null ? that.QRCD_ADR == null : this.QRCD_ADR.equals(that.QRCD_ADR));
    equal = equal && (this.AVG_PBAN_INTR == null ? that.AVG_PBAN_INTR == null : this.AVG_PBAN_INTR.equals(that.AVG_PBAN_INTR));
    equal = equal && (this.EIH_LDG_DTM == null ? that.EIH_LDG_DTM == null : this.EIH_LDG_DTM.equals(that.EIH_LDG_DTM));
    equal = equal && (this.NW_FAMT_INS_PD_CTG_CD == null ? that.NW_FAMT_INS_PD_CTG_CD == null : this.NW_FAMT_INS_PD_CTG_CD.equals(that.NW_FAMT_INS_PD_CTG_CD));
    equal = equal && (this.AT_ALTN_PY_TP_CD == null ? that.AT_ALTN_PY_TP_CD == null : this.AT_ALTN_PY_TP_CD.equals(that.AT_ALTN_PY_TP_CD));
    equal = equal && (this.ICLO_STD_RT == null ? that.ICLO_STD_RT == null : this.ICLO_STD_RT.equals(that.ICLO_STD_RT));
    equal = equal && (this.MFRC_PD_YN == null ? that.MFRC_PD_YN == null : this.MFRC_PD_YN.equals(that.MFRC_PD_YN));
    equal = equal && (this.PY_EXEM_LRG_TOP_YN == null ? that.PY_EXEM_LRG_TOP_YN == null : this.PY_EXEM_LRG_TOP_YN.equals(that.PY_EXEM_LRG_TOP_YN));
    equal = equal && (this.SCRN_EXPS_SQ == null ? that.SCRN_EXPS_SQ == null : this.SCRN_EXPS_SQ.equals(that.SCRN_EXPS_SQ));
    equal = equal && (this.SAL_BGN_TM == null ? that.SAL_BGN_TM == null : this.SAL_BGN_TM.equals(that.SAL_BGN_TM));
    equal = equal && (this.ITMGP_CD == null ? that.ITMGP_CD == null : this.ITMGP_CD.equals(that.ITMGP_CD));
    equal = equal && (this.GRUP_PREM_AGE_STD_CD == null ? that.GRUP_PREM_AGE_STD_CD == null : this.GRUP_PREM_AGE_STD_CD.equals(that.GRUP_PREM_AGE_STD_CD));
    equal = equal && (this.PDGP_CD == null ? that.PDGP_CD == null : this.PDGP_CD.equals(that.PDGP_CD));
    equal = equal && (this.INS_ITMS_CD == null ? that.INS_ITMS_CD == null : this.INS_ITMS_CD.equals(that.INS_ITMS_CD));
    equal = equal && (this.LNK_INDP_PD_CD == null ? that.LNK_INDP_PD_CD == null : this.LNK_INDP_PD_CD.equals(that.LNK_INDP_PD_CD));
    equal = equal && (this.MBL_CLUS_ADR == null ? that.MBL_CLUS_ADR == null : this.MBL_CLUS_ADR.equals(that.MBL_CLUS_ADR));
    equal = equal && (this.MLTD_OBJ_YN == null ? that.MLTD_OBJ_YN == null : this.MLTD_OBJ_YN.equals(that.MLTD_OBJ_YN));
    equal = equal && (this.UNT_PD_SCRN_EXPS_NM == null ? that.UNT_PD_SCRN_EXPS_NM == null : this.UNT_PD_SCRN_EXPS_NM.equals(that.UNT_PD_SCRN_EXPS_NM));
    equal = equal && (this.PY_EXEM_KND_TYP_DIV_CD == null ? that.PY_EXEM_KND_TYP_DIV_CD == null : this.PY_EXEM_KND_TYP_DIV_CD.equals(that.PY_EXEM_KND_TYP_DIV_CD));
    equal = equal && (this.PY_EXEM_DIV_VAL == null ? that.PY_EXEM_DIV_VAL == null : this.PY_EXEM_DIV_VAL.equals(that.PY_EXEM_DIV_VAL));
    equal = equal && (this.FETS_PRD_CAL_DIV_CD == null ? that.FETS_PRD_CAL_DIV_CD == null : this.FETS_PRD_CAL_DIV_CD.equals(that.FETS_PRD_CAL_DIV_CD));
    equal = equal && (this.UNT_PD_TP_CD == null ? that.UNT_PD_TP_CD == null : this.UNT_PD_TP_CD.equals(that.UNT_PD_TP_CD));
    equal = equal && (this.BZ_IDC_PD_LCTG_NM == null ? that.BZ_IDC_PD_LCTG_NM == null : this.BZ_IDC_PD_LCTG_NM.equals(that.BZ_IDC_PD_LCTG_NM));
    equal = equal && (this.BZ_IDC_PD_MCTG_NM == null ? that.BZ_IDC_PD_MCTG_NM == null : this.BZ_IDC_PD_MCTG_NM.equals(that.BZ_IDC_PD_MCTG_NM));
    equal = equal && (this.BZ_IDC_PD_CTG_NM == null ? that.BZ_IDC_PD_CTG_NM == null : this.BZ_IDC_PD_CTG_NM.equals(that.BZ_IDC_PD_CTG_NM));
    return equal;
  }
  public void readFields(ResultSet __dbResults) throws SQLException {
    this.__cur_result_set = __dbResults;
    this.UNT_PD_CD = JdbcWritableBridge.readString(1, __dbResults);
    this.VF_DT = JdbcWritableBridge.readTimestamp(2, __dbResults);
    this.VT_DT = JdbcWritableBridge.readTimestamp(3, __dbResults);
    this.UNT_PD_NM = JdbcWritableBridge.readString(4, __dbResults);
    this.UNT_PD_ABR_NM = JdbcWritableBridge.readString(5, __dbResults);
    this.UNT_PD_ENG_NM = JdbcWritableBridge.readString(6, __dbResults);
    this.UNT_PD_ENG_ABR_NM = JdbcWritableBridge.readString(7, __dbResults);
    this.PD_AUTH_DT = JdbcWritableBridge.readTimestamp(8, __dbResults);
    this.PD_SAL_TMRR_SUSP_DT = JdbcWritableBridge.readTimestamp(9, __dbResults);
    this.SAL_BGN_DT = JdbcWritableBridge.readTimestamp(10, __dbResults);
    this.SAL_ED_DT = JdbcWritableBridge.readTimestamp(11, __dbResults);
    this.INS_BGN_TM = JdbcWritableBridge.readString(12, __dbResults);
    this.INS_ED_TM = JdbcWritableBridge.readString(13, __dbResults);
    this.RPS_PD_CD = JdbcWritableBridge.readString(14, __dbResults);
    this.OD_PD_CD = JdbcWritableBridge.readString(15, __dbResults);
    this.INS_ITMS_DIV_CD = JdbcWritableBridge.readString(16, __dbResults);
    this.OD_STIC_PD_CTG_CD = JdbcWritableBridge.readString(17, __dbResults);
    this.NW_STIC_PD_CTG_CD = JdbcWritableBridge.readString(18, __dbResults);
    this.FAMT_INS_PD_CTG_CD = JdbcWritableBridge.readString(19, __dbResults);
    this.PD_AUTH_TP_CD = JdbcWritableBridge.readString(20, __dbResults);
    this.ISP_STD_SCR = JdbcWritableBridge.readBigDecimal(21, __dbResults);
    this.GURT_SAV_DIV_CD = JdbcWritableBridge.readString(22, __dbResults);
    this.SPC_ACCT_DIV_CD = JdbcWritableBridge.readString(23, __dbResults);
    this.DVND_PAY_YN = JdbcWritableBridge.readString(24, __dbResults);
    this.BZCC_JNT_PD_YN = JdbcWritableBridge.readString(25, __dbResults);
    this.FETS_SBC_PSB_YN = JdbcWritableBridge.readString(26, __dbResults);
    this.ACU_GURT_SPR_YN = JdbcWritableBridge.readString(27, __dbResults);
    this.RNWL_COV_BEIN_YN = JdbcWritableBridge.readString(28, __dbResults);
    this.PREM_CMPT_AGE_STD_CD = JdbcWritableBridge.readString(29, __dbResults);
    this.HDTL_YN = JdbcWritableBridge.readString(30, __dbResults);
    this.ALTN_PY_TRG_DIV_CD = JdbcWritableBridge.readString(31, __dbResults);
    this.PSTP_REVV_PSB_YN = JdbcWritableBridge.readString(32, __dbResults);
    this.AYTM_PY_PSB_YN = JdbcWritableBridge.readString(33, __dbResults);
    this.FSS_DAT_OTPT_SEQ = JdbcWritableBridge.readBigDecimal(34, __dbResults);
    this.SAL_PLAN_INCL_YN = JdbcWritableBridge.readString(35, __dbResults);
    this.PPBZ_FND_CTRB_INST_CD = JdbcWritableBridge.readString(36, __dbResults);
    this.PBPF_BZ_FND_CTRB_RT = JdbcWritableBridge.readBigDecimal(37, __dbResults);
    this.APL_PREM_RDDW_UNT_CD = JdbcWritableBridge.readString(38, __dbResults);
    this.PD_MNDC_ISS_YN = JdbcWritableBridge.readString(39, __dbResults);
    this.ADJT_PSB_YN = JdbcWritableBridge.readString(40, __dbResults);
    this.INDV_CRP_DIV_CD = JdbcWritableBridge.readString(41, __dbResults);
    this.GRUP_TRT_YN = JdbcWritableBridge.readString(42, __dbResults);
    this.SMNS_POL_PSB_YN = JdbcWritableBridge.readString(43, __dbResults);
    this.GIRO_ISS_PSB_YN = JdbcWritableBridge.readString(44, __dbResults);
    this.PLR_STUP_PSB_YN = JdbcWritableBridge.readString(45, __dbResults);
    this.HNDY_DSG_PSB_YN = JdbcWritableBridge.readString(46, __dbResults);
    this.CLOG_DPC_INP_YN = JdbcWritableBridge.readString(47, __dbResults);
    this.KORE_PD_CD = JdbcWritableBridge.readString(48, __dbResults);
    this.CLUS_DIV_CD = JdbcWritableBridge.readString(49, __dbResults);
    this.LGTM_CTR_CR_XTR_MD_CD = JdbcWritableBridge.readString(50, __dbResults);
    this.IPY_PSB_YN = JdbcWritableBridge.readString(51, __dbResults);
    this.SRP_APL_TRG_YN = JdbcWritableBridge.readString(52, __dbResults);
    this.INCM_DDC_TRG_YN = JdbcWritableBridge.readString(53, __dbResults);
    this.HSEC_DIV_CD = JdbcWritableBridge.readString(54, __dbResults);
    this.SECT_INS_DIV_CD = JdbcWritableBridge.readString(55, __dbResults);
    this.PVCTR_ALLW_YN = JdbcWritableBridge.readString(56, __dbResults);
    this.IPY_LPS_PRD_DIV_CD = JdbcWritableBridge.readString(57, __dbResults);
    this.IPY_PPN_PRD_DIV_CD = JdbcWritableBridge.readString(58, __dbResults);
    this.NCLAM_BNS_EN = JdbcWritableBridge.readString(59, __dbResults);
    this.RVW_ITMS_CRSS_PD_YN = JdbcWritableBridge.readString(60, __dbResults);
    this.PRPY_PSB_TP_CD = JdbcWritableBridge.readString(61, __dbResults);
    this.LANN_DIV_CD = JdbcWritableBridge.readString(62, __dbResults);
    this.PD_GRP_CD = JdbcWritableBridge.readString(63, __dbResults);
    this.CNCLL_DDC_AMT_SBTR_YN = JdbcWritableBridge.readString(64, __dbResults);
    this.CNCLL_DDC_YR_NUM = JdbcWritableBridge.readBigDecimal(65, __dbResults);
    this.XPT_INTR = JdbcWritableBridge.readBigDecimal(66, __dbResults);
    this.BNCA_YN = JdbcWritableBridge.readString(67, __dbResults);
    this.MID_AMT_PAY_YN = JdbcWritableBridge.readString(68, __dbResults);
    this.HFWY_WDR_YN = JdbcWritableBridge.readString(69, __dbResults);
    this.LNK_PD_CD = JdbcWritableBridge.readString(70, __dbResults);
    this.APL_PD_CD = JdbcWritableBridge.readString(71, __dbResults);
    this.RPT_PD_CD = JdbcWritableBridge.readString(72, __dbResults);
    this.RPT_PD_NM = JdbcWritableBridge.readString(73, __dbResults);
    this.RMK_CON = JdbcWritableBridge.readString(74, __dbResults);
    this.BZPLN_PD_CTG_CD = JdbcWritableBridge.readString(75, __dbResults);
    this.ITGR_PD_YN = JdbcWritableBridge.readString(76, __dbResults);
    this.EXPR_RFD_APL_DIV_CD = JdbcWritableBridge.readString(77, __dbResults);
    this.SLZ_PD_DIV_CD = JdbcWritableBridge.readString(78, __dbResults);
    this.ANN_DIV_CD = JdbcWritableBridge.readString(79, __dbResults);
    this.ANN_CAL_TP_CD = JdbcWritableBridge.readString(80, __dbResults);
    this.PRPY_DC_APL_PREM_CD = JdbcWritableBridge.readString(81, __dbResults);
    this.HFWY_WDR_RFD_STD_CON = JdbcWritableBridge.readString(82, __dbResults);
    this.CI_PD_YN = JdbcWritableBridge.readString(83, __dbResults);
    this.REGPE_NM = JdbcWritableBridge.readString(84, __dbResults);
    this.REG_DT = JdbcWritableBridge.readTimestamp(85, __dbResults);
    this.MME_RPT_PD_CD = JdbcWritableBridge.readString(86, __dbResults);
    this.MME_RPT_PD_CD_NM = JdbcWritableBridge.readString(87, __dbResults);
    this.AYTM_PY_LM_AMT_DIV_CD = JdbcWritableBridge.readString(88, __dbResults);
    this.ICLO_PSB_YN = JdbcWritableBridge.readString(89, __dbResults);
    this.UNT_PD_SAL_NM = JdbcWritableBridge.readString(90, __dbResults);
    this.ISP_PD_CTG_CD = JdbcWritableBridge.readString(91, __dbResults);
    this.LGTM_INDV_GRUP_DIV_CD = JdbcWritableBridge.readString(92, __dbResults);
    this.KIDI_PD_CD = JdbcWritableBridge.readString(93, __dbResults);
    this.PRDY_AMT_PD_GRP_CD = JdbcWritableBridge.readString(94, __dbResults);
    this.STND_INTR = JdbcWritableBridge.readBigDecimal(95, __dbResults);
    this.MDF_RT_APL_DIV_CD = JdbcWritableBridge.readString(96, __dbResults);
    this.INDP_SIC_PD_YN = JdbcWritableBridge.readString(97, __dbResults);
    this.CKUP_TRG_PD_YN = JdbcWritableBridge.readString(98, __dbResults);
    this.POL_OTPT_WY_DIV_CD = JdbcWritableBridge.readString(99, __dbResults);
    this.SAL_BGN_DT1 = JdbcWritableBridge.readTimestamp(100, __dbResults);
    this.NW_KIDI_PD_CD = JdbcWritableBridge.readString(101, __dbResults);
    this.STIC_IDC_PD_CTG_CD = JdbcWritableBridge.readString(102, __dbResults);
    this.QRCD_ADR = JdbcWritableBridge.readString(103, __dbResults);
    this.AVG_PBAN_INTR = JdbcWritableBridge.readBigDecimal(104, __dbResults);
    this.EIH_LDG_DTM = JdbcWritableBridge.readTimestamp(105, __dbResults);
    this.NW_FAMT_INS_PD_CTG_CD = JdbcWritableBridge.readString(106, __dbResults);
    this.AT_ALTN_PY_TP_CD = JdbcWritableBridge.readString(107, __dbResults);
    this.ICLO_STD_RT = JdbcWritableBridge.readBigDecimal(108, __dbResults);
    this.MFRC_PD_YN = JdbcWritableBridge.readString(109, __dbResults);
    this.PY_EXEM_LRG_TOP_YN = JdbcWritableBridge.readString(110, __dbResults);
    this.SCRN_EXPS_SQ = JdbcWritableBridge.readBigDecimal(111, __dbResults);
    this.SAL_BGN_TM = JdbcWritableBridge.readString(112, __dbResults);
    this.ITMGP_CD = JdbcWritableBridge.readString(113, __dbResults);
    this.GRUP_PREM_AGE_STD_CD = JdbcWritableBridge.readString(114, __dbResults);
    this.PDGP_CD = JdbcWritableBridge.readString(115, __dbResults);
    this.INS_ITMS_CD = JdbcWritableBridge.readString(116, __dbResults);
    this.LNK_INDP_PD_CD = JdbcWritableBridge.readString(117, __dbResults);
    this.MBL_CLUS_ADR = JdbcWritableBridge.readString(118, __dbResults);
    this.MLTD_OBJ_YN = JdbcWritableBridge.readString(119, __dbResults);
    this.UNT_PD_SCRN_EXPS_NM = JdbcWritableBridge.readString(120, __dbResults);
    this.PY_EXEM_KND_TYP_DIV_CD = JdbcWritableBridge.readString(121, __dbResults);
    this.PY_EXEM_DIV_VAL = JdbcWritableBridge.readString(122, __dbResults);
    this.FETS_PRD_CAL_DIV_CD = JdbcWritableBridge.readString(123, __dbResults);
    this.UNT_PD_TP_CD = JdbcWritableBridge.readString(124, __dbResults);
    this.BZ_IDC_PD_LCTG_NM = JdbcWritableBridge.readString(125, __dbResults);
    this.BZ_IDC_PD_MCTG_NM = JdbcWritableBridge.readString(126, __dbResults);
    this.BZ_IDC_PD_CTG_NM = JdbcWritableBridge.readString(127, __dbResults);
  }
  public void readFields0(ResultSet __dbResults) throws SQLException {
    this.UNT_PD_CD = JdbcWritableBridge.readString(1, __dbResults);
    this.VF_DT = JdbcWritableBridge.readTimestamp(2, __dbResults);
    this.VT_DT = JdbcWritableBridge.readTimestamp(3, __dbResults);
    this.UNT_PD_NM = JdbcWritableBridge.readString(4, __dbResults);
    this.UNT_PD_ABR_NM = JdbcWritableBridge.readString(5, __dbResults);
    this.UNT_PD_ENG_NM = JdbcWritableBridge.readString(6, __dbResults);
    this.UNT_PD_ENG_ABR_NM = JdbcWritableBridge.readString(7, __dbResults);
    this.PD_AUTH_DT = JdbcWritableBridge.readTimestamp(8, __dbResults);
    this.PD_SAL_TMRR_SUSP_DT = JdbcWritableBridge.readTimestamp(9, __dbResults);
    this.SAL_BGN_DT = JdbcWritableBridge.readTimestamp(10, __dbResults);
    this.SAL_ED_DT = JdbcWritableBridge.readTimestamp(11, __dbResults);
    this.INS_BGN_TM = JdbcWritableBridge.readString(12, __dbResults);
    this.INS_ED_TM = JdbcWritableBridge.readString(13, __dbResults);
    this.RPS_PD_CD = JdbcWritableBridge.readString(14, __dbResults);
    this.OD_PD_CD = JdbcWritableBridge.readString(15, __dbResults);
    this.INS_ITMS_DIV_CD = JdbcWritableBridge.readString(16, __dbResults);
    this.OD_STIC_PD_CTG_CD = JdbcWritableBridge.readString(17, __dbResults);
    this.NW_STIC_PD_CTG_CD = JdbcWritableBridge.readString(18, __dbResults);
    this.FAMT_INS_PD_CTG_CD = JdbcWritableBridge.readString(19, __dbResults);
    this.PD_AUTH_TP_CD = JdbcWritableBridge.readString(20, __dbResults);
    this.ISP_STD_SCR = JdbcWritableBridge.readBigDecimal(21, __dbResults);
    this.GURT_SAV_DIV_CD = JdbcWritableBridge.readString(22, __dbResults);
    this.SPC_ACCT_DIV_CD = JdbcWritableBridge.readString(23, __dbResults);
    this.DVND_PAY_YN = JdbcWritableBridge.readString(24, __dbResults);
    this.BZCC_JNT_PD_YN = JdbcWritableBridge.readString(25, __dbResults);
    this.FETS_SBC_PSB_YN = JdbcWritableBridge.readString(26, __dbResults);
    this.ACU_GURT_SPR_YN = JdbcWritableBridge.readString(27, __dbResults);
    this.RNWL_COV_BEIN_YN = JdbcWritableBridge.readString(28, __dbResults);
    this.PREM_CMPT_AGE_STD_CD = JdbcWritableBridge.readString(29, __dbResults);
    this.HDTL_YN = JdbcWritableBridge.readString(30, __dbResults);
    this.ALTN_PY_TRG_DIV_CD = JdbcWritableBridge.readString(31, __dbResults);
    this.PSTP_REVV_PSB_YN = JdbcWritableBridge.readString(32, __dbResults);
    this.AYTM_PY_PSB_YN = JdbcWritableBridge.readString(33, __dbResults);
    this.FSS_DAT_OTPT_SEQ = JdbcWritableBridge.readBigDecimal(34, __dbResults);
    this.SAL_PLAN_INCL_YN = JdbcWritableBridge.readString(35, __dbResults);
    this.PPBZ_FND_CTRB_INST_CD = JdbcWritableBridge.readString(36, __dbResults);
    this.PBPF_BZ_FND_CTRB_RT = JdbcWritableBridge.readBigDecimal(37, __dbResults);
    this.APL_PREM_RDDW_UNT_CD = JdbcWritableBridge.readString(38, __dbResults);
    this.PD_MNDC_ISS_YN = JdbcWritableBridge.readString(39, __dbResults);
    this.ADJT_PSB_YN = JdbcWritableBridge.readString(40, __dbResults);
    this.INDV_CRP_DIV_CD = JdbcWritableBridge.readString(41, __dbResults);
    this.GRUP_TRT_YN = JdbcWritableBridge.readString(42, __dbResults);
    this.SMNS_POL_PSB_YN = JdbcWritableBridge.readString(43, __dbResults);
    this.GIRO_ISS_PSB_YN = JdbcWritableBridge.readString(44, __dbResults);
    this.PLR_STUP_PSB_YN = JdbcWritableBridge.readString(45, __dbResults);
    this.HNDY_DSG_PSB_YN = JdbcWritableBridge.readString(46, __dbResults);
    this.CLOG_DPC_INP_YN = JdbcWritableBridge.readString(47, __dbResults);
    this.KORE_PD_CD = JdbcWritableBridge.readString(48, __dbResults);
    this.CLUS_DIV_CD = JdbcWritableBridge.readString(49, __dbResults);
    this.LGTM_CTR_CR_XTR_MD_CD = JdbcWritableBridge.readString(50, __dbResults);
    this.IPY_PSB_YN = JdbcWritableBridge.readString(51, __dbResults);
    this.SRP_APL_TRG_YN = JdbcWritableBridge.readString(52, __dbResults);
    this.INCM_DDC_TRG_YN = JdbcWritableBridge.readString(53, __dbResults);
    this.HSEC_DIV_CD = JdbcWritableBridge.readString(54, __dbResults);
    this.SECT_INS_DIV_CD = JdbcWritableBridge.readString(55, __dbResults);
    this.PVCTR_ALLW_YN = JdbcWritableBridge.readString(56, __dbResults);
    this.IPY_LPS_PRD_DIV_CD = JdbcWritableBridge.readString(57, __dbResults);
    this.IPY_PPN_PRD_DIV_CD = JdbcWritableBridge.readString(58, __dbResults);
    this.NCLAM_BNS_EN = JdbcWritableBridge.readString(59, __dbResults);
    this.RVW_ITMS_CRSS_PD_YN = JdbcWritableBridge.readString(60, __dbResults);
    this.PRPY_PSB_TP_CD = JdbcWritableBridge.readString(61, __dbResults);
    this.LANN_DIV_CD = JdbcWritableBridge.readString(62, __dbResults);
    this.PD_GRP_CD = JdbcWritableBridge.readString(63, __dbResults);
    this.CNCLL_DDC_AMT_SBTR_YN = JdbcWritableBridge.readString(64, __dbResults);
    this.CNCLL_DDC_YR_NUM = JdbcWritableBridge.readBigDecimal(65, __dbResults);
    this.XPT_INTR = JdbcWritableBridge.readBigDecimal(66, __dbResults);
    this.BNCA_YN = JdbcWritableBridge.readString(67, __dbResults);
    this.MID_AMT_PAY_YN = JdbcWritableBridge.readString(68, __dbResults);
    this.HFWY_WDR_YN = JdbcWritableBridge.readString(69, __dbResults);
    this.LNK_PD_CD = JdbcWritableBridge.readString(70, __dbResults);
    this.APL_PD_CD = JdbcWritableBridge.readString(71, __dbResults);
    this.RPT_PD_CD = JdbcWritableBridge.readString(72, __dbResults);
    this.RPT_PD_NM = JdbcWritableBridge.readString(73, __dbResults);
    this.RMK_CON = JdbcWritableBridge.readString(74, __dbResults);
    this.BZPLN_PD_CTG_CD = JdbcWritableBridge.readString(75, __dbResults);
    this.ITGR_PD_YN = JdbcWritableBridge.readString(76, __dbResults);
    this.EXPR_RFD_APL_DIV_CD = JdbcWritableBridge.readString(77, __dbResults);
    this.SLZ_PD_DIV_CD = JdbcWritableBridge.readString(78, __dbResults);
    this.ANN_DIV_CD = JdbcWritableBridge.readString(79, __dbResults);
    this.ANN_CAL_TP_CD = JdbcWritableBridge.readString(80, __dbResults);
    this.PRPY_DC_APL_PREM_CD = JdbcWritableBridge.readString(81, __dbResults);
    this.HFWY_WDR_RFD_STD_CON = JdbcWritableBridge.readString(82, __dbResults);
    this.CI_PD_YN = JdbcWritableBridge.readString(83, __dbResults);
    this.REGPE_NM = JdbcWritableBridge.readString(84, __dbResults);
    this.REG_DT = JdbcWritableBridge.readTimestamp(85, __dbResults);
    this.MME_RPT_PD_CD = JdbcWritableBridge.readString(86, __dbResults);
    this.MME_RPT_PD_CD_NM = JdbcWritableBridge.readString(87, __dbResults);
    this.AYTM_PY_LM_AMT_DIV_CD = JdbcWritableBridge.readString(88, __dbResults);
    this.ICLO_PSB_YN = JdbcWritableBridge.readString(89, __dbResults);
    this.UNT_PD_SAL_NM = JdbcWritableBridge.readString(90, __dbResults);
    this.ISP_PD_CTG_CD = JdbcWritableBridge.readString(91, __dbResults);
    this.LGTM_INDV_GRUP_DIV_CD = JdbcWritableBridge.readString(92, __dbResults);
    this.KIDI_PD_CD = JdbcWritableBridge.readString(93, __dbResults);
    this.PRDY_AMT_PD_GRP_CD = JdbcWritableBridge.readString(94, __dbResults);
    this.STND_INTR = JdbcWritableBridge.readBigDecimal(95, __dbResults);
    this.MDF_RT_APL_DIV_CD = JdbcWritableBridge.readString(96, __dbResults);
    this.INDP_SIC_PD_YN = JdbcWritableBridge.readString(97, __dbResults);
    this.CKUP_TRG_PD_YN = JdbcWritableBridge.readString(98, __dbResults);
    this.POL_OTPT_WY_DIV_CD = JdbcWritableBridge.readString(99, __dbResults);
    this.SAL_BGN_DT1 = JdbcWritableBridge.readTimestamp(100, __dbResults);
    this.NW_KIDI_PD_CD = JdbcWritableBridge.readString(101, __dbResults);
    this.STIC_IDC_PD_CTG_CD = JdbcWritableBridge.readString(102, __dbResults);
    this.QRCD_ADR = JdbcWritableBridge.readString(103, __dbResults);
    this.AVG_PBAN_INTR = JdbcWritableBridge.readBigDecimal(104, __dbResults);
    this.EIH_LDG_DTM = JdbcWritableBridge.readTimestamp(105, __dbResults);
    this.NW_FAMT_INS_PD_CTG_CD = JdbcWritableBridge.readString(106, __dbResults);
    this.AT_ALTN_PY_TP_CD = JdbcWritableBridge.readString(107, __dbResults);
    this.ICLO_STD_RT = JdbcWritableBridge.readBigDecimal(108, __dbResults);
    this.MFRC_PD_YN = JdbcWritableBridge.readString(109, __dbResults);
    this.PY_EXEM_LRG_TOP_YN = JdbcWritableBridge.readString(110, __dbResults);
    this.SCRN_EXPS_SQ = JdbcWritableBridge.readBigDecimal(111, __dbResults);
    this.SAL_BGN_TM = JdbcWritableBridge.readString(112, __dbResults);
    this.ITMGP_CD = JdbcWritableBridge.readString(113, __dbResults);
    this.GRUP_PREM_AGE_STD_CD = JdbcWritableBridge.readString(114, __dbResults);
    this.PDGP_CD = JdbcWritableBridge.readString(115, __dbResults);
    this.INS_ITMS_CD = JdbcWritableBridge.readString(116, __dbResults);
    this.LNK_INDP_PD_CD = JdbcWritableBridge.readString(117, __dbResults);
    this.MBL_CLUS_ADR = JdbcWritableBridge.readString(118, __dbResults);
    this.MLTD_OBJ_YN = JdbcWritableBridge.readString(119, __dbResults);
    this.UNT_PD_SCRN_EXPS_NM = JdbcWritableBridge.readString(120, __dbResults);
    this.PY_EXEM_KND_TYP_DIV_CD = JdbcWritableBridge.readString(121, __dbResults);
    this.PY_EXEM_DIV_VAL = JdbcWritableBridge.readString(122, __dbResults);
    this.FETS_PRD_CAL_DIV_CD = JdbcWritableBridge.readString(123, __dbResults);
    this.UNT_PD_TP_CD = JdbcWritableBridge.readString(124, __dbResults);
    this.BZ_IDC_PD_LCTG_NM = JdbcWritableBridge.readString(125, __dbResults);
    this.BZ_IDC_PD_MCTG_NM = JdbcWritableBridge.readString(126, __dbResults);
    this.BZ_IDC_PD_CTG_NM = JdbcWritableBridge.readString(127, __dbResults);
  }
  public void loadLargeObjects(LargeObjectLoader __loader)
      throws SQLException, IOException, InterruptedException {
  }
  public void loadLargeObjects0(LargeObjectLoader __loader)
      throws SQLException, IOException, InterruptedException {
  }
  public void write(PreparedStatement __dbStmt) throws SQLException {
    write(__dbStmt, 0);
  }

  public int write(PreparedStatement __dbStmt, int __off) throws SQLException {
    JdbcWritableBridge.writeString(UNT_PD_CD, 1 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeTimestamp(VF_DT, 2 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeTimestamp(VT_DT, 3 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeString(UNT_PD_NM, 4 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(UNT_PD_ABR_NM, 5 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(UNT_PD_ENG_NM, 6 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(UNT_PD_ENG_ABR_NM, 7 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeTimestamp(PD_AUTH_DT, 8 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeTimestamp(PD_SAL_TMRR_SUSP_DT, 9 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeTimestamp(SAL_BGN_DT, 10 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeTimestamp(SAL_ED_DT, 11 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeString(INS_BGN_TM, 12 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(INS_ED_TM, 13 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(RPS_PD_CD, 14 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(OD_PD_CD, 15 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(INS_ITMS_DIV_CD, 16 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(OD_STIC_PD_CTG_CD, 17 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(NW_STIC_PD_CTG_CD, 18 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(FAMT_INS_PD_CTG_CD, 19 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(PD_AUTH_TP_CD, 20 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(ISP_STD_SCR, 21 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(GURT_SAV_DIV_CD, 22 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(SPC_ACCT_DIV_CD, 23 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(DVND_PAY_YN, 24 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(BZCC_JNT_PD_YN, 25 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(FETS_SBC_PSB_YN, 26 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(ACU_GURT_SPR_YN, 27 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(RNWL_COV_BEIN_YN, 28 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(PREM_CMPT_AGE_STD_CD, 29 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(HDTL_YN, 30 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(ALTN_PY_TRG_DIV_CD, 31 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(PSTP_REVV_PSB_YN, 32 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(AYTM_PY_PSB_YN, 33 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(FSS_DAT_OTPT_SEQ, 34 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(SAL_PLAN_INCL_YN, 35 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(PPBZ_FND_CTRB_INST_CD, 36 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(PBPF_BZ_FND_CTRB_RT, 37 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(APL_PREM_RDDW_UNT_CD, 38 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(PD_MNDC_ISS_YN, 39 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(ADJT_PSB_YN, 40 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(INDV_CRP_DIV_CD, 41 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(GRUP_TRT_YN, 42 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(SMNS_POL_PSB_YN, 43 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(GIRO_ISS_PSB_YN, 44 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(PLR_STUP_PSB_YN, 45 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(HNDY_DSG_PSB_YN, 46 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(CLOG_DPC_INP_YN, 47 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(KORE_PD_CD, 48 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(CLUS_DIV_CD, 49 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(LGTM_CTR_CR_XTR_MD_CD, 50 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(IPY_PSB_YN, 51 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(SRP_APL_TRG_YN, 52 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(INCM_DDC_TRG_YN, 53 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(HSEC_DIV_CD, 54 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(SECT_INS_DIV_CD, 55 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(PVCTR_ALLW_YN, 56 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(IPY_LPS_PRD_DIV_CD, 57 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(IPY_PPN_PRD_DIV_CD, 58 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(NCLAM_BNS_EN, 59 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(RVW_ITMS_CRSS_PD_YN, 60 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(PRPY_PSB_TP_CD, 61 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(LANN_DIV_CD, 62 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(PD_GRP_CD, 63 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(CNCLL_DDC_AMT_SBTR_YN, 64 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(CNCLL_DDC_YR_NUM, 65 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(XPT_INTR, 66 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(BNCA_YN, 67 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(MID_AMT_PAY_YN, 68 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(HFWY_WDR_YN, 69 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(LNK_PD_CD, 70 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(APL_PD_CD, 71 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(RPT_PD_CD, 72 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(RPT_PD_NM, 73 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(RMK_CON, 74 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(BZPLN_PD_CTG_CD, 75 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(ITGR_PD_YN, 76 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(EXPR_RFD_APL_DIV_CD, 77 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(SLZ_PD_DIV_CD, 78 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(ANN_DIV_CD, 79 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(ANN_CAL_TP_CD, 80 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(PRPY_DC_APL_PREM_CD, 81 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(HFWY_WDR_RFD_STD_CON, 82 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(CI_PD_YN, 83 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(REGPE_NM, 84 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeTimestamp(REG_DT, 85 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeString(MME_RPT_PD_CD, 86 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(MME_RPT_PD_CD_NM, 87 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(AYTM_PY_LM_AMT_DIV_CD, 88 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(ICLO_PSB_YN, 89 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(UNT_PD_SAL_NM, 90 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(ISP_PD_CTG_CD, 91 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(LGTM_INDV_GRUP_DIV_CD, 92 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(KIDI_PD_CD, 93 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(PRDY_AMT_PD_GRP_CD, 94 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(STND_INTR, 95 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(MDF_RT_APL_DIV_CD, 96 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(INDP_SIC_PD_YN, 97 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(CKUP_TRG_PD_YN, 98 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(POL_OTPT_WY_DIV_CD, 99 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeTimestamp(SAL_BGN_DT1, 100 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeString(NW_KIDI_PD_CD, 101 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(STIC_IDC_PD_CTG_CD, 102 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(QRCD_ADR, 103 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(AVG_PBAN_INTR, 104 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeTimestamp(EIH_LDG_DTM, 105 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeString(NW_FAMT_INS_PD_CTG_CD, 106 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(AT_ALTN_PY_TP_CD, 107 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(ICLO_STD_RT, 108 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(MFRC_PD_YN, 109 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(PY_EXEM_LRG_TOP_YN, 110 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(SCRN_EXPS_SQ, 111 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(SAL_BGN_TM, 112 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(ITMGP_CD, 113 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(GRUP_PREM_AGE_STD_CD, 114 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(PDGP_CD, 115 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(INS_ITMS_CD, 116 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(LNK_INDP_PD_CD, 117 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(MBL_CLUS_ADR, 118 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(MLTD_OBJ_YN, 119 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(UNT_PD_SCRN_EXPS_NM, 120 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(PY_EXEM_KND_TYP_DIV_CD, 121 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(PY_EXEM_DIV_VAL, 122 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(FETS_PRD_CAL_DIV_CD, 123 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(UNT_PD_TP_CD, 124 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(BZ_IDC_PD_LCTG_NM, 125 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(BZ_IDC_PD_MCTG_NM, 126 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(BZ_IDC_PD_CTG_NM, 127 + __off, 12, __dbStmt);
    return 127;
  }
  public void write0(PreparedStatement __dbStmt, int __off) throws SQLException {
    JdbcWritableBridge.writeString(UNT_PD_CD, 1 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeTimestamp(VF_DT, 2 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeTimestamp(VT_DT, 3 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeString(UNT_PD_NM, 4 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(UNT_PD_ABR_NM, 5 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(UNT_PD_ENG_NM, 6 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(UNT_PD_ENG_ABR_NM, 7 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeTimestamp(PD_AUTH_DT, 8 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeTimestamp(PD_SAL_TMRR_SUSP_DT, 9 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeTimestamp(SAL_BGN_DT, 10 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeTimestamp(SAL_ED_DT, 11 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeString(INS_BGN_TM, 12 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(INS_ED_TM, 13 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(RPS_PD_CD, 14 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(OD_PD_CD, 15 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(INS_ITMS_DIV_CD, 16 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(OD_STIC_PD_CTG_CD, 17 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(NW_STIC_PD_CTG_CD, 18 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(FAMT_INS_PD_CTG_CD, 19 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(PD_AUTH_TP_CD, 20 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(ISP_STD_SCR, 21 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(GURT_SAV_DIV_CD, 22 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(SPC_ACCT_DIV_CD, 23 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(DVND_PAY_YN, 24 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(BZCC_JNT_PD_YN, 25 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(FETS_SBC_PSB_YN, 26 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(ACU_GURT_SPR_YN, 27 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(RNWL_COV_BEIN_YN, 28 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(PREM_CMPT_AGE_STD_CD, 29 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(HDTL_YN, 30 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(ALTN_PY_TRG_DIV_CD, 31 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(PSTP_REVV_PSB_YN, 32 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(AYTM_PY_PSB_YN, 33 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(FSS_DAT_OTPT_SEQ, 34 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(SAL_PLAN_INCL_YN, 35 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(PPBZ_FND_CTRB_INST_CD, 36 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(PBPF_BZ_FND_CTRB_RT, 37 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(APL_PREM_RDDW_UNT_CD, 38 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(PD_MNDC_ISS_YN, 39 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(ADJT_PSB_YN, 40 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(INDV_CRP_DIV_CD, 41 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(GRUP_TRT_YN, 42 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(SMNS_POL_PSB_YN, 43 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(GIRO_ISS_PSB_YN, 44 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(PLR_STUP_PSB_YN, 45 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(HNDY_DSG_PSB_YN, 46 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(CLOG_DPC_INP_YN, 47 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(KORE_PD_CD, 48 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(CLUS_DIV_CD, 49 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(LGTM_CTR_CR_XTR_MD_CD, 50 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(IPY_PSB_YN, 51 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(SRP_APL_TRG_YN, 52 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(INCM_DDC_TRG_YN, 53 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(HSEC_DIV_CD, 54 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(SECT_INS_DIV_CD, 55 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(PVCTR_ALLW_YN, 56 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(IPY_LPS_PRD_DIV_CD, 57 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(IPY_PPN_PRD_DIV_CD, 58 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(NCLAM_BNS_EN, 59 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(RVW_ITMS_CRSS_PD_YN, 60 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(PRPY_PSB_TP_CD, 61 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(LANN_DIV_CD, 62 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(PD_GRP_CD, 63 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(CNCLL_DDC_AMT_SBTR_YN, 64 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(CNCLL_DDC_YR_NUM, 65 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(XPT_INTR, 66 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(BNCA_YN, 67 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(MID_AMT_PAY_YN, 68 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(HFWY_WDR_YN, 69 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(LNK_PD_CD, 70 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(APL_PD_CD, 71 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(RPT_PD_CD, 72 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(RPT_PD_NM, 73 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(RMK_CON, 74 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(BZPLN_PD_CTG_CD, 75 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(ITGR_PD_YN, 76 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(EXPR_RFD_APL_DIV_CD, 77 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(SLZ_PD_DIV_CD, 78 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(ANN_DIV_CD, 79 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(ANN_CAL_TP_CD, 80 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(PRPY_DC_APL_PREM_CD, 81 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(HFWY_WDR_RFD_STD_CON, 82 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(CI_PD_YN, 83 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(REGPE_NM, 84 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeTimestamp(REG_DT, 85 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeString(MME_RPT_PD_CD, 86 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(MME_RPT_PD_CD_NM, 87 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(AYTM_PY_LM_AMT_DIV_CD, 88 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(ICLO_PSB_YN, 89 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(UNT_PD_SAL_NM, 90 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(ISP_PD_CTG_CD, 91 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(LGTM_INDV_GRUP_DIV_CD, 92 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(KIDI_PD_CD, 93 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(PRDY_AMT_PD_GRP_CD, 94 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(STND_INTR, 95 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(MDF_RT_APL_DIV_CD, 96 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(INDP_SIC_PD_YN, 97 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(CKUP_TRG_PD_YN, 98 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(POL_OTPT_WY_DIV_CD, 99 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeTimestamp(SAL_BGN_DT1, 100 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeString(NW_KIDI_PD_CD, 101 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(STIC_IDC_PD_CTG_CD, 102 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(QRCD_ADR, 103 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(AVG_PBAN_INTR, 104 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeTimestamp(EIH_LDG_DTM, 105 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeString(NW_FAMT_INS_PD_CTG_CD, 106 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(AT_ALTN_PY_TP_CD, 107 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(ICLO_STD_RT, 108 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(MFRC_PD_YN, 109 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(PY_EXEM_LRG_TOP_YN, 110 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(SCRN_EXPS_SQ, 111 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(SAL_BGN_TM, 112 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(ITMGP_CD, 113 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(GRUP_PREM_AGE_STD_CD, 114 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(PDGP_CD, 115 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(INS_ITMS_CD, 116 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(LNK_INDP_PD_CD, 117 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(MBL_CLUS_ADR, 118 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(MLTD_OBJ_YN, 119 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(UNT_PD_SCRN_EXPS_NM, 120 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(PY_EXEM_KND_TYP_DIV_CD, 121 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(PY_EXEM_DIV_VAL, 122 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(FETS_PRD_CAL_DIV_CD, 123 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(UNT_PD_TP_CD, 124 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(BZ_IDC_PD_LCTG_NM, 125 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(BZ_IDC_PD_MCTG_NM, 126 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(BZ_IDC_PD_CTG_NM, 127 + __off, 12, __dbStmt);
  }
  public void readFields(DataInput __dataIn) throws IOException {
this.readFields0(__dataIn);  }
  public void readFields0(DataInput __dataIn) throws IOException {
    if (__dataIn.readBoolean()) { 
        this.UNT_PD_CD = null;
    } else {
    this.UNT_PD_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.VF_DT = null;
    } else {
    this.VF_DT = new Timestamp(__dataIn.readLong());
    this.VF_DT.setNanos(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.VT_DT = null;
    } else {
    this.VT_DT = new Timestamp(__dataIn.readLong());
    this.VT_DT.setNanos(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.UNT_PD_NM = null;
    } else {
    this.UNT_PD_NM = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.UNT_PD_ABR_NM = null;
    } else {
    this.UNT_PD_ABR_NM = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.UNT_PD_ENG_NM = null;
    } else {
    this.UNT_PD_ENG_NM = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.UNT_PD_ENG_ABR_NM = null;
    } else {
    this.UNT_PD_ENG_ABR_NM = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.PD_AUTH_DT = null;
    } else {
    this.PD_AUTH_DT = new Timestamp(__dataIn.readLong());
    this.PD_AUTH_DT.setNanos(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.PD_SAL_TMRR_SUSP_DT = null;
    } else {
    this.PD_SAL_TMRR_SUSP_DT = new Timestamp(__dataIn.readLong());
    this.PD_SAL_TMRR_SUSP_DT.setNanos(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.SAL_BGN_DT = null;
    } else {
    this.SAL_BGN_DT = new Timestamp(__dataIn.readLong());
    this.SAL_BGN_DT.setNanos(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.SAL_ED_DT = null;
    } else {
    this.SAL_ED_DT = new Timestamp(__dataIn.readLong());
    this.SAL_ED_DT.setNanos(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.INS_BGN_TM = null;
    } else {
    this.INS_BGN_TM = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.INS_ED_TM = null;
    } else {
    this.INS_ED_TM = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RPS_PD_CD = null;
    } else {
    this.RPS_PD_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.OD_PD_CD = null;
    } else {
    this.OD_PD_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.INS_ITMS_DIV_CD = null;
    } else {
    this.INS_ITMS_DIV_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.OD_STIC_PD_CTG_CD = null;
    } else {
    this.OD_STIC_PD_CTG_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.NW_STIC_PD_CTG_CD = null;
    } else {
    this.NW_STIC_PD_CTG_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.FAMT_INS_PD_CTG_CD = null;
    } else {
    this.FAMT_INS_PD_CTG_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.PD_AUTH_TP_CD = null;
    } else {
    this.PD_AUTH_TP_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.ISP_STD_SCR = null;
    } else {
    this.ISP_STD_SCR = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.GURT_SAV_DIV_CD = null;
    } else {
    this.GURT_SAV_DIV_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.SPC_ACCT_DIV_CD = null;
    } else {
    this.SPC_ACCT_DIV_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.DVND_PAY_YN = null;
    } else {
    this.DVND_PAY_YN = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.BZCC_JNT_PD_YN = null;
    } else {
    this.BZCC_JNT_PD_YN = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.FETS_SBC_PSB_YN = null;
    } else {
    this.FETS_SBC_PSB_YN = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.ACU_GURT_SPR_YN = null;
    } else {
    this.ACU_GURT_SPR_YN = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RNWL_COV_BEIN_YN = null;
    } else {
    this.RNWL_COV_BEIN_YN = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.PREM_CMPT_AGE_STD_CD = null;
    } else {
    this.PREM_CMPT_AGE_STD_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.HDTL_YN = null;
    } else {
    this.HDTL_YN = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.ALTN_PY_TRG_DIV_CD = null;
    } else {
    this.ALTN_PY_TRG_DIV_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.PSTP_REVV_PSB_YN = null;
    } else {
    this.PSTP_REVV_PSB_YN = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.AYTM_PY_PSB_YN = null;
    } else {
    this.AYTM_PY_PSB_YN = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.FSS_DAT_OTPT_SEQ = null;
    } else {
    this.FSS_DAT_OTPT_SEQ = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.SAL_PLAN_INCL_YN = null;
    } else {
    this.SAL_PLAN_INCL_YN = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.PPBZ_FND_CTRB_INST_CD = null;
    } else {
    this.PPBZ_FND_CTRB_INST_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.PBPF_BZ_FND_CTRB_RT = null;
    } else {
    this.PBPF_BZ_FND_CTRB_RT = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.APL_PREM_RDDW_UNT_CD = null;
    } else {
    this.APL_PREM_RDDW_UNT_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.PD_MNDC_ISS_YN = null;
    } else {
    this.PD_MNDC_ISS_YN = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.ADJT_PSB_YN = null;
    } else {
    this.ADJT_PSB_YN = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.INDV_CRP_DIV_CD = null;
    } else {
    this.INDV_CRP_DIV_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.GRUP_TRT_YN = null;
    } else {
    this.GRUP_TRT_YN = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.SMNS_POL_PSB_YN = null;
    } else {
    this.SMNS_POL_PSB_YN = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.GIRO_ISS_PSB_YN = null;
    } else {
    this.GIRO_ISS_PSB_YN = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.PLR_STUP_PSB_YN = null;
    } else {
    this.PLR_STUP_PSB_YN = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.HNDY_DSG_PSB_YN = null;
    } else {
    this.HNDY_DSG_PSB_YN = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.CLOG_DPC_INP_YN = null;
    } else {
    this.CLOG_DPC_INP_YN = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.KORE_PD_CD = null;
    } else {
    this.KORE_PD_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.CLUS_DIV_CD = null;
    } else {
    this.CLUS_DIV_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.LGTM_CTR_CR_XTR_MD_CD = null;
    } else {
    this.LGTM_CTR_CR_XTR_MD_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.IPY_PSB_YN = null;
    } else {
    this.IPY_PSB_YN = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.SRP_APL_TRG_YN = null;
    } else {
    this.SRP_APL_TRG_YN = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.INCM_DDC_TRG_YN = null;
    } else {
    this.INCM_DDC_TRG_YN = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.HSEC_DIV_CD = null;
    } else {
    this.HSEC_DIV_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.SECT_INS_DIV_CD = null;
    } else {
    this.SECT_INS_DIV_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.PVCTR_ALLW_YN = null;
    } else {
    this.PVCTR_ALLW_YN = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.IPY_LPS_PRD_DIV_CD = null;
    } else {
    this.IPY_LPS_PRD_DIV_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.IPY_PPN_PRD_DIV_CD = null;
    } else {
    this.IPY_PPN_PRD_DIV_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.NCLAM_BNS_EN = null;
    } else {
    this.NCLAM_BNS_EN = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RVW_ITMS_CRSS_PD_YN = null;
    } else {
    this.RVW_ITMS_CRSS_PD_YN = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.PRPY_PSB_TP_CD = null;
    } else {
    this.PRPY_PSB_TP_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.LANN_DIV_CD = null;
    } else {
    this.LANN_DIV_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.PD_GRP_CD = null;
    } else {
    this.PD_GRP_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.CNCLL_DDC_AMT_SBTR_YN = null;
    } else {
    this.CNCLL_DDC_AMT_SBTR_YN = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.CNCLL_DDC_YR_NUM = null;
    } else {
    this.CNCLL_DDC_YR_NUM = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.XPT_INTR = null;
    } else {
    this.XPT_INTR = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.BNCA_YN = null;
    } else {
    this.BNCA_YN = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.MID_AMT_PAY_YN = null;
    } else {
    this.MID_AMT_PAY_YN = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.HFWY_WDR_YN = null;
    } else {
    this.HFWY_WDR_YN = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.LNK_PD_CD = null;
    } else {
    this.LNK_PD_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.APL_PD_CD = null;
    } else {
    this.APL_PD_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RPT_PD_CD = null;
    } else {
    this.RPT_PD_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RPT_PD_NM = null;
    } else {
    this.RPT_PD_NM = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RMK_CON = null;
    } else {
    this.RMK_CON = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.BZPLN_PD_CTG_CD = null;
    } else {
    this.BZPLN_PD_CTG_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.ITGR_PD_YN = null;
    } else {
    this.ITGR_PD_YN = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.EXPR_RFD_APL_DIV_CD = null;
    } else {
    this.EXPR_RFD_APL_DIV_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.SLZ_PD_DIV_CD = null;
    } else {
    this.SLZ_PD_DIV_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.ANN_DIV_CD = null;
    } else {
    this.ANN_DIV_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.ANN_CAL_TP_CD = null;
    } else {
    this.ANN_CAL_TP_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.PRPY_DC_APL_PREM_CD = null;
    } else {
    this.PRPY_DC_APL_PREM_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.HFWY_WDR_RFD_STD_CON = null;
    } else {
    this.HFWY_WDR_RFD_STD_CON = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.CI_PD_YN = null;
    } else {
    this.CI_PD_YN = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.REGPE_NM = null;
    } else {
    this.REGPE_NM = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.REG_DT = null;
    } else {
    this.REG_DT = new Timestamp(__dataIn.readLong());
    this.REG_DT.setNanos(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.MME_RPT_PD_CD = null;
    } else {
    this.MME_RPT_PD_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.MME_RPT_PD_CD_NM = null;
    } else {
    this.MME_RPT_PD_CD_NM = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.AYTM_PY_LM_AMT_DIV_CD = null;
    } else {
    this.AYTM_PY_LM_AMT_DIV_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.ICLO_PSB_YN = null;
    } else {
    this.ICLO_PSB_YN = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.UNT_PD_SAL_NM = null;
    } else {
    this.UNT_PD_SAL_NM = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.ISP_PD_CTG_CD = null;
    } else {
    this.ISP_PD_CTG_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.LGTM_INDV_GRUP_DIV_CD = null;
    } else {
    this.LGTM_INDV_GRUP_DIV_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.KIDI_PD_CD = null;
    } else {
    this.KIDI_PD_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.PRDY_AMT_PD_GRP_CD = null;
    } else {
    this.PRDY_AMT_PD_GRP_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.STND_INTR = null;
    } else {
    this.STND_INTR = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.MDF_RT_APL_DIV_CD = null;
    } else {
    this.MDF_RT_APL_DIV_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.INDP_SIC_PD_YN = null;
    } else {
    this.INDP_SIC_PD_YN = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.CKUP_TRG_PD_YN = null;
    } else {
    this.CKUP_TRG_PD_YN = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.POL_OTPT_WY_DIV_CD = null;
    } else {
    this.POL_OTPT_WY_DIV_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.SAL_BGN_DT1 = null;
    } else {
    this.SAL_BGN_DT1 = new Timestamp(__dataIn.readLong());
    this.SAL_BGN_DT1.setNanos(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.NW_KIDI_PD_CD = null;
    } else {
    this.NW_KIDI_PD_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.STIC_IDC_PD_CTG_CD = null;
    } else {
    this.STIC_IDC_PD_CTG_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.QRCD_ADR = null;
    } else {
    this.QRCD_ADR = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.AVG_PBAN_INTR = null;
    } else {
    this.AVG_PBAN_INTR = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.EIH_LDG_DTM = null;
    } else {
    this.EIH_LDG_DTM = new Timestamp(__dataIn.readLong());
    this.EIH_LDG_DTM.setNanos(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.NW_FAMT_INS_PD_CTG_CD = null;
    } else {
    this.NW_FAMT_INS_PD_CTG_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.AT_ALTN_PY_TP_CD = null;
    } else {
    this.AT_ALTN_PY_TP_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.ICLO_STD_RT = null;
    } else {
    this.ICLO_STD_RT = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.MFRC_PD_YN = null;
    } else {
    this.MFRC_PD_YN = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.PY_EXEM_LRG_TOP_YN = null;
    } else {
    this.PY_EXEM_LRG_TOP_YN = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.SCRN_EXPS_SQ = null;
    } else {
    this.SCRN_EXPS_SQ = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.SAL_BGN_TM = null;
    } else {
    this.SAL_BGN_TM = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.ITMGP_CD = null;
    } else {
    this.ITMGP_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.GRUP_PREM_AGE_STD_CD = null;
    } else {
    this.GRUP_PREM_AGE_STD_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.PDGP_CD = null;
    } else {
    this.PDGP_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.INS_ITMS_CD = null;
    } else {
    this.INS_ITMS_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.LNK_INDP_PD_CD = null;
    } else {
    this.LNK_INDP_PD_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.MBL_CLUS_ADR = null;
    } else {
    this.MBL_CLUS_ADR = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.MLTD_OBJ_YN = null;
    } else {
    this.MLTD_OBJ_YN = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.UNT_PD_SCRN_EXPS_NM = null;
    } else {
    this.UNT_PD_SCRN_EXPS_NM = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.PY_EXEM_KND_TYP_DIV_CD = null;
    } else {
    this.PY_EXEM_KND_TYP_DIV_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.PY_EXEM_DIV_VAL = null;
    } else {
    this.PY_EXEM_DIV_VAL = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.FETS_PRD_CAL_DIV_CD = null;
    } else {
    this.FETS_PRD_CAL_DIV_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.UNT_PD_TP_CD = null;
    } else {
    this.UNT_PD_TP_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.BZ_IDC_PD_LCTG_NM = null;
    } else {
    this.BZ_IDC_PD_LCTG_NM = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.BZ_IDC_PD_MCTG_NM = null;
    } else {
    this.BZ_IDC_PD_MCTG_NM = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.BZ_IDC_PD_CTG_NM = null;
    } else {
    this.BZ_IDC_PD_CTG_NM = Text.readString(__dataIn);
    }
  }
  public void write(DataOutput __dataOut) throws IOException {
    if (null == this.UNT_PD_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, UNT_PD_CD);
    }
    if (null == this.VF_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.VF_DT.getTime());
    __dataOut.writeInt(this.VF_DT.getNanos());
    }
    if (null == this.VT_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.VT_DT.getTime());
    __dataOut.writeInt(this.VT_DT.getNanos());
    }
    if (null == this.UNT_PD_NM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, UNT_PD_NM);
    }
    if (null == this.UNT_PD_ABR_NM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, UNT_PD_ABR_NM);
    }
    if (null == this.UNT_PD_ENG_NM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, UNT_PD_ENG_NM);
    }
    if (null == this.UNT_PD_ENG_ABR_NM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, UNT_PD_ENG_ABR_NM);
    }
    if (null == this.PD_AUTH_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.PD_AUTH_DT.getTime());
    __dataOut.writeInt(this.PD_AUTH_DT.getNanos());
    }
    if (null == this.PD_SAL_TMRR_SUSP_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.PD_SAL_TMRR_SUSP_DT.getTime());
    __dataOut.writeInt(this.PD_SAL_TMRR_SUSP_DT.getNanos());
    }
    if (null == this.SAL_BGN_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.SAL_BGN_DT.getTime());
    __dataOut.writeInt(this.SAL_BGN_DT.getNanos());
    }
    if (null == this.SAL_ED_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.SAL_ED_DT.getTime());
    __dataOut.writeInt(this.SAL_ED_DT.getNanos());
    }
    if (null == this.INS_BGN_TM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, INS_BGN_TM);
    }
    if (null == this.INS_ED_TM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, INS_ED_TM);
    }
    if (null == this.RPS_PD_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RPS_PD_CD);
    }
    if (null == this.OD_PD_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, OD_PD_CD);
    }
    if (null == this.INS_ITMS_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, INS_ITMS_DIV_CD);
    }
    if (null == this.OD_STIC_PD_CTG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, OD_STIC_PD_CTG_CD);
    }
    if (null == this.NW_STIC_PD_CTG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, NW_STIC_PD_CTG_CD);
    }
    if (null == this.FAMT_INS_PD_CTG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, FAMT_INS_PD_CTG_CD);
    }
    if (null == this.PD_AUTH_TP_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, PD_AUTH_TP_CD);
    }
    if (null == this.ISP_STD_SCR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.ISP_STD_SCR, __dataOut);
    }
    if (null == this.GURT_SAV_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, GURT_SAV_DIV_CD);
    }
    if (null == this.SPC_ACCT_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, SPC_ACCT_DIV_CD);
    }
    if (null == this.DVND_PAY_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, DVND_PAY_YN);
    }
    if (null == this.BZCC_JNT_PD_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, BZCC_JNT_PD_YN);
    }
    if (null == this.FETS_SBC_PSB_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, FETS_SBC_PSB_YN);
    }
    if (null == this.ACU_GURT_SPR_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ACU_GURT_SPR_YN);
    }
    if (null == this.RNWL_COV_BEIN_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RNWL_COV_BEIN_YN);
    }
    if (null == this.PREM_CMPT_AGE_STD_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, PREM_CMPT_AGE_STD_CD);
    }
    if (null == this.HDTL_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, HDTL_YN);
    }
    if (null == this.ALTN_PY_TRG_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ALTN_PY_TRG_DIV_CD);
    }
    if (null == this.PSTP_REVV_PSB_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, PSTP_REVV_PSB_YN);
    }
    if (null == this.AYTM_PY_PSB_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, AYTM_PY_PSB_YN);
    }
    if (null == this.FSS_DAT_OTPT_SEQ) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.FSS_DAT_OTPT_SEQ, __dataOut);
    }
    if (null == this.SAL_PLAN_INCL_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, SAL_PLAN_INCL_YN);
    }
    if (null == this.PPBZ_FND_CTRB_INST_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, PPBZ_FND_CTRB_INST_CD);
    }
    if (null == this.PBPF_BZ_FND_CTRB_RT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.PBPF_BZ_FND_CTRB_RT, __dataOut);
    }
    if (null == this.APL_PREM_RDDW_UNT_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, APL_PREM_RDDW_UNT_CD);
    }
    if (null == this.PD_MNDC_ISS_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, PD_MNDC_ISS_YN);
    }
    if (null == this.ADJT_PSB_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ADJT_PSB_YN);
    }
    if (null == this.INDV_CRP_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, INDV_CRP_DIV_CD);
    }
    if (null == this.GRUP_TRT_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, GRUP_TRT_YN);
    }
    if (null == this.SMNS_POL_PSB_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, SMNS_POL_PSB_YN);
    }
    if (null == this.GIRO_ISS_PSB_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, GIRO_ISS_PSB_YN);
    }
    if (null == this.PLR_STUP_PSB_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, PLR_STUP_PSB_YN);
    }
    if (null == this.HNDY_DSG_PSB_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, HNDY_DSG_PSB_YN);
    }
    if (null == this.CLOG_DPC_INP_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CLOG_DPC_INP_YN);
    }
    if (null == this.KORE_PD_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, KORE_PD_CD);
    }
    if (null == this.CLUS_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CLUS_DIV_CD);
    }
    if (null == this.LGTM_CTR_CR_XTR_MD_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, LGTM_CTR_CR_XTR_MD_CD);
    }
    if (null == this.IPY_PSB_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, IPY_PSB_YN);
    }
    if (null == this.SRP_APL_TRG_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, SRP_APL_TRG_YN);
    }
    if (null == this.INCM_DDC_TRG_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, INCM_DDC_TRG_YN);
    }
    if (null == this.HSEC_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, HSEC_DIV_CD);
    }
    if (null == this.SECT_INS_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, SECT_INS_DIV_CD);
    }
    if (null == this.PVCTR_ALLW_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, PVCTR_ALLW_YN);
    }
    if (null == this.IPY_LPS_PRD_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, IPY_LPS_PRD_DIV_CD);
    }
    if (null == this.IPY_PPN_PRD_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, IPY_PPN_PRD_DIV_CD);
    }
    if (null == this.NCLAM_BNS_EN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, NCLAM_BNS_EN);
    }
    if (null == this.RVW_ITMS_CRSS_PD_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RVW_ITMS_CRSS_PD_YN);
    }
    if (null == this.PRPY_PSB_TP_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, PRPY_PSB_TP_CD);
    }
    if (null == this.LANN_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, LANN_DIV_CD);
    }
    if (null == this.PD_GRP_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, PD_GRP_CD);
    }
    if (null == this.CNCLL_DDC_AMT_SBTR_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CNCLL_DDC_AMT_SBTR_YN);
    }
    if (null == this.CNCLL_DDC_YR_NUM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.CNCLL_DDC_YR_NUM, __dataOut);
    }
    if (null == this.XPT_INTR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.XPT_INTR, __dataOut);
    }
    if (null == this.BNCA_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, BNCA_YN);
    }
    if (null == this.MID_AMT_PAY_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, MID_AMT_PAY_YN);
    }
    if (null == this.HFWY_WDR_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, HFWY_WDR_YN);
    }
    if (null == this.LNK_PD_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, LNK_PD_CD);
    }
    if (null == this.APL_PD_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, APL_PD_CD);
    }
    if (null == this.RPT_PD_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RPT_PD_CD);
    }
    if (null == this.RPT_PD_NM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RPT_PD_NM);
    }
    if (null == this.RMK_CON) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RMK_CON);
    }
    if (null == this.BZPLN_PD_CTG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, BZPLN_PD_CTG_CD);
    }
    if (null == this.ITGR_PD_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ITGR_PD_YN);
    }
    if (null == this.EXPR_RFD_APL_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, EXPR_RFD_APL_DIV_CD);
    }
    if (null == this.SLZ_PD_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, SLZ_PD_DIV_CD);
    }
    if (null == this.ANN_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ANN_DIV_CD);
    }
    if (null == this.ANN_CAL_TP_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ANN_CAL_TP_CD);
    }
    if (null == this.PRPY_DC_APL_PREM_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, PRPY_DC_APL_PREM_CD);
    }
    if (null == this.HFWY_WDR_RFD_STD_CON) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, HFWY_WDR_RFD_STD_CON);
    }
    if (null == this.CI_PD_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CI_PD_YN);
    }
    if (null == this.REGPE_NM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, REGPE_NM);
    }
    if (null == this.REG_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.REG_DT.getTime());
    __dataOut.writeInt(this.REG_DT.getNanos());
    }
    if (null == this.MME_RPT_PD_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, MME_RPT_PD_CD);
    }
    if (null == this.MME_RPT_PD_CD_NM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, MME_RPT_PD_CD_NM);
    }
    if (null == this.AYTM_PY_LM_AMT_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, AYTM_PY_LM_AMT_DIV_CD);
    }
    if (null == this.ICLO_PSB_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ICLO_PSB_YN);
    }
    if (null == this.UNT_PD_SAL_NM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, UNT_PD_SAL_NM);
    }
    if (null == this.ISP_PD_CTG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ISP_PD_CTG_CD);
    }
    if (null == this.LGTM_INDV_GRUP_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, LGTM_INDV_GRUP_DIV_CD);
    }
    if (null == this.KIDI_PD_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, KIDI_PD_CD);
    }
    if (null == this.PRDY_AMT_PD_GRP_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, PRDY_AMT_PD_GRP_CD);
    }
    if (null == this.STND_INTR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.STND_INTR, __dataOut);
    }
    if (null == this.MDF_RT_APL_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, MDF_RT_APL_DIV_CD);
    }
    if (null == this.INDP_SIC_PD_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, INDP_SIC_PD_YN);
    }
    if (null == this.CKUP_TRG_PD_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CKUP_TRG_PD_YN);
    }
    if (null == this.POL_OTPT_WY_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, POL_OTPT_WY_DIV_CD);
    }
    if (null == this.SAL_BGN_DT1) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.SAL_BGN_DT1.getTime());
    __dataOut.writeInt(this.SAL_BGN_DT1.getNanos());
    }
    if (null == this.NW_KIDI_PD_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, NW_KIDI_PD_CD);
    }
    if (null == this.STIC_IDC_PD_CTG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, STIC_IDC_PD_CTG_CD);
    }
    if (null == this.QRCD_ADR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, QRCD_ADR);
    }
    if (null == this.AVG_PBAN_INTR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.AVG_PBAN_INTR, __dataOut);
    }
    if (null == this.EIH_LDG_DTM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.EIH_LDG_DTM.getTime());
    __dataOut.writeInt(this.EIH_LDG_DTM.getNanos());
    }
    if (null == this.NW_FAMT_INS_PD_CTG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, NW_FAMT_INS_PD_CTG_CD);
    }
    if (null == this.AT_ALTN_PY_TP_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, AT_ALTN_PY_TP_CD);
    }
    if (null == this.ICLO_STD_RT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.ICLO_STD_RT, __dataOut);
    }
    if (null == this.MFRC_PD_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, MFRC_PD_YN);
    }
    if (null == this.PY_EXEM_LRG_TOP_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, PY_EXEM_LRG_TOP_YN);
    }
    if (null == this.SCRN_EXPS_SQ) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.SCRN_EXPS_SQ, __dataOut);
    }
    if (null == this.SAL_BGN_TM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, SAL_BGN_TM);
    }
    if (null == this.ITMGP_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ITMGP_CD);
    }
    if (null == this.GRUP_PREM_AGE_STD_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, GRUP_PREM_AGE_STD_CD);
    }
    if (null == this.PDGP_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, PDGP_CD);
    }
    if (null == this.INS_ITMS_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, INS_ITMS_CD);
    }
    if (null == this.LNK_INDP_PD_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, LNK_INDP_PD_CD);
    }
    if (null == this.MBL_CLUS_ADR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, MBL_CLUS_ADR);
    }
    if (null == this.MLTD_OBJ_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, MLTD_OBJ_YN);
    }
    if (null == this.UNT_PD_SCRN_EXPS_NM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, UNT_PD_SCRN_EXPS_NM);
    }
    if (null == this.PY_EXEM_KND_TYP_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, PY_EXEM_KND_TYP_DIV_CD);
    }
    if (null == this.PY_EXEM_DIV_VAL) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, PY_EXEM_DIV_VAL);
    }
    if (null == this.FETS_PRD_CAL_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, FETS_PRD_CAL_DIV_CD);
    }
    if (null == this.UNT_PD_TP_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, UNT_PD_TP_CD);
    }
    if (null == this.BZ_IDC_PD_LCTG_NM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, BZ_IDC_PD_LCTG_NM);
    }
    if (null == this.BZ_IDC_PD_MCTG_NM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, BZ_IDC_PD_MCTG_NM);
    }
    if (null == this.BZ_IDC_PD_CTG_NM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, BZ_IDC_PD_CTG_NM);
    }
  }
  public void write0(DataOutput __dataOut) throws IOException {
    if (null == this.UNT_PD_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, UNT_PD_CD);
    }
    if (null == this.VF_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.VF_DT.getTime());
    __dataOut.writeInt(this.VF_DT.getNanos());
    }
    if (null == this.VT_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.VT_DT.getTime());
    __dataOut.writeInt(this.VT_DT.getNanos());
    }
    if (null == this.UNT_PD_NM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, UNT_PD_NM);
    }
    if (null == this.UNT_PD_ABR_NM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, UNT_PD_ABR_NM);
    }
    if (null == this.UNT_PD_ENG_NM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, UNT_PD_ENG_NM);
    }
    if (null == this.UNT_PD_ENG_ABR_NM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, UNT_PD_ENG_ABR_NM);
    }
    if (null == this.PD_AUTH_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.PD_AUTH_DT.getTime());
    __dataOut.writeInt(this.PD_AUTH_DT.getNanos());
    }
    if (null == this.PD_SAL_TMRR_SUSP_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.PD_SAL_TMRR_SUSP_DT.getTime());
    __dataOut.writeInt(this.PD_SAL_TMRR_SUSP_DT.getNanos());
    }
    if (null == this.SAL_BGN_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.SAL_BGN_DT.getTime());
    __dataOut.writeInt(this.SAL_BGN_DT.getNanos());
    }
    if (null == this.SAL_ED_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.SAL_ED_DT.getTime());
    __dataOut.writeInt(this.SAL_ED_DT.getNanos());
    }
    if (null == this.INS_BGN_TM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, INS_BGN_TM);
    }
    if (null == this.INS_ED_TM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, INS_ED_TM);
    }
    if (null == this.RPS_PD_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RPS_PD_CD);
    }
    if (null == this.OD_PD_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, OD_PD_CD);
    }
    if (null == this.INS_ITMS_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, INS_ITMS_DIV_CD);
    }
    if (null == this.OD_STIC_PD_CTG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, OD_STIC_PD_CTG_CD);
    }
    if (null == this.NW_STIC_PD_CTG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, NW_STIC_PD_CTG_CD);
    }
    if (null == this.FAMT_INS_PD_CTG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, FAMT_INS_PD_CTG_CD);
    }
    if (null == this.PD_AUTH_TP_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, PD_AUTH_TP_CD);
    }
    if (null == this.ISP_STD_SCR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.ISP_STD_SCR, __dataOut);
    }
    if (null == this.GURT_SAV_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, GURT_SAV_DIV_CD);
    }
    if (null == this.SPC_ACCT_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, SPC_ACCT_DIV_CD);
    }
    if (null == this.DVND_PAY_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, DVND_PAY_YN);
    }
    if (null == this.BZCC_JNT_PD_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, BZCC_JNT_PD_YN);
    }
    if (null == this.FETS_SBC_PSB_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, FETS_SBC_PSB_YN);
    }
    if (null == this.ACU_GURT_SPR_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ACU_GURT_SPR_YN);
    }
    if (null == this.RNWL_COV_BEIN_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RNWL_COV_BEIN_YN);
    }
    if (null == this.PREM_CMPT_AGE_STD_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, PREM_CMPT_AGE_STD_CD);
    }
    if (null == this.HDTL_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, HDTL_YN);
    }
    if (null == this.ALTN_PY_TRG_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ALTN_PY_TRG_DIV_CD);
    }
    if (null == this.PSTP_REVV_PSB_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, PSTP_REVV_PSB_YN);
    }
    if (null == this.AYTM_PY_PSB_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, AYTM_PY_PSB_YN);
    }
    if (null == this.FSS_DAT_OTPT_SEQ) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.FSS_DAT_OTPT_SEQ, __dataOut);
    }
    if (null == this.SAL_PLAN_INCL_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, SAL_PLAN_INCL_YN);
    }
    if (null == this.PPBZ_FND_CTRB_INST_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, PPBZ_FND_CTRB_INST_CD);
    }
    if (null == this.PBPF_BZ_FND_CTRB_RT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.PBPF_BZ_FND_CTRB_RT, __dataOut);
    }
    if (null == this.APL_PREM_RDDW_UNT_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, APL_PREM_RDDW_UNT_CD);
    }
    if (null == this.PD_MNDC_ISS_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, PD_MNDC_ISS_YN);
    }
    if (null == this.ADJT_PSB_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ADJT_PSB_YN);
    }
    if (null == this.INDV_CRP_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, INDV_CRP_DIV_CD);
    }
    if (null == this.GRUP_TRT_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, GRUP_TRT_YN);
    }
    if (null == this.SMNS_POL_PSB_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, SMNS_POL_PSB_YN);
    }
    if (null == this.GIRO_ISS_PSB_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, GIRO_ISS_PSB_YN);
    }
    if (null == this.PLR_STUP_PSB_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, PLR_STUP_PSB_YN);
    }
    if (null == this.HNDY_DSG_PSB_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, HNDY_DSG_PSB_YN);
    }
    if (null == this.CLOG_DPC_INP_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CLOG_DPC_INP_YN);
    }
    if (null == this.KORE_PD_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, KORE_PD_CD);
    }
    if (null == this.CLUS_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CLUS_DIV_CD);
    }
    if (null == this.LGTM_CTR_CR_XTR_MD_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, LGTM_CTR_CR_XTR_MD_CD);
    }
    if (null == this.IPY_PSB_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, IPY_PSB_YN);
    }
    if (null == this.SRP_APL_TRG_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, SRP_APL_TRG_YN);
    }
    if (null == this.INCM_DDC_TRG_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, INCM_DDC_TRG_YN);
    }
    if (null == this.HSEC_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, HSEC_DIV_CD);
    }
    if (null == this.SECT_INS_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, SECT_INS_DIV_CD);
    }
    if (null == this.PVCTR_ALLW_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, PVCTR_ALLW_YN);
    }
    if (null == this.IPY_LPS_PRD_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, IPY_LPS_PRD_DIV_CD);
    }
    if (null == this.IPY_PPN_PRD_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, IPY_PPN_PRD_DIV_CD);
    }
    if (null == this.NCLAM_BNS_EN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, NCLAM_BNS_EN);
    }
    if (null == this.RVW_ITMS_CRSS_PD_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RVW_ITMS_CRSS_PD_YN);
    }
    if (null == this.PRPY_PSB_TP_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, PRPY_PSB_TP_CD);
    }
    if (null == this.LANN_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, LANN_DIV_CD);
    }
    if (null == this.PD_GRP_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, PD_GRP_CD);
    }
    if (null == this.CNCLL_DDC_AMT_SBTR_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CNCLL_DDC_AMT_SBTR_YN);
    }
    if (null == this.CNCLL_DDC_YR_NUM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.CNCLL_DDC_YR_NUM, __dataOut);
    }
    if (null == this.XPT_INTR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.XPT_INTR, __dataOut);
    }
    if (null == this.BNCA_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, BNCA_YN);
    }
    if (null == this.MID_AMT_PAY_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, MID_AMT_PAY_YN);
    }
    if (null == this.HFWY_WDR_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, HFWY_WDR_YN);
    }
    if (null == this.LNK_PD_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, LNK_PD_CD);
    }
    if (null == this.APL_PD_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, APL_PD_CD);
    }
    if (null == this.RPT_PD_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RPT_PD_CD);
    }
    if (null == this.RPT_PD_NM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RPT_PD_NM);
    }
    if (null == this.RMK_CON) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RMK_CON);
    }
    if (null == this.BZPLN_PD_CTG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, BZPLN_PD_CTG_CD);
    }
    if (null == this.ITGR_PD_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ITGR_PD_YN);
    }
    if (null == this.EXPR_RFD_APL_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, EXPR_RFD_APL_DIV_CD);
    }
    if (null == this.SLZ_PD_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, SLZ_PD_DIV_CD);
    }
    if (null == this.ANN_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ANN_DIV_CD);
    }
    if (null == this.ANN_CAL_TP_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ANN_CAL_TP_CD);
    }
    if (null == this.PRPY_DC_APL_PREM_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, PRPY_DC_APL_PREM_CD);
    }
    if (null == this.HFWY_WDR_RFD_STD_CON) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, HFWY_WDR_RFD_STD_CON);
    }
    if (null == this.CI_PD_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CI_PD_YN);
    }
    if (null == this.REGPE_NM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, REGPE_NM);
    }
    if (null == this.REG_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.REG_DT.getTime());
    __dataOut.writeInt(this.REG_DT.getNanos());
    }
    if (null == this.MME_RPT_PD_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, MME_RPT_PD_CD);
    }
    if (null == this.MME_RPT_PD_CD_NM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, MME_RPT_PD_CD_NM);
    }
    if (null == this.AYTM_PY_LM_AMT_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, AYTM_PY_LM_AMT_DIV_CD);
    }
    if (null == this.ICLO_PSB_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ICLO_PSB_YN);
    }
    if (null == this.UNT_PD_SAL_NM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, UNT_PD_SAL_NM);
    }
    if (null == this.ISP_PD_CTG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ISP_PD_CTG_CD);
    }
    if (null == this.LGTM_INDV_GRUP_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, LGTM_INDV_GRUP_DIV_CD);
    }
    if (null == this.KIDI_PD_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, KIDI_PD_CD);
    }
    if (null == this.PRDY_AMT_PD_GRP_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, PRDY_AMT_PD_GRP_CD);
    }
    if (null == this.STND_INTR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.STND_INTR, __dataOut);
    }
    if (null == this.MDF_RT_APL_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, MDF_RT_APL_DIV_CD);
    }
    if (null == this.INDP_SIC_PD_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, INDP_SIC_PD_YN);
    }
    if (null == this.CKUP_TRG_PD_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CKUP_TRG_PD_YN);
    }
    if (null == this.POL_OTPT_WY_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, POL_OTPT_WY_DIV_CD);
    }
    if (null == this.SAL_BGN_DT1) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.SAL_BGN_DT1.getTime());
    __dataOut.writeInt(this.SAL_BGN_DT1.getNanos());
    }
    if (null == this.NW_KIDI_PD_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, NW_KIDI_PD_CD);
    }
    if (null == this.STIC_IDC_PD_CTG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, STIC_IDC_PD_CTG_CD);
    }
    if (null == this.QRCD_ADR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, QRCD_ADR);
    }
    if (null == this.AVG_PBAN_INTR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.AVG_PBAN_INTR, __dataOut);
    }
    if (null == this.EIH_LDG_DTM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.EIH_LDG_DTM.getTime());
    __dataOut.writeInt(this.EIH_LDG_DTM.getNanos());
    }
    if (null == this.NW_FAMT_INS_PD_CTG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, NW_FAMT_INS_PD_CTG_CD);
    }
    if (null == this.AT_ALTN_PY_TP_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, AT_ALTN_PY_TP_CD);
    }
    if (null == this.ICLO_STD_RT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.ICLO_STD_RT, __dataOut);
    }
    if (null == this.MFRC_PD_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, MFRC_PD_YN);
    }
    if (null == this.PY_EXEM_LRG_TOP_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, PY_EXEM_LRG_TOP_YN);
    }
    if (null == this.SCRN_EXPS_SQ) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.SCRN_EXPS_SQ, __dataOut);
    }
    if (null == this.SAL_BGN_TM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, SAL_BGN_TM);
    }
    if (null == this.ITMGP_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ITMGP_CD);
    }
    if (null == this.GRUP_PREM_AGE_STD_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, GRUP_PREM_AGE_STD_CD);
    }
    if (null == this.PDGP_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, PDGP_CD);
    }
    if (null == this.INS_ITMS_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, INS_ITMS_CD);
    }
    if (null == this.LNK_INDP_PD_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, LNK_INDP_PD_CD);
    }
    if (null == this.MBL_CLUS_ADR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, MBL_CLUS_ADR);
    }
    if (null == this.MLTD_OBJ_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, MLTD_OBJ_YN);
    }
    if (null == this.UNT_PD_SCRN_EXPS_NM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, UNT_PD_SCRN_EXPS_NM);
    }
    if (null == this.PY_EXEM_KND_TYP_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, PY_EXEM_KND_TYP_DIV_CD);
    }
    if (null == this.PY_EXEM_DIV_VAL) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, PY_EXEM_DIV_VAL);
    }
    if (null == this.FETS_PRD_CAL_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, FETS_PRD_CAL_DIV_CD);
    }
    if (null == this.UNT_PD_TP_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, UNT_PD_TP_CD);
    }
    if (null == this.BZ_IDC_PD_LCTG_NM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, BZ_IDC_PD_LCTG_NM);
    }
    if (null == this.BZ_IDC_PD_MCTG_NM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, BZ_IDC_PD_MCTG_NM);
    }
    if (null == this.BZ_IDC_PD_CTG_NM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, BZ_IDC_PD_CTG_NM);
    }
  }
  private static final DelimiterSet __outputDelimiters = new DelimiterSet((char) 1, (char) 10, (char) 0, (char) 0, false);
  public String toString() {
    return toString(__outputDelimiters, true);
  }
  public String toString(DelimiterSet delimiters) {
    return toString(delimiters, true);
  }
  public String toString(boolean useRecordDelim) {
    return toString(__outputDelimiters, useRecordDelim);
  }
  public String toString(DelimiterSet delimiters, boolean useRecordDelim) {
    StringBuilder __sb = new StringBuilder();
    char fieldDelim = delimiters.getFieldsTerminatedBy();
    __sb.append(FieldFormatter.escapeAndEnclose(UNT_PD_CD==null?"null":UNT_PD_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(VF_DT==null?"null":"" + VF_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(VT_DT==null?"null":"" + VT_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(UNT_PD_NM==null?"null":UNT_PD_NM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(UNT_PD_ABR_NM==null?"null":UNT_PD_ABR_NM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(UNT_PD_ENG_NM==null?"null":UNT_PD_ENG_NM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(UNT_PD_ENG_ABR_NM==null?"null":UNT_PD_ENG_ABR_NM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PD_AUTH_DT==null?"null":"" + PD_AUTH_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PD_SAL_TMRR_SUSP_DT==null?"null":"" + PD_SAL_TMRR_SUSP_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SAL_BGN_DT==null?"null":"" + SAL_BGN_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SAL_ED_DT==null?"null":"" + SAL_ED_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(INS_BGN_TM==null?"null":INS_BGN_TM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(INS_ED_TM==null?"null":INS_ED_TM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RPS_PD_CD==null?"null":RPS_PD_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(OD_PD_CD==null?"null":OD_PD_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(INS_ITMS_DIV_CD==null?"null":INS_ITMS_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(OD_STIC_PD_CTG_CD==null?"null":OD_STIC_PD_CTG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(NW_STIC_PD_CTG_CD==null?"null":NW_STIC_PD_CTG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(FAMT_INS_PD_CTG_CD==null?"null":FAMT_INS_PD_CTG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PD_AUTH_TP_CD==null?"null":PD_AUTH_TP_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ISP_STD_SCR==null?"null":ISP_STD_SCR.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(GURT_SAV_DIV_CD==null?"null":GURT_SAV_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SPC_ACCT_DIV_CD==null?"null":SPC_ACCT_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DVND_PAY_YN==null?"null":DVND_PAY_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(BZCC_JNT_PD_YN==null?"null":BZCC_JNT_PD_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(FETS_SBC_PSB_YN==null?"null":FETS_SBC_PSB_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ACU_GURT_SPR_YN==null?"null":ACU_GURT_SPR_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RNWL_COV_BEIN_YN==null?"null":RNWL_COV_BEIN_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PREM_CMPT_AGE_STD_CD==null?"null":PREM_CMPT_AGE_STD_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(HDTL_YN==null?"null":HDTL_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ALTN_PY_TRG_DIV_CD==null?"null":ALTN_PY_TRG_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PSTP_REVV_PSB_YN==null?"null":PSTP_REVV_PSB_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(AYTM_PY_PSB_YN==null?"null":AYTM_PY_PSB_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(FSS_DAT_OTPT_SEQ==null?"null":FSS_DAT_OTPT_SEQ.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SAL_PLAN_INCL_YN==null?"null":SAL_PLAN_INCL_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PPBZ_FND_CTRB_INST_CD==null?"null":PPBZ_FND_CTRB_INST_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PBPF_BZ_FND_CTRB_RT==null?"null":PBPF_BZ_FND_CTRB_RT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(APL_PREM_RDDW_UNT_CD==null?"null":APL_PREM_RDDW_UNT_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PD_MNDC_ISS_YN==null?"null":PD_MNDC_ISS_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ADJT_PSB_YN==null?"null":ADJT_PSB_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(INDV_CRP_DIV_CD==null?"null":INDV_CRP_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(GRUP_TRT_YN==null?"null":GRUP_TRT_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SMNS_POL_PSB_YN==null?"null":SMNS_POL_PSB_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(GIRO_ISS_PSB_YN==null?"null":GIRO_ISS_PSB_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PLR_STUP_PSB_YN==null?"null":PLR_STUP_PSB_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(HNDY_DSG_PSB_YN==null?"null":HNDY_DSG_PSB_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CLOG_DPC_INP_YN==null?"null":CLOG_DPC_INP_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(KORE_PD_CD==null?"null":KORE_PD_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CLUS_DIV_CD==null?"null":CLUS_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(LGTM_CTR_CR_XTR_MD_CD==null?"null":LGTM_CTR_CR_XTR_MD_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(IPY_PSB_YN==null?"null":IPY_PSB_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SRP_APL_TRG_YN==null?"null":SRP_APL_TRG_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(INCM_DDC_TRG_YN==null?"null":INCM_DDC_TRG_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(HSEC_DIV_CD==null?"null":HSEC_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SECT_INS_DIV_CD==null?"null":SECT_INS_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PVCTR_ALLW_YN==null?"null":PVCTR_ALLW_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(IPY_LPS_PRD_DIV_CD==null?"null":IPY_LPS_PRD_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(IPY_PPN_PRD_DIV_CD==null?"null":IPY_PPN_PRD_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(NCLAM_BNS_EN==null?"null":NCLAM_BNS_EN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RVW_ITMS_CRSS_PD_YN==null?"null":RVW_ITMS_CRSS_PD_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PRPY_PSB_TP_CD==null?"null":PRPY_PSB_TP_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(LANN_DIV_CD==null?"null":LANN_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PD_GRP_CD==null?"null":PD_GRP_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CNCLL_DDC_AMT_SBTR_YN==null?"null":CNCLL_DDC_AMT_SBTR_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CNCLL_DDC_YR_NUM==null?"null":CNCLL_DDC_YR_NUM.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(XPT_INTR==null?"null":XPT_INTR.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(BNCA_YN==null?"null":BNCA_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(MID_AMT_PAY_YN==null?"null":MID_AMT_PAY_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(HFWY_WDR_YN==null?"null":HFWY_WDR_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(LNK_PD_CD==null?"null":LNK_PD_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(APL_PD_CD==null?"null":APL_PD_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RPT_PD_CD==null?"null":RPT_PD_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RPT_PD_NM==null?"null":RPT_PD_NM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RMK_CON==null?"null":RMK_CON, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(BZPLN_PD_CTG_CD==null?"null":BZPLN_PD_CTG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ITGR_PD_YN==null?"null":ITGR_PD_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(EXPR_RFD_APL_DIV_CD==null?"null":EXPR_RFD_APL_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SLZ_PD_DIV_CD==null?"null":SLZ_PD_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ANN_DIV_CD==null?"null":ANN_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ANN_CAL_TP_CD==null?"null":ANN_CAL_TP_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PRPY_DC_APL_PREM_CD==null?"null":PRPY_DC_APL_PREM_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(HFWY_WDR_RFD_STD_CON==null?"null":HFWY_WDR_RFD_STD_CON, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CI_PD_YN==null?"null":CI_PD_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(REGPE_NM==null?"null":REGPE_NM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(REG_DT==null?"null":"" + REG_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(MME_RPT_PD_CD==null?"null":MME_RPT_PD_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(MME_RPT_PD_CD_NM==null?"null":MME_RPT_PD_CD_NM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(AYTM_PY_LM_AMT_DIV_CD==null?"null":AYTM_PY_LM_AMT_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ICLO_PSB_YN==null?"null":ICLO_PSB_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(UNT_PD_SAL_NM==null?"null":UNT_PD_SAL_NM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ISP_PD_CTG_CD==null?"null":ISP_PD_CTG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(LGTM_INDV_GRUP_DIV_CD==null?"null":LGTM_INDV_GRUP_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(KIDI_PD_CD==null?"null":KIDI_PD_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PRDY_AMT_PD_GRP_CD==null?"null":PRDY_AMT_PD_GRP_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(STND_INTR==null?"null":STND_INTR.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(MDF_RT_APL_DIV_CD==null?"null":MDF_RT_APL_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(INDP_SIC_PD_YN==null?"null":INDP_SIC_PD_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CKUP_TRG_PD_YN==null?"null":CKUP_TRG_PD_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(POL_OTPT_WY_DIV_CD==null?"null":POL_OTPT_WY_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SAL_BGN_DT1==null?"null":"" + SAL_BGN_DT1, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(NW_KIDI_PD_CD==null?"null":NW_KIDI_PD_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(STIC_IDC_PD_CTG_CD==null?"null":STIC_IDC_PD_CTG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(QRCD_ADR==null?"null":QRCD_ADR, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(AVG_PBAN_INTR==null?"null":AVG_PBAN_INTR.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(EIH_LDG_DTM==null?"null":"" + EIH_LDG_DTM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(NW_FAMT_INS_PD_CTG_CD==null?"null":NW_FAMT_INS_PD_CTG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(AT_ALTN_PY_TP_CD==null?"null":AT_ALTN_PY_TP_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ICLO_STD_RT==null?"null":ICLO_STD_RT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(MFRC_PD_YN==null?"null":MFRC_PD_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PY_EXEM_LRG_TOP_YN==null?"null":PY_EXEM_LRG_TOP_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SCRN_EXPS_SQ==null?"null":SCRN_EXPS_SQ.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SAL_BGN_TM==null?"null":SAL_BGN_TM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ITMGP_CD==null?"null":ITMGP_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(GRUP_PREM_AGE_STD_CD==null?"null":GRUP_PREM_AGE_STD_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PDGP_CD==null?"null":PDGP_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(INS_ITMS_CD==null?"null":INS_ITMS_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(LNK_INDP_PD_CD==null?"null":LNK_INDP_PD_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(MBL_CLUS_ADR==null?"null":MBL_CLUS_ADR, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(MLTD_OBJ_YN==null?"null":MLTD_OBJ_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(UNT_PD_SCRN_EXPS_NM==null?"null":UNT_PD_SCRN_EXPS_NM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PY_EXEM_KND_TYP_DIV_CD==null?"null":PY_EXEM_KND_TYP_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PY_EXEM_DIV_VAL==null?"null":PY_EXEM_DIV_VAL, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(FETS_PRD_CAL_DIV_CD==null?"null":FETS_PRD_CAL_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(UNT_PD_TP_CD==null?"null":UNT_PD_TP_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(BZ_IDC_PD_LCTG_NM==null?"null":BZ_IDC_PD_LCTG_NM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(BZ_IDC_PD_MCTG_NM==null?"null":BZ_IDC_PD_MCTG_NM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(BZ_IDC_PD_CTG_NM==null?"null":BZ_IDC_PD_CTG_NM, delimiters));
    if (useRecordDelim) {
      __sb.append(delimiters.getLinesTerminatedBy());
    }
    return __sb.toString();
  }
  public void toString0(DelimiterSet delimiters, StringBuilder __sb, char fieldDelim) {
    __sb.append(FieldFormatter.escapeAndEnclose(UNT_PD_CD==null?"null":UNT_PD_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(VF_DT==null?"null":"" + VF_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(VT_DT==null?"null":"" + VT_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(UNT_PD_NM==null?"null":UNT_PD_NM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(UNT_PD_ABR_NM==null?"null":UNT_PD_ABR_NM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(UNT_PD_ENG_NM==null?"null":UNT_PD_ENG_NM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(UNT_PD_ENG_ABR_NM==null?"null":UNT_PD_ENG_ABR_NM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PD_AUTH_DT==null?"null":"" + PD_AUTH_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PD_SAL_TMRR_SUSP_DT==null?"null":"" + PD_SAL_TMRR_SUSP_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SAL_BGN_DT==null?"null":"" + SAL_BGN_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SAL_ED_DT==null?"null":"" + SAL_ED_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(INS_BGN_TM==null?"null":INS_BGN_TM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(INS_ED_TM==null?"null":INS_ED_TM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RPS_PD_CD==null?"null":RPS_PD_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(OD_PD_CD==null?"null":OD_PD_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(INS_ITMS_DIV_CD==null?"null":INS_ITMS_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(OD_STIC_PD_CTG_CD==null?"null":OD_STIC_PD_CTG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(NW_STIC_PD_CTG_CD==null?"null":NW_STIC_PD_CTG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(FAMT_INS_PD_CTG_CD==null?"null":FAMT_INS_PD_CTG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PD_AUTH_TP_CD==null?"null":PD_AUTH_TP_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ISP_STD_SCR==null?"null":ISP_STD_SCR.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(GURT_SAV_DIV_CD==null?"null":GURT_SAV_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SPC_ACCT_DIV_CD==null?"null":SPC_ACCT_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DVND_PAY_YN==null?"null":DVND_PAY_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(BZCC_JNT_PD_YN==null?"null":BZCC_JNT_PD_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(FETS_SBC_PSB_YN==null?"null":FETS_SBC_PSB_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ACU_GURT_SPR_YN==null?"null":ACU_GURT_SPR_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RNWL_COV_BEIN_YN==null?"null":RNWL_COV_BEIN_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PREM_CMPT_AGE_STD_CD==null?"null":PREM_CMPT_AGE_STD_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(HDTL_YN==null?"null":HDTL_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ALTN_PY_TRG_DIV_CD==null?"null":ALTN_PY_TRG_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PSTP_REVV_PSB_YN==null?"null":PSTP_REVV_PSB_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(AYTM_PY_PSB_YN==null?"null":AYTM_PY_PSB_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(FSS_DAT_OTPT_SEQ==null?"null":FSS_DAT_OTPT_SEQ.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SAL_PLAN_INCL_YN==null?"null":SAL_PLAN_INCL_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PPBZ_FND_CTRB_INST_CD==null?"null":PPBZ_FND_CTRB_INST_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PBPF_BZ_FND_CTRB_RT==null?"null":PBPF_BZ_FND_CTRB_RT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(APL_PREM_RDDW_UNT_CD==null?"null":APL_PREM_RDDW_UNT_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PD_MNDC_ISS_YN==null?"null":PD_MNDC_ISS_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ADJT_PSB_YN==null?"null":ADJT_PSB_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(INDV_CRP_DIV_CD==null?"null":INDV_CRP_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(GRUP_TRT_YN==null?"null":GRUP_TRT_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SMNS_POL_PSB_YN==null?"null":SMNS_POL_PSB_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(GIRO_ISS_PSB_YN==null?"null":GIRO_ISS_PSB_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PLR_STUP_PSB_YN==null?"null":PLR_STUP_PSB_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(HNDY_DSG_PSB_YN==null?"null":HNDY_DSG_PSB_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CLOG_DPC_INP_YN==null?"null":CLOG_DPC_INP_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(KORE_PD_CD==null?"null":KORE_PD_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CLUS_DIV_CD==null?"null":CLUS_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(LGTM_CTR_CR_XTR_MD_CD==null?"null":LGTM_CTR_CR_XTR_MD_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(IPY_PSB_YN==null?"null":IPY_PSB_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SRP_APL_TRG_YN==null?"null":SRP_APL_TRG_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(INCM_DDC_TRG_YN==null?"null":INCM_DDC_TRG_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(HSEC_DIV_CD==null?"null":HSEC_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SECT_INS_DIV_CD==null?"null":SECT_INS_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PVCTR_ALLW_YN==null?"null":PVCTR_ALLW_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(IPY_LPS_PRD_DIV_CD==null?"null":IPY_LPS_PRD_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(IPY_PPN_PRD_DIV_CD==null?"null":IPY_PPN_PRD_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(NCLAM_BNS_EN==null?"null":NCLAM_BNS_EN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RVW_ITMS_CRSS_PD_YN==null?"null":RVW_ITMS_CRSS_PD_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PRPY_PSB_TP_CD==null?"null":PRPY_PSB_TP_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(LANN_DIV_CD==null?"null":LANN_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PD_GRP_CD==null?"null":PD_GRP_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CNCLL_DDC_AMT_SBTR_YN==null?"null":CNCLL_DDC_AMT_SBTR_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CNCLL_DDC_YR_NUM==null?"null":CNCLL_DDC_YR_NUM.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(XPT_INTR==null?"null":XPT_INTR.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(BNCA_YN==null?"null":BNCA_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(MID_AMT_PAY_YN==null?"null":MID_AMT_PAY_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(HFWY_WDR_YN==null?"null":HFWY_WDR_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(LNK_PD_CD==null?"null":LNK_PD_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(APL_PD_CD==null?"null":APL_PD_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RPT_PD_CD==null?"null":RPT_PD_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RPT_PD_NM==null?"null":RPT_PD_NM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RMK_CON==null?"null":RMK_CON, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(BZPLN_PD_CTG_CD==null?"null":BZPLN_PD_CTG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ITGR_PD_YN==null?"null":ITGR_PD_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(EXPR_RFD_APL_DIV_CD==null?"null":EXPR_RFD_APL_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SLZ_PD_DIV_CD==null?"null":SLZ_PD_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ANN_DIV_CD==null?"null":ANN_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ANN_CAL_TP_CD==null?"null":ANN_CAL_TP_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PRPY_DC_APL_PREM_CD==null?"null":PRPY_DC_APL_PREM_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(HFWY_WDR_RFD_STD_CON==null?"null":HFWY_WDR_RFD_STD_CON, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CI_PD_YN==null?"null":CI_PD_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(REGPE_NM==null?"null":REGPE_NM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(REG_DT==null?"null":"" + REG_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(MME_RPT_PD_CD==null?"null":MME_RPT_PD_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(MME_RPT_PD_CD_NM==null?"null":MME_RPT_PD_CD_NM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(AYTM_PY_LM_AMT_DIV_CD==null?"null":AYTM_PY_LM_AMT_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ICLO_PSB_YN==null?"null":ICLO_PSB_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(UNT_PD_SAL_NM==null?"null":UNT_PD_SAL_NM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ISP_PD_CTG_CD==null?"null":ISP_PD_CTG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(LGTM_INDV_GRUP_DIV_CD==null?"null":LGTM_INDV_GRUP_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(KIDI_PD_CD==null?"null":KIDI_PD_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PRDY_AMT_PD_GRP_CD==null?"null":PRDY_AMT_PD_GRP_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(STND_INTR==null?"null":STND_INTR.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(MDF_RT_APL_DIV_CD==null?"null":MDF_RT_APL_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(INDP_SIC_PD_YN==null?"null":INDP_SIC_PD_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CKUP_TRG_PD_YN==null?"null":CKUP_TRG_PD_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(POL_OTPT_WY_DIV_CD==null?"null":POL_OTPT_WY_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SAL_BGN_DT1==null?"null":"" + SAL_BGN_DT1, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(NW_KIDI_PD_CD==null?"null":NW_KIDI_PD_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(STIC_IDC_PD_CTG_CD==null?"null":STIC_IDC_PD_CTG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(QRCD_ADR==null?"null":QRCD_ADR, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(AVG_PBAN_INTR==null?"null":AVG_PBAN_INTR.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(EIH_LDG_DTM==null?"null":"" + EIH_LDG_DTM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(NW_FAMT_INS_PD_CTG_CD==null?"null":NW_FAMT_INS_PD_CTG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(AT_ALTN_PY_TP_CD==null?"null":AT_ALTN_PY_TP_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ICLO_STD_RT==null?"null":ICLO_STD_RT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(MFRC_PD_YN==null?"null":MFRC_PD_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PY_EXEM_LRG_TOP_YN==null?"null":PY_EXEM_LRG_TOP_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SCRN_EXPS_SQ==null?"null":SCRN_EXPS_SQ.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SAL_BGN_TM==null?"null":SAL_BGN_TM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ITMGP_CD==null?"null":ITMGP_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(GRUP_PREM_AGE_STD_CD==null?"null":GRUP_PREM_AGE_STD_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PDGP_CD==null?"null":PDGP_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(INS_ITMS_CD==null?"null":INS_ITMS_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(LNK_INDP_PD_CD==null?"null":LNK_INDP_PD_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(MBL_CLUS_ADR==null?"null":MBL_CLUS_ADR, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(MLTD_OBJ_YN==null?"null":MLTD_OBJ_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(UNT_PD_SCRN_EXPS_NM==null?"null":UNT_PD_SCRN_EXPS_NM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PY_EXEM_KND_TYP_DIV_CD==null?"null":PY_EXEM_KND_TYP_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PY_EXEM_DIV_VAL==null?"null":PY_EXEM_DIV_VAL, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(FETS_PRD_CAL_DIV_CD==null?"null":FETS_PRD_CAL_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(UNT_PD_TP_CD==null?"null":UNT_PD_TP_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(BZ_IDC_PD_LCTG_NM==null?"null":BZ_IDC_PD_LCTG_NM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(BZ_IDC_PD_MCTG_NM==null?"null":BZ_IDC_PD_MCTG_NM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(BZ_IDC_PD_CTG_NM==null?"null":BZ_IDC_PD_CTG_NM, delimiters));
  }
  private static final DelimiterSet __inputDelimiters = new DelimiterSet((char) 1, (char) 10, (char) 0, (char) 0, false);
  private RecordParser __parser;
  public void parse(Text __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(CharSequence __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(byte [] __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(char [] __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(ByteBuffer __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(CharBuffer __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  private void __loadFromFields(List<String> fields) {
    Iterator<String> __it = fields.listIterator();
    String __cur_str = null;
    try {
    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.UNT_PD_CD = null; } else {
      this.UNT_PD_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.VF_DT = null; } else {
      this.VF_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.VT_DT = null; } else {
      this.VT_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.UNT_PD_NM = null; } else {
      this.UNT_PD_NM = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.UNT_PD_ABR_NM = null; } else {
      this.UNT_PD_ABR_NM = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.UNT_PD_ENG_NM = null; } else {
      this.UNT_PD_ENG_NM = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.UNT_PD_ENG_ABR_NM = null; } else {
      this.UNT_PD_ENG_ABR_NM = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.PD_AUTH_DT = null; } else {
      this.PD_AUTH_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.PD_SAL_TMRR_SUSP_DT = null; } else {
      this.PD_SAL_TMRR_SUSP_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.SAL_BGN_DT = null; } else {
      this.SAL_BGN_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.SAL_ED_DT = null; } else {
      this.SAL_ED_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.INS_BGN_TM = null; } else {
      this.INS_BGN_TM = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.INS_ED_TM = null; } else {
      this.INS_ED_TM = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.RPS_PD_CD = null; } else {
      this.RPS_PD_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.OD_PD_CD = null; } else {
      this.OD_PD_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.INS_ITMS_DIV_CD = null; } else {
      this.INS_ITMS_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.OD_STIC_PD_CTG_CD = null; } else {
      this.OD_STIC_PD_CTG_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.NW_STIC_PD_CTG_CD = null; } else {
      this.NW_STIC_PD_CTG_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.FAMT_INS_PD_CTG_CD = null; } else {
      this.FAMT_INS_PD_CTG_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.PD_AUTH_TP_CD = null; } else {
      this.PD_AUTH_TP_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.ISP_STD_SCR = null; } else {
      this.ISP_STD_SCR = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.GURT_SAV_DIV_CD = null; } else {
      this.GURT_SAV_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.SPC_ACCT_DIV_CD = null; } else {
      this.SPC_ACCT_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.DVND_PAY_YN = null; } else {
      this.DVND_PAY_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.BZCC_JNT_PD_YN = null; } else {
      this.BZCC_JNT_PD_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.FETS_SBC_PSB_YN = null; } else {
      this.FETS_SBC_PSB_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.ACU_GURT_SPR_YN = null; } else {
      this.ACU_GURT_SPR_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.RNWL_COV_BEIN_YN = null; } else {
      this.RNWL_COV_BEIN_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.PREM_CMPT_AGE_STD_CD = null; } else {
      this.PREM_CMPT_AGE_STD_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.HDTL_YN = null; } else {
      this.HDTL_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.ALTN_PY_TRG_DIV_CD = null; } else {
      this.ALTN_PY_TRG_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.PSTP_REVV_PSB_YN = null; } else {
      this.PSTP_REVV_PSB_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.AYTM_PY_PSB_YN = null; } else {
      this.AYTM_PY_PSB_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.FSS_DAT_OTPT_SEQ = null; } else {
      this.FSS_DAT_OTPT_SEQ = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.SAL_PLAN_INCL_YN = null; } else {
      this.SAL_PLAN_INCL_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.PPBZ_FND_CTRB_INST_CD = null; } else {
      this.PPBZ_FND_CTRB_INST_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.PBPF_BZ_FND_CTRB_RT = null; } else {
      this.PBPF_BZ_FND_CTRB_RT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.APL_PREM_RDDW_UNT_CD = null; } else {
      this.APL_PREM_RDDW_UNT_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.PD_MNDC_ISS_YN = null; } else {
      this.PD_MNDC_ISS_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.ADJT_PSB_YN = null; } else {
      this.ADJT_PSB_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.INDV_CRP_DIV_CD = null; } else {
      this.INDV_CRP_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.GRUP_TRT_YN = null; } else {
      this.GRUP_TRT_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.SMNS_POL_PSB_YN = null; } else {
      this.SMNS_POL_PSB_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.GIRO_ISS_PSB_YN = null; } else {
      this.GIRO_ISS_PSB_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.PLR_STUP_PSB_YN = null; } else {
      this.PLR_STUP_PSB_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.HNDY_DSG_PSB_YN = null; } else {
      this.HNDY_DSG_PSB_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CLOG_DPC_INP_YN = null; } else {
      this.CLOG_DPC_INP_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.KORE_PD_CD = null; } else {
      this.KORE_PD_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CLUS_DIV_CD = null; } else {
      this.CLUS_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.LGTM_CTR_CR_XTR_MD_CD = null; } else {
      this.LGTM_CTR_CR_XTR_MD_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.IPY_PSB_YN = null; } else {
      this.IPY_PSB_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.SRP_APL_TRG_YN = null; } else {
      this.SRP_APL_TRG_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.INCM_DDC_TRG_YN = null; } else {
      this.INCM_DDC_TRG_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.HSEC_DIV_CD = null; } else {
      this.HSEC_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.SECT_INS_DIV_CD = null; } else {
      this.SECT_INS_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.PVCTR_ALLW_YN = null; } else {
      this.PVCTR_ALLW_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.IPY_LPS_PRD_DIV_CD = null; } else {
      this.IPY_LPS_PRD_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.IPY_PPN_PRD_DIV_CD = null; } else {
      this.IPY_PPN_PRD_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.NCLAM_BNS_EN = null; } else {
      this.NCLAM_BNS_EN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.RVW_ITMS_CRSS_PD_YN = null; } else {
      this.RVW_ITMS_CRSS_PD_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.PRPY_PSB_TP_CD = null; } else {
      this.PRPY_PSB_TP_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.LANN_DIV_CD = null; } else {
      this.LANN_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.PD_GRP_CD = null; } else {
      this.PD_GRP_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CNCLL_DDC_AMT_SBTR_YN = null; } else {
      this.CNCLL_DDC_AMT_SBTR_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.CNCLL_DDC_YR_NUM = null; } else {
      this.CNCLL_DDC_YR_NUM = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.XPT_INTR = null; } else {
      this.XPT_INTR = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.BNCA_YN = null; } else {
      this.BNCA_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.MID_AMT_PAY_YN = null; } else {
      this.MID_AMT_PAY_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.HFWY_WDR_YN = null; } else {
      this.HFWY_WDR_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.LNK_PD_CD = null; } else {
      this.LNK_PD_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.APL_PD_CD = null; } else {
      this.APL_PD_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.RPT_PD_CD = null; } else {
      this.RPT_PD_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.RPT_PD_NM = null; } else {
      this.RPT_PD_NM = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.RMK_CON = null; } else {
      this.RMK_CON = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.BZPLN_PD_CTG_CD = null; } else {
      this.BZPLN_PD_CTG_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.ITGR_PD_YN = null; } else {
      this.ITGR_PD_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.EXPR_RFD_APL_DIV_CD = null; } else {
      this.EXPR_RFD_APL_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.SLZ_PD_DIV_CD = null; } else {
      this.SLZ_PD_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.ANN_DIV_CD = null; } else {
      this.ANN_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.ANN_CAL_TP_CD = null; } else {
      this.ANN_CAL_TP_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.PRPY_DC_APL_PREM_CD = null; } else {
      this.PRPY_DC_APL_PREM_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.HFWY_WDR_RFD_STD_CON = null; } else {
      this.HFWY_WDR_RFD_STD_CON = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CI_PD_YN = null; } else {
      this.CI_PD_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.REGPE_NM = null; } else {
      this.REGPE_NM = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.REG_DT = null; } else {
      this.REG_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.MME_RPT_PD_CD = null; } else {
      this.MME_RPT_PD_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.MME_RPT_PD_CD_NM = null; } else {
      this.MME_RPT_PD_CD_NM = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.AYTM_PY_LM_AMT_DIV_CD = null; } else {
      this.AYTM_PY_LM_AMT_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.ICLO_PSB_YN = null; } else {
      this.ICLO_PSB_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.UNT_PD_SAL_NM = null; } else {
      this.UNT_PD_SAL_NM = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.ISP_PD_CTG_CD = null; } else {
      this.ISP_PD_CTG_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.LGTM_INDV_GRUP_DIV_CD = null; } else {
      this.LGTM_INDV_GRUP_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.KIDI_PD_CD = null; } else {
      this.KIDI_PD_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.PRDY_AMT_PD_GRP_CD = null; } else {
      this.PRDY_AMT_PD_GRP_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.STND_INTR = null; } else {
      this.STND_INTR = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.MDF_RT_APL_DIV_CD = null; } else {
      this.MDF_RT_APL_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.INDP_SIC_PD_YN = null; } else {
      this.INDP_SIC_PD_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CKUP_TRG_PD_YN = null; } else {
      this.CKUP_TRG_PD_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.POL_OTPT_WY_DIV_CD = null; } else {
      this.POL_OTPT_WY_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.SAL_BGN_DT1 = null; } else {
      this.SAL_BGN_DT1 = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.NW_KIDI_PD_CD = null; } else {
      this.NW_KIDI_PD_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.STIC_IDC_PD_CTG_CD = null; } else {
      this.STIC_IDC_PD_CTG_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.QRCD_ADR = null; } else {
      this.QRCD_ADR = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.AVG_PBAN_INTR = null; } else {
      this.AVG_PBAN_INTR = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.EIH_LDG_DTM = null; } else {
      this.EIH_LDG_DTM = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.NW_FAMT_INS_PD_CTG_CD = null; } else {
      this.NW_FAMT_INS_PD_CTG_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.AT_ALTN_PY_TP_CD = null; } else {
      this.AT_ALTN_PY_TP_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.ICLO_STD_RT = null; } else {
      this.ICLO_STD_RT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.MFRC_PD_YN = null; } else {
      this.MFRC_PD_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.PY_EXEM_LRG_TOP_YN = null; } else {
      this.PY_EXEM_LRG_TOP_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.SCRN_EXPS_SQ = null; } else {
      this.SCRN_EXPS_SQ = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.SAL_BGN_TM = null; } else {
      this.SAL_BGN_TM = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.ITMGP_CD = null; } else {
      this.ITMGP_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.GRUP_PREM_AGE_STD_CD = null; } else {
      this.GRUP_PREM_AGE_STD_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.PDGP_CD = null; } else {
      this.PDGP_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.INS_ITMS_CD = null; } else {
      this.INS_ITMS_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.LNK_INDP_PD_CD = null; } else {
      this.LNK_INDP_PD_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.MBL_CLUS_ADR = null; } else {
      this.MBL_CLUS_ADR = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.MLTD_OBJ_YN = null; } else {
      this.MLTD_OBJ_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.UNT_PD_SCRN_EXPS_NM = null; } else {
      this.UNT_PD_SCRN_EXPS_NM = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.PY_EXEM_KND_TYP_DIV_CD = null; } else {
      this.PY_EXEM_KND_TYP_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.PY_EXEM_DIV_VAL = null; } else {
      this.PY_EXEM_DIV_VAL = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.FETS_PRD_CAL_DIV_CD = null; } else {
      this.FETS_PRD_CAL_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.UNT_PD_TP_CD = null; } else {
      this.UNT_PD_TP_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.BZ_IDC_PD_LCTG_NM = null; } else {
      this.BZ_IDC_PD_LCTG_NM = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.BZ_IDC_PD_MCTG_NM = null; } else {
      this.BZ_IDC_PD_MCTG_NM = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.BZ_IDC_PD_CTG_NM = null; } else {
      this.BZ_IDC_PD_CTG_NM = __cur_str;
    }

    } catch (RuntimeException e) {    throw new RuntimeException("Can't parse input data: '" + __cur_str + "'", e);    }  }

  private void __loadFromFields0(Iterator<String> __it) {
    String __cur_str = null;
    try {
    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.UNT_PD_CD = null; } else {
      this.UNT_PD_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.VF_DT = null; } else {
      this.VF_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.VT_DT = null; } else {
      this.VT_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.UNT_PD_NM = null; } else {
      this.UNT_PD_NM = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.UNT_PD_ABR_NM = null; } else {
      this.UNT_PD_ABR_NM = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.UNT_PD_ENG_NM = null; } else {
      this.UNT_PD_ENG_NM = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.UNT_PD_ENG_ABR_NM = null; } else {
      this.UNT_PD_ENG_ABR_NM = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.PD_AUTH_DT = null; } else {
      this.PD_AUTH_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.PD_SAL_TMRR_SUSP_DT = null; } else {
      this.PD_SAL_TMRR_SUSP_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.SAL_BGN_DT = null; } else {
      this.SAL_BGN_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.SAL_ED_DT = null; } else {
      this.SAL_ED_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.INS_BGN_TM = null; } else {
      this.INS_BGN_TM = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.INS_ED_TM = null; } else {
      this.INS_ED_TM = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.RPS_PD_CD = null; } else {
      this.RPS_PD_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.OD_PD_CD = null; } else {
      this.OD_PD_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.INS_ITMS_DIV_CD = null; } else {
      this.INS_ITMS_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.OD_STIC_PD_CTG_CD = null; } else {
      this.OD_STIC_PD_CTG_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.NW_STIC_PD_CTG_CD = null; } else {
      this.NW_STIC_PD_CTG_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.FAMT_INS_PD_CTG_CD = null; } else {
      this.FAMT_INS_PD_CTG_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.PD_AUTH_TP_CD = null; } else {
      this.PD_AUTH_TP_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.ISP_STD_SCR = null; } else {
      this.ISP_STD_SCR = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.GURT_SAV_DIV_CD = null; } else {
      this.GURT_SAV_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.SPC_ACCT_DIV_CD = null; } else {
      this.SPC_ACCT_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.DVND_PAY_YN = null; } else {
      this.DVND_PAY_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.BZCC_JNT_PD_YN = null; } else {
      this.BZCC_JNT_PD_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.FETS_SBC_PSB_YN = null; } else {
      this.FETS_SBC_PSB_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.ACU_GURT_SPR_YN = null; } else {
      this.ACU_GURT_SPR_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.RNWL_COV_BEIN_YN = null; } else {
      this.RNWL_COV_BEIN_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.PREM_CMPT_AGE_STD_CD = null; } else {
      this.PREM_CMPT_AGE_STD_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.HDTL_YN = null; } else {
      this.HDTL_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.ALTN_PY_TRG_DIV_CD = null; } else {
      this.ALTN_PY_TRG_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.PSTP_REVV_PSB_YN = null; } else {
      this.PSTP_REVV_PSB_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.AYTM_PY_PSB_YN = null; } else {
      this.AYTM_PY_PSB_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.FSS_DAT_OTPT_SEQ = null; } else {
      this.FSS_DAT_OTPT_SEQ = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.SAL_PLAN_INCL_YN = null; } else {
      this.SAL_PLAN_INCL_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.PPBZ_FND_CTRB_INST_CD = null; } else {
      this.PPBZ_FND_CTRB_INST_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.PBPF_BZ_FND_CTRB_RT = null; } else {
      this.PBPF_BZ_FND_CTRB_RT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.APL_PREM_RDDW_UNT_CD = null; } else {
      this.APL_PREM_RDDW_UNT_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.PD_MNDC_ISS_YN = null; } else {
      this.PD_MNDC_ISS_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.ADJT_PSB_YN = null; } else {
      this.ADJT_PSB_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.INDV_CRP_DIV_CD = null; } else {
      this.INDV_CRP_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.GRUP_TRT_YN = null; } else {
      this.GRUP_TRT_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.SMNS_POL_PSB_YN = null; } else {
      this.SMNS_POL_PSB_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.GIRO_ISS_PSB_YN = null; } else {
      this.GIRO_ISS_PSB_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.PLR_STUP_PSB_YN = null; } else {
      this.PLR_STUP_PSB_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.HNDY_DSG_PSB_YN = null; } else {
      this.HNDY_DSG_PSB_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CLOG_DPC_INP_YN = null; } else {
      this.CLOG_DPC_INP_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.KORE_PD_CD = null; } else {
      this.KORE_PD_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CLUS_DIV_CD = null; } else {
      this.CLUS_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.LGTM_CTR_CR_XTR_MD_CD = null; } else {
      this.LGTM_CTR_CR_XTR_MD_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.IPY_PSB_YN = null; } else {
      this.IPY_PSB_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.SRP_APL_TRG_YN = null; } else {
      this.SRP_APL_TRG_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.INCM_DDC_TRG_YN = null; } else {
      this.INCM_DDC_TRG_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.HSEC_DIV_CD = null; } else {
      this.HSEC_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.SECT_INS_DIV_CD = null; } else {
      this.SECT_INS_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.PVCTR_ALLW_YN = null; } else {
      this.PVCTR_ALLW_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.IPY_LPS_PRD_DIV_CD = null; } else {
      this.IPY_LPS_PRD_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.IPY_PPN_PRD_DIV_CD = null; } else {
      this.IPY_PPN_PRD_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.NCLAM_BNS_EN = null; } else {
      this.NCLAM_BNS_EN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.RVW_ITMS_CRSS_PD_YN = null; } else {
      this.RVW_ITMS_CRSS_PD_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.PRPY_PSB_TP_CD = null; } else {
      this.PRPY_PSB_TP_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.LANN_DIV_CD = null; } else {
      this.LANN_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.PD_GRP_CD = null; } else {
      this.PD_GRP_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CNCLL_DDC_AMT_SBTR_YN = null; } else {
      this.CNCLL_DDC_AMT_SBTR_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.CNCLL_DDC_YR_NUM = null; } else {
      this.CNCLL_DDC_YR_NUM = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.XPT_INTR = null; } else {
      this.XPT_INTR = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.BNCA_YN = null; } else {
      this.BNCA_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.MID_AMT_PAY_YN = null; } else {
      this.MID_AMT_PAY_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.HFWY_WDR_YN = null; } else {
      this.HFWY_WDR_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.LNK_PD_CD = null; } else {
      this.LNK_PD_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.APL_PD_CD = null; } else {
      this.APL_PD_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.RPT_PD_CD = null; } else {
      this.RPT_PD_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.RPT_PD_NM = null; } else {
      this.RPT_PD_NM = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.RMK_CON = null; } else {
      this.RMK_CON = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.BZPLN_PD_CTG_CD = null; } else {
      this.BZPLN_PD_CTG_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.ITGR_PD_YN = null; } else {
      this.ITGR_PD_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.EXPR_RFD_APL_DIV_CD = null; } else {
      this.EXPR_RFD_APL_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.SLZ_PD_DIV_CD = null; } else {
      this.SLZ_PD_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.ANN_DIV_CD = null; } else {
      this.ANN_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.ANN_CAL_TP_CD = null; } else {
      this.ANN_CAL_TP_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.PRPY_DC_APL_PREM_CD = null; } else {
      this.PRPY_DC_APL_PREM_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.HFWY_WDR_RFD_STD_CON = null; } else {
      this.HFWY_WDR_RFD_STD_CON = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CI_PD_YN = null; } else {
      this.CI_PD_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.REGPE_NM = null; } else {
      this.REGPE_NM = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.REG_DT = null; } else {
      this.REG_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.MME_RPT_PD_CD = null; } else {
      this.MME_RPT_PD_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.MME_RPT_PD_CD_NM = null; } else {
      this.MME_RPT_PD_CD_NM = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.AYTM_PY_LM_AMT_DIV_CD = null; } else {
      this.AYTM_PY_LM_AMT_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.ICLO_PSB_YN = null; } else {
      this.ICLO_PSB_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.UNT_PD_SAL_NM = null; } else {
      this.UNT_PD_SAL_NM = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.ISP_PD_CTG_CD = null; } else {
      this.ISP_PD_CTG_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.LGTM_INDV_GRUP_DIV_CD = null; } else {
      this.LGTM_INDV_GRUP_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.KIDI_PD_CD = null; } else {
      this.KIDI_PD_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.PRDY_AMT_PD_GRP_CD = null; } else {
      this.PRDY_AMT_PD_GRP_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.STND_INTR = null; } else {
      this.STND_INTR = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.MDF_RT_APL_DIV_CD = null; } else {
      this.MDF_RT_APL_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.INDP_SIC_PD_YN = null; } else {
      this.INDP_SIC_PD_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CKUP_TRG_PD_YN = null; } else {
      this.CKUP_TRG_PD_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.POL_OTPT_WY_DIV_CD = null; } else {
      this.POL_OTPT_WY_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.SAL_BGN_DT1 = null; } else {
      this.SAL_BGN_DT1 = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.NW_KIDI_PD_CD = null; } else {
      this.NW_KIDI_PD_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.STIC_IDC_PD_CTG_CD = null; } else {
      this.STIC_IDC_PD_CTG_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.QRCD_ADR = null; } else {
      this.QRCD_ADR = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.AVG_PBAN_INTR = null; } else {
      this.AVG_PBAN_INTR = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.EIH_LDG_DTM = null; } else {
      this.EIH_LDG_DTM = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.NW_FAMT_INS_PD_CTG_CD = null; } else {
      this.NW_FAMT_INS_PD_CTG_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.AT_ALTN_PY_TP_CD = null; } else {
      this.AT_ALTN_PY_TP_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.ICLO_STD_RT = null; } else {
      this.ICLO_STD_RT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.MFRC_PD_YN = null; } else {
      this.MFRC_PD_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.PY_EXEM_LRG_TOP_YN = null; } else {
      this.PY_EXEM_LRG_TOP_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.SCRN_EXPS_SQ = null; } else {
      this.SCRN_EXPS_SQ = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.SAL_BGN_TM = null; } else {
      this.SAL_BGN_TM = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.ITMGP_CD = null; } else {
      this.ITMGP_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.GRUP_PREM_AGE_STD_CD = null; } else {
      this.GRUP_PREM_AGE_STD_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.PDGP_CD = null; } else {
      this.PDGP_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.INS_ITMS_CD = null; } else {
      this.INS_ITMS_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.LNK_INDP_PD_CD = null; } else {
      this.LNK_INDP_PD_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.MBL_CLUS_ADR = null; } else {
      this.MBL_CLUS_ADR = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.MLTD_OBJ_YN = null; } else {
      this.MLTD_OBJ_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.UNT_PD_SCRN_EXPS_NM = null; } else {
      this.UNT_PD_SCRN_EXPS_NM = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.PY_EXEM_KND_TYP_DIV_CD = null; } else {
      this.PY_EXEM_KND_TYP_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.PY_EXEM_DIV_VAL = null; } else {
      this.PY_EXEM_DIV_VAL = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.FETS_PRD_CAL_DIV_CD = null; } else {
      this.FETS_PRD_CAL_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.UNT_PD_TP_CD = null; } else {
      this.UNT_PD_TP_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.BZ_IDC_PD_LCTG_NM = null; } else {
      this.BZ_IDC_PD_LCTG_NM = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.BZ_IDC_PD_MCTG_NM = null; } else {
      this.BZ_IDC_PD_MCTG_NM = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.BZ_IDC_PD_CTG_NM = null; } else {
      this.BZ_IDC_PD_CTG_NM = __cur_str;
    }

    } catch (RuntimeException e) {    throw new RuntimeException("Can't parse input data: '" + __cur_str + "'", e);    }  }

  public Object clone() throws CloneNotSupportedException {
    QueryResult o = (QueryResult) super.clone();
    o.VF_DT = (o.VF_DT != null) ? (java.sql.Timestamp) o.VF_DT.clone() : null;
    o.VT_DT = (o.VT_DT != null) ? (java.sql.Timestamp) o.VT_DT.clone() : null;
    o.PD_AUTH_DT = (o.PD_AUTH_DT != null) ? (java.sql.Timestamp) o.PD_AUTH_DT.clone() : null;
    o.PD_SAL_TMRR_SUSP_DT = (o.PD_SAL_TMRR_SUSP_DT != null) ? (java.sql.Timestamp) o.PD_SAL_TMRR_SUSP_DT.clone() : null;
    o.SAL_BGN_DT = (o.SAL_BGN_DT != null) ? (java.sql.Timestamp) o.SAL_BGN_DT.clone() : null;
    o.SAL_ED_DT = (o.SAL_ED_DT != null) ? (java.sql.Timestamp) o.SAL_ED_DT.clone() : null;
    o.REG_DT = (o.REG_DT != null) ? (java.sql.Timestamp) o.REG_DT.clone() : null;
    o.SAL_BGN_DT1 = (o.SAL_BGN_DT1 != null) ? (java.sql.Timestamp) o.SAL_BGN_DT1.clone() : null;
    o.EIH_LDG_DTM = (o.EIH_LDG_DTM != null) ? (java.sql.Timestamp) o.EIH_LDG_DTM.clone() : null;
    return o;
  }

  public void clone0(QueryResult o) throws CloneNotSupportedException {
    o.VF_DT = (o.VF_DT != null) ? (java.sql.Timestamp) o.VF_DT.clone() : null;
    o.VT_DT = (o.VT_DT != null) ? (java.sql.Timestamp) o.VT_DT.clone() : null;
    o.PD_AUTH_DT = (o.PD_AUTH_DT != null) ? (java.sql.Timestamp) o.PD_AUTH_DT.clone() : null;
    o.PD_SAL_TMRR_SUSP_DT = (o.PD_SAL_TMRR_SUSP_DT != null) ? (java.sql.Timestamp) o.PD_SAL_TMRR_SUSP_DT.clone() : null;
    o.SAL_BGN_DT = (o.SAL_BGN_DT != null) ? (java.sql.Timestamp) o.SAL_BGN_DT.clone() : null;
    o.SAL_ED_DT = (o.SAL_ED_DT != null) ? (java.sql.Timestamp) o.SAL_ED_DT.clone() : null;
    o.REG_DT = (o.REG_DT != null) ? (java.sql.Timestamp) o.REG_DT.clone() : null;
    o.SAL_BGN_DT1 = (o.SAL_BGN_DT1 != null) ? (java.sql.Timestamp) o.SAL_BGN_DT1.clone() : null;
    o.EIH_LDG_DTM = (o.EIH_LDG_DTM != null) ? (java.sql.Timestamp) o.EIH_LDG_DTM.clone() : null;
  }

  public Map<String, Object> getFieldMap() {
    Map<String, Object> __sqoop$field_map = new HashMap<String, Object>();
    __sqoop$field_map.put("UNT_PD_CD", this.UNT_PD_CD);
    __sqoop$field_map.put("VF_DT", this.VF_DT);
    __sqoop$field_map.put("VT_DT", this.VT_DT);
    __sqoop$field_map.put("UNT_PD_NM", this.UNT_PD_NM);
    __sqoop$field_map.put("UNT_PD_ABR_NM", this.UNT_PD_ABR_NM);
    __sqoop$field_map.put("UNT_PD_ENG_NM", this.UNT_PD_ENG_NM);
    __sqoop$field_map.put("UNT_PD_ENG_ABR_NM", this.UNT_PD_ENG_ABR_NM);
    __sqoop$field_map.put("PD_AUTH_DT", this.PD_AUTH_DT);
    __sqoop$field_map.put("PD_SAL_TMRR_SUSP_DT", this.PD_SAL_TMRR_SUSP_DT);
    __sqoop$field_map.put("SAL_BGN_DT", this.SAL_BGN_DT);
    __sqoop$field_map.put("SAL_ED_DT", this.SAL_ED_DT);
    __sqoop$field_map.put("INS_BGN_TM", this.INS_BGN_TM);
    __sqoop$field_map.put("INS_ED_TM", this.INS_ED_TM);
    __sqoop$field_map.put("RPS_PD_CD", this.RPS_PD_CD);
    __sqoop$field_map.put("OD_PD_CD", this.OD_PD_CD);
    __sqoop$field_map.put("INS_ITMS_DIV_CD", this.INS_ITMS_DIV_CD);
    __sqoop$field_map.put("OD_STIC_PD_CTG_CD", this.OD_STIC_PD_CTG_CD);
    __sqoop$field_map.put("NW_STIC_PD_CTG_CD", this.NW_STIC_PD_CTG_CD);
    __sqoop$field_map.put("FAMT_INS_PD_CTG_CD", this.FAMT_INS_PD_CTG_CD);
    __sqoop$field_map.put("PD_AUTH_TP_CD", this.PD_AUTH_TP_CD);
    __sqoop$field_map.put("ISP_STD_SCR", this.ISP_STD_SCR);
    __sqoop$field_map.put("GURT_SAV_DIV_CD", this.GURT_SAV_DIV_CD);
    __sqoop$field_map.put("SPC_ACCT_DIV_CD", this.SPC_ACCT_DIV_CD);
    __sqoop$field_map.put("DVND_PAY_YN", this.DVND_PAY_YN);
    __sqoop$field_map.put("BZCC_JNT_PD_YN", this.BZCC_JNT_PD_YN);
    __sqoop$field_map.put("FETS_SBC_PSB_YN", this.FETS_SBC_PSB_YN);
    __sqoop$field_map.put("ACU_GURT_SPR_YN", this.ACU_GURT_SPR_YN);
    __sqoop$field_map.put("RNWL_COV_BEIN_YN", this.RNWL_COV_BEIN_YN);
    __sqoop$field_map.put("PREM_CMPT_AGE_STD_CD", this.PREM_CMPT_AGE_STD_CD);
    __sqoop$field_map.put("HDTL_YN", this.HDTL_YN);
    __sqoop$field_map.put("ALTN_PY_TRG_DIV_CD", this.ALTN_PY_TRG_DIV_CD);
    __sqoop$field_map.put("PSTP_REVV_PSB_YN", this.PSTP_REVV_PSB_YN);
    __sqoop$field_map.put("AYTM_PY_PSB_YN", this.AYTM_PY_PSB_YN);
    __sqoop$field_map.put("FSS_DAT_OTPT_SEQ", this.FSS_DAT_OTPT_SEQ);
    __sqoop$field_map.put("SAL_PLAN_INCL_YN", this.SAL_PLAN_INCL_YN);
    __sqoop$field_map.put("PPBZ_FND_CTRB_INST_CD", this.PPBZ_FND_CTRB_INST_CD);
    __sqoop$field_map.put("PBPF_BZ_FND_CTRB_RT", this.PBPF_BZ_FND_CTRB_RT);
    __sqoop$field_map.put("APL_PREM_RDDW_UNT_CD", this.APL_PREM_RDDW_UNT_CD);
    __sqoop$field_map.put("PD_MNDC_ISS_YN", this.PD_MNDC_ISS_YN);
    __sqoop$field_map.put("ADJT_PSB_YN", this.ADJT_PSB_YN);
    __sqoop$field_map.put("INDV_CRP_DIV_CD", this.INDV_CRP_DIV_CD);
    __sqoop$field_map.put("GRUP_TRT_YN", this.GRUP_TRT_YN);
    __sqoop$field_map.put("SMNS_POL_PSB_YN", this.SMNS_POL_PSB_YN);
    __sqoop$field_map.put("GIRO_ISS_PSB_YN", this.GIRO_ISS_PSB_YN);
    __sqoop$field_map.put("PLR_STUP_PSB_YN", this.PLR_STUP_PSB_YN);
    __sqoop$field_map.put("HNDY_DSG_PSB_YN", this.HNDY_DSG_PSB_YN);
    __sqoop$field_map.put("CLOG_DPC_INP_YN", this.CLOG_DPC_INP_YN);
    __sqoop$field_map.put("KORE_PD_CD", this.KORE_PD_CD);
    __sqoop$field_map.put("CLUS_DIV_CD", this.CLUS_DIV_CD);
    __sqoop$field_map.put("LGTM_CTR_CR_XTR_MD_CD", this.LGTM_CTR_CR_XTR_MD_CD);
    __sqoop$field_map.put("IPY_PSB_YN", this.IPY_PSB_YN);
    __sqoop$field_map.put("SRP_APL_TRG_YN", this.SRP_APL_TRG_YN);
    __sqoop$field_map.put("INCM_DDC_TRG_YN", this.INCM_DDC_TRG_YN);
    __sqoop$field_map.put("HSEC_DIV_CD", this.HSEC_DIV_CD);
    __sqoop$field_map.put("SECT_INS_DIV_CD", this.SECT_INS_DIV_CD);
    __sqoop$field_map.put("PVCTR_ALLW_YN", this.PVCTR_ALLW_YN);
    __sqoop$field_map.put("IPY_LPS_PRD_DIV_CD", this.IPY_LPS_PRD_DIV_CD);
    __sqoop$field_map.put("IPY_PPN_PRD_DIV_CD", this.IPY_PPN_PRD_DIV_CD);
    __sqoop$field_map.put("NCLAM_BNS_EN", this.NCLAM_BNS_EN);
    __sqoop$field_map.put("RVW_ITMS_CRSS_PD_YN", this.RVW_ITMS_CRSS_PD_YN);
    __sqoop$field_map.put("PRPY_PSB_TP_CD", this.PRPY_PSB_TP_CD);
    __sqoop$field_map.put("LANN_DIV_CD", this.LANN_DIV_CD);
    __sqoop$field_map.put("PD_GRP_CD", this.PD_GRP_CD);
    __sqoop$field_map.put("CNCLL_DDC_AMT_SBTR_YN", this.CNCLL_DDC_AMT_SBTR_YN);
    __sqoop$field_map.put("CNCLL_DDC_YR_NUM", this.CNCLL_DDC_YR_NUM);
    __sqoop$field_map.put("XPT_INTR", this.XPT_INTR);
    __sqoop$field_map.put("BNCA_YN", this.BNCA_YN);
    __sqoop$field_map.put("MID_AMT_PAY_YN", this.MID_AMT_PAY_YN);
    __sqoop$field_map.put("HFWY_WDR_YN", this.HFWY_WDR_YN);
    __sqoop$field_map.put("LNK_PD_CD", this.LNK_PD_CD);
    __sqoop$field_map.put("APL_PD_CD", this.APL_PD_CD);
    __sqoop$field_map.put("RPT_PD_CD", this.RPT_PD_CD);
    __sqoop$field_map.put("RPT_PD_NM", this.RPT_PD_NM);
    __sqoop$field_map.put("RMK_CON", this.RMK_CON);
    __sqoop$field_map.put("BZPLN_PD_CTG_CD", this.BZPLN_PD_CTG_CD);
    __sqoop$field_map.put("ITGR_PD_YN", this.ITGR_PD_YN);
    __sqoop$field_map.put("EXPR_RFD_APL_DIV_CD", this.EXPR_RFD_APL_DIV_CD);
    __sqoop$field_map.put("SLZ_PD_DIV_CD", this.SLZ_PD_DIV_CD);
    __sqoop$field_map.put("ANN_DIV_CD", this.ANN_DIV_CD);
    __sqoop$field_map.put("ANN_CAL_TP_CD", this.ANN_CAL_TP_CD);
    __sqoop$field_map.put("PRPY_DC_APL_PREM_CD", this.PRPY_DC_APL_PREM_CD);
    __sqoop$field_map.put("HFWY_WDR_RFD_STD_CON", this.HFWY_WDR_RFD_STD_CON);
    __sqoop$field_map.put("CI_PD_YN", this.CI_PD_YN);
    __sqoop$field_map.put("REGPE_NM", this.REGPE_NM);
    __sqoop$field_map.put("REG_DT", this.REG_DT);
    __sqoop$field_map.put("MME_RPT_PD_CD", this.MME_RPT_PD_CD);
    __sqoop$field_map.put("MME_RPT_PD_CD_NM", this.MME_RPT_PD_CD_NM);
    __sqoop$field_map.put("AYTM_PY_LM_AMT_DIV_CD", this.AYTM_PY_LM_AMT_DIV_CD);
    __sqoop$field_map.put("ICLO_PSB_YN", this.ICLO_PSB_YN);
    __sqoop$field_map.put("UNT_PD_SAL_NM", this.UNT_PD_SAL_NM);
    __sqoop$field_map.put("ISP_PD_CTG_CD", this.ISP_PD_CTG_CD);
    __sqoop$field_map.put("LGTM_INDV_GRUP_DIV_CD", this.LGTM_INDV_GRUP_DIV_CD);
    __sqoop$field_map.put("KIDI_PD_CD", this.KIDI_PD_CD);
    __sqoop$field_map.put("PRDY_AMT_PD_GRP_CD", this.PRDY_AMT_PD_GRP_CD);
    __sqoop$field_map.put("STND_INTR", this.STND_INTR);
    __sqoop$field_map.put("MDF_RT_APL_DIV_CD", this.MDF_RT_APL_DIV_CD);
    __sqoop$field_map.put("INDP_SIC_PD_YN", this.INDP_SIC_PD_YN);
    __sqoop$field_map.put("CKUP_TRG_PD_YN", this.CKUP_TRG_PD_YN);
    __sqoop$field_map.put("POL_OTPT_WY_DIV_CD", this.POL_OTPT_WY_DIV_CD);
    __sqoop$field_map.put("SAL_BGN_DT1", this.SAL_BGN_DT1);
    __sqoop$field_map.put("NW_KIDI_PD_CD", this.NW_KIDI_PD_CD);
    __sqoop$field_map.put("STIC_IDC_PD_CTG_CD", this.STIC_IDC_PD_CTG_CD);
    __sqoop$field_map.put("QRCD_ADR", this.QRCD_ADR);
    __sqoop$field_map.put("AVG_PBAN_INTR", this.AVG_PBAN_INTR);
    __sqoop$field_map.put("EIH_LDG_DTM", this.EIH_LDG_DTM);
    __sqoop$field_map.put("NW_FAMT_INS_PD_CTG_CD", this.NW_FAMT_INS_PD_CTG_CD);
    __sqoop$field_map.put("AT_ALTN_PY_TP_CD", this.AT_ALTN_PY_TP_CD);
    __sqoop$field_map.put("ICLO_STD_RT", this.ICLO_STD_RT);
    __sqoop$field_map.put("MFRC_PD_YN", this.MFRC_PD_YN);
    __sqoop$field_map.put("PY_EXEM_LRG_TOP_YN", this.PY_EXEM_LRG_TOP_YN);
    __sqoop$field_map.put("SCRN_EXPS_SQ", this.SCRN_EXPS_SQ);
    __sqoop$field_map.put("SAL_BGN_TM", this.SAL_BGN_TM);
    __sqoop$field_map.put("ITMGP_CD", this.ITMGP_CD);
    __sqoop$field_map.put("GRUP_PREM_AGE_STD_CD", this.GRUP_PREM_AGE_STD_CD);
    __sqoop$field_map.put("PDGP_CD", this.PDGP_CD);
    __sqoop$field_map.put("INS_ITMS_CD", this.INS_ITMS_CD);
    __sqoop$field_map.put("LNK_INDP_PD_CD", this.LNK_INDP_PD_CD);
    __sqoop$field_map.put("MBL_CLUS_ADR", this.MBL_CLUS_ADR);
    __sqoop$field_map.put("MLTD_OBJ_YN", this.MLTD_OBJ_YN);
    __sqoop$field_map.put("UNT_PD_SCRN_EXPS_NM", this.UNT_PD_SCRN_EXPS_NM);
    __sqoop$field_map.put("PY_EXEM_KND_TYP_DIV_CD", this.PY_EXEM_KND_TYP_DIV_CD);
    __sqoop$field_map.put("PY_EXEM_DIV_VAL", this.PY_EXEM_DIV_VAL);
    __sqoop$field_map.put("FETS_PRD_CAL_DIV_CD", this.FETS_PRD_CAL_DIV_CD);
    __sqoop$field_map.put("UNT_PD_TP_CD", this.UNT_PD_TP_CD);
    __sqoop$field_map.put("BZ_IDC_PD_LCTG_NM", this.BZ_IDC_PD_LCTG_NM);
    __sqoop$field_map.put("BZ_IDC_PD_MCTG_NM", this.BZ_IDC_PD_MCTG_NM);
    __sqoop$field_map.put("BZ_IDC_PD_CTG_NM", this.BZ_IDC_PD_CTG_NM);
    return __sqoop$field_map;
  }

  public void getFieldMap0(Map<String, Object> __sqoop$field_map) {
    __sqoop$field_map.put("UNT_PD_CD", this.UNT_PD_CD);
    __sqoop$field_map.put("VF_DT", this.VF_DT);
    __sqoop$field_map.put("VT_DT", this.VT_DT);
    __sqoop$field_map.put("UNT_PD_NM", this.UNT_PD_NM);
    __sqoop$field_map.put("UNT_PD_ABR_NM", this.UNT_PD_ABR_NM);
    __sqoop$field_map.put("UNT_PD_ENG_NM", this.UNT_PD_ENG_NM);
    __sqoop$field_map.put("UNT_PD_ENG_ABR_NM", this.UNT_PD_ENG_ABR_NM);
    __sqoop$field_map.put("PD_AUTH_DT", this.PD_AUTH_DT);
    __sqoop$field_map.put("PD_SAL_TMRR_SUSP_DT", this.PD_SAL_TMRR_SUSP_DT);
    __sqoop$field_map.put("SAL_BGN_DT", this.SAL_BGN_DT);
    __sqoop$field_map.put("SAL_ED_DT", this.SAL_ED_DT);
    __sqoop$field_map.put("INS_BGN_TM", this.INS_BGN_TM);
    __sqoop$field_map.put("INS_ED_TM", this.INS_ED_TM);
    __sqoop$field_map.put("RPS_PD_CD", this.RPS_PD_CD);
    __sqoop$field_map.put("OD_PD_CD", this.OD_PD_CD);
    __sqoop$field_map.put("INS_ITMS_DIV_CD", this.INS_ITMS_DIV_CD);
    __sqoop$field_map.put("OD_STIC_PD_CTG_CD", this.OD_STIC_PD_CTG_CD);
    __sqoop$field_map.put("NW_STIC_PD_CTG_CD", this.NW_STIC_PD_CTG_CD);
    __sqoop$field_map.put("FAMT_INS_PD_CTG_CD", this.FAMT_INS_PD_CTG_CD);
    __sqoop$field_map.put("PD_AUTH_TP_CD", this.PD_AUTH_TP_CD);
    __sqoop$field_map.put("ISP_STD_SCR", this.ISP_STD_SCR);
    __sqoop$field_map.put("GURT_SAV_DIV_CD", this.GURT_SAV_DIV_CD);
    __sqoop$field_map.put("SPC_ACCT_DIV_CD", this.SPC_ACCT_DIV_CD);
    __sqoop$field_map.put("DVND_PAY_YN", this.DVND_PAY_YN);
    __sqoop$field_map.put("BZCC_JNT_PD_YN", this.BZCC_JNT_PD_YN);
    __sqoop$field_map.put("FETS_SBC_PSB_YN", this.FETS_SBC_PSB_YN);
    __sqoop$field_map.put("ACU_GURT_SPR_YN", this.ACU_GURT_SPR_YN);
    __sqoop$field_map.put("RNWL_COV_BEIN_YN", this.RNWL_COV_BEIN_YN);
    __sqoop$field_map.put("PREM_CMPT_AGE_STD_CD", this.PREM_CMPT_AGE_STD_CD);
    __sqoop$field_map.put("HDTL_YN", this.HDTL_YN);
    __sqoop$field_map.put("ALTN_PY_TRG_DIV_CD", this.ALTN_PY_TRG_DIV_CD);
    __sqoop$field_map.put("PSTP_REVV_PSB_YN", this.PSTP_REVV_PSB_YN);
    __sqoop$field_map.put("AYTM_PY_PSB_YN", this.AYTM_PY_PSB_YN);
    __sqoop$field_map.put("FSS_DAT_OTPT_SEQ", this.FSS_DAT_OTPT_SEQ);
    __sqoop$field_map.put("SAL_PLAN_INCL_YN", this.SAL_PLAN_INCL_YN);
    __sqoop$field_map.put("PPBZ_FND_CTRB_INST_CD", this.PPBZ_FND_CTRB_INST_CD);
    __sqoop$field_map.put("PBPF_BZ_FND_CTRB_RT", this.PBPF_BZ_FND_CTRB_RT);
    __sqoop$field_map.put("APL_PREM_RDDW_UNT_CD", this.APL_PREM_RDDW_UNT_CD);
    __sqoop$field_map.put("PD_MNDC_ISS_YN", this.PD_MNDC_ISS_YN);
    __sqoop$field_map.put("ADJT_PSB_YN", this.ADJT_PSB_YN);
    __sqoop$field_map.put("INDV_CRP_DIV_CD", this.INDV_CRP_DIV_CD);
    __sqoop$field_map.put("GRUP_TRT_YN", this.GRUP_TRT_YN);
    __sqoop$field_map.put("SMNS_POL_PSB_YN", this.SMNS_POL_PSB_YN);
    __sqoop$field_map.put("GIRO_ISS_PSB_YN", this.GIRO_ISS_PSB_YN);
    __sqoop$field_map.put("PLR_STUP_PSB_YN", this.PLR_STUP_PSB_YN);
    __sqoop$field_map.put("HNDY_DSG_PSB_YN", this.HNDY_DSG_PSB_YN);
    __sqoop$field_map.put("CLOG_DPC_INP_YN", this.CLOG_DPC_INP_YN);
    __sqoop$field_map.put("KORE_PD_CD", this.KORE_PD_CD);
    __sqoop$field_map.put("CLUS_DIV_CD", this.CLUS_DIV_CD);
    __sqoop$field_map.put("LGTM_CTR_CR_XTR_MD_CD", this.LGTM_CTR_CR_XTR_MD_CD);
    __sqoop$field_map.put("IPY_PSB_YN", this.IPY_PSB_YN);
    __sqoop$field_map.put("SRP_APL_TRG_YN", this.SRP_APL_TRG_YN);
    __sqoop$field_map.put("INCM_DDC_TRG_YN", this.INCM_DDC_TRG_YN);
    __sqoop$field_map.put("HSEC_DIV_CD", this.HSEC_DIV_CD);
    __sqoop$field_map.put("SECT_INS_DIV_CD", this.SECT_INS_DIV_CD);
    __sqoop$field_map.put("PVCTR_ALLW_YN", this.PVCTR_ALLW_YN);
    __sqoop$field_map.put("IPY_LPS_PRD_DIV_CD", this.IPY_LPS_PRD_DIV_CD);
    __sqoop$field_map.put("IPY_PPN_PRD_DIV_CD", this.IPY_PPN_PRD_DIV_CD);
    __sqoop$field_map.put("NCLAM_BNS_EN", this.NCLAM_BNS_EN);
    __sqoop$field_map.put("RVW_ITMS_CRSS_PD_YN", this.RVW_ITMS_CRSS_PD_YN);
    __sqoop$field_map.put("PRPY_PSB_TP_CD", this.PRPY_PSB_TP_CD);
    __sqoop$field_map.put("LANN_DIV_CD", this.LANN_DIV_CD);
    __sqoop$field_map.put("PD_GRP_CD", this.PD_GRP_CD);
    __sqoop$field_map.put("CNCLL_DDC_AMT_SBTR_YN", this.CNCLL_DDC_AMT_SBTR_YN);
    __sqoop$field_map.put("CNCLL_DDC_YR_NUM", this.CNCLL_DDC_YR_NUM);
    __sqoop$field_map.put("XPT_INTR", this.XPT_INTR);
    __sqoop$field_map.put("BNCA_YN", this.BNCA_YN);
    __sqoop$field_map.put("MID_AMT_PAY_YN", this.MID_AMT_PAY_YN);
    __sqoop$field_map.put("HFWY_WDR_YN", this.HFWY_WDR_YN);
    __sqoop$field_map.put("LNK_PD_CD", this.LNK_PD_CD);
    __sqoop$field_map.put("APL_PD_CD", this.APL_PD_CD);
    __sqoop$field_map.put("RPT_PD_CD", this.RPT_PD_CD);
    __sqoop$field_map.put("RPT_PD_NM", this.RPT_PD_NM);
    __sqoop$field_map.put("RMK_CON", this.RMK_CON);
    __sqoop$field_map.put("BZPLN_PD_CTG_CD", this.BZPLN_PD_CTG_CD);
    __sqoop$field_map.put("ITGR_PD_YN", this.ITGR_PD_YN);
    __sqoop$field_map.put("EXPR_RFD_APL_DIV_CD", this.EXPR_RFD_APL_DIV_CD);
    __sqoop$field_map.put("SLZ_PD_DIV_CD", this.SLZ_PD_DIV_CD);
    __sqoop$field_map.put("ANN_DIV_CD", this.ANN_DIV_CD);
    __sqoop$field_map.put("ANN_CAL_TP_CD", this.ANN_CAL_TP_CD);
    __sqoop$field_map.put("PRPY_DC_APL_PREM_CD", this.PRPY_DC_APL_PREM_CD);
    __sqoop$field_map.put("HFWY_WDR_RFD_STD_CON", this.HFWY_WDR_RFD_STD_CON);
    __sqoop$field_map.put("CI_PD_YN", this.CI_PD_YN);
    __sqoop$field_map.put("REGPE_NM", this.REGPE_NM);
    __sqoop$field_map.put("REG_DT", this.REG_DT);
    __sqoop$field_map.put("MME_RPT_PD_CD", this.MME_RPT_PD_CD);
    __sqoop$field_map.put("MME_RPT_PD_CD_NM", this.MME_RPT_PD_CD_NM);
    __sqoop$field_map.put("AYTM_PY_LM_AMT_DIV_CD", this.AYTM_PY_LM_AMT_DIV_CD);
    __sqoop$field_map.put("ICLO_PSB_YN", this.ICLO_PSB_YN);
    __sqoop$field_map.put("UNT_PD_SAL_NM", this.UNT_PD_SAL_NM);
    __sqoop$field_map.put("ISP_PD_CTG_CD", this.ISP_PD_CTG_CD);
    __sqoop$field_map.put("LGTM_INDV_GRUP_DIV_CD", this.LGTM_INDV_GRUP_DIV_CD);
    __sqoop$field_map.put("KIDI_PD_CD", this.KIDI_PD_CD);
    __sqoop$field_map.put("PRDY_AMT_PD_GRP_CD", this.PRDY_AMT_PD_GRP_CD);
    __sqoop$field_map.put("STND_INTR", this.STND_INTR);
    __sqoop$field_map.put("MDF_RT_APL_DIV_CD", this.MDF_RT_APL_DIV_CD);
    __sqoop$field_map.put("INDP_SIC_PD_YN", this.INDP_SIC_PD_YN);
    __sqoop$field_map.put("CKUP_TRG_PD_YN", this.CKUP_TRG_PD_YN);
    __sqoop$field_map.put("POL_OTPT_WY_DIV_CD", this.POL_OTPT_WY_DIV_CD);
    __sqoop$field_map.put("SAL_BGN_DT1", this.SAL_BGN_DT1);
    __sqoop$field_map.put("NW_KIDI_PD_CD", this.NW_KIDI_PD_CD);
    __sqoop$field_map.put("STIC_IDC_PD_CTG_CD", this.STIC_IDC_PD_CTG_CD);
    __sqoop$field_map.put("QRCD_ADR", this.QRCD_ADR);
    __sqoop$field_map.put("AVG_PBAN_INTR", this.AVG_PBAN_INTR);
    __sqoop$field_map.put("EIH_LDG_DTM", this.EIH_LDG_DTM);
    __sqoop$field_map.put("NW_FAMT_INS_PD_CTG_CD", this.NW_FAMT_INS_PD_CTG_CD);
    __sqoop$field_map.put("AT_ALTN_PY_TP_CD", this.AT_ALTN_PY_TP_CD);
    __sqoop$field_map.put("ICLO_STD_RT", this.ICLO_STD_RT);
    __sqoop$field_map.put("MFRC_PD_YN", this.MFRC_PD_YN);
    __sqoop$field_map.put("PY_EXEM_LRG_TOP_YN", this.PY_EXEM_LRG_TOP_YN);
    __sqoop$field_map.put("SCRN_EXPS_SQ", this.SCRN_EXPS_SQ);
    __sqoop$field_map.put("SAL_BGN_TM", this.SAL_BGN_TM);
    __sqoop$field_map.put("ITMGP_CD", this.ITMGP_CD);
    __sqoop$field_map.put("GRUP_PREM_AGE_STD_CD", this.GRUP_PREM_AGE_STD_CD);
    __sqoop$field_map.put("PDGP_CD", this.PDGP_CD);
    __sqoop$field_map.put("INS_ITMS_CD", this.INS_ITMS_CD);
    __sqoop$field_map.put("LNK_INDP_PD_CD", this.LNK_INDP_PD_CD);
    __sqoop$field_map.put("MBL_CLUS_ADR", this.MBL_CLUS_ADR);
    __sqoop$field_map.put("MLTD_OBJ_YN", this.MLTD_OBJ_YN);
    __sqoop$field_map.put("UNT_PD_SCRN_EXPS_NM", this.UNT_PD_SCRN_EXPS_NM);
    __sqoop$field_map.put("PY_EXEM_KND_TYP_DIV_CD", this.PY_EXEM_KND_TYP_DIV_CD);
    __sqoop$field_map.put("PY_EXEM_DIV_VAL", this.PY_EXEM_DIV_VAL);
    __sqoop$field_map.put("FETS_PRD_CAL_DIV_CD", this.FETS_PRD_CAL_DIV_CD);
    __sqoop$field_map.put("UNT_PD_TP_CD", this.UNT_PD_TP_CD);
    __sqoop$field_map.put("BZ_IDC_PD_LCTG_NM", this.BZ_IDC_PD_LCTG_NM);
    __sqoop$field_map.put("BZ_IDC_PD_MCTG_NM", this.BZ_IDC_PD_MCTG_NM);
    __sqoop$field_map.put("BZ_IDC_PD_CTG_NM", this.BZ_IDC_PD_CTG_NM);
  }

  public void setField(String __fieldName, Object __fieldVal) {
    if (!setters.containsKey(__fieldName)) {
      throw new RuntimeException("No such field:"+__fieldName);
    }
    setters.get(__fieldName).setField(__fieldVal);
  }

}
