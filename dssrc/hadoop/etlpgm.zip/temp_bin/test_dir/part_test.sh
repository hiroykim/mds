#!/bin/bash

#/usr/bin/hive -e "create external table ykhong_part_test1 like last_thddh_vpduntpd PARTITIONED BY (ins_itms_div_cd int);"
#/usr/bin/hive -e "create external table ykhong_part_test1 PARTITIONED BY (ins_itms_div_cd int) like last_thddh_vpduntpd;"
#/usr/bin/hive -e "create external table ykhong_part_test1 like last_thddh_vpduntpd;"
#/usr/bin/hive -e "insert overwrite table ykhong_part_test1 partition (ins_itms_div_cd) select * from last_thddh_vpduntpd where ins_itms_div_cd is not null;"

#/usr/bin/hive -e "drop table ykhong_part_test1"
#hdfs dfs -rm -r -f /warehouse/tablespace/external/hive/ykhong_part_test1


#/usr/bin/hive -e "create external table ykhong_part_test 
#	partitioned by (ins_itms_div_cd int) 
#	stored as parquet tblproperties('PARQUET.COMPRESS'='SNAPPY') 
#	as select * from last_thddh_vpduntpd;"

#/usr/bin/hive -e "create external table ykhong_part_test1(unt_pd_cd String, rps_pd_cd String) PARTITIONED BY (ins_itms_div_cd int) stored as parquet tblproperties('parquet.compress'='snappy');"
/usr/bin/hive -e "insert overwrite table ykhong_part_test1 partition (ins_itms_div_cd) select unt_pd_cd, rps_pd_cd, ins_itms_div_cd from last_thddh_vpduntpd;"
