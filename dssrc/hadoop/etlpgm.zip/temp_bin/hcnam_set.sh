#!/bin/bash

/sqoopbin/scripts/etlpgm/bin/THDDH_TCTTCOT.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TCTTCOTPTY.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TCTTCOTOBJ.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TCTTCOTORG.sh
/sqoopbin/scripts/etlpgm/bin/THDDH_TCTUW.sh
/sqoopbin/scripts/etlpgm/bin/TMLDB_ICPSISPQRY.sh

echo "end" >> /sqoopbin/scripts/etlpgm/flow_log/temp_log.txt
