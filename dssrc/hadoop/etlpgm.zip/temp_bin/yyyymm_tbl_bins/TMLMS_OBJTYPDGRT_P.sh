#!/bin/bash

if [ $# -eq 0 ]
then           
    ARGS=N    
else           
    ARGS=$1
fi             

NOW=$(date +"+%Y-%m-%d_%T")
SHLOG_DIR=/sqoopbin/scripts/etlpgm/cur_log
HISLOG_DIR=/sqoopbin/scripts/etlpgm/his_log

export HADOOP_OPTS=-Djava.security.egd=file:/dev/../dev/urandom
export ORACLE_BASE=/sw/oracle
export ORACLE_HOME=/sw/oracle/product/11.2.0.4/client_1
export LD_LIBRARY_PATH=/sw/oracle/product/11.2.0.4/client_1/lib:/sw/oracle/product/11.2.0.4/client_1/lib:
export PATH=/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/usr/hdp/3.0.0.0-1634/spark2/bin/:/var/opt/node/bin/:/opt/maven/bin:/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/usr/lib64/qt-3.3/bin:/var/opt/node/bin/:/usr/hdp/3.0.0.0-1634/spark2/bin/:/opt/maven/bin:/usr/local/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/home/hdpapp/.local/bin:/home/hdpapp/bin
export TNS_ADMIN=/sw/oracle/product/11.2.0.4/client_1/network/admin
export ORACLE_SID=DBEDWP2
export NLS_LANG=American_America.KO16MSWIN949

#----------------------------------------------------#
# 작업내용 : TMLMS_OBJTYPDGRT 테이블 sqoop 복제 작업
# 작업주기 : M 
#----------------------------------------------------#

    echo " "
    echo "*-----------[ TMLMS_OBJTYPDGRT.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ TMLMS_OBJTYPDGRT.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`  >  ${SHLOG_DIR}/TMLMS_OBJTYPDGRT.shlog

PART=$1

#----------------------------------------------------#
# 테이블별 일변경 데이터를 받아 오는 부분
#----------------------------------------------------#
    /usr/bin/hadoop fs -rm -r -f  /tmp2/STG_TMLMS_OBJTYPDGRT  >> ${SHLOG_DIR}/TMLMS_OBJTYPDGRT.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.STG_TMLMS_OBJTYPDGRT ; " >> ${SHLOG_DIR}/TMLMS_OBJTYPDGRT.shlog 2>&1 &&
    /usr/hdp/3.0.0.0-1634/sqoop/bin/sqoop import -D mapred.child.java.opts="-Djava.security.egd=file:/dev/../dev/urandom" -Dorg.apache.sqoop.splitter.allow_text_splitter=true \
    --connect jdbc:oracle:thin:EDWHADOOP/wjdqhrP\!23@10.91.41.172:12560:DBEDWP2 \
    --username  EDWHADOOP \
    --password wjdqhrP\!23 \
    --query "SELECT /*+ FULL(TMLMS_OBJTYPDGRT) */  REPLACE(REPLACE(CLOG_YYMM,CHR(13),''),CHR(10),'') CLOG_YYMM
, REPLACE(REPLACE(POL_NO,CHR(13),''),CHR(10),'') POL_NO
, REPLACE(REPLACE(CTR_ID,CHR(13),''),CHR(10),'') CTR_ID
, REPLACE(REPLACE(CTR_OBJ_ID,CHR(13),''),CHR(10),'') CTR_OBJ_ID
, REPLACE(REPLACE(CTR_COV_ID,CHR(13),''),CHR(10),'') CTR_COV_ID
, REPLACE(REPLACE(OBJ_ID,CHR(13),''),CHR(10),'') OBJ_ID
, REPLACE(REPLACE(COV_CD,CHR(13),''),CHR(10),'') COV_CD
, REPLACE(REPLACE(COV_NM,CHR(13),''),CHR(10),'') COV_NM
, REPLACE(REPLACE(PD_COV_NM,CHR(13),''),CHR(10),'') PD_COV_NM
, REPLACE(REPLACE(UNT_PD_CD,CHR(13),''),CHR(10),'') UNT_PD_CD
, REPLACE(REPLACE(UNT_PD_NM,CHR(13),''),CHR(10),'') UNT_PD_NM
, REPLACE(REPLACE(RPS_PD_CD,CHR(13),''),CHR(10),'') RPS_PD_CD
, REPLACE(REPLACE(RPS_PD_NM,CHR(13),''),CHR(10),'') RPS_PD_NM
, REPLACE(REPLACE(SAL_PD_CD,CHR(13),''),CHR(10),'') SAL_PD_CD
, REPLACE(REPLACE(SAL_PD_NM,CHR(13),''),CHR(10),'') SAL_PD_NM
, REPLACE(REPLACE(OD_STIC_PD_CTG_CD,CHR(13),''),CHR(10),'') OD_STIC_PD_CTG_CD
, REPLACE(REPLACE(NW_STIC_PD_CTG_CD,CHR(13),''),CHR(10),'') NW_STIC_PD_CTG_CD
, REPLACE(REPLACE(GURT_SAV_DIV_CD,CHR(13),''),CHR(10),'') GURT_SAV_DIV_CD
, SBCP_DT
, REPLACE(REPLACE(CTR_STAT_CD,CHR(13),''),CHR(10),'') CTR_STAT_CD
, REPLACE(REPLACE(CTR_STAT_DTL_CD,CHR(13),''),CHR(10),'') CTR_STAT_DTL_CD
, INS_BGN_DT
, INS_ED_DT
, REPLACE(REPLACE(PY_CYC_CD,CHR(13),''),CHR(10),'') PY_CYC_CD
, REPLACE(REPLACE(INS_PRD_TP_CD,CHR(13),''),CHR(10),'') INS_PRD_TP_CD
, REPLACE(REPLACE(PY_PRD_TP_CD,CHR(13),''),CHR(10),'') PY_PRD_TP_CD
, INS_PRD
, PY_PRD
, REPLACE(REPLACE(OWN_CTR_YN,CHR(13),''),CHR(10),'') OWN_CTR_YN
, LAST_ENDR_HIS_STD_NO
, REPLACE(REPLACE(SBCP_CHN_DIV_CD,CHR(13),''),CHR(10),'') SBCP_CHN_DIV_CD
, REPLACE(REPLACE(SAL_CHN_DIV_CD,CHR(13),''),CHR(10),'') SAL_CHN_DIV_CD
, REPLACE(REPLACE(ISP_TP_DIV_CD,CHR(13),''),CHR(10),'') ISP_TP_DIV_CD
, REPLACE(REPLACE(OBJ_TP_CD,CHR(13),''),CHR(10),'') OBJ_TP_CD
, REPLACE(REPLACE(OBJ_DIV_CD,CHR(13),''),CHR(10),'') OBJ_DIV_CD
, REPLACE(REPLACE(OPN_JBCL_CD,CHR(13),''),CHR(10),'') OPN_JBCL_CD
, REPLACE(REPLACE(OPJB_NM,CHR(13),''),CHR(10),'') OPJB_NM
, REPLACE(REPLACE(TNG_DIV_CD,CHR(13),''),CHR(10),'') TNG_DIV_CD
, REPLACE(REPLACE(OBJ_GRD_CD,CHR(13),''),CHR(10),'') OBJ_GRD_CD
, REPLACE(REPLACE(INSPE_DIV_CD,CHR(13),''),CHR(10),'') INSPE_DIV_CD
, REPLACE(REPLACE(INSPE_CUS_NO,CHR(13),''),CHR(10),'') INSPE_CUS_NO
, REPLACE(REPLACE(INSPE_JOB_CD,CHR(13),''),CHR(10),'') INSPE_JOB_CD
, REPLACE(REPLACE(INSPE_JOB_GRD_CD,CHR(13),''),CHR(10),'') INSPE_JOB_GRD_CD
, REPLACE(REPLACE(INSPE_GNDR_CD,CHR(13),''),CHR(10),'') INSPE_GNDR_CD
, INSPE_INS_AGE
, REPLACE(REPLACE(INSPE_NATL_CD,CHR(13),''),CHR(10),'') INSPE_NATL_CD
, REPLACE(REPLACE(INSPE_STAY_QUAL_KD_CD,CHR(13),''),CHR(10),'') INSPE_STAY_QUAL_KD_CD
, REPLACE(REPLACE(INSPE_FETS_YN,CHR(13),''),CHR(10),'') INSPE_FETS_YN
, REPLACE(REPLACE(MFETS_YN,CHR(13),''),CHR(10),'') MFETS_YN
, REPLACE(REPLACE(PLAN_CD,CHR(13),''),CHR(10),'') PLAN_CD
, REPLACE(REPLACE(PLAN_GRP_DIV_CD,CHR(13),''),CHR(10),'') PLAN_GRP_DIV_CD
, REPLACE(REPLACE(PLAN_NM,CHR(13),''),CHR(10),'') PLAN_NM
, REPLACE(REPLACE(DMG_RT_COV_LCTG_CD,CHR(13),''),CHR(10),'') DMG_RT_COV_LCTG_CD
, REPLACE(REPLACE(DMG_RT_COV_MCTG_CD,CHR(13),''),CHR(10),'') DMG_RT_COV_MCTG_CD
, REPLACE(REPLACE(DMG_RT_COV_SCTG_CD,CHR(13),''),CHR(10),'') DMG_RT_COV_SCTG_CD
, REPLACE(REPLACE(DMG_RT_COV_DCTG_CD,CHR(13),''),CHR(10),'') DMG_RT_COV_DCTG_CD
, REPLACE(REPLACE(ACCM_COV_CON,CHR(13),''),CHR(10),'') ACCM_COV_CON
, ACCM_COMS_MLTP
, REPLACE(REPLACE(BAS_SIC_DIV_CD,CHR(13),''),CHR(10),'') BAS_SIC_DIV_CD
, REPLACE(REPLACE(CTR_COV_STAT_CD,CHR(13),''),CHR(10),'') CTR_COV_STAT_CD
, REPLACE(REPLACE(CTR_COV_STAT_DTL_CD,CHR(13),''),CHR(10),'') CTR_COV_STAT_DTL_CD
, REPLACE(REPLACE(COV_INS_PRD_TP_CD,CHR(13),''),CHR(10),'') COV_INS_PRD_TP_CD
, REPLACE(REPLACE(COV_PY_PRD_TP_CD,CHR(13),''),CHR(10),'') COV_PY_PRD_TP_CD
, COV_INS_PRD
, COV_PY_PRD
, COV_INS_BGN_DT
, COV_INS_ED_DT
, COV_BAS_PREM
, COV_APL_PREM
, COV_INSD_AMT
, REPLACE(REPLACE(XCHG_RDU_DIV_CD,CHR(13),''),CHR(10),'') XCHG_RDU_DIV_CD
, REPLACE(REPLACE(RNWL_CYC_DIV_CD,CHR(13),''),CHR(10),'') RNWL_CYC_DIV_CD
, REPLACE(REPLACE(ALMEXP_STDTN_YN,CHR(13),''),CHR(10),'') ALMEXP_STDTN_YN
, REPLACE(REPLACE(CLLPE_ORG_CD,CHR(13),''),CHR(10),'') CLLPE_ORG_CD
, REPLACE(REPLACE(CLLPE_ORG_NM,CHR(13),''),CHR(10),'') CLLPE_ORG_NM
, REPLACE(REPLACE(CLLPE_ORG_ID,CHR(13),''),CHR(10),'') CLLPE_ORG_ID
, REPLACE(REPLACE(CLLPE_CUS_ID,CHR(13),''),CHR(10),'') CLLPE_CUS_ID
, REPLACE(REPLACE(RCRT_AGPLR_ORG_CD,CHR(13),''),CHR(10),'') RCRT_AGPLR_ORG_CD
, REPLACE(REPLACE(RCRT_AGPLR_ORG_NM,CHR(13),''),CHR(10),'') RCRT_AGPLR_ORG_NM
, REPLACE(REPLACE(RCRT_AGPLR_ORG_ID,CHR(13),''),CHR(10),'') RCRT_AGPLR_ORG_ID
, REPLACE(REPLACE(RCRT_AGPLR_CUS_ID,CHR(13),''),CHR(10),'') RCRT_AGPLR_CUS_ID
, REPLACE(REPLACE(TRTPE_ORG_CD,CHR(13),''),CHR(10),'') TRTPE_ORG_CD
, REPLACE(REPLACE(TRTPE_ORG_NM,CHR(13),''),CHR(10),'') TRTPE_ORG_NM
, REPLACE(REPLACE(TRTPE_ORG_ID,CHR(13),''),CHR(10),'') TRTPE_ORG_ID
, REPLACE(REPLACE(TRTPE_CUS_ID,CHR(13),''),CHR(10),'') TRTPE_CUS_ID
, REPLACE(REPLACE(TRTPE_FML_YN,CHR(13),''),CHR(10),'') TRTPE_FML_YN
, REPLACE(REPLACE(TRT_AGPLR_ORG_CD,CHR(13),''),CHR(10),'') TRT_AGPLR_ORG_CD
, REPLACE(REPLACE(TRT_AGPLR_NM,CHR(13),''),CHR(10),'') TRT_AGPLR_NM
, REPLACE(REPLACE(TRT_AGPLR_ORG_ID,CHR(13),''),CHR(10),'') TRT_AGPLR_ORG_ID
, REPLACE(REPLACE(TRT_AGPLR_CUS_ID,CHR(13),''),CHR(10),'') TRT_AGPLR_CUS_ID
, ORIG_RSK_PREM
, ORIG_INS_AMT
, PRPD_ORIG_OINS_AMT
, ORIG_OS_INS_AMT
, ORIG_DMG_AMT
, EIH_LDG_DTM
, REPLACE(REPLACE(RCRT_TPT_INSPE_FETS_YN,CHR(13),''),CHR(10),'') RCRT_TPT_INSPE_FETS_YN
, REPLACE(REPLACE(RCRT_TPT_MFETS_YN,CHR(13),''),CHR(10),'') RCRT_TPT_MFETS_YN
, REPLACE(REPLACE(INS_PRD_CAL_TP_CD,CHR(13),''),CHR(10),'') INS_PRD_CAL_TP_CD
, REPLACE(REPLACE(POLHD_CUS_ID,CHR(13),''),CHR(10),'') POLHD_CUS_ID
, REPLACE(REPLACE(POLHD_CUS_NO,CHR(13),''),CHR(10),'') POLHD_CUS_NO
, REPLACE(REPLACE(ISP_NO,CHR(13),''),CHR(10),'') ISP_NO
, REPLACE(REPLACE(PRCTR_NO,CHR(13),''),CHR(10),'') PRCTR_NO
, INSPE_BDT
, REPLACE(REPLACE(COV_UNT_PD_CD,CHR(13),''),CHR(10),'') COV_UNT_PD_CD
, REPLACE(REPLACE(MOM_COV_CD,CHR(13),''),CHR(10),'') MOM_COV_CD
, MOM_COV_INSD_AMT
 FROM TMLMS_OBJTYPDGRT
                       WHERE \$CONDITIONS 
                         AND CLOG_YYMM = '${PART}' "\
    --m 8 \
    --boundary-query "SELECT 0, 7 FROM DUAL" \
    --split-by "ora_hash(ctr_cov_id, 7)" \
    --target-dir /tmp2/STG_TMLMS_OBJTYPDGRT \
    --hive-import \
    --external-table-dir hdfs:///tmp2/temp_tbl/STG_TMLMS_OBJTYPDGRT \
    --hive-overwrite \
    --hive-table DEFAULT.STG_TMLMS_OBJTYPDGRT  >> ${SHLOG_DIR}/TMLMS_OBJTYPDGRT.shlog 2>&1 &&

#----------------------------------------------------#
# Hadoop 원본테이블에 변경분 최종 적용
#----------------------------------------------------#
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.TMLMS_OBJTYPDGRT_TMP ; " >> ${SHLOG_DIR}/TMLMS_OBJTYPDGRT.shlog 2>&1 &&
    /usr/bin/hive -e "CREATE EXTERNAL TABLE MERITZ.TMLMS_OBJTYPDGRT_TMP STORED AS PARQUET TBLPROPERTIES ('PARQUET.COMPRESS'='SNAPPY') AS
                                SELECT *
                                FROM DEFAULT.STG_TMLMS_OBJTYPDGRT ;" >> ${SHLOG_DIR}/TMLMS_OBJTYPDGRT.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.STG_TMLMS_OBJTYPDGRT ;" >> ${SHLOG_DIR}/TMLMS_OBJTYPDGRT.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.TMLMS_OBJTYPDGRT_${PART} ;" >> ${SHLOG_DIR}/TMLMS_OBJTYPDGRT.shlog 2>&1 &&

# 위의 파티션 드롭 코드는 아래 파일삭제를 전제하고 있음
# external table은 drop시 자동삭제가 되지 않기 때문에 꼬였었음 181129 수정
    /usr/bin/hadoop fs -rm -r -f  /warehouse/tablespace/external/hive/meritz.db/tmlms_objtypdgrt_${PART}  >> ${SHLOG_DIR}/TMLMS_OBJTYPDGRT.shlog 2>&1 &&

    /usr/bin/hive -e "ALTER TABLE MERITZ.TMLMS_OBJTYPDGRT_TMP RENAME TO MERITZ.TMLMS_OBJTYPDGRT_${PART} ;" >> ${SHLOG_DIR}/TMLMS_OBJTYPDGRT.shlog 2>&1 &&

# external table 이 alter문 동작 다른 문제로 아래 과정이 필요해짐
    /usr/bin/hive -e "ALTER TABLE MERITZ.TMLMS_OBJTYPDGRT_${PART} SET LOCATION 'hdfs:///warehouse/tablespace/external/hive/meritz.db/tmlms_objtypdgrt_${PART}' ;" >> ${SHLOG_DIR}/TMLMS_OBJTYPDGRT.shlog 2>&1 &&
    /usr/bin/hdfs dfs -mv /warehouse/tablespace/external/hive/meritz.db/tmlms_objtypdgrt_tmp /warehouse/tablespace/external/hive/meritz.db/tmlms_objtypdgrt_${PART} >> ${SHLOG_DIR}/TMLMS_OBJTYPDGRT.shlog 2>&1 &&

    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.TMLMS_OBJTYPDGRT_TMP ;" >> ${SHLOG_DIR}/TMLMS_OBJTYPDGRT.shlog 2>&1 

if [ $? -ne 0 ]
then             
    echo "*-----------[ TMLMS_OBJTYPDGRT.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/TMLMS_OBJTYPDGRT.shlog"
    echo "*-----------[ TMLMS_OBJTYPDGRT.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/TMLMS_OBJTYPDGRT.shlog"  >>  ${SHLOG_DIR}/TMLMS_OBJTYPDGRT.shlog
    echo "*-----------[ TMLMS_OBJTYPDGRT.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ TMLMS_OBJTYPDGRT.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/TMLMS_OBJTYPDGRT.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/TMLMS_OBJTYPDGRT.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/TMLMS_OBJTYPDGRT.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/TMLMS_OBJTYPDGRT.shlog /sqoopbin/scripts/etlpgm/his_log/TMLMS_OBJTYPDGRT_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  TMLMS_OBJTYPDGRT.sh cmd command error !! ***
    fi               

    exit -1      

else             
    echo "*-----------[ TMLMS_OBJTYPDGRT.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ TMLMS_OBJTYPDGRT.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/TMLMS_OBJTYPDGRT.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/TMLMS_OBJTYPDGRT.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/TMLMS_OBJTYPDGRT.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/TMLMS_OBJTYPDGRT.shlog /sqoopbin/scripts/etlpgm/his_log/TMLMS_OBJTYPDGRT_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  TMLMS_OBJTYPDGRT.sh cmd command error !! ***
        exit -1      
    else             
        exit 0       
    fi               
fi               
