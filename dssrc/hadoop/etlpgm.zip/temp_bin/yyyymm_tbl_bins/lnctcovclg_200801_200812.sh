#!/bin/bash

#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/TMLMB_LNCTCOVCLG_P.sh 200801
#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/TMLMB_LNCTCOVCLG_P.sh 200812
#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/TMLMB_LNCTCOVCLG_P.sh 200811
#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/TMLMB_LNCTCOVCLG_P.sh 200810
#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/TMLMB_LNCTCOVCLG_P.sh 200809
#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/TMLMB_LNCTCOVCLG_P.sh 200808
#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/TMLMB_LNCTCOVCLG_P.sh 200807
#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/TMLMB_LNCTCOVCLG_P.sh 200806
#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/TMLMB_LNCTCOVCLG_P.sh 200805
#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/TMLMB_LNCTCOVCLG_P.sh 200804
#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/TMLMB_LNCTCOVCLG_P.sh 200803
#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/TMLMB_LNCTCOVCLG_P.sh 200802

/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/TMLMB_LNCTCOVCLG_P.sh 200912
/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/TMLMB_LNCTCOVCLG_P.sh 200911
/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/TMLMB_LNCTCOVCLG_P.sh 200910
/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/TMLMB_LNCTCOVCLG_P.sh 200909
/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/TMLMB_LNCTCOVCLG_P.sh 200908
/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/TMLMB_LNCTCOVCLG_P.sh 200907
/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/TMLMB_LNCTCOVCLG_P.sh 200906
/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/TMLMB_LNCTCOVCLG_P.sh 200905
/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/TMLMB_LNCTCOVCLG_P.sh 200904
/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/TMLMB_LNCTCOVCLG_P.sh 200903
/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/TMLMB_LNCTCOVCLG_P.sh 200902
/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/TMLMB_LNCTCOVCLG_P.sh 200901
