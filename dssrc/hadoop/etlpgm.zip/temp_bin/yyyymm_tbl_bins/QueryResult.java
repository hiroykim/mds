// ORM class for table 'null'
// WARNING: This class is AUTO-GENERATED. Modify at your own risk.
//
// Debug information:
// Generated date: Wed Jan 22 07:21:46 GMT 2020
// For connector: org.apache.sqoop.manager.OracleManager
import org.apache.hadoop.io.BytesWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.mapred.lib.db.DBWritable;
import org.apache.sqoop.lib.JdbcWritableBridge;
import org.apache.sqoop.lib.DelimiterSet;
import org.apache.sqoop.lib.FieldFormatter;
import org.apache.sqoop.lib.RecordParser;
import org.apache.sqoop.lib.BooleanParser;
import org.apache.sqoop.lib.BlobRef;
import org.apache.sqoop.lib.ClobRef;
import org.apache.sqoop.lib.LargeObjectLoader;
import org.apache.sqoop.lib.SqoopRecord;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.sql.Date;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

public class QueryResult extends SqoopRecord  implements DBWritable, Writable {
  private final int PROTOCOL_VERSION = 3;
  public int getClassFormatVersion() { return PROTOCOL_VERSION; }
  public static interface FieldSetterCommand {    void setField(Object value);  }  protected ResultSet __cur_result_set;
  private Map<String, FieldSetterCommand> setters = new HashMap<String, FieldSetterCommand>();
  private void init0() {
    setters.put("CLOG_DT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.CLOG_DT = (java.sql.Timestamp)value;
      }
    });
    setters.put("CLM_ID", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.CLM_ID = (String)value;
      }
    });
    setters.put("COV_INS_AMT_ID", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.COV_INS_AMT_ID = (String)value;
      }
    });
    setters.put("CSS_COV_INS_AMT_ID", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.CSS_COV_INS_AMT_ID = (String)value;
      }
    });
    setters.put("CLADJ_CLOG_DIV_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.CLADJ_CLOG_DIV_CD = (String)value;
      }
    });
    setters.put("INS_ITMS_DIV_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.INS_ITMS_DIV_CD = (String)value;
      }
    });
    setters.put("BZPLN_PD_CTG_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.BZPLN_PD_CTG_CD = (String)value;
      }
    });
    setters.put("PREBL_MNG_PD_CTG_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.PREBL_MNG_PD_CTG_CD = (String)value;
      }
    });
    setters.put("SAL_PD_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.SAL_PD_CD = (String)value;
      }
    });
    setters.put("UNT_PD_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.UNT_PD_CD = (String)value;
      }
    });
    setters.put("ACD_NO_YY", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.ACD_NO_YY = (String)value;
      }
    });
    setters.put("ACD_NO_SEQ", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.ACD_NO_SEQ = (java.math.BigDecimal)value;
      }
    });
    setters.put("ACD_RCT_ID", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.ACD_RCT_ID = (String)value;
      }
    });
    setters.put("ACD_RCT_HIS_SEQ", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.ACD_RCT_HIS_SEQ = (java.math.BigDecimal)value;
      }
    });
    setters.put("RCT_DTM", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.RCT_DTM = (java.sql.Timestamp)value;
      }
    });
    setters.put("RCT_DT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.RCT_DT = (java.sql.Timestamp)value;
      }
    });
    setters.put("ACD_DTM", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.ACD_DTM = (java.sql.Timestamp)value;
      }
    });
    setters.put("ACD_DT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.ACD_DT = (java.sql.Timestamp)value;
      }
    });
    setters.put("HOLI_YN", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.HOLI_YN = (String)value;
      }
    });
    setters.put("OD_ACD_NO", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.OD_ACD_NO = (String)value;
      }
    });
    setters.put("OTHCO_ACD_NO", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.OTHCO_ACD_NO = (String)value;
      }
    });
    setters.put("ACD_WKD_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.ACD_WKD_CD = (String)value;
      }
    });
    setters.put("CITY_NATL_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.CITY_NATL_CD = (String)value;
      }
    });
    setters.put("ACD_PLC_ZPCD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.ACD_PLC_ZPCD = (String)value;
      }
    });
    setters.put("ACD_PLC_ZPCD_SNO", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.ACD_PLC_ZPCD_SNO = (String)value;
      }
    });
    setters.put("ACD_PLC_ZPCD_ADR", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.ACD_PLC_ZPCD_ADR = (String)value;
      }
    });
    setters.put("ACD_PLC_DTL_ADR_CON", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.ACD_PLC_DTL_ADR_CON = (String)value;
      }
    });
    setters.put("LTT_DIV_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.LTT_DIV_CD = (String)value;
      }
    });
    setters.put("LTT_COO_DG", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.LTT_COO_DG = (java.math.BigDecimal)value;
      }
    });
    setters.put("LTT_COO_MI", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.LTT_COO_MI = (java.math.BigDecimal)value;
      }
    });
    setters.put("LTT_COO_SS", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.LTT_COO_SS = (java.math.BigDecimal)value;
      }
    });
    setters.put("LNT_DIV_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.LNT_DIV_CD = (String)value;
      }
    });
    setters.put("LNT_COO_DG", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.LNT_COO_DG = (java.math.BigDecimal)value;
      }
    });
    setters.put("LNT_COO_MI", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.LNT_COO_MI = (java.math.BigDecimal)value;
      }
    });
    setters.put("LNT_COO_SS", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.LNT_COO_SS = (java.math.BigDecimal)value;
      }
    });
    setters.put("ACD_CTR_ID", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.ACD_CTR_ID = (String)value;
      }
    });
    setters.put("ACD_CTR_HIS_SEQ", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.ACD_CTR_HIS_SEQ = (java.math.BigDecimal)value;
      }
    });
    setters.put("POL_NO", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.POL_NO = (String)value;
      }
    });
    setters.put("CTR_ENDR_NO", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.CTR_ENDR_NO = (java.math.BigDecimal)value;
      }
    });
    setters.put("RTRO_ENDR_NO", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.RTRO_ENDR_NO = (java.math.BigDecimal)value;
      }
    });
    setters.put("ENDR_HIS_STD_NO", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.ENDR_HIS_STD_NO = (java.math.BigDecimal)value;
      }
    });
    setters.put("POLHD_CUS_ID", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.POLHD_CUS_ID = (String)value;
      }
    });
    setters.put("POLHD_NM", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.POLHD_NM = (String)value;
      }
    });
    setters.put("CTR_STAT_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.CTR_STAT_CD = (String)value;
      }
    });
    setters.put("CTR_STAT_DTL_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.CTR_STAT_DTL_CD = (String)value;
      }
    });
    setters.put("INS_BGN_DT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.INS_BGN_DT = (java.sql.Timestamp)value;
      }
    });
    setters.put("INS_ED_DT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.INS_ED_DT = (java.sql.Timestamp)value;
      }
    });
    setters.put("SBCP_DT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.SBCP_DT = (java.sql.Timestamp)value;
      }
    });
    setters.put("ACP_SH_DIV_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.ACP_SH_DIV_CD = (String)value;
      }
    });
    setters.put("MRIN_PD_DIV_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.MRIN_PD_DIV_CD = (String)value;
      }
    });
    setters.put("MA_INSPE_CUS_ID", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.MA_INSPE_CUS_ID = (String)value;
      }
    });
    setters.put("MA_INSPE_NM", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.MA_INSPE_NM = (String)value;
      }
    });
    setters.put("ORIG_RTRC_DIV_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.ORIG_RTRC_DIV_CD = (String)value;
      }
    });
    setters.put("PLR_STUP_YN", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.PLR_STUP_YN = (String)value;
      }
    });
    setters.put("TRT_HDQT_ORG_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.TRT_HDQT_ORG_CD = (String)value;
      }
    });
    setters.put("TRT_BCH_ORG_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.TRT_BCH_ORG_CD = (String)value;
      }
    });
    setters.put("TRT_BRCH_ORG_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.TRT_BRCH_ORG_CD = (String)value;
      }
    });
    setters.put("TRTPE_ORG_ID", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.TRTPE_ORG_ID = (String)value;
      }
    });
    setters.put("TRTPE_ORG_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.TRTPE_ORG_CD = (String)value;
      }
    });
    setters.put("CLM_TP_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.CLM_TP_CD = (String)value;
      }
    });
    setters.put("DSS_CD_YY", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.DSS_CD_YY = (String)value;
      }
    });
    setters.put("DSS_CD_SEQ", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.DSS_CD_SEQ = (java.math.BigDecimal)value;
      }
    });
    setters.put("CLM_STAT_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.CLM_STAT_CD = (String)value;
      }
    });
    setters.put("ACD_CAUS_LCTG_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.ACD_CAUS_LCTG_CD = (String)value;
      }
    });
    setters.put("ACD_CAUS_MCTG_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.ACD_CAUS_MCTG_CD = (String)value;
      }
    });
    setters.put("ACD_CAUS_SCTG_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.ACD_CAUS_SCTG_CD = (String)value;
      }
    });
    setters.put("ACD_CAUS_DCTG_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.ACD_CAUS_DCTG_CD = (String)value;
      }
    });
    setters.put("ACD_CAUS_DCTG2_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.ACD_CAUS_DCTG2_CD = (String)value;
      }
    });
    setters.put("COMS_PART_ORG_ID", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.COMS_PART_ORG_ID = (String)value;
      }
    });
    setters.put("COMS_PART_ORG_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.COMS_PART_ORG_CD = (String)value;
      }
    });
    setters.put("COMS_TEM_ORG_ID", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.COMS_TEM_ORG_ID = (String)value;
      }
    });
    setters.put("COMS_TEM_ORG_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.COMS_TEM_ORG_CD = (String)value;
      }
    });
    setters.put("COMS_CHRPE_ORG_ID", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.COMS_CHRPE_ORG_ID = (String)value;
      }
    });
    setters.put("CPIC_ORG_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.CPIC_ORG_CD = (String)value;
      }
    });
    setters.put("CNCLU_DT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.CNCLU_DT = (java.sql.Timestamp)value;
      }
    });
    setters.put("EXMP_DCN_DT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.EXMP_DCN_DT = (java.sql.Timestamp)value;
      }
    });
    setters.put("DAM_DGR_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.DAM_DGR_CD = (String)value;
      }
    });
    setters.put("AT_ISP_YN", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.AT_ISP_YN = (String)value;
      }
    });
    setters.put("ACD_CTR_OBJ_ID", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.ACD_CTR_OBJ_ID = (String)value;
      }
    });
    setters.put("ACD_CTR_OBJ_HIS_SEQ", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.ACD_CTR_OBJ_HIS_SEQ = (java.math.BigDecimal)value;
      }
    });
    setters.put("ACD_OBJ_DIV_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.ACD_OBJ_DIV_CD = (String)value;
      }
    });
    setters.put("ACD_OBJ_ID", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.ACD_OBJ_ID = (String)value;
      }
    });
    setters.put("DAM_ORD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.DAM_ORD = (java.math.BigDecimal)value;
      }
    });
    setters.put("CTR_OBJ_ID", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.CTR_OBJ_ID = (String)value;
      }
    });
    setters.put("CTR_OBJ_ADR_ID", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.CTR_OBJ_ADR_ID = (String)value;
      }
    });
    setters.put("OBJ_TP_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.OBJ_TP_CD = (String)value;
      }
    });
    setters.put("DMPE_CUS_ID", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.DMPE_CUS_ID = (String)value;
      }
    });
    setters.put("DMPO_NM", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.DMPO_NM = (String)value;
      }
    });
    setters.put("PVDS_YN", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.PVDS_YN = (String)value;
      }
    });
    setters.put("TCTR_DMPE_JOB_GRD_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.TCTR_DMPE_JOB_GRD_CD = (String)value;
      }
    });
    setters.put("TCTR_DMPE_JOB_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.TCTR_DMPE_JOB_CD = (String)value;
      }
    });
    setters.put("TACD_DMPE_JOB_GRD_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.TACD_DMPE_JOB_GRD_CD = (String)value;
      }
    });
    setters.put("TACD_DMPE_JOB_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.TACD_DMPE_JOB_CD = (String)value;
      }
    });
    setters.put("OWNR_NM", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.OWNR_NM = (String)value;
      }
    });
    setters.put("DMPE_AGE", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.DMPE_AGE = (java.math.BigDecimal)value;
      }
    });
    setters.put("TNG_DIV_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.TNG_DIV_CD = (String)value;
      }
    });
    setters.put("OBJ_GRD_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.OBJ_GRD_CD = (String)value;
      }
    });
    setters.put("OPN_JBCL_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.OPN_JBCL_CD = (String)value;
      }
    });
    setters.put("OPJB_NM", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.OPJB_NM = (String)value;
      }
    });
    setters.put("OBJ_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.OBJ_CD = (String)value;
      }
    });
    setters.put("DMOB_LCTG_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.DMOB_LCTG_CD = (String)value;
      }
    });
    setters.put("DMOB_MCTG_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.DMOB_MCTG_CD = (String)value;
      }
    });
    setters.put("DMOB_SCTG_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.DMOB_SCTG_CD = (String)value;
      }
    });
    setters.put("DMOB_TPIDS_LCTG_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.DMOB_TPIDS_LCTG_CD = (String)value;
      }
    });
    setters.put("DMOB_TPIDS_MCTG_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.DMOB_TPIDS_MCTG_CD = (String)value;
      }
    });
    setters.put("DMOB_TPIDS_SCTG_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.DMOB_TPIDS_SCTG_CD = (String)value;
      }
    });
    setters.put("DMOB_TPIDS_DCTG_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.DMOB_TPIDS_DCTG_CD = (String)value;
      }
    });
    setters.put("MCSH_FSHBT_DIV_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.MCSH_FSHBT_DIV_CD = (String)value;
      }
    });
    setters.put("SHAG", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.SHAG = (java.math.BigDecimal)value;
      }
    });
    setters.put("SHP_TP_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.SHP_TP_CD = (String)value;
      }
    });
    setters.put("SHP_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.SHP_CD = (String)value;
      }
    });
    setters.put("ARCRF_REG_NO", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.ARCRF_REG_NO = (String)value;
      }
    });
    setters.put("CARG_TRN_ITM_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.CARG_TRN_ITM_CD = (String)value;
      }
    });
    setters.put("DTH_YN", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.DTH_YN = (String)value;
      }
    });
    setters.put("AFOBS_YN", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.AFOBS_YN = (String)value;
      }
    });
    setters.put("HSP_MD_EXP_YN", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.HSP_MD_EXP_YN = (String)value;
      }
    });
    setters.put("GHR_MD_EXP_YN", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.GHR_MD_EXP_YN = (String)value;
      }
    });
    setters.put("PSC_MD_EXP_YN", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.PSC_MD_EXP_YN = (String)value;
      }
    });
    setters.put("HSP_DDPY_YN", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.HSP_DDPY_YN = (String)value;
      }
    });
    setters.put("LAST_DGN_YN", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.LAST_DGN_YN = (String)value;
      }
    });
    setters.put("SROP_YN", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.SROP_YN = (String)value;
      }
    });
    setters.put("EXP_YN", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.EXP_YN = (String)value;
      }
    });
    setters.put("SROP_BDW_YN", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.SROP_BDW_YN = (String)value;
      }
    });
    setters.put("OS_ID", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.OS_ID = (String)value;
      }
    });
    setters.put("OS_HIS_SEQ", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.OS_HIS_SEQ = (java.math.BigDecimal)value;
      }
    });
    setters.put("OS_SEQ", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.OS_SEQ = (java.math.BigDecimal)value;
      }
    });
    setters.put("OS_DIV_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.OS_DIV_CD = (String)value;
      }
    });
    setters.put("DCN_ID", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.DCN_ID = (String)value;
      }
    });
    setters.put("DCN_HIS_SEQ", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.DCN_HIS_SEQ = (java.math.BigDecimal)value;
      }
    });
    setters.put("DCN_SEQ", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.DCN_SEQ = (java.math.BigDecimal)value;
      }
    });
    setters.put("DCN_DIV_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.DCN_DIV_CD = (String)value;
      }
    });
    setters.put("CNCLU_ID", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.CNCLU_ID = (String)value;
      }
    });
    setters.put("CNCLU_HIS_SEQ", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.CNCLU_HIS_SEQ = (java.math.BigDecimal)value;
      }
    });
    setters.put("CNCLU_DIV_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.CNCLU_DIV_CD = (String)value;
      }
    });
    setters.put("CNCLU_DATA_DIV_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.CNCLU_DATA_DIV_CD = (String)value;
      }
    });
    setters.put("COV_INS_DATA_DIV_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.COV_INS_DATA_DIV_CD = (String)value;
      }
    });
    setters.put("COV_INS_HIS_SEQ", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.COV_INS_HIS_SEQ = (java.math.BigDecimal)value;
      }
    });
    setters.put("INS_AMT_APVL_DT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.INS_AMT_APVL_DT = (java.sql.Timestamp)value;
      }
    });
    setters.put("CSS_COV_INS_HIS_SEQ", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.CSS_COV_INS_HIS_SEQ = (java.math.BigDecimal)value;
      }
    });
    setters.put("SPTPY_DIV_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.SPTPY_DIV_CD = (String)value;
      }
    });
    setters.put("ISD_PCS_SEQ", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.ISD_PCS_SEQ = (java.math.BigDecimal)value;
      }
    });
    setters.put("COV_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.COV_CD = (String)value;
      }
    });
    setters.put("INS_AMT_EXT_EXP_DIV_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.INS_AMT_EXT_EXP_DIV_CD = (String)value;
      }
    });
    setters.put("GURT_UNT_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.GURT_UNT_CD = (String)value;
      }
    });
    setters.put("RSK_UNT_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.RSK_UNT_CD = (String)value;
      }
    });
    setters.put("CLADJ_DIV_CTG_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.CLADJ_DIV_CTG_CD = (String)value;
      }
    });
    setters.put("BAS_SIC_DIV_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.BAS_SIC_DIV_CD = (String)value;
      }
    });
    setters.put("COV_INS_BGN_DT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.COV_INS_BGN_DT = (java.sql.Timestamp)value;
      }
    });
    setters.put("COV_INS_ED_DT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.COV_INS_ED_DT = (java.sql.Timestamp)value;
      }
    });
    setters.put("INSD_AMT_CUR_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.INSD_AMT_CUR_CD = (String)value;
      }
    });
    setters.put("CUR_INSD_AMT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.CUR_INSD_AMT = (java.math.BigDecimal)value;
      }
    });
    setters.put("INSD_AMT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.INSD_AMT = (java.math.BigDecimal)value;
      }
    });
    setters.put("PPS_COMS_LM_AMT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.PPS_COMS_LM_AMT = (java.math.BigDecimal)value;
      }
    });
    setters.put("PACD_COMS_LM_AMT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.PACD_COMS_LM_AMT = (java.math.BigDecimal)value;
      }
    });
    setters.put("LDCO_CTR_BZAC_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.LDCO_CTR_BZAC_CD = (String)value;
      }
    });
    setters.put("COI_CTR_BZAC_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.COI_CTR_BZAC_CD = (String)value;
      }
    });
    setters.put("CSS_COV_INS_SEQ", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.CSS_COV_INS_SEQ = (java.math.BigDecimal)value;
      }
    });
    setters.put("JNT_ACP_COV_INS_SEQ", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.JNT_ACP_COV_INS_SEQ = (java.math.BigDecimal)value;
      }
    });
    setters.put("PRTC_RT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.PRTC_RT = (java.math.BigDecimal)value;
      }
    });
    setters.put("BRKR_CTR_BZAC_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.BRKR_CTR_BZAC_CD = (String)value;
      }
    });
    setters.put("RINCO_CTR_BZAC_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.RINCO_CTR_BZAC_CD = (String)value;
      }
    });
    setters.put("CLOG_APL_YN", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.CLOG_APL_YN = (String)value;
      }
    });
    setters.put("CSS_CTR_ID", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.CSS_CTR_ID = (String)value;
      }
    });
    setters.put("RINS_SH_DIV_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.RINS_SH_DIV_CD = (String)value;
      }
    });
    setters.put("BRKR_CSS_RT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.BRKR_CSS_RT = (java.math.BigDecimal)value;
      }
    });
    setters.put("INSD_AMT_STD_CSS_RT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.INSD_AMT_STD_CSS_RT = (java.math.BigDecimal)value;
      }
    });
    setters.put("ACP_AMT_STD_CSS_RT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.ACP_AMT_STD_CSS_RT = (java.math.BigDecimal)value;
      }
    });
    setters.put("CUR_CD", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.CUR_CD = (String)value;
      }
    });
    setters.put("APL_EXRT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.APL_EXRT = (java.math.BigDecimal)value;
      }
    });
    setters.put("CSS_INS_AMT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.CSS_INS_AMT = (java.math.BigDecimal)value;
      }
    });
    setters.put("KWCV_CSS_INS_AMT", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.KWCV_CSS_INS_AMT = (java.math.BigDecimal)value;
      }
    });
    setters.put("EIH_LDG_DTM", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        QueryResult.this.EIH_LDG_DTM = (java.sql.Timestamp)value;
      }
    });
  }
  public QueryResult() {
    init0();
  }
  private java.sql.Timestamp CLOG_DT;
  public java.sql.Timestamp get_CLOG_DT() {
    return CLOG_DT;
  }
  public void set_CLOG_DT(java.sql.Timestamp CLOG_DT) {
    this.CLOG_DT = CLOG_DT;
  }
  public QueryResult with_CLOG_DT(java.sql.Timestamp CLOG_DT) {
    this.CLOG_DT = CLOG_DT;
    return this;
  }
  private String CLM_ID;
  public String get_CLM_ID() {
    return CLM_ID;
  }
  public void set_CLM_ID(String CLM_ID) {
    this.CLM_ID = CLM_ID;
  }
  public QueryResult with_CLM_ID(String CLM_ID) {
    this.CLM_ID = CLM_ID;
    return this;
  }
  private String COV_INS_AMT_ID;
  public String get_COV_INS_AMT_ID() {
    return COV_INS_AMT_ID;
  }
  public void set_COV_INS_AMT_ID(String COV_INS_AMT_ID) {
    this.COV_INS_AMT_ID = COV_INS_AMT_ID;
  }
  public QueryResult with_COV_INS_AMT_ID(String COV_INS_AMT_ID) {
    this.COV_INS_AMT_ID = COV_INS_AMT_ID;
    return this;
  }
  private String CSS_COV_INS_AMT_ID;
  public String get_CSS_COV_INS_AMT_ID() {
    return CSS_COV_INS_AMT_ID;
  }
  public void set_CSS_COV_INS_AMT_ID(String CSS_COV_INS_AMT_ID) {
    this.CSS_COV_INS_AMT_ID = CSS_COV_INS_AMT_ID;
  }
  public QueryResult with_CSS_COV_INS_AMT_ID(String CSS_COV_INS_AMT_ID) {
    this.CSS_COV_INS_AMT_ID = CSS_COV_INS_AMT_ID;
    return this;
  }
  private String CLADJ_CLOG_DIV_CD;
  public String get_CLADJ_CLOG_DIV_CD() {
    return CLADJ_CLOG_DIV_CD;
  }
  public void set_CLADJ_CLOG_DIV_CD(String CLADJ_CLOG_DIV_CD) {
    this.CLADJ_CLOG_DIV_CD = CLADJ_CLOG_DIV_CD;
  }
  public QueryResult with_CLADJ_CLOG_DIV_CD(String CLADJ_CLOG_DIV_CD) {
    this.CLADJ_CLOG_DIV_CD = CLADJ_CLOG_DIV_CD;
    return this;
  }
  private String INS_ITMS_DIV_CD;
  public String get_INS_ITMS_DIV_CD() {
    return INS_ITMS_DIV_CD;
  }
  public void set_INS_ITMS_DIV_CD(String INS_ITMS_DIV_CD) {
    this.INS_ITMS_DIV_CD = INS_ITMS_DIV_CD;
  }
  public QueryResult with_INS_ITMS_DIV_CD(String INS_ITMS_DIV_CD) {
    this.INS_ITMS_DIV_CD = INS_ITMS_DIV_CD;
    return this;
  }
  private String BZPLN_PD_CTG_CD;
  public String get_BZPLN_PD_CTG_CD() {
    return BZPLN_PD_CTG_CD;
  }
  public void set_BZPLN_PD_CTG_CD(String BZPLN_PD_CTG_CD) {
    this.BZPLN_PD_CTG_CD = BZPLN_PD_CTG_CD;
  }
  public QueryResult with_BZPLN_PD_CTG_CD(String BZPLN_PD_CTG_CD) {
    this.BZPLN_PD_CTG_CD = BZPLN_PD_CTG_CD;
    return this;
  }
  private String PREBL_MNG_PD_CTG_CD;
  public String get_PREBL_MNG_PD_CTG_CD() {
    return PREBL_MNG_PD_CTG_CD;
  }
  public void set_PREBL_MNG_PD_CTG_CD(String PREBL_MNG_PD_CTG_CD) {
    this.PREBL_MNG_PD_CTG_CD = PREBL_MNG_PD_CTG_CD;
  }
  public QueryResult with_PREBL_MNG_PD_CTG_CD(String PREBL_MNG_PD_CTG_CD) {
    this.PREBL_MNG_PD_CTG_CD = PREBL_MNG_PD_CTG_CD;
    return this;
  }
  private String SAL_PD_CD;
  public String get_SAL_PD_CD() {
    return SAL_PD_CD;
  }
  public void set_SAL_PD_CD(String SAL_PD_CD) {
    this.SAL_PD_CD = SAL_PD_CD;
  }
  public QueryResult with_SAL_PD_CD(String SAL_PD_CD) {
    this.SAL_PD_CD = SAL_PD_CD;
    return this;
  }
  private String UNT_PD_CD;
  public String get_UNT_PD_CD() {
    return UNT_PD_CD;
  }
  public void set_UNT_PD_CD(String UNT_PD_CD) {
    this.UNT_PD_CD = UNT_PD_CD;
  }
  public QueryResult with_UNT_PD_CD(String UNT_PD_CD) {
    this.UNT_PD_CD = UNT_PD_CD;
    return this;
  }
  private String ACD_NO_YY;
  public String get_ACD_NO_YY() {
    return ACD_NO_YY;
  }
  public void set_ACD_NO_YY(String ACD_NO_YY) {
    this.ACD_NO_YY = ACD_NO_YY;
  }
  public QueryResult with_ACD_NO_YY(String ACD_NO_YY) {
    this.ACD_NO_YY = ACD_NO_YY;
    return this;
  }
  private java.math.BigDecimal ACD_NO_SEQ;
  public java.math.BigDecimal get_ACD_NO_SEQ() {
    return ACD_NO_SEQ;
  }
  public void set_ACD_NO_SEQ(java.math.BigDecimal ACD_NO_SEQ) {
    this.ACD_NO_SEQ = ACD_NO_SEQ;
  }
  public QueryResult with_ACD_NO_SEQ(java.math.BigDecimal ACD_NO_SEQ) {
    this.ACD_NO_SEQ = ACD_NO_SEQ;
    return this;
  }
  private String ACD_RCT_ID;
  public String get_ACD_RCT_ID() {
    return ACD_RCT_ID;
  }
  public void set_ACD_RCT_ID(String ACD_RCT_ID) {
    this.ACD_RCT_ID = ACD_RCT_ID;
  }
  public QueryResult with_ACD_RCT_ID(String ACD_RCT_ID) {
    this.ACD_RCT_ID = ACD_RCT_ID;
    return this;
  }
  private java.math.BigDecimal ACD_RCT_HIS_SEQ;
  public java.math.BigDecimal get_ACD_RCT_HIS_SEQ() {
    return ACD_RCT_HIS_SEQ;
  }
  public void set_ACD_RCT_HIS_SEQ(java.math.BigDecimal ACD_RCT_HIS_SEQ) {
    this.ACD_RCT_HIS_SEQ = ACD_RCT_HIS_SEQ;
  }
  public QueryResult with_ACD_RCT_HIS_SEQ(java.math.BigDecimal ACD_RCT_HIS_SEQ) {
    this.ACD_RCT_HIS_SEQ = ACD_RCT_HIS_SEQ;
    return this;
  }
  private java.sql.Timestamp RCT_DTM;
  public java.sql.Timestamp get_RCT_DTM() {
    return RCT_DTM;
  }
  public void set_RCT_DTM(java.sql.Timestamp RCT_DTM) {
    this.RCT_DTM = RCT_DTM;
  }
  public QueryResult with_RCT_DTM(java.sql.Timestamp RCT_DTM) {
    this.RCT_DTM = RCT_DTM;
    return this;
  }
  private java.sql.Timestamp RCT_DT;
  public java.sql.Timestamp get_RCT_DT() {
    return RCT_DT;
  }
  public void set_RCT_DT(java.sql.Timestamp RCT_DT) {
    this.RCT_DT = RCT_DT;
  }
  public QueryResult with_RCT_DT(java.sql.Timestamp RCT_DT) {
    this.RCT_DT = RCT_DT;
    return this;
  }
  private java.sql.Timestamp ACD_DTM;
  public java.sql.Timestamp get_ACD_DTM() {
    return ACD_DTM;
  }
  public void set_ACD_DTM(java.sql.Timestamp ACD_DTM) {
    this.ACD_DTM = ACD_DTM;
  }
  public QueryResult with_ACD_DTM(java.sql.Timestamp ACD_DTM) {
    this.ACD_DTM = ACD_DTM;
    return this;
  }
  private java.sql.Timestamp ACD_DT;
  public java.sql.Timestamp get_ACD_DT() {
    return ACD_DT;
  }
  public void set_ACD_DT(java.sql.Timestamp ACD_DT) {
    this.ACD_DT = ACD_DT;
  }
  public QueryResult with_ACD_DT(java.sql.Timestamp ACD_DT) {
    this.ACD_DT = ACD_DT;
    return this;
  }
  private String HOLI_YN;
  public String get_HOLI_YN() {
    return HOLI_YN;
  }
  public void set_HOLI_YN(String HOLI_YN) {
    this.HOLI_YN = HOLI_YN;
  }
  public QueryResult with_HOLI_YN(String HOLI_YN) {
    this.HOLI_YN = HOLI_YN;
    return this;
  }
  private String OD_ACD_NO;
  public String get_OD_ACD_NO() {
    return OD_ACD_NO;
  }
  public void set_OD_ACD_NO(String OD_ACD_NO) {
    this.OD_ACD_NO = OD_ACD_NO;
  }
  public QueryResult with_OD_ACD_NO(String OD_ACD_NO) {
    this.OD_ACD_NO = OD_ACD_NO;
    return this;
  }
  private String OTHCO_ACD_NO;
  public String get_OTHCO_ACD_NO() {
    return OTHCO_ACD_NO;
  }
  public void set_OTHCO_ACD_NO(String OTHCO_ACD_NO) {
    this.OTHCO_ACD_NO = OTHCO_ACD_NO;
  }
  public QueryResult with_OTHCO_ACD_NO(String OTHCO_ACD_NO) {
    this.OTHCO_ACD_NO = OTHCO_ACD_NO;
    return this;
  }
  private String ACD_WKD_CD;
  public String get_ACD_WKD_CD() {
    return ACD_WKD_CD;
  }
  public void set_ACD_WKD_CD(String ACD_WKD_CD) {
    this.ACD_WKD_CD = ACD_WKD_CD;
  }
  public QueryResult with_ACD_WKD_CD(String ACD_WKD_CD) {
    this.ACD_WKD_CD = ACD_WKD_CD;
    return this;
  }
  private String CITY_NATL_CD;
  public String get_CITY_NATL_CD() {
    return CITY_NATL_CD;
  }
  public void set_CITY_NATL_CD(String CITY_NATL_CD) {
    this.CITY_NATL_CD = CITY_NATL_CD;
  }
  public QueryResult with_CITY_NATL_CD(String CITY_NATL_CD) {
    this.CITY_NATL_CD = CITY_NATL_CD;
    return this;
  }
  private String ACD_PLC_ZPCD;
  public String get_ACD_PLC_ZPCD() {
    return ACD_PLC_ZPCD;
  }
  public void set_ACD_PLC_ZPCD(String ACD_PLC_ZPCD) {
    this.ACD_PLC_ZPCD = ACD_PLC_ZPCD;
  }
  public QueryResult with_ACD_PLC_ZPCD(String ACD_PLC_ZPCD) {
    this.ACD_PLC_ZPCD = ACD_PLC_ZPCD;
    return this;
  }
  private String ACD_PLC_ZPCD_SNO;
  public String get_ACD_PLC_ZPCD_SNO() {
    return ACD_PLC_ZPCD_SNO;
  }
  public void set_ACD_PLC_ZPCD_SNO(String ACD_PLC_ZPCD_SNO) {
    this.ACD_PLC_ZPCD_SNO = ACD_PLC_ZPCD_SNO;
  }
  public QueryResult with_ACD_PLC_ZPCD_SNO(String ACD_PLC_ZPCD_SNO) {
    this.ACD_PLC_ZPCD_SNO = ACD_PLC_ZPCD_SNO;
    return this;
  }
  private String ACD_PLC_ZPCD_ADR;
  public String get_ACD_PLC_ZPCD_ADR() {
    return ACD_PLC_ZPCD_ADR;
  }
  public void set_ACD_PLC_ZPCD_ADR(String ACD_PLC_ZPCD_ADR) {
    this.ACD_PLC_ZPCD_ADR = ACD_PLC_ZPCD_ADR;
  }
  public QueryResult with_ACD_PLC_ZPCD_ADR(String ACD_PLC_ZPCD_ADR) {
    this.ACD_PLC_ZPCD_ADR = ACD_PLC_ZPCD_ADR;
    return this;
  }
  private String ACD_PLC_DTL_ADR_CON;
  public String get_ACD_PLC_DTL_ADR_CON() {
    return ACD_PLC_DTL_ADR_CON;
  }
  public void set_ACD_PLC_DTL_ADR_CON(String ACD_PLC_DTL_ADR_CON) {
    this.ACD_PLC_DTL_ADR_CON = ACD_PLC_DTL_ADR_CON;
  }
  public QueryResult with_ACD_PLC_DTL_ADR_CON(String ACD_PLC_DTL_ADR_CON) {
    this.ACD_PLC_DTL_ADR_CON = ACD_PLC_DTL_ADR_CON;
    return this;
  }
  private String LTT_DIV_CD;
  public String get_LTT_DIV_CD() {
    return LTT_DIV_CD;
  }
  public void set_LTT_DIV_CD(String LTT_DIV_CD) {
    this.LTT_DIV_CD = LTT_DIV_CD;
  }
  public QueryResult with_LTT_DIV_CD(String LTT_DIV_CD) {
    this.LTT_DIV_CD = LTT_DIV_CD;
    return this;
  }
  private java.math.BigDecimal LTT_COO_DG;
  public java.math.BigDecimal get_LTT_COO_DG() {
    return LTT_COO_DG;
  }
  public void set_LTT_COO_DG(java.math.BigDecimal LTT_COO_DG) {
    this.LTT_COO_DG = LTT_COO_DG;
  }
  public QueryResult with_LTT_COO_DG(java.math.BigDecimal LTT_COO_DG) {
    this.LTT_COO_DG = LTT_COO_DG;
    return this;
  }
  private java.math.BigDecimal LTT_COO_MI;
  public java.math.BigDecimal get_LTT_COO_MI() {
    return LTT_COO_MI;
  }
  public void set_LTT_COO_MI(java.math.BigDecimal LTT_COO_MI) {
    this.LTT_COO_MI = LTT_COO_MI;
  }
  public QueryResult with_LTT_COO_MI(java.math.BigDecimal LTT_COO_MI) {
    this.LTT_COO_MI = LTT_COO_MI;
    return this;
  }
  private java.math.BigDecimal LTT_COO_SS;
  public java.math.BigDecimal get_LTT_COO_SS() {
    return LTT_COO_SS;
  }
  public void set_LTT_COO_SS(java.math.BigDecimal LTT_COO_SS) {
    this.LTT_COO_SS = LTT_COO_SS;
  }
  public QueryResult with_LTT_COO_SS(java.math.BigDecimal LTT_COO_SS) {
    this.LTT_COO_SS = LTT_COO_SS;
    return this;
  }
  private String LNT_DIV_CD;
  public String get_LNT_DIV_CD() {
    return LNT_DIV_CD;
  }
  public void set_LNT_DIV_CD(String LNT_DIV_CD) {
    this.LNT_DIV_CD = LNT_DIV_CD;
  }
  public QueryResult with_LNT_DIV_CD(String LNT_DIV_CD) {
    this.LNT_DIV_CD = LNT_DIV_CD;
    return this;
  }
  private java.math.BigDecimal LNT_COO_DG;
  public java.math.BigDecimal get_LNT_COO_DG() {
    return LNT_COO_DG;
  }
  public void set_LNT_COO_DG(java.math.BigDecimal LNT_COO_DG) {
    this.LNT_COO_DG = LNT_COO_DG;
  }
  public QueryResult with_LNT_COO_DG(java.math.BigDecimal LNT_COO_DG) {
    this.LNT_COO_DG = LNT_COO_DG;
    return this;
  }
  private java.math.BigDecimal LNT_COO_MI;
  public java.math.BigDecimal get_LNT_COO_MI() {
    return LNT_COO_MI;
  }
  public void set_LNT_COO_MI(java.math.BigDecimal LNT_COO_MI) {
    this.LNT_COO_MI = LNT_COO_MI;
  }
  public QueryResult with_LNT_COO_MI(java.math.BigDecimal LNT_COO_MI) {
    this.LNT_COO_MI = LNT_COO_MI;
    return this;
  }
  private java.math.BigDecimal LNT_COO_SS;
  public java.math.BigDecimal get_LNT_COO_SS() {
    return LNT_COO_SS;
  }
  public void set_LNT_COO_SS(java.math.BigDecimal LNT_COO_SS) {
    this.LNT_COO_SS = LNT_COO_SS;
  }
  public QueryResult with_LNT_COO_SS(java.math.BigDecimal LNT_COO_SS) {
    this.LNT_COO_SS = LNT_COO_SS;
    return this;
  }
  private String ACD_CTR_ID;
  public String get_ACD_CTR_ID() {
    return ACD_CTR_ID;
  }
  public void set_ACD_CTR_ID(String ACD_CTR_ID) {
    this.ACD_CTR_ID = ACD_CTR_ID;
  }
  public QueryResult with_ACD_CTR_ID(String ACD_CTR_ID) {
    this.ACD_CTR_ID = ACD_CTR_ID;
    return this;
  }
  private java.math.BigDecimal ACD_CTR_HIS_SEQ;
  public java.math.BigDecimal get_ACD_CTR_HIS_SEQ() {
    return ACD_CTR_HIS_SEQ;
  }
  public void set_ACD_CTR_HIS_SEQ(java.math.BigDecimal ACD_CTR_HIS_SEQ) {
    this.ACD_CTR_HIS_SEQ = ACD_CTR_HIS_SEQ;
  }
  public QueryResult with_ACD_CTR_HIS_SEQ(java.math.BigDecimal ACD_CTR_HIS_SEQ) {
    this.ACD_CTR_HIS_SEQ = ACD_CTR_HIS_SEQ;
    return this;
  }
  private String POL_NO;
  public String get_POL_NO() {
    return POL_NO;
  }
  public void set_POL_NO(String POL_NO) {
    this.POL_NO = POL_NO;
  }
  public QueryResult with_POL_NO(String POL_NO) {
    this.POL_NO = POL_NO;
    return this;
  }
  private java.math.BigDecimal CTR_ENDR_NO;
  public java.math.BigDecimal get_CTR_ENDR_NO() {
    return CTR_ENDR_NO;
  }
  public void set_CTR_ENDR_NO(java.math.BigDecimal CTR_ENDR_NO) {
    this.CTR_ENDR_NO = CTR_ENDR_NO;
  }
  public QueryResult with_CTR_ENDR_NO(java.math.BigDecimal CTR_ENDR_NO) {
    this.CTR_ENDR_NO = CTR_ENDR_NO;
    return this;
  }
  private java.math.BigDecimal RTRO_ENDR_NO;
  public java.math.BigDecimal get_RTRO_ENDR_NO() {
    return RTRO_ENDR_NO;
  }
  public void set_RTRO_ENDR_NO(java.math.BigDecimal RTRO_ENDR_NO) {
    this.RTRO_ENDR_NO = RTRO_ENDR_NO;
  }
  public QueryResult with_RTRO_ENDR_NO(java.math.BigDecimal RTRO_ENDR_NO) {
    this.RTRO_ENDR_NO = RTRO_ENDR_NO;
    return this;
  }
  private java.math.BigDecimal ENDR_HIS_STD_NO;
  public java.math.BigDecimal get_ENDR_HIS_STD_NO() {
    return ENDR_HIS_STD_NO;
  }
  public void set_ENDR_HIS_STD_NO(java.math.BigDecimal ENDR_HIS_STD_NO) {
    this.ENDR_HIS_STD_NO = ENDR_HIS_STD_NO;
  }
  public QueryResult with_ENDR_HIS_STD_NO(java.math.BigDecimal ENDR_HIS_STD_NO) {
    this.ENDR_HIS_STD_NO = ENDR_HIS_STD_NO;
    return this;
  }
  private String POLHD_CUS_ID;
  public String get_POLHD_CUS_ID() {
    return POLHD_CUS_ID;
  }
  public void set_POLHD_CUS_ID(String POLHD_CUS_ID) {
    this.POLHD_CUS_ID = POLHD_CUS_ID;
  }
  public QueryResult with_POLHD_CUS_ID(String POLHD_CUS_ID) {
    this.POLHD_CUS_ID = POLHD_CUS_ID;
    return this;
  }
  private String POLHD_NM;
  public String get_POLHD_NM() {
    return POLHD_NM;
  }
  public void set_POLHD_NM(String POLHD_NM) {
    this.POLHD_NM = POLHD_NM;
  }
  public QueryResult with_POLHD_NM(String POLHD_NM) {
    this.POLHD_NM = POLHD_NM;
    return this;
  }
  private String CTR_STAT_CD;
  public String get_CTR_STAT_CD() {
    return CTR_STAT_CD;
  }
  public void set_CTR_STAT_CD(String CTR_STAT_CD) {
    this.CTR_STAT_CD = CTR_STAT_CD;
  }
  public QueryResult with_CTR_STAT_CD(String CTR_STAT_CD) {
    this.CTR_STAT_CD = CTR_STAT_CD;
    return this;
  }
  private String CTR_STAT_DTL_CD;
  public String get_CTR_STAT_DTL_CD() {
    return CTR_STAT_DTL_CD;
  }
  public void set_CTR_STAT_DTL_CD(String CTR_STAT_DTL_CD) {
    this.CTR_STAT_DTL_CD = CTR_STAT_DTL_CD;
  }
  public QueryResult with_CTR_STAT_DTL_CD(String CTR_STAT_DTL_CD) {
    this.CTR_STAT_DTL_CD = CTR_STAT_DTL_CD;
    return this;
  }
  private java.sql.Timestamp INS_BGN_DT;
  public java.sql.Timestamp get_INS_BGN_DT() {
    return INS_BGN_DT;
  }
  public void set_INS_BGN_DT(java.sql.Timestamp INS_BGN_DT) {
    this.INS_BGN_DT = INS_BGN_DT;
  }
  public QueryResult with_INS_BGN_DT(java.sql.Timestamp INS_BGN_DT) {
    this.INS_BGN_DT = INS_BGN_DT;
    return this;
  }
  private java.sql.Timestamp INS_ED_DT;
  public java.sql.Timestamp get_INS_ED_DT() {
    return INS_ED_DT;
  }
  public void set_INS_ED_DT(java.sql.Timestamp INS_ED_DT) {
    this.INS_ED_DT = INS_ED_DT;
  }
  public QueryResult with_INS_ED_DT(java.sql.Timestamp INS_ED_DT) {
    this.INS_ED_DT = INS_ED_DT;
    return this;
  }
  private java.sql.Timestamp SBCP_DT;
  public java.sql.Timestamp get_SBCP_DT() {
    return SBCP_DT;
  }
  public void set_SBCP_DT(java.sql.Timestamp SBCP_DT) {
    this.SBCP_DT = SBCP_DT;
  }
  public QueryResult with_SBCP_DT(java.sql.Timestamp SBCP_DT) {
    this.SBCP_DT = SBCP_DT;
    return this;
  }
  private String ACP_SH_DIV_CD;
  public String get_ACP_SH_DIV_CD() {
    return ACP_SH_DIV_CD;
  }
  public void set_ACP_SH_DIV_CD(String ACP_SH_DIV_CD) {
    this.ACP_SH_DIV_CD = ACP_SH_DIV_CD;
  }
  public QueryResult with_ACP_SH_DIV_CD(String ACP_SH_DIV_CD) {
    this.ACP_SH_DIV_CD = ACP_SH_DIV_CD;
    return this;
  }
  private String MRIN_PD_DIV_CD;
  public String get_MRIN_PD_DIV_CD() {
    return MRIN_PD_DIV_CD;
  }
  public void set_MRIN_PD_DIV_CD(String MRIN_PD_DIV_CD) {
    this.MRIN_PD_DIV_CD = MRIN_PD_DIV_CD;
  }
  public QueryResult with_MRIN_PD_DIV_CD(String MRIN_PD_DIV_CD) {
    this.MRIN_PD_DIV_CD = MRIN_PD_DIV_CD;
    return this;
  }
  private String MA_INSPE_CUS_ID;
  public String get_MA_INSPE_CUS_ID() {
    return MA_INSPE_CUS_ID;
  }
  public void set_MA_INSPE_CUS_ID(String MA_INSPE_CUS_ID) {
    this.MA_INSPE_CUS_ID = MA_INSPE_CUS_ID;
  }
  public QueryResult with_MA_INSPE_CUS_ID(String MA_INSPE_CUS_ID) {
    this.MA_INSPE_CUS_ID = MA_INSPE_CUS_ID;
    return this;
  }
  private String MA_INSPE_NM;
  public String get_MA_INSPE_NM() {
    return MA_INSPE_NM;
  }
  public void set_MA_INSPE_NM(String MA_INSPE_NM) {
    this.MA_INSPE_NM = MA_INSPE_NM;
  }
  public QueryResult with_MA_INSPE_NM(String MA_INSPE_NM) {
    this.MA_INSPE_NM = MA_INSPE_NM;
    return this;
  }
  private String ORIG_RTRC_DIV_CD;
  public String get_ORIG_RTRC_DIV_CD() {
    return ORIG_RTRC_DIV_CD;
  }
  public void set_ORIG_RTRC_DIV_CD(String ORIG_RTRC_DIV_CD) {
    this.ORIG_RTRC_DIV_CD = ORIG_RTRC_DIV_CD;
  }
  public QueryResult with_ORIG_RTRC_DIV_CD(String ORIG_RTRC_DIV_CD) {
    this.ORIG_RTRC_DIV_CD = ORIG_RTRC_DIV_CD;
    return this;
  }
  private String PLR_STUP_YN;
  public String get_PLR_STUP_YN() {
    return PLR_STUP_YN;
  }
  public void set_PLR_STUP_YN(String PLR_STUP_YN) {
    this.PLR_STUP_YN = PLR_STUP_YN;
  }
  public QueryResult with_PLR_STUP_YN(String PLR_STUP_YN) {
    this.PLR_STUP_YN = PLR_STUP_YN;
    return this;
  }
  private String TRT_HDQT_ORG_CD;
  public String get_TRT_HDQT_ORG_CD() {
    return TRT_HDQT_ORG_CD;
  }
  public void set_TRT_HDQT_ORG_CD(String TRT_HDQT_ORG_CD) {
    this.TRT_HDQT_ORG_CD = TRT_HDQT_ORG_CD;
  }
  public QueryResult with_TRT_HDQT_ORG_CD(String TRT_HDQT_ORG_CD) {
    this.TRT_HDQT_ORG_CD = TRT_HDQT_ORG_CD;
    return this;
  }
  private String TRT_BCH_ORG_CD;
  public String get_TRT_BCH_ORG_CD() {
    return TRT_BCH_ORG_CD;
  }
  public void set_TRT_BCH_ORG_CD(String TRT_BCH_ORG_CD) {
    this.TRT_BCH_ORG_CD = TRT_BCH_ORG_CD;
  }
  public QueryResult with_TRT_BCH_ORG_CD(String TRT_BCH_ORG_CD) {
    this.TRT_BCH_ORG_CD = TRT_BCH_ORG_CD;
    return this;
  }
  private String TRT_BRCH_ORG_CD;
  public String get_TRT_BRCH_ORG_CD() {
    return TRT_BRCH_ORG_CD;
  }
  public void set_TRT_BRCH_ORG_CD(String TRT_BRCH_ORG_CD) {
    this.TRT_BRCH_ORG_CD = TRT_BRCH_ORG_CD;
  }
  public QueryResult with_TRT_BRCH_ORG_CD(String TRT_BRCH_ORG_CD) {
    this.TRT_BRCH_ORG_CD = TRT_BRCH_ORG_CD;
    return this;
  }
  private String TRTPE_ORG_ID;
  public String get_TRTPE_ORG_ID() {
    return TRTPE_ORG_ID;
  }
  public void set_TRTPE_ORG_ID(String TRTPE_ORG_ID) {
    this.TRTPE_ORG_ID = TRTPE_ORG_ID;
  }
  public QueryResult with_TRTPE_ORG_ID(String TRTPE_ORG_ID) {
    this.TRTPE_ORG_ID = TRTPE_ORG_ID;
    return this;
  }
  private String TRTPE_ORG_CD;
  public String get_TRTPE_ORG_CD() {
    return TRTPE_ORG_CD;
  }
  public void set_TRTPE_ORG_CD(String TRTPE_ORG_CD) {
    this.TRTPE_ORG_CD = TRTPE_ORG_CD;
  }
  public QueryResult with_TRTPE_ORG_CD(String TRTPE_ORG_CD) {
    this.TRTPE_ORG_CD = TRTPE_ORG_CD;
    return this;
  }
  private String CLM_TP_CD;
  public String get_CLM_TP_CD() {
    return CLM_TP_CD;
  }
  public void set_CLM_TP_CD(String CLM_TP_CD) {
    this.CLM_TP_CD = CLM_TP_CD;
  }
  public QueryResult with_CLM_TP_CD(String CLM_TP_CD) {
    this.CLM_TP_CD = CLM_TP_CD;
    return this;
  }
  private String DSS_CD_YY;
  public String get_DSS_CD_YY() {
    return DSS_CD_YY;
  }
  public void set_DSS_CD_YY(String DSS_CD_YY) {
    this.DSS_CD_YY = DSS_CD_YY;
  }
  public QueryResult with_DSS_CD_YY(String DSS_CD_YY) {
    this.DSS_CD_YY = DSS_CD_YY;
    return this;
  }
  private java.math.BigDecimal DSS_CD_SEQ;
  public java.math.BigDecimal get_DSS_CD_SEQ() {
    return DSS_CD_SEQ;
  }
  public void set_DSS_CD_SEQ(java.math.BigDecimal DSS_CD_SEQ) {
    this.DSS_CD_SEQ = DSS_CD_SEQ;
  }
  public QueryResult with_DSS_CD_SEQ(java.math.BigDecimal DSS_CD_SEQ) {
    this.DSS_CD_SEQ = DSS_CD_SEQ;
    return this;
  }
  private String CLM_STAT_CD;
  public String get_CLM_STAT_CD() {
    return CLM_STAT_CD;
  }
  public void set_CLM_STAT_CD(String CLM_STAT_CD) {
    this.CLM_STAT_CD = CLM_STAT_CD;
  }
  public QueryResult with_CLM_STAT_CD(String CLM_STAT_CD) {
    this.CLM_STAT_CD = CLM_STAT_CD;
    return this;
  }
  private String ACD_CAUS_LCTG_CD;
  public String get_ACD_CAUS_LCTG_CD() {
    return ACD_CAUS_LCTG_CD;
  }
  public void set_ACD_CAUS_LCTG_CD(String ACD_CAUS_LCTG_CD) {
    this.ACD_CAUS_LCTG_CD = ACD_CAUS_LCTG_CD;
  }
  public QueryResult with_ACD_CAUS_LCTG_CD(String ACD_CAUS_LCTG_CD) {
    this.ACD_CAUS_LCTG_CD = ACD_CAUS_LCTG_CD;
    return this;
  }
  private String ACD_CAUS_MCTG_CD;
  public String get_ACD_CAUS_MCTG_CD() {
    return ACD_CAUS_MCTG_CD;
  }
  public void set_ACD_CAUS_MCTG_CD(String ACD_CAUS_MCTG_CD) {
    this.ACD_CAUS_MCTG_CD = ACD_CAUS_MCTG_CD;
  }
  public QueryResult with_ACD_CAUS_MCTG_CD(String ACD_CAUS_MCTG_CD) {
    this.ACD_CAUS_MCTG_CD = ACD_CAUS_MCTG_CD;
    return this;
  }
  private String ACD_CAUS_SCTG_CD;
  public String get_ACD_CAUS_SCTG_CD() {
    return ACD_CAUS_SCTG_CD;
  }
  public void set_ACD_CAUS_SCTG_CD(String ACD_CAUS_SCTG_CD) {
    this.ACD_CAUS_SCTG_CD = ACD_CAUS_SCTG_CD;
  }
  public QueryResult with_ACD_CAUS_SCTG_CD(String ACD_CAUS_SCTG_CD) {
    this.ACD_CAUS_SCTG_CD = ACD_CAUS_SCTG_CD;
    return this;
  }
  private String ACD_CAUS_DCTG_CD;
  public String get_ACD_CAUS_DCTG_CD() {
    return ACD_CAUS_DCTG_CD;
  }
  public void set_ACD_CAUS_DCTG_CD(String ACD_CAUS_DCTG_CD) {
    this.ACD_CAUS_DCTG_CD = ACD_CAUS_DCTG_CD;
  }
  public QueryResult with_ACD_CAUS_DCTG_CD(String ACD_CAUS_DCTG_CD) {
    this.ACD_CAUS_DCTG_CD = ACD_CAUS_DCTG_CD;
    return this;
  }
  private String ACD_CAUS_DCTG2_CD;
  public String get_ACD_CAUS_DCTG2_CD() {
    return ACD_CAUS_DCTG2_CD;
  }
  public void set_ACD_CAUS_DCTG2_CD(String ACD_CAUS_DCTG2_CD) {
    this.ACD_CAUS_DCTG2_CD = ACD_CAUS_DCTG2_CD;
  }
  public QueryResult with_ACD_CAUS_DCTG2_CD(String ACD_CAUS_DCTG2_CD) {
    this.ACD_CAUS_DCTG2_CD = ACD_CAUS_DCTG2_CD;
    return this;
  }
  private String COMS_PART_ORG_ID;
  public String get_COMS_PART_ORG_ID() {
    return COMS_PART_ORG_ID;
  }
  public void set_COMS_PART_ORG_ID(String COMS_PART_ORG_ID) {
    this.COMS_PART_ORG_ID = COMS_PART_ORG_ID;
  }
  public QueryResult with_COMS_PART_ORG_ID(String COMS_PART_ORG_ID) {
    this.COMS_PART_ORG_ID = COMS_PART_ORG_ID;
    return this;
  }
  private String COMS_PART_ORG_CD;
  public String get_COMS_PART_ORG_CD() {
    return COMS_PART_ORG_CD;
  }
  public void set_COMS_PART_ORG_CD(String COMS_PART_ORG_CD) {
    this.COMS_PART_ORG_CD = COMS_PART_ORG_CD;
  }
  public QueryResult with_COMS_PART_ORG_CD(String COMS_PART_ORG_CD) {
    this.COMS_PART_ORG_CD = COMS_PART_ORG_CD;
    return this;
  }
  private String COMS_TEM_ORG_ID;
  public String get_COMS_TEM_ORG_ID() {
    return COMS_TEM_ORG_ID;
  }
  public void set_COMS_TEM_ORG_ID(String COMS_TEM_ORG_ID) {
    this.COMS_TEM_ORG_ID = COMS_TEM_ORG_ID;
  }
  public QueryResult with_COMS_TEM_ORG_ID(String COMS_TEM_ORG_ID) {
    this.COMS_TEM_ORG_ID = COMS_TEM_ORG_ID;
    return this;
  }
  private String COMS_TEM_ORG_CD;
  public String get_COMS_TEM_ORG_CD() {
    return COMS_TEM_ORG_CD;
  }
  public void set_COMS_TEM_ORG_CD(String COMS_TEM_ORG_CD) {
    this.COMS_TEM_ORG_CD = COMS_TEM_ORG_CD;
  }
  public QueryResult with_COMS_TEM_ORG_CD(String COMS_TEM_ORG_CD) {
    this.COMS_TEM_ORG_CD = COMS_TEM_ORG_CD;
    return this;
  }
  private String COMS_CHRPE_ORG_ID;
  public String get_COMS_CHRPE_ORG_ID() {
    return COMS_CHRPE_ORG_ID;
  }
  public void set_COMS_CHRPE_ORG_ID(String COMS_CHRPE_ORG_ID) {
    this.COMS_CHRPE_ORG_ID = COMS_CHRPE_ORG_ID;
  }
  public QueryResult with_COMS_CHRPE_ORG_ID(String COMS_CHRPE_ORG_ID) {
    this.COMS_CHRPE_ORG_ID = COMS_CHRPE_ORG_ID;
    return this;
  }
  private String CPIC_ORG_CD;
  public String get_CPIC_ORG_CD() {
    return CPIC_ORG_CD;
  }
  public void set_CPIC_ORG_CD(String CPIC_ORG_CD) {
    this.CPIC_ORG_CD = CPIC_ORG_CD;
  }
  public QueryResult with_CPIC_ORG_CD(String CPIC_ORG_CD) {
    this.CPIC_ORG_CD = CPIC_ORG_CD;
    return this;
  }
  private java.sql.Timestamp CNCLU_DT;
  public java.sql.Timestamp get_CNCLU_DT() {
    return CNCLU_DT;
  }
  public void set_CNCLU_DT(java.sql.Timestamp CNCLU_DT) {
    this.CNCLU_DT = CNCLU_DT;
  }
  public QueryResult with_CNCLU_DT(java.sql.Timestamp CNCLU_DT) {
    this.CNCLU_DT = CNCLU_DT;
    return this;
  }
  private java.sql.Timestamp EXMP_DCN_DT;
  public java.sql.Timestamp get_EXMP_DCN_DT() {
    return EXMP_DCN_DT;
  }
  public void set_EXMP_DCN_DT(java.sql.Timestamp EXMP_DCN_DT) {
    this.EXMP_DCN_DT = EXMP_DCN_DT;
  }
  public QueryResult with_EXMP_DCN_DT(java.sql.Timestamp EXMP_DCN_DT) {
    this.EXMP_DCN_DT = EXMP_DCN_DT;
    return this;
  }
  private String DAM_DGR_CD;
  public String get_DAM_DGR_CD() {
    return DAM_DGR_CD;
  }
  public void set_DAM_DGR_CD(String DAM_DGR_CD) {
    this.DAM_DGR_CD = DAM_DGR_CD;
  }
  public QueryResult with_DAM_DGR_CD(String DAM_DGR_CD) {
    this.DAM_DGR_CD = DAM_DGR_CD;
    return this;
  }
  private String AT_ISP_YN;
  public String get_AT_ISP_YN() {
    return AT_ISP_YN;
  }
  public void set_AT_ISP_YN(String AT_ISP_YN) {
    this.AT_ISP_YN = AT_ISP_YN;
  }
  public QueryResult with_AT_ISP_YN(String AT_ISP_YN) {
    this.AT_ISP_YN = AT_ISP_YN;
    return this;
  }
  private String ACD_CTR_OBJ_ID;
  public String get_ACD_CTR_OBJ_ID() {
    return ACD_CTR_OBJ_ID;
  }
  public void set_ACD_CTR_OBJ_ID(String ACD_CTR_OBJ_ID) {
    this.ACD_CTR_OBJ_ID = ACD_CTR_OBJ_ID;
  }
  public QueryResult with_ACD_CTR_OBJ_ID(String ACD_CTR_OBJ_ID) {
    this.ACD_CTR_OBJ_ID = ACD_CTR_OBJ_ID;
    return this;
  }
  private java.math.BigDecimal ACD_CTR_OBJ_HIS_SEQ;
  public java.math.BigDecimal get_ACD_CTR_OBJ_HIS_SEQ() {
    return ACD_CTR_OBJ_HIS_SEQ;
  }
  public void set_ACD_CTR_OBJ_HIS_SEQ(java.math.BigDecimal ACD_CTR_OBJ_HIS_SEQ) {
    this.ACD_CTR_OBJ_HIS_SEQ = ACD_CTR_OBJ_HIS_SEQ;
  }
  public QueryResult with_ACD_CTR_OBJ_HIS_SEQ(java.math.BigDecimal ACD_CTR_OBJ_HIS_SEQ) {
    this.ACD_CTR_OBJ_HIS_SEQ = ACD_CTR_OBJ_HIS_SEQ;
    return this;
  }
  private String ACD_OBJ_DIV_CD;
  public String get_ACD_OBJ_DIV_CD() {
    return ACD_OBJ_DIV_CD;
  }
  public void set_ACD_OBJ_DIV_CD(String ACD_OBJ_DIV_CD) {
    this.ACD_OBJ_DIV_CD = ACD_OBJ_DIV_CD;
  }
  public QueryResult with_ACD_OBJ_DIV_CD(String ACD_OBJ_DIV_CD) {
    this.ACD_OBJ_DIV_CD = ACD_OBJ_DIV_CD;
    return this;
  }
  private String ACD_OBJ_ID;
  public String get_ACD_OBJ_ID() {
    return ACD_OBJ_ID;
  }
  public void set_ACD_OBJ_ID(String ACD_OBJ_ID) {
    this.ACD_OBJ_ID = ACD_OBJ_ID;
  }
  public QueryResult with_ACD_OBJ_ID(String ACD_OBJ_ID) {
    this.ACD_OBJ_ID = ACD_OBJ_ID;
    return this;
  }
  private java.math.BigDecimal DAM_ORD;
  public java.math.BigDecimal get_DAM_ORD() {
    return DAM_ORD;
  }
  public void set_DAM_ORD(java.math.BigDecimal DAM_ORD) {
    this.DAM_ORD = DAM_ORD;
  }
  public QueryResult with_DAM_ORD(java.math.BigDecimal DAM_ORD) {
    this.DAM_ORD = DAM_ORD;
    return this;
  }
  private String CTR_OBJ_ID;
  public String get_CTR_OBJ_ID() {
    return CTR_OBJ_ID;
  }
  public void set_CTR_OBJ_ID(String CTR_OBJ_ID) {
    this.CTR_OBJ_ID = CTR_OBJ_ID;
  }
  public QueryResult with_CTR_OBJ_ID(String CTR_OBJ_ID) {
    this.CTR_OBJ_ID = CTR_OBJ_ID;
    return this;
  }
  private String CTR_OBJ_ADR_ID;
  public String get_CTR_OBJ_ADR_ID() {
    return CTR_OBJ_ADR_ID;
  }
  public void set_CTR_OBJ_ADR_ID(String CTR_OBJ_ADR_ID) {
    this.CTR_OBJ_ADR_ID = CTR_OBJ_ADR_ID;
  }
  public QueryResult with_CTR_OBJ_ADR_ID(String CTR_OBJ_ADR_ID) {
    this.CTR_OBJ_ADR_ID = CTR_OBJ_ADR_ID;
    return this;
  }
  private String OBJ_TP_CD;
  public String get_OBJ_TP_CD() {
    return OBJ_TP_CD;
  }
  public void set_OBJ_TP_CD(String OBJ_TP_CD) {
    this.OBJ_TP_CD = OBJ_TP_CD;
  }
  public QueryResult with_OBJ_TP_CD(String OBJ_TP_CD) {
    this.OBJ_TP_CD = OBJ_TP_CD;
    return this;
  }
  private String DMPE_CUS_ID;
  public String get_DMPE_CUS_ID() {
    return DMPE_CUS_ID;
  }
  public void set_DMPE_CUS_ID(String DMPE_CUS_ID) {
    this.DMPE_CUS_ID = DMPE_CUS_ID;
  }
  public QueryResult with_DMPE_CUS_ID(String DMPE_CUS_ID) {
    this.DMPE_CUS_ID = DMPE_CUS_ID;
    return this;
  }
  private String DMPO_NM;
  public String get_DMPO_NM() {
    return DMPO_NM;
  }
  public void set_DMPO_NM(String DMPO_NM) {
    this.DMPO_NM = DMPO_NM;
  }
  public QueryResult with_DMPO_NM(String DMPO_NM) {
    this.DMPO_NM = DMPO_NM;
    return this;
  }
  private String PVDS_YN;
  public String get_PVDS_YN() {
    return PVDS_YN;
  }
  public void set_PVDS_YN(String PVDS_YN) {
    this.PVDS_YN = PVDS_YN;
  }
  public QueryResult with_PVDS_YN(String PVDS_YN) {
    this.PVDS_YN = PVDS_YN;
    return this;
  }
  private String TCTR_DMPE_JOB_GRD_CD;
  public String get_TCTR_DMPE_JOB_GRD_CD() {
    return TCTR_DMPE_JOB_GRD_CD;
  }
  public void set_TCTR_DMPE_JOB_GRD_CD(String TCTR_DMPE_JOB_GRD_CD) {
    this.TCTR_DMPE_JOB_GRD_CD = TCTR_DMPE_JOB_GRD_CD;
  }
  public QueryResult with_TCTR_DMPE_JOB_GRD_CD(String TCTR_DMPE_JOB_GRD_CD) {
    this.TCTR_DMPE_JOB_GRD_CD = TCTR_DMPE_JOB_GRD_CD;
    return this;
  }
  private String TCTR_DMPE_JOB_CD;
  public String get_TCTR_DMPE_JOB_CD() {
    return TCTR_DMPE_JOB_CD;
  }
  public void set_TCTR_DMPE_JOB_CD(String TCTR_DMPE_JOB_CD) {
    this.TCTR_DMPE_JOB_CD = TCTR_DMPE_JOB_CD;
  }
  public QueryResult with_TCTR_DMPE_JOB_CD(String TCTR_DMPE_JOB_CD) {
    this.TCTR_DMPE_JOB_CD = TCTR_DMPE_JOB_CD;
    return this;
  }
  private String TACD_DMPE_JOB_GRD_CD;
  public String get_TACD_DMPE_JOB_GRD_CD() {
    return TACD_DMPE_JOB_GRD_CD;
  }
  public void set_TACD_DMPE_JOB_GRD_CD(String TACD_DMPE_JOB_GRD_CD) {
    this.TACD_DMPE_JOB_GRD_CD = TACD_DMPE_JOB_GRD_CD;
  }
  public QueryResult with_TACD_DMPE_JOB_GRD_CD(String TACD_DMPE_JOB_GRD_CD) {
    this.TACD_DMPE_JOB_GRD_CD = TACD_DMPE_JOB_GRD_CD;
    return this;
  }
  private String TACD_DMPE_JOB_CD;
  public String get_TACD_DMPE_JOB_CD() {
    return TACD_DMPE_JOB_CD;
  }
  public void set_TACD_DMPE_JOB_CD(String TACD_DMPE_JOB_CD) {
    this.TACD_DMPE_JOB_CD = TACD_DMPE_JOB_CD;
  }
  public QueryResult with_TACD_DMPE_JOB_CD(String TACD_DMPE_JOB_CD) {
    this.TACD_DMPE_JOB_CD = TACD_DMPE_JOB_CD;
    return this;
  }
  private String OWNR_NM;
  public String get_OWNR_NM() {
    return OWNR_NM;
  }
  public void set_OWNR_NM(String OWNR_NM) {
    this.OWNR_NM = OWNR_NM;
  }
  public QueryResult with_OWNR_NM(String OWNR_NM) {
    this.OWNR_NM = OWNR_NM;
    return this;
  }
  private java.math.BigDecimal DMPE_AGE;
  public java.math.BigDecimal get_DMPE_AGE() {
    return DMPE_AGE;
  }
  public void set_DMPE_AGE(java.math.BigDecimal DMPE_AGE) {
    this.DMPE_AGE = DMPE_AGE;
  }
  public QueryResult with_DMPE_AGE(java.math.BigDecimal DMPE_AGE) {
    this.DMPE_AGE = DMPE_AGE;
    return this;
  }
  private String TNG_DIV_CD;
  public String get_TNG_DIV_CD() {
    return TNG_DIV_CD;
  }
  public void set_TNG_DIV_CD(String TNG_DIV_CD) {
    this.TNG_DIV_CD = TNG_DIV_CD;
  }
  public QueryResult with_TNG_DIV_CD(String TNG_DIV_CD) {
    this.TNG_DIV_CD = TNG_DIV_CD;
    return this;
  }
  private String OBJ_GRD_CD;
  public String get_OBJ_GRD_CD() {
    return OBJ_GRD_CD;
  }
  public void set_OBJ_GRD_CD(String OBJ_GRD_CD) {
    this.OBJ_GRD_CD = OBJ_GRD_CD;
  }
  public QueryResult with_OBJ_GRD_CD(String OBJ_GRD_CD) {
    this.OBJ_GRD_CD = OBJ_GRD_CD;
    return this;
  }
  private String OPN_JBCL_CD;
  public String get_OPN_JBCL_CD() {
    return OPN_JBCL_CD;
  }
  public void set_OPN_JBCL_CD(String OPN_JBCL_CD) {
    this.OPN_JBCL_CD = OPN_JBCL_CD;
  }
  public QueryResult with_OPN_JBCL_CD(String OPN_JBCL_CD) {
    this.OPN_JBCL_CD = OPN_JBCL_CD;
    return this;
  }
  private String OPJB_NM;
  public String get_OPJB_NM() {
    return OPJB_NM;
  }
  public void set_OPJB_NM(String OPJB_NM) {
    this.OPJB_NM = OPJB_NM;
  }
  public QueryResult with_OPJB_NM(String OPJB_NM) {
    this.OPJB_NM = OPJB_NM;
    return this;
  }
  private String OBJ_CD;
  public String get_OBJ_CD() {
    return OBJ_CD;
  }
  public void set_OBJ_CD(String OBJ_CD) {
    this.OBJ_CD = OBJ_CD;
  }
  public QueryResult with_OBJ_CD(String OBJ_CD) {
    this.OBJ_CD = OBJ_CD;
    return this;
  }
  private String DMOB_LCTG_CD;
  public String get_DMOB_LCTG_CD() {
    return DMOB_LCTG_CD;
  }
  public void set_DMOB_LCTG_CD(String DMOB_LCTG_CD) {
    this.DMOB_LCTG_CD = DMOB_LCTG_CD;
  }
  public QueryResult with_DMOB_LCTG_CD(String DMOB_LCTG_CD) {
    this.DMOB_LCTG_CD = DMOB_LCTG_CD;
    return this;
  }
  private String DMOB_MCTG_CD;
  public String get_DMOB_MCTG_CD() {
    return DMOB_MCTG_CD;
  }
  public void set_DMOB_MCTG_CD(String DMOB_MCTG_CD) {
    this.DMOB_MCTG_CD = DMOB_MCTG_CD;
  }
  public QueryResult with_DMOB_MCTG_CD(String DMOB_MCTG_CD) {
    this.DMOB_MCTG_CD = DMOB_MCTG_CD;
    return this;
  }
  private String DMOB_SCTG_CD;
  public String get_DMOB_SCTG_CD() {
    return DMOB_SCTG_CD;
  }
  public void set_DMOB_SCTG_CD(String DMOB_SCTG_CD) {
    this.DMOB_SCTG_CD = DMOB_SCTG_CD;
  }
  public QueryResult with_DMOB_SCTG_CD(String DMOB_SCTG_CD) {
    this.DMOB_SCTG_CD = DMOB_SCTG_CD;
    return this;
  }
  private String DMOB_TPIDS_LCTG_CD;
  public String get_DMOB_TPIDS_LCTG_CD() {
    return DMOB_TPIDS_LCTG_CD;
  }
  public void set_DMOB_TPIDS_LCTG_CD(String DMOB_TPIDS_LCTG_CD) {
    this.DMOB_TPIDS_LCTG_CD = DMOB_TPIDS_LCTG_CD;
  }
  public QueryResult with_DMOB_TPIDS_LCTG_CD(String DMOB_TPIDS_LCTG_CD) {
    this.DMOB_TPIDS_LCTG_CD = DMOB_TPIDS_LCTG_CD;
    return this;
  }
  private String DMOB_TPIDS_MCTG_CD;
  public String get_DMOB_TPIDS_MCTG_CD() {
    return DMOB_TPIDS_MCTG_CD;
  }
  public void set_DMOB_TPIDS_MCTG_CD(String DMOB_TPIDS_MCTG_CD) {
    this.DMOB_TPIDS_MCTG_CD = DMOB_TPIDS_MCTG_CD;
  }
  public QueryResult with_DMOB_TPIDS_MCTG_CD(String DMOB_TPIDS_MCTG_CD) {
    this.DMOB_TPIDS_MCTG_CD = DMOB_TPIDS_MCTG_CD;
    return this;
  }
  private String DMOB_TPIDS_SCTG_CD;
  public String get_DMOB_TPIDS_SCTG_CD() {
    return DMOB_TPIDS_SCTG_CD;
  }
  public void set_DMOB_TPIDS_SCTG_CD(String DMOB_TPIDS_SCTG_CD) {
    this.DMOB_TPIDS_SCTG_CD = DMOB_TPIDS_SCTG_CD;
  }
  public QueryResult with_DMOB_TPIDS_SCTG_CD(String DMOB_TPIDS_SCTG_CD) {
    this.DMOB_TPIDS_SCTG_CD = DMOB_TPIDS_SCTG_CD;
    return this;
  }
  private String DMOB_TPIDS_DCTG_CD;
  public String get_DMOB_TPIDS_DCTG_CD() {
    return DMOB_TPIDS_DCTG_CD;
  }
  public void set_DMOB_TPIDS_DCTG_CD(String DMOB_TPIDS_DCTG_CD) {
    this.DMOB_TPIDS_DCTG_CD = DMOB_TPIDS_DCTG_CD;
  }
  public QueryResult with_DMOB_TPIDS_DCTG_CD(String DMOB_TPIDS_DCTG_CD) {
    this.DMOB_TPIDS_DCTG_CD = DMOB_TPIDS_DCTG_CD;
    return this;
  }
  private String MCSH_FSHBT_DIV_CD;
  public String get_MCSH_FSHBT_DIV_CD() {
    return MCSH_FSHBT_DIV_CD;
  }
  public void set_MCSH_FSHBT_DIV_CD(String MCSH_FSHBT_DIV_CD) {
    this.MCSH_FSHBT_DIV_CD = MCSH_FSHBT_DIV_CD;
  }
  public QueryResult with_MCSH_FSHBT_DIV_CD(String MCSH_FSHBT_DIV_CD) {
    this.MCSH_FSHBT_DIV_CD = MCSH_FSHBT_DIV_CD;
    return this;
  }
  private java.math.BigDecimal SHAG;
  public java.math.BigDecimal get_SHAG() {
    return SHAG;
  }
  public void set_SHAG(java.math.BigDecimal SHAG) {
    this.SHAG = SHAG;
  }
  public QueryResult with_SHAG(java.math.BigDecimal SHAG) {
    this.SHAG = SHAG;
    return this;
  }
  private String SHP_TP_CD;
  public String get_SHP_TP_CD() {
    return SHP_TP_CD;
  }
  public void set_SHP_TP_CD(String SHP_TP_CD) {
    this.SHP_TP_CD = SHP_TP_CD;
  }
  public QueryResult with_SHP_TP_CD(String SHP_TP_CD) {
    this.SHP_TP_CD = SHP_TP_CD;
    return this;
  }
  private String SHP_CD;
  public String get_SHP_CD() {
    return SHP_CD;
  }
  public void set_SHP_CD(String SHP_CD) {
    this.SHP_CD = SHP_CD;
  }
  public QueryResult with_SHP_CD(String SHP_CD) {
    this.SHP_CD = SHP_CD;
    return this;
  }
  private String ARCRF_REG_NO;
  public String get_ARCRF_REG_NO() {
    return ARCRF_REG_NO;
  }
  public void set_ARCRF_REG_NO(String ARCRF_REG_NO) {
    this.ARCRF_REG_NO = ARCRF_REG_NO;
  }
  public QueryResult with_ARCRF_REG_NO(String ARCRF_REG_NO) {
    this.ARCRF_REG_NO = ARCRF_REG_NO;
    return this;
  }
  private String CARG_TRN_ITM_CD;
  public String get_CARG_TRN_ITM_CD() {
    return CARG_TRN_ITM_CD;
  }
  public void set_CARG_TRN_ITM_CD(String CARG_TRN_ITM_CD) {
    this.CARG_TRN_ITM_CD = CARG_TRN_ITM_CD;
  }
  public QueryResult with_CARG_TRN_ITM_CD(String CARG_TRN_ITM_CD) {
    this.CARG_TRN_ITM_CD = CARG_TRN_ITM_CD;
    return this;
  }
  private String DTH_YN;
  public String get_DTH_YN() {
    return DTH_YN;
  }
  public void set_DTH_YN(String DTH_YN) {
    this.DTH_YN = DTH_YN;
  }
  public QueryResult with_DTH_YN(String DTH_YN) {
    this.DTH_YN = DTH_YN;
    return this;
  }
  private String AFOBS_YN;
  public String get_AFOBS_YN() {
    return AFOBS_YN;
  }
  public void set_AFOBS_YN(String AFOBS_YN) {
    this.AFOBS_YN = AFOBS_YN;
  }
  public QueryResult with_AFOBS_YN(String AFOBS_YN) {
    this.AFOBS_YN = AFOBS_YN;
    return this;
  }
  private String HSP_MD_EXP_YN;
  public String get_HSP_MD_EXP_YN() {
    return HSP_MD_EXP_YN;
  }
  public void set_HSP_MD_EXP_YN(String HSP_MD_EXP_YN) {
    this.HSP_MD_EXP_YN = HSP_MD_EXP_YN;
  }
  public QueryResult with_HSP_MD_EXP_YN(String HSP_MD_EXP_YN) {
    this.HSP_MD_EXP_YN = HSP_MD_EXP_YN;
    return this;
  }
  private String GHR_MD_EXP_YN;
  public String get_GHR_MD_EXP_YN() {
    return GHR_MD_EXP_YN;
  }
  public void set_GHR_MD_EXP_YN(String GHR_MD_EXP_YN) {
    this.GHR_MD_EXP_YN = GHR_MD_EXP_YN;
  }
  public QueryResult with_GHR_MD_EXP_YN(String GHR_MD_EXP_YN) {
    this.GHR_MD_EXP_YN = GHR_MD_EXP_YN;
    return this;
  }
  private String PSC_MD_EXP_YN;
  public String get_PSC_MD_EXP_YN() {
    return PSC_MD_EXP_YN;
  }
  public void set_PSC_MD_EXP_YN(String PSC_MD_EXP_YN) {
    this.PSC_MD_EXP_YN = PSC_MD_EXP_YN;
  }
  public QueryResult with_PSC_MD_EXP_YN(String PSC_MD_EXP_YN) {
    this.PSC_MD_EXP_YN = PSC_MD_EXP_YN;
    return this;
  }
  private String HSP_DDPY_YN;
  public String get_HSP_DDPY_YN() {
    return HSP_DDPY_YN;
  }
  public void set_HSP_DDPY_YN(String HSP_DDPY_YN) {
    this.HSP_DDPY_YN = HSP_DDPY_YN;
  }
  public QueryResult with_HSP_DDPY_YN(String HSP_DDPY_YN) {
    this.HSP_DDPY_YN = HSP_DDPY_YN;
    return this;
  }
  private String LAST_DGN_YN;
  public String get_LAST_DGN_YN() {
    return LAST_DGN_YN;
  }
  public void set_LAST_DGN_YN(String LAST_DGN_YN) {
    this.LAST_DGN_YN = LAST_DGN_YN;
  }
  public QueryResult with_LAST_DGN_YN(String LAST_DGN_YN) {
    this.LAST_DGN_YN = LAST_DGN_YN;
    return this;
  }
  private String SROP_YN;
  public String get_SROP_YN() {
    return SROP_YN;
  }
  public void set_SROP_YN(String SROP_YN) {
    this.SROP_YN = SROP_YN;
  }
  public QueryResult with_SROP_YN(String SROP_YN) {
    this.SROP_YN = SROP_YN;
    return this;
  }
  private String EXP_YN;
  public String get_EXP_YN() {
    return EXP_YN;
  }
  public void set_EXP_YN(String EXP_YN) {
    this.EXP_YN = EXP_YN;
  }
  public QueryResult with_EXP_YN(String EXP_YN) {
    this.EXP_YN = EXP_YN;
    return this;
  }
  private String SROP_BDW_YN;
  public String get_SROP_BDW_YN() {
    return SROP_BDW_YN;
  }
  public void set_SROP_BDW_YN(String SROP_BDW_YN) {
    this.SROP_BDW_YN = SROP_BDW_YN;
  }
  public QueryResult with_SROP_BDW_YN(String SROP_BDW_YN) {
    this.SROP_BDW_YN = SROP_BDW_YN;
    return this;
  }
  private String OS_ID;
  public String get_OS_ID() {
    return OS_ID;
  }
  public void set_OS_ID(String OS_ID) {
    this.OS_ID = OS_ID;
  }
  public QueryResult with_OS_ID(String OS_ID) {
    this.OS_ID = OS_ID;
    return this;
  }
  private java.math.BigDecimal OS_HIS_SEQ;
  public java.math.BigDecimal get_OS_HIS_SEQ() {
    return OS_HIS_SEQ;
  }
  public void set_OS_HIS_SEQ(java.math.BigDecimal OS_HIS_SEQ) {
    this.OS_HIS_SEQ = OS_HIS_SEQ;
  }
  public QueryResult with_OS_HIS_SEQ(java.math.BigDecimal OS_HIS_SEQ) {
    this.OS_HIS_SEQ = OS_HIS_SEQ;
    return this;
  }
  private java.math.BigDecimal OS_SEQ;
  public java.math.BigDecimal get_OS_SEQ() {
    return OS_SEQ;
  }
  public void set_OS_SEQ(java.math.BigDecimal OS_SEQ) {
    this.OS_SEQ = OS_SEQ;
  }
  public QueryResult with_OS_SEQ(java.math.BigDecimal OS_SEQ) {
    this.OS_SEQ = OS_SEQ;
    return this;
  }
  private String OS_DIV_CD;
  public String get_OS_DIV_CD() {
    return OS_DIV_CD;
  }
  public void set_OS_DIV_CD(String OS_DIV_CD) {
    this.OS_DIV_CD = OS_DIV_CD;
  }
  public QueryResult with_OS_DIV_CD(String OS_DIV_CD) {
    this.OS_DIV_CD = OS_DIV_CD;
    return this;
  }
  private String DCN_ID;
  public String get_DCN_ID() {
    return DCN_ID;
  }
  public void set_DCN_ID(String DCN_ID) {
    this.DCN_ID = DCN_ID;
  }
  public QueryResult with_DCN_ID(String DCN_ID) {
    this.DCN_ID = DCN_ID;
    return this;
  }
  private java.math.BigDecimal DCN_HIS_SEQ;
  public java.math.BigDecimal get_DCN_HIS_SEQ() {
    return DCN_HIS_SEQ;
  }
  public void set_DCN_HIS_SEQ(java.math.BigDecimal DCN_HIS_SEQ) {
    this.DCN_HIS_SEQ = DCN_HIS_SEQ;
  }
  public QueryResult with_DCN_HIS_SEQ(java.math.BigDecimal DCN_HIS_SEQ) {
    this.DCN_HIS_SEQ = DCN_HIS_SEQ;
    return this;
  }
  private java.math.BigDecimal DCN_SEQ;
  public java.math.BigDecimal get_DCN_SEQ() {
    return DCN_SEQ;
  }
  public void set_DCN_SEQ(java.math.BigDecimal DCN_SEQ) {
    this.DCN_SEQ = DCN_SEQ;
  }
  public QueryResult with_DCN_SEQ(java.math.BigDecimal DCN_SEQ) {
    this.DCN_SEQ = DCN_SEQ;
    return this;
  }
  private String DCN_DIV_CD;
  public String get_DCN_DIV_CD() {
    return DCN_DIV_CD;
  }
  public void set_DCN_DIV_CD(String DCN_DIV_CD) {
    this.DCN_DIV_CD = DCN_DIV_CD;
  }
  public QueryResult with_DCN_DIV_CD(String DCN_DIV_CD) {
    this.DCN_DIV_CD = DCN_DIV_CD;
    return this;
  }
  private String CNCLU_ID;
  public String get_CNCLU_ID() {
    return CNCLU_ID;
  }
  public void set_CNCLU_ID(String CNCLU_ID) {
    this.CNCLU_ID = CNCLU_ID;
  }
  public QueryResult with_CNCLU_ID(String CNCLU_ID) {
    this.CNCLU_ID = CNCLU_ID;
    return this;
  }
  private java.math.BigDecimal CNCLU_HIS_SEQ;
  public java.math.BigDecimal get_CNCLU_HIS_SEQ() {
    return CNCLU_HIS_SEQ;
  }
  public void set_CNCLU_HIS_SEQ(java.math.BigDecimal CNCLU_HIS_SEQ) {
    this.CNCLU_HIS_SEQ = CNCLU_HIS_SEQ;
  }
  public QueryResult with_CNCLU_HIS_SEQ(java.math.BigDecimal CNCLU_HIS_SEQ) {
    this.CNCLU_HIS_SEQ = CNCLU_HIS_SEQ;
    return this;
  }
  private String CNCLU_DIV_CD;
  public String get_CNCLU_DIV_CD() {
    return CNCLU_DIV_CD;
  }
  public void set_CNCLU_DIV_CD(String CNCLU_DIV_CD) {
    this.CNCLU_DIV_CD = CNCLU_DIV_CD;
  }
  public QueryResult with_CNCLU_DIV_CD(String CNCLU_DIV_CD) {
    this.CNCLU_DIV_CD = CNCLU_DIV_CD;
    return this;
  }
  private String CNCLU_DATA_DIV_CD;
  public String get_CNCLU_DATA_DIV_CD() {
    return CNCLU_DATA_DIV_CD;
  }
  public void set_CNCLU_DATA_DIV_CD(String CNCLU_DATA_DIV_CD) {
    this.CNCLU_DATA_DIV_CD = CNCLU_DATA_DIV_CD;
  }
  public QueryResult with_CNCLU_DATA_DIV_CD(String CNCLU_DATA_DIV_CD) {
    this.CNCLU_DATA_DIV_CD = CNCLU_DATA_DIV_CD;
    return this;
  }
  private String COV_INS_DATA_DIV_CD;
  public String get_COV_INS_DATA_DIV_CD() {
    return COV_INS_DATA_DIV_CD;
  }
  public void set_COV_INS_DATA_DIV_CD(String COV_INS_DATA_DIV_CD) {
    this.COV_INS_DATA_DIV_CD = COV_INS_DATA_DIV_CD;
  }
  public QueryResult with_COV_INS_DATA_DIV_CD(String COV_INS_DATA_DIV_CD) {
    this.COV_INS_DATA_DIV_CD = COV_INS_DATA_DIV_CD;
    return this;
  }
  private java.math.BigDecimal COV_INS_HIS_SEQ;
  public java.math.BigDecimal get_COV_INS_HIS_SEQ() {
    return COV_INS_HIS_SEQ;
  }
  public void set_COV_INS_HIS_SEQ(java.math.BigDecimal COV_INS_HIS_SEQ) {
    this.COV_INS_HIS_SEQ = COV_INS_HIS_SEQ;
  }
  public QueryResult with_COV_INS_HIS_SEQ(java.math.BigDecimal COV_INS_HIS_SEQ) {
    this.COV_INS_HIS_SEQ = COV_INS_HIS_SEQ;
    return this;
  }
  private java.sql.Timestamp INS_AMT_APVL_DT;
  public java.sql.Timestamp get_INS_AMT_APVL_DT() {
    return INS_AMT_APVL_DT;
  }
  public void set_INS_AMT_APVL_DT(java.sql.Timestamp INS_AMT_APVL_DT) {
    this.INS_AMT_APVL_DT = INS_AMT_APVL_DT;
  }
  public QueryResult with_INS_AMT_APVL_DT(java.sql.Timestamp INS_AMT_APVL_DT) {
    this.INS_AMT_APVL_DT = INS_AMT_APVL_DT;
    return this;
  }
  private java.math.BigDecimal CSS_COV_INS_HIS_SEQ;
  public java.math.BigDecimal get_CSS_COV_INS_HIS_SEQ() {
    return CSS_COV_INS_HIS_SEQ;
  }
  public void set_CSS_COV_INS_HIS_SEQ(java.math.BigDecimal CSS_COV_INS_HIS_SEQ) {
    this.CSS_COV_INS_HIS_SEQ = CSS_COV_INS_HIS_SEQ;
  }
  public QueryResult with_CSS_COV_INS_HIS_SEQ(java.math.BigDecimal CSS_COV_INS_HIS_SEQ) {
    this.CSS_COV_INS_HIS_SEQ = CSS_COV_INS_HIS_SEQ;
    return this;
  }
  private String SPTPY_DIV_CD;
  public String get_SPTPY_DIV_CD() {
    return SPTPY_DIV_CD;
  }
  public void set_SPTPY_DIV_CD(String SPTPY_DIV_CD) {
    this.SPTPY_DIV_CD = SPTPY_DIV_CD;
  }
  public QueryResult with_SPTPY_DIV_CD(String SPTPY_DIV_CD) {
    this.SPTPY_DIV_CD = SPTPY_DIV_CD;
    return this;
  }
  private java.math.BigDecimal ISD_PCS_SEQ;
  public java.math.BigDecimal get_ISD_PCS_SEQ() {
    return ISD_PCS_SEQ;
  }
  public void set_ISD_PCS_SEQ(java.math.BigDecimal ISD_PCS_SEQ) {
    this.ISD_PCS_SEQ = ISD_PCS_SEQ;
  }
  public QueryResult with_ISD_PCS_SEQ(java.math.BigDecimal ISD_PCS_SEQ) {
    this.ISD_PCS_SEQ = ISD_PCS_SEQ;
    return this;
  }
  private String COV_CD;
  public String get_COV_CD() {
    return COV_CD;
  }
  public void set_COV_CD(String COV_CD) {
    this.COV_CD = COV_CD;
  }
  public QueryResult with_COV_CD(String COV_CD) {
    this.COV_CD = COV_CD;
    return this;
  }
  private String INS_AMT_EXT_EXP_DIV_CD;
  public String get_INS_AMT_EXT_EXP_DIV_CD() {
    return INS_AMT_EXT_EXP_DIV_CD;
  }
  public void set_INS_AMT_EXT_EXP_DIV_CD(String INS_AMT_EXT_EXP_DIV_CD) {
    this.INS_AMT_EXT_EXP_DIV_CD = INS_AMT_EXT_EXP_DIV_CD;
  }
  public QueryResult with_INS_AMT_EXT_EXP_DIV_CD(String INS_AMT_EXT_EXP_DIV_CD) {
    this.INS_AMT_EXT_EXP_DIV_CD = INS_AMT_EXT_EXP_DIV_CD;
    return this;
  }
  private String GURT_UNT_CD;
  public String get_GURT_UNT_CD() {
    return GURT_UNT_CD;
  }
  public void set_GURT_UNT_CD(String GURT_UNT_CD) {
    this.GURT_UNT_CD = GURT_UNT_CD;
  }
  public QueryResult with_GURT_UNT_CD(String GURT_UNT_CD) {
    this.GURT_UNT_CD = GURT_UNT_CD;
    return this;
  }
  private String RSK_UNT_CD;
  public String get_RSK_UNT_CD() {
    return RSK_UNT_CD;
  }
  public void set_RSK_UNT_CD(String RSK_UNT_CD) {
    this.RSK_UNT_CD = RSK_UNT_CD;
  }
  public QueryResult with_RSK_UNT_CD(String RSK_UNT_CD) {
    this.RSK_UNT_CD = RSK_UNT_CD;
    return this;
  }
  private String CLADJ_DIV_CTG_CD;
  public String get_CLADJ_DIV_CTG_CD() {
    return CLADJ_DIV_CTG_CD;
  }
  public void set_CLADJ_DIV_CTG_CD(String CLADJ_DIV_CTG_CD) {
    this.CLADJ_DIV_CTG_CD = CLADJ_DIV_CTG_CD;
  }
  public QueryResult with_CLADJ_DIV_CTG_CD(String CLADJ_DIV_CTG_CD) {
    this.CLADJ_DIV_CTG_CD = CLADJ_DIV_CTG_CD;
    return this;
  }
  private String BAS_SIC_DIV_CD;
  public String get_BAS_SIC_DIV_CD() {
    return BAS_SIC_DIV_CD;
  }
  public void set_BAS_SIC_DIV_CD(String BAS_SIC_DIV_CD) {
    this.BAS_SIC_DIV_CD = BAS_SIC_DIV_CD;
  }
  public QueryResult with_BAS_SIC_DIV_CD(String BAS_SIC_DIV_CD) {
    this.BAS_SIC_DIV_CD = BAS_SIC_DIV_CD;
    return this;
  }
  private java.sql.Timestamp COV_INS_BGN_DT;
  public java.sql.Timestamp get_COV_INS_BGN_DT() {
    return COV_INS_BGN_DT;
  }
  public void set_COV_INS_BGN_DT(java.sql.Timestamp COV_INS_BGN_DT) {
    this.COV_INS_BGN_DT = COV_INS_BGN_DT;
  }
  public QueryResult with_COV_INS_BGN_DT(java.sql.Timestamp COV_INS_BGN_DT) {
    this.COV_INS_BGN_DT = COV_INS_BGN_DT;
    return this;
  }
  private java.sql.Timestamp COV_INS_ED_DT;
  public java.sql.Timestamp get_COV_INS_ED_DT() {
    return COV_INS_ED_DT;
  }
  public void set_COV_INS_ED_DT(java.sql.Timestamp COV_INS_ED_DT) {
    this.COV_INS_ED_DT = COV_INS_ED_DT;
  }
  public QueryResult with_COV_INS_ED_DT(java.sql.Timestamp COV_INS_ED_DT) {
    this.COV_INS_ED_DT = COV_INS_ED_DT;
    return this;
  }
  private String INSD_AMT_CUR_CD;
  public String get_INSD_AMT_CUR_CD() {
    return INSD_AMT_CUR_CD;
  }
  public void set_INSD_AMT_CUR_CD(String INSD_AMT_CUR_CD) {
    this.INSD_AMT_CUR_CD = INSD_AMT_CUR_CD;
  }
  public QueryResult with_INSD_AMT_CUR_CD(String INSD_AMT_CUR_CD) {
    this.INSD_AMT_CUR_CD = INSD_AMT_CUR_CD;
    return this;
  }
  private java.math.BigDecimal CUR_INSD_AMT;
  public java.math.BigDecimal get_CUR_INSD_AMT() {
    return CUR_INSD_AMT;
  }
  public void set_CUR_INSD_AMT(java.math.BigDecimal CUR_INSD_AMT) {
    this.CUR_INSD_AMT = CUR_INSD_AMT;
  }
  public QueryResult with_CUR_INSD_AMT(java.math.BigDecimal CUR_INSD_AMT) {
    this.CUR_INSD_AMT = CUR_INSD_AMT;
    return this;
  }
  private java.math.BigDecimal INSD_AMT;
  public java.math.BigDecimal get_INSD_AMT() {
    return INSD_AMT;
  }
  public void set_INSD_AMT(java.math.BigDecimal INSD_AMT) {
    this.INSD_AMT = INSD_AMT;
  }
  public QueryResult with_INSD_AMT(java.math.BigDecimal INSD_AMT) {
    this.INSD_AMT = INSD_AMT;
    return this;
  }
  private java.math.BigDecimal PPS_COMS_LM_AMT;
  public java.math.BigDecimal get_PPS_COMS_LM_AMT() {
    return PPS_COMS_LM_AMT;
  }
  public void set_PPS_COMS_LM_AMT(java.math.BigDecimal PPS_COMS_LM_AMT) {
    this.PPS_COMS_LM_AMT = PPS_COMS_LM_AMT;
  }
  public QueryResult with_PPS_COMS_LM_AMT(java.math.BigDecimal PPS_COMS_LM_AMT) {
    this.PPS_COMS_LM_AMT = PPS_COMS_LM_AMT;
    return this;
  }
  private java.math.BigDecimal PACD_COMS_LM_AMT;
  public java.math.BigDecimal get_PACD_COMS_LM_AMT() {
    return PACD_COMS_LM_AMT;
  }
  public void set_PACD_COMS_LM_AMT(java.math.BigDecimal PACD_COMS_LM_AMT) {
    this.PACD_COMS_LM_AMT = PACD_COMS_LM_AMT;
  }
  public QueryResult with_PACD_COMS_LM_AMT(java.math.BigDecimal PACD_COMS_LM_AMT) {
    this.PACD_COMS_LM_AMT = PACD_COMS_LM_AMT;
    return this;
  }
  private String LDCO_CTR_BZAC_CD;
  public String get_LDCO_CTR_BZAC_CD() {
    return LDCO_CTR_BZAC_CD;
  }
  public void set_LDCO_CTR_BZAC_CD(String LDCO_CTR_BZAC_CD) {
    this.LDCO_CTR_BZAC_CD = LDCO_CTR_BZAC_CD;
  }
  public QueryResult with_LDCO_CTR_BZAC_CD(String LDCO_CTR_BZAC_CD) {
    this.LDCO_CTR_BZAC_CD = LDCO_CTR_BZAC_CD;
    return this;
  }
  private String COI_CTR_BZAC_CD;
  public String get_COI_CTR_BZAC_CD() {
    return COI_CTR_BZAC_CD;
  }
  public void set_COI_CTR_BZAC_CD(String COI_CTR_BZAC_CD) {
    this.COI_CTR_BZAC_CD = COI_CTR_BZAC_CD;
  }
  public QueryResult with_COI_CTR_BZAC_CD(String COI_CTR_BZAC_CD) {
    this.COI_CTR_BZAC_CD = COI_CTR_BZAC_CD;
    return this;
  }
  private java.math.BigDecimal CSS_COV_INS_SEQ;
  public java.math.BigDecimal get_CSS_COV_INS_SEQ() {
    return CSS_COV_INS_SEQ;
  }
  public void set_CSS_COV_INS_SEQ(java.math.BigDecimal CSS_COV_INS_SEQ) {
    this.CSS_COV_INS_SEQ = CSS_COV_INS_SEQ;
  }
  public QueryResult with_CSS_COV_INS_SEQ(java.math.BigDecimal CSS_COV_INS_SEQ) {
    this.CSS_COV_INS_SEQ = CSS_COV_INS_SEQ;
    return this;
  }
  private java.math.BigDecimal JNT_ACP_COV_INS_SEQ;
  public java.math.BigDecimal get_JNT_ACP_COV_INS_SEQ() {
    return JNT_ACP_COV_INS_SEQ;
  }
  public void set_JNT_ACP_COV_INS_SEQ(java.math.BigDecimal JNT_ACP_COV_INS_SEQ) {
    this.JNT_ACP_COV_INS_SEQ = JNT_ACP_COV_INS_SEQ;
  }
  public QueryResult with_JNT_ACP_COV_INS_SEQ(java.math.BigDecimal JNT_ACP_COV_INS_SEQ) {
    this.JNT_ACP_COV_INS_SEQ = JNT_ACP_COV_INS_SEQ;
    return this;
  }
  private java.math.BigDecimal PRTC_RT;
  public java.math.BigDecimal get_PRTC_RT() {
    return PRTC_RT;
  }
  public void set_PRTC_RT(java.math.BigDecimal PRTC_RT) {
    this.PRTC_RT = PRTC_RT;
  }
  public QueryResult with_PRTC_RT(java.math.BigDecimal PRTC_RT) {
    this.PRTC_RT = PRTC_RT;
    return this;
  }
  private String BRKR_CTR_BZAC_CD;
  public String get_BRKR_CTR_BZAC_CD() {
    return BRKR_CTR_BZAC_CD;
  }
  public void set_BRKR_CTR_BZAC_CD(String BRKR_CTR_BZAC_CD) {
    this.BRKR_CTR_BZAC_CD = BRKR_CTR_BZAC_CD;
  }
  public QueryResult with_BRKR_CTR_BZAC_CD(String BRKR_CTR_BZAC_CD) {
    this.BRKR_CTR_BZAC_CD = BRKR_CTR_BZAC_CD;
    return this;
  }
  private String RINCO_CTR_BZAC_CD;
  public String get_RINCO_CTR_BZAC_CD() {
    return RINCO_CTR_BZAC_CD;
  }
  public void set_RINCO_CTR_BZAC_CD(String RINCO_CTR_BZAC_CD) {
    this.RINCO_CTR_BZAC_CD = RINCO_CTR_BZAC_CD;
  }
  public QueryResult with_RINCO_CTR_BZAC_CD(String RINCO_CTR_BZAC_CD) {
    this.RINCO_CTR_BZAC_CD = RINCO_CTR_BZAC_CD;
    return this;
  }
  private String CLOG_APL_YN;
  public String get_CLOG_APL_YN() {
    return CLOG_APL_YN;
  }
  public void set_CLOG_APL_YN(String CLOG_APL_YN) {
    this.CLOG_APL_YN = CLOG_APL_YN;
  }
  public QueryResult with_CLOG_APL_YN(String CLOG_APL_YN) {
    this.CLOG_APL_YN = CLOG_APL_YN;
    return this;
  }
  private String CSS_CTR_ID;
  public String get_CSS_CTR_ID() {
    return CSS_CTR_ID;
  }
  public void set_CSS_CTR_ID(String CSS_CTR_ID) {
    this.CSS_CTR_ID = CSS_CTR_ID;
  }
  public QueryResult with_CSS_CTR_ID(String CSS_CTR_ID) {
    this.CSS_CTR_ID = CSS_CTR_ID;
    return this;
  }
  private String RINS_SH_DIV_CD;
  public String get_RINS_SH_DIV_CD() {
    return RINS_SH_DIV_CD;
  }
  public void set_RINS_SH_DIV_CD(String RINS_SH_DIV_CD) {
    this.RINS_SH_DIV_CD = RINS_SH_DIV_CD;
  }
  public QueryResult with_RINS_SH_DIV_CD(String RINS_SH_DIV_CD) {
    this.RINS_SH_DIV_CD = RINS_SH_DIV_CD;
    return this;
  }
  private java.math.BigDecimal BRKR_CSS_RT;
  public java.math.BigDecimal get_BRKR_CSS_RT() {
    return BRKR_CSS_RT;
  }
  public void set_BRKR_CSS_RT(java.math.BigDecimal BRKR_CSS_RT) {
    this.BRKR_CSS_RT = BRKR_CSS_RT;
  }
  public QueryResult with_BRKR_CSS_RT(java.math.BigDecimal BRKR_CSS_RT) {
    this.BRKR_CSS_RT = BRKR_CSS_RT;
    return this;
  }
  private java.math.BigDecimal INSD_AMT_STD_CSS_RT;
  public java.math.BigDecimal get_INSD_AMT_STD_CSS_RT() {
    return INSD_AMT_STD_CSS_RT;
  }
  public void set_INSD_AMT_STD_CSS_RT(java.math.BigDecimal INSD_AMT_STD_CSS_RT) {
    this.INSD_AMT_STD_CSS_RT = INSD_AMT_STD_CSS_RT;
  }
  public QueryResult with_INSD_AMT_STD_CSS_RT(java.math.BigDecimal INSD_AMT_STD_CSS_RT) {
    this.INSD_AMT_STD_CSS_RT = INSD_AMT_STD_CSS_RT;
    return this;
  }
  private java.math.BigDecimal ACP_AMT_STD_CSS_RT;
  public java.math.BigDecimal get_ACP_AMT_STD_CSS_RT() {
    return ACP_AMT_STD_CSS_RT;
  }
  public void set_ACP_AMT_STD_CSS_RT(java.math.BigDecimal ACP_AMT_STD_CSS_RT) {
    this.ACP_AMT_STD_CSS_RT = ACP_AMT_STD_CSS_RT;
  }
  public QueryResult with_ACP_AMT_STD_CSS_RT(java.math.BigDecimal ACP_AMT_STD_CSS_RT) {
    this.ACP_AMT_STD_CSS_RT = ACP_AMT_STD_CSS_RT;
    return this;
  }
  private String CUR_CD;
  public String get_CUR_CD() {
    return CUR_CD;
  }
  public void set_CUR_CD(String CUR_CD) {
    this.CUR_CD = CUR_CD;
  }
  public QueryResult with_CUR_CD(String CUR_CD) {
    this.CUR_CD = CUR_CD;
    return this;
  }
  private java.math.BigDecimal APL_EXRT;
  public java.math.BigDecimal get_APL_EXRT() {
    return APL_EXRT;
  }
  public void set_APL_EXRT(java.math.BigDecimal APL_EXRT) {
    this.APL_EXRT = APL_EXRT;
  }
  public QueryResult with_APL_EXRT(java.math.BigDecimal APL_EXRT) {
    this.APL_EXRT = APL_EXRT;
    return this;
  }
  private java.math.BigDecimal CSS_INS_AMT;
  public java.math.BigDecimal get_CSS_INS_AMT() {
    return CSS_INS_AMT;
  }
  public void set_CSS_INS_AMT(java.math.BigDecimal CSS_INS_AMT) {
    this.CSS_INS_AMT = CSS_INS_AMT;
  }
  public QueryResult with_CSS_INS_AMT(java.math.BigDecimal CSS_INS_AMT) {
    this.CSS_INS_AMT = CSS_INS_AMT;
    return this;
  }
  private java.math.BigDecimal KWCV_CSS_INS_AMT;
  public java.math.BigDecimal get_KWCV_CSS_INS_AMT() {
    return KWCV_CSS_INS_AMT;
  }
  public void set_KWCV_CSS_INS_AMT(java.math.BigDecimal KWCV_CSS_INS_AMT) {
    this.KWCV_CSS_INS_AMT = KWCV_CSS_INS_AMT;
  }
  public QueryResult with_KWCV_CSS_INS_AMT(java.math.BigDecimal KWCV_CSS_INS_AMT) {
    this.KWCV_CSS_INS_AMT = KWCV_CSS_INS_AMT;
    return this;
  }
  private java.sql.Timestamp EIH_LDG_DTM;
  public java.sql.Timestamp get_EIH_LDG_DTM() {
    return EIH_LDG_DTM;
  }
  public void set_EIH_LDG_DTM(java.sql.Timestamp EIH_LDG_DTM) {
    this.EIH_LDG_DTM = EIH_LDG_DTM;
  }
  public QueryResult with_EIH_LDG_DTM(java.sql.Timestamp EIH_LDG_DTM) {
    this.EIH_LDG_DTM = EIH_LDG_DTM;
    return this;
  }
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (!(o instanceof QueryResult)) {
      return false;
    }
    QueryResult that = (QueryResult) o;
    boolean equal = true;
    equal = equal && (this.CLOG_DT == null ? that.CLOG_DT == null : this.CLOG_DT.equals(that.CLOG_DT));
    equal = equal && (this.CLM_ID == null ? that.CLM_ID == null : this.CLM_ID.equals(that.CLM_ID));
    equal = equal && (this.COV_INS_AMT_ID == null ? that.COV_INS_AMT_ID == null : this.COV_INS_AMT_ID.equals(that.COV_INS_AMT_ID));
    equal = equal && (this.CSS_COV_INS_AMT_ID == null ? that.CSS_COV_INS_AMT_ID == null : this.CSS_COV_INS_AMT_ID.equals(that.CSS_COV_INS_AMT_ID));
    equal = equal && (this.CLADJ_CLOG_DIV_CD == null ? that.CLADJ_CLOG_DIV_CD == null : this.CLADJ_CLOG_DIV_CD.equals(that.CLADJ_CLOG_DIV_CD));
    equal = equal && (this.INS_ITMS_DIV_CD == null ? that.INS_ITMS_DIV_CD == null : this.INS_ITMS_DIV_CD.equals(that.INS_ITMS_DIV_CD));
    equal = equal && (this.BZPLN_PD_CTG_CD == null ? that.BZPLN_PD_CTG_CD == null : this.BZPLN_PD_CTG_CD.equals(that.BZPLN_PD_CTG_CD));
    equal = equal && (this.PREBL_MNG_PD_CTG_CD == null ? that.PREBL_MNG_PD_CTG_CD == null : this.PREBL_MNG_PD_CTG_CD.equals(that.PREBL_MNG_PD_CTG_CD));
    equal = equal && (this.SAL_PD_CD == null ? that.SAL_PD_CD == null : this.SAL_PD_CD.equals(that.SAL_PD_CD));
    equal = equal && (this.UNT_PD_CD == null ? that.UNT_PD_CD == null : this.UNT_PD_CD.equals(that.UNT_PD_CD));
    equal = equal && (this.ACD_NO_YY == null ? that.ACD_NO_YY == null : this.ACD_NO_YY.equals(that.ACD_NO_YY));
    equal = equal && (this.ACD_NO_SEQ == null ? that.ACD_NO_SEQ == null : this.ACD_NO_SEQ.equals(that.ACD_NO_SEQ));
    equal = equal && (this.ACD_RCT_ID == null ? that.ACD_RCT_ID == null : this.ACD_RCT_ID.equals(that.ACD_RCT_ID));
    equal = equal && (this.ACD_RCT_HIS_SEQ == null ? that.ACD_RCT_HIS_SEQ == null : this.ACD_RCT_HIS_SEQ.equals(that.ACD_RCT_HIS_SEQ));
    equal = equal && (this.RCT_DTM == null ? that.RCT_DTM == null : this.RCT_DTM.equals(that.RCT_DTM));
    equal = equal && (this.RCT_DT == null ? that.RCT_DT == null : this.RCT_DT.equals(that.RCT_DT));
    equal = equal && (this.ACD_DTM == null ? that.ACD_DTM == null : this.ACD_DTM.equals(that.ACD_DTM));
    equal = equal && (this.ACD_DT == null ? that.ACD_DT == null : this.ACD_DT.equals(that.ACD_DT));
    equal = equal && (this.HOLI_YN == null ? that.HOLI_YN == null : this.HOLI_YN.equals(that.HOLI_YN));
    equal = equal && (this.OD_ACD_NO == null ? that.OD_ACD_NO == null : this.OD_ACD_NO.equals(that.OD_ACD_NO));
    equal = equal && (this.OTHCO_ACD_NO == null ? that.OTHCO_ACD_NO == null : this.OTHCO_ACD_NO.equals(that.OTHCO_ACD_NO));
    equal = equal && (this.ACD_WKD_CD == null ? that.ACD_WKD_CD == null : this.ACD_WKD_CD.equals(that.ACD_WKD_CD));
    equal = equal && (this.CITY_NATL_CD == null ? that.CITY_NATL_CD == null : this.CITY_NATL_CD.equals(that.CITY_NATL_CD));
    equal = equal && (this.ACD_PLC_ZPCD == null ? that.ACD_PLC_ZPCD == null : this.ACD_PLC_ZPCD.equals(that.ACD_PLC_ZPCD));
    equal = equal && (this.ACD_PLC_ZPCD_SNO == null ? that.ACD_PLC_ZPCD_SNO == null : this.ACD_PLC_ZPCD_SNO.equals(that.ACD_PLC_ZPCD_SNO));
    equal = equal && (this.ACD_PLC_ZPCD_ADR == null ? that.ACD_PLC_ZPCD_ADR == null : this.ACD_PLC_ZPCD_ADR.equals(that.ACD_PLC_ZPCD_ADR));
    equal = equal && (this.ACD_PLC_DTL_ADR_CON == null ? that.ACD_PLC_DTL_ADR_CON == null : this.ACD_PLC_DTL_ADR_CON.equals(that.ACD_PLC_DTL_ADR_CON));
    equal = equal && (this.LTT_DIV_CD == null ? that.LTT_DIV_CD == null : this.LTT_DIV_CD.equals(that.LTT_DIV_CD));
    equal = equal && (this.LTT_COO_DG == null ? that.LTT_COO_DG == null : this.LTT_COO_DG.equals(that.LTT_COO_DG));
    equal = equal && (this.LTT_COO_MI == null ? that.LTT_COO_MI == null : this.LTT_COO_MI.equals(that.LTT_COO_MI));
    equal = equal && (this.LTT_COO_SS == null ? that.LTT_COO_SS == null : this.LTT_COO_SS.equals(that.LTT_COO_SS));
    equal = equal && (this.LNT_DIV_CD == null ? that.LNT_DIV_CD == null : this.LNT_DIV_CD.equals(that.LNT_DIV_CD));
    equal = equal && (this.LNT_COO_DG == null ? that.LNT_COO_DG == null : this.LNT_COO_DG.equals(that.LNT_COO_DG));
    equal = equal && (this.LNT_COO_MI == null ? that.LNT_COO_MI == null : this.LNT_COO_MI.equals(that.LNT_COO_MI));
    equal = equal && (this.LNT_COO_SS == null ? that.LNT_COO_SS == null : this.LNT_COO_SS.equals(that.LNT_COO_SS));
    equal = equal && (this.ACD_CTR_ID == null ? that.ACD_CTR_ID == null : this.ACD_CTR_ID.equals(that.ACD_CTR_ID));
    equal = equal && (this.ACD_CTR_HIS_SEQ == null ? that.ACD_CTR_HIS_SEQ == null : this.ACD_CTR_HIS_SEQ.equals(that.ACD_CTR_HIS_SEQ));
    equal = equal && (this.POL_NO == null ? that.POL_NO == null : this.POL_NO.equals(that.POL_NO));
    equal = equal && (this.CTR_ENDR_NO == null ? that.CTR_ENDR_NO == null : this.CTR_ENDR_NO.equals(that.CTR_ENDR_NO));
    equal = equal && (this.RTRO_ENDR_NO == null ? that.RTRO_ENDR_NO == null : this.RTRO_ENDR_NO.equals(that.RTRO_ENDR_NO));
    equal = equal && (this.ENDR_HIS_STD_NO == null ? that.ENDR_HIS_STD_NO == null : this.ENDR_HIS_STD_NO.equals(that.ENDR_HIS_STD_NO));
    equal = equal && (this.POLHD_CUS_ID == null ? that.POLHD_CUS_ID == null : this.POLHD_CUS_ID.equals(that.POLHD_CUS_ID));
    equal = equal && (this.POLHD_NM == null ? that.POLHD_NM == null : this.POLHD_NM.equals(that.POLHD_NM));
    equal = equal && (this.CTR_STAT_CD == null ? that.CTR_STAT_CD == null : this.CTR_STAT_CD.equals(that.CTR_STAT_CD));
    equal = equal && (this.CTR_STAT_DTL_CD == null ? that.CTR_STAT_DTL_CD == null : this.CTR_STAT_DTL_CD.equals(that.CTR_STAT_DTL_CD));
    equal = equal && (this.INS_BGN_DT == null ? that.INS_BGN_DT == null : this.INS_BGN_DT.equals(that.INS_BGN_DT));
    equal = equal && (this.INS_ED_DT == null ? that.INS_ED_DT == null : this.INS_ED_DT.equals(that.INS_ED_DT));
    equal = equal && (this.SBCP_DT == null ? that.SBCP_DT == null : this.SBCP_DT.equals(that.SBCP_DT));
    equal = equal && (this.ACP_SH_DIV_CD == null ? that.ACP_SH_DIV_CD == null : this.ACP_SH_DIV_CD.equals(that.ACP_SH_DIV_CD));
    equal = equal && (this.MRIN_PD_DIV_CD == null ? that.MRIN_PD_DIV_CD == null : this.MRIN_PD_DIV_CD.equals(that.MRIN_PD_DIV_CD));
    equal = equal && (this.MA_INSPE_CUS_ID == null ? that.MA_INSPE_CUS_ID == null : this.MA_INSPE_CUS_ID.equals(that.MA_INSPE_CUS_ID));
    equal = equal && (this.MA_INSPE_NM == null ? that.MA_INSPE_NM == null : this.MA_INSPE_NM.equals(that.MA_INSPE_NM));
    equal = equal && (this.ORIG_RTRC_DIV_CD == null ? that.ORIG_RTRC_DIV_CD == null : this.ORIG_RTRC_DIV_CD.equals(that.ORIG_RTRC_DIV_CD));
    equal = equal && (this.PLR_STUP_YN == null ? that.PLR_STUP_YN == null : this.PLR_STUP_YN.equals(that.PLR_STUP_YN));
    equal = equal && (this.TRT_HDQT_ORG_CD == null ? that.TRT_HDQT_ORG_CD == null : this.TRT_HDQT_ORG_CD.equals(that.TRT_HDQT_ORG_CD));
    equal = equal && (this.TRT_BCH_ORG_CD == null ? that.TRT_BCH_ORG_CD == null : this.TRT_BCH_ORG_CD.equals(that.TRT_BCH_ORG_CD));
    equal = equal && (this.TRT_BRCH_ORG_CD == null ? that.TRT_BRCH_ORG_CD == null : this.TRT_BRCH_ORG_CD.equals(that.TRT_BRCH_ORG_CD));
    equal = equal && (this.TRTPE_ORG_ID == null ? that.TRTPE_ORG_ID == null : this.TRTPE_ORG_ID.equals(that.TRTPE_ORG_ID));
    equal = equal && (this.TRTPE_ORG_CD == null ? that.TRTPE_ORG_CD == null : this.TRTPE_ORG_CD.equals(that.TRTPE_ORG_CD));
    equal = equal && (this.CLM_TP_CD == null ? that.CLM_TP_CD == null : this.CLM_TP_CD.equals(that.CLM_TP_CD));
    equal = equal && (this.DSS_CD_YY == null ? that.DSS_CD_YY == null : this.DSS_CD_YY.equals(that.DSS_CD_YY));
    equal = equal && (this.DSS_CD_SEQ == null ? that.DSS_CD_SEQ == null : this.DSS_CD_SEQ.equals(that.DSS_CD_SEQ));
    equal = equal && (this.CLM_STAT_CD == null ? that.CLM_STAT_CD == null : this.CLM_STAT_CD.equals(that.CLM_STAT_CD));
    equal = equal && (this.ACD_CAUS_LCTG_CD == null ? that.ACD_CAUS_LCTG_CD == null : this.ACD_CAUS_LCTG_CD.equals(that.ACD_CAUS_LCTG_CD));
    equal = equal && (this.ACD_CAUS_MCTG_CD == null ? that.ACD_CAUS_MCTG_CD == null : this.ACD_CAUS_MCTG_CD.equals(that.ACD_CAUS_MCTG_CD));
    equal = equal && (this.ACD_CAUS_SCTG_CD == null ? that.ACD_CAUS_SCTG_CD == null : this.ACD_CAUS_SCTG_CD.equals(that.ACD_CAUS_SCTG_CD));
    equal = equal && (this.ACD_CAUS_DCTG_CD == null ? that.ACD_CAUS_DCTG_CD == null : this.ACD_CAUS_DCTG_CD.equals(that.ACD_CAUS_DCTG_CD));
    equal = equal && (this.ACD_CAUS_DCTG2_CD == null ? that.ACD_CAUS_DCTG2_CD == null : this.ACD_CAUS_DCTG2_CD.equals(that.ACD_CAUS_DCTG2_CD));
    equal = equal && (this.COMS_PART_ORG_ID == null ? that.COMS_PART_ORG_ID == null : this.COMS_PART_ORG_ID.equals(that.COMS_PART_ORG_ID));
    equal = equal && (this.COMS_PART_ORG_CD == null ? that.COMS_PART_ORG_CD == null : this.COMS_PART_ORG_CD.equals(that.COMS_PART_ORG_CD));
    equal = equal && (this.COMS_TEM_ORG_ID == null ? that.COMS_TEM_ORG_ID == null : this.COMS_TEM_ORG_ID.equals(that.COMS_TEM_ORG_ID));
    equal = equal && (this.COMS_TEM_ORG_CD == null ? that.COMS_TEM_ORG_CD == null : this.COMS_TEM_ORG_CD.equals(that.COMS_TEM_ORG_CD));
    equal = equal && (this.COMS_CHRPE_ORG_ID == null ? that.COMS_CHRPE_ORG_ID == null : this.COMS_CHRPE_ORG_ID.equals(that.COMS_CHRPE_ORG_ID));
    equal = equal && (this.CPIC_ORG_CD == null ? that.CPIC_ORG_CD == null : this.CPIC_ORG_CD.equals(that.CPIC_ORG_CD));
    equal = equal && (this.CNCLU_DT == null ? that.CNCLU_DT == null : this.CNCLU_DT.equals(that.CNCLU_DT));
    equal = equal && (this.EXMP_DCN_DT == null ? that.EXMP_DCN_DT == null : this.EXMP_DCN_DT.equals(that.EXMP_DCN_DT));
    equal = equal && (this.DAM_DGR_CD == null ? that.DAM_DGR_CD == null : this.DAM_DGR_CD.equals(that.DAM_DGR_CD));
    equal = equal && (this.AT_ISP_YN == null ? that.AT_ISP_YN == null : this.AT_ISP_YN.equals(that.AT_ISP_YN));
    equal = equal && (this.ACD_CTR_OBJ_ID == null ? that.ACD_CTR_OBJ_ID == null : this.ACD_CTR_OBJ_ID.equals(that.ACD_CTR_OBJ_ID));
    equal = equal && (this.ACD_CTR_OBJ_HIS_SEQ == null ? that.ACD_CTR_OBJ_HIS_SEQ == null : this.ACD_CTR_OBJ_HIS_SEQ.equals(that.ACD_CTR_OBJ_HIS_SEQ));
    equal = equal && (this.ACD_OBJ_DIV_CD == null ? that.ACD_OBJ_DIV_CD == null : this.ACD_OBJ_DIV_CD.equals(that.ACD_OBJ_DIV_CD));
    equal = equal && (this.ACD_OBJ_ID == null ? that.ACD_OBJ_ID == null : this.ACD_OBJ_ID.equals(that.ACD_OBJ_ID));
    equal = equal && (this.DAM_ORD == null ? that.DAM_ORD == null : this.DAM_ORD.equals(that.DAM_ORD));
    equal = equal && (this.CTR_OBJ_ID == null ? that.CTR_OBJ_ID == null : this.CTR_OBJ_ID.equals(that.CTR_OBJ_ID));
    equal = equal && (this.CTR_OBJ_ADR_ID == null ? that.CTR_OBJ_ADR_ID == null : this.CTR_OBJ_ADR_ID.equals(that.CTR_OBJ_ADR_ID));
    equal = equal && (this.OBJ_TP_CD == null ? that.OBJ_TP_CD == null : this.OBJ_TP_CD.equals(that.OBJ_TP_CD));
    equal = equal && (this.DMPE_CUS_ID == null ? that.DMPE_CUS_ID == null : this.DMPE_CUS_ID.equals(that.DMPE_CUS_ID));
    equal = equal && (this.DMPO_NM == null ? that.DMPO_NM == null : this.DMPO_NM.equals(that.DMPO_NM));
    equal = equal && (this.PVDS_YN == null ? that.PVDS_YN == null : this.PVDS_YN.equals(that.PVDS_YN));
    equal = equal && (this.TCTR_DMPE_JOB_GRD_CD == null ? that.TCTR_DMPE_JOB_GRD_CD == null : this.TCTR_DMPE_JOB_GRD_CD.equals(that.TCTR_DMPE_JOB_GRD_CD));
    equal = equal && (this.TCTR_DMPE_JOB_CD == null ? that.TCTR_DMPE_JOB_CD == null : this.TCTR_DMPE_JOB_CD.equals(that.TCTR_DMPE_JOB_CD));
    equal = equal && (this.TACD_DMPE_JOB_GRD_CD == null ? that.TACD_DMPE_JOB_GRD_CD == null : this.TACD_DMPE_JOB_GRD_CD.equals(that.TACD_DMPE_JOB_GRD_CD));
    equal = equal && (this.TACD_DMPE_JOB_CD == null ? that.TACD_DMPE_JOB_CD == null : this.TACD_DMPE_JOB_CD.equals(that.TACD_DMPE_JOB_CD));
    equal = equal && (this.OWNR_NM == null ? that.OWNR_NM == null : this.OWNR_NM.equals(that.OWNR_NM));
    equal = equal && (this.DMPE_AGE == null ? that.DMPE_AGE == null : this.DMPE_AGE.equals(that.DMPE_AGE));
    equal = equal && (this.TNG_DIV_CD == null ? that.TNG_DIV_CD == null : this.TNG_DIV_CD.equals(that.TNG_DIV_CD));
    equal = equal && (this.OBJ_GRD_CD == null ? that.OBJ_GRD_CD == null : this.OBJ_GRD_CD.equals(that.OBJ_GRD_CD));
    equal = equal && (this.OPN_JBCL_CD == null ? that.OPN_JBCL_CD == null : this.OPN_JBCL_CD.equals(that.OPN_JBCL_CD));
    equal = equal && (this.OPJB_NM == null ? that.OPJB_NM == null : this.OPJB_NM.equals(that.OPJB_NM));
    equal = equal && (this.OBJ_CD == null ? that.OBJ_CD == null : this.OBJ_CD.equals(that.OBJ_CD));
    equal = equal && (this.DMOB_LCTG_CD == null ? that.DMOB_LCTG_CD == null : this.DMOB_LCTG_CD.equals(that.DMOB_LCTG_CD));
    equal = equal && (this.DMOB_MCTG_CD == null ? that.DMOB_MCTG_CD == null : this.DMOB_MCTG_CD.equals(that.DMOB_MCTG_CD));
    equal = equal && (this.DMOB_SCTG_CD == null ? that.DMOB_SCTG_CD == null : this.DMOB_SCTG_CD.equals(that.DMOB_SCTG_CD));
    equal = equal && (this.DMOB_TPIDS_LCTG_CD == null ? that.DMOB_TPIDS_LCTG_CD == null : this.DMOB_TPIDS_LCTG_CD.equals(that.DMOB_TPIDS_LCTG_CD));
    equal = equal && (this.DMOB_TPIDS_MCTG_CD == null ? that.DMOB_TPIDS_MCTG_CD == null : this.DMOB_TPIDS_MCTG_CD.equals(that.DMOB_TPIDS_MCTG_CD));
    equal = equal && (this.DMOB_TPIDS_SCTG_CD == null ? that.DMOB_TPIDS_SCTG_CD == null : this.DMOB_TPIDS_SCTG_CD.equals(that.DMOB_TPIDS_SCTG_CD));
    equal = equal && (this.DMOB_TPIDS_DCTG_CD == null ? that.DMOB_TPIDS_DCTG_CD == null : this.DMOB_TPIDS_DCTG_CD.equals(that.DMOB_TPIDS_DCTG_CD));
    equal = equal && (this.MCSH_FSHBT_DIV_CD == null ? that.MCSH_FSHBT_DIV_CD == null : this.MCSH_FSHBT_DIV_CD.equals(that.MCSH_FSHBT_DIV_CD));
    equal = equal && (this.SHAG == null ? that.SHAG == null : this.SHAG.equals(that.SHAG));
    equal = equal && (this.SHP_TP_CD == null ? that.SHP_TP_CD == null : this.SHP_TP_CD.equals(that.SHP_TP_CD));
    equal = equal && (this.SHP_CD == null ? that.SHP_CD == null : this.SHP_CD.equals(that.SHP_CD));
    equal = equal && (this.ARCRF_REG_NO == null ? that.ARCRF_REG_NO == null : this.ARCRF_REG_NO.equals(that.ARCRF_REG_NO));
    equal = equal && (this.CARG_TRN_ITM_CD == null ? that.CARG_TRN_ITM_CD == null : this.CARG_TRN_ITM_CD.equals(that.CARG_TRN_ITM_CD));
    equal = equal && (this.DTH_YN == null ? that.DTH_YN == null : this.DTH_YN.equals(that.DTH_YN));
    equal = equal && (this.AFOBS_YN == null ? that.AFOBS_YN == null : this.AFOBS_YN.equals(that.AFOBS_YN));
    equal = equal && (this.HSP_MD_EXP_YN == null ? that.HSP_MD_EXP_YN == null : this.HSP_MD_EXP_YN.equals(that.HSP_MD_EXP_YN));
    equal = equal && (this.GHR_MD_EXP_YN == null ? that.GHR_MD_EXP_YN == null : this.GHR_MD_EXP_YN.equals(that.GHR_MD_EXP_YN));
    equal = equal && (this.PSC_MD_EXP_YN == null ? that.PSC_MD_EXP_YN == null : this.PSC_MD_EXP_YN.equals(that.PSC_MD_EXP_YN));
    equal = equal && (this.HSP_DDPY_YN == null ? that.HSP_DDPY_YN == null : this.HSP_DDPY_YN.equals(that.HSP_DDPY_YN));
    equal = equal && (this.LAST_DGN_YN == null ? that.LAST_DGN_YN == null : this.LAST_DGN_YN.equals(that.LAST_DGN_YN));
    equal = equal && (this.SROP_YN == null ? that.SROP_YN == null : this.SROP_YN.equals(that.SROP_YN));
    equal = equal && (this.EXP_YN == null ? that.EXP_YN == null : this.EXP_YN.equals(that.EXP_YN));
    equal = equal && (this.SROP_BDW_YN == null ? that.SROP_BDW_YN == null : this.SROP_BDW_YN.equals(that.SROP_BDW_YN));
    equal = equal && (this.OS_ID == null ? that.OS_ID == null : this.OS_ID.equals(that.OS_ID));
    equal = equal && (this.OS_HIS_SEQ == null ? that.OS_HIS_SEQ == null : this.OS_HIS_SEQ.equals(that.OS_HIS_SEQ));
    equal = equal && (this.OS_SEQ == null ? that.OS_SEQ == null : this.OS_SEQ.equals(that.OS_SEQ));
    equal = equal && (this.OS_DIV_CD == null ? that.OS_DIV_CD == null : this.OS_DIV_CD.equals(that.OS_DIV_CD));
    equal = equal && (this.DCN_ID == null ? that.DCN_ID == null : this.DCN_ID.equals(that.DCN_ID));
    equal = equal && (this.DCN_HIS_SEQ == null ? that.DCN_HIS_SEQ == null : this.DCN_HIS_SEQ.equals(that.DCN_HIS_SEQ));
    equal = equal && (this.DCN_SEQ == null ? that.DCN_SEQ == null : this.DCN_SEQ.equals(that.DCN_SEQ));
    equal = equal && (this.DCN_DIV_CD == null ? that.DCN_DIV_CD == null : this.DCN_DIV_CD.equals(that.DCN_DIV_CD));
    equal = equal && (this.CNCLU_ID == null ? that.CNCLU_ID == null : this.CNCLU_ID.equals(that.CNCLU_ID));
    equal = equal && (this.CNCLU_HIS_SEQ == null ? that.CNCLU_HIS_SEQ == null : this.CNCLU_HIS_SEQ.equals(that.CNCLU_HIS_SEQ));
    equal = equal && (this.CNCLU_DIV_CD == null ? that.CNCLU_DIV_CD == null : this.CNCLU_DIV_CD.equals(that.CNCLU_DIV_CD));
    equal = equal && (this.CNCLU_DATA_DIV_CD == null ? that.CNCLU_DATA_DIV_CD == null : this.CNCLU_DATA_DIV_CD.equals(that.CNCLU_DATA_DIV_CD));
    equal = equal && (this.COV_INS_DATA_DIV_CD == null ? that.COV_INS_DATA_DIV_CD == null : this.COV_INS_DATA_DIV_CD.equals(that.COV_INS_DATA_DIV_CD));
    equal = equal && (this.COV_INS_HIS_SEQ == null ? that.COV_INS_HIS_SEQ == null : this.COV_INS_HIS_SEQ.equals(that.COV_INS_HIS_SEQ));
    equal = equal && (this.INS_AMT_APVL_DT == null ? that.INS_AMT_APVL_DT == null : this.INS_AMT_APVL_DT.equals(that.INS_AMT_APVL_DT));
    equal = equal && (this.CSS_COV_INS_HIS_SEQ == null ? that.CSS_COV_INS_HIS_SEQ == null : this.CSS_COV_INS_HIS_SEQ.equals(that.CSS_COV_INS_HIS_SEQ));
    equal = equal && (this.SPTPY_DIV_CD == null ? that.SPTPY_DIV_CD == null : this.SPTPY_DIV_CD.equals(that.SPTPY_DIV_CD));
    equal = equal && (this.ISD_PCS_SEQ == null ? that.ISD_PCS_SEQ == null : this.ISD_PCS_SEQ.equals(that.ISD_PCS_SEQ));
    equal = equal && (this.COV_CD == null ? that.COV_CD == null : this.COV_CD.equals(that.COV_CD));
    equal = equal && (this.INS_AMT_EXT_EXP_DIV_CD == null ? that.INS_AMT_EXT_EXP_DIV_CD == null : this.INS_AMT_EXT_EXP_DIV_CD.equals(that.INS_AMT_EXT_EXP_DIV_CD));
    equal = equal && (this.GURT_UNT_CD == null ? that.GURT_UNT_CD == null : this.GURT_UNT_CD.equals(that.GURT_UNT_CD));
    equal = equal && (this.RSK_UNT_CD == null ? that.RSK_UNT_CD == null : this.RSK_UNT_CD.equals(that.RSK_UNT_CD));
    equal = equal && (this.CLADJ_DIV_CTG_CD == null ? that.CLADJ_DIV_CTG_CD == null : this.CLADJ_DIV_CTG_CD.equals(that.CLADJ_DIV_CTG_CD));
    equal = equal && (this.BAS_SIC_DIV_CD == null ? that.BAS_SIC_DIV_CD == null : this.BAS_SIC_DIV_CD.equals(that.BAS_SIC_DIV_CD));
    equal = equal && (this.COV_INS_BGN_DT == null ? that.COV_INS_BGN_DT == null : this.COV_INS_BGN_DT.equals(that.COV_INS_BGN_DT));
    equal = equal && (this.COV_INS_ED_DT == null ? that.COV_INS_ED_DT == null : this.COV_INS_ED_DT.equals(that.COV_INS_ED_DT));
    equal = equal && (this.INSD_AMT_CUR_CD == null ? that.INSD_AMT_CUR_CD == null : this.INSD_AMT_CUR_CD.equals(that.INSD_AMT_CUR_CD));
    equal = equal && (this.CUR_INSD_AMT == null ? that.CUR_INSD_AMT == null : this.CUR_INSD_AMT.equals(that.CUR_INSD_AMT));
    equal = equal && (this.INSD_AMT == null ? that.INSD_AMT == null : this.INSD_AMT.equals(that.INSD_AMT));
    equal = equal && (this.PPS_COMS_LM_AMT == null ? that.PPS_COMS_LM_AMT == null : this.PPS_COMS_LM_AMT.equals(that.PPS_COMS_LM_AMT));
    equal = equal && (this.PACD_COMS_LM_AMT == null ? that.PACD_COMS_LM_AMT == null : this.PACD_COMS_LM_AMT.equals(that.PACD_COMS_LM_AMT));
    equal = equal && (this.LDCO_CTR_BZAC_CD == null ? that.LDCO_CTR_BZAC_CD == null : this.LDCO_CTR_BZAC_CD.equals(that.LDCO_CTR_BZAC_CD));
    equal = equal && (this.COI_CTR_BZAC_CD == null ? that.COI_CTR_BZAC_CD == null : this.COI_CTR_BZAC_CD.equals(that.COI_CTR_BZAC_CD));
    equal = equal && (this.CSS_COV_INS_SEQ == null ? that.CSS_COV_INS_SEQ == null : this.CSS_COV_INS_SEQ.equals(that.CSS_COV_INS_SEQ));
    equal = equal && (this.JNT_ACP_COV_INS_SEQ == null ? that.JNT_ACP_COV_INS_SEQ == null : this.JNT_ACP_COV_INS_SEQ.equals(that.JNT_ACP_COV_INS_SEQ));
    equal = equal && (this.PRTC_RT == null ? that.PRTC_RT == null : this.PRTC_RT.equals(that.PRTC_RT));
    equal = equal && (this.BRKR_CTR_BZAC_CD == null ? that.BRKR_CTR_BZAC_CD == null : this.BRKR_CTR_BZAC_CD.equals(that.BRKR_CTR_BZAC_CD));
    equal = equal && (this.RINCO_CTR_BZAC_CD == null ? that.RINCO_CTR_BZAC_CD == null : this.RINCO_CTR_BZAC_CD.equals(that.RINCO_CTR_BZAC_CD));
    equal = equal && (this.CLOG_APL_YN == null ? that.CLOG_APL_YN == null : this.CLOG_APL_YN.equals(that.CLOG_APL_YN));
    equal = equal && (this.CSS_CTR_ID == null ? that.CSS_CTR_ID == null : this.CSS_CTR_ID.equals(that.CSS_CTR_ID));
    equal = equal && (this.RINS_SH_DIV_CD == null ? that.RINS_SH_DIV_CD == null : this.RINS_SH_DIV_CD.equals(that.RINS_SH_DIV_CD));
    equal = equal && (this.BRKR_CSS_RT == null ? that.BRKR_CSS_RT == null : this.BRKR_CSS_RT.equals(that.BRKR_CSS_RT));
    equal = equal && (this.INSD_AMT_STD_CSS_RT == null ? that.INSD_AMT_STD_CSS_RT == null : this.INSD_AMT_STD_CSS_RT.equals(that.INSD_AMT_STD_CSS_RT));
    equal = equal && (this.ACP_AMT_STD_CSS_RT == null ? that.ACP_AMT_STD_CSS_RT == null : this.ACP_AMT_STD_CSS_RT.equals(that.ACP_AMT_STD_CSS_RT));
    equal = equal && (this.CUR_CD == null ? that.CUR_CD == null : this.CUR_CD.equals(that.CUR_CD));
    equal = equal && (this.APL_EXRT == null ? that.APL_EXRT == null : this.APL_EXRT.equals(that.APL_EXRT));
    equal = equal && (this.CSS_INS_AMT == null ? that.CSS_INS_AMT == null : this.CSS_INS_AMT.equals(that.CSS_INS_AMT));
    equal = equal && (this.KWCV_CSS_INS_AMT == null ? that.KWCV_CSS_INS_AMT == null : this.KWCV_CSS_INS_AMT.equals(that.KWCV_CSS_INS_AMT));
    equal = equal && (this.EIH_LDG_DTM == null ? that.EIH_LDG_DTM == null : this.EIH_LDG_DTM.equals(that.EIH_LDG_DTM));
    return equal;
  }
  public boolean equals0(Object o) {
    if (this == o) {
      return true;
    }
    if (!(o instanceof QueryResult)) {
      return false;
    }
    QueryResult that = (QueryResult) o;
    boolean equal = true;
    equal = equal && (this.CLOG_DT == null ? that.CLOG_DT == null : this.CLOG_DT.equals(that.CLOG_DT));
    equal = equal && (this.CLM_ID == null ? that.CLM_ID == null : this.CLM_ID.equals(that.CLM_ID));
    equal = equal && (this.COV_INS_AMT_ID == null ? that.COV_INS_AMT_ID == null : this.COV_INS_AMT_ID.equals(that.COV_INS_AMT_ID));
    equal = equal && (this.CSS_COV_INS_AMT_ID == null ? that.CSS_COV_INS_AMT_ID == null : this.CSS_COV_INS_AMT_ID.equals(that.CSS_COV_INS_AMT_ID));
    equal = equal && (this.CLADJ_CLOG_DIV_CD == null ? that.CLADJ_CLOG_DIV_CD == null : this.CLADJ_CLOG_DIV_CD.equals(that.CLADJ_CLOG_DIV_CD));
    equal = equal && (this.INS_ITMS_DIV_CD == null ? that.INS_ITMS_DIV_CD == null : this.INS_ITMS_DIV_CD.equals(that.INS_ITMS_DIV_CD));
    equal = equal && (this.BZPLN_PD_CTG_CD == null ? that.BZPLN_PD_CTG_CD == null : this.BZPLN_PD_CTG_CD.equals(that.BZPLN_PD_CTG_CD));
    equal = equal && (this.PREBL_MNG_PD_CTG_CD == null ? that.PREBL_MNG_PD_CTG_CD == null : this.PREBL_MNG_PD_CTG_CD.equals(that.PREBL_MNG_PD_CTG_CD));
    equal = equal && (this.SAL_PD_CD == null ? that.SAL_PD_CD == null : this.SAL_PD_CD.equals(that.SAL_PD_CD));
    equal = equal && (this.UNT_PD_CD == null ? that.UNT_PD_CD == null : this.UNT_PD_CD.equals(that.UNT_PD_CD));
    equal = equal && (this.ACD_NO_YY == null ? that.ACD_NO_YY == null : this.ACD_NO_YY.equals(that.ACD_NO_YY));
    equal = equal && (this.ACD_NO_SEQ == null ? that.ACD_NO_SEQ == null : this.ACD_NO_SEQ.equals(that.ACD_NO_SEQ));
    equal = equal && (this.ACD_RCT_ID == null ? that.ACD_RCT_ID == null : this.ACD_RCT_ID.equals(that.ACD_RCT_ID));
    equal = equal && (this.ACD_RCT_HIS_SEQ == null ? that.ACD_RCT_HIS_SEQ == null : this.ACD_RCT_HIS_SEQ.equals(that.ACD_RCT_HIS_SEQ));
    equal = equal && (this.RCT_DTM == null ? that.RCT_DTM == null : this.RCT_DTM.equals(that.RCT_DTM));
    equal = equal && (this.RCT_DT == null ? that.RCT_DT == null : this.RCT_DT.equals(that.RCT_DT));
    equal = equal && (this.ACD_DTM == null ? that.ACD_DTM == null : this.ACD_DTM.equals(that.ACD_DTM));
    equal = equal && (this.ACD_DT == null ? that.ACD_DT == null : this.ACD_DT.equals(that.ACD_DT));
    equal = equal && (this.HOLI_YN == null ? that.HOLI_YN == null : this.HOLI_YN.equals(that.HOLI_YN));
    equal = equal && (this.OD_ACD_NO == null ? that.OD_ACD_NO == null : this.OD_ACD_NO.equals(that.OD_ACD_NO));
    equal = equal && (this.OTHCO_ACD_NO == null ? that.OTHCO_ACD_NO == null : this.OTHCO_ACD_NO.equals(that.OTHCO_ACD_NO));
    equal = equal && (this.ACD_WKD_CD == null ? that.ACD_WKD_CD == null : this.ACD_WKD_CD.equals(that.ACD_WKD_CD));
    equal = equal && (this.CITY_NATL_CD == null ? that.CITY_NATL_CD == null : this.CITY_NATL_CD.equals(that.CITY_NATL_CD));
    equal = equal && (this.ACD_PLC_ZPCD == null ? that.ACD_PLC_ZPCD == null : this.ACD_PLC_ZPCD.equals(that.ACD_PLC_ZPCD));
    equal = equal && (this.ACD_PLC_ZPCD_SNO == null ? that.ACD_PLC_ZPCD_SNO == null : this.ACD_PLC_ZPCD_SNO.equals(that.ACD_PLC_ZPCD_SNO));
    equal = equal && (this.ACD_PLC_ZPCD_ADR == null ? that.ACD_PLC_ZPCD_ADR == null : this.ACD_PLC_ZPCD_ADR.equals(that.ACD_PLC_ZPCD_ADR));
    equal = equal && (this.ACD_PLC_DTL_ADR_CON == null ? that.ACD_PLC_DTL_ADR_CON == null : this.ACD_PLC_DTL_ADR_CON.equals(that.ACD_PLC_DTL_ADR_CON));
    equal = equal && (this.LTT_DIV_CD == null ? that.LTT_DIV_CD == null : this.LTT_DIV_CD.equals(that.LTT_DIV_CD));
    equal = equal && (this.LTT_COO_DG == null ? that.LTT_COO_DG == null : this.LTT_COO_DG.equals(that.LTT_COO_DG));
    equal = equal && (this.LTT_COO_MI == null ? that.LTT_COO_MI == null : this.LTT_COO_MI.equals(that.LTT_COO_MI));
    equal = equal && (this.LTT_COO_SS == null ? that.LTT_COO_SS == null : this.LTT_COO_SS.equals(that.LTT_COO_SS));
    equal = equal && (this.LNT_DIV_CD == null ? that.LNT_DIV_CD == null : this.LNT_DIV_CD.equals(that.LNT_DIV_CD));
    equal = equal && (this.LNT_COO_DG == null ? that.LNT_COO_DG == null : this.LNT_COO_DG.equals(that.LNT_COO_DG));
    equal = equal && (this.LNT_COO_MI == null ? that.LNT_COO_MI == null : this.LNT_COO_MI.equals(that.LNT_COO_MI));
    equal = equal && (this.LNT_COO_SS == null ? that.LNT_COO_SS == null : this.LNT_COO_SS.equals(that.LNT_COO_SS));
    equal = equal && (this.ACD_CTR_ID == null ? that.ACD_CTR_ID == null : this.ACD_CTR_ID.equals(that.ACD_CTR_ID));
    equal = equal && (this.ACD_CTR_HIS_SEQ == null ? that.ACD_CTR_HIS_SEQ == null : this.ACD_CTR_HIS_SEQ.equals(that.ACD_CTR_HIS_SEQ));
    equal = equal && (this.POL_NO == null ? that.POL_NO == null : this.POL_NO.equals(that.POL_NO));
    equal = equal && (this.CTR_ENDR_NO == null ? that.CTR_ENDR_NO == null : this.CTR_ENDR_NO.equals(that.CTR_ENDR_NO));
    equal = equal && (this.RTRO_ENDR_NO == null ? that.RTRO_ENDR_NO == null : this.RTRO_ENDR_NO.equals(that.RTRO_ENDR_NO));
    equal = equal && (this.ENDR_HIS_STD_NO == null ? that.ENDR_HIS_STD_NO == null : this.ENDR_HIS_STD_NO.equals(that.ENDR_HIS_STD_NO));
    equal = equal && (this.POLHD_CUS_ID == null ? that.POLHD_CUS_ID == null : this.POLHD_CUS_ID.equals(that.POLHD_CUS_ID));
    equal = equal && (this.POLHD_NM == null ? that.POLHD_NM == null : this.POLHD_NM.equals(that.POLHD_NM));
    equal = equal && (this.CTR_STAT_CD == null ? that.CTR_STAT_CD == null : this.CTR_STAT_CD.equals(that.CTR_STAT_CD));
    equal = equal && (this.CTR_STAT_DTL_CD == null ? that.CTR_STAT_DTL_CD == null : this.CTR_STAT_DTL_CD.equals(that.CTR_STAT_DTL_CD));
    equal = equal && (this.INS_BGN_DT == null ? that.INS_BGN_DT == null : this.INS_BGN_DT.equals(that.INS_BGN_DT));
    equal = equal && (this.INS_ED_DT == null ? that.INS_ED_DT == null : this.INS_ED_DT.equals(that.INS_ED_DT));
    equal = equal && (this.SBCP_DT == null ? that.SBCP_DT == null : this.SBCP_DT.equals(that.SBCP_DT));
    equal = equal && (this.ACP_SH_DIV_CD == null ? that.ACP_SH_DIV_CD == null : this.ACP_SH_DIV_CD.equals(that.ACP_SH_DIV_CD));
    equal = equal && (this.MRIN_PD_DIV_CD == null ? that.MRIN_PD_DIV_CD == null : this.MRIN_PD_DIV_CD.equals(that.MRIN_PD_DIV_CD));
    equal = equal && (this.MA_INSPE_CUS_ID == null ? that.MA_INSPE_CUS_ID == null : this.MA_INSPE_CUS_ID.equals(that.MA_INSPE_CUS_ID));
    equal = equal && (this.MA_INSPE_NM == null ? that.MA_INSPE_NM == null : this.MA_INSPE_NM.equals(that.MA_INSPE_NM));
    equal = equal && (this.ORIG_RTRC_DIV_CD == null ? that.ORIG_RTRC_DIV_CD == null : this.ORIG_RTRC_DIV_CD.equals(that.ORIG_RTRC_DIV_CD));
    equal = equal && (this.PLR_STUP_YN == null ? that.PLR_STUP_YN == null : this.PLR_STUP_YN.equals(that.PLR_STUP_YN));
    equal = equal && (this.TRT_HDQT_ORG_CD == null ? that.TRT_HDQT_ORG_CD == null : this.TRT_HDQT_ORG_CD.equals(that.TRT_HDQT_ORG_CD));
    equal = equal && (this.TRT_BCH_ORG_CD == null ? that.TRT_BCH_ORG_CD == null : this.TRT_BCH_ORG_CD.equals(that.TRT_BCH_ORG_CD));
    equal = equal && (this.TRT_BRCH_ORG_CD == null ? that.TRT_BRCH_ORG_CD == null : this.TRT_BRCH_ORG_CD.equals(that.TRT_BRCH_ORG_CD));
    equal = equal && (this.TRTPE_ORG_ID == null ? that.TRTPE_ORG_ID == null : this.TRTPE_ORG_ID.equals(that.TRTPE_ORG_ID));
    equal = equal && (this.TRTPE_ORG_CD == null ? that.TRTPE_ORG_CD == null : this.TRTPE_ORG_CD.equals(that.TRTPE_ORG_CD));
    equal = equal && (this.CLM_TP_CD == null ? that.CLM_TP_CD == null : this.CLM_TP_CD.equals(that.CLM_TP_CD));
    equal = equal && (this.DSS_CD_YY == null ? that.DSS_CD_YY == null : this.DSS_CD_YY.equals(that.DSS_CD_YY));
    equal = equal && (this.DSS_CD_SEQ == null ? that.DSS_CD_SEQ == null : this.DSS_CD_SEQ.equals(that.DSS_CD_SEQ));
    equal = equal && (this.CLM_STAT_CD == null ? that.CLM_STAT_CD == null : this.CLM_STAT_CD.equals(that.CLM_STAT_CD));
    equal = equal && (this.ACD_CAUS_LCTG_CD == null ? that.ACD_CAUS_LCTG_CD == null : this.ACD_CAUS_LCTG_CD.equals(that.ACD_CAUS_LCTG_CD));
    equal = equal && (this.ACD_CAUS_MCTG_CD == null ? that.ACD_CAUS_MCTG_CD == null : this.ACD_CAUS_MCTG_CD.equals(that.ACD_CAUS_MCTG_CD));
    equal = equal && (this.ACD_CAUS_SCTG_CD == null ? that.ACD_CAUS_SCTG_CD == null : this.ACD_CAUS_SCTG_CD.equals(that.ACD_CAUS_SCTG_CD));
    equal = equal && (this.ACD_CAUS_DCTG_CD == null ? that.ACD_CAUS_DCTG_CD == null : this.ACD_CAUS_DCTG_CD.equals(that.ACD_CAUS_DCTG_CD));
    equal = equal && (this.ACD_CAUS_DCTG2_CD == null ? that.ACD_CAUS_DCTG2_CD == null : this.ACD_CAUS_DCTG2_CD.equals(that.ACD_CAUS_DCTG2_CD));
    equal = equal && (this.COMS_PART_ORG_ID == null ? that.COMS_PART_ORG_ID == null : this.COMS_PART_ORG_ID.equals(that.COMS_PART_ORG_ID));
    equal = equal && (this.COMS_PART_ORG_CD == null ? that.COMS_PART_ORG_CD == null : this.COMS_PART_ORG_CD.equals(that.COMS_PART_ORG_CD));
    equal = equal && (this.COMS_TEM_ORG_ID == null ? that.COMS_TEM_ORG_ID == null : this.COMS_TEM_ORG_ID.equals(that.COMS_TEM_ORG_ID));
    equal = equal && (this.COMS_TEM_ORG_CD == null ? that.COMS_TEM_ORG_CD == null : this.COMS_TEM_ORG_CD.equals(that.COMS_TEM_ORG_CD));
    equal = equal && (this.COMS_CHRPE_ORG_ID == null ? that.COMS_CHRPE_ORG_ID == null : this.COMS_CHRPE_ORG_ID.equals(that.COMS_CHRPE_ORG_ID));
    equal = equal && (this.CPIC_ORG_CD == null ? that.CPIC_ORG_CD == null : this.CPIC_ORG_CD.equals(that.CPIC_ORG_CD));
    equal = equal && (this.CNCLU_DT == null ? that.CNCLU_DT == null : this.CNCLU_DT.equals(that.CNCLU_DT));
    equal = equal && (this.EXMP_DCN_DT == null ? that.EXMP_DCN_DT == null : this.EXMP_DCN_DT.equals(that.EXMP_DCN_DT));
    equal = equal && (this.DAM_DGR_CD == null ? that.DAM_DGR_CD == null : this.DAM_DGR_CD.equals(that.DAM_DGR_CD));
    equal = equal && (this.AT_ISP_YN == null ? that.AT_ISP_YN == null : this.AT_ISP_YN.equals(that.AT_ISP_YN));
    equal = equal && (this.ACD_CTR_OBJ_ID == null ? that.ACD_CTR_OBJ_ID == null : this.ACD_CTR_OBJ_ID.equals(that.ACD_CTR_OBJ_ID));
    equal = equal && (this.ACD_CTR_OBJ_HIS_SEQ == null ? that.ACD_CTR_OBJ_HIS_SEQ == null : this.ACD_CTR_OBJ_HIS_SEQ.equals(that.ACD_CTR_OBJ_HIS_SEQ));
    equal = equal && (this.ACD_OBJ_DIV_CD == null ? that.ACD_OBJ_DIV_CD == null : this.ACD_OBJ_DIV_CD.equals(that.ACD_OBJ_DIV_CD));
    equal = equal && (this.ACD_OBJ_ID == null ? that.ACD_OBJ_ID == null : this.ACD_OBJ_ID.equals(that.ACD_OBJ_ID));
    equal = equal && (this.DAM_ORD == null ? that.DAM_ORD == null : this.DAM_ORD.equals(that.DAM_ORD));
    equal = equal && (this.CTR_OBJ_ID == null ? that.CTR_OBJ_ID == null : this.CTR_OBJ_ID.equals(that.CTR_OBJ_ID));
    equal = equal && (this.CTR_OBJ_ADR_ID == null ? that.CTR_OBJ_ADR_ID == null : this.CTR_OBJ_ADR_ID.equals(that.CTR_OBJ_ADR_ID));
    equal = equal && (this.OBJ_TP_CD == null ? that.OBJ_TP_CD == null : this.OBJ_TP_CD.equals(that.OBJ_TP_CD));
    equal = equal && (this.DMPE_CUS_ID == null ? that.DMPE_CUS_ID == null : this.DMPE_CUS_ID.equals(that.DMPE_CUS_ID));
    equal = equal && (this.DMPO_NM == null ? that.DMPO_NM == null : this.DMPO_NM.equals(that.DMPO_NM));
    equal = equal && (this.PVDS_YN == null ? that.PVDS_YN == null : this.PVDS_YN.equals(that.PVDS_YN));
    equal = equal && (this.TCTR_DMPE_JOB_GRD_CD == null ? that.TCTR_DMPE_JOB_GRD_CD == null : this.TCTR_DMPE_JOB_GRD_CD.equals(that.TCTR_DMPE_JOB_GRD_CD));
    equal = equal && (this.TCTR_DMPE_JOB_CD == null ? that.TCTR_DMPE_JOB_CD == null : this.TCTR_DMPE_JOB_CD.equals(that.TCTR_DMPE_JOB_CD));
    equal = equal && (this.TACD_DMPE_JOB_GRD_CD == null ? that.TACD_DMPE_JOB_GRD_CD == null : this.TACD_DMPE_JOB_GRD_CD.equals(that.TACD_DMPE_JOB_GRD_CD));
    equal = equal && (this.TACD_DMPE_JOB_CD == null ? that.TACD_DMPE_JOB_CD == null : this.TACD_DMPE_JOB_CD.equals(that.TACD_DMPE_JOB_CD));
    equal = equal && (this.OWNR_NM == null ? that.OWNR_NM == null : this.OWNR_NM.equals(that.OWNR_NM));
    equal = equal && (this.DMPE_AGE == null ? that.DMPE_AGE == null : this.DMPE_AGE.equals(that.DMPE_AGE));
    equal = equal && (this.TNG_DIV_CD == null ? that.TNG_DIV_CD == null : this.TNG_DIV_CD.equals(that.TNG_DIV_CD));
    equal = equal && (this.OBJ_GRD_CD == null ? that.OBJ_GRD_CD == null : this.OBJ_GRD_CD.equals(that.OBJ_GRD_CD));
    equal = equal && (this.OPN_JBCL_CD == null ? that.OPN_JBCL_CD == null : this.OPN_JBCL_CD.equals(that.OPN_JBCL_CD));
    equal = equal && (this.OPJB_NM == null ? that.OPJB_NM == null : this.OPJB_NM.equals(that.OPJB_NM));
    equal = equal && (this.OBJ_CD == null ? that.OBJ_CD == null : this.OBJ_CD.equals(that.OBJ_CD));
    equal = equal && (this.DMOB_LCTG_CD == null ? that.DMOB_LCTG_CD == null : this.DMOB_LCTG_CD.equals(that.DMOB_LCTG_CD));
    equal = equal && (this.DMOB_MCTG_CD == null ? that.DMOB_MCTG_CD == null : this.DMOB_MCTG_CD.equals(that.DMOB_MCTG_CD));
    equal = equal && (this.DMOB_SCTG_CD == null ? that.DMOB_SCTG_CD == null : this.DMOB_SCTG_CD.equals(that.DMOB_SCTG_CD));
    equal = equal && (this.DMOB_TPIDS_LCTG_CD == null ? that.DMOB_TPIDS_LCTG_CD == null : this.DMOB_TPIDS_LCTG_CD.equals(that.DMOB_TPIDS_LCTG_CD));
    equal = equal && (this.DMOB_TPIDS_MCTG_CD == null ? that.DMOB_TPIDS_MCTG_CD == null : this.DMOB_TPIDS_MCTG_CD.equals(that.DMOB_TPIDS_MCTG_CD));
    equal = equal && (this.DMOB_TPIDS_SCTG_CD == null ? that.DMOB_TPIDS_SCTG_CD == null : this.DMOB_TPIDS_SCTG_CD.equals(that.DMOB_TPIDS_SCTG_CD));
    equal = equal && (this.DMOB_TPIDS_DCTG_CD == null ? that.DMOB_TPIDS_DCTG_CD == null : this.DMOB_TPIDS_DCTG_CD.equals(that.DMOB_TPIDS_DCTG_CD));
    equal = equal && (this.MCSH_FSHBT_DIV_CD == null ? that.MCSH_FSHBT_DIV_CD == null : this.MCSH_FSHBT_DIV_CD.equals(that.MCSH_FSHBT_DIV_CD));
    equal = equal && (this.SHAG == null ? that.SHAG == null : this.SHAG.equals(that.SHAG));
    equal = equal && (this.SHP_TP_CD == null ? that.SHP_TP_CD == null : this.SHP_TP_CD.equals(that.SHP_TP_CD));
    equal = equal && (this.SHP_CD == null ? that.SHP_CD == null : this.SHP_CD.equals(that.SHP_CD));
    equal = equal && (this.ARCRF_REG_NO == null ? that.ARCRF_REG_NO == null : this.ARCRF_REG_NO.equals(that.ARCRF_REG_NO));
    equal = equal && (this.CARG_TRN_ITM_CD == null ? that.CARG_TRN_ITM_CD == null : this.CARG_TRN_ITM_CD.equals(that.CARG_TRN_ITM_CD));
    equal = equal && (this.DTH_YN == null ? that.DTH_YN == null : this.DTH_YN.equals(that.DTH_YN));
    equal = equal && (this.AFOBS_YN == null ? that.AFOBS_YN == null : this.AFOBS_YN.equals(that.AFOBS_YN));
    equal = equal && (this.HSP_MD_EXP_YN == null ? that.HSP_MD_EXP_YN == null : this.HSP_MD_EXP_YN.equals(that.HSP_MD_EXP_YN));
    equal = equal && (this.GHR_MD_EXP_YN == null ? that.GHR_MD_EXP_YN == null : this.GHR_MD_EXP_YN.equals(that.GHR_MD_EXP_YN));
    equal = equal && (this.PSC_MD_EXP_YN == null ? that.PSC_MD_EXP_YN == null : this.PSC_MD_EXP_YN.equals(that.PSC_MD_EXP_YN));
    equal = equal && (this.HSP_DDPY_YN == null ? that.HSP_DDPY_YN == null : this.HSP_DDPY_YN.equals(that.HSP_DDPY_YN));
    equal = equal && (this.LAST_DGN_YN == null ? that.LAST_DGN_YN == null : this.LAST_DGN_YN.equals(that.LAST_DGN_YN));
    equal = equal && (this.SROP_YN == null ? that.SROP_YN == null : this.SROP_YN.equals(that.SROP_YN));
    equal = equal && (this.EXP_YN == null ? that.EXP_YN == null : this.EXP_YN.equals(that.EXP_YN));
    equal = equal && (this.SROP_BDW_YN == null ? that.SROP_BDW_YN == null : this.SROP_BDW_YN.equals(that.SROP_BDW_YN));
    equal = equal && (this.OS_ID == null ? that.OS_ID == null : this.OS_ID.equals(that.OS_ID));
    equal = equal && (this.OS_HIS_SEQ == null ? that.OS_HIS_SEQ == null : this.OS_HIS_SEQ.equals(that.OS_HIS_SEQ));
    equal = equal && (this.OS_SEQ == null ? that.OS_SEQ == null : this.OS_SEQ.equals(that.OS_SEQ));
    equal = equal && (this.OS_DIV_CD == null ? that.OS_DIV_CD == null : this.OS_DIV_CD.equals(that.OS_DIV_CD));
    equal = equal && (this.DCN_ID == null ? that.DCN_ID == null : this.DCN_ID.equals(that.DCN_ID));
    equal = equal && (this.DCN_HIS_SEQ == null ? that.DCN_HIS_SEQ == null : this.DCN_HIS_SEQ.equals(that.DCN_HIS_SEQ));
    equal = equal && (this.DCN_SEQ == null ? that.DCN_SEQ == null : this.DCN_SEQ.equals(that.DCN_SEQ));
    equal = equal && (this.DCN_DIV_CD == null ? that.DCN_DIV_CD == null : this.DCN_DIV_CD.equals(that.DCN_DIV_CD));
    equal = equal && (this.CNCLU_ID == null ? that.CNCLU_ID == null : this.CNCLU_ID.equals(that.CNCLU_ID));
    equal = equal && (this.CNCLU_HIS_SEQ == null ? that.CNCLU_HIS_SEQ == null : this.CNCLU_HIS_SEQ.equals(that.CNCLU_HIS_SEQ));
    equal = equal && (this.CNCLU_DIV_CD == null ? that.CNCLU_DIV_CD == null : this.CNCLU_DIV_CD.equals(that.CNCLU_DIV_CD));
    equal = equal && (this.CNCLU_DATA_DIV_CD == null ? that.CNCLU_DATA_DIV_CD == null : this.CNCLU_DATA_DIV_CD.equals(that.CNCLU_DATA_DIV_CD));
    equal = equal && (this.COV_INS_DATA_DIV_CD == null ? that.COV_INS_DATA_DIV_CD == null : this.COV_INS_DATA_DIV_CD.equals(that.COV_INS_DATA_DIV_CD));
    equal = equal && (this.COV_INS_HIS_SEQ == null ? that.COV_INS_HIS_SEQ == null : this.COV_INS_HIS_SEQ.equals(that.COV_INS_HIS_SEQ));
    equal = equal && (this.INS_AMT_APVL_DT == null ? that.INS_AMT_APVL_DT == null : this.INS_AMT_APVL_DT.equals(that.INS_AMT_APVL_DT));
    equal = equal && (this.CSS_COV_INS_HIS_SEQ == null ? that.CSS_COV_INS_HIS_SEQ == null : this.CSS_COV_INS_HIS_SEQ.equals(that.CSS_COV_INS_HIS_SEQ));
    equal = equal && (this.SPTPY_DIV_CD == null ? that.SPTPY_DIV_CD == null : this.SPTPY_DIV_CD.equals(that.SPTPY_DIV_CD));
    equal = equal && (this.ISD_PCS_SEQ == null ? that.ISD_PCS_SEQ == null : this.ISD_PCS_SEQ.equals(that.ISD_PCS_SEQ));
    equal = equal && (this.COV_CD == null ? that.COV_CD == null : this.COV_CD.equals(that.COV_CD));
    equal = equal && (this.INS_AMT_EXT_EXP_DIV_CD == null ? that.INS_AMT_EXT_EXP_DIV_CD == null : this.INS_AMT_EXT_EXP_DIV_CD.equals(that.INS_AMT_EXT_EXP_DIV_CD));
    equal = equal && (this.GURT_UNT_CD == null ? that.GURT_UNT_CD == null : this.GURT_UNT_CD.equals(that.GURT_UNT_CD));
    equal = equal && (this.RSK_UNT_CD == null ? that.RSK_UNT_CD == null : this.RSK_UNT_CD.equals(that.RSK_UNT_CD));
    equal = equal && (this.CLADJ_DIV_CTG_CD == null ? that.CLADJ_DIV_CTG_CD == null : this.CLADJ_DIV_CTG_CD.equals(that.CLADJ_DIV_CTG_CD));
    equal = equal && (this.BAS_SIC_DIV_CD == null ? that.BAS_SIC_DIV_CD == null : this.BAS_SIC_DIV_CD.equals(that.BAS_SIC_DIV_CD));
    equal = equal && (this.COV_INS_BGN_DT == null ? that.COV_INS_BGN_DT == null : this.COV_INS_BGN_DT.equals(that.COV_INS_BGN_DT));
    equal = equal && (this.COV_INS_ED_DT == null ? that.COV_INS_ED_DT == null : this.COV_INS_ED_DT.equals(that.COV_INS_ED_DT));
    equal = equal && (this.INSD_AMT_CUR_CD == null ? that.INSD_AMT_CUR_CD == null : this.INSD_AMT_CUR_CD.equals(that.INSD_AMT_CUR_CD));
    equal = equal && (this.CUR_INSD_AMT == null ? that.CUR_INSD_AMT == null : this.CUR_INSD_AMT.equals(that.CUR_INSD_AMT));
    equal = equal && (this.INSD_AMT == null ? that.INSD_AMT == null : this.INSD_AMT.equals(that.INSD_AMT));
    equal = equal && (this.PPS_COMS_LM_AMT == null ? that.PPS_COMS_LM_AMT == null : this.PPS_COMS_LM_AMT.equals(that.PPS_COMS_LM_AMT));
    equal = equal && (this.PACD_COMS_LM_AMT == null ? that.PACD_COMS_LM_AMT == null : this.PACD_COMS_LM_AMT.equals(that.PACD_COMS_LM_AMT));
    equal = equal && (this.LDCO_CTR_BZAC_CD == null ? that.LDCO_CTR_BZAC_CD == null : this.LDCO_CTR_BZAC_CD.equals(that.LDCO_CTR_BZAC_CD));
    equal = equal && (this.COI_CTR_BZAC_CD == null ? that.COI_CTR_BZAC_CD == null : this.COI_CTR_BZAC_CD.equals(that.COI_CTR_BZAC_CD));
    equal = equal && (this.CSS_COV_INS_SEQ == null ? that.CSS_COV_INS_SEQ == null : this.CSS_COV_INS_SEQ.equals(that.CSS_COV_INS_SEQ));
    equal = equal && (this.JNT_ACP_COV_INS_SEQ == null ? that.JNT_ACP_COV_INS_SEQ == null : this.JNT_ACP_COV_INS_SEQ.equals(that.JNT_ACP_COV_INS_SEQ));
    equal = equal && (this.PRTC_RT == null ? that.PRTC_RT == null : this.PRTC_RT.equals(that.PRTC_RT));
    equal = equal && (this.BRKR_CTR_BZAC_CD == null ? that.BRKR_CTR_BZAC_CD == null : this.BRKR_CTR_BZAC_CD.equals(that.BRKR_CTR_BZAC_CD));
    equal = equal && (this.RINCO_CTR_BZAC_CD == null ? that.RINCO_CTR_BZAC_CD == null : this.RINCO_CTR_BZAC_CD.equals(that.RINCO_CTR_BZAC_CD));
    equal = equal && (this.CLOG_APL_YN == null ? that.CLOG_APL_YN == null : this.CLOG_APL_YN.equals(that.CLOG_APL_YN));
    equal = equal && (this.CSS_CTR_ID == null ? that.CSS_CTR_ID == null : this.CSS_CTR_ID.equals(that.CSS_CTR_ID));
    equal = equal && (this.RINS_SH_DIV_CD == null ? that.RINS_SH_DIV_CD == null : this.RINS_SH_DIV_CD.equals(that.RINS_SH_DIV_CD));
    equal = equal && (this.BRKR_CSS_RT == null ? that.BRKR_CSS_RT == null : this.BRKR_CSS_RT.equals(that.BRKR_CSS_RT));
    equal = equal && (this.INSD_AMT_STD_CSS_RT == null ? that.INSD_AMT_STD_CSS_RT == null : this.INSD_AMT_STD_CSS_RT.equals(that.INSD_AMT_STD_CSS_RT));
    equal = equal && (this.ACP_AMT_STD_CSS_RT == null ? that.ACP_AMT_STD_CSS_RT == null : this.ACP_AMT_STD_CSS_RT.equals(that.ACP_AMT_STD_CSS_RT));
    equal = equal && (this.CUR_CD == null ? that.CUR_CD == null : this.CUR_CD.equals(that.CUR_CD));
    equal = equal && (this.APL_EXRT == null ? that.APL_EXRT == null : this.APL_EXRT.equals(that.APL_EXRT));
    equal = equal && (this.CSS_INS_AMT == null ? that.CSS_INS_AMT == null : this.CSS_INS_AMT.equals(that.CSS_INS_AMT));
    equal = equal && (this.KWCV_CSS_INS_AMT == null ? that.KWCV_CSS_INS_AMT == null : this.KWCV_CSS_INS_AMT.equals(that.KWCV_CSS_INS_AMT));
    equal = equal && (this.EIH_LDG_DTM == null ? that.EIH_LDG_DTM == null : this.EIH_LDG_DTM.equals(that.EIH_LDG_DTM));
    return equal;
  }
  public void readFields(ResultSet __dbResults) throws SQLException {
    this.__cur_result_set = __dbResults;
    this.CLOG_DT = JdbcWritableBridge.readTimestamp(1, __dbResults);
    this.CLM_ID = JdbcWritableBridge.readString(2, __dbResults);
    this.COV_INS_AMT_ID = JdbcWritableBridge.readString(3, __dbResults);
    this.CSS_COV_INS_AMT_ID = JdbcWritableBridge.readString(4, __dbResults);
    this.CLADJ_CLOG_DIV_CD = JdbcWritableBridge.readString(5, __dbResults);
    this.INS_ITMS_DIV_CD = JdbcWritableBridge.readString(6, __dbResults);
    this.BZPLN_PD_CTG_CD = JdbcWritableBridge.readString(7, __dbResults);
    this.PREBL_MNG_PD_CTG_CD = JdbcWritableBridge.readString(8, __dbResults);
    this.SAL_PD_CD = JdbcWritableBridge.readString(9, __dbResults);
    this.UNT_PD_CD = JdbcWritableBridge.readString(10, __dbResults);
    this.ACD_NO_YY = JdbcWritableBridge.readString(11, __dbResults);
    this.ACD_NO_SEQ = JdbcWritableBridge.readBigDecimal(12, __dbResults);
    this.ACD_RCT_ID = JdbcWritableBridge.readString(13, __dbResults);
    this.ACD_RCT_HIS_SEQ = JdbcWritableBridge.readBigDecimal(14, __dbResults);
    this.RCT_DTM = JdbcWritableBridge.readTimestamp(15, __dbResults);
    this.RCT_DT = JdbcWritableBridge.readTimestamp(16, __dbResults);
    this.ACD_DTM = JdbcWritableBridge.readTimestamp(17, __dbResults);
    this.ACD_DT = JdbcWritableBridge.readTimestamp(18, __dbResults);
    this.HOLI_YN = JdbcWritableBridge.readString(19, __dbResults);
    this.OD_ACD_NO = JdbcWritableBridge.readString(20, __dbResults);
    this.OTHCO_ACD_NO = JdbcWritableBridge.readString(21, __dbResults);
    this.ACD_WKD_CD = JdbcWritableBridge.readString(22, __dbResults);
    this.CITY_NATL_CD = JdbcWritableBridge.readString(23, __dbResults);
    this.ACD_PLC_ZPCD = JdbcWritableBridge.readString(24, __dbResults);
    this.ACD_PLC_ZPCD_SNO = JdbcWritableBridge.readString(25, __dbResults);
    this.ACD_PLC_ZPCD_ADR = JdbcWritableBridge.readString(26, __dbResults);
    this.ACD_PLC_DTL_ADR_CON = JdbcWritableBridge.readString(27, __dbResults);
    this.LTT_DIV_CD = JdbcWritableBridge.readString(28, __dbResults);
    this.LTT_COO_DG = JdbcWritableBridge.readBigDecimal(29, __dbResults);
    this.LTT_COO_MI = JdbcWritableBridge.readBigDecimal(30, __dbResults);
    this.LTT_COO_SS = JdbcWritableBridge.readBigDecimal(31, __dbResults);
    this.LNT_DIV_CD = JdbcWritableBridge.readString(32, __dbResults);
    this.LNT_COO_DG = JdbcWritableBridge.readBigDecimal(33, __dbResults);
    this.LNT_COO_MI = JdbcWritableBridge.readBigDecimal(34, __dbResults);
    this.LNT_COO_SS = JdbcWritableBridge.readBigDecimal(35, __dbResults);
    this.ACD_CTR_ID = JdbcWritableBridge.readString(36, __dbResults);
    this.ACD_CTR_HIS_SEQ = JdbcWritableBridge.readBigDecimal(37, __dbResults);
    this.POL_NO = JdbcWritableBridge.readString(38, __dbResults);
    this.CTR_ENDR_NO = JdbcWritableBridge.readBigDecimal(39, __dbResults);
    this.RTRO_ENDR_NO = JdbcWritableBridge.readBigDecimal(40, __dbResults);
    this.ENDR_HIS_STD_NO = JdbcWritableBridge.readBigDecimal(41, __dbResults);
    this.POLHD_CUS_ID = JdbcWritableBridge.readString(42, __dbResults);
    this.POLHD_NM = JdbcWritableBridge.readString(43, __dbResults);
    this.CTR_STAT_CD = JdbcWritableBridge.readString(44, __dbResults);
    this.CTR_STAT_DTL_CD = JdbcWritableBridge.readString(45, __dbResults);
    this.INS_BGN_DT = JdbcWritableBridge.readTimestamp(46, __dbResults);
    this.INS_ED_DT = JdbcWritableBridge.readTimestamp(47, __dbResults);
    this.SBCP_DT = JdbcWritableBridge.readTimestamp(48, __dbResults);
    this.ACP_SH_DIV_CD = JdbcWritableBridge.readString(49, __dbResults);
    this.MRIN_PD_DIV_CD = JdbcWritableBridge.readString(50, __dbResults);
    this.MA_INSPE_CUS_ID = JdbcWritableBridge.readString(51, __dbResults);
    this.MA_INSPE_NM = JdbcWritableBridge.readString(52, __dbResults);
    this.ORIG_RTRC_DIV_CD = JdbcWritableBridge.readString(53, __dbResults);
    this.PLR_STUP_YN = JdbcWritableBridge.readString(54, __dbResults);
    this.TRT_HDQT_ORG_CD = JdbcWritableBridge.readString(55, __dbResults);
    this.TRT_BCH_ORG_CD = JdbcWritableBridge.readString(56, __dbResults);
    this.TRT_BRCH_ORG_CD = JdbcWritableBridge.readString(57, __dbResults);
    this.TRTPE_ORG_ID = JdbcWritableBridge.readString(58, __dbResults);
    this.TRTPE_ORG_CD = JdbcWritableBridge.readString(59, __dbResults);
    this.CLM_TP_CD = JdbcWritableBridge.readString(60, __dbResults);
    this.DSS_CD_YY = JdbcWritableBridge.readString(61, __dbResults);
    this.DSS_CD_SEQ = JdbcWritableBridge.readBigDecimal(62, __dbResults);
    this.CLM_STAT_CD = JdbcWritableBridge.readString(63, __dbResults);
    this.ACD_CAUS_LCTG_CD = JdbcWritableBridge.readString(64, __dbResults);
    this.ACD_CAUS_MCTG_CD = JdbcWritableBridge.readString(65, __dbResults);
    this.ACD_CAUS_SCTG_CD = JdbcWritableBridge.readString(66, __dbResults);
    this.ACD_CAUS_DCTG_CD = JdbcWritableBridge.readString(67, __dbResults);
    this.ACD_CAUS_DCTG2_CD = JdbcWritableBridge.readString(68, __dbResults);
    this.COMS_PART_ORG_ID = JdbcWritableBridge.readString(69, __dbResults);
    this.COMS_PART_ORG_CD = JdbcWritableBridge.readString(70, __dbResults);
    this.COMS_TEM_ORG_ID = JdbcWritableBridge.readString(71, __dbResults);
    this.COMS_TEM_ORG_CD = JdbcWritableBridge.readString(72, __dbResults);
    this.COMS_CHRPE_ORG_ID = JdbcWritableBridge.readString(73, __dbResults);
    this.CPIC_ORG_CD = JdbcWritableBridge.readString(74, __dbResults);
    this.CNCLU_DT = JdbcWritableBridge.readTimestamp(75, __dbResults);
    this.EXMP_DCN_DT = JdbcWritableBridge.readTimestamp(76, __dbResults);
    this.DAM_DGR_CD = JdbcWritableBridge.readString(77, __dbResults);
    this.AT_ISP_YN = JdbcWritableBridge.readString(78, __dbResults);
    this.ACD_CTR_OBJ_ID = JdbcWritableBridge.readString(79, __dbResults);
    this.ACD_CTR_OBJ_HIS_SEQ = JdbcWritableBridge.readBigDecimal(80, __dbResults);
    this.ACD_OBJ_DIV_CD = JdbcWritableBridge.readString(81, __dbResults);
    this.ACD_OBJ_ID = JdbcWritableBridge.readString(82, __dbResults);
    this.DAM_ORD = JdbcWritableBridge.readBigDecimal(83, __dbResults);
    this.CTR_OBJ_ID = JdbcWritableBridge.readString(84, __dbResults);
    this.CTR_OBJ_ADR_ID = JdbcWritableBridge.readString(85, __dbResults);
    this.OBJ_TP_CD = JdbcWritableBridge.readString(86, __dbResults);
    this.DMPE_CUS_ID = JdbcWritableBridge.readString(87, __dbResults);
    this.DMPO_NM = JdbcWritableBridge.readString(88, __dbResults);
    this.PVDS_YN = JdbcWritableBridge.readString(89, __dbResults);
    this.TCTR_DMPE_JOB_GRD_CD = JdbcWritableBridge.readString(90, __dbResults);
    this.TCTR_DMPE_JOB_CD = JdbcWritableBridge.readString(91, __dbResults);
    this.TACD_DMPE_JOB_GRD_CD = JdbcWritableBridge.readString(92, __dbResults);
    this.TACD_DMPE_JOB_CD = JdbcWritableBridge.readString(93, __dbResults);
    this.OWNR_NM = JdbcWritableBridge.readString(94, __dbResults);
    this.DMPE_AGE = JdbcWritableBridge.readBigDecimal(95, __dbResults);
    this.TNG_DIV_CD = JdbcWritableBridge.readString(96, __dbResults);
    this.OBJ_GRD_CD = JdbcWritableBridge.readString(97, __dbResults);
    this.OPN_JBCL_CD = JdbcWritableBridge.readString(98, __dbResults);
    this.OPJB_NM = JdbcWritableBridge.readString(99, __dbResults);
    this.OBJ_CD = JdbcWritableBridge.readString(100, __dbResults);
    this.DMOB_LCTG_CD = JdbcWritableBridge.readString(101, __dbResults);
    this.DMOB_MCTG_CD = JdbcWritableBridge.readString(102, __dbResults);
    this.DMOB_SCTG_CD = JdbcWritableBridge.readString(103, __dbResults);
    this.DMOB_TPIDS_LCTG_CD = JdbcWritableBridge.readString(104, __dbResults);
    this.DMOB_TPIDS_MCTG_CD = JdbcWritableBridge.readString(105, __dbResults);
    this.DMOB_TPIDS_SCTG_CD = JdbcWritableBridge.readString(106, __dbResults);
    this.DMOB_TPIDS_DCTG_CD = JdbcWritableBridge.readString(107, __dbResults);
    this.MCSH_FSHBT_DIV_CD = JdbcWritableBridge.readString(108, __dbResults);
    this.SHAG = JdbcWritableBridge.readBigDecimal(109, __dbResults);
    this.SHP_TP_CD = JdbcWritableBridge.readString(110, __dbResults);
    this.SHP_CD = JdbcWritableBridge.readString(111, __dbResults);
    this.ARCRF_REG_NO = JdbcWritableBridge.readString(112, __dbResults);
    this.CARG_TRN_ITM_CD = JdbcWritableBridge.readString(113, __dbResults);
    this.DTH_YN = JdbcWritableBridge.readString(114, __dbResults);
    this.AFOBS_YN = JdbcWritableBridge.readString(115, __dbResults);
    this.HSP_MD_EXP_YN = JdbcWritableBridge.readString(116, __dbResults);
    this.GHR_MD_EXP_YN = JdbcWritableBridge.readString(117, __dbResults);
    this.PSC_MD_EXP_YN = JdbcWritableBridge.readString(118, __dbResults);
    this.HSP_DDPY_YN = JdbcWritableBridge.readString(119, __dbResults);
    this.LAST_DGN_YN = JdbcWritableBridge.readString(120, __dbResults);
    this.SROP_YN = JdbcWritableBridge.readString(121, __dbResults);
    this.EXP_YN = JdbcWritableBridge.readString(122, __dbResults);
    this.SROP_BDW_YN = JdbcWritableBridge.readString(123, __dbResults);
    this.OS_ID = JdbcWritableBridge.readString(124, __dbResults);
    this.OS_HIS_SEQ = JdbcWritableBridge.readBigDecimal(125, __dbResults);
    this.OS_SEQ = JdbcWritableBridge.readBigDecimal(126, __dbResults);
    this.OS_DIV_CD = JdbcWritableBridge.readString(127, __dbResults);
    this.DCN_ID = JdbcWritableBridge.readString(128, __dbResults);
    this.DCN_HIS_SEQ = JdbcWritableBridge.readBigDecimal(129, __dbResults);
    this.DCN_SEQ = JdbcWritableBridge.readBigDecimal(130, __dbResults);
    this.DCN_DIV_CD = JdbcWritableBridge.readString(131, __dbResults);
    this.CNCLU_ID = JdbcWritableBridge.readString(132, __dbResults);
    this.CNCLU_HIS_SEQ = JdbcWritableBridge.readBigDecimal(133, __dbResults);
    this.CNCLU_DIV_CD = JdbcWritableBridge.readString(134, __dbResults);
    this.CNCLU_DATA_DIV_CD = JdbcWritableBridge.readString(135, __dbResults);
    this.COV_INS_DATA_DIV_CD = JdbcWritableBridge.readString(136, __dbResults);
    this.COV_INS_HIS_SEQ = JdbcWritableBridge.readBigDecimal(137, __dbResults);
    this.INS_AMT_APVL_DT = JdbcWritableBridge.readTimestamp(138, __dbResults);
    this.CSS_COV_INS_HIS_SEQ = JdbcWritableBridge.readBigDecimal(139, __dbResults);
    this.SPTPY_DIV_CD = JdbcWritableBridge.readString(140, __dbResults);
    this.ISD_PCS_SEQ = JdbcWritableBridge.readBigDecimal(141, __dbResults);
    this.COV_CD = JdbcWritableBridge.readString(142, __dbResults);
    this.INS_AMT_EXT_EXP_DIV_CD = JdbcWritableBridge.readString(143, __dbResults);
    this.GURT_UNT_CD = JdbcWritableBridge.readString(144, __dbResults);
    this.RSK_UNT_CD = JdbcWritableBridge.readString(145, __dbResults);
    this.CLADJ_DIV_CTG_CD = JdbcWritableBridge.readString(146, __dbResults);
    this.BAS_SIC_DIV_CD = JdbcWritableBridge.readString(147, __dbResults);
    this.COV_INS_BGN_DT = JdbcWritableBridge.readTimestamp(148, __dbResults);
    this.COV_INS_ED_DT = JdbcWritableBridge.readTimestamp(149, __dbResults);
    this.INSD_AMT_CUR_CD = JdbcWritableBridge.readString(150, __dbResults);
    this.CUR_INSD_AMT = JdbcWritableBridge.readBigDecimal(151, __dbResults);
    this.INSD_AMT = JdbcWritableBridge.readBigDecimal(152, __dbResults);
    this.PPS_COMS_LM_AMT = JdbcWritableBridge.readBigDecimal(153, __dbResults);
    this.PACD_COMS_LM_AMT = JdbcWritableBridge.readBigDecimal(154, __dbResults);
    this.LDCO_CTR_BZAC_CD = JdbcWritableBridge.readString(155, __dbResults);
    this.COI_CTR_BZAC_CD = JdbcWritableBridge.readString(156, __dbResults);
    this.CSS_COV_INS_SEQ = JdbcWritableBridge.readBigDecimal(157, __dbResults);
    this.JNT_ACP_COV_INS_SEQ = JdbcWritableBridge.readBigDecimal(158, __dbResults);
    this.PRTC_RT = JdbcWritableBridge.readBigDecimal(159, __dbResults);
    this.BRKR_CTR_BZAC_CD = JdbcWritableBridge.readString(160, __dbResults);
    this.RINCO_CTR_BZAC_CD = JdbcWritableBridge.readString(161, __dbResults);
    this.CLOG_APL_YN = JdbcWritableBridge.readString(162, __dbResults);
    this.CSS_CTR_ID = JdbcWritableBridge.readString(163, __dbResults);
    this.RINS_SH_DIV_CD = JdbcWritableBridge.readString(164, __dbResults);
    this.BRKR_CSS_RT = JdbcWritableBridge.readBigDecimal(165, __dbResults);
    this.INSD_AMT_STD_CSS_RT = JdbcWritableBridge.readBigDecimal(166, __dbResults);
    this.ACP_AMT_STD_CSS_RT = JdbcWritableBridge.readBigDecimal(167, __dbResults);
    this.CUR_CD = JdbcWritableBridge.readString(168, __dbResults);
    this.APL_EXRT = JdbcWritableBridge.readBigDecimal(169, __dbResults);
    this.CSS_INS_AMT = JdbcWritableBridge.readBigDecimal(170, __dbResults);
    this.KWCV_CSS_INS_AMT = JdbcWritableBridge.readBigDecimal(171, __dbResults);
    this.EIH_LDG_DTM = JdbcWritableBridge.readTimestamp(172, __dbResults);
  }
  public void readFields0(ResultSet __dbResults) throws SQLException {
    this.CLOG_DT = JdbcWritableBridge.readTimestamp(1, __dbResults);
    this.CLM_ID = JdbcWritableBridge.readString(2, __dbResults);
    this.COV_INS_AMT_ID = JdbcWritableBridge.readString(3, __dbResults);
    this.CSS_COV_INS_AMT_ID = JdbcWritableBridge.readString(4, __dbResults);
    this.CLADJ_CLOG_DIV_CD = JdbcWritableBridge.readString(5, __dbResults);
    this.INS_ITMS_DIV_CD = JdbcWritableBridge.readString(6, __dbResults);
    this.BZPLN_PD_CTG_CD = JdbcWritableBridge.readString(7, __dbResults);
    this.PREBL_MNG_PD_CTG_CD = JdbcWritableBridge.readString(8, __dbResults);
    this.SAL_PD_CD = JdbcWritableBridge.readString(9, __dbResults);
    this.UNT_PD_CD = JdbcWritableBridge.readString(10, __dbResults);
    this.ACD_NO_YY = JdbcWritableBridge.readString(11, __dbResults);
    this.ACD_NO_SEQ = JdbcWritableBridge.readBigDecimal(12, __dbResults);
    this.ACD_RCT_ID = JdbcWritableBridge.readString(13, __dbResults);
    this.ACD_RCT_HIS_SEQ = JdbcWritableBridge.readBigDecimal(14, __dbResults);
    this.RCT_DTM = JdbcWritableBridge.readTimestamp(15, __dbResults);
    this.RCT_DT = JdbcWritableBridge.readTimestamp(16, __dbResults);
    this.ACD_DTM = JdbcWritableBridge.readTimestamp(17, __dbResults);
    this.ACD_DT = JdbcWritableBridge.readTimestamp(18, __dbResults);
    this.HOLI_YN = JdbcWritableBridge.readString(19, __dbResults);
    this.OD_ACD_NO = JdbcWritableBridge.readString(20, __dbResults);
    this.OTHCO_ACD_NO = JdbcWritableBridge.readString(21, __dbResults);
    this.ACD_WKD_CD = JdbcWritableBridge.readString(22, __dbResults);
    this.CITY_NATL_CD = JdbcWritableBridge.readString(23, __dbResults);
    this.ACD_PLC_ZPCD = JdbcWritableBridge.readString(24, __dbResults);
    this.ACD_PLC_ZPCD_SNO = JdbcWritableBridge.readString(25, __dbResults);
    this.ACD_PLC_ZPCD_ADR = JdbcWritableBridge.readString(26, __dbResults);
    this.ACD_PLC_DTL_ADR_CON = JdbcWritableBridge.readString(27, __dbResults);
    this.LTT_DIV_CD = JdbcWritableBridge.readString(28, __dbResults);
    this.LTT_COO_DG = JdbcWritableBridge.readBigDecimal(29, __dbResults);
    this.LTT_COO_MI = JdbcWritableBridge.readBigDecimal(30, __dbResults);
    this.LTT_COO_SS = JdbcWritableBridge.readBigDecimal(31, __dbResults);
    this.LNT_DIV_CD = JdbcWritableBridge.readString(32, __dbResults);
    this.LNT_COO_DG = JdbcWritableBridge.readBigDecimal(33, __dbResults);
    this.LNT_COO_MI = JdbcWritableBridge.readBigDecimal(34, __dbResults);
    this.LNT_COO_SS = JdbcWritableBridge.readBigDecimal(35, __dbResults);
    this.ACD_CTR_ID = JdbcWritableBridge.readString(36, __dbResults);
    this.ACD_CTR_HIS_SEQ = JdbcWritableBridge.readBigDecimal(37, __dbResults);
    this.POL_NO = JdbcWritableBridge.readString(38, __dbResults);
    this.CTR_ENDR_NO = JdbcWritableBridge.readBigDecimal(39, __dbResults);
    this.RTRO_ENDR_NO = JdbcWritableBridge.readBigDecimal(40, __dbResults);
    this.ENDR_HIS_STD_NO = JdbcWritableBridge.readBigDecimal(41, __dbResults);
    this.POLHD_CUS_ID = JdbcWritableBridge.readString(42, __dbResults);
    this.POLHD_NM = JdbcWritableBridge.readString(43, __dbResults);
    this.CTR_STAT_CD = JdbcWritableBridge.readString(44, __dbResults);
    this.CTR_STAT_DTL_CD = JdbcWritableBridge.readString(45, __dbResults);
    this.INS_BGN_DT = JdbcWritableBridge.readTimestamp(46, __dbResults);
    this.INS_ED_DT = JdbcWritableBridge.readTimestamp(47, __dbResults);
    this.SBCP_DT = JdbcWritableBridge.readTimestamp(48, __dbResults);
    this.ACP_SH_DIV_CD = JdbcWritableBridge.readString(49, __dbResults);
    this.MRIN_PD_DIV_CD = JdbcWritableBridge.readString(50, __dbResults);
    this.MA_INSPE_CUS_ID = JdbcWritableBridge.readString(51, __dbResults);
    this.MA_INSPE_NM = JdbcWritableBridge.readString(52, __dbResults);
    this.ORIG_RTRC_DIV_CD = JdbcWritableBridge.readString(53, __dbResults);
    this.PLR_STUP_YN = JdbcWritableBridge.readString(54, __dbResults);
    this.TRT_HDQT_ORG_CD = JdbcWritableBridge.readString(55, __dbResults);
    this.TRT_BCH_ORG_CD = JdbcWritableBridge.readString(56, __dbResults);
    this.TRT_BRCH_ORG_CD = JdbcWritableBridge.readString(57, __dbResults);
    this.TRTPE_ORG_ID = JdbcWritableBridge.readString(58, __dbResults);
    this.TRTPE_ORG_CD = JdbcWritableBridge.readString(59, __dbResults);
    this.CLM_TP_CD = JdbcWritableBridge.readString(60, __dbResults);
    this.DSS_CD_YY = JdbcWritableBridge.readString(61, __dbResults);
    this.DSS_CD_SEQ = JdbcWritableBridge.readBigDecimal(62, __dbResults);
    this.CLM_STAT_CD = JdbcWritableBridge.readString(63, __dbResults);
    this.ACD_CAUS_LCTG_CD = JdbcWritableBridge.readString(64, __dbResults);
    this.ACD_CAUS_MCTG_CD = JdbcWritableBridge.readString(65, __dbResults);
    this.ACD_CAUS_SCTG_CD = JdbcWritableBridge.readString(66, __dbResults);
    this.ACD_CAUS_DCTG_CD = JdbcWritableBridge.readString(67, __dbResults);
    this.ACD_CAUS_DCTG2_CD = JdbcWritableBridge.readString(68, __dbResults);
    this.COMS_PART_ORG_ID = JdbcWritableBridge.readString(69, __dbResults);
    this.COMS_PART_ORG_CD = JdbcWritableBridge.readString(70, __dbResults);
    this.COMS_TEM_ORG_ID = JdbcWritableBridge.readString(71, __dbResults);
    this.COMS_TEM_ORG_CD = JdbcWritableBridge.readString(72, __dbResults);
    this.COMS_CHRPE_ORG_ID = JdbcWritableBridge.readString(73, __dbResults);
    this.CPIC_ORG_CD = JdbcWritableBridge.readString(74, __dbResults);
    this.CNCLU_DT = JdbcWritableBridge.readTimestamp(75, __dbResults);
    this.EXMP_DCN_DT = JdbcWritableBridge.readTimestamp(76, __dbResults);
    this.DAM_DGR_CD = JdbcWritableBridge.readString(77, __dbResults);
    this.AT_ISP_YN = JdbcWritableBridge.readString(78, __dbResults);
    this.ACD_CTR_OBJ_ID = JdbcWritableBridge.readString(79, __dbResults);
    this.ACD_CTR_OBJ_HIS_SEQ = JdbcWritableBridge.readBigDecimal(80, __dbResults);
    this.ACD_OBJ_DIV_CD = JdbcWritableBridge.readString(81, __dbResults);
    this.ACD_OBJ_ID = JdbcWritableBridge.readString(82, __dbResults);
    this.DAM_ORD = JdbcWritableBridge.readBigDecimal(83, __dbResults);
    this.CTR_OBJ_ID = JdbcWritableBridge.readString(84, __dbResults);
    this.CTR_OBJ_ADR_ID = JdbcWritableBridge.readString(85, __dbResults);
    this.OBJ_TP_CD = JdbcWritableBridge.readString(86, __dbResults);
    this.DMPE_CUS_ID = JdbcWritableBridge.readString(87, __dbResults);
    this.DMPO_NM = JdbcWritableBridge.readString(88, __dbResults);
    this.PVDS_YN = JdbcWritableBridge.readString(89, __dbResults);
    this.TCTR_DMPE_JOB_GRD_CD = JdbcWritableBridge.readString(90, __dbResults);
    this.TCTR_DMPE_JOB_CD = JdbcWritableBridge.readString(91, __dbResults);
    this.TACD_DMPE_JOB_GRD_CD = JdbcWritableBridge.readString(92, __dbResults);
    this.TACD_DMPE_JOB_CD = JdbcWritableBridge.readString(93, __dbResults);
    this.OWNR_NM = JdbcWritableBridge.readString(94, __dbResults);
    this.DMPE_AGE = JdbcWritableBridge.readBigDecimal(95, __dbResults);
    this.TNG_DIV_CD = JdbcWritableBridge.readString(96, __dbResults);
    this.OBJ_GRD_CD = JdbcWritableBridge.readString(97, __dbResults);
    this.OPN_JBCL_CD = JdbcWritableBridge.readString(98, __dbResults);
    this.OPJB_NM = JdbcWritableBridge.readString(99, __dbResults);
    this.OBJ_CD = JdbcWritableBridge.readString(100, __dbResults);
    this.DMOB_LCTG_CD = JdbcWritableBridge.readString(101, __dbResults);
    this.DMOB_MCTG_CD = JdbcWritableBridge.readString(102, __dbResults);
    this.DMOB_SCTG_CD = JdbcWritableBridge.readString(103, __dbResults);
    this.DMOB_TPIDS_LCTG_CD = JdbcWritableBridge.readString(104, __dbResults);
    this.DMOB_TPIDS_MCTG_CD = JdbcWritableBridge.readString(105, __dbResults);
    this.DMOB_TPIDS_SCTG_CD = JdbcWritableBridge.readString(106, __dbResults);
    this.DMOB_TPIDS_DCTG_CD = JdbcWritableBridge.readString(107, __dbResults);
    this.MCSH_FSHBT_DIV_CD = JdbcWritableBridge.readString(108, __dbResults);
    this.SHAG = JdbcWritableBridge.readBigDecimal(109, __dbResults);
    this.SHP_TP_CD = JdbcWritableBridge.readString(110, __dbResults);
    this.SHP_CD = JdbcWritableBridge.readString(111, __dbResults);
    this.ARCRF_REG_NO = JdbcWritableBridge.readString(112, __dbResults);
    this.CARG_TRN_ITM_CD = JdbcWritableBridge.readString(113, __dbResults);
    this.DTH_YN = JdbcWritableBridge.readString(114, __dbResults);
    this.AFOBS_YN = JdbcWritableBridge.readString(115, __dbResults);
    this.HSP_MD_EXP_YN = JdbcWritableBridge.readString(116, __dbResults);
    this.GHR_MD_EXP_YN = JdbcWritableBridge.readString(117, __dbResults);
    this.PSC_MD_EXP_YN = JdbcWritableBridge.readString(118, __dbResults);
    this.HSP_DDPY_YN = JdbcWritableBridge.readString(119, __dbResults);
    this.LAST_DGN_YN = JdbcWritableBridge.readString(120, __dbResults);
    this.SROP_YN = JdbcWritableBridge.readString(121, __dbResults);
    this.EXP_YN = JdbcWritableBridge.readString(122, __dbResults);
    this.SROP_BDW_YN = JdbcWritableBridge.readString(123, __dbResults);
    this.OS_ID = JdbcWritableBridge.readString(124, __dbResults);
    this.OS_HIS_SEQ = JdbcWritableBridge.readBigDecimal(125, __dbResults);
    this.OS_SEQ = JdbcWritableBridge.readBigDecimal(126, __dbResults);
    this.OS_DIV_CD = JdbcWritableBridge.readString(127, __dbResults);
    this.DCN_ID = JdbcWritableBridge.readString(128, __dbResults);
    this.DCN_HIS_SEQ = JdbcWritableBridge.readBigDecimal(129, __dbResults);
    this.DCN_SEQ = JdbcWritableBridge.readBigDecimal(130, __dbResults);
    this.DCN_DIV_CD = JdbcWritableBridge.readString(131, __dbResults);
    this.CNCLU_ID = JdbcWritableBridge.readString(132, __dbResults);
    this.CNCLU_HIS_SEQ = JdbcWritableBridge.readBigDecimal(133, __dbResults);
    this.CNCLU_DIV_CD = JdbcWritableBridge.readString(134, __dbResults);
    this.CNCLU_DATA_DIV_CD = JdbcWritableBridge.readString(135, __dbResults);
    this.COV_INS_DATA_DIV_CD = JdbcWritableBridge.readString(136, __dbResults);
    this.COV_INS_HIS_SEQ = JdbcWritableBridge.readBigDecimal(137, __dbResults);
    this.INS_AMT_APVL_DT = JdbcWritableBridge.readTimestamp(138, __dbResults);
    this.CSS_COV_INS_HIS_SEQ = JdbcWritableBridge.readBigDecimal(139, __dbResults);
    this.SPTPY_DIV_CD = JdbcWritableBridge.readString(140, __dbResults);
    this.ISD_PCS_SEQ = JdbcWritableBridge.readBigDecimal(141, __dbResults);
    this.COV_CD = JdbcWritableBridge.readString(142, __dbResults);
    this.INS_AMT_EXT_EXP_DIV_CD = JdbcWritableBridge.readString(143, __dbResults);
    this.GURT_UNT_CD = JdbcWritableBridge.readString(144, __dbResults);
    this.RSK_UNT_CD = JdbcWritableBridge.readString(145, __dbResults);
    this.CLADJ_DIV_CTG_CD = JdbcWritableBridge.readString(146, __dbResults);
    this.BAS_SIC_DIV_CD = JdbcWritableBridge.readString(147, __dbResults);
    this.COV_INS_BGN_DT = JdbcWritableBridge.readTimestamp(148, __dbResults);
    this.COV_INS_ED_DT = JdbcWritableBridge.readTimestamp(149, __dbResults);
    this.INSD_AMT_CUR_CD = JdbcWritableBridge.readString(150, __dbResults);
    this.CUR_INSD_AMT = JdbcWritableBridge.readBigDecimal(151, __dbResults);
    this.INSD_AMT = JdbcWritableBridge.readBigDecimal(152, __dbResults);
    this.PPS_COMS_LM_AMT = JdbcWritableBridge.readBigDecimal(153, __dbResults);
    this.PACD_COMS_LM_AMT = JdbcWritableBridge.readBigDecimal(154, __dbResults);
    this.LDCO_CTR_BZAC_CD = JdbcWritableBridge.readString(155, __dbResults);
    this.COI_CTR_BZAC_CD = JdbcWritableBridge.readString(156, __dbResults);
    this.CSS_COV_INS_SEQ = JdbcWritableBridge.readBigDecimal(157, __dbResults);
    this.JNT_ACP_COV_INS_SEQ = JdbcWritableBridge.readBigDecimal(158, __dbResults);
    this.PRTC_RT = JdbcWritableBridge.readBigDecimal(159, __dbResults);
    this.BRKR_CTR_BZAC_CD = JdbcWritableBridge.readString(160, __dbResults);
    this.RINCO_CTR_BZAC_CD = JdbcWritableBridge.readString(161, __dbResults);
    this.CLOG_APL_YN = JdbcWritableBridge.readString(162, __dbResults);
    this.CSS_CTR_ID = JdbcWritableBridge.readString(163, __dbResults);
    this.RINS_SH_DIV_CD = JdbcWritableBridge.readString(164, __dbResults);
    this.BRKR_CSS_RT = JdbcWritableBridge.readBigDecimal(165, __dbResults);
    this.INSD_AMT_STD_CSS_RT = JdbcWritableBridge.readBigDecimal(166, __dbResults);
    this.ACP_AMT_STD_CSS_RT = JdbcWritableBridge.readBigDecimal(167, __dbResults);
    this.CUR_CD = JdbcWritableBridge.readString(168, __dbResults);
    this.APL_EXRT = JdbcWritableBridge.readBigDecimal(169, __dbResults);
    this.CSS_INS_AMT = JdbcWritableBridge.readBigDecimal(170, __dbResults);
    this.KWCV_CSS_INS_AMT = JdbcWritableBridge.readBigDecimal(171, __dbResults);
    this.EIH_LDG_DTM = JdbcWritableBridge.readTimestamp(172, __dbResults);
  }
  public void loadLargeObjects(LargeObjectLoader __loader)
      throws SQLException, IOException, InterruptedException {
  }
  public void loadLargeObjects0(LargeObjectLoader __loader)
      throws SQLException, IOException, InterruptedException {
  }
  public void write(PreparedStatement __dbStmt) throws SQLException {
    write(__dbStmt, 0);
  }

  public int write(PreparedStatement __dbStmt, int __off) throws SQLException {
    JdbcWritableBridge.writeTimestamp(CLOG_DT, 1 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeString(CLM_ID, 2 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(COV_INS_AMT_ID, 3 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(CSS_COV_INS_AMT_ID, 4 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(CLADJ_CLOG_DIV_CD, 5 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(INS_ITMS_DIV_CD, 6 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(BZPLN_PD_CTG_CD, 7 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(PREBL_MNG_PD_CTG_CD, 8 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(SAL_PD_CD, 9 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(UNT_PD_CD, 10 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(ACD_NO_YY, 11 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(ACD_NO_SEQ, 12 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(ACD_RCT_ID, 13 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(ACD_RCT_HIS_SEQ, 14 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeTimestamp(RCT_DTM, 15 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeTimestamp(RCT_DT, 16 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeTimestamp(ACD_DTM, 17 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeTimestamp(ACD_DT, 18 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeString(HOLI_YN, 19 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(OD_ACD_NO, 20 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(OTHCO_ACD_NO, 21 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(ACD_WKD_CD, 22 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(CITY_NATL_CD, 23 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(ACD_PLC_ZPCD, 24 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(ACD_PLC_ZPCD_SNO, 25 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(ACD_PLC_ZPCD_ADR, 26 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(ACD_PLC_DTL_ADR_CON, 27 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(LTT_DIV_CD, 28 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(LTT_COO_DG, 29 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(LTT_COO_MI, 30 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(LTT_COO_SS, 31 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(LNT_DIV_CD, 32 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(LNT_COO_DG, 33 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(LNT_COO_MI, 34 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(LNT_COO_SS, 35 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(ACD_CTR_ID, 36 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(ACD_CTR_HIS_SEQ, 37 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(POL_NO, 38 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(CTR_ENDR_NO, 39 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(RTRO_ENDR_NO, 40 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(ENDR_HIS_STD_NO, 41 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(POLHD_CUS_ID, 42 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(POLHD_NM, 43 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(CTR_STAT_CD, 44 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(CTR_STAT_DTL_CD, 45 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeTimestamp(INS_BGN_DT, 46 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeTimestamp(INS_ED_DT, 47 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeTimestamp(SBCP_DT, 48 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeString(ACP_SH_DIV_CD, 49 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(MRIN_PD_DIV_CD, 50 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(MA_INSPE_CUS_ID, 51 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(MA_INSPE_NM, 52 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(ORIG_RTRC_DIV_CD, 53 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(PLR_STUP_YN, 54 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(TRT_HDQT_ORG_CD, 55 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(TRT_BCH_ORG_CD, 56 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(TRT_BRCH_ORG_CD, 57 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(TRTPE_ORG_ID, 58 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(TRTPE_ORG_CD, 59 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(CLM_TP_CD, 60 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(DSS_CD_YY, 61 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(DSS_CD_SEQ, 62 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(CLM_STAT_CD, 63 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(ACD_CAUS_LCTG_CD, 64 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(ACD_CAUS_MCTG_CD, 65 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(ACD_CAUS_SCTG_CD, 66 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(ACD_CAUS_DCTG_CD, 67 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(ACD_CAUS_DCTG2_CD, 68 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(COMS_PART_ORG_ID, 69 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(COMS_PART_ORG_CD, 70 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(COMS_TEM_ORG_ID, 71 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(COMS_TEM_ORG_CD, 72 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(COMS_CHRPE_ORG_ID, 73 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(CPIC_ORG_CD, 74 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeTimestamp(CNCLU_DT, 75 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeTimestamp(EXMP_DCN_DT, 76 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeString(DAM_DGR_CD, 77 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(AT_ISP_YN, 78 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(ACD_CTR_OBJ_ID, 79 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(ACD_CTR_OBJ_HIS_SEQ, 80 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(ACD_OBJ_DIV_CD, 81 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(ACD_OBJ_ID, 82 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(DAM_ORD, 83 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(CTR_OBJ_ID, 84 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(CTR_OBJ_ADR_ID, 85 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(OBJ_TP_CD, 86 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(DMPE_CUS_ID, 87 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(DMPO_NM, 88 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(PVDS_YN, 89 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(TCTR_DMPE_JOB_GRD_CD, 90 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(TCTR_DMPE_JOB_CD, 91 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(TACD_DMPE_JOB_GRD_CD, 92 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(TACD_DMPE_JOB_CD, 93 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(OWNR_NM, 94 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(DMPE_AGE, 95 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(TNG_DIV_CD, 96 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(OBJ_GRD_CD, 97 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(OPN_JBCL_CD, 98 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(OPJB_NM, 99 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(OBJ_CD, 100 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(DMOB_LCTG_CD, 101 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(DMOB_MCTG_CD, 102 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(DMOB_SCTG_CD, 103 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(DMOB_TPIDS_LCTG_CD, 104 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(DMOB_TPIDS_MCTG_CD, 105 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(DMOB_TPIDS_SCTG_CD, 106 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(DMOB_TPIDS_DCTG_CD, 107 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(MCSH_FSHBT_DIV_CD, 108 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(SHAG, 109 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(SHP_TP_CD, 110 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(SHP_CD, 111 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(ARCRF_REG_NO, 112 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(CARG_TRN_ITM_CD, 113 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(DTH_YN, 114 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(AFOBS_YN, 115 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(HSP_MD_EXP_YN, 116 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(GHR_MD_EXP_YN, 117 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(PSC_MD_EXP_YN, 118 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(HSP_DDPY_YN, 119 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(LAST_DGN_YN, 120 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(SROP_YN, 121 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(EXP_YN, 122 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(SROP_BDW_YN, 123 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(OS_ID, 124 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(OS_HIS_SEQ, 125 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(OS_SEQ, 126 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(OS_DIV_CD, 127 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(DCN_ID, 128 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(DCN_HIS_SEQ, 129 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(DCN_SEQ, 130 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(DCN_DIV_CD, 131 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(CNCLU_ID, 132 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(CNCLU_HIS_SEQ, 133 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(CNCLU_DIV_CD, 134 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(CNCLU_DATA_DIV_CD, 135 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(COV_INS_DATA_DIV_CD, 136 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(COV_INS_HIS_SEQ, 137 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeTimestamp(INS_AMT_APVL_DT, 138 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(CSS_COV_INS_HIS_SEQ, 139 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(SPTPY_DIV_CD, 140 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(ISD_PCS_SEQ, 141 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(COV_CD, 142 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(INS_AMT_EXT_EXP_DIV_CD, 143 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(GURT_UNT_CD, 144 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(RSK_UNT_CD, 145 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(CLADJ_DIV_CTG_CD, 146 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(BAS_SIC_DIV_CD, 147 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeTimestamp(COV_INS_BGN_DT, 148 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeTimestamp(COV_INS_ED_DT, 149 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeString(INSD_AMT_CUR_CD, 150 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(CUR_INSD_AMT, 151 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(INSD_AMT, 152 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(PPS_COMS_LM_AMT, 153 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(PACD_COMS_LM_AMT, 154 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(LDCO_CTR_BZAC_CD, 155 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(COI_CTR_BZAC_CD, 156 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(CSS_COV_INS_SEQ, 157 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(JNT_ACP_COV_INS_SEQ, 158 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(PRTC_RT, 159 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(BRKR_CTR_BZAC_CD, 160 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(RINCO_CTR_BZAC_CD, 161 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(CLOG_APL_YN, 162 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(CSS_CTR_ID, 163 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(RINS_SH_DIV_CD, 164 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(BRKR_CSS_RT, 165 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(INSD_AMT_STD_CSS_RT, 166 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(ACP_AMT_STD_CSS_RT, 167 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(CUR_CD, 168 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(APL_EXRT, 169 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(CSS_INS_AMT, 170 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(KWCV_CSS_INS_AMT, 171 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeTimestamp(EIH_LDG_DTM, 172 + __off, 93, __dbStmt);
    return 172;
  }
  public void write0(PreparedStatement __dbStmt, int __off) throws SQLException {
    JdbcWritableBridge.writeTimestamp(CLOG_DT, 1 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeString(CLM_ID, 2 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(COV_INS_AMT_ID, 3 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(CSS_COV_INS_AMT_ID, 4 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(CLADJ_CLOG_DIV_CD, 5 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(INS_ITMS_DIV_CD, 6 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(BZPLN_PD_CTG_CD, 7 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(PREBL_MNG_PD_CTG_CD, 8 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(SAL_PD_CD, 9 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(UNT_PD_CD, 10 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(ACD_NO_YY, 11 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(ACD_NO_SEQ, 12 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(ACD_RCT_ID, 13 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(ACD_RCT_HIS_SEQ, 14 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeTimestamp(RCT_DTM, 15 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeTimestamp(RCT_DT, 16 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeTimestamp(ACD_DTM, 17 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeTimestamp(ACD_DT, 18 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeString(HOLI_YN, 19 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(OD_ACD_NO, 20 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(OTHCO_ACD_NO, 21 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(ACD_WKD_CD, 22 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(CITY_NATL_CD, 23 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(ACD_PLC_ZPCD, 24 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(ACD_PLC_ZPCD_SNO, 25 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(ACD_PLC_ZPCD_ADR, 26 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(ACD_PLC_DTL_ADR_CON, 27 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(LTT_DIV_CD, 28 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(LTT_COO_DG, 29 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(LTT_COO_MI, 30 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(LTT_COO_SS, 31 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(LNT_DIV_CD, 32 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(LNT_COO_DG, 33 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(LNT_COO_MI, 34 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(LNT_COO_SS, 35 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(ACD_CTR_ID, 36 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(ACD_CTR_HIS_SEQ, 37 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(POL_NO, 38 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(CTR_ENDR_NO, 39 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(RTRO_ENDR_NO, 40 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(ENDR_HIS_STD_NO, 41 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(POLHD_CUS_ID, 42 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(POLHD_NM, 43 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(CTR_STAT_CD, 44 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(CTR_STAT_DTL_CD, 45 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeTimestamp(INS_BGN_DT, 46 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeTimestamp(INS_ED_DT, 47 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeTimestamp(SBCP_DT, 48 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeString(ACP_SH_DIV_CD, 49 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(MRIN_PD_DIV_CD, 50 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(MA_INSPE_CUS_ID, 51 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(MA_INSPE_NM, 52 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(ORIG_RTRC_DIV_CD, 53 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(PLR_STUP_YN, 54 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(TRT_HDQT_ORG_CD, 55 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(TRT_BCH_ORG_CD, 56 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(TRT_BRCH_ORG_CD, 57 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(TRTPE_ORG_ID, 58 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(TRTPE_ORG_CD, 59 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(CLM_TP_CD, 60 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(DSS_CD_YY, 61 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(DSS_CD_SEQ, 62 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(CLM_STAT_CD, 63 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(ACD_CAUS_LCTG_CD, 64 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(ACD_CAUS_MCTG_CD, 65 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(ACD_CAUS_SCTG_CD, 66 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(ACD_CAUS_DCTG_CD, 67 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(ACD_CAUS_DCTG2_CD, 68 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(COMS_PART_ORG_ID, 69 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(COMS_PART_ORG_CD, 70 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(COMS_TEM_ORG_ID, 71 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(COMS_TEM_ORG_CD, 72 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(COMS_CHRPE_ORG_ID, 73 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(CPIC_ORG_CD, 74 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeTimestamp(CNCLU_DT, 75 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeTimestamp(EXMP_DCN_DT, 76 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeString(DAM_DGR_CD, 77 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(AT_ISP_YN, 78 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(ACD_CTR_OBJ_ID, 79 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(ACD_CTR_OBJ_HIS_SEQ, 80 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(ACD_OBJ_DIV_CD, 81 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(ACD_OBJ_ID, 82 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(DAM_ORD, 83 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(CTR_OBJ_ID, 84 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(CTR_OBJ_ADR_ID, 85 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(OBJ_TP_CD, 86 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(DMPE_CUS_ID, 87 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(DMPO_NM, 88 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(PVDS_YN, 89 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(TCTR_DMPE_JOB_GRD_CD, 90 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(TCTR_DMPE_JOB_CD, 91 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(TACD_DMPE_JOB_GRD_CD, 92 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(TACD_DMPE_JOB_CD, 93 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(OWNR_NM, 94 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(DMPE_AGE, 95 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(TNG_DIV_CD, 96 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(OBJ_GRD_CD, 97 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(OPN_JBCL_CD, 98 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(OPJB_NM, 99 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(OBJ_CD, 100 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(DMOB_LCTG_CD, 101 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(DMOB_MCTG_CD, 102 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(DMOB_SCTG_CD, 103 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(DMOB_TPIDS_LCTG_CD, 104 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(DMOB_TPIDS_MCTG_CD, 105 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(DMOB_TPIDS_SCTG_CD, 106 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(DMOB_TPIDS_DCTG_CD, 107 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(MCSH_FSHBT_DIV_CD, 108 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(SHAG, 109 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(SHP_TP_CD, 110 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(SHP_CD, 111 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(ARCRF_REG_NO, 112 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(CARG_TRN_ITM_CD, 113 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(DTH_YN, 114 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(AFOBS_YN, 115 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(HSP_MD_EXP_YN, 116 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(GHR_MD_EXP_YN, 117 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(PSC_MD_EXP_YN, 118 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(HSP_DDPY_YN, 119 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(LAST_DGN_YN, 120 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(SROP_YN, 121 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(EXP_YN, 122 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(SROP_BDW_YN, 123 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(OS_ID, 124 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(OS_HIS_SEQ, 125 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(OS_SEQ, 126 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(OS_DIV_CD, 127 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(DCN_ID, 128 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(DCN_HIS_SEQ, 129 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(DCN_SEQ, 130 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(DCN_DIV_CD, 131 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(CNCLU_ID, 132 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(CNCLU_HIS_SEQ, 133 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(CNCLU_DIV_CD, 134 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(CNCLU_DATA_DIV_CD, 135 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(COV_INS_DATA_DIV_CD, 136 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(COV_INS_HIS_SEQ, 137 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeTimestamp(INS_AMT_APVL_DT, 138 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(CSS_COV_INS_HIS_SEQ, 139 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(SPTPY_DIV_CD, 140 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(ISD_PCS_SEQ, 141 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(COV_CD, 142 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(INS_AMT_EXT_EXP_DIV_CD, 143 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(GURT_UNT_CD, 144 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(RSK_UNT_CD, 145 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(CLADJ_DIV_CTG_CD, 146 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(BAS_SIC_DIV_CD, 147 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeTimestamp(COV_INS_BGN_DT, 148 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeTimestamp(COV_INS_ED_DT, 149 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeString(INSD_AMT_CUR_CD, 150 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(CUR_INSD_AMT, 151 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(INSD_AMT, 152 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(PPS_COMS_LM_AMT, 153 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(PACD_COMS_LM_AMT, 154 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(LDCO_CTR_BZAC_CD, 155 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(COI_CTR_BZAC_CD, 156 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(CSS_COV_INS_SEQ, 157 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(JNT_ACP_COV_INS_SEQ, 158 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(PRTC_RT, 159 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(BRKR_CTR_BZAC_CD, 160 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(RINCO_CTR_BZAC_CD, 161 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(CLOG_APL_YN, 162 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(CSS_CTR_ID, 163 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(RINS_SH_DIV_CD, 164 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(BRKR_CSS_RT, 165 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(INSD_AMT_STD_CSS_RT, 166 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(ACP_AMT_STD_CSS_RT, 167 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeString(CUR_CD, 168 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(APL_EXRT, 169 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(CSS_INS_AMT, 170 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeBigDecimal(KWCV_CSS_INS_AMT, 171 + __off, 2, __dbStmt);
    JdbcWritableBridge.writeTimestamp(EIH_LDG_DTM, 172 + __off, 93, __dbStmt);
  }
  public void readFields(DataInput __dataIn) throws IOException {
this.readFields0(__dataIn);  }
  public void readFields0(DataInput __dataIn) throws IOException {
    if (__dataIn.readBoolean()) { 
        this.CLOG_DT = null;
    } else {
    this.CLOG_DT = new Timestamp(__dataIn.readLong());
    this.CLOG_DT.setNanos(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.CLM_ID = null;
    } else {
    this.CLM_ID = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.COV_INS_AMT_ID = null;
    } else {
    this.COV_INS_AMT_ID = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.CSS_COV_INS_AMT_ID = null;
    } else {
    this.CSS_COV_INS_AMT_ID = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.CLADJ_CLOG_DIV_CD = null;
    } else {
    this.CLADJ_CLOG_DIV_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.INS_ITMS_DIV_CD = null;
    } else {
    this.INS_ITMS_DIV_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.BZPLN_PD_CTG_CD = null;
    } else {
    this.BZPLN_PD_CTG_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.PREBL_MNG_PD_CTG_CD = null;
    } else {
    this.PREBL_MNG_PD_CTG_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.SAL_PD_CD = null;
    } else {
    this.SAL_PD_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.UNT_PD_CD = null;
    } else {
    this.UNT_PD_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.ACD_NO_YY = null;
    } else {
    this.ACD_NO_YY = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.ACD_NO_SEQ = null;
    } else {
    this.ACD_NO_SEQ = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.ACD_RCT_ID = null;
    } else {
    this.ACD_RCT_ID = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.ACD_RCT_HIS_SEQ = null;
    } else {
    this.ACD_RCT_HIS_SEQ = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RCT_DTM = null;
    } else {
    this.RCT_DTM = new Timestamp(__dataIn.readLong());
    this.RCT_DTM.setNanos(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.RCT_DT = null;
    } else {
    this.RCT_DT = new Timestamp(__dataIn.readLong());
    this.RCT_DT.setNanos(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.ACD_DTM = null;
    } else {
    this.ACD_DTM = new Timestamp(__dataIn.readLong());
    this.ACD_DTM.setNanos(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.ACD_DT = null;
    } else {
    this.ACD_DT = new Timestamp(__dataIn.readLong());
    this.ACD_DT.setNanos(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.HOLI_YN = null;
    } else {
    this.HOLI_YN = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.OD_ACD_NO = null;
    } else {
    this.OD_ACD_NO = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.OTHCO_ACD_NO = null;
    } else {
    this.OTHCO_ACD_NO = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.ACD_WKD_CD = null;
    } else {
    this.ACD_WKD_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.CITY_NATL_CD = null;
    } else {
    this.CITY_NATL_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.ACD_PLC_ZPCD = null;
    } else {
    this.ACD_PLC_ZPCD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.ACD_PLC_ZPCD_SNO = null;
    } else {
    this.ACD_PLC_ZPCD_SNO = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.ACD_PLC_ZPCD_ADR = null;
    } else {
    this.ACD_PLC_ZPCD_ADR = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.ACD_PLC_DTL_ADR_CON = null;
    } else {
    this.ACD_PLC_DTL_ADR_CON = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.LTT_DIV_CD = null;
    } else {
    this.LTT_DIV_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.LTT_COO_DG = null;
    } else {
    this.LTT_COO_DG = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.LTT_COO_MI = null;
    } else {
    this.LTT_COO_MI = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.LTT_COO_SS = null;
    } else {
    this.LTT_COO_SS = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.LNT_DIV_CD = null;
    } else {
    this.LNT_DIV_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.LNT_COO_DG = null;
    } else {
    this.LNT_COO_DG = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.LNT_COO_MI = null;
    } else {
    this.LNT_COO_MI = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.LNT_COO_SS = null;
    } else {
    this.LNT_COO_SS = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.ACD_CTR_ID = null;
    } else {
    this.ACD_CTR_ID = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.ACD_CTR_HIS_SEQ = null;
    } else {
    this.ACD_CTR_HIS_SEQ = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.POL_NO = null;
    } else {
    this.POL_NO = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.CTR_ENDR_NO = null;
    } else {
    this.CTR_ENDR_NO = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RTRO_ENDR_NO = null;
    } else {
    this.RTRO_ENDR_NO = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.ENDR_HIS_STD_NO = null;
    } else {
    this.ENDR_HIS_STD_NO = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.POLHD_CUS_ID = null;
    } else {
    this.POLHD_CUS_ID = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.POLHD_NM = null;
    } else {
    this.POLHD_NM = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.CTR_STAT_CD = null;
    } else {
    this.CTR_STAT_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.CTR_STAT_DTL_CD = null;
    } else {
    this.CTR_STAT_DTL_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.INS_BGN_DT = null;
    } else {
    this.INS_BGN_DT = new Timestamp(__dataIn.readLong());
    this.INS_BGN_DT.setNanos(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.INS_ED_DT = null;
    } else {
    this.INS_ED_DT = new Timestamp(__dataIn.readLong());
    this.INS_ED_DT.setNanos(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.SBCP_DT = null;
    } else {
    this.SBCP_DT = new Timestamp(__dataIn.readLong());
    this.SBCP_DT.setNanos(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.ACP_SH_DIV_CD = null;
    } else {
    this.ACP_SH_DIV_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.MRIN_PD_DIV_CD = null;
    } else {
    this.MRIN_PD_DIV_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.MA_INSPE_CUS_ID = null;
    } else {
    this.MA_INSPE_CUS_ID = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.MA_INSPE_NM = null;
    } else {
    this.MA_INSPE_NM = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.ORIG_RTRC_DIV_CD = null;
    } else {
    this.ORIG_RTRC_DIV_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.PLR_STUP_YN = null;
    } else {
    this.PLR_STUP_YN = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.TRT_HDQT_ORG_CD = null;
    } else {
    this.TRT_HDQT_ORG_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.TRT_BCH_ORG_CD = null;
    } else {
    this.TRT_BCH_ORG_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.TRT_BRCH_ORG_CD = null;
    } else {
    this.TRT_BRCH_ORG_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.TRTPE_ORG_ID = null;
    } else {
    this.TRTPE_ORG_ID = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.TRTPE_ORG_CD = null;
    } else {
    this.TRTPE_ORG_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.CLM_TP_CD = null;
    } else {
    this.CLM_TP_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.DSS_CD_YY = null;
    } else {
    this.DSS_CD_YY = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.DSS_CD_SEQ = null;
    } else {
    this.DSS_CD_SEQ = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.CLM_STAT_CD = null;
    } else {
    this.CLM_STAT_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.ACD_CAUS_LCTG_CD = null;
    } else {
    this.ACD_CAUS_LCTG_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.ACD_CAUS_MCTG_CD = null;
    } else {
    this.ACD_CAUS_MCTG_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.ACD_CAUS_SCTG_CD = null;
    } else {
    this.ACD_CAUS_SCTG_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.ACD_CAUS_DCTG_CD = null;
    } else {
    this.ACD_CAUS_DCTG_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.ACD_CAUS_DCTG2_CD = null;
    } else {
    this.ACD_CAUS_DCTG2_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.COMS_PART_ORG_ID = null;
    } else {
    this.COMS_PART_ORG_ID = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.COMS_PART_ORG_CD = null;
    } else {
    this.COMS_PART_ORG_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.COMS_TEM_ORG_ID = null;
    } else {
    this.COMS_TEM_ORG_ID = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.COMS_TEM_ORG_CD = null;
    } else {
    this.COMS_TEM_ORG_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.COMS_CHRPE_ORG_ID = null;
    } else {
    this.COMS_CHRPE_ORG_ID = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.CPIC_ORG_CD = null;
    } else {
    this.CPIC_ORG_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.CNCLU_DT = null;
    } else {
    this.CNCLU_DT = new Timestamp(__dataIn.readLong());
    this.CNCLU_DT.setNanos(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.EXMP_DCN_DT = null;
    } else {
    this.EXMP_DCN_DT = new Timestamp(__dataIn.readLong());
    this.EXMP_DCN_DT.setNanos(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.DAM_DGR_CD = null;
    } else {
    this.DAM_DGR_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.AT_ISP_YN = null;
    } else {
    this.AT_ISP_YN = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.ACD_CTR_OBJ_ID = null;
    } else {
    this.ACD_CTR_OBJ_ID = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.ACD_CTR_OBJ_HIS_SEQ = null;
    } else {
    this.ACD_CTR_OBJ_HIS_SEQ = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.ACD_OBJ_DIV_CD = null;
    } else {
    this.ACD_OBJ_DIV_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.ACD_OBJ_ID = null;
    } else {
    this.ACD_OBJ_ID = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.DAM_ORD = null;
    } else {
    this.DAM_ORD = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.CTR_OBJ_ID = null;
    } else {
    this.CTR_OBJ_ID = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.CTR_OBJ_ADR_ID = null;
    } else {
    this.CTR_OBJ_ADR_ID = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.OBJ_TP_CD = null;
    } else {
    this.OBJ_TP_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.DMPE_CUS_ID = null;
    } else {
    this.DMPE_CUS_ID = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.DMPO_NM = null;
    } else {
    this.DMPO_NM = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.PVDS_YN = null;
    } else {
    this.PVDS_YN = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.TCTR_DMPE_JOB_GRD_CD = null;
    } else {
    this.TCTR_DMPE_JOB_GRD_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.TCTR_DMPE_JOB_CD = null;
    } else {
    this.TCTR_DMPE_JOB_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.TACD_DMPE_JOB_GRD_CD = null;
    } else {
    this.TACD_DMPE_JOB_GRD_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.TACD_DMPE_JOB_CD = null;
    } else {
    this.TACD_DMPE_JOB_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.OWNR_NM = null;
    } else {
    this.OWNR_NM = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.DMPE_AGE = null;
    } else {
    this.DMPE_AGE = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.TNG_DIV_CD = null;
    } else {
    this.TNG_DIV_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.OBJ_GRD_CD = null;
    } else {
    this.OBJ_GRD_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.OPN_JBCL_CD = null;
    } else {
    this.OPN_JBCL_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.OPJB_NM = null;
    } else {
    this.OPJB_NM = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.OBJ_CD = null;
    } else {
    this.OBJ_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.DMOB_LCTG_CD = null;
    } else {
    this.DMOB_LCTG_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.DMOB_MCTG_CD = null;
    } else {
    this.DMOB_MCTG_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.DMOB_SCTG_CD = null;
    } else {
    this.DMOB_SCTG_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.DMOB_TPIDS_LCTG_CD = null;
    } else {
    this.DMOB_TPIDS_LCTG_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.DMOB_TPIDS_MCTG_CD = null;
    } else {
    this.DMOB_TPIDS_MCTG_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.DMOB_TPIDS_SCTG_CD = null;
    } else {
    this.DMOB_TPIDS_SCTG_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.DMOB_TPIDS_DCTG_CD = null;
    } else {
    this.DMOB_TPIDS_DCTG_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.MCSH_FSHBT_DIV_CD = null;
    } else {
    this.MCSH_FSHBT_DIV_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.SHAG = null;
    } else {
    this.SHAG = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.SHP_TP_CD = null;
    } else {
    this.SHP_TP_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.SHP_CD = null;
    } else {
    this.SHP_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.ARCRF_REG_NO = null;
    } else {
    this.ARCRF_REG_NO = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.CARG_TRN_ITM_CD = null;
    } else {
    this.CARG_TRN_ITM_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.DTH_YN = null;
    } else {
    this.DTH_YN = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.AFOBS_YN = null;
    } else {
    this.AFOBS_YN = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.HSP_MD_EXP_YN = null;
    } else {
    this.HSP_MD_EXP_YN = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.GHR_MD_EXP_YN = null;
    } else {
    this.GHR_MD_EXP_YN = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.PSC_MD_EXP_YN = null;
    } else {
    this.PSC_MD_EXP_YN = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.HSP_DDPY_YN = null;
    } else {
    this.HSP_DDPY_YN = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.LAST_DGN_YN = null;
    } else {
    this.LAST_DGN_YN = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.SROP_YN = null;
    } else {
    this.SROP_YN = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.EXP_YN = null;
    } else {
    this.EXP_YN = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.SROP_BDW_YN = null;
    } else {
    this.SROP_BDW_YN = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.OS_ID = null;
    } else {
    this.OS_ID = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.OS_HIS_SEQ = null;
    } else {
    this.OS_HIS_SEQ = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.OS_SEQ = null;
    } else {
    this.OS_SEQ = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.OS_DIV_CD = null;
    } else {
    this.OS_DIV_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.DCN_ID = null;
    } else {
    this.DCN_ID = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.DCN_HIS_SEQ = null;
    } else {
    this.DCN_HIS_SEQ = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.DCN_SEQ = null;
    } else {
    this.DCN_SEQ = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.DCN_DIV_CD = null;
    } else {
    this.DCN_DIV_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.CNCLU_ID = null;
    } else {
    this.CNCLU_ID = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.CNCLU_HIS_SEQ = null;
    } else {
    this.CNCLU_HIS_SEQ = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.CNCLU_DIV_CD = null;
    } else {
    this.CNCLU_DIV_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.CNCLU_DATA_DIV_CD = null;
    } else {
    this.CNCLU_DATA_DIV_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.COV_INS_DATA_DIV_CD = null;
    } else {
    this.COV_INS_DATA_DIV_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.COV_INS_HIS_SEQ = null;
    } else {
    this.COV_INS_HIS_SEQ = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.INS_AMT_APVL_DT = null;
    } else {
    this.INS_AMT_APVL_DT = new Timestamp(__dataIn.readLong());
    this.INS_AMT_APVL_DT.setNanos(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.CSS_COV_INS_HIS_SEQ = null;
    } else {
    this.CSS_COV_INS_HIS_SEQ = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.SPTPY_DIV_CD = null;
    } else {
    this.SPTPY_DIV_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.ISD_PCS_SEQ = null;
    } else {
    this.ISD_PCS_SEQ = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.COV_CD = null;
    } else {
    this.COV_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.INS_AMT_EXT_EXP_DIV_CD = null;
    } else {
    this.INS_AMT_EXT_EXP_DIV_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.GURT_UNT_CD = null;
    } else {
    this.GURT_UNT_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RSK_UNT_CD = null;
    } else {
    this.RSK_UNT_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.CLADJ_DIV_CTG_CD = null;
    } else {
    this.CLADJ_DIV_CTG_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.BAS_SIC_DIV_CD = null;
    } else {
    this.BAS_SIC_DIV_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.COV_INS_BGN_DT = null;
    } else {
    this.COV_INS_BGN_DT = new Timestamp(__dataIn.readLong());
    this.COV_INS_BGN_DT.setNanos(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.COV_INS_ED_DT = null;
    } else {
    this.COV_INS_ED_DT = new Timestamp(__dataIn.readLong());
    this.COV_INS_ED_DT.setNanos(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.INSD_AMT_CUR_CD = null;
    } else {
    this.INSD_AMT_CUR_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.CUR_INSD_AMT = null;
    } else {
    this.CUR_INSD_AMT = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.INSD_AMT = null;
    } else {
    this.INSD_AMT = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.PPS_COMS_LM_AMT = null;
    } else {
    this.PPS_COMS_LM_AMT = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.PACD_COMS_LM_AMT = null;
    } else {
    this.PACD_COMS_LM_AMT = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.LDCO_CTR_BZAC_CD = null;
    } else {
    this.LDCO_CTR_BZAC_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.COI_CTR_BZAC_CD = null;
    } else {
    this.COI_CTR_BZAC_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.CSS_COV_INS_SEQ = null;
    } else {
    this.CSS_COV_INS_SEQ = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.JNT_ACP_COV_INS_SEQ = null;
    } else {
    this.JNT_ACP_COV_INS_SEQ = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.PRTC_RT = null;
    } else {
    this.PRTC_RT = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.BRKR_CTR_BZAC_CD = null;
    } else {
    this.BRKR_CTR_BZAC_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RINCO_CTR_BZAC_CD = null;
    } else {
    this.RINCO_CTR_BZAC_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.CLOG_APL_YN = null;
    } else {
    this.CLOG_APL_YN = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.CSS_CTR_ID = null;
    } else {
    this.CSS_CTR_ID = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.RINS_SH_DIV_CD = null;
    } else {
    this.RINS_SH_DIV_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.BRKR_CSS_RT = null;
    } else {
    this.BRKR_CSS_RT = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.INSD_AMT_STD_CSS_RT = null;
    } else {
    this.INSD_AMT_STD_CSS_RT = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.ACP_AMT_STD_CSS_RT = null;
    } else {
    this.ACP_AMT_STD_CSS_RT = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.CUR_CD = null;
    } else {
    this.CUR_CD = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.APL_EXRT = null;
    } else {
    this.APL_EXRT = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.CSS_INS_AMT = null;
    } else {
    this.CSS_INS_AMT = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.KWCV_CSS_INS_AMT = null;
    } else {
    this.KWCV_CSS_INS_AMT = org.apache.sqoop.lib.BigDecimalSerializer.readFields(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.EIH_LDG_DTM = null;
    } else {
    this.EIH_LDG_DTM = new Timestamp(__dataIn.readLong());
    this.EIH_LDG_DTM.setNanos(__dataIn.readInt());
    }
  }
  public void write(DataOutput __dataOut) throws IOException {
    if (null == this.CLOG_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.CLOG_DT.getTime());
    __dataOut.writeInt(this.CLOG_DT.getNanos());
    }
    if (null == this.CLM_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CLM_ID);
    }
    if (null == this.COV_INS_AMT_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, COV_INS_AMT_ID);
    }
    if (null == this.CSS_COV_INS_AMT_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CSS_COV_INS_AMT_ID);
    }
    if (null == this.CLADJ_CLOG_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CLADJ_CLOG_DIV_CD);
    }
    if (null == this.INS_ITMS_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, INS_ITMS_DIV_CD);
    }
    if (null == this.BZPLN_PD_CTG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, BZPLN_PD_CTG_CD);
    }
    if (null == this.PREBL_MNG_PD_CTG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, PREBL_MNG_PD_CTG_CD);
    }
    if (null == this.SAL_PD_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, SAL_PD_CD);
    }
    if (null == this.UNT_PD_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, UNT_PD_CD);
    }
    if (null == this.ACD_NO_YY) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ACD_NO_YY);
    }
    if (null == this.ACD_NO_SEQ) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.ACD_NO_SEQ, __dataOut);
    }
    if (null == this.ACD_RCT_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ACD_RCT_ID);
    }
    if (null == this.ACD_RCT_HIS_SEQ) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.ACD_RCT_HIS_SEQ, __dataOut);
    }
    if (null == this.RCT_DTM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.RCT_DTM.getTime());
    __dataOut.writeInt(this.RCT_DTM.getNanos());
    }
    if (null == this.RCT_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.RCT_DT.getTime());
    __dataOut.writeInt(this.RCT_DT.getNanos());
    }
    if (null == this.ACD_DTM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.ACD_DTM.getTime());
    __dataOut.writeInt(this.ACD_DTM.getNanos());
    }
    if (null == this.ACD_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.ACD_DT.getTime());
    __dataOut.writeInt(this.ACD_DT.getNanos());
    }
    if (null == this.HOLI_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, HOLI_YN);
    }
    if (null == this.OD_ACD_NO) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, OD_ACD_NO);
    }
    if (null == this.OTHCO_ACD_NO) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, OTHCO_ACD_NO);
    }
    if (null == this.ACD_WKD_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ACD_WKD_CD);
    }
    if (null == this.CITY_NATL_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CITY_NATL_CD);
    }
    if (null == this.ACD_PLC_ZPCD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ACD_PLC_ZPCD);
    }
    if (null == this.ACD_PLC_ZPCD_SNO) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ACD_PLC_ZPCD_SNO);
    }
    if (null == this.ACD_PLC_ZPCD_ADR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ACD_PLC_ZPCD_ADR);
    }
    if (null == this.ACD_PLC_DTL_ADR_CON) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ACD_PLC_DTL_ADR_CON);
    }
    if (null == this.LTT_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, LTT_DIV_CD);
    }
    if (null == this.LTT_COO_DG) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.LTT_COO_DG, __dataOut);
    }
    if (null == this.LTT_COO_MI) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.LTT_COO_MI, __dataOut);
    }
    if (null == this.LTT_COO_SS) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.LTT_COO_SS, __dataOut);
    }
    if (null == this.LNT_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, LNT_DIV_CD);
    }
    if (null == this.LNT_COO_DG) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.LNT_COO_DG, __dataOut);
    }
    if (null == this.LNT_COO_MI) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.LNT_COO_MI, __dataOut);
    }
    if (null == this.LNT_COO_SS) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.LNT_COO_SS, __dataOut);
    }
    if (null == this.ACD_CTR_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ACD_CTR_ID);
    }
    if (null == this.ACD_CTR_HIS_SEQ) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.ACD_CTR_HIS_SEQ, __dataOut);
    }
    if (null == this.POL_NO) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, POL_NO);
    }
    if (null == this.CTR_ENDR_NO) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.CTR_ENDR_NO, __dataOut);
    }
    if (null == this.RTRO_ENDR_NO) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.RTRO_ENDR_NO, __dataOut);
    }
    if (null == this.ENDR_HIS_STD_NO) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.ENDR_HIS_STD_NO, __dataOut);
    }
    if (null == this.POLHD_CUS_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, POLHD_CUS_ID);
    }
    if (null == this.POLHD_NM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, POLHD_NM);
    }
    if (null == this.CTR_STAT_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CTR_STAT_CD);
    }
    if (null == this.CTR_STAT_DTL_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CTR_STAT_DTL_CD);
    }
    if (null == this.INS_BGN_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.INS_BGN_DT.getTime());
    __dataOut.writeInt(this.INS_BGN_DT.getNanos());
    }
    if (null == this.INS_ED_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.INS_ED_DT.getTime());
    __dataOut.writeInt(this.INS_ED_DT.getNanos());
    }
    if (null == this.SBCP_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.SBCP_DT.getTime());
    __dataOut.writeInt(this.SBCP_DT.getNanos());
    }
    if (null == this.ACP_SH_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ACP_SH_DIV_CD);
    }
    if (null == this.MRIN_PD_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, MRIN_PD_DIV_CD);
    }
    if (null == this.MA_INSPE_CUS_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, MA_INSPE_CUS_ID);
    }
    if (null == this.MA_INSPE_NM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, MA_INSPE_NM);
    }
    if (null == this.ORIG_RTRC_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ORIG_RTRC_DIV_CD);
    }
    if (null == this.PLR_STUP_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, PLR_STUP_YN);
    }
    if (null == this.TRT_HDQT_ORG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, TRT_HDQT_ORG_CD);
    }
    if (null == this.TRT_BCH_ORG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, TRT_BCH_ORG_CD);
    }
    if (null == this.TRT_BRCH_ORG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, TRT_BRCH_ORG_CD);
    }
    if (null == this.TRTPE_ORG_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, TRTPE_ORG_ID);
    }
    if (null == this.TRTPE_ORG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, TRTPE_ORG_CD);
    }
    if (null == this.CLM_TP_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CLM_TP_CD);
    }
    if (null == this.DSS_CD_YY) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, DSS_CD_YY);
    }
    if (null == this.DSS_CD_SEQ) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.DSS_CD_SEQ, __dataOut);
    }
    if (null == this.CLM_STAT_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CLM_STAT_CD);
    }
    if (null == this.ACD_CAUS_LCTG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ACD_CAUS_LCTG_CD);
    }
    if (null == this.ACD_CAUS_MCTG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ACD_CAUS_MCTG_CD);
    }
    if (null == this.ACD_CAUS_SCTG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ACD_CAUS_SCTG_CD);
    }
    if (null == this.ACD_CAUS_DCTG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ACD_CAUS_DCTG_CD);
    }
    if (null == this.ACD_CAUS_DCTG2_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ACD_CAUS_DCTG2_CD);
    }
    if (null == this.COMS_PART_ORG_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, COMS_PART_ORG_ID);
    }
    if (null == this.COMS_PART_ORG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, COMS_PART_ORG_CD);
    }
    if (null == this.COMS_TEM_ORG_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, COMS_TEM_ORG_ID);
    }
    if (null == this.COMS_TEM_ORG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, COMS_TEM_ORG_CD);
    }
    if (null == this.COMS_CHRPE_ORG_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, COMS_CHRPE_ORG_ID);
    }
    if (null == this.CPIC_ORG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CPIC_ORG_CD);
    }
    if (null == this.CNCLU_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.CNCLU_DT.getTime());
    __dataOut.writeInt(this.CNCLU_DT.getNanos());
    }
    if (null == this.EXMP_DCN_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.EXMP_DCN_DT.getTime());
    __dataOut.writeInt(this.EXMP_DCN_DT.getNanos());
    }
    if (null == this.DAM_DGR_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, DAM_DGR_CD);
    }
    if (null == this.AT_ISP_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, AT_ISP_YN);
    }
    if (null == this.ACD_CTR_OBJ_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ACD_CTR_OBJ_ID);
    }
    if (null == this.ACD_CTR_OBJ_HIS_SEQ) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.ACD_CTR_OBJ_HIS_SEQ, __dataOut);
    }
    if (null == this.ACD_OBJ_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ACD_OBJ_DIV_CD);
    }
    if (null == this.ACD_OBJ_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ACD_OBJ_ID);
    }
    if (null == this.DAM_ORD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.DAM_ORD, __dataOut);
    }
    if (null == this.CTR_OBJ_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CTR_OBJ_ID);
    }
    if (null == this.CTR_OBJ_ADR_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CTR_OBJ_ADR_ID);
    }
    if (null == this.OBJ_TP_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, OBJ_TP_CD);
    }
    if (null == this.DMPE_CUS_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, DMPE_CUS_ID);
    }
    if (null == this.DMPO_NM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, DMPO_NM);
    }
    if (null == this.PVDS_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, PVDS_YN);
    }
    if (null == this.TCTR_DMPE_JOB_GRD_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, TCTR_DMPE_JOB_GRD_CD);
    }
    if (null == this.TCTR_DMPE_JOB_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, TCTR_DMPE_JOB_CD);
    }
    if (null == this.TACD_DMPE_JOB_GRD_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, TACD_DMPE_JOB_GRD_CD);
    }
    if (null == this.TACD_DMPE_JOB_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, TACD_DMPE_JOB_CD);
    }
    if (null == this.OWNR_NM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, OWNR_NM);
    }
    if (null == this.DMPE_AGE) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.DMPE_AGE, __dataOut);
    }
    if (null == this.TNG_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, TNG_DIV_CD);
    }
    if (null == this.OBJ_GRD_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, OBJ_GRD_CD);
    }
    if (null == this.OPN_JBCL_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, OPN_JBCL_CD);
    }
    if (null == this.OPJB_NM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, OPJB_NM);
    }
    if (null == this.OBJ_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, OBJ_CD);
    }
    if (null == this.DMOB_LCTG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, DMOB_LCTG_CD);
    }
    if (null == this.DMOB_MCTG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, DMOB_MCTG_CD);
    }
    if (null == this.DMOB_SCTG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, DMOB_SCTG_CD);
    }
    if (null == this.DMOB_TPIDS_LCTG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, DMOB_TPIDS_LCTG_CD);
    }
    if (null == this.DMOB_TPIDS_MCTG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, DMOB_TPIDS_MCTG_CD);
    }
    if (null == this.DMOB_TPIDS_SCTG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, DMOB_TPIDS_SCTG_CD);
    }
    if (null == this.DMOB_TPIDS_DCTG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, DMOB_TPIDS_DCTG_CD);
    }
    if (null == this.MCSH_FSHBT_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, MCSH_FSHBT_DIV_CD);
    }
    if (null == this.SHAG) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.SHAG, __dataOut);
    }
    if (null == this.SHP_TP_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, SHP_TP_CD);
    }
    if (null == this.SHP_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, SHP_CD);
    }
    if (null == this.ARCRF_REG_NO) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ARCRF_REG_NO);
    }
    if (null == this.CARG_TRN_ITM_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CARG_TRN_ITM_CD);
    }
    if (null == this.DTH_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, DTH_YN);
    }
    if (null == this.AFOBS_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, AFOBS_YN);
    }
    if (null == this.HSP_MD_EXP_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, HSP_MD_EXP_YN);
    }
    if (null == this.GHR_MD_EXP_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, GHR_MD_EXP_YN);
    }
    if (null == this.PSC_MD_EXP_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, PSC_MD_EXP_YN);
    }
    if (null == this.HSP_DDPY_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, HSP_DDPY_YN);
    }
    if (null == this.LAST_DGN_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, LAST_DGN_YN);
    }
    if (null == this.SROP_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, SROP_YN);
    }
    if (null == this.EXP_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, EXP_YN);
    }
    if (null == this.SROP_BDW_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, SROP_BDW_YN);
    }
    if (null == this.OS_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, OS_ID);
    }
    if (null == this.OS_HIS_SEQ) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.OS_HIS_SEQ, __dataOut);
    }
    if (null == this.OS_SEQ) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.OS_SEQ, __dataOut);
    }
    if (null == this.OS_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, OS_DIV_CD);
    }
    if (null == this.DCN_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, DCN_ID);
    }
    if (null == this.DCN_HIS_SEQ) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.DCN_HIS_SEQ, __dataOut);
    }
    if (null == this.DCN_SEQ) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.DCN_SEQ, __dataOut);
    }
    if (null == this.DCN_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, DCN_DIV_CD);
    }
    if (null == this.CNCLU_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CNCLU_ID);
    }
    if (null == this.CNCLU_HIS_SEQ) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.CNCLU_HIS_SEQ, __dataOut);
    }
    if (null == this.CNCLU_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CNCLU_DIV_CD);
    }
    if (null == this.CNCLU_DATA_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CNCLU_DATA_DIV_CD);
    }
    if (null == this.COV_INS_DATA_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, COV_INS_DATA_DIV_CD);
    }
    if (null == this.COV_INS_HIS_SEQ) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.COV_INS_HIS_SEQ, __dataOut);
    }
    if (null == this.INS_AMT_APVL_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.INS_AMT_APVL_DT.getTime());
    __dataOut.writeInt(this.INS_AMT_APVL_DT.getNanos());
    }
    if (null == this.CSS_COV_INS_HIS_SEQ) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.CSS_COV_INS_HIS_SEQ, __dataOut);
    }
    if (null == this.SPTPY_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, SPTPY_DIV_CD);
    }
    if (null == this.ISD_PCS_SEQ) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.ISD_PCS_SEQ, __dataOut);
    }
    if (null == this.COV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, COV_CD);
    }
    if (null == this.INS_AMT_EXT_EXP_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, INS_AMT_EXT_EXP_DIV_CD);
    }
    if (null == this.GURT_UNT_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, GURT_UNT_CD);
    }
    if (null == this.RSK_UNT_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RSK_UNT_CD);
    }
    if (null == this.CLADJ_DIV_CTG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CLADJ_DIV_CTG_CD);
    }
    if (null == this.BAS_SIC_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, BAS_SIC_DIV_CD);
    }
    if (null == this.COV_INS_BGN_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.COV_INS_BGN_DT.getTime());
    __dataOut.writeInt(this.COV_INS_BGN_DT.getNanos());
    }
    if (null == this.COV_INS_ED_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.COV_INS_ED_DT.getTime());
    __dataOut.writeInt(this.COV_INS_ED_DT.getNanos());
    }
    if (null == this.INSD_AMT_CUR_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, INSD_AMT_CUR_CD);
    }
    if (null == this.CUR_INSD_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.CUR_INSD_AMT, __dataOut);
    }
    if (null == this.INSD_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.INSD_AMT, __dataOut);
    }
    if (null == this.PPS_COMS_LM_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.PPS_COMS_LM_AMT, __dataOut);
    }
    if (null == this.PACD_COMS_LM_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.PACD_COMS_LM_AMT, __dataOut);
    }
    if (null == this.LDCO_CTR_BZAC_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, LDCO_CTR_BZAC_CD);
    }
    if (null == this.COI_CTR_BZAC_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, COI_CTR_BZAC_CD);
    }
    if (null == this.CSS_COV_INS_SEQ) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.CSS_COV_INS_SEQ, __dataOut);
    }
    if (null == this.JNT_ACP_COV_INS_SEQ) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.JNT_ACP_COV_INS_SEQ, __dataOut);
    }
    if (null == this.PRTC_RT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.PRTC_RT, __dataOut);
    }
    if (null == this.BRKR_CTR_BZAC_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, BRKR_CTR_BZAC_CD);
    }
    if (null == this.RINCO_CTR_BZAC_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RINCO_CTR_BZAC_CD);
    }
    if (null == this.CLOG_APL_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CLOG_APL_YN);
    }
    if (null == this.CSS_CTR_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CSS_CTR_ID);
    }
    if (null == this.RINS_SH_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RINS_SH_DIV_CD);
    }
    if (null == this.BRKR_CSS_RT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.BRKR_CSS_RT, __dataOut);
    }
    if (null == this.INSD_AMT_STD_CSS_RT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.INSD_AMT_STD_CSS_RT, __dataOut);
    }
    if (null == this.ACP_AMT_STD_CSS_RT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.ACP_AMT_STD_CSS_RT, __dataOut);
    }
    if (null == this.CUR_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CUR_CD);
    }
    if (null == this.APL_EXRT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.APL_EXRT, __dataOut);
    }
    if (null == this.CSS_INS_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.CSS_INS_AMT, __dataOut);
    }
    if (null == this.KWCV_CSS_INS_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.KWCV_CSS_INS_AMT, __dataOut);
    }
    if (null == this.EIH_LDG_DTM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.EIH_LDG_DTM.getTime());
    __dataOut.writeInt(this.EIH_LDG_DTM.getNanos());
    }
  }
  public void write0(DataOutput __dataOut) throws IOException {
    if (null == this.CLOG_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.CLOG_DT.getTime());
    __dataOut.writeInt(this.CLOG_DT.getNanos());
    }
    if (null == this.CLM_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CLM_ID);
    }
    if (null == this.COV_INS_AMT_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, COV_INS_AMT_ID);
    }
    if (null == this.CSS_COV_INS_AMT_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CSS_COV_INS_AMT_ID);
    }
    if (null == this.CLADJ_CLOG_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CLADJ_CLOG_DIV_CD);
    }
    if (null == this.INS_ITMS_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, INS_ITMS_DIV_CD);
    }
    if (null == this.BZPLN_PD_CTG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, BZPLN_PD_CTG_CD);
    }
    if (null == this.PREBL_MNG_PD_CTG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, PREBL_MNG_PD_CTG_CD);
    }
    if (null == this.SAL_PD_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, SAL_PD_CD);
    }
    if (null == this.UNT_PD_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, UNT_PD_CD);
    }
    if (null == this.ACD_NO_YY) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ACD_NO_YY);
    }
    if (null == this.ACD_NO_SEQ) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.ACD_NO_SEQ, __dataOut);
    }
    if (null == this.ACD_RCT_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ACD_RCT_ID);
    }
    if (null == this.ACD_RCT_HIS_SEQ) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.ACD_RCT_HIS_SEQ, __dataOut);
    }
    if (null == this.RCT_DTM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.RCT_DTM.getTime());
    __dataOut.writeInt(this.RCT_DTM.getNanos());
    }
    if (null == this.RCT_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.RCT_DT.getTime());
    __dataOut.writeInt(this.RCT_DT.getNanos());
    }
    if (null == this.ACD_DTM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.ACD_DTM.getTime());
    __dataOut.writeInt(this.ACD_DTM.getNanos());
    }
    if (null == this.ACD_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.ACD_DT.getTime());
    __dataOut.writeInt(this.ACD_DT.getNanos());
    }
    if (null == this.HOLI_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, HOLI_YN);
    }
    if (null == this.OD_ACD_NO) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, OD_ACD_NO);
    }
    if (null == this.OTHCO_ACD_NO) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, OTHCO_ACD_NO);
    }
    if (null == this.ACD_WKD_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ACD_WKD_CD);
    }
    if (null == this.CITY_NATL_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CITY_NATL_CD);
    }
    if (null == this.ACD_PLC_ZPCD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ACD_PLC_ZPCD);
    }
    if (null == this.ACD_PLC_ZPCD_SNO) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ACD_PLC_ZPCD_SNO);
    }
    if (null == this.ACD_PLC_ZPCD_ADR) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ACD_PLC_ZPCD_ADR);
    }
    if (null == this.ACD_PLC_DTL_ADR_CON) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ACD_PLC_DTL_ADR_CON);
    }
    if (null == this.LTT_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, LTT_DIV_CD);
    }
    if (null == this.LTT_COO_DG) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.LTT_COO_DG, __dataOut);
    }
    if (null == this.LTT_COO_MI) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.LTT_COO_MI, __dataOut);
    }
    if (null == this.LTT_COO_SS) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.LTT_COO_SS, __dataOut);
    }
    if (null == this.LNT_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, LNT_DIV_CD);
    }
    if (null == this.LNT_COO_DG) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.LNT_COO_DG, __dataOut);
    }
    if (null == this.LNT_COO_MI) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.LNT_COO_MI, __dataOut);
    }
    if (null == this.LNT_COO_SS) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.LNT_COO_SS, __dataOut);
    }
    if (null == this.ACD_CTR_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ACD_CTR_ID);
    }
    if (null == this.ACD_CTR_HIS_SEQ) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.ACD_CTR_HIS_SEQ, __dataOut);
    }
    if (null == this.POL_NO) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, POL_NO);
    }
    if (null == this.CTR_ENDR_NO) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.CTR_ENDR_NO, __dataOut);
    }
    if (null == this.RTRO_ENDR_NO) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.RTRO_ENDR_NO, __dataOut);
    }
    if (null == this.ENDR_HIS_STD_NO) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.ENDR_HIS_STD_NO, __dataOut);
    }
    if (null == this.POLHD_CUS_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, POLHD_CUS_ID);
    }
    if (null == this.POLHD_NM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, POLHD_NM);
    }
    if (null == this.CTR_STAT_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CTR_STAT_CD);
    }
    if (null == this.CTR_STAT_DTL_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CTR_STAT_DTL_CD);
    }
    if (null == this.INS_BGN_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.INS_BGN_DT.getTime());
    __dataOut.writeInt(this.INS_BGN_DT.getNanos());
    }
    if (null == this.INS_ED_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.INS_ED_DT.getTime());
    __dataOut.writeInt(this.INS_ED_DT.getNanos());
    }
    if (null == this.SBCP_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.SBCP_DT.getTime());
    __dataOut.writeInt(this.SBCP_DT.getNanos());
    }
    if (null == this.ACP_SH_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ACP_SH_DIV_CD);
    }
    if (null == this.MRIN_PD_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, MRIN_PD_DIV_CD);
    }
    if (null == this.MA_INSPE_CUS_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, MA_INSPE_CUS_ID);
    }
    if (null == this.MA_INSPE_NM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, MA_INSPE_NM);
    }
    if (null == this.ORIG_RTRC_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ORIG_RTRC_DIV_CD);
    }
    if (null == this.PLR_STUP_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, PLR_STUP_YN);
    }
    if (null == this.TRT_HDQT_ORG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, TRT_HDQT_ORG_CD);
    }
    if (null == this.TRT_BCH_ORG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, TRT_BCH_ORG_CD);
    }
    if (null == this.TRT_BRCH_ORG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, TRT_BRCH_ORG_CD);
    }
    if (null == this.TRTPE_ORG_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, TRTPE_ORG_ID);
    }
    if (null == this.TRTPE_ORG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, TRTPE_ORG_CD);
    }
    if (null == this.CLM_TP_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CLM_TP_CD);
    }
    if (null == this.DSS_CD_YY) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, DSS_CD_YY);
    }
    if (null == this.DSS_CD_SEQ) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.DSS_CD_SEQ, __dataOut);
    }
    if (null == this.CLM_STAT_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CLM_STAT_CD);
    }
    if (null == this.ACD_CAUS_LCTG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ACD_CAUS_LCTG_CD);
    }
    if (null == this.ACD_CAUS_MCTG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ACD_CAUS_MCTG_CD);
    }
    if (null == this.ACD_CAUS_SCTG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ACD_CAUS_SCTG_CD);
    }
    if (null == this.ACD_CAUS_DCTG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ACD_CAUS_DCTG_CD);
    }
    if (null == this.ACD_CAUS_DCTG2_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ACD_CAUS_DCTG2_CD);
    }
    if (null == this.COMS_PART_ORG_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, COMS_PART_ORG_ID);
    }
    if (null == this.COMS_PART_ORG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, COMS_PART_ORG_CD);
    }
    if (null == this.COMS_TEM_ORG_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, COMS_TEM_ORG_ID);
    }
    if (null == this.COMS_TEM_ORG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, COMS_TEM_ORG_CD);
    }
    if (null == this.COMS_CHRPE_ORG_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, COMS_CHRPE_ORG_ID);
    }
    if (null == this.CPIC_ORG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CPIC_ORG_CD);
    }
    if (null == this.CNCLU_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.CNCLU_DT.getTime());
    __dataOut.writeInt(this.CNCLU_DT.getNanos());
    }
    if (null == this.EXMP_DCN_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.EXMP_DCN_DT.getTime());
    __dataOut.writeInt(this.EXMP_DCN_DT.getNanos());
    }
    if (null == this.DAM_DGR_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, DAM_DGR_CD);
    }
    if (null == this.AT_ISP_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, AT_ISP_YN);
    }
    if (null == this.ACD_CTR_OBJ_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ACD_CTR_OBJ_ID);
    }
    if (null == this.ACD_CTR_OBJ_HIS_SEQ) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.ACD_CTR_OBJ_HIS_SEQ, __dataOut);
    }
    if (null == this.ACD_OBJ_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ACD_OBJ_DIV_CD);
    }
    if (null == this.ACD_OBJ_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ACD_OBJ_ID);
    }
    if (null == this.DAM_ORD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.DAM_ORD, __dataOut);
    }
    if (null == this.CTR_OBJ_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CTR_OBJ_ID);
    }
    if (null == this.CTR_OBJ_ADR_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CTR_OBJ_ADR_ID);
    }
    if (null == this.OBJ_TP_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, OBJ_TP_CD);
    }
    if (null == this.DMPE_CUS_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, DMPE_CUS_ID);
    }
    if (null == this.DMPO_NM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, DMPO_NM);
    }
    if (null == this.PVDS_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, PVDS_YN);
    }
    if (null == this.TCTR_DMPE_JOB_GRD_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, TCTR_DMPE_JOB_GRD_CD);
    }
    if (null == this.TCTR_DMPE_JOB_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, TCTR_DMPE_JOB_CD);
    }
    if (null == this.TACD_DMPE_JOB_GRD_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, TACD_DMPE_JOB_GRD_CD);
    }
    if (null == this.TACD_DMPE_JOB_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, TACD_DMPE_JOB_CD);
    }
    if (null == this.OWNR_NM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, OWNR_NM);
    }
    if (null == this.DMPE_AGE) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.DMPE_AGE, __dataOut);
    }
    if (null == this.TNG_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, TNG_DIV_CD);
    }
    if (null == this.OBJ_GRD_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, OBJ_GRD_CD);
    }
    if (null == this.OPN_JBCL_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, OPN_JBCL_CD);
    }
    if (null == this.OPJB_NM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, OPJB_NM);
    }
    if (null == this.OBJ_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, OBJ_CD);
    }
    if (null == this.DMOB_LCTG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, DMOB_LCTG_CD);
    }
    if (null == this.DMOB_MCTG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, DMOB_MCTG_CD);
    }
    if (null == this.DMOB_SCTG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, DMOB_SCTG_CD);
    }
    if (null == this.DMOB_TPIDS_LCTG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, DMOB_TPIDS_LCTG_CD);
    }
    if (null == this.DMOB_TPIDS_MCTG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, DMOB_TPIDS_MCTG_CD);
    }
    if (null == this.DMOB_TPIDS_SCTG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, DMOB_TPIDS_SCTG_CD);
    }
    if (null == this.DMOB_TPIDS_DCTG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, DMOB_TPIDS_DCTG_CD);
    }
    if (null == this.MCSH_FSHBT_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, MCSH_FSHBT_DIV_CD);
    }
    if (null == this.SHAG) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.SHAG, __dataOut);
    }
    if (null == this.SHP_TP_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, SHP_TP_CD);
    }
    if (null == this.SHP_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, SHP_CD);
    }
    if (null == this.ARCRF_REG_NO) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, ARCRF_REG_NO);
    }
    if (null == this.CARG_TRN_ITM_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CARG_TRN_ITM_CD);
    }
    if (null == this.DTH_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, DTH_YN);
    }
    if (null == this.AFOBS_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, AFOBS_YN);
    }
    if (null == this.HSP_MD_EXP_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, HSP_MD_EXP_YN);
    }
    if (null == this.GHR_MD_EXP_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, GHR_MD_EXP_YN);
    }
    if (null == this.PSC_MD_EXP_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, PSC_MD_EXP_YN);
    }
    if (null == this.HSP_DDPY_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, HSP_DDPY_YN);
    }
    if (null == this.LAST_DGN_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, LAST_DGN_YN);
    }
    if (null == this.SROP_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, SROP_YN);
    }
    if (null == this.EXP_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, EXP_YN);
    }
    if (null == this.SROP_BDW_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, SROP_BDW_YN);
    }
    if (null == this.OS_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, OS_ID);
    }
    if (null == this.OS_HIS_SEQ) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.OS_HIS_SEQ, __dataOut);
    }
    if (null == this.OS_SEQ) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.OS_SEQ, __dataOut);
    }
    if (null == this.OS_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, OS_DIV_CD);
    }
    if (null == this.DCN_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, DCN_ID);
    }
    if (null == this.DCN_HIS_SEQ) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.DCN_HIS_SEQ, __dataOut);
    }
    if (null == this.DCN_SEQ) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.DCN_SEQ, __dataOut);
    }
    if (null == this.DCN_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, DCN_DIV_CD);
    }
    if (null == this.CNCLU_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CNCLU_ID);
    }
    if (null == this.CNCLU_HIS_SEQ) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.CNCLU_HIS_SEQ, __dataOut);
    }
    if (null == this.CNCLU_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CNCLU_DIV_CD);
    }
    if (null == this.CNCLU_DATA_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CNCLU_DATA_DIV_CD);
    }
    if (null == this.COV_INS_DATA_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, COV_INS_DATA_DIV_CD);
    }
    if (null == this.COV_INS_HIS_SEQ) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.COV_INS_HIS_SEQ, __dataOut);
    }
    if (null == this.INS_AMT_APVL_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.INS_AMT_APVL_DT.getTime());
    __dataOut.writeInt(this.INS_AMT_APVL_DT.getNanos());
    }
    if (null == this.CSS_COV_INS_HIS_SEQ) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.CSS_COV_INS_HIS_SEQ, __dataOut);
    }
    if (null == this.SPTPY_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, SPTPY_DIV_CD);
    }
    if (null == this.ISD_PCS_SEQ) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.ISD_PCS_SEQ, __dataOut);
    }
    if (null == this.COV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, COV_CD);
    }
    if (null == this.INS_AMT_EXT_EXP_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, INS_AMT_EXT_EXP_DIV_CD);
    }
    if (null == this.GURT_UNT_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, GURT_UNT_CD);
    }
    if (null == this.RSK_UNT_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RSK_UNT_CD);
    }
    if (null == this.CLADJ_DIV_CTG_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CLADJ_DIV_CTG_CD);
    }
    if (null == this.BAS_SIC_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, BAS_SIC_DIV_CD);
    }
    if (null == this.COV_INS_BGN_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.COV_INS_BGN_DT.getTime());
    __dataOut.writeInt(this.COV_INS_BGN_DT.getNanos());
    }
    if (null == this.COV_INS_ED_DT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.COV_INS_ED_DT.getTime());
    __dataOut.writeInt(this.COV_INS_ED_DT.getNanos());
    }
    if (null == this.INSD_AMT_CUR_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, INSD_AMT_CUR_CD);
    }
    if (null == this.CUR_INSD_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.CUR_INSD_AMT, __dataOut);
    }
    if (null == this.INSD_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.INSD_AMT, __dataOut);
    }
    if (null == this.PPS_COMS_LM_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.PPS_COMS_LM_AMT, __dataOut);
    }
    if (null == this.PACD_COMS_LM_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.PACD_COMS_LM_AMT, __dataOut);
    }
    if (null == this.LDCO_CTR_BZAC_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, LDCO_CTR_BZAC_CD);
    }
    if (null == this.COI_CTR_BZAC_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, COI_CTR_BZAC_CD);
    }
    if (null == this.CSS_COV_INS_SEQ) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.CSS_COV_INS_SEQ, __dataOut);
    }
    if (null == this.JNT_ACP_COV_INS_SEQ) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.JNT_ACP_COV_INS_SEQ, __dataOut);
    }
    if (null == this.PRTC_RT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.PRTC_RT, __dataOut);
    }
    if (null == this.BRKR_CTR_BZAC_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, BRKR_CTR_BZAC_CD);
    }
    if (null == this.RINCO_CTR_BZAC_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RINCO_CTR_BZAC_CD);
    }
    if (null == this.CLOG_APL_YN) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CLOG_APL_YN);
    }
    if (null == this.CSS_CTR_ID) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CSS_CTR_ID);
    }
    if (null == this.RINS_SH_DIV_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, RINS_SH_DIV_CD);
    }
    if (null == this.BRKR_CSS_RT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.BRKR_CSS_RT, __dataOut);
    }
    if (null == this.INSD_AMT_STD_CSS_RT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.INSD_AMT_STD_CSS_RT, __dataOut);
    }
    if (null == this.ACP_AMT_STD_CSS_RT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.ACP_AMT_STD_CSS_RT, __dataOut);
    }
    if (null == this.CUR_CD) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, CUR_CD);
    }
    if (null == this.APL_EXRT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.APL_EXRT, __dataOut);
    }
    if (null == this.CSS_INS_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.CSS_INS_AMT, __dataOut);
    }
    if (null == this.KWCV_CSS_INS_AMT) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    org.apache.sqoop.lib.BigDecimalSerializer.write(this.KWCV_CSS_INS_AMT, __dataOut);
    }
    if (null == this.EIH_LDG_DTM) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.EIH_LDG_DTM.getTime());
    __dataOut.writeInt(this.EIH_LDG_DTM.getNanos());
    }
  }
  private static final DelimiterSet __outputDelimiters = new DelimiterSet((char) 1, (char) 10, (char) 0, (char) 0, false);
  public String toString() {
    return toString(__outputDelimiters, true);
  }
  public String toString(DelimiterSet delimiters) {
    return toString(delimiters, true);
  }
  public String toString(boolean useRecordDelim) {
    return toString(__outputDelimiters, useRecordDelim);
  }
  public String toString(DelimiterSet delimiters, boolean useRecordDelim) {
    StringBuilder __sb = new StringBuilder();
    char fieldDelim = delimiters.getFieldsTerminatedBy();
    __sb.append(FieldFormatter.escapeAndEnclose(CLOG_DT==null?"null":"" + CLOG_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CLM_ID==null?"null":CLM_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(COV_INS_AMT_ID==null?"null":COV_INS_AMT_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CSS_COV_INS_AMT_ID==null?"null":CSS_COV_INS_AMT_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CLADJ_CLOG_DIV_CD==null?"null":CLADJ_CLOG_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(INS_ITMS_DIV_CD==null?"null":INS_ITMS_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(BZPLN_PD_CTG_CD==null?"null":BZPLN_PD_CTG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PREBL_MNG_PD_CTG_CD==null?"null":PREBL_MNG_PD_CTG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SAL_PD_CD==null?"null":SAL_PD_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(UNT_PD_CD==null?"null":UNT_PD_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ACD_NO_YY==null?"null":ACD_NO_YY, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ACD_NO_SEQ==null?"null":ACD_NO_SEQ.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ACD_RCT_ID==null?"null":ACD_RCT_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ACD_RCT_HIS_SEQ==null?"null":ACD_RCT_HIS_SEQ.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RCT_DTM==null?"null":"" + RCT_DTM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RCT_DT==null?"null":"" + RCT_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ACD_DTM==null?"null":"" + ACD_DTM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ACD_DT==null?"null":"" + ACD_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(HOLI_YN==null?"null":HOLI_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(OD_ACD_NO==null?"null":OD_ACD_NO, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(OTHCO_ACD_NO==null?"null":OTHCO_ACD_NO, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ACD_WKD_CD==null?"null":ACD_WKD_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CITY_NATL_CD==null?"null":CITY_NATL_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ACD_PLC_ZPCD==null?"null":ACD_PLC_ZPCD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ACD_PLC_ZPCD_SNO==null?"null":ACD_PLC_ZPCD_SNO, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ACD_PLC_ZPCD_ADR==null?"null":ACD_PLC_ZPCD_ADR, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ACD_PLC_DTL_ADR_CON==null?"null":ACD_PLC_DTL_ADR_CON, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(LTT_DIV_CD==null?"null":LTT_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(LTT_COO_DG==null?"null":LTT_COO_DG.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(LTT_COO_MI==null?"null":LTT_COO_MI.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(LTT_COO_SS==null?"null":LTT_COO_SS.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(LNT_DIV_CD==null?"null":LNT_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(LNT_COO_DG==null?"null":LNT_COO_DG.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(LNT_COO_MI==null?"null":LNT_COO_MI.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(LNT_COO_SS==null?"null":LNT_COO_SS.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ACD_CTR_ID==null?"null":ACD_CTR_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ACD_CTR_HIS_SEQ==null?"null":ACD_CTR_HIS_SEQ.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(POL_NO==null?"null":POL_NO, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CTR_ENDR_NO==null?"null":CTR_ENDR_NO.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RTRO_ENDR_NO==null?"null":RTRO_ENDR_NO.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ENDR_HIS_STD_NO==null?"null":ENDR_HIS_STD_NO.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(POLHD_CUS_ID==null?"null":POLHD_CUS_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(POLHD_NM==null?"null":POLHD_NM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CTR_STAT_CD==null?"null":CTR_STAT_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CTR_STAT_DTL_CD==null?"null":CTR_STAT_DTL_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(INS_BGN_DT==null?"null":"" + INS_BGN_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(INS_ED_DT==null?"null":"" + INS_ED_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SBCP_DT==null?"null":"" + SBCP_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ACP_SH_DIV_CD==null?"null":ACP_SH_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(MRIN_PD_DIV_CD==null?"null":MRIN_PD_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(MA_INSPE_CUS_ID==null?"null":MA_INSPE_CUS_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(MA_INSPE_NM==null?"null":MA_INSPE_NM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ORIG_RTRC_DIV_CD==null?"null":ORIG_RTRC_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PLR_STUP_YN==null?"null":PLR_STUP_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(TRT_HDQT_ORG_CD==null?"null":TRT_HDQT_ORG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(TRT_BCH_ORG_CD==null?"null":TRT_BCH_ORG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(TRT_BRCH_ORG_CD==null?"null":TRT_BRCH_ORG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(TRTPE_ORG_ID==null?"null":TRTPE_ORG_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(TRTPE_ORG_CD==null?"null":TRTPE_ORG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CLM_TP_CD==null?"null":CLM_TP_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DSS_CD_YY==null?"null":DSS_CD_YY, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DSS_CD_SEQ==null?"null":DSS_CD_SEQ.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CLM_STAT_CD==null?"null":CLM_STAT_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ACD_CAUS_LCTG_CD==null?"null":ACD_CAUS_LCTG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ACD_CAUS_MCTG_CD==null?"null":ACD_CAUS_MCTG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ACD_CAUS_SCTG_CD==null?"null":ACD_CAUS_SCTG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ACD_CAUS_DCTG_CD==null?"null":ACD_CAUS_DCTG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ACD_CAUS_DCTG2_CD==null?"null":ACD_CAUS_DCTG2_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(COMS_PART_ORG_ID==null?"null":COMS_PART_ORG_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(COMS_PART_ORG_CD==null?"null":COMS_PART_ORG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(COMS_TEM_ORG_ID==null?"null":COMS_TEM_ORG_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(COMS_TEM_ORG_CD==null?"null":COMS_TEM_ORG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(COMS_CHRPE_ORG_ID==null?"null":COMS_CHRPE_ORG_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CPIC_ORG_CD==null?"null":CPIC_ORG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CNCLU_DT==null?"null":"" + CNCLU_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(EXMP_DCN_DT==null?"null":"" + EXMP_DCN_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DAM_DGR_CD==null?"null":DAM_DGR_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(AT_ISP_YN==null?"null":AT_ISP_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ACD_CTR_OBJ_ID==null?"null":ACD_CTR_OBJ_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ACD_CTR_OBJ_HIS_SEQ==null?"null":ACD_CTR_OBJ_HIS_SEQ.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ACD_OBJ_DIV_CD==null?"null":ACD_OBJ_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ACD_OBJ_ID==null?"null":ACD_OBJ_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DAM_ORD==null?"null":DAM_ORD.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CTR_OBJ_ID==null?"null":CTR_OBJ_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CTR_OBJ_ADR_ID==null?"null":CTR_OBJ_ADR_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(OBJ_TP_CD==null?"null":OBJ_TP_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DMPE_CUS_ID==null?"null":DMPE_CUS_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DMPO_NM==null?"null":DMPO_NM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PVDS_YN==null?"null":PVDS_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(TCTR_DMPE_JOB_GRD_CD==null?"null":TCTR_DMPE_JOB_GRD_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(TCTR_DMPE_JOB_CD==null?"null":TCTR_DMPE_JOB_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(TACD_DMPE_JOB_GRD_CD==null?"null":TACD_DMPE_JOB_GRD_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(TACD_DMPE_JOB_CD==null?"null":TACD_DMPE_JOB_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(OWNR_NM==null?"null":OWNR_NM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DMPE_AGE==null?"null":DMPE_AGE.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(TNG_DIV_CD==null?"null":TNG_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(OBJ_GRD_CD==null?"null":OBJ_GRD_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(OPN_JBCL_CD==null?"null":OPN_JBCL_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(OPJB_NM==null?"null":OPJB_NM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(OBJ_CD==null?"null":OBJ_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DMOB_LCTG_CD==null?"null":DMOB_LCTG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DMOB_MCTG_CD==null?"null":DMOB_MCTG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DMOB_SCTG_CD==null?"null":DMOB_SCTG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DMOB_TPIDS_LCTG_CD==null?"null":DMOB_TPIDS_LCTG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DMOB_TPIDS_MCTG_CD==null?"null":DMOB_TPIDS_MCTG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DMOB_TPIDS_SCTG_CD==null?"null":DMOB_TPIDS_SCTG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DMOB_TPIDS_DCTG_CD==null?"null":DMOB_TPIDS_DCTG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(MCSH_FSHBT_DIV_CD==null?"null":MCSH_FSHBT_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SHAG==null?"null":SHAG.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SHP_TP_CD==null?"null":SHP_TP_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SHP_CD==null?"null":SHP_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ARCRF_REG_NO==null?"null":ARCRF_REG_NO, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CARG_TRN_ITM_CD==null?"null":CARG_TRN_ITM_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DTH_YN==null?"null":DTH_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(AFOBS_YN==null?"null":AFOBS_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(HSP_MD_EXP_YN==null?"null":HSP_MD_EXP_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(GHR_MD_EXP_YN==null?"null":GHR_MD_EXP_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PSC_MD_EXP_YN==null?"null":PSC_MD_EXP_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(HSP_DDPY_YN==null?"null":HSP_DDPY_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(LAST_DGN_YN==null?"null":LAST_DGN_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SROP_YN==null?"null":SROP_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(EXP_YN==null?"null":EXP_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SROP_BDW_YN==null?"null":SROP_BDW_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(OS_ID==null?"null":OS_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(OS_HIS_SEQ==null?"null":OS_HIS_SEQ.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(OS_SEQ==null?"null":OS_SEQ.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(OS_DIV_CD==null?"null":OS_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DCN_ID==null?"null":DCN_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DCN_HIS_SEQ==null?"null":DCN_HIS_SEQ.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DCN_SEQ==null?"null":DCN_SEQ.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DCN_DIV_CD==null?"null":DCN_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CNCLU_ID==null?"null":CNCLU_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CNCLU_HIS_SEQ==null?"null":CNCLU_HIS_SEQ.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CNCLU_DIV_CD==null?"null":CNCLU_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CNCLU_DATA_DIV_CD==null?"null":CNCLU_DATA_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(COV_INS_DATA_DIV_CD==null?"null":COV_INS_DATA_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(COV_INS_HIS_SEQ==null?"null":COV_INS_HIS_SEQ.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(INS_AMT_APVL_DT==null?"null":"" + INS_AMT_APVL_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CSS_COV_INS_HIS_SEQ==null?"null":CSS_COV_INS_HIS_SEQ.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SPTPY_DIV_CD==null?"null":SPTPY_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ISD_PCS_SEQ==null?"null":ISD_PCS_SEQ.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(COV_CD==null?"null":COV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(INS_AMT_EXT_EXP_DIV_CD==null?"null":INS_AMT_EXT_EXP_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(GURT_UNT_CD==null?"null":GURT_UNT_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RSK_UNT_CD==null?"null":RSK_UNT_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CLADJ_DIV_CTG_CD==null?"null":CLADJ_DIV_CTG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(BAS_SIC_DIV_CD==null?"null":BAS_SIC_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(COV_INS_BGN_DT==null?"null":"" + COV_INS_BGN_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(COV_INS_ED_DT==null?"null":"" + COV_INS_ED_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(INSD_AMT_CUR_CD==null?"null":INSD_AMT_CUR_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CUR_INSD_AMT==null?"null":CUR_INSD_AMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(INSD_AMT==null?"null":INSD_AMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PPS_COMS_LM_AMT==null?"null":PPS_COMS_LM_AMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PACD_COMS_LM_AMT==null?"null":PACD_COMS_LM_AMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(LDCO_CTR_BZAC_CD==null?"null":LDCO_CTR_BZAC_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(COI_CTR_BZAC_CD==null?"null":COI_CTR_BZAC_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CSS_COV_INS_SEQ==null?"null":CSS_COV_INS_SEQ.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(JNT_ACP_COV_INS_SEQ==null?"null":JNT_ACP_COV_INS_SEQ.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PRTC_RT==null?"null":PRTC_RT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(BRKR_CTR_BZAC_CD==null?"null":BRKR_CTR_BZAC_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RINCO_CTR_BZAC_CD==null?"null":RINCO_CTR_BZAC_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CLOG_APL_YN==null?"null":CLOG_APL_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CSS_CTR_ID==null?"null":CSS_CTR_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RINS_SH_DIV_CD==null?"null":RINS_SH_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(BRKR_CSS_RT==null?"null":BRKR_CSS_RT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(INSD_AMT_STD_CSS_RT==null?"null":INSD_AMT_STD_CSS_RT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ACP_AMT_STD_CSS_RT==null?"null":ACP_AMT_STD_CSS_RT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CUR_CD==null?"null":CUR_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(APL_EXRT==null?"null":APL_EXRT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CSS_INS_AMT==null?"null":CSS_INS_AMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(KWCV_CSS_INS_AMT==null?"null":KWCV_CSS_INS_AMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(EIH_LDG_DTM==null?"null":"" + EIH_LDG_DTM, delimiters));
    if (useRecordDelim) {
      __sb.append(delimiters.getLinesTerminatedBy());
    }
    return __sb.toString();
  }
  public void toString0(DelimiterSet delimiters, StringBuilder __sb, char fieldDelim) {
    __sb.append(FieldFormatter.escapeAndEnclose(CLOG_DT==null?"null":"" + CLOG_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CLM_ID==null?"null":CLM_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(COV_INS_AMT_ID==null?"null":COV_INS_AMT_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CSS_COV_INS_AMT_ID==null?"null":CSS_COV_INS_AMT_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CLADJ_CLOG_DIV_CD==null?"null":CLADJ_CLOG_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(INS_ITMS_DIV_CD==null?"null":INS_ITMS_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(BZPLN_PD_CTG_CD==null?"null":BZPLN_PD_CTG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PREBL_MNG_PD_CTG_CD==null?"null":PREBL_MNG_PD_CTG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SAL_PD_CD==null?"null":SAL_PD_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(UNT_PD_CD==null?"null":UNT_PD_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ACD_NO_YY==null?"null":ACD_NO_YY, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ACD_NO_SEQ==null?"null":ACD_NO_SEQ.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ACD_RCT_ID==null?"null":ACD_RCT_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ACD_RCT_HIS_SEQ==null?"null":ACD_RCT_HIS_SEQ.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RCT_DTM==null?"null":"" + RCT_DTM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RCT_DT==null?"null":"" + RCT_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ACD_DTM==null?"null":"" + ACD_DTM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ACD_DT==null?"null":"" + ACD_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(HOLI_YN==null?"null":HOLI_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(OD_ACD_NO==null?"null":OD_ACD_NO, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(OTHCO_ACD_NO==null?"null":OTHCO_ACD_NO, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ACD_WKD_CD==null?"null":ACD_WKD_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CITY_NATL_CD==null?"null":CITY_NATL_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ACD_PLC_ZPCD==null?"null":ACD_PLC_ZPCD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ACD_PLC_ZPCD_SNO==null?"null":ACD_PLC_ZPCD_SNO, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ACD_PLC_ZPCD_ADR==null?"null":ACD_PLC_ZPCD_ADR, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ACD_PLC_DTL_ADR_CON==null?"null":ACD_PLC_DTL_ADR_CON, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(LTT_DIV_CD==null?"null":LTT_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(LTT_COO_DG==null?"null":LTT_COO_DG.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(LTT_COO_MI==null?"null":LTT_COO_MI.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(LTT_COO_SS==null?"null":LTT_COO_SS.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(LNT_DIV_CD==null?"null":LNT_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(LNT_COO_DG==null?"null":LNT_COO_DG.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(LNT_COO_MI==null?"null":LNT_COO_MI.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(LNT_COO_SS==null?"null":LNT_COO_SS.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ACD_CTR_ID==null?"null":ACD_CTR_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ACD_CTR_HIS_SEQ==null?"null":ACD_CTR_HIS_SEQ.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(POL_NO==null?"null":POL_NO, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CTR_ENDR_NO==null?"null":CTR_ENDR_NO.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RTRO_ENDR_NO==null?"null":RTRO_ENDR_NO.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ENDR_HIS_STD_NO==null?"null":ENDR_HIS_STD_NO.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(POLHD_CUS_ID==null?"null":POLHD_CUS_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(POLHD_NM==null?"null":POLHD_NM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CTR_STAT_CD==null?"null":CTR_STAT_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CTR_STAT_DTL_CD==null?"null":CTR_STAT_DTL_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(INS_BGN_DT==null?"null":"" + INS_BGN_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(INS_ED_DT==null?"null":"" + INS_ED_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SBCP_DT==null?"null":"" + SBCP_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ACP_SH_DIV_CD==null?"null":ACP_SH_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(MRIN_PD_DIV_CD==null?"null":MRIN_PD_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(MA_INSPE_CUS_ID==null?"null":MA_INSPE_CUS_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(MA_INSPE_NM==null?"null":MA_INSPE_NM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ORIG_RTRC_DIV_CD==null?"null":ORIG_RTRC_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PLR_STUP_YN==null?"null":PLR_STUP_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(TRT_HDQT_ORG_CD==null?"null":TRT_HDQT_ORG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(TRT_BCH_ORG_CD==null?"null":TRT_BCH_ORG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(TRT_BRCH_ORG_CD==null?"null":TRT_BRCH_ORG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(TRTPE_ORG_ID==null?"null":TRTPE_ORG_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(TRTPE_ORG_CD==null?"null":TRTPE_ORG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CLM_TP_CD==null?"null":CLM_TP_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DSS_CD_YY==null?"null":DSS_CD_YY, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DSS_CD_SEQ==null?"null":DSS_CD_SEQ.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CLM_STAT_CD==null?"null":CLM_STAT_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ACD_CAUS_LCTG_CD==null?"null":ACD_CAUS_LCTG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ACD_CAUS_MCTG_CD==null?"null":ACD_CAUS_MCTG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ACD_CAUS_SCTG_CD==null?"null":ACD_CAUS_SCTG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ACD_CAUS_DCTG_CD==null?"null":ACD_CAUS_DCTG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ACD_CAUS_DCTG2_CD==null?"null":ACD_CAUS_DCTG2_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(COMS_PART_ORG_ID==null?"null":COMS_PART_ORG_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(COMS_PART_ORG_CD==null?"null":COMS_PART_ORG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(COMS_TEM_ORG_ID==null?"null":COMS_TEM_ORG_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(COMS_TEM_ORG_CD==null?"null":COMS_TEM_ORG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(COMS_CHRPE_ORG_ID==null?"null":COMS_CHRPE_ORG_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CPIC_ORG_CD==null?"null":CPIC_ORG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CNCLU_DT==null?"null":"" + CNCLU_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(EXMP_DCN_DT==null?"null":"" + EXMP_DCN_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DAM_DGR_CD==null?"null":DAM_DGR_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(AT_ISP_YN==null?"null":AT_ISP_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ACD_CTR_OBJ_ID==null?"null":ACD_CTR_OBJ_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ACD_CTR_OBJ_HIS_SEQ==null?"null":ACD_CTR_OBJ_HIS_SEQ.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ACD_OBJ_DIV_CD==null?"null":ACD_OBJ_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ACD_OBJ_ID==null?"null":ACD_OBJ_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DAM_ORD==null?"null":DAM_ORD.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CTR_OBJ_ID==null?"null":CTR_OBJ_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CTR_OBJ_ADR_ID==null?"null":CTR_OBJ_ADR_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(OBJ_TP_CD==null?"null":OBJ_TP_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DMPE_CUS_ID==null?"null":DMPE_CUS_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DMPO_NM==null?"null":DMPO_NM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PVDS_YN==null?"null":PVDS_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(TCTR_DMPE_JOB_GRD_CD==null?"null":TCTR_DMPE_JOB_GRD_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(TCTR_DMPE_JOB_CD==null?"null":TCTR_DMPE_JOB_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(TACD_DMPE_JOB_GRD_CD==null?"null":TACD_DMPE_JOB_GRD_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(TACD_DMPE_JOB_CD==null?"null":TACD_DMPE_JOB_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(OWNR_NM==null?"null":OWNR_NM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DMPE_AGE==null?"null":DMPE_AGE.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(TNG_DIV_CD==null?"null":TNG_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(OBJ_GRD_CD==null?"null":OBJ_GRD_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(OPN_JBCL_CD==null?"null":OPN_JBCL_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(OPJB_NM==null?"null":OPJB_NM, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(OBJ_CD==null?"null":OBJ_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DMOB_LCTG_CD==null?"null":DMOB_LCTG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DMOB_MCTG_CD==null?"null":DMOB_MCTG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DMOB_SCTG_CD==null?"null":DMOB_SCTG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DMOB_TPIDS_LCTG_CD==null?"null":DMOB_TPIDS_LCTG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DMOB_TPIDS_MCTG_CD==null?"null":DMOB_TPIDS_MCTG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DMOB_TPIDS_SCTG_CD==null?"null":DMOB_TPIDS_SCTG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DMOB_TPIDS_DCTG_CD==null?"null":DMOB_TPIDS_DCTG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(MCSH_FSHBT_DIV_CD==null?"null":MCSH_FSHBT_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SHAG==null?"null":SHAG.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SHP_TP_CD==null?"null":SHP_TP_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SHP_CD==null?"null":SHP_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ARCRF_REG_NO==null?"null":ARCRF_REG_NO, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CARG_TRN_ITM_CD==null?"null":CARG_TRN_ITM_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DTH_YN==null?"null":DTH_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(AFOBS_YN==null?"null":AFOBS_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(HSP_MD_EXP_YN==null?"null":HSP_MD_EXP_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(GHR_MD_EXP_YN==null?"null":GHR_MD_EXP_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PSC_MD_EXP_YN==null?"null":PSC_MD_EXP_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(HSP_DDPY_YN==null?"null":HSP_DDPY_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(LAST_DGN_YN==null?"null":LAST_DGN_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SROP_YN==null?"null":SROP_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(EXP_YN==null?"null":EXP_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SROP_BDW_YN==null?"null":SROP_BDW_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(OS_ID==null?"null":OS_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(OS_HIS_SEQ==null?"null":OS_HIS_SEQ.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(OS_SEQ==null?"null":OS_SEQ.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(OS_DIV_CD==null?"null":OS_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DCN_ID==null?"null":DCN_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DCN_HIS_SEQ==null?"null":DCN_HIS_SEQ.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DCN_SEQ==null?"null":DCN_SEQ.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(DCN_DIV_CD==null?"null":DCN_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CNCLU_ID==null?"null":CNCLU_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CNCLU_HIS_SEQ==null?"null":CNCLU_HIS_SEQ.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CNCLU_DIV_CD==null?"null":CNCLU_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CNCLU_DATA_DIV_CD==null?"null":CNCLU_DATA_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(COV_INS_DATA_DIV_CD==null?"null":COV_INS_DATA_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(COV_INS_HIS_SEQ==null?"null":COV_INS_HIS_SEQ.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(INS_AMT_APVL_DT==null?"null":"" + INS_AMT_APVL_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CSS_COV_INS_HIS_SEQ==null?"null":CSS_COV_INS_HIS_SEQ.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(SPTPY_DIV_CD==null?"null":SPTPY_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ISD_PCS_SEQ==null?"null":ISD_PCS_SEQ.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(COV_CD==null?"null":COV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(INS_AMT_EXT_EXP_DIV_CD==null?"null":INS_AMT_EXT_EXP_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(GURT_UNT_CD==null?"null":GURT_UNT_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RSK_UNT_CD==null?"null":RSK_UNT_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CLADJ_DIV_CTG_CD==null?"null":CLADJ_DIV_CTG_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(BAS_SIC_DIV_CD==null?"null":BAS_SIC_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(COV_INS_BGN_DT==null?"null":"" + COV_INS_BGN_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(COV_INS_ED_DT==null?"null":"" + COV_INS_ED_DT, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(INSD_AMT_CUR_CD==null?"null":INSD_AMT_CUR_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CUR_INSD_AMT==null?"null":CUR_INSD_AMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(INSD_AMT==null?"null":INSD_AMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PPS_COMS_LM_AMT==null?"null":PPS_COMS_LM_AMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PACD_COMS_LM_AMT==null?"null":PACD_COMS_LM_AMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(LDCO_CTR_BZAC_CD==null?"null":LDCO_CTR_BZAC_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(COI_CTR_BZAC_CD==null?"null":COI_CTR_BZAC_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CSS_COV_INS_SEQ==null?"null":CSS_COV_INS_SEQ.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(JNT_ACP_COV_INS_SEQ==null?"null":JNT_ACP_COV_INS_SEQ.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(PRTC_RT==null?"null":PRTC_RT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(BRKR_CTR_BZAC_CD==null?"null":BRKR_CTR_BZAC_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RINCO_CTR_BZAC_CD==null?"null":RINCO_CTR_BZAC_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CLOG_APL_YN==null?"null":CLOG_APL_YN, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CSS_CTR_ID==null?"null":CSS_CTR_ID, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(RINS_SH_DIV_CD==null?"null":RINS_SH_DIV_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(BRKR_CSS_RT==null?"null":BRKR_CSS_RT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(INSD_AMT_STD_CSS_RT==null?"null":INSD_AMT_STD_CSS_RT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ACP_AMT_STD_CSS_RT==null?"null":ACP_AMT_STD_CSS_RT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CUR_CD==null?"null":CUR_CD, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(APL_EXRT==null?"null":APL_EXRT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(CSS_INS_AMT==null?"null":CSS_INS_AMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(KWCV_CSS_INS_AMT==null?"null":KWCV_CSS_INS_AMT.toPlainString(), delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(EIH_LDG_DTM==null?"null":"" + EIH_LDG_DTM, delimiters));
  }
  private static final DelimiterSet __inputDelimiters = new DelimiterSet((char) 1, (char) 10, (char) 0, (char) 0, false);
  private RecordParser __parser;
  public void parse(Text __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(CharSequence __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(byte [] __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(char [] __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(ByteBuffer __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(CharBuffer __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  private void __loadFromFields(List<String> fields) {
    Iterator<String> __it = fields.listIterator();
    String __cur_str = null;
    try {
    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.CLOG_DT = null; } else {
      this.CLOG_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CLM_ID = null; } else {
      this.CLM_ID = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.COV_INS_AMT_ID = null; } else {
      this.COV_INS_AMT_ID = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CSS_COV_INS_AMT_ID = null; } else {
      this.CSS_COV_INS_AMT_ID = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CLADJ_CLOG_DIV_CD = null; } else {
      this.CLADJ_CLOG_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.INS_ITMS_DIV_CD = null; } else {
      this.INS_ITMS_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.BZPLN_PD_CTG_CD = null; } else {
      this.BZPLN_PD_CTG_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.PREBL_MNG_PD_CTG_CD = null; } else {
      this.PREBL_MNG_PD_CTG_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.SAL_PD_CD = null; } else {
      this.SAL_PD_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.UNT_PD_CD = null; } else {
      this.UNT_PD_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.ACD_NO_YY = null; } else {
      this.ACD_NO_YY = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.ACD_NO_SEQ = null; } else {
      this.ACD_NO_SEQ = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.ACD_RCT_ID = null; } else {
      this.ACD_RCT_ID = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.ACD_RCT_HIS_SEQ = null; } else {
      this.ACD_RCT_HIS_SEQ = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RCT_DTM = null; } else {
      this.RCT_DTM = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RCT_DT = null; } else {
      this.RCT_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.ACD_DTM = null; } else {
      this.ACD_DTM = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.ACD_DT = null; } else {
      this.ACD_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.HOLI_YN = null; } else {
      this.HOLI_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.OD_ACD_NO = null; } else {
      this.OD_ACD_NO = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.OTHCO_ACD_NO = null; } else {
      this.OTHCO_ACD_NO = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.ACD_WKD_CD = null; } else {
      this.ACD_WKD_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CITY_NATL_CD = null; } else {
      this.CITY_NATL_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.ACD_PLC_ZPCD = null; } else {
      this.ACD_PLC_ZPCD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.ACD_PLC_ZPCD_SNO = null; } else {
      this.ACD_PLC_ZPCD_SNO = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.ACD_PLC_ZPCD_ADR = null; } else {
      this.ACD_PLC_ZPCD_ADR = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.ACD_PLC_DTL_ADR_CON = null; } else {
      this.ACD_PLC_DTL_ADR_CON = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.LTT_DIV_CD = null; } else {
      this.LTT_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.LTT_COO_DG = null; } else {
      this.LTT_COO_DG = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.LTT_COO_MI = null; } else {
      this.LTT_COO_MI = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.LTT_COO_SS = null; } else {
      this.LTT_COO_SS = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.LNT_DIV_CD = null; } else {
      this.LNT_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.LNT_COO_DG = null; } else {
      this.LNT_COO_DG = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.LNT_COO_MI = null; } else {
      this.LNT_COO_MI = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.LNT_COO_SS = null; } else {
      this.LNT_COO_SS = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.ACD_CTR_ID = null; } else {
      this.ACD_CTR_ID = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.ACD_CTR_HIS_SEQ = null; } else {
      this.ACD_CTR_HIS_SEQ = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.POL_NO = null; } else {
      this.POL_NO = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.CTR_ENDR_NO = null; } else {
      this.CTR_ENDR_NO = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RTRO_ENDR_NO = null; } else {
      this.RTRO_ENDR_NO = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.ENDR_HIS_STD_NO = null; } else {
      this.ENDR_HIS_STD_NO = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.POLHD_CUS_ID = null; } else {
      this.POLHD_CUS_ID = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.POLHD_NM = null; } else {
      this.POLHD_NM = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CTR_STAT_CD = null; } else {
      this.CTR_STAT_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CTR_STAT_DTL_CD = null; } else {
      this.CTR_STAT_DTL_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.INS_BGN_DT = null; } else {
      this.INS_BGN_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.INS_ED_DT = null; } else {
      this.INS_ED_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.SBCP_DT = null; } else {
      this.SBCP_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.ACP_SH_DIV_CD = null; } else {
      this.ACP_SH_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.MRIN_PD_DIV_CD = null; } else {
      this.MRIN_PD_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.MA_INSPE_CUS_ID = null; } else {
      this.MA_INSPE_CUS_ID = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.MA_INSPE_NM = null; } else {
      this.MA_INSPE_NM = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.ORIG_RTRC_DIV_CD = null; } else {
      this.ORIG_RTRC_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.PLR_STUP_YN = null; } else {
      this.PLR_STUP_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.TRT_HDQT_ORG_CD = null; } else {
      this.TRT_HDQT_ORG_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.TRT_BCH_ORG_CD = null; } else {
      this.TRT_BCH_ORG_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.TRT_BRCH_ORG_CD = null; } else {
      this.TRT_BRCH_ORG_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.TRTPE_ORG_ID = null; } else {
      this.TRTPE_ORG_ID = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.TRTPE_ORG_CD = null; } else {
      this.TRTPE_ORG_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CLM_TP_CD = null; } else {
      this.CLM_TP_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.DSS_CD_YY = null; } else {
      this.DSS_CD_YY = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.DSS_CD_SEQ = null; } else {
      this.DSS_CD_SEQ = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CLM_STAT_CD = null; } else {
      this.CLM_STAT_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.ACD_CAUS_LCTG_CD = null; } else {
      this.ACD_CAUS_LCTG_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.ACD_CAUS_MCTG_CD = null; } else {
      this.ACD_CAUS_MCTG_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.ACD_CAUS_SCTG_CD = null; } else {
      this.ACD_CAUS_SCTG_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.ACD_CAUS_DCTG_CD = null; } else {
      this.ACD_CAUS_DCTG_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.ACD_CAUS_DCTG2_CD = null; } else {
      this.ACD_CAUS_DCTG2_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.COMS_PART_ORG_ID = null; } else {
      this.COMS_PART_ORG_ID = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.COMS_PART_ORG_CD = null; } else {
      this.COMS_PART_ORG_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.COMS_TEM_ORG_ID = null; } else {
      this.COMS_TEM_ORG_ID = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.COMS_TEM_ORG_CD = null; } else {
      this.COMS_TEM_ORG_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.COMS_CHRPE_ORG_ID = null; } else {
      this.COMS_CHRPE_ORG_ID = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CPIC_ORG_CD = null; } else {
      this.CPIC_ORG_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.CNCLU_DT = null; } else {
      this.CNCLU_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.EXMP_DCN_DT = null; } else {
      this.EXMP_DCN_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.DAM_DGR_CD = null; } else {
      this.DAM_DGR_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.AT_ISP_YN = null; } else {
      this.AT_ISP_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.ACD_CTR_OBJ_ID = null; } else {
      this.ACD_CTR_OBJ_ID = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.ACD_CTR_OBJ_HIS_SEQ = null; } else {
      this.ACD_CTR_OBJ_HIS_SEQ = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.ACD_OBJ_DIV_CD = null; } else {
      this.ACD_OBJ_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.ACD_OBJ_ID = null; } else {
      this.ACD_OBJ_ID = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.DAM_ORD = null; } else {
      this.DAM_ORD = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CTR_OBJ_ID = null; } else {
      this.CTR_OBJ_ID = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CTR_OBJ_ADR_ID = null; } else {
      this.CTR_OBJ_ADR_ID = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.OBJ_TP_CD = null; } else {
      this.OBJ_TP_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.DMPE_CUS_ID = null; } else {
      this.DMPE_CUS_ID = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.DMPO_NM = null; } else {
      this.DMPO_NM = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.PVDS_YN = null; } else {
      this.PVDS_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.TCTR_DMPE_JOB_GRD_CD = null; } else {
      this.TCTR_DMPE_JOB_GRD_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.TCTR_DMPE_JOB_CD = null; } else {
      this.TCTR_DMPE_JOB_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.TACD_DMPE_JOB_GRD_CD = null; } else {
      this.TACD_DMPE_JOB_GRD_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.TACD_DMPE_JOB_CD = null; } else {
      this.TACD_DMPE_JOB_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.OWNR_NM = null; } else {
      this.OWNR_NM = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.DMPE_AGE = null; } else {
      this.DMPE_AGE = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.TNG_DIV_CD = null; } else {
      this.TNG_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.OBJ_GRD_CD = null; } else {
      this.OBJ_GRD_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.OPN_JBCL_CD = null; } else {
      this.OPN_JBCL_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.OPJB_NM = null; } else {
      this.OPJB_NM = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.OBJ_CD = null; } else {
      this.OBJ_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.DMOB_LCTG_CD = null; } else {
      this.DMOB_LCTG_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.DMOB_MCTG_CD = null; } else {
      this.DMOB_MCTG_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.DMOB_SCTG_CD = null; } else {
      this.DMOB_SCTG_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.DMOB_TPIDS_LCTG_CD = null; } else {
      this.DMOB_TPIDS_LCTG_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.DMOB_TPIDS_MCTG_CD = null; } else {
      this.DMOB_TPIDS_MCTG_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.DMOB_TPIDS_SCTG_CD = null; } else {
      this.DMOB_TPIDS_SCTG_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.DMOB_TPIDS_DCTG_CD = null; } else {
      this.DMOB_TPIDS_DCTG_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.MCSH_FSHBT_DIV_CD = null; } else {
      this.MCSH_FSHBT_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.SHAG = null; } else {
      this.SHAG = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.SHP_TP_CD = null; } else {
      this.SHP_TP_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.SHP_CD = null; } else {
      this.SHP_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.ARCRF_REG_NO = null; } else {
      this.ARCRF_REG_NO = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CARG_TRN_ITM_CD = null; } else {
      this.CARG_TRN_ITM_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.DTH_YN = null; } else {
      this.DTH_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.AFOBS_YN = null; } else {
      this.AFOBS_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.HSP_MD_EXP_YN = null; } else {
      this.HSP_MD_EXP_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.GHR_MD_EXP_YN = null; } else {
      this.GHR_MD_EXP_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.PSC_MD_EXP_YN = null; } else {
      this.PSC_MD_EXP_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.HSP_DDPY_YN = null; } else {
      this.HSP_DDPY_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.LAST_DGN_YN = null; } else {
      this.LAST_DGN_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.SROP_YN = null; } else {
      this.SROP_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.EXP_YN = null; } else {
      this.EXP_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.SROP_BDW_YN = null; } else {
      this.SROP_BDW_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.OS_ID = null; } else {
      this.OS_ID = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.OS_HIS_SEQ = null; } else {
      this.OS_HIS_SEQ = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.OS_SEQ = null; } else {
      this.OS_SEQ = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.OS_DIV_CD = null; } else {
      this.OS_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.DCN_ID = null; } else {
      this.DCN_ID = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.DCN_HIS_SEQ = null; } else {
      this.DCN_HIS_SEQ = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.DCN_SEQ = null; } else {
      this.DCN_SEQ = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.DCN_DIV_CD = null; } else {
      this.DCN_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CNCLU_ID = null; } else {
      this.CNCLU_ID = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.CNCLU_HIS_SEQ = null; } else {
      this.CNCLU_HIS_SEQ = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CNCLU_DIV_CD = null; } else {
      this.CNCLU_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CNCLU_DATA_DIV_CD = null; } else {
      this.CNCLU_DATA_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.COV_INS_DATA_DIV_CD = null; } else {
      this.COV_INS_DATA_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.COV_INS_HIS_SEQ = null; } else {
      this.COV_INS_HIS_SEQ = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.INS_AMT_APVL_DT = null; } else {
      this.INS_AMT_APVL_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.CSS_COV_INS_HIS_SEQ = null; } else {
      this.CSS_COV_INS_HIS_SEQ = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.SPTPY_DIV_CD = null; } else {
      this.SPTPY_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.ISD_PCS_SEQ = null; } else {
      this.ISD_PCS_SEQ = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.COV_CD = null; } else {
      this.COV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.INS_AMT_EXT_EXP_DIV_CD = null; } else {
      this.INS_AMT_EXT_EXP_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.GURT_UNT_CD = null; } else {
      this.GURT_UNT_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.RSK_UNT_CD = null; } else {
      this.RSK_UNT_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CLADJ_DIV_CTG_CD = null; } else {
      this.CLADJ_DIV_CTG_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.BAS_SIC_DIV_CD = null; } else {
      this.BAS_SIC_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.COV_INS_BGN_DT = null; } else {
      this.COV_INS_BGN_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.COV_INS_ED_DT = null; } else {
      this.COV_INS_ED_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.INSD_AMT_CUR_CD = null; } else {
      this.INSD_AMT_CUR_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.CUR_INSD_AMT = null; } else {
      this.CUR_INSD_AMT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.INSD_AMT = null; } else {
      this.INSD_AMT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.PPS_COMS_LM_AMT = null; } else {
      this.PPS_COMS_LM_AMT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.PACD_COMS_LM_AMT = null; } else {
      this.PACD_COMS_LM_AMT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.LDCO_CTR_BZAC_CD = null; } else {
      this.LDCO_CTR_BZAC_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.COI_CTR_BZAC_CD = null; } else {
      this.COI_CTR_BZAC_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.CSS_COV_INS_SEQ = null; } else {
      this.CSS_COV_INS_SEQ = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.JNT_ACP_COV_INS_SEQ = null; } else {
      this.JNT_ACP_COV_INS_SEQ = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.PRTC_RT = null; } else {
      this.PRTC_RT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.BRKR_CTR_BZAC_CD = null; } else {
      this.BRKR_CTR_BZAC_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.RINCO_CTR_BZAC_CD = null; } else {
      this.RINCO_CTR_BZAC_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CLOG_APL_YN = null; } else {
      this.CLOG_APL_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CSS_CTR_ID = null; } else {
      this.CSS_CTR_ID = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.RINS_SH_DIV_CD = null; } else {
      this.RINS_SH_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.BRKR_CSS_RT = null; } else {
      this.BRKR_CSS_RT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.INSD_AMT_STD_CSS_RT = null; } else {
      this.INSD_AMT_STD_CSS_RT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.ACP_AMT_STD_CSS_RT = null; } else {
      this.ACP_AMT_STD_CSS_RT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CUR_CD = null; } else {
      this.CUR_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.APL_EXRT = null; } else {
      this.APL_EXRT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.CSS_INS_AMT = null; } else {
      this.CSS_INS_AMT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.KWCV_CSS_INS_AMT = null; } else {
      this.KWCV_CSS_INS_AMT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.EIH_LDG_DTM = null; } else {
      this.EIH_LDG_DTM = java.sql.Timestamp.valueOf(__cur_str);
    }

    } catch (RuntimeException e) {    throw new RuntimeException("Can't parse input data: '" + __cur_str + "'", e);    }  }

  private void __loadFromFields0(Iterator<String> __it) {
    String __cur_str = null;
    try {
    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.CLOG_DT = null; } else {
      this.CLOG_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CLM_ID = null; } else {
      this.CLM_ID = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.COV_INS_AMT_ID = null; } else {
      this.COV_INS_AMT_ID = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CSS_COV_INS_AMT_ID = null; } else {
      this.CSS_COV_INS_AMT_ID = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CLADJ_CLOG_DIV_CD = null; } else {
      this.CLADJ_CLOG_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.INS_ITMS_DIV_CD = null; } else {
      this.INS_ITMS_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.BZPLN_PD_CTG_CD = null; } else {
      this.BZPLN_PD_CTG_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.PREBL_MNG_PD_CTG_CD = null; } else {
      this.PREBL_MNG_PD_CTG_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.SAL_PD_CD = null; } else {
      this.SAL_PD_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.UNT_PD_CD = null; } else {
      this.UNT_PD_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.ACD_NO_YY = null; } else {
      this.ACD_NO_YY = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.ACD_NO_SEQ = null; } else {
      this.ACD_NO_SEQ = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.ACD_RCT_ID = null; } else {
      this.ACD_RCT_ID = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.ACD_RCT_HIS_SEQ = null; } else {
      this.ACD_RCT_HIS_SEQ = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RCT_DTM = null; } else {
      this.RCT_DTM = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RCT_DT = null; } else {
      this.RCT_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.ACD_DTM = null; } else {
      this.ACD_DTM = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.ACD_DT = null; } else {
      this.ACD_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.HOLI_YN = null; } else {
      this.HOLI_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.OD_ACD_NO = null; } else {
      this.OD_ACD_NO = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.OTHCO_ACD_NO = null; } else {
      this.OTHCO_ACD_NO = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.ACD_WKD_CD = null; } else {
      this.ACD_WKD_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CITY_NATL_CD = null; } else {
      this.CITY_NATL_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.ACD_PLC_ZPCD = null; } else {
      this.ACD_PLC_ZPCD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.ACD_PLC_ZPCD_SNO = null; } else {
      this.ACD_PLC_ZPCD_SNO = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.ACD_PLC_ZPCD_ADR = null; } else {
      this.ACD_PLC_ZPCD_ADR = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.ACD_PLC_DTL_ADR_CON = null; } else {
      this.ACD_PLC_DTL_ADR_CON = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.LTT_DIV_CD = null; } else {
      this.LTT_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.LTT_COO_DG = null; } else {
      this.LTT_COO_DG = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.LTT_COO_MI = null; } else {
      this.LTT_COO_MI = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.LTT_COO_SS = null; } else {
      this.LTT_COO_SS = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.LNT_DIV_CD = null; } else {
      this.LNT_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.LNT_COO_DG = null; } else {
      this.LNT_COO_DG = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.LNT_COO_MI = null; } else {
      this.LNT_COO_MI = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.LNT_COO_SS = null; } else {
      this.LNT_COO_SS = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.ACD_CTR_ID = null; } else {
      this.ACD_CTR_ID = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.ACD_CTR_HIS_SEQ = null; } else {
      this.ACD_CTR_HIS_SEQ = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.POL_NO = null; } else {
      this.POL_NO = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.CTR_ENDR_NO = null; } else {
      this.CTR_ENDR_NO = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.RTRO_ENDR_NO = null; } else {
      this.RTRO_ENDR_NO = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.ENDR_HIS_STD_NO = null; } else {
      this.ENDR_HIS_STD_NO = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.POLHD_CUS_ID = null; } else {
      this.POLHD_CUS_ID = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.POLHD_NM = null; } else {
      this.POLHD_NM = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CTR_STAT_CD = null; } else {
      this.CTR_STAT_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CTR_STAT_DTL_CD = null; } else {
      this.CTR_STAT_DTL_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.INS_BGN_DT = null; } else {
      this.INS_BGN_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.INS_ED_DT = null; } else {
      this.INS_ED_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.SBCP_DT = null; } else {
      this.SBCP_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.ACP_SH_DIV_CD = null; } else {
      this.ACP_SH_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.MRIN_PD_DIV_CD = null; } else {
      this.MRIN_PD_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.MA_INSPE_CUS_ID = null; } else {
      this.MA_INSPE_CUS_ID = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.MA_INSPE_NM = null; } else {
      this.MA_INSPE_NM = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.ORIG_RTRC_DIV_CD = null; } else {
      this.ORIG_RTRC_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.PLR_STUP_YN = null; } else {
      this.PLR_STUP_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.TRT_HDQT_ORG_CD = null; } else {
      this.TRT_HDQT_ORG_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.TRT_BCH_ORG_CD = null; } else {
      this.TRT_BCH_ORG_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.TRT_BRCH_ORG_CD = null; } else {
      this.TRT_BRCH_ORG_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.TRTPE_ORG_ID = null; } else {
      this.TRTPE_ORG_ID = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.TRTPE_ORG_CD = null; } else {
      this.TRTPE_ORG_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CLM_TP_CD = null; } else {
      this.CLM_TP_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.DSS_CD_YY = null; } else {
      this.DSS_CD_YY = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.DSS_CD_SEQ = null; } else {
      this.DSS_CD_SEQ = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CLM_STAT_CD = null; } else {
      this.CLM_STAT_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.ACD_CAUS_LCTG_CD = null; } else {
      this.ACD_CAUS_LCTG_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.ACD_CAUS_MCTG_CD = null; } else {
      this.ACD_CAUS_MCTG_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.ACD_CAUS_SCTG_CD = null; } else {
      this.ACD_CAUS_SCTG_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.ACD_CAUS_DCTG_CD = null; } else {
      this.ACD_CAUS_DCTG_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.ACD_CAUS_DCTG2_CD = null; } else {
      this.ACD_CAUS_DCTG2_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.COMS_PART_ORG_ID = null; } else {
      this.COMS_PART_ORG_ID = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.COMS_PART_ORG_CD = null; } else {
      this.COMS_PART_ORG_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.COMS_TEM_ORG_ID = null; } else {
      this.COMS_TEM_ORG_ID = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.COMS_TEM_ORG_CD = null; } else {
      this.COMS_TEM_ORG_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.COMS_CHRPE_ORG_ID = null; } else {
      this.COMS_CHRPE_ORG_ID = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CPIC_ORG_CD = null; } else {
      this.CPIC_ORG_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.CNCLU_DT = null; } else {
      this.CNCLU_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.EXMP_DCN_DT = null; } else {
      this.EXMP_DCN_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.DAM_DGR_CD = null; } else {
      this.DAM_DGR_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.AT_ISP_YN = null; } else {
      this.AT_ISP_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.ACD_CTR_OBJ_ID = null; } else {
      this.ACD_CTR_OBJ_ID = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.ACD_CTR_OBJ_HIS_SEQ = null; } else {
      this.ACD_CTR_OBJ_HIS_SEQ = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.ACD_OBJ_DIV_CD = null; } else {
      this.ACD_OBJ_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.ACD_OBJ_ID = null; } else {
      this.ACD_OBJ_ID = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.DAM_ORD = null; } else {
      this.DAM_ORD = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CTR_OBJ_ID = null; } else {
      this.CTR_OBJ_ID = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CTR_OBJ_ADR_ID = null; } else {
      this.CTR_OBJ_ADR_ID = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.OBJ_TP_CD = null; } else {
      this.OBJ_TP_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.DMPE_CUS_ID = null; } else {
      this.DMPE_CUS_ID = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.DMPO_NM = null; } else {
      this.DMPO_NM = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.PVDS_YN = null; } else {
      this.PVDS_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.TCTR_DMPE_JOB_GRD_CD = null; } else {
      this.TCTR_DMPE_JOB_GRD_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.TCTR_DMPE_JOB_CD = null; } else {
      this.TCTR_DMPE_JOB_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.TACD_DMPE_JOB_GRD_CD = null; } else {
      this.TACD_DMPE_JOB_GRD_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.TACD_DMPE_JOB_CD = null; } else {
      this.TACD_DMPE_JOB_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.OWNR_NM = null; } else {
      this.OWNR_NM = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.DMPE_AGE = null; } else {
      this.DMPE_AGE = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.TNG_DIV_CD = null; } else {
      this.TNG_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.OBJ_GRD_CD = null; } else {
      this.OBJ_GRD_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.OPN_JBCL_CD = null; } else {
      this.OPN_JBCL_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.OPJB_NM = null; } else {
      this.OPJB_NM = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.OBJ_CD = null; } else {
      this.OBJ_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.DMOB_LCTG_CD = null; } else {
      this.DMOB_LCTG_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.DMOB_MCTG_CD = null; } else {
      this.DMOB_MCTG_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.DMOB_SCTG_CD = null; } else {
      this.DMOB_SCTG_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.DMOB_TPIDS_LCTG_CD = null; } else {
      this.DMOB_TPIDS_LCTG_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.DMOB_TPIDS_MCTG_CD = null; } else {
      this.DMOB_TPIDS_MCTG_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.DMOB_TPIDS_SCTG_CD = null; } else {
      this.DMOB_TPIDS_SCTG_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.DMOB_TPIDS_DCTG_CD = null; } else {
      this.DMOB_TPIDS_DCTG_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.MCSH_FSHBT_DIV_CD = null; } else {
      this.MCSH_FSHBT_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.SHAG = null; } else {
      this.SHAG = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.SHP_TP_CD = null; } else {
      this.SHP_TP_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.SHP_CD = null; } else {
      this.SHP_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.ARCRF_REG_NO = null; } else {
      this.ARCRF_REG_NO = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CARG_TRN_ITM_CD = null; } else {
      this.CARG_TRN_ITM_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.DTH_YN = null; } else {
      this.DTH_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.AFOBS_YN = null; } else {
      this.AFOBS_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.HSP_MD_EXP_YN = null; } else {
      this.HSP_MD_EXP_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.GHR_MD_EXP_YN = null; } else {
      this.GHR_MD_EXP_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.PSC_MD_EXP_YN = null; } else {
      this.PSC_MD_EXP_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.HSP_DDPY_YN = null; } else {
      this.HSP_DDPY_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.LAST_DGN_YN = null; } else {
      this.LAST_DGN_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.SROP_YN = null; } else {
      this.SROP_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.EXP_YN = null; } else {
      this.EXP_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.SROP_BDW_YN = null; } else {
      this.SROP_BDW_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.OS_ID = null; } else {
      this.OS_ID = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.OS_HIS_SEQ = null; } else {
      this.OS_HIS_SEQ = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.OS_SEQ = null; } else {
      this.OS_SEQ = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.OS_DIV_CD = null; } else {
      this.OS_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.DCN_ID = null; } else {
      this.DCN_ID = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.DCN_HIS_SEQ = null; } else {
      this.DCN_HIS_SEQ = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.DCN_SEQ = null; } else {
      this.DCN_SEQ = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.DCN_DIV_CD = null; } else {
      this.DCN_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CNCLU_ID = null; } else {
      this.CNCLU_ID = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.CNCLU_HIS_SEQ = null; } else {
      this.CNCLU_HIS_SEQ = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CNCLU_DIV_CD = null; } else {
      this.CNCLU_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CNCLU_DATA_DIV_CD = null; } else {
      this.CNCLU_DATA_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.COV_INS_DATA_DIV_CD = null; } else {
      this.COV_INS_DATA_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.COV_INS_HIS_SEQ = null; } else {
      this.COV_INS_HIS_SEQ = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.INS_AMT_APVL_DT = null; } else {
      this.INS_AMT_APVL_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.CSS_COV_INS_HIS_SEQ = null; } else {
      this.CSS_COV_INS_HIS_SEQ = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.SPTPY_DIV_CD = null; } else {
      this.SPTPY_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.ISD_PCS_SEQ = null; } else {
      this.ISD_PCS_SEQ = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.COV_CD = null; } else {
      this.COV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.INS_AMT_EXT_EXP_DIV_CD = null; } else {
      this.INS_AMT_EXT_EXP_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.GURT_UNT_CD = null; } else {
      this.GURT_UNT_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.RSK_UNT_CD = null; } else {
      this.RSK_UNT_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CLADJ_DIV_CTG_CD = null; } else {
      this.CLADJ_DIV_CTG_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.BAS_SIC_DIV_CD = null; } else {
      this.BAS_SIC_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.COV_INS_BGN_DT = null; } else {
      this.COV_INS_BGN_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.COV_INS_ED_DT = null; } else {
      this.COV_INS_ED_DT = java.sql.Timestamp.valueOf(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.INSD_AMT_CUR_CD = null; } else {
      this.INSD_AMT_CUR_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.CUR_INSD_AMT = null; } else {
      this.CUR_INSD_AMT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.INSD_AMT = null; } else {
      this.INSD_AMT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.PPS_COMS_LM_AMT = null; } else {
      this.PPS_COMS_LM_AMT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.PACD_COMS_LM_AMT = null; } else {
      this.PACD_COMS_LM_AMT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.LDCO_CTR_BZAC_CD = null; } else {
      this.LDCO_CTR_BZAC_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.COI_CTR_BZAC_CD = null; } else {
      this.COI_CTR_BZAC_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.CSS_COV_INS_SEQ = null; } else {
      this.CSS_COV_INS_SEQ = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.JNT_ACP_COV_INS_SEQ = null; } else {
      this.JNT_ACP_COV_INS_SEQ = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.PRTC_RT = null; } else {
      this.PRTC_RT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.BRKR_CTR_BZAC_CD = null; } else {
      this.BRKR_CTR_BZAC_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.RINCO_CTR_BZAC_CD = null; } else {
      this.RINCO_CTR_BZAC_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CLOG_APL_YN = null; } else {
      this.CLOG_APL_YN = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CSS_CTR_ID = null; } else {
      this.CSS_CTR_ID = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.RINS_SH_DIV_CD = null; } else {
      this.RINS_SH_DIV_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.BRKR_CSS_RT = null; } else {
      this.BRKR_CSS_RT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.INSD_AMT_STD_CSS_RT = null; } else {
      this.INSD_AMT_STD_CSS_RT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.ACP_AMT_STD_CSS_RT = null; } else {
      this.ACP_AMT_STD_CSS_RT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null")) { this.CUR_CD = null; } else {
      this.CUR_CD = __cur_str;
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.APL_EXRT = null; } else {
      this.APL_EXRT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.CSS_INS_AMT = null; } else {
      this.CSS_INS_AMT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.KWCV_CSS_INS_AMT = null; } else {
      this.KWCV_CSS_INS_AMT = new java.math.BigDecimal(__cur_str);
    }

    if (__it.hasNext()) {
        __cur_str = __it.next();
    } else {
        __cur_str = "null";
    }
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.EIH_LDG_DTM = null; } else {
      this.EIH_LDG_DTM = java.sql.Timestamp.valueOf(__cur_str);
    }

    } catch (RuntimeException e) {    throw new RuntimeException("Can't parse input data: '" + __cur_str + "'", e);    }  }

  public Object clone() throws CloneNotSupportedException {
    QueryResult o = (QueryResult) super.clone();
    o.CLOG_DT = (o.CLOG_DT != null) ? (java.sql.Timestamp) o.CLOG_DT.clone() : null;
    o.RCT_DTM = (o.RCT_DTM != null) ? (java.sql.Timestamp) o.RCT_DTM.clone() : null;
    o.RCT_DT = (o.RCT_DT != null) ? (java.sql.Timestamp) o.RCT_DT.clone() : null;
    o.ACD_DTM = (o.ACD_DTM != null) ? (java.sql.Timestamp) o.ACD_DTM.clone() : null;
    o.ACD_DT = (o.ACD_DT != null) ? (java.sql.Timestamp) o.ACD_DT.clone() : null;
    o.INS_BGN_DT = (o.INS_BGN_DT != null) ? (java.sql.Timestamp) o.INS_BGN_DT.clone() : null;
    o.INS_ED_DT = (o.INS_ED_DT != null) ? (java.sql.Timestamp) o.INS_ED_DT.clone() : null;
    o.SBCP_DT = (o.SBCP_DT != null) ? (java.sql.Timestamp) o.SBCP_DT.clone() : null;
    o.CNCLU_DT = (o.CNCLU_DT != null) ? (java.sql.Timestamp) o.CNCLU_DT.clone() : null;
    o.EXMP_DCN_DT = (o.EXMP_DCN_DT != null) ? (java.sql.Timestamp) o.EXMP_DCN_DT.clone() : null;
    o.INS_AMT_APVL_DT = (o.INS_AMT_APVL_DT != null) ? (java.sql.Timestamp) o.INS_AMT_APVL_DT.clone() : null;
    o.COV_INS_BGN_DT = (o.COV_INS_BGN_DT != null) ? (java.sql.Timestamp) o.COV_INS_BGN_DT.clone() : null;
    o.COV_INS_ED_DT = (o.COV_INS_ED_DT != null) ? (java.sql.Timestamp) o.COV_INS_ED_DT.clone() : null;
    o.EIH_LDG_DTM = (o.EIH_LDG_DTM != null) ? (java.sql.Timestamp) o.EIH_LDG_DTM.clone() : null;
    return o;
  }

  public void clone0(QueryResult o) throws CloneNotSupportedException {
    o.CLOG_DT = (o.CLOG_DT != null) ? (java.sql.Timestamp) o.CLOG_DT.clone() : null;
    o.RCT_DTM = (o.RCT_DTM != null) ? (java.sql.Timestamp) o.RCT_DTM.clone() : null;
    o.RCT_DT = (o.RCT_DT != null) ? (java.sql.Timestamp) o.RCT_DT.clone() : null;
    o.ACD_DTM = (o.ACD_DTM != null) ? (java.sql.Timestamp) o.ACD_DTM.clone() : null;
    o.ACD_DT = (o.ACD_DT != null) ? (java.sql.Timestamp) o.ACD_DT.clone() : null;
    o.INS_BGN_DT = (o.INS_BGN_DT != null) ? (java.sql.Timestamp) o.INS_BGN_DT.clone() : null;
    o.INS_ED_DT = (o.INS_ED_DT != null) ? (java.sql.Timestamp) o.INS_ED_DT.clone() : null;
    o.SBCP_DT = (o.SBCP_DT != null) ? (java.sql.Timestamp) o.SBCP_DT.clone() : null;
    o.CNCLU_DT = (o.CNCLU_DT != null) ? (java.sql.Timestamp) o.CNCLU_DT.clone() : null;
    o.EXMP_DCN_DT = (o.EXMP_DCN_DT != null) ? (java.sql.Timestamp) o.EXMP_DCN_DT.clone() : null;
    o.INS_AMT_APVL_DT = (o.INS_AMT_APVL_DT != null) ? (java.sql.Timestamp) o.INS_AMT_APVL_DT.clone() : null;
    o.COV_INS_BGN_DT = (o.COV_INS_BGN_DT != null) ? (java.sql.Timestamp) o.COV_INS_BGN_DT.clone() : null;
    o.COV_INS_ED_DT = (o.COV_INS_ED_DT != null) ? (java.sql.Timestamp) o.COV_INS_ED_DT.clone() : null;
    o.EIH_LDG_DTM = (o.EIH_LDG_DTM != null) ? (java.sql.Timestamp) o.EIH_LDG_DTM.clone() : null;
  }

  public Map<String, Object> getFieldMap() {
    Map<String, Object> __sqoop$field_map = new HashMap<String, Object>();
    __sqoop$field_map.put("CLOG_DT", this.CLOG_DT);
    __sqoop$field_map.put("CLM_ID", this.CLM_ID);
    __sqoop$field_map.put("COV_INS_AMT_ID", this.COV_INS_AMT_ID);
    __sqoop$field_map.put("CSS_COV_INS_AMT_ID", this.CSS_COV_INS_AMT_ID);
    __sqoop$field_map.put("CLADJ_CLOG_DIV_CD", this.CLADJ_CLOG_DIV_CD);
    __sqoop$field_map.put("INS_ITMS_DIV_CD", this.INS_ITMS_DIV_CD);
    __sqoop$field_map.put("BZPLN_PD_CTG_CD", this.BZPLN_PD_CTG_CD);
    __sqoop$field_map.put("PREBL_MNG_PD_CTG_CD", this.PREBL_MNG_PD_CTG_CD);
    __sqoop$field_map.put("SAL_PD_CD", this.SAL_PD_CD);
    __sqoop$field_map.put("UNT_PD_CD", this.UNT_PD_CD);
    __sqoop$field_map.put("ACD_NO_YY", this.ACD_NO_YY);
    __sqoop$field_map.put("ACD_NO_SEQ", this.ACD_NO_SEQ);
    __sqoop$field_map.put("ACD_RCT_ID", this.ACD_RCT_ID);
    __sqoop$field_map.put("ACD_RCT_HIS_SEQ", this.ACD_RCT_HIS_SEQ);
    __sqoop$field_map.put("RCT_DTM", this.RCT_DTM);
    __sqoop$field_map.put("RCT_DT", this.RCT_DT);
    __sqoop$field_map.put("ACD_DTM", this.ACD_DTM);
    __sqoop$field_map.put("ACD_DT", this.ACD_DT);
    __sqoop$field_map.put("HOLI_YN", this.HOLI_YN);
    __sqoop$field_map.put("OD_ACD_NO", this.OD_ACD_NO);
    __sqoop$field_map.put("OTHCO_ACD_NO", this.OTHCO_ACD_NO);
    __sqoop$field_map.put("ACD_WKD_CD", this.ACD_WKD_CD);
    __sqoop$field_map.put("CITY_NATL_CD", this.CITY_NATL_CD);
    __sqoop$field_map.put("ACD_PLC_ZPCD", this.ACD_PLC_ZPCD);
    __sqoop$field_map.put("ACD_PLC_ZPCD_SNO", this.ACD_PLC_ZPCD_SNO);
    __sqoop$field_map.put("ACD_PLC_ZPCD_ADR", this.ACD_PLC_ZPCD_ADR);
    __sqoop$field_map.put("ACD_PLC_DTL_ADR_CON", this.ACD_PLC_DTL_ADR_CON);
    __sqoop$field_map.put("LTT_DIV_CD", this.LTT_DIV_CD);
    __sqoop$field_map.put("LTT_COO_DG", this.LTT_COO_DG);
    __sqoop$field_map.put("LTT_COO_MI", this.LTT_COO_MI);
    __sqoop$field_map.put("LTT_COO_SS", this.LTT_COO_SS);
    __sqoop$field_map.put("LNT_DIV_CD", this.LNT_DIV_CD);
    __sqoop$field_map.put("LNT_COO_DG", this.LNT_COO_DG);
    __sqoop$field_map.put("LNT_COO_MI", this.LNT_COO_MI);
    __sqoop$field_map.put("LNT_COO_SS", this.LNT_COO_SS);
    __sqoop$field_map.put("ACD_CTR_ID", this.ACD_CTR_ID);
    __sqoop$field_map.put("ACD_CTR_HIS_SEQ", this.ACD_CTR_HIS_SEQ);
    __sqoop$field_map.put("POL_NO", this.POL_NO);
    __sqoop$field_map.put("CTR_ENDR_NO", this.CTR_ENDR_NO);
    __sqoop$field_map.put("RTRO_ENDR_NO", this.RTRO_ENDR_NO);
    __sqoop$field_map.put("ENDR_HIS_STD_NO", this.ENDR_HIS_STD_NO);
    __sqoop$field_map.put("POLHD_CUS_ID", this.POLHD_CUS_ID);
    __sqoop$field_map.put("POLHD_NM", this.POLHD_NM);
    __sqoop$field_map.put("CTR_STAT_CD", this.CTR_STAT_CD);
    __sqoop$field_map.put("CTR_STAT_DTL_CD", this.CTR_STAT_DTL_CD);
    __sqoop$field_map.put("INS_BGN_DT", this.INS_BGN_DT);
    __sqoop$field_map.put("INS_ED_DT", this.INS_ED_DT);
    __sqoop$field_map.put("SBCP_DT", this.SBCP_DT);
    __sqoop$field_map.put("ACP_SH_DIV_CD", this.ACP_SH_DIV_CD);
    __sqoop$field_map.put("MRIN_PD_DIV_CD", this.MRIN_PD_DIV_CD);
    __sqoop$field_map.put("MA_INSPE_CUS_ID", this.MA_INSPE_CUS_ID);
    __sqoop$field_map.put("MA_INSPE_NM", this.MA_INSPE_NM);
    __sqoop$field_map.put("ORIG_RTRC_DIV_CD", this.ORIG_RTRC_DIV_CD);
    __sqoop$field_map.put("PLR_STUP_YN", this.PLR_STUP_YN);
    __sqoop$field_map.put("TRT_HDQT_ORG_CD", this.TRT_HDQT_ORG_CD);
    __sqoop$field_map.put("TRT_BCH_ORG_CD", this.TRT_BCH_ORG_CD);
    __sqoop$field_map.put("TRT_BRCH_ORG_CD", this.TRT_BRCH_ORG_CD);
    __sqoop$field_map.put("TRTPE_ORG_ID", this.TRTPE_ORG_ID);
    __sqoop$field_map.put("TRTPE_ORG_CD", this.TRTPE_ORG_CD);
    __sqoop$field_map.put("CLM_TP_CD", this.CLM_TP_CD);
    __sqoop$field_map.put("DSS_CD_YY", this.DSS_CD_YY);
    __sqoop$field_map.put("DSS_CD_SEQ", this.DSS_CD_SEQ);
    __sqoop$field_map.put("CLM_STAT_CD", this.CLM_STAT_CD);
    __sqoop$field_map.put("ACD_CAUS_LCTG_CD", this.ACD_CAUS_LCTG_CD);
    __sqoop$field_map.put("ACD_CAUS_MCTG_CD", this.ACD_CAUS_MCTG_CD);
    __sqoop$field_map.put("ACD_CAUS_SCTG_CD", this.ACD_CAUS_SCTG_CD);
    __sqoop$field_map.put("ACD_CAUS_DCTG_CD", this.ACD_CAUS_DCTG_CD);
    __sqoop$field_map.put("ACD_CAUS_DCTG2_CD", this.ACD_CAUS_DCTG2_CD);
    __sqoop$field_map.put("COMS_PART_ORG_ID", this.COMS_PART_ORG_ID);
    __sqoop$field_map.put("COMS_PART_ORG_CD", this.COMS_PART_ORG_CD);
    __sqoop$field_map.put("COMS_TEM_ORG_ID", this.COMS_TEM_ORG_ID);
    __sqoop$field_map.put("COMS_TEM_ORG_CD", this.COMS_TEM_ORG_CD);
    __sqoop$field_map.put("COMS_CHRPE_ORG_ID", this.COMS_CHRPE_ORG_ID);
    __sqoop$field_map.put("CPIC_ORG_CD", this.CPIC_ORG_CD);
    __sqoop$field_map.put("CNCLU_DT", this.CNCLU_DT);
    __sqoop$field_map.put("EXMP_DCN_DT", this.EXMP_DCN_DT);
    __sqoop$field_map.put("DAM_DGR_CD", this.DAM_DGR_CD);
    __sqoop$field_map.put("AT_ISP_YN", this.AT_ISP_YN);
    __sqoop$field_map.put("ACD_CTR_OBJ_ID", this.ACD_CTR_OBJ_ID);
    __sqoop$field_map.put("ACD_CTR_OBJ_HIS_SEQ", this.ACD_CTR_OBJ_HIS_SEQ);
    __sqoop$field_map.put("ACD_OBJ_DIV_CD", this.ACD_OBJ_DIV_CD);
    __sqoop$field_map.put("ACD_OBJ_ID", this.ACD_OBJ_ID);
    __sqoop$field_map.put("DAM_ORD", this.DAM_ORD);
    __sqoop$field_map.put("CTR_OBJ_ID", this.CTR_OBJ_ID);
    __sqoop$field_map.put("CTR_OBJ_ADR_ID", this.CTR_OBJ_ADR_ID);
    __sqoop$field_map.put("OBJ_TP_CD", this.OBJ_TP_CD);
    __sqoop$field_map.put("DMPE_CUS_ID", this.DMPE_CUS_ID);
    __sqoop$field_map.put("DMPO_NM", this.DMPO_NM);
    __sqoop$field_map.put("PVDS_YN", this.PVDS_YN);
    __sqoop$field_map.put("TCTR_DMPE_JOB_GRD_CD", this.TCTR_DMPE_JOB_GRD_CD);
    __sqoop$field_map.put("TCTR_DMPE_JOB_CD", this.TCTR_DMPE_JOB_CD);
    __sqoop$field_map.put("TACD_DMPE_JOB_GRD_CD", this.TACD_DMPE_JOB_GRD_CD);
    __sqoop$field_map.put("TACD_DMPE_JOB_CD", this.TACD_DMPE_JOB_CD);
    __sqoop$field_map.put("OWNR_NM", this.OWNR_NM);
    __sqoop$field_map.put("DMPE_AGE", this.DMPE_AGE);
    __sqoop$field_map.put("TNG_DIV_CD", this.TNG_DIV_CD);
    __sqoop$field_map.put("OBJ_GRD_CD", this.OBJ_GRD_CD);
    __sqoop$field_map.put("OPN_JBCL_CD", this.OPN_JBCL_CD);
    __sqoop$field_map.put("OPJB_NM", this.OPJB_NM);
    __sqoop$field_map.put("OBJ_CD", this.OBJ_CD);
    __sqoop$field_map.put("DMOB_LCTG_CD", this.DMOB_LCTG_CD);
    __sqoop$field_map.put("DMOB_MCTG_CD", this.DMOB_MCTG_CD);
    __sqoop$field_map.put("DMOB_SCTG_CD", this.DMOB_SCTG_CD);
    __sqoop$field_map.put("DMOB_TPIDS_LCTG_CD", this.DMOB_TPIDS_LCTG_CD);
    __sqoop$field_map.put("DMOB_TPIDS_MCTG_CD", this.DMOB_TPIDS_MCTG_CD);
    __sqoop$field_map.put("DMOB_TPIDS_SCTG_CD", this.DMOB_TPIDS_SCTG_CD);
    __sqoop$field_map.put("DMOB_TPIDS_DCTG_CD", this.DMOB_TPIDS_DCTG_CD);
    __sqoop$field_map.put("MCSH_FSHBT_DIV_CD", this.MCSH_FSHBT_DIV_CD);
    __sqoop$field_map.put("SHAG", this.SHAG);
    __sqoop$field_map.put("SHP_TP_CD", this.SHP_TP_CD);
    __sqoop$field_map.put("SHP_CD", this.SHP_CD);
    __sqoop$field_map.put("ARCRF_REG_NO", this.ARCRF_REG_NO);
    __sqoop$field_map.put("CARG_TRN_ITM_CD", this.CARG_TRN_ITM_CD);
    __sqoop$field_map.put("DTH_YN", this.DTH_YN);
    __sqoop$field_map.put("AFOBS_YN", this.AFOBS_YN);
    __sqoop$field_map.put("HSP_MD_EXP_YN", this.HSP_MD_EXP_YN);
    __sqoop$field_map.put("GHR_MD_EXP_YN", this.GHR_MD_EXP_YN);
    __sqoop$field_map.put("PSC_MD_EXP_YN", this.PSC_MD_EXP_YN);
    __sqoop$field_map.put("HSP_DDPY_YN", this.HSP_DDPY_YN);
    __sqoop$field_map.put("LAST_DGN_YN", this.LAST_DGN_YN);
    __sqoop$field_map.put("SROP_YN", this.SROP_YN);
    __sqoop$field_map.put("EXP_YN", this.EXP_YN);
    __sqoop$field_map.put("SROP_BDW_YN", this.SROP_BDW_YN);
    __sqoop$field_map.put("OS_ID", this.OS_ID);
    __sqoop$field_map.put("OS_HIS_SEQ", this.OS_HIS_SEQ);
    __sqoop$field_map.put("OS_SEQ", this.OS_SEQ);
    __sqoop$field_map.put("OS_DIV_CD", this.OS_DIV_CD);
    __sqoop$field_map.put("DCN_ID", this.DCN_ID);
    __sqoop$field_map.put("DCN_HIS_SEQ", this.DCN_HIS_SEQ);
    __sqoop$field_map.put("DCN_SEQ", this.DCN_SEQ);
    __sqoop$field_map.put("DCN_DIV_CD", this.DCN_DIV_CD);
    __sqoop$field_map.put("CNCLU_ID", this.CNCLU_ID);
    __sqoop$field_map.put("CNCLU_HIS_SEQ", this.CNCLU_HIS_SEQ);
    __sqoop$field_map.put("CNCLU_DIV_CD", this.CNCLU_DIV_CD);
    __sqoop$field_map.put("CNCLU_DATA_DIV_CD", this.CNCLU_DATA_DIV_CD);
    __sqoop$field_map.put("COV_INS_DATA_DIV_CD", this.COV_INS_DATA_DIV_CD);
    __sqoop$field_map.put("COV_INS_HIS_SEQ", this.COV_INS_HIS_SEQ);
    __sqoop$field_map.put("INS_AMT_APVL_DT", this.INS_AMT_APVL_DT);
    __sqoop$field_map.put("CSS_COV_INS_HIS_SEQ", this.CSS_COV_INS_HIS_SEQ);
    __sqoop$field_map.put("SPTPY_DIV_CD", this.SPTPY_DIV_CD);
    __sqoop$field_map.put("ISD_PCS_SEQ", this.ISD_PCS_SEQ);
    __sqoop$field_map.put("COV_CD", this.COV_CD);
    __sqoop$field_map.put("INS_AMT_EXT_EXP_DIV_CD", this.INS_AMT_EXT_EXP_DIV_CD);
    __sqoop$field_map.put("GURT_UNT_CD", this.GURT_UNT_CD);
    __sqoop$field_map.put("RSK_UNT_CD", this.RSK_UNT_CD);
    __sqoop$field_map.put("CLADJ_DIV_CTG_CD", this.CLADJ_DIV_CTG_CD);
    __sqoop$field_map.put("BAS_SIC_DIV_CD", this.BAS_SIC_DIV_CD);
    __sqoop$field_map.put("COV_INS_BGN_DT", this.COV_INS_BGN_DT);
    __sqoop$field_map.put("COV_INS_ED_DT", this.COV_INS_ED_DT);
    __sqoop$field_map.put("INSD_AMT_CUR_CD", this.INSD_AMT_CUR_CD);
    __sqoop$field_map.put("CUR_INSD_AMT", this.CUR_INSD_AMT);
    __sqoop$field_map.put("INSD_AMT", this.INSD_AMT);
    __sqoop$field_map.put("PPS_COMS_LM_AMT", this.PPS_COMS_LM_AMT);
    __sqoop$field_map.put("PACD_COMS_LM_AMT", this.PACD_COMS_LM_AMT);
    __sqoop$field_map.put("LDCO_CTR_BZAC_CD", this.LDCO_CTR_BZAC_CD);
    __sqoop$field_map.put("COI_CTR_BZAC_CD", this.COI_CTR_BZAC_CD);
    __sqoop$field_map.put("CSS_COV_INS_SEQ", this.CSS_COV_INS_SEQ);
    __sqoop$field_map.put("JNT_ACP_COV_INS_SEQ", this.JNT_ACP_COV_INS_SEQ);
    __sqoop$field_map.put("PRTC_RT", this.PRTC_RT);
    __sqoop$field_map.put("BRKR_CTR_BZAC_CD", this.BRKR_CTR_BZAC_CD);
    __sqoop$field_map.put("RINCO_CTR_BZAC_CD", this.RINCO_CTR_BZAC_CD);
    __sqoop$field_map.put("CLOG_APL_YN", this.CLOG_APL_YN);
    __sqoop$field_map.put("CSS_CTR_ID", this.CSS_CTR_ID);
    __sqoop$field_map.put("RINS_SH_DIV_CD", this.RINS_SH_DIV_CD);
    __sqoop$field_map.put("BRKR_CSS_RT", this.BRKR_CSS_RT);
    __sqoop$field_map.put("INSD_AMT_STD_CSS_RT", this.INSD_AMT_STD_CSS_RT);
    __sqoop$field_map.put("ACP_AMT_STD_CSS_RT", this.ACP_AMT_STD_CSS_RT);
    __sqoop$field_map.put("CUR_CD", this.CUR_CD);
    __sqoop$field_map.put("APL_EXRT", this.APL_EXRT);
    __sqoop$field_map.put("CSS_INS_AMT", this.CSS_INS_AMT);
    __sqoop$field_map.put("KWCV_CSS_INS_AMT", this.KWCV_CSS_INS_AMT);
    __sqoop$field_map.put("EIH_LDG_DTM", this.EIH_LDG_DTM);
    return __sqoop$field_map;
  }

  public void getFieldMap0(Map<String, Object> __sqoop$field_map) {
    __sqoop$field_map.put("CLOG_DT", this.CLOG_DT);
    __sqoop$field_map.put("CLM_ID", this.CLM_ID);
    __sqoop$field_map.put("COV_INS_AMT_ID", this.COV_INS_AMT_ID);
    __sqoop$field_map.put("CSS_COV_INS_AMT_ID", this.CSS_COV_INS_AMT_ID);
    __sqoop$field_map.put("CLADJ_CLOG_DIV_CD", this.CLADJ_CLOG_DIV_CD);
    __sqoop$field_map.put("INS_ITMS_DIV_CD", this.INS_ITMS_DIV_CD);
    __sqoop$field_map.put("BZPLN_PD_CTG_CD", this.BZPLN_PD_CTG_CD);
    __sqoop$field_map.put("PREBL_MNG_PD_CTG_CD", this.PREBL_MNG_PD_CTG_CD);
    __sqoop$field_map.put("SAL_PD_CD", this.SAL_PD_CD);
    __sqoop$field_map.put("UNT_PD_CD", this.UNT_PD_CD);
    __sqoop$field_map.put("ACD_NO_YY", this.ACD_NO_YY);
    __sqoop$field_map.put("ACD_NO_SEQ", this.ACD_NO_SEQ);
    __sqoop$field_map.put("ACD_RCT_ID", this.ACD_RCT_ID);
    __sqoop$field_map.put("ACD_RCT_HIS_SEQ", this.ACD_RCT_HIS_SEQ);
    __sqoop$field_map.put("RCT_DTM", this.RCT_DTM);
    __sqoop$field_map.put("RCT_DT", this.RCT_DT);
    __sqoop$field_map.put("ACD_DTM", this.ACD_DTM);
    __sqoop$field_map.put("ACD_DT", this.ACD_DT);
    __sqoop$field_map.put("HOLI_YN", this.HOLI_YN);
    __sqoop$field_map.put("OD_ACD_NO", this.OD_ACD_NO);
    __sqoop$field_map.put("OTHCO_ACD_NO", this.OTHCO_ACD_NO);
    __sqoop$field_map.put("ACD_WKD_CD", this.ACD_WKD_CD);
    __sqoop$field_map.put("CITY_NATL_CD", this.CITY_NATL_CD);
    __sqoop$field_map.put("ACD_PLC_ZPCD", this.ACD_PLC_ZPCD);
    __sqoop$field_map.put("ACD_PLC_ZPCD_SNO", this.ACD_PLC_ZPCD_SNO);
    __sqoop$field_map.put("ACD_PLC_ZPCD_ADR", this.ACD_PLC_ZPCD_ADR);
    __sqoop$field_map.put("ACD_PLC_DTL_ADR_CON", this.ACD_PLC_DTL_ADR_CON);
    __sqoop$field_map.put("LTT_DIV_CD", this.LTT_DIV_CD);
    __sqoop$field_map.put("LTT_COO_DG", this.LTT_COO_DG);
    __sqoop$field_map.put("LTT_COO_MI", this.LTT_COO_MI);
    __sqoop$field_map.put("LTT_COO_SS", this.LTT_COO_SS);
    __sqoop$field_map.put("LNT_DIV_CD", this.LNT_DIV_CD);
    __sqoop$field_map.put("LNT_COO_DG", this.LNT_COO_DG);
    __sqoop$field_map.put("LNT_COO_MI", this.LNT_COO_MI);
    __sqoop$field_map.put("LNT_COO_SS", this.LNT_COO_SS);
    __sqoop$field_map.put("ACD_CTR_ID", this.ACD_CTR_ID);
    __sqoop$field_map.put("ACD_CTR_HIS_SEQ", this.ACD_CTR_HIS_SEQ);
    __sqoop$field_map.put("POL_NO", this.POL_NO);
    __sqoop$field_map.put("CTR_ENDR_NO", this.CTR_ENDR_NO);
    __sqoop$field_map.put("RTRO_ENDR_NO", this.RTRO_ENDR_NO);
    __sqoop$field_map.put("ENDR_HIS_STD_NO", this.ENDR_HIS_STD_NO);
    __sqoop$field_map.put("POLHD_CUS_ID", this.POLHD_CUS_ID);
    __sqoop$field_map.put("POLHD_NM", this.POLHD_NM);
    __sqoop$field_map.put("CTR_STAT_CD", this.CTR_STAT_CD);
    __sqoop$field_map.put("CTR_STAT_DTL_CD", this.CTR_STAT_DTL_CD);
    __sqoop$field_map.put("INS_BGN_DT", this.INS_BGN_DT);
    __sqoop$field_map.put("INS_ED_DT", this.INS_ED_DT);
    __sqoop$field_map.put("SBCP_DT", this.SBCP_DT);
    __sqoop$field_map.put("ACP_SH_DIV_CD", this.ACP_SH_DIV_CD);
    __sqoop$field_map.put("MRIN_PD_DIV_CD", this.MRIN_PD_DIV_CD);
    __sqoop$field_map.put("MA_INSPE_CUS_ID", this.MA_INSPE_CUS_ID);
    __sqoop$field_map.put("MA_INSPE_NM", this.MA_INSPE_NM);
    __sqoop$field_map.put("ORIG_RTRC_DIV_CD", this.ORIG_RTRC_DIV_CD);
    __sqoop$field_map.put("PLR_STUP_YN", this.PLR_STUP_YN);
    __sqoop$field_map.put("TRT_HDQT_ORG_CD", this.TRT_HDQT_ORG_CD);
    __sqoop$field_map.put("TRT_BCH_ORG_CD", this.TRT_BCH_ORG_CD);
    __sqoop$field_map.put("TRT_BRCH_ORG_CD", this.TRT_BRCH_ORG_CD);
    __sqoop$field_map.put("TRTPE_ORG_ID", this.TRTPE_ORG_ID);
    __sqoop$field_map.put("TRTPE_ORG_CD", this.TRTPE_ORG_CD);
    __sqoop$field_map.put("CLM_TP_CD", this.CLM_TP_CD);
    __sqoop$field_map.put("DSS_CD_YY", this.DSS_CD_YY);
    __sqoop$field_map.put("DSS_CD_SEQ", this.DSS_CD_SEQ);
    __sqoop$field_map.put("CLM_STAT_CD", this.CLM_STAT_CD);
    __sqoop$field_map.put("ACD_CAUS_LCTG_CD", this.ACD_CAUS_LCTG_CD);
    __sqoop$field_map.put("ACD_CAUS_MCTG_CD", this.ACD_CAUS_MCTG_CD);
    __sqoop$field_map.put("ACD_CAUS_SCTG_CD", this.ACD_CAUS_SCTG_CD);
    __sqoop$field_map.put("ACD_CAUS_DCTG_CD", this.ACD_CAUS_DCTG_CD);
    __sqoop$field_map.put("ACD_CAUS_DCTG2_CD", this.ACD_CAUS_DCTG2_CD);
    __sqoop$field_map.put("COMS_PART_ORG_ID", this.COMS_PART_ORG_ID);
    __sqoop$field_map.put("COMS_PART_ORG_CD", this.COMS_PART_ORG_CD);
    __sqoop$field_map.put("COMS_TEM_ORG_ID", this.COMS_TEM_ORG_ID);
    __sqoop$field_map.put("COMS_TEM_ORG_CD", this.COMS_TEM_ORG_CD);
    __sqoop$field_map.put("COMS_CHRPE_ORG_ID", this.COMS_CHRPE_ORG_ID);
    __sqoop$field_map.put("CPIC_ORG_CD", this.CPIC_ORG_CD);
    __sqoop$field_map.put("CNCLU_DT", this.CNCLU_DT);
    __sqoop$field_map.put("EXMP_DCN_DT", this.EXMP_DCN_DT);
    __sqoop$field_map.put("DAM_DGR_CD", this.DAM_DGR_CD);
    __sqoop$field_map.put("AT_ISP_YN", this.AT_ISP_YN);
    __sqoop$field_map.put("ACD_CTR_OBJ_ID", this.ACD_CTR_OBJ_ID);
    __sqoop$field_map.put("ACD_CTR_OBJ_HIS_SEQ", this.ACD_CTR_OBJ_HIS_SEQ);
    __sqoop$field_map.put("ACD_OBJ_DIV_CD", this.ACD_OBJ_DIV_CD);
    __sqoop$field_map.put("ACD_OBJ_ID", this.ACD_OBJ_ID);
    __sqoop$field_map.put("DAM_ORD", this.DAM_ORD);
    __sqoop$field_map.put("CTR_OBJ_ID", this.CTR_OBJ_ID);
    __sqoop$field_map.put("CTR_OBJ_ADR_ID", this.CTR_OBJ_ADR_ID);
    __sqoop$field_map.put("OBJ_TP_CD", this.OBJ_TP_CD);
    __sqoop$field_map.put("DMPE_CUS_ID", this.DMPE_CUS_ID);
    __sqoop$field_map.put("DMPO_NM", this.DMPO_NM);
    __sqoop$field_map.put("PVDS_YN", this.PVDS_YN);
    __sqoop$field_map.put("TCTR_DMPE_JOB_GRD_CD", this.TCTR_DMPE_JOB_GRD_CD);
    __sqoop$field_map.put("TCTR_DMPE_JOB_CD", this.TCTR_DMPE_JOB_CD);
    __sqoop$field_map.put("TACD_DMPE_JOB_GRD_CD", this.TACD_DMPE_JOB_GRD_CD);
    __sqoop$field_map.put("TACD_DMPE_JOB_CD", this.TACD_DMPE_JOB_CD);
    __sqoop$field_map.put("OWNR_NM", this.OWNR_NM);
    __sqoop$field_map.put("DMPE_AGE", this.DMPE_AGE);
    __sqoop$field_map.put("TNG_DIV_CD", this.TNG_DIV_CD);
    __sqoop$field_map.put("OBJ_GRD_CD", this.OBJ_GRD_CD);
    __sqoop$field_map.put("OPN_JBCL_CD", this.OPN_JBCL_CD);
    __sqoop$field_map.put("OPJB_NM", this.OPJB_NM);
    __sqoop$field_map.put("OBJ_CD", this.OBJ_CD);
    __sqoop$field_map.put("DMOB_LCTG_CD", this.DMOB_LCTG_CD);
    __sqoop$field_map.put("DMOB_MCTG_CD", this.DMOB_MCTG_CD);
    __sqoop$field_map.put("DMOB_SCTG_CD", this.DMOB_SCTG_CD);
    __sqoop$field_map.put("DMOB_TPIDS_LCTG_CD", this.DMOB_TPIDS_LCTG_CD);
    __sqoop$field_map.put("DMOB_TPIDS_MCTG_CD", this.DMOB_TPIDS_MCTG_CD);
    __sqoop$field_map.put("DMOB_TPIDS_SCTG_CD", this.DMOB_TPIDS_SCTG_CD);
    __sqoop$field_map.put("DMOB_TPIDS_DCTG_CD", this.DMOB_TPIDS_DCTG_CD);
    __sqoop$field_map.put("MCSH_FSHBT_DIV_CD", this.MCSH_FSHBT_DIV_CD);
    __sqoop$field_map.put("SHAG", this.SHAG);
    __sqoop$field_map.put("SHP_TP_CD", this.SHP_TP_CD);
    __sqoop$field_map.put("SHP_CD", this.SHP_CD);
    __sqoop$field_map.put("ARCRF_REG_NO", this.ARCRF_REG_NO);
    __sqoop$field_map.put("CARG_TRN_ITM_CD", this.CARG_TRN_ITM_CD);
    __sqoop$field_map.put("DTH_YN", this.DTH_YN);
    __sqoop$field_map.put("AFOBS_YN", this.AFOBS_YN);
    __sqoop$field_map.put("HSP_MD_EXP_YN", this.HSP_MD_EXP_YN);
    __sqoop$field_map.put("GHR_MD_EXP_YN", this.GHR_MD_EXP_YN);
    __sqoop$field_map.put("PSC_MD_EXP_YN", this.PSC_MD_EXP_YN);
    __sqoop$field_map.put("HSP_DDPY_YN", this.HSP_DDPY_YN);
    __sqoop$field_map.put("LAST_DGN_YN", this.LAST_DGN_YN);
    __sqoop$field_map.put("SROP_YN", this.SROP_YN);
    __sqoop$field_map.put("EXP_YN", this.EXP_YN);
    __sqoop$field_map.put("SROP_BDW_YN", this.SROP_BDW_YN);
    __sqoop$field_map.put("OS_ID", this.OS_ID);
    __sqoop$field_map.put("OS_HIS_SEQ", this.OS_HIS_SEQ);
    __sqoop$field_map.put("OS_SEQ", this.OS_SEQ);
    __sqoop$field_map.put("OS_DIV_CD", this.OS_DIV_CD);
    __sqoop$field_map.put("DCN_ID", this.DCN_ID);
    __sqoop$field_map.put("DCN_HIS_SEQ", this.DCN_HIS_SEQ);
    __sqoop$field_map.put("DCN_SEQ", this.DCN_SEQ);
    __sqoop$field_map.put("DCN_DIV_CD", this.DCN_DIV_CD);
    __sqoop$field_map.put("CNCLU_ID", this.CNCLU_ID);
    __sqoop$field_map.put("CNCLU_HIS_SEQ", this.CNCLU_HIS_SEQ);
    __sqoop$field_map.put("CNCLU_DIV_CD", this.CNCLU_DIV_CD);
    __sqoop$field_map.put("CNCLU_DATA_DIV_CD", this.CNCLU_DATA_DIV_CD);
    __sqoop$field_map.put("COV_INS_DATA_DIV_CD", this.COV_INS_DATA_DIV_CD);
    __sqoop$field_map.put("COV_INS_HIS_SEQ", this.COV_INS_HIS_SEQ);
    __sqoop$field_map.put("INS_AMT_APVL_DT", this.INS_AMT_APVL_DT);
    __sqoop$field_map.put("CSS_COV_INS_HIS_SEQ", this.CSS_COV_INS_HIS_SEQ);
    __sqoop$field_map.put("SPTPY_DIV_CD", this.SPTPY_DIV_CD);
    __sqoop$field_map.put("ISD_PCS_SEQ", this.ISD_PCS_SEQ);
    __sqoop$field_map.put("COV_CD", this.COV_CD);
    __sqoop$field_map.put("INS_AMT_EXT_EXP_DIV_CD", this.INS_AMT_EXT_EXP_DIV_CD);
    __sqoop$field_map.put("GURT_UNT_CD", this.GURT_UNT_CD);
    __sqoop$field_map.put("RSK_UNT_CD", this.RSK_UNT_CD);
    __sqoop$field_map.put("CLADJ_DIV_CTG_CD", this.CLADJ_DIV_CTG_CD);
    __sqoop$field_map.put("BAS_SIC_DIV_CD", this.BAS_SIC_DIV_CD);
    __sqoop$field_map.put("COV_INS_BGN_DT", this.COV_INS_BGN_DT);
    __sqoop$field_map.put("COV_INS_ED_DT", this.COV_INS_ED_DT);
    __sqoop$field_map.put("INSD_AMT_CUR_CD", this.INSD_AMT_CUR_CD);
    __sqoop$field_map.put("CUR_INSD_AMT", this.CUR_INSD_AMT);
    __sqoop$field_map.put("INSD_AMT", this.INSD_AMT);
    __sqoop$field_map.put("PPS_COMS_LM_AMT", this.PPS_COMS_LM_AMT);
    __sqoop$field_map.put("PACD_COMS_LM_AMT", this.PACD_COMS_LM_AMT);
    __sqoop$field_map.put("LDCO_CTR_BZAC_CD", this.LDCO_CTR_BZAC_CD);
    __sqoop$field_map.put("COI_CTR_BZAC_CD", this.COI_CTR_BZAC_CD);
    __sqoop$field_map.put("CSS_COV_INS_SEQ", this.CSS_COV_INS_SEQ);
    __sqoop$field_map.put("JNT_ACP_COV_INS_SEQ", this.JNT_ACP_COV_INS_SEQ);
    __sqoop$field_map.put("PRTC_RT", this.PRTC_RT);
    __sqoop$field_map.put("BRKR_CTR_BZAC_CD", this.BRKR_CTR_BZAC_CD);
    __sqoop$field_map.put("RINCO_CTR_BZAC_CD", this.RINCO_CTR_BZAC_CD);
    __sqoop$field_map.put("CLOG_APL_YN", this.CLOG_APL_YN);
    __sqoop$field_map.put("CSS_CTR_ID", this.CSS_CTR_ID);
    __sqoop$field_map.put("RINS_SH_DIV_CD", this.RINS_SH_DIV_CD);
    __sqoop$field_map.put("BRKR_CSS_RT", this.BRKR_CSS_RT);
    __sqoop$field_map.put("INSD_AMT_STD_CSS_RT", this.INSD_AMT_STD_CSS_RT);
    __sqoop$field_map.put("ACP_AMT_STD_CSS_RT", this.ACP_AMT_STD_CSS_RT);
    __sqoop$field_map.put("CUR_CD", this.CUR_CD);
    __sqoop$field_map.put("APL_EXRT", this.APL_EXRT);
    __sqoop$field_map.put("CSS_INS_AMT", this.CSS_INS_AMT);
    __sqoop$field_map.put("KWCV_CSS_INS_AMT", this.KWCV_CSS_INS_AMT);
    __sqoop$field_map.put("EIH_LDG_DTM", this.EIH_LDG_DTM);
  }

  public void setField(String __fieldName, Object __fieldVal) {
    if (!setters.containsKey(__fieldName)) {
      throw new RuntimeException("No such field:"+__fieldName);
    }
    setters.get(__fieldName).setField(__fieldVal);
  }

}
