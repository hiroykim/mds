#!/bin/bash

if [ $# -eq 0 ]
then           
    ARGS=N    
else           
    ARGS=$1
fi             

NOW=$(date +"+%Y-%m-%d_%T")
SHLOG_DIR=/sqoopbin/scripts/etlpgm/cur_log
HISLOG_DIR=/sqoopbin/scripts/etlpgm/his_log

export HADOOP_OPTS=-Djava.security.egd=file:/dev/../dev/urandom
export ORACLE_BASE=/sw/oracle
export ORACLE_HOME=/sw/oracle/product/11.2.0.4/client_1
export LD_LIBRARY_PATH=/sw/oracle/product/11.2.0.4/client_1/lib:/sw/oracle/product/11.2.0.4/client_1/lib:
export PATH=/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/usr/lib64/qt-3.3/bin:/usr/hdp/3.0.0.0-1634/spark2/bin/:/var/opt/node/bin/:/opt/maven/bin:/usr/local/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/home/hdpapp/workspace/data-science-at-the-command-line/tools:/home/hdpapp/.local/bin:/home/hdpapp/bin
export TNS_ADMIN=/sw/oracle/product/11.2.0.4/client_1/network/admin
export ORACLE_SID=DBEDWP2
export NLS_LANG=American_America.KO16MSWIN949

#----------------------------------------------------#
# 작업내용 : THDDH_LNMVADJTCP 테이블 sqoop 복제 작업
# 작업주기 :  
#----------------------------------------------------#

    echo " "
    echo "*-----------[ THDDH_LNMVADJTCP.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_LNMVADJTCP.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`  >  ${SHLOG_DIR}/THDDH_LNMVADJTCP.shlog
PART=$1

#----------------------------------------------------#
# 테이블별 전체 데이터를 받아 오는 부분
#----------------------------------------------------#
    /usr/bin/hadoop fs -rm -r -f  /tmp2/STG_THDDH_LNMVADJTCP  >> ${SHLOG_DIR}/THDDH_LNMVADJTCP.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.STG_THDDH_LNMVADJTCP ; " >> ${SHLOG_DIR}/THDDH_LNMVADJTCP.shlog 2>&1 &&
    /usr/hdp/3.0.0.0-1634/sqoop/bin/sqoop import -D mapred.child.java.opts="-Djava.security.egd=file:/dev/../dev/urandom" \
    --connect jdbc:oracle:thin:EDWHADOOP/wjdqhrP\!23@10.91.41.172:12560:DBEDWP2 \
    --username  EDWHADOOP \
    --password wjdqhrP\!23 \
    --query "SELECT /*+ FULL(THDDH_LNMVADJTCP) */ REPLACE(REPLACE(STD_YYMM,CHR(13),''),CHR(10),'') STD_YYMM
, REPLACE(REPLACE(POL_NO,CHR(13),''),CHR(10),'') POL_NO
, REPLACE(REPLACE(COV_CD,CHR(13),''),CHR(10),'') COV_CD
, REPLACE(REPLACE(CTR_OBJ_ID,CHR(13),''),CHR(10),'') CTR_OBJ_ID
, ACRSL_ORIG_PREM
, ACRSL_RPM
, ACRSL_ORIG_DMG_AMT
, ACRSL_CSS_PREM
, ACRSL_CSS_DMG_AMT
, ACRSL_PO_ETPY_FEE
, ACRSL_NCT_RSLFE
, ACRSL_ETC_NPTPY_FEE
, ACRSL_MNCL_ETPY_FEE
, ACRSL_CRD_FEE
, ACRSL_EXPR_RFD_AMT
, ACRSL_HFWY_RFD_AMT
, PFR3_ACRSL_CLAT
, PFR4_ACRSL_CLAT
, ACRSL_ANN_PAY_AMT
, ACRSL_CAFL_AMT
, SUPP_ORIG_PREM
, DMSP_ORIG_PREM
, SUPP_RSK_PREM
, SUPP_ORIG_DMG_AMT
, SUPP_CSS_PREM
, SUPP_CSS_DMG_AMT
, SUPP_PO_ETPY_FEE
, SUPP_NCT_RSLFE
, SUPP_ETC_NPTPY_FEE
, SUPP_MNCL_ETPY_FEE
, SUPP_CRD_FEE
, SUPP_EXPR_RFD_AMT
, SUPP_HFWY_RFD_AMT
, PFR3_SUPP_CLAT
, PFR4_SUPP_CLAT
, SUPP_ANN_PAY_AMT
, SUPP_CAFL_AMT
, COR_SUPP_ORIG_DMG_AMT
, COR_SUPP_CSS_DMG_AMT
, ACRSL_TMTD_RDY_AMT
, SUPP_TMTD_RDY_AMT
, IDAR_TMTD_RDY_AMT
, ICDC_SUPP_TMTD_RDY_AMT
, ACRSL_FUTR_WRTH_AMT
, SUPP_FUTR_WRTH_AMT
, ACRSL_SVV_CRD_ETPY_FEE
, SUPP_SVV_CRD_ETPY_FEE
, ACRSL_SVV_CCEA
, SUPP_SVV_CCEA
, RSK_EXP
, NCT_KMV_AMT
, NCT_CCEA
, NCT_CRD_ETPY_FEE
, NCT_RSK_EXP
, TRSPC_PFAT
, TRSPC_CCEA
, TRSPC_CRD_ETPY_PFAT
, TRSPC_RSK_EXP_PFAT
, TRSVA_PFAT
, THMM_ORIG_TRSVA_CCEA
, THMM_CSS_TRSVA_CCEA
, THMM_TRSVA_CRD_PFAT
, SVV_TRSVA_CCNR_PFAT
, SVV_TRSVA_CRD_PFAT
, TRSVA_RSK_EXP_PFAT
, CNC_PFAT
, CNC_CCEA
, CNC_ETPY_CRD_PFAT
, CNC_RSK_EXP_PFAT
, ESCN_PFAT
, ESCN_CCEA
, ESCN_CRD_ETPY_PFAT
, ESCN_RSK_EXP_PFAT
, DGRT_SVSA_PFAT
, ORIG_DGRT_SVSA_PFAT
, CSS_DGRT_SVSA_PFAT
, TMN_RT_PFAT
, DGRT_PFAT
, SUPP_CHNG_PFAT
, SVSA_PFAT
, DC_VS_XPT_INTR_PFAT
, PSCT_PFAT
, KMV_PFAT
, ACRSL_ADVEXP
, SUPP_ADVEXP
, ACRSL_ETPY_CRD_EXP
, SUPP_ETPY_CRD_EXP
, REPLACE(REPLACE(CTR_STAT_CD,CHR(13),''),CHR(10),'') CTR_STAT_CD
, YR_CNVS_PREM
, ACRSL_REM_YR_CNVS_PREM
, SUPP_REM_YR_CNVS_PREM
, SUPP_SVV_RT
, REPLACE(REPLACE(SMRZ_ORG_CD,CHR(13),''),CHR(10),'') SMRZ_ORG_CD
, REPLACE(REPLACE(BZ_SB_ADT_CMTT_ORG_CD,CHR(13),''),CHR(10),'') BZ_SB_ADT_CMTT_ORG_CD
, REPLACE(REPLACE(HDQT_ORG_CD,CHR(13),''),CHR(10),'') HDQT_ORG_CD
, REPLACE(REPLACE(BRCH_ORG_CD,CHR(13),''),CHR(10),'') BRCH_ORG_CD
, REPLACE(REPLACE(BCH_ORG_CD,CHR(13),''),CHR(10),'') BCH_ORG_CD
, REPLACE(REPLACE(TRTPE_ORG_CD,CHR(13),''),CHR(10),'') TRTPE_ORG_CD
, REPLACE(REPLACE(AGC_BROF_ORG_CD,CHR(13),''),CHR(10),'') AGC_BROF_ORG_CD
, REPLACE(REPLACE(AGC_PLNR_ORG_CD,CHR(13),''),CHR(10),'') AGC_PLNR_ORG_CD
, SBCP_DT
, EIH_LDG_DTM
, RCHG_PFAT
, RCHG_CCEA
, RCHG_CRD_ETPY_PFAT
, RCHG_RSK_EXP_PFAT
, ACRSL_NPO_RDMP_AMT
, SNPO_RDMP_AMT
, FEE_RT_SVSA_AMT
, FEE_RT_PFAT FROM THDDH_LNMVADJTCP
                       WHERE \$CONDITIONS 
			AND STD_YYMM = '${PART}'"\
    --m 8 \
    --boundary-query "SELECT 0, 7 FROM DUAL"\
    --split-by "ORA_HASH(POL_NO, 7)"\
    --target-dir /tmp2/STG_THDDH_LNMVADJTCP \
    --hive-import \
    --external-table-dir hdfs:///tmp2/temp_tbl/STG_THDDH_LNMVADJTCP \
    --hive-overwrite \
    --hive-table DEFAULT.STG_THDDH_LNMVADJTCP  >> ${SHLOG_DIR}/THDDH_LNMVADJTCP.shlog 2>&1 &&

#----------------------------------------------------#
# Hadoop 원본테이블에 변경분 최종 적용
#----------------------------------------------------#
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_LNMVADJTCP_TMP ; " >> ${SHLOG_DIR}/THDDH_LNMVADJTCP.shlog 2>&1 &&
    /usr/bin/hive -e "CREATE EXTERNAL TABLE MERITZ.THDDH_LNMVADJTCP_TMP STORED AS PARQUET TBLPROPERTIES ('PARQUET.COMPRESS'='SNAPPY') AS
                                SELECT *
                                FROM DEFAULT.STG_THDDH_LNMVADJTCP ;" >> ${SHLOG_DIR}/THDDH_LNMVADJTCP.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.STG_THDDH_LNMVADJTCP ;" >> ${SHLOG_DIR}/THDDH_LNMVADJTCP.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_LNMVADJTCP_${PART} ;" >> ${SHLOG_DIR}/THDDH_LNMVADJTCP.shlog 2>&1 &&
# 위의 파티션 드롭 코드는 아래 파일삭제를 전제하고 있음 
# external table은 drop시 자동삭제가 되지 않기 때문에 꼬였었음 181129 수정 
    /usr/bin/hadoop fs -rm -r -f  /warehouse/tablespace/external/hive/meritz.db/thddh_lnmvadjtcp_${PART}  >> ${SHLOG_DIR}/THDDH_LNMVADJTCP.shlog 2>&1 &&
    /usr/bin/hive -e "ALTER TABLE MERITZ.THDDH_LNMVADJTCP_TMP RENAME TO MERITZ.THDDH_LNMVADJTCP_${PART} ;" >> ${SHLOG_DIR}/THDDH_LNMVADJTCP.shlog 2>&1 &&
# external table 이 alter문 동작 다른 문제로 아래 과정이 필요해짐 
    /usr/bin/hive -e "ALTER TABLE MERITZ.THDDH_LNMVADJTCP_${PART} SET LOCATION 'hdfs:///warehouse/tablespace/external/hive/meritz.db/thddh_lnmvadjtcp_${PART}' ;" >> ${SHLOG_DIR}/THDDH_LNMVADJTCP.shlog 2>&1 &&
    /usr/bin/hdfs dfs -mv /warehouse/tablespace/external/hive/meritz.db/thddh_lnmvadjtcp_tmp /warehouse/tablespace/external/hive/meritz.db/thddh_lnmvadjtcp_${PART} >> ${SHLOG_DIR}/THDDH_LNMVADJTCP.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_LNMVADJTCP_TMP ;" >> ${SHLOG_DIR}/THDDH_LNMVADJTCP.shlog 2>&1 

if [ $? -ne 0 ]
then             
    echo "*-----------[ THDDH_LNMVADJTCP.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/THDDH_LNMVADJTCP.shlog"
    echo "*-----------[ THDDH_LNMVADJTCP.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/THDDH_LNMVADJTCP.shlog"  >>  ${SHLOG_DIR}/THDDH_LNMVADJTCP.shlog
    echo "*-----------[ THDDH_LNMVADJTCP.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_LNMVADJTCP.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/THDDH_LNMVADJTCP.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/THDDH_LNMVADJTCP.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/THDDH_LNMVADJTCP.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/THDDH_LNMVADJTCP.shlog /sqoopbin/scripts/etlpgm/his_log/THDDH_LNMVADJTCP_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  THDDH_LNMVADJTCP.sh cmd command error !! ***
    fi               

    exit -1      

else             
    echo "*-----------[ THDDH_LNMVADJTCP.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_LNMVADJTCP.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/THDDH_LNMVADJTCP.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/THDDH_LNMVADJTCP.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/THDDH_LNMVADJTCP.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/THDDH_LNMVADJTCP.shlog /sqoopbin/scripts/etlpgm/his_log/THDDH_LNMVADJTCP_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  THDDH_LNMVADJTCP.sh cmd command error !! ***
        exit -1      
    else             
        exit 0       
    fi               
fi               
