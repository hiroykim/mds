#!/bin/bash

/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/TMLMB_LNCTCOVCLG_P.sh 201712
/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/TMLMB_LNCTCOVCLG_P.sh 201711
/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/TMLMB_LNCTCOVCLG_P.sh 201710
/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/TMLMB_LNCTCOVCLG_P.sh 201709
/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/TMLMB_LNCTCOVCLG_P.sh 201708
/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/TMLMB_LNCTCOVCLG_P.sh 201707
/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/TMLMB_LNCTCOVCLG_P.sh 201706
/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/TMLMB_LNCTCOVCLG_P.sh 201705
/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/TMLMB_LNCTCOVCLG_P.sh 201704
/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/TMLMB_LNCTCOVCLG_P.sh 201703
/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/TMLMB_LNCTCOVCLG_P.sh 201702
/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/TMLMB_LNCTCOVCLG_P.sh 201701

/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/TMLMB_LNCTCOVCLG_P.sh 201612
/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/TMLMB_LNCTCOVCLG_P.sh 201611
/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/TMLMB_LNCTCOVCLG_P.sh 201610
/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/TMLMB_LNCTCOVCLG_P.sh 201609
/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/TMLMB_LNCTCOVCLG_P.sh 201608
/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/TMLMB_LNCTCOVCLG_P.sh 201607
/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/TMLMB_LNCTCOVCLG_P.sh 201606
/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/TMLMB_LNCTCOVCLG_P.sh 201605
/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/TMLMB_LNCTCOVCLG_P.sh 201604
/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/TMLMB_LNCTCOVCLG_P.sh 201603
/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/TMLMB_LNCTCOVCLG_P.sh 201602
/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/TMLMB_LNCTCOVCLG_P.sh 201601
