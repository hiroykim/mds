#!/bin/bash

if [ $# -eq 0 ]
then           
    ARGS=N    
else           
    ARGS=$1
fi             

NOW=$(date +"+%Y-%m-%d_%T")
SHLOG_DIR=/sqoopbin/scripts/etlpgm/cur_log
HISLOG_DIR=/sqoopbin/scripts/etlpgm/his_log

export HADOOP_OPTS=-Djava.security.egd=file:/dev/../dev/urandom
export ORACLE_BASE=/sw/oracle
export ORACLE_HOME=/sw/oracle/product/11.2.0.4/client_1
export LD_LIBRARY_PATH=/sw/oracle/product/11.2.0.4/client_1/lib:/sw/oracle/product/11.2.0.4/client_1/lib:
export PATH=/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/usr/lib64/qt-3.3/bin:/usr/hdp/3.0.0.0-1634/spark2/bin/:/var/opt/node/bin/:/opt/maven/bin:/usr/local/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/home/hdpapp/workspace/data-science-at-the-command-line/tools:/home/hdpapp/.local/bin:/home/hdpapp/bin
export TNS_ADMIN=/sw/oracle/product/11.2.0.4/client_1/network/admin
export ORACLE_SID=DBEDWP2
export NLS_LANG=American_America.KO16MSWIN949

#----------------------------------------------------#
# 작업내용 : THDDH_TCTRDYLCTR 테이블 sqoop 복제 작업
# 작업주기 :  
#----------------------------------------------------#

    echo " "
    echo "*-----------[ THDDH_TCTRDYLCTR.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TCTRDYLCTR.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`  >  ${SHLOG_DIR}/THDDH_TCTRDYLCTR.shlog
PART=$1

#----------------------------------------------------#
# 테이블별 전체 데이터를 받아 오는 부분
#----------------------------------------------------#
    /usr/bin/hadoop fs -rm -r -f  /tmp2/STG_THDDH_TCTRDYLCTR  >> ${SHLOG_DIR}/THDDH_TCTRDYLCTR.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.STG_THDDH_TCTRDYLCTR ; " >> ${SHLOG_DIR}/THDDH_TCTRDYLCTR.shlog 2>&1 &&
    /usr/hdp/3.0.0.0-1634/sqoop/bin/sqoop import -D mapred.child.java.opts="-Djava.security.egd=file:/dev/../dev/urandom" \
    --connect jdbc:oracle:thin:EDWHADOOP/wjdqhrP\!23@10.91.41.172:12560:DBEDWP2 \
    --username  EDWHADOOP \
    --password wjdqhrP\!23 \
    --query "SELECT /*+ FULL(THDDH_TCTRDYLCTR) */ REPLACE(REPLACE(CLOG_YYMM,CHR(13),''),CHR(10),'') CLOG_YYMM
, REPLACE(REPLACE(CTR_ID,CHR(13),''),CHR(10),'') CTR_ID
, REPLACE(REPLACE(CTR_STAT_CD1,CHR(13),''),CHR(10),'') CTR_STAT_CD1
, REPLACE(REPLACE(POL_NO,CHR(13),''),CHR(10),'') POL_NO
, REPLACE(REPLACE(PD_CD,CHR(13),''),CHR(10),'') PD_CD
, REPLACE(REPLACE(LAST_PY_YYMM,CHR(13),''),CHR(10),'') LAST_PY_YYMM
, LAST_PY_TMS
, TT_PY_PREM
, INS_BGN_DT
, INS_ED_DT
, PY_ST_DT
, PY_ED_DT
, SBCP_DT
, LPS_DT
, REVV_DT
, REPLACE(REPLACE(CTR_STAT_CD,CHR(13),''),CHR(10),'') CTR_STAT_CD
, REPLACE(REPLACE(CTR_STAT_DTL_CD,CHR(13),''),CHR(10),'') CTR_STAT_DTL_CD
, REPLACE(REPLACE(CTR_STAT_DTL_CD1,CHR(13),''),CHR(10),'') CTR_STAT_DTL_CD1
, REPLACE(REPLACE(INS_PRD_TP_CD,CHR(13),''),CHR(10),'') INS_PRD_TP_CD
, REPLACE(REPLACE(PY_PRD_TP_CD,CHR(13),''),CHR(10),'') PY_PRD_TP_CD
, INS_PRD
, PY_PRD
, REPLACE(REPLACE(PY_CYC_CD,CHR(13),''),CHR(10),'') PY_CYC_CD
, REPLACE(REPLACE(CLF_DIV_CD,CHR(13),''),CHR(10),'') CLF_DIV_CD
, REPLACE(REPLACE(GRUP_DIV_CD,CHR(13),''),CHR(10),'') GRUP_DIV_CD
, REPLACE(REPLACE(INS_SBC_SH_CD,CHR(13),''),CHR(10),'') INS_SBC_SH_CD
, REPLACE(REPLACE(INS_SBC_TP_CD,CHR(13),''),CHR(10),'') INS_SBC_TP_CD
, ANN_PAY_ST_DT
, INS_AGE
, FULL_AGE
, PY_ED_AGE
, INS_ED_AGE
, REPLACE(REPLACE(MOM_PD_CD,CHR(13),''),CHR(10),'') MOM_PD_CD
, APL_PREM
, SLZ_PREM
, ELP_YR_NUM
, ELP_MM_NUM
, TT_ELP_MM_NUM
, UNPSS_MM_NUM
, CMPT_STD_DT
, PRPY_TIMS
, EXPC_LPS_DT
, PRDCH_ENDR_HIS_STD_NO
, PREM_ENDR_HIS_STD_NO
, XPT_ACQ_EXP_TAMT
, STND_ACQ_EXP_TAMT
, GURT_BAS_UNRPD_ACQ_EXP
, GURT_SIC_UNRPD_ACQ_EXP
, ACU_UNRPD_ACQ_EXP
, GURT_UNPSS_PREM
, LPS_IAMT
, PRPY_RDY_AMT
, PVCTR_RDY_AMT
, AGURT_BAS_NPTD_RDY_AMT
, GURT_BAS_NPTD_RDY_AMT
, AGURT_SIC_NPTD_RDY_AMT
, GURT_SIC_NPTD_RDY_AMT
, GURT_BAS_CNTD_RDY_AMT
, GURT_SIC_CNTD_RDY_AMT
, ACU_NPTD_RDY_AMT
, ACU_TMTD_RDY_AMT
, ACU_CNTD_RDY_AMT
, NRM_INTR_ACU_AMT
, GRAD_INTR_ACU_AMT
, NRM_INTR_MID_AMT
, GRAD_INTR_MID_AMT
, NRM_INTR_ALTN_PY_PREM
, GRAD_INTR_ALTN_PY_PREM
, ADD_ACU_CNTD_RDY_AMT
, ADD_ACU_TMTD_RDY_AMT
, ADD_ACU_NPTD_RDY_AMT
, FDSG_CNTD_RDY_AMT
, FDSG_TMTD_RDY_AMT
, FDSG_NPTD_RDY_AMT
, FDSG_ADD_CNTD_RDY_AMT
, FDSG_ADD_TMTD_RDY_AMT
, FDSG_ADD_NPTD_RDY_AMT
, CADD_ACU_CNTD_RDY_AMT
, CADD_ACU_TMTD_RDY_AMT
, CADD_ACU_NPTD_RDY_AMT
, APL_NPTD_RDY_AMT
, NPTD_RDY_AMT
, APL_TMTD_RDY_AMT
, TMTD_RDY_AMT
, CNTD_RDY_AMT
, SUM_APL_NPTD_RDY_AMT
, SUM_NPTD_RDY_AMT
, SUM_APL_TMTD_RDY_AMT
, SUM_TMTD_RDY_AMT
, SUM_CNTD_RDY_AMT
, ACU_UNPSS_PREM
, PFLS_ANLY_RDY_AMT
, XPT_INTR
, NRM_INTR
, GRAD_INTR
, CAL_DT
, REPLACE(REPLACE(INPPE_ORG_ID,CHR(13),''),CHR(10),'') INPPE_ORG_ID
, SYS_OCC_DTM
, REPLACE(REPLACE(SYS_DEL_DIV_CD,CHR(13),''),CHR(10),'') SYS_DEL_DIV_CD
, REPLACE(REPLACE(OCC_IP,CHR(13),''),CHR(10),'') OCC_IP
, REPLACE(REPLACE(APP_ID,CHR(13),''),CHR(10),'') APP_ID
, DATA_CHNG_DTM
, ADD_NRM_INTR_ACU_AMT
, ADD_GRAD_INTR_ACU_AMT
, FDSG_NRM_INTR_ACU_AMT
, FDSG_GRAD_INTR_ACU_AMT
, FDSD_NRM_INTR_ACU_AMT
, FDSD_GRAD_INTR_ACU_AMT
, LMPY_NRM_INTR_ACU_AMT
, LMPY_GRAD_INTR_ACU_AMT
, CAR_NRM_INTR_ACU_AMT
, CAR_GRAD_INTR_ACU_AMT
, EIH_LDG_DTM
, NITR_ACU_COV_PPI
, GITR_ACU_COV_PPI
, ICLO_RPY_AMT
, ICLO_RPY_LPS_IAMT
, STY_XACQ_EXP_TAMT
, STY_STND_ACQ_EXP_TAMT
, STY_GURT_BAS_URPAE
, STY_STND_BAS_URPAE
, STY_GURT_SIC_URPAE
, STY_STND_SIC_URPAE
, TMTD_LPS_IAMT
, APL_INTR
, LWST_GRN_INTR
, REPLACE(REPLACE(ADD_INS_PRD_TP_CD,CHR(13),''),CHR(10),'') ADD_INS_PRD_TP_CD
, REPLACE(REPLACE(ADD_PY_PRD_TP_CD,CHR(13),''),CHR(10),'') ADD_PY_PRD_TP_CD
, ADD_INS_PRD
, ADD_PY_PRD
, ADD_INS_ED_AGE
, ADD_PY_ED_AGE
, REPLACE(REPLACE(LWRT_TMN_RFD_TP_CD,CHR(13),''),CHR(10),'') LWRT_TMN_RFD_TP_CD FROM THDDH_TCTRDYLCTR
                       WHERE \$CONDITIONS 
			AND CLOG_YYMM = '${PART}'"\
    --m 8 \
    --boundary-query "SELECT 0, 7 FROM DUAL"\
    --split-by "ORA_HASH(CTR_ID, 7)"\
    --target-dir /tmp2/STG_THDDH_TCTRDYLCTR \
    --hive-import \
    --external-table-dir hdfs:///tmp2/temp_tbl/STG_THDDH_TCTRDYLCTR \
    --hive-overwrite \
    --hive-table DEFAULT.STG_THDDH_TCTRDYLCTR  >> ${SHLOG_DIR}/THDDH_TCTRDYLCTR.shlog 2>&1 &&

#----------------------------------------------------#
# Hadoop 원본테이블에 변경분 최종 적용
#----------------------------------------------------#
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TCTRDYLCTR_TMP2 ; " >> ${SHLOG_DIR}/THDDH_TCTRDYLCTR.shlog 2>&1 &&
    /usr/bin/hive -e "CREATE EXTERNAL TABLE MERITZ.THDDH_TCTRDYLCTR_TMP2 STORED AS PARQUET TBLPROPERTIES ('PARQUET.COMPRESS'='SNAPPY') AS
                                SELECT *
                                FROM DEFAULT.STG_THDDH_TCTRDYLCTR ;" >> ${SHLOG_DIR}/THDDH_TCTRDYLCTR.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.STG_THDDH_TCTRDYLCTR ;" >> ${SHLOG_DIR}/THDDH_TCTRDYLCTR.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TCTRDYLCTR_${PART} ;" >> ${SHLOG_DIR}/THDDH_TCTRDYLCTR.shlog 2>&1 &&
# 위의 파티션 드롭 코드는 아래 파일삭제를 전제하고 있음 
# external table은 drop시 자동삭제가 되지 않기 때문에 꼬였었음 181129 수정 
    /usr/bin/hadoop fs -rm -r -f  /warehouse/tablespace/external/hive/meritz.db/thddh_tctrdylctr_${PART}  >> ${SHLOG_DIR}/THDDH_TCTRDYLCTR.shlog 2>&1 &&
    /usr/bin/hive -e "ALTER TABLE MERITZ.THDDH_TCTRDYLCTR_TMP2 RENAME TO MERITZ.THDDH_TCTRDYLCTR_${PART} ;" >> ${SHLOG_DIR}/THDDH_TCTRDYLCTR.shlog 2>&1 &&
# external table 이 alter문 동작 다른 문제로 아래 과정이 필요해짐 
    /usr/bin/hive -e "ALTER TABLE MERITZ.THDDH_TCTRDYLCTR_${PART} SET LOCATION 'hdfs:///warehouse/tablespace/external/hive/meritz.db/thddh_tctrdylctr_${PART}' ;" >> ${SHLOG_DIR}/THDDH_TCTRDYLCTR.shlog 2>&1 &&
    /usr/bin/hdfs dfs -mv /warehouse/tablespace/external/hive/meritz.db/thddh_tctrdylctr_tmp2 /warehouse/tablespace/external/hive/meritz.db/thddh_tctrdylctr_${PART} >> ${SHLOG_DIR}/THDDH_TCTRDYLCTR.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TCTRDYLCTR_TMP2 ;" >> ${SHLOG_DIR}/THDDH_TCTRDYLCTR.shlog 2>&1 

if [ $? -ne 0 ]
then             
    echo "*-----------[ THDDH_TCTRDYLCTR.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/THDDH_TCTRDYLCTR.shlog"
    echo "*-----------[ THDDH_TCTRDYLCTR.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/THDDH_TCTRDYLCTR.shlog"  >>  ${SHLOG_DIR}/THDDH_TCTRDYLCTR.shlog
    echo "*-----------[ THDDH_TCTRDYLCTR.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TCTRDYLCTR.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/THDDH_TCTRDYLCTR.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/THDDH_TCTRDYLCTR.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCTRDYLCTR.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCTRDYLCTR.shlog /sqoopbin/scripts/etlpgm/his_log/THDDH_TCTRDYLCTR_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  THDDH_TCTRDYLCTR.sh cmd command error !! ***
    fi               

    exit -1      

else             
    echo "*-----------[ THDDH_TCTRDYLCTR.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TCTRDYLCTR.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/THDDH_TCTRDYLCTR.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/THDDH_TCTRDYLCTR.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCTRDYLCTR.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCTRDYLCTR.shlog /sqoopbin/scripts/etlpgm/his_log/THDDH_TCTRDYLCTR_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  THDDH_TCTRDYLCTR.sh cmd command error !! ***
        exit -1      
    else             
        exit 0       
    fi               
fi               
