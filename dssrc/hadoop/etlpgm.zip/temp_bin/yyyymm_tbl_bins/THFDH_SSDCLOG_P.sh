#!/bin/bash

if [ $# -eq 0 ]
then           
    ARGS=N    
else           
    ARGS=$1
fi             

NOW=$(date +"+%Y-%m-%d_%T")
SHLOG_DIR=/sqoopbin/scripts/etlpgm/cur_log
HISLOG_DIR=/sqoopbin/scripts/etlpgm/his_log

export HADOOP_OPTS=-Djava.security.egd=file:/dev/../dev/urandom
export ORACLE_BASE=/sw/oracle
export ORACLE_HOME=/sw/oracle/product/11.2.0.4/client_1
export LD_LIBRARY_PATH=/sw/oracle/product/11.2.0.4/client_1/lib:/sw/oracle/product/11.2.0.4/client_1/lib:
export PATH=/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/usr/lib64/qt-3.3/bin:/var/opt/node/bin/:/usr/hdp/3.0.0.0-1634/spark2/bin/:/opt/maven/bin:/usr/local/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/home/hdpapp/.local/bin:/home/hdpapp/bin
export TNS_ADMIN=/sw/oracle/product/11.2.0.4/client_1/network/admin
export ORACLE_SID=DBEDWP2
export NLS_LANG=American_America.KO16MSWIN949

#----------------------------------------------------#
# 작업내용 : THFDH_SSDCLOG 테이블 sqoop 복제 작업
# 작업주기 : D 
#----------------------------------------------------#

    echo " "
    echo "*-----------[ THFDH_SSDCLOG.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THFDH_SSDCLOG.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`  >  ${SHLOG_DIR}/THFDH_SSDCLOG.shlog

PART=$1

#----------------------------------------------------#
# 테이블별 일변경 데이터를 받아 오는 부분
#----------------------------------------------------#
    /usr/bin/hadoop fs -rm -r -f  /tmp2/STG_THFDH_SSDCLOG  >> ${SHLOG_DIR}/THFDH_SSDCLOG.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.STG_THFDH_SSDCLOG ; " >> ${SHLOG_DIR}/THFDH_SSDCLOG.shlog 2>&1 &&
    /usr/hdp/3.0.0.0-1634/sqoop/bin/sqoop import -D mapred.child.java.opts="-Djava.security.egd=file:/dev/../dev/urandom" \
    --connect jdbc:oracle:thin:EDWHADOOP/wjdqhrP\!23@10.91.41.172:12560:DBEDWP2 \
    --username  EDWHADOOP \
    --password wjdqhrP\!23 \
    --query "SELECT /*+ FULL(THFDH_SSDCLOG) */ CLOG_DT
, REPLACE(REPLACE(CLM_ID,CHR(13),''),CHR(10),'') CLM_ID
, REPLACE(REPLACE(COV_INS_AMT_ID,CHR(13),''),CHR(10),'') COV_INS_AMT_ID
, REPLACE(REPLACE(CSS_COV_INS_AMT_ID,CHR(13),''),CHR(10),'') CSS_COV_INS_AMT_ID
, REPLACE(REPLACE(CLADJ_CLOG_DIV_CD,CHR(13),''),CHR(10),'') CLADJ_CLOG_DIV_CD
, REPLACE(REPLACE(INS_ITMS_DIV_CD,CHR(13),''),CHR(10),'') INS_ITMS_DIV_CD
, REPLACE(REPLACE(BZPLN_PD_CTG_CD,CHR(13),''),CHR(10),'') BZPLN_PD_CTG_CD
, REPLACE(REPLACE(PREBL_MNG_PD_CTG_CD,CHR(13),''),CHR(10),'') PREBL_MNG_PD_CTG_CD
, REPLACE(REPLACE(SAL_PD_CD,CHR(13),''),CHR(10),'') SAL_PD_CD
, REPLACE(REPLACE(UNT_PD_CD,CHR(13),''),CHR(10),'') UNT_PD_CD
, REPLACE(REPLACE(ACD_NO_YY,CHR(13),''),CHR(10),'') ACD_NO_YY
, ACD_NO_SEQ
, REPLACE(REPLACE(ACD_RCT_ID,CHR(13),''),CHR(10),'') ACD_RCT_ID
, ACD_RCT_HIS_SEQ
, RCT_DTM
, RCT_DT
, ACD_DTM
, ACD_DT
, REPLACE(REPLACE(HOLI_YN,CHR(13),''),CHR(10),'') HOLI_YN
, REPLACE(REPLACE(OD_ACD_NO,CHR(13),''),CHR(10),'') OD_ACD_NO
, REPLACE(REPLACE(OTHCO_ACD_NO,CHR(13),''),CHR(10),'') OTHCO_ACD_NO
, REPLACE(REPLACE(ACD_WKD_CD,CHR(13),''),CHR(10),'') ACD_WKD_CD
, REPLACE(REPLACE(CITY_NATL_CD,CHR(13),''),CHR(10),'') CITY_NATL_CD
, REPLACE(REPLACE(ACD_PLC_ZPCD,CHR(13),''),CHR(10),'') ACD_PLC_ZPCD
, REPLACE(REPLACE(ACD_PLC_ZPCD_SNO,CHR(13),''),CHR(10),'') ACD_PLC_ZPCD_SNO
, REPLACE(REPLACE(ACD_PLC_ZPCD_ADR,CHR(13),''),CHR(10),'') ACD_PLC_ZPCD_ADR
, REPLACE(REPLACE(ACD_PLC_DTL_ADR_CON,CHR(13),''),CHR(10),'') ACD_PLC_DTL_ADR_CON
, REPLACE(REPLACE(LTT_DIV_CD,CHR(13),''),CHR(10),'') LTT_DIV_CD
, LTT_COO_DG
, LTT_COO_MI
, LTT_COO_SS
, REPLACE(REPLACE(LNT_DIV_CD,CHR(13),''),CHR(10),'') LNT_DIV_CD
, LNT_COO_DG
, LNT_COO_MI
, LNT_COO_SS
, REPLACE(REPLACE(ACD_CTR_ID,CHR(13),''),CHR(10),'') ACD_CTR_ID
, ACD_CTR_HIS_SEQ
, REPLACE(REPLACE(POL_NO,CHR(13),''),CHR(10),'') POL_NO
, CTR_ENDR_NO
, RTRO_ENDR_NO
, ENDR_HIS_STD_NO
, REPLACE(REPLACE(POLHD_CUS_ID,CHR(13),''),CHR(10),'') POLHD_CUS_ID
, REPLACE(REPLACE(POLHD_NM,CHR(13),''),CHR(10),'') POLHD_NM
, REPLACE(REPLACE(CTR_STAT_CD,CHR(13),''),CHR(10),'') CTR_STAT_CD
, REPLACE(REPLACE(CTR_STAT_DTL_CD,CHR(13),''),CHR(10),'') CTR_STAT_DTL_CD
, INS_BGN_DT
, INS_ED_DT
, SBCP_DT
, REPLACE(REPLACE(ACP_SH_DIV_CD,CHR(13),''),CHR(10),'') ACP_SH_DIV_CD
, REPLACE(REPLACE(MRIN_PD_DIV_CD,CHR(13),''),CHR(10),'') MRIN_PD_DIV_CD
, REPLACE(REPLACE(MA_INSPE_CUS_ID,CHR(13),''),CHR(10),'') MA_INSPE_CUS_ID
, REPLACE(REPLACE(MA_INSPE_NM,CHR(13),''),CHR(10),'') MA_INSPE_NM
, REPLACE(REPLACE(ORIG_RTRC_DIV_CD,CHR(13),''),CHR(10),'') ORIG_RTRC_DIV_CD
, REPLACE(REPLACE(PLR_STUP_YN,CHR(13),''),CHR(10),'') PLR_STUP_YN
, REPLACE(REPLACE(TRT_HDQT_ORG_CD,CHR(13),''),CHR(10),'') TRT_HDQT_ORG_CD
, REPLACE(REPLACE(TRT_BCH_ORG_CD,CHR(13),''),CHR(10),'') TRT_BCH_ORG_CD
, REPLACE(REPLACE(TRT_BRCH_ORG_CD,CHR(13),''),CHR(10),'') TRT_BRCH_ORG_CD
, REPLACE(REPLACE(TRTPE_ORG_ID,CHR(13),''),CHR(10),'') TRTPE_ORG_ID
, REPLACE(REPLACE(TRTPE_ORG_CD,CHR(13),''),CHR(10),'') TRTPE_ORG_CD
, REPLACE(REPLACE(CLM_TP_CD,CHR(13),''),CHR(10),'') CLM_TP_CD
, REPLACE(REPLACE(DSS_CD_YY,CHR(13),''),CHR(10),'') DSS_CD_YY
, DSS_CD_SEQ
, REPLACE(REPLACE(CLM_STAT_CD,CHR(13),''),CHR(10),'') CLM_STAT_CD
, REPLACE(REPLACE(ACD_CAUS_LCTG_CD,CHR(13),''),CHR(10),'') ACD_CAUS_LCTG_CD
, REPLACE(REPLACE(ACD_CAUS_MCTG_CD,CHR(13),''),CHR(10),'') ACD_CAUS_MCTG_CD
, REPLACE(REPLACE(ACD_CAUS_SCTG_CD,CHR(13),''),CHR(10),'') ACD_CAUS_SCTG_CD
, REPLACE(REPLACE(ACD_CAUS_DCTG_CD,CHR(13),''),CHR(10),'') ACD_CAUS_DCTG_CD
, REPLACE(REPLACE(ACD_CAUS_DCTG2_CD,CHR(13),''),CHR(10),'') ACD_CAUS_DCTG2_CD
, REPLACE(REPLACE(COMS_PART_ORG_ID,CHR(13),''),CHR(10),'') COMS_PART_ORG_ID
, REPLACE(REPLACE(COMS_PART_ORG_CD,CHR(13),''),CHR(10),'') COMS_PART_ORG_CD
, REPLACE(REPLACE(COMS_TEM_ORG_ID,CHR(13),''),CHR(10),'') COMS_TEM_ORG_ID
, REPLACE(REPLACE(COMS_TEM_ORG_CD,CHR(13),''),CHR(10),'') COMS_TEM_ORG_CD
, REPLACE(REPLACE(COMS_CHRPE_ORG_ID,CHR(13),''),CHR(10),'') COMS_CHRPE_ORG_ID
, REPLACE(REPLACE(CPIC_ORG_CD,CHR(13),''),CHR(10),'') CPIC_ORG_CD
, CNCLU_DT
, EXMP_DCN_DT
, REPLACE(REPLACE(DAM_DGR_CD,CHR(13),''),CHR(10),'') DAM_DGR_CD
, REPLACE(REPLACE(AT_ISP_YN,CHR(13),''),CHR(10),'') AT_ISP_YN
, REPLACE(REPLACE(ACD_CTR_OBJ_ID,CHR(13),''),CHR(10),'') ACD_CTR_OBJ_ID
, ACD_CTR_OBJ_HIS_SEQ
, REPLACE(REPLACE(ACD_OBJ_DIV_CD,CHR(13),''),CHR(10),'') ACD_OBJ_DIV_CD
, REPLACE(REPLACE(ACD_OBJ_ID,CHR(13),''),CHR(10),'') ACD_OBJ_ID
, DAM_ORD
, REPLACE(REPLACE(CTR_OBJ_ID,CHR(13),''),CHR(10),'') CTR_OBJ_ID
, REPLACE(REPLACE(CTR_OBJ_ADR_ID,CHR(13),''),CHR(10),'') CTR_OBJ_ADR_ID
, REPLACE(REPLACE(OBJ_TP_CD,CHR(13),''),CHR(10),'') OBJ_TP_CD
, REPLACE(REPLACE(DMPE_CUS_ID,CHR(13),''),CHR(10),'') DMPE_CUS_ID
, REPLACE(REPLACE(DMPO_NM,CHR(13),''),CHR(10),'') DMPO_NM
, REPLACE(REPLACE(PVDS_YN,CHR(13),''),CHR(10),'') PVDS_YN
, REPLACE(REPLACE(TCTR_DMPE_JOB_GRD_CD,CHR(13),''),CHR(10),'') TCTR_DMPE_JOB_GRD_CD
, REPLACE(REPLACE(TCTR_DMPE_JOB_CD,CHR(13),''),CHR(10),'') TCTR_DMPE_JOB_CD
, REPLACE(REPLACE(TACD_DMPE_JOB_GRD_CD,CHR(13),''),CHR(10),'') TACD_DMPE_JOB_GRD_CD
, REPLACE(REPLACE(TACD_DMPE_JOB_CD,CHR(13),''),CHR(10),'') TACD_DMPE_JOB_CD
, REPLACE(REPLACE(OWNR_NM,CHR(13),''),CHR(10),'') OWNR_NM
, DMPE_AGE
, REPLACE(REPLACE(TNG_DIV_CD,CHR(13),''),CHR(10),'') TNG_DIV_CD
, REPLACE(REPLACE(OBJ_GRD_CD,CHR(13),''),CHR(10),'') OBJ_GRD_CD
, REPLACE(REPLACE(OPN_JBCL_CD,CHR(13),''),CHR(10),'') OPN_JBCL_CD
, REPLACE(REPLACE(OPJB_NM,CHR(13),''),CHR(10),'') OPJB_NM
, REPLACE(REPLACE(OBJ_CD,CHR(13),''),CHR(10),'') OBJ_CD
, REPLACE(REPLACE(DMOB_LCTG_CD,CHR(13),''),CHR(10),'') DMOB_LCTG_CD
, REPLACE(REPLACE(DMOB_MCTG_CD,CHR(13),''),CHR(10),'') DMOB_MCTG_CD
, REPLACE(REPLACE(DMOB_SCTG_CD,CHR(13),''),CHR(10),'') DMOB_SCTG_CD
, REPLACE(REPLACE(DMOB_TPIDS_LCTG_CD,CHR(13),''),CHR(10),'') DMOB_TPIDS_LCTG_CD
, REPLACE(REPLACE(DMOB_TPIDS_MCTG_CD,CHR(13),''),CHR(10),'') DMOB_TPIDS_MCTG_CD
, REPLACE(REPLACE(DMOB_TPIDS_SCTG_CD,CHR(13),''),CHR(10),'') DMOB_TPIDS_SCTG_CD
, REPLACE(REPLACE(DMOB_TPIDS_DCTG_CD,CHR(13),''),CHR(10),'') DMOB_TPIDS_DCTG_CD
, REPLACE(REPLACE(MCSH_FSHBT_DIV_CD,CHR(13),''),CHR(10),'') MCSH_FSHBT_DIV_CD
, SHAG
, REPLACE(REPLACE(SHP_TP_CD,CHR(13),''),CHR(10),'') SHP_TP_CD
, REPLACE(REPLACE(SHP_CD,CHR(13),''),CHR(10),'') SHP_CD
, REPLACE(REPLACE(ARCRF_REG_NO,CHR(13),''),CHR(10),'') ARCRF_REG_NO
, REPLACE(REPLACE(CARG_TRN_ITM_CD,CHR(13),''),CHR(10),'') CARG_TRN_ITM_CD
, REPLACE(REPLACE(DTH_YN,CHR(13),''),CHR(10),'') DTH_YN
, REPLACE(REPLACE(AFOBS_YN,CHR(13),''),CHR(10),'') AFOBS_YN
, REPLACE(REPLACE(HSP_MD_EXP_YN,CHR(13),''),CHR(10),'') HSP_MD_EXP_YN
, REPLACE(REPLACE(GHR_MD_EXP_YN,CHR(13),''),CHR(10),'') GHR_MD_EXP_YN
, REPLACE(REPLACE(PSC_MD_EXP_YN,CHR(13),''),CHR(10),'') PSC_MD_EXP_YN
, REPLACE(REPLACE(HSP_DDPY_YN,CHR(13),''),CHR(10),'') HSP_DDPY_YN
, REPLACE(REPLACE(LAST_DGN_YN,CHR(13),''),CHR(10),'') LAST_DGN_YN
, REPLACE(REPLACE(SROP_YN,CHR(13),''),CHR(10),'') SROP_YN
, REPLACE(REPLACE(EXP_YN,CHR(13),''),CHR(10),'') EXP_YN
, REPLACE(REPLACE(SROP_BDW_YN,CHR(13),''),CHR(10),'') SROP_BDW_YN
, REPLACE(REPLACE(OS_ID,CHR(13),''),CHR(10),'') OS_ID
, OS_HIS_SEQ
, OS_SEQ
, REPLACE(REPLACE(OS_DIV_CD,CHR(13),''),CHR(10),'') OS_DIV_CD
, REPLACE(REPLACE(DCN_ID,CHR(13),''),CHR(10),'') DCN_ID
, DCN_HIS_SEQ
, DCN_SEQ
, REPLACE(REPLACE(DCN_DIV_CD,CHR(13),''),CHR(10),'') DCN_DIV_CD
, REPLACE(REPLACE(CNCLU_ID,CHR(13),''),CHR(10),'') CNCLU_ID
, CNCLU_HIS_SEQ
, REPLACE(REPLACE(CNCLU_DIV_CD,CHR(13),''),CHR(10),'') CNCLU_DIV_CD
, REPLACE(REPLACE(CNCLU_DATA_DIV_CD,CHR(13),''),CHR(10),'') CNCLU_DATA_DIV_CD
, REPLACE(REPLACE(COV_INS_DATA_DIV_CD,CHR(13),''),CHR(10),'') COV_INS_DATA_DIV_CD
, COV_INS_HIS_SEQ
, INS_AMT_APVL_DT
, CSS_COV_INS_HIS_SEQ
, REPLACE(REPLACE(SPTPY_DIV_CD,CHR(13),''),CHR(10),'') SPTPY_DIV_CD
, ISD_PCS_SEQ
, REPLACE(REPLACE(COV_CD,CHR(13),''),CHR(10),'') COV_CD
, REPLACE(REPLACE(INS_AMT_EXT_EXP_DIV_CD,CHR(13),''),CHR(10),'') INS_AMT_EXT_EXP_DIV_CD
, REPLACE(REPLACE(GURT_UNT_CD,CHR(13),''),CHR(10),'') GURT_UNT_CD
, REPLACE(REPLACE(RSK_UNT_CD,CHR(13),''),CHR(10),'') RSK_UNT_CD
, REPLACE(REPLACE(CLADJ_DIV_CTG_CD,CHR(13),''),CHR(10),'') CLADJ_DIV_CTG_CD
, REPLACE(REPLACE(BAS_SIC_DIV_CD,CHR(13),''),CHR(10),'') BAS_SIC_DIV_CD
, COV_INS_BGN_DT
, COV_INS_ED_DT
, REPLACE(REPLACE(INSD_AMT_CUR_CD,CHR(13),''),CHR(10),'') INSD_AMT_CUR_CD
, CUR_INSD_AMT
, INSD_AMT
, PPS_COMS_LM_AMT
, PACD_COMS_LM_AMT
, REPLACE(REPLACE(LDCO_CTR_BZAC_CD,CHR(13),''),CHR(10),'') LDCO_CTR_BZAC_CD
, REPLACE(REPLACE(COI_CTR_BZAC_CD,CHR(13),''),CHR(10),'') COI_CTR_BZAC_CD
, CSS_COV_INS_SEQ
, JNT_ACP_COV_INS_SEQ
, PRTC_RT
, REPLACE(REPLACE(BRKR_CTR_BZAC_CD,CHR(13),''),CHR(10),'') BRKR_CTR_BZAC_CD
, REPLACE(REPLACE(RINCO_CTR_BZAC_CD,CHR(13),''),CHR(10),'') RINCO_CTR_BZAC_CD
, REPLACE(REPLACE(CLOG_APL_YN,CHR(13),''),CHR(10),'') CLOG_APL_YN
, REPLACE(REPLACE(CSS_CTR_ID,CHR(13),''),CHR(10),'') CSS_CTR_ID
, REPLACE(REPLACE(RINS_SH_DIV_CD,CHR(13),''),CHR(10),'') RINS_SH_DIV_CD
, BRKR_CSS_RT
, INSD_AMT_STD_CSS_RT
, ACP_AMT_STD_CSS_RT
, REPLACE(REPLACE(CUR_CD,CHR(13),''),CHR(10),'') CUR_CD
, APL_EXRT
, CSS_INS_AMT
, KWCV_CSS_INS_AMT
, EIH_LDG_DTM FROM THFDH_SSDCLOG
                       WHERE \$CONDITIONS 
                         AND CLOG_DT BETWEEN TO_DATE(${PART}||'01','YYYYMMDD') AND LAST_DAY(TO_DATE(${PART}||'01','YYYYMMDD')) "\
    --m 8 \
    --boundary-query "SELECT 0, 7 FROM DUAL" \
    --split-by "ora_hash(clm_id,7)" \
    --target-dir /tmp2/STG_THFDH_SSDCLOG \
    --hive-import \
    --external-table-dir hdfs:///tmp2/temp_tbl/STG_THFDH_SSDCLOG \
    --hive-overwrite \
    --hive-table DEFAULT.STG_THFDH_SSDCLOG  >> ${SHLOG_DIR}/THFDH_SSDCLOG.shlog 2>&1 &&

#----------------------------------------------------#
# Hadoop 원본테이블에 변경분 최종 적용
#----------------------------------------------------#
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THFDH_SSDCLOG_TMP ; " >> ${SHLOG_DIR}/THFDH_SSDCLOG.shlog 2>&1 &&
    /usr/bin/hive -e "CREATE EXTERNAL TABLE MERITZ.THFDH_SSDCLOG_TMP STORED AS PARQUET TBLPROPERTIES ('PARQUET.COMPRESS'='SNAPPY') AS
                                SELECT *
                                FROM DEFAULT.STG_THFDH_SSDCLOG ;" >> ${SHLOG_DIR}/THFDH_SSDCLOG.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.STG_THFDH_SSDCLOG ;" >> ${SHLOG_DIR}/THFDH_SSDCLOG.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THFDH_SSDCLOG_${PART} ;" >> ${SHLOG_DIR}/THFDH_SSDCLOG.shlog 2>&1 &&

# 위의 파티션 드롭 코드는 아래 파일삭제를 전제하고 있음
# external table은 drop시 자동삭제가 되지 않기 때문에 꼬였었음 181129 수정
    /usr/bin/hadoop fs -rm -r -f  /warehouse/tablespace/external/hive/meritz.db/thfdh_ssdclog_${PART}  >> ${SHLOG_DIR}/THFDH_SSDCLOG.shlog 2>&1 &&

    /usr/bin/hive -e "ALTER TABLE MERITZ.THFDH_SSDCLOG_TMP RENAME TO MERITZ.THFDH_SSDCLOG_${PART} ;" >> ${SHLOG_DIR}/THFDH_SSDCLOG.shlog 2>&1 &&

# external table 이 alter문 동작 다른 문제로 아래 과정이 필요해짐
    /usr/bin/hive -e "ALTER TABLE MERITZ.THFDH_SSDCLOG_${PART} SET LOCATION 'hdfs:///warehouse/tablespace/external/hive/meritz.db/thfdh_ssdclog_${PART}' ;" >> ${SHLOG_DIR}/THFDH_SSDCLOG.shlog 2>&1 &&
    /usr/bin/hdfs dfs -mv /warehouse/tablespace/external/hive/meritz.db/thfdh_ssdclog_tmp /warehouse/tablespace/external/hive/meritz.db/thfdh_ssdclog_${PART} >> ${SHLOG_DIR}/THFDH_SSDCLOG.shlog 2>&1 &&

    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THFDH_SSDCLOG_TMP ;" >> ${SHLOG_DIR}/THFDH_SSDCLOG.shlog 2>&1 

if [ $? -ne 0 ]
then             
    echo "*-----------[ THFDH_SSDCLOG.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/THFDH_SSDCLOG.shlog"
    echo "*-----------[ THFDH_SSDCLOG.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/THFDH_SSDCLOG.shlog"  >>  ${SHLOG_DIR}/THFDH_SSDCLOG.shlog
    echo "*-----------[ THFDH_SSDCLOG.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THFDH_SSDCLOG.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/THFDH_SSDCLOG.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/THFDH_SSDCLOG.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/THFDH_SSDCLOG.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/THFDH_SSDCLOG.shlog /sqoopbin/scripts/etlpgm/his_log/THFDH_SSDCLOG_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  THFDH_SSDCLOG.sh cmd command error !! ***
    fi               

    exit -1      

else             
    echo "*-----------[ THFDH_SSDCLOG.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THFDH_SSDCLOG.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/THFDH_SSDCLOG.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/THFDH_SSDCLOG.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/THFDH_SSDCLOG.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/THFDH_SSDCLOG.shlog /sqoopbin/scripts/etlpgm/his_log/THFDH_SSDCLOG_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  THFDH_SSDCLOG.sh cmd command error !! ***
        exit -1      
    else             
        exit 0       
    fi               
fi               
