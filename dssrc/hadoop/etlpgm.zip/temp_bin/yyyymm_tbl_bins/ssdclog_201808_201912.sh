#!/bin/bash

#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THFDH_SSDCLOG_P.sh 201808
/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THFDH_SSDCLOG_P.sh 201809
/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THFDH_SSDCLOG_P.sh 201810
/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THFDH_SSDCLOG_P.sh 201811
/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THFDH_SSDCLOG_P.sh 201812
/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THFDH_SSDCLOG_P.sh 201901
/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THFDH_SSDCLOG_P.sh 201902
/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THFDH_SSDCLOG_P.sh 201903
/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THFDH_SSDCLOG_P.sh 201904
/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THFDH_SSDCLOG_P.sh 201905
/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THFDH_SSDCLOG_P.sh 201906
/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THFDH_SSDCLOG_P.sh 201907
/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THFDH_SSDCLOG_P.sh 201908
/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THFDH_SSDCLOG_P.sh 201909
/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THFDH_SSDCLOG_P.sh 201910
/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THFDH_SSDCLOG_P.sh 201911
/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THFDH_SSDCLOG_P.sh 201912
