#!/bin/bash

#/sqoopbin/scripts/etlpgm/temp_bin/THDDH_LCOVRDYRST_P.sh 201701
/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_LCOVRDYRST_P.sh 201702
/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_LCOVRDYRST_P.sh 201703
/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_LCOVRDYRST_P.sh 201704
/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_LCOVRDYRST_P.sh 201705
/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_LCOVRDYRST_P.sh 201706
/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_LCOVRDYRST_P.sh 201707
/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_LCOVRDYRST_P.sh 201708
/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_LCOVRDYRST_P.sh 201709
/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_LCOVRDYRST_P.sh 201710
/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_LCOVRDYRST_P.sh 201711
/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_LCOVRDYRST_P.sh 201712
