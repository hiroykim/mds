#!/bin/bash

#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_LPSCTMVCTP_P.sh 201909
/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_LPSCTMVCTP_P.sh 201910
/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_LPSCTMVCTP_P.sh 201911
#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_LPSCTMVCTP_P.sh 201912
