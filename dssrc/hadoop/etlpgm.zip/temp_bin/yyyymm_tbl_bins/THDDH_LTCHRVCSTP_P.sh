#!/bin/bash

if [ $# -eq 0 ]
then           
    ARGS=N    
else           
    ARGS=$1
fi             

NOW=$(date +"+%Y-%m-%d_%T")
SHLOG_DIR=/sqoopbin/scripts/etlpgm/cur_log
HISLOG_DIR=/sqoopbin/scripts/etlpgm/his_log

export HADOOP_OPTS=-Djava.security.egd=file:/dev/../dev/urandom
export ORACLE_BASE=/sw/oracle
export ORACLE_HOME=/sw/oracle/product/11.2.0.4/client_1
export LD_LIBRARY_PATH=/sw/oracle/product/11.2.0.4/client_1/lib:/sw/oracle/product/11.2.0.4/client_1/lib:
export PATH=/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/usr/lib64/qt-3.3/bin:/usr/hdp/3.0.0.0-1634/spark2/bin/:/var/opt/node/bin/:/opt/maven/bin:/usr/local/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/home/hdpapp/workspace/data-science-at-the-command-line/tools:/home/hdpapp/.local/bin:/home/hdpapp/bin
export TNS_ADMIN=/sw/oracle/product/11.2.0.4/client_1/network/admin
export ORACLE_SID=DBEDWP2
export NLS_LANG=American_America.KO16MSWIN949

#----------------------------------------------------#
# 작업내용 : THDDH_LTCHRVCSTP 테이블 sqoop 복제 작업
# 작업주기 :  
#----------------------------------------------------#

    echo " "
    echo "*-----------[ THDDH_LTCHRVCSTP.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_LTCHRVCSTP.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`  >  ${SHLOG_DIR}/THDDH_LTCHRVCSTP.shlog
PART=$1

#----------------------------------------------------#
# 테이블별 전체 데이터를 받아 오는 부분
#----------------------------------------------------#
    /usr/bin/hadoop fs -rm -r -f  /tmp2/STG_THDDH_LTCHRVCSTP  >> ${SHLOG_DIR}/THDDH_LTCHRVCSTP.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.STG_THDDH_LTCHRVCSTP ; " >> ${SHLOG_DIR}/THDDH_LTCHRVCSTP.shlog 2>&1 &&
    /usr/hdp/3.0.0.0-1634/sqoop/bin/sqoop import -D mapred.child.java.opts="-Djava.security.egd=file:/dev/../dev/urandom" \
    --connect jdbc:oracle:thin:EDWHADOOP/wjdqhrP\!23@10.91.41.172:12560:DBEDWP2 \
    --username  EDWHADOOP \
    --password wjdqhrP\!23 \
    --query "SELECT /*+ FULL(THDDH_LTCHRVCSTP) */ REPLACE(REPLACE(CLOG_YYMM,CHR(13),''),CHR(10),'') CLOG_YYMM
, STD_DT
, REPLACE(REPLACE(CTR_CHNG_STAT_CD,CHR(13),''),CHR(10),'') CTR_CHNG_STAT_CD
, REPLACE(REPLACE(POL_NO,CHR(13),''),CHR(10),'') POL_NO
, REPLACE(REPLACE(COV_CD,CHR(13),''),CHR(10),'') COV_CD
, REPLACE(REPLACE(CTR_COV_ID,CHR(13),''),CHR(10),'') CTR_COV_ID
, ENDR_NO
, REPLACE(REPLACE(UNT_PD_CD,CHR(13),''),CHR(10),'') UNT_PD_CD
, REPLACE(REPLACE(SBCP_YYMM,CHR(13),''),CHR(10),'') SBCP_YYMM
, REPLACE(REPLACE(FEE_PAY_TP_CD,CHR(13),''),CHR(10),'') FEE_PAY_TP_CD
, SBCP_DT
, ENDR_DT
, REPLACE(REPLACE(DMG_RT_COV_DCTG_CD,CHR(13),''),CHR(10),'') DMG_RT_COV_DCTG_CD
, REPLACE(REPLACE(INS_PRD_TP_CD,CHR(13),''),CHR(10),'') INS_PRD_TP_CD
, INS_PRD
, REPLACE(REPLACE(PY_PRD_TP_CD,CHR(13),''),CHR(10),'') PY_PRD_TP_CD
, PY_PRD
, REPLACE(REPLACE(PY_CYC_CD,CHR(13),''),CHR(10),'') PY_CYC_CD
, SBC_AGE
, REPLACE(REPLACE(GNDR_CD,CHR(13),''),CHR(10),'') GNDR_CD
, INJR_GR_NUM
, REPLACE(REPLACE(LAST_PY_YYMM,CHR(13),''),CHR(10),'') LAST_PY_YYMM
, LAST_PY_TMS
, REPLACE(REPLACE(RCRT_HDQT_ORG_CD,CHR(13),''),CHR(10),'') RCRT_HDQT_ORG_CD
, REPLACE(REPLACE(RCRT_BRCH_ORG_CD,CHR(13),''),CHR(10),'') RCRT_BRCH_ORG_CD
, REPLACE(REPLACE(RCRT_BCH_ORG_CD,CHR(13),''),CHR(10),'') RCRT_BCH_ORG_CD
, REPLACE(REPLACE(RCRT_TRTPE_ORG_CD,CHR(13),''),CHR(10),'') RCRT_TRTPE_ORG_CD
, REPLACE(REPLACE(RCRT_AGC_PLNR_CD,CHR(13),''),CHR(10),'') RCRT_AGC_PLNR_CD
, REPLACE(REPLACE(TRT_HDQT_ORG_CD,CHR(13),''),CHR(10),'') TRT_HDQT_ORG_CD
, REPLACE(REPLACE(TRT_BRCH_ORG_CD,CHR(13),''),CHR(10),'') TRT_BRCH_ORG_CD
, REPLACE(REPLACE(TRT_BCH_ORG_CD,CHR(13),''),CHR(10),'') TRT_BCH_ORG_CD
, REPLACE(REPLACE(TRTPE_ORG_CD,CHR(13),''),CHR(10),'') TRTPE_ORG_CD
, REPLACE(REPLACE(AGC_PLNR_CD,CHR(13),''),CHR(10),'') AGC_PLNR_CD
, HDQT_OPPN_DG_CF
, SLZ_PREM
, IRTD_MKVL_AMT
, BZEX_MKVL_AMT
, RSKEX_MKVL_AMT
, EIH_LDG_DTM
, RB_EXP_CPR
, RSK_PREM_CPR
, ORIG_PREM_CPR
, MKVL_CPR
, EXPR_RFD_AMT_CPR
, CLAT_CPR
, SRVL_BNT_CPR
, ANN_PAY_AMT_CPR
, PO_ETPY_CPR
, MNCL_FEE_CPR
, SAV_PREM_CPR
, XACQ_EXP_CPR
, XPT_MTN_EXP_CPR
, XPT_MNCL_EXP_CPR
, INS_AMT_CPR
, NPTPY_NW_CTR_RSLFE_CPR
, NPTPY_ETC_NPO_CPR
, TMN_MGI_CPR
, ACD_ATTM_RDY_AMT_CPR
, PY_EXEM_PREM_CPR
, HFWY_WDR_CPR
, TMN_RSK_PREM_CPR
, LCAT_PD_CLAT_CPR
, TMN_ATTM_RDY_AMT_CPR
, DMN15_WTHN_SLZ_PREM
, DMN15_TMTD_RDY_AMT
, REPLACE(REPLACE(OWN_CTR_YN,CHR(13),''),CHR(10),'') OWN_CTR_YN
, REPLACE(REPLACE(CTR_CONV_SIC_SBC_YN,CHR(13),''),CHR(10),'') CTR_CONV_SIC_SBC_YN
, SBC_AMT
, CRD_FEE_CPR
, CUS_CNTRB_ERN_AMT
, SUM_FEE_CPR
, ITRT_RISK_AMT
, KICS_MKVL_CPR
, ITRT_DEPRC_MKVL_CPR
, ITRT_ASCD_MKVL_CPR
, REPLACE(REPLACE(CTR_INS_PRD_TP_CD,CHR(13),''),CHR(10),'') CTR_INS_PRD_TP_CD
, MMPY_CNVS_PREM
, REPLACE(REPLACE(PLAN_CD,CHR(13),''),CHR(10),'') PLAN_CD
, REPLACE(REPLACE(COV_UNT_PD_CD,CHR(13),''),CHR(10),'') COV_UNT_PD_CD
, CSS_PREM_CPR
, CSS_INS_AMT_RFD_CPR
, MKVL_BKPM_AMT_CPR
, CSS_RT
, REPLACE(REPLACE(CLF_DIV_CD,CHR(13),''),CHR(10),'') CLF_DIV_CD
, REPLACE(REPLACE(INS_SBC_SH_CD,CHR(13),''),CHR(10),'') INS_SBC_SH_CD
, REPLACE(REPLACE(SBC_DSG_FEE_PAY_TP_CD,CHR(13),''),CHR(10),'') SBC_DSG_FEE_PAY_TP_CD
, SBC_DSG_IRTD_MVAT
, SBC_DSG_BZEX_MVAT
, SBC_DSG_RSKEX_MVAT
, SBC_DSG_RB_EXP_CPR
, SBC_DSG_RSK_PREM_CPR
, SBC_DSG_ORIG_PREM_CPR
, SBC_DSG_MKVL_CPR
, REPLACE(REPLACE(LWRT_TMN_RFD_TP_CD,CHR(13),''),CHR(10),'') LWRT_TMN_RFD_TP_CD
, REPLACE(REPLACE(LGTM_ITMS_DIV_CD,CHR(13),''),CHR(10),'') LGTM_ITMS_DIV_CD
, ADVEXP
, REPLACE(REPLACE(TRTPE_TRFR_YN,CHR(13),''),CHR(10),'') TRTPE_TRFR_YN
, REPLACE(REPLACE(DTBT_CTR_YN,CHR(13),''),CHR(10),'') DTBT_CTR_YN
, REPLACE(REPLACE(INSPE_GRDE_VAL,CHR(13),''),CHR(10),'') INSPE_GRDE_VAL
, REPLACE(REPLACE(PY_EXEM_TP_CD,CHR(13),''),CHR(10),'') PY_EXEM_TP_CD
, REPLACE(REPLACE(AMBA_CHN_DIV_CD,CHR(13),''),CHR(10),'') AMBA_CHN_DIV_CD
, PSINS_CRD_ETC_FEE
, PSINS_AT_TRS_ETC_FEE
, PSINS_COMS_ETC_FEE
, LGTM_CHGE_EXP
, LGTM_FIXT_EXP
, PSINS_ATNS_MKVL_AMT FROM THDDH_LTCHRVCSTP
                       WHERE \$CONDITIONS 
			AND CLOG_YYMM = '${PART}'"\
    --m 8 \
    --boundary-query "SELECT 0, 7 FROM DUAL"\
    --split-by "ORA_HASH(POL_NO, 7)"\
    --target-dir /tmp2/STG_THDDH_LTCHRVCSTP \
    --hive-import \
    --external-table-dir hdfs:///tmp2/temp_tbl/STG_THDDH_LTCHRVCSTP \
    --hive-overwrite \
    --hive-table DEFAULT.STG_THDDH_LTCHRVCSTP  >> ${SHLOG_DIR}/THDDH_LTCHRVCSTP.shlog 2>&1 &&

#----------------------------------------------------#
# Hadoop 원본테이블에 변경분 최종 적용
#----------------------------------------------------#
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_LTCHRVCSTP_TMP ; " >> ${SHLOG_DIR}/THDDH_LTCHRVCSTP.shlog 2>&1 &&
    /usr/bin/hive -e "CREATE EXTERNAL TABLE MERITZ.THDDH_LTCHRVCSTP_TMP STORED AS PARQUET TBLPROPERTIES ('PARQUET.COMPRESS'='SNAPPY') AS
                                SELECT *
                                FROM DEFAULT.STG_THDDH_LTCHRVCSTP ;" >> ${SHLOG_DIR}/THDDH_LTCHRVCSTP.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.STG_THDDH_LTCHRVCSTP ;" >> ${SHLOG_DIR}/THDDH_LTCHRVCSTP.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_LTCHRVCSTP_${PART} ;" >> ${SHLOG_DIR}/THDDH_LTCHRVCSTP.shlog 2>&1 &&
# 위의 파티션 드롭 코드는 아래 파일삭제를 전제하고 있음 
# external table은 drop시 자동삭제가 되지 않기 때문에 꼬였었음 181129 수정 
    /usr/bin/hadoop fs -rm -r -f  /warehouse/tablespace/external/hive/meritz.db/thddh_ltchrvcstp_${PART}  >> ${SHLOG_DIR}/THDDH_LTCHRVCSTP.shlog 2>&1 &&
    /usr/bin/hive -e "ALTER TABLE MERITZ.THDDH_LTCHRVCSTP_TMP RENAME TO MERITZ.THDDH_LTCHRVCSTP_${PART} ;" >> ${SHLOG_DIR}/THDDH_LTCHRVCSTP.shlog 2>&1 &&
# external table 이 alter문 동작 다른 문제로 아래 과정이 필요해짐 
    /usr/bin/hive -e "ALTER TABLE MERITZ.THDDH_LTCHRVCSTP_${PART} SET LOCATION 'hdfs:///warehouse/tablespace/external/hive/meritz.db/thddh_ltchrvcstp_${PART}' ;" >> ${SHLOG_DIR}/THDDH_LTCHRVCSTP.shlog 2>&1 &&
    /usr/bin/hdfs dfs -mv /warehouse/tablespace/external/hive/meritz.db/thddh_ltchrvcstp_tmp /warehouse/tablespace/external/hive/meritz.db/thddh_ltchrvcstp_${PART} >> ${SHLOG_DIR}/THDDH_LTCHRVCSTP.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_LTCHRVCSTP_TMP ;" >> ${SHLOG_DIR}/THDDH_LTCHRVCSTP.shlog 2>&1 

if [ $? -ne 0 ]
then             
    echo "*-----------[ THDDH_LTCHRVCSTP.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/THDDH_LTCHRVCSTP.shlog"
    echo "*-----------[ THDDH_LTCHRVCSTP.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/THDDH_LTCHRVCSTP.shlog"  >>  ${SHLOG_DIR}/THDDH_LTCHRVCSTP.shlog
    echo "*-----------[ THDDH_LTCHRVCSTP.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_LTCHRVCSTP.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/THDDH_LTCHRVCSTP.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/THDDH_LTCHRVCSTP.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/THDDH_LTCHRVCSTP.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/THDDH_LTCHRVCSTP.shlog /sqoopbin/scripts/etlpgm/his_log/THDDH_LTCHRVCSTP_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  THDDH_LTCHRVCSTP.sh cmd command error !! ***
    fi               

    exit -1      

else             
    echo "*-----------[ THDDH_LTCHRVCSTP.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_LTCHRVCSTP.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/THDDH_LTCHRVCSTP.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/THDDH_LTCHRVCSTP.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/THDDH_LTCHRVCSTP.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/THDDH_LTCHRVCSTP.shlog /sqoopbin/scripts/etlpgm/his_log/THDDH_LTCHRVCSTP_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  THDDH_LTCHRVCSTP.sh cmd command error !! ***
        exit -1      
    else             
        exit 0       
    fi               
fi               
