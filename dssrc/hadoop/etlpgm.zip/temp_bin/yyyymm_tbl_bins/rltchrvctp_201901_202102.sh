#!/bin/bash

#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_RLTCHRVCTP_P.sh 201901
#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_RLTCHRVCTP_P.sh 201902
#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_RLTCHRVCTP_P.sh 201903
#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_RLTCHRVCTP_P.sh 201904
#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_RLTCHRVCTP_P.sh 201905
#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_RLTCHRVCTP_P.sh 201906
#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_RLTCHRVCTP_P.sh 201907
#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_RLTCHRVCTP_P.sh 201908
#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_RLTCHRVCTP_P.sh 201909
#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_RLTCHRVCTP_P.sh 201910
#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_RLTCHRVCTP_P.sh 201911
#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_RLTCHRVCTP_P.sh 201912
#
#
#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_RLTCHRVCTP_P.sh 202001
#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_RLTCHRVCTP_P.sh 202002
#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_RLTCHRVCTP_P.sh 202003
#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_RLTCHRVCTP_P.sh 202004
#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_RLTCHRVCTP_P.sh 202005
#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_RLTCHRVCTP_P.sh 202006
#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_RLTCHRVCTP_P.sh 202007
#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_RLTCHRVCTP_P.sh 202008
#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_RLTCHRVCTP_P.sh 202009
#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_RLTCHRVCTP_P.sh 202010
#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_RLTCHRVCTP_P.sh 202011
#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_RLTCHRVCTP_P.sh 202012

#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_RLTCHRVCTP_P.sh 202101
#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_RLTCHRVCTP_P.sh 202102

#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_RLTCHRVCTP_P.sh 202108
#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_RLTCHRVCTP_P.sh 202109
/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_RLTCHRVCTP_P.sh 202110
