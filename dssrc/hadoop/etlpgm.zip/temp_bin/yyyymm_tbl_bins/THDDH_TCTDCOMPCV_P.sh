#!/bin/bash

if [ $# -eq 0 ]
then           
    ARGS=N    
else           
    ARGS=$1
fi             

NOW=$(date +"+%Y-%m-%d_%T")
SHLOG_DIR=/sqoopbin/scripts/etlpgm/cur_log
HISLOG_DIR=/sqoopbin/scripts/etlpgm/his_log

export HADOOP_OPTS=-Djava.security.egd=file:/dev/../dev/urandom
export ORACLE_BASE=/sw/oracle
export ORACLE_HOME=/sw/oracle/product/11.2.0.4/client_1
export LD_LIBRARY_PATH=/sw/oracle/product/11.2.0.4/client_1/lib:/sw/oracle/product/11.2.0.4/client_1/lib:
export PATH=/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/usr/lib64/qt-3.3/bin:/var/opt/node/bin/:/usr/hdp/3.0.0.0-1634/spark2/bin/:/opt/maven/bin:/usr/local/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/home/hdpapp/.local/bin:/home/hdpapp/bin
export TNS_ADMIN=/sw/oracle/product/11.2.0.4/client_1/network/admin
export ORACLE_SID=DBEDWP2
export NLS_LANG=American_America.KO16MSWIN949

#----------------------------------------------------#
# 작업내용 : THDDH_TCTDCOMPCV 테이블 sqoop 복제 작업
# 작업주기 : D 
#----------------------------------------------------#

    echo " "
    echo "*-----------[ THDDH_TCTDCOMPCV.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TCTDCOMPCV.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`  >  ${SHLOG_DIR}/THDDH_TCTDCOMPCV.shlog

PART=$1
#----------------------------------------------------#
# 테이블별 일변경 데이터를 받아 오는 부분
#----------------------------------------------------#
    /usr/bin/hadoop fs -rm -r -f  /tmp2/STG_THDDH_TCTDCOMPCV  >> ${SHLOG_DIR}/THDDH_TCTDCOMPCV.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.STG_THDDH_TCTDCOMPCV ; " >> ${SHLOG_DIR}/THDDH_TCTDCOMPCV.shlog 2>&1 &&
    /usr/hdp/3.0.0.0-1634/sqoop/bin/sqoop import -D mapred.child.java.opts="-Djava.security.egd=file:/dev/../dev/urandom" \
    --connect jdbc:oracle:thin:EDWHADOOP/wjdqhrP\!23@10.91.41.172:12560:DBEDWP2 \
    --username  EDWHADOOP \
    --password wjdqhrP\!23 \
    --query "SELECT REPLACE(REPLACE(COVTP_PREM_DIS_ID,CHR(13),''),CHR(10),'') COVTP_PREM_DIS_ID
, SUMUP_DT
, REPLACE(REPLACE(PREM_DIS_ID,CHR(13),''),CHR(10),'') PREM_DIS_ID
, REPLACE(REPLACE(PREM_PYRC_XPT_ID,CHR(13),''),CHR(10),'') PREM_PYRC_XPT_ID
, REPLACE(REPLACE(CTR_COV_ID,CHR(13),''),CHR(10),'') CTR_COV_ID
, COVTP_DIS_SEQ
, REPLACE(REPLACE(NW_STIC_PD_CTG_CD,CHR(13),''),CHR(10),'') NW_STIC_PD_CTG_CD
, REPLACE(REPLACE(PD_CD,CHR(13),''),CHR(10),'') PD_CD
, REPLACE(REPLACE(POL_NO,CHR(13),''),CHR(10),'') POL_NO
, REPLACE(REPLACE(CTR_OBJ_ID,CHR(13),''),CHR(10),'') CTR_OBJ_ID
, REPLACE(REPLACE(COV_CD,CHR(13),''),CHR(10),'') COV_CD
, DIS_STD_DT
, REPLACE(REPLACE(NTLY_DIV_CD,CHR(13),''),CHR(10),'') NTLY_DIV_CD
, REPLACE(REPLACE(DIS_DIV_CD,CHR(13),''),CHR(10),'') DIS_DIV_CD
, PYRC_NTLY_DT
, RCPT_INP_DT
, PYRC_DT
, NTLY_DT
, NEXT_ELP_DT
, PY_EXEM_ST_DT
, REPLACE(REPLACE(PY_CYC_CD,CHR(13),''),CHR(10),'') PY_CYC_CD
, IAMT_APL_STD_DT
, PYRC_XPT_TMS
, RCPT_PREM
, ORIG_EWPY_AMT
, IAMT_EWPY_AMT
, ELP_YR_NUM
, KEY_COV_SEQ
, KEY_HIS_SEQ
, REPLACE(REPLACE(RKEY_CNFG_CHT_VAL,CHR(13),''),CHR(10),'') RKEY_CNFG_CHT_VAL
, REPLACE(REPLACE(BKEY_CNFG_CHT_VAL,CHR(13),''),CHR(10),'') BKEY_CNFG_CHT_VAL
, SOT_RDY_AMT
, EOT_RDY_AMT
, RDY_AMT_CMPT_NET_PREM
, PREM_CMPT_NET_PREM
, XPT_ACQ_EXP_TAMT
, APL_XACQ_EXP_TAMT
, XCHG_CF
, SBC_AMT_MLTP
, STD_SBC_AMT
, SBC_AMT
, DIS_TRG_PREM
, DIS_PREM
, SAV_PREM
, CNTD_SAV_PREM
, RSK_PREM
, UNPSS_PREM
, ACQ_EXP
, CNTD_ACQ_EXP
, MRTD_ACQ_EXP
, MTN_EXP
, MNCL_EXP
, DMG_SVY_EXP
, ITGR_BZ_EXP
, MTN_RMNR_ACQ_EXP
, MTN_DC_PREM
, MNCL_DC_PREM
, ALTN_PY_PREM
, CNTD_YYBG_RDY_AMT
, CNTD_YYE_RDY_AMT
, REPLACE(REPLACE(CTR_ID,CHR(13),''),CHR(10),'') CTR_ID
, SYS_OCC_DTM
, REPLACE(REPLACE(SYS_DEL_DIV_CD,CHR(13),''),CHR(10),'') SYS_DEL_DIV_CD
, REPLACE(REPLACE(APP_ID,CHR(13),''),CHR(10),'') APP_ID
, DATA_CHNG_DTM
, PRPY_NTLY_PREM
, EIH_LDG_DTM
, REPLACE(REPLACE(DIS_RTRO_PCS_DIV_CD,CHR(13),''),CHR(10),'') DIS_RTRO_PCS_DIV_CD
, LWRT_TMN_SAV_PREM FROM THDDH_TCTDCOMPCV
                       WHERE \$CONDITIONS 
                         AND SUMUP_DT BETWEEN TO_DATE(${PART}||'01','YYYYMMDD') AND LAST_DAY(TO_DATE(${PART}||'01','YYYYMMDD')) "\
    --m 8 \
    --boundary-query "SELECT 0, 7 FROM DUAL" \
    --split-by "ora_hash(ctr_cov_id, 7)" \
    --target-dir /tmp2/STG_THDDH_TCTDCOMPCV \
    --hive-import \
    --external-table-dir hdfs:///tmp2/temp_tbl/STG_THDDH_TCTDCOMPCV \
    --hive-overwrite \
    --hive-table DEFAULT.STG_THDDH_TCTDCOMPCV  >> ${SHLOG_DIR}/THDDH_TCTDCOMPCV.shlog 2>&1 &&

#----------------------------------------------------#
# Hadoop 원본테이블에 변경분 최종 적용
#----------------------------------------------------#
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TCTDCOMPCV_TMP ; " >> ${SHLOG_DIR}/THDDH_TCTDCOMPCV.shlog 2>&1 &&
    /usr/bin/hive -e "CREATE EXTERNAL TABLE MERITZ.THDDH_TCTDCOMPCV_TMP STORED AS PARQUET TBLPROPERTIES ('PARQUET.COMPRESS'='SNAPPY') AS
                                SELECT *
                                FROM DEFAULT.STG_THDDH_TCTDCOMPCV ;" >> ${SHLOG_DIR}/THDDH_TCTDCOMPCV.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.STG_THDDH_TCTDCOMPCV ;" >> ${SHLOG_DIR}/THDDH_TCTDCOMPCV.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TCTDCOMPCV_${PART} ;" >> ${SHLOG_DIR}/THDDH_TCTDCOMPCV.shlog 2>&1 &&

# 위의 파티션 드롭 코드는 아래 파일삭제를 전제하고 있음
# external table은 drop시 자동삭제가 되지 않기 때문에 꼬였었음 181129 수정
    /usr/bin/hadoop fs -rm -r -f  /warehouse/tablespace/external/hive/meritz.db/thddh_tctdcompcv_${PART}  >> ${SHLOG_DIR}/THDDH_TCTDCOMPCV.shlog 2>&1 &&

    /usr/bin/hive -e "ALTER TABLE MERITZ.THDDH_TCTDCOMPCV_TMP RENAME TO MERITZ.THDDH_TCTDCOMPCV_${PART} ;" >> ${SHLOG_DIR}/THDDH_TCTDCOMPCV.shlog 2>&1 &&

# external table 이 alter문 동작 다른 문제로 아래 과정이 필요해짐
    /usr/bin/hive -e "ALTER TABLE MERITZ.THDDH_TCTDCOMPCV_${PART} SET LOCATION 'hdfs:///warehouse/tablespace/external/hive/meritz.db/thddh_tctdcompcv_${PART}' ;" >> ${SHLOG_DIR}/THDDH_TCTDCOMPCV.shlog 2>&1 &&
    /usr/bin/hdfs dfs -mv /warehouse/tablespace/external/hive/meritz.db/thddh_tctdcompcv_tmp /warehouse/tablespace/external/hive/meritz.db/thddh_tctdcompcv_${PART} >> ${SHLOG_DIR}/THDDH_TCTDCOMPCV.shlog 2>&1 &&

    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.THDDH_TCTDCOMPCV_TMP ;" >> ${SHLOG_DIR}/THDDH_TCTDCOMPCV.shlog 2>&1 

if [ $? -ne 0 ]
then             
    echo "*-----------[ THDDH_TCTDCOMPCV.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/THDDH_TCTDCOMPCV.shlog"
    echo "*-----------[ THDDH_TCTDCOMPCV.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/THDDH_TCTDCOMPCV.shlog"  >>  ${SHLOG_DIR}/THDDH_TCTDCOMPCV.shlog
    echo "*-----------[ THDDH_TCTDCOMPCV.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TCTDCOMPCV.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/THDDH_TCTDCOMPCV.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/THDDH_TCTDCOMPCV.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCTDCOMPCV.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCTDCOMPCV.shlog /sqoopbin/scripts/etlpgm/his_log/THDDH_TCTDCOMPCV_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  THDDH_TCTDCOMPCV.sh cmd command error !! ***
    fi               

    exit -1      

else             
    echo "*-----------[ THDDH_TCTDCOMPCV.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ THDDH_TCTDCOMPCV.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/THDDH_TCTDCOMPCV.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/THDDH_TCTDCOMPCV.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCTDCOMPCV.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/THDDH_TCTDCOMPCV.shlog /sqoopbin/scripts/etlpgm/his_log/THDDH_TCTDCOMPCV_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  THDDH_TCTDCOMPCV.sh cmd command error !! ***
        exit -1      
    else             
        exit 0       
    fi               
fi               
