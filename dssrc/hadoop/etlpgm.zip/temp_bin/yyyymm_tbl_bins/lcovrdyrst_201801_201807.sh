#!/bin/bash

/sqoopbin/scripts/etlpgm/temp_bin/THDDH_LCOVRDYRST_P.sh 201807
/sqoopbin/scripts/etlpgm/temp_bin/THDDH_LCOVRDYRST_P.sh 201806
/sqoopbin/scripts/etlpgm/temp_bin/THDDH_LCOVRDYRST_P.sh 201805
/sqoopbin/scripts/etlpgm/temp_bin/THDDH_LCOVRDYRST_P.sh 201804
/sqoopbin/scripts/etlpgm/temp_bin/THDDH_LCOVRDYRST_P.sh 201803
/sqoopbin/scripts/etlpgm/temp_bin/THDDH_LCOVRDYRST_P.sh 201802
/sqoopbin/scripts/etlpgm/temp_bin/THDDH_LCOVRDYRST_P.sh 201801
