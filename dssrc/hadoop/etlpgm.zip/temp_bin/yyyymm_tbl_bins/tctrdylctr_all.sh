#!/bin/bash

#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_TCTRDYLCTR_P.sh 201412
#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_TCTRDYLCTR_P.sh 201411
#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_TCTRDYLCTR_P.sh 201410
#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_TCTRDYLCTR_P.sh 201409
#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_TCTRDYLCTR_P.sh 201408
#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_TCTRDYLCTR_P.sh 201407
#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_TCTRDYLCTR_P.sh 201406
#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_TCTRDYLCTR_P.sh 201405
#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_TCTRDYLCTR_P.sh 201404
#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_TCTRDYLCTR_P.sh 201403
#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_TCTRDYLCTR_P.sh 201402
#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_TCTRDYLCTR_P.sh 201401

#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_TCTRDYLCTR_P.sh 201312
#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_TCTRDYLCTR_P.sh 201311
#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_TCTRDYLCTR_P.sh 201310
#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_TCTRDYLCTR_P.sh 201309
#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_TCTRDYLCTR_P.sh 201308
#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_TCTRDYLCTR_P.sh 201307
#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_TCTRDYLCTR_P.sh 201306
#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_TCTRDYLCTR_P.sh 201305
#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_TCTRDYLCTR_P.sh 201303

#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_TCTRDYLCTR_P.sh 201512
#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_TCTRDYLCTR_P.sh 201511
#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_TCTRDYLCTR_P.sh 201510
#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_TCTRDYLCTR_P.sh 201509
#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_TCTRDYLCTR_P.sh 201508
#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_TCTRDYLCTR_P.sh 201507
#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_TCTRDYLCTR_P.sh 201506
#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_TCTRDYLCTR_P.sh 201505
#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_TCTRDYLCTR_P.sh 201504
#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_TCTRDYLCTR_P.sh 201503
#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_TCTRDYLCTR_P.sh 201502
#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_TCTRDYLCTR_P.sh 201501

#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_TCTRDYLCTR_P.sh 201612
#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_TCTRDYLCTR_P.sh 201611
#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_TCTRDYLCTR_P.sh 201610
#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_TCTRDYLCTR_P.sh 201609
#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_TCTRDYLCTR_P.sh 201608
#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_TCTRDYLCTR_P.sh 201607
#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_TCTRDYLCTR_P.sh 201606
#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_TCTRDYLCTR_P.sh 201605
#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_TCTRDYLCTR_P.sh 201604
#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_TCTRDYLCTR_P.sh 201603
#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_TCTRDYLCTR_P.sh 201602
#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_TCTRDYLCTR_P.sh 201601

#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_TCTRDYLCTR_P.sh 201712
#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_TCTRDYLCTR_P.sh 201711
#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_TCTRDYLCTR_P.sh 201710
#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_TCTRDYLCTR_P.sh 201709
#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_TCTRDYLCTR_P.sh 201708
#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_TCTRDYLCTR_P.sh 201707
#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_TCTRDYLCTR_P.sh 201706
#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_TCTRDYLCTR_P.sh 201705
#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_TCTRDYLCTR_P.sh 201704
#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_TCTRDYLCTR_P.sh 201703
#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_TCTRDYLCTR_P.sh 201702
#/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_TCTRDYLCTR_P.sh 201701

/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_TCTRDYLCTR_P.sh 201812
/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_TCTRDYLCTR_P.sh 201811
/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_TCTRDYLCTR_P.sh 201810
/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_TCTRDYLCTR_P.sh 201809
/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_TCTRDYLCTR_P.sh 201808
/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_TCTRDYLCTR_P.sh 201807
/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_TCTRDYLCTR_P.sh 201806
/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_TCTRDYLCTR_P.sh 201805
/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_TCTRDYLCTR_P.sh 201804
/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_TCTRDYLCTR_P.sh 201803
/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_TCTRDYLCTR_P.sh 201802
/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_TCTRDYLCTR_P.sh 201801

/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_TCTRDYLCTR_P.sh 201912
/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_TCTRDYLCTR_P.sh 201911
/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_TCTRDYLCTR_P.sh 201910
/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_TCTRDYLCTR_P.sh 201909
/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_TCTRDYLCTR_P.sh 201908
/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_TCTRDYLCTR_P.sh 201907
/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_TCTRDYLCTR_P.sh 201906
/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_TCTRDYLCTR_P.sh 201905
/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_TCTRDYLCTR_P.sh 201904
/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_TCTRDYLCTR_P.sh 201903
/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_TCTRDYLCTR_P.sh 201902
/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_TCTRDYLCTR_P.sh 201901

/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_TCTRDYLCTR_P.sh 202001
/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_TCTRDYLCTR_P.sh 202002
/sqoopbin/scripts/etlpgm/temp_bin/yyyymm_tbl_bins/THDDH_TCTRDYLCTR_P.sh 202003
