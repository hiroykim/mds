#!/bin/bash

if [ $# -eq 0 ]
then           
    ARGS=N    
else           
    ARGS=$1
fi             

NOW=$(date +"+%Y-%m-%d_%T")
SHLOG_DIR=/sqoopbin/scripts/etlpgm/cur_log
HISLOG_DIR=/sqoopbin/scripts/etlpgm/his_log

export HADOOP_OPTS=-Djava.security.egd=file:/dev/../dev/urandom
export ORACLE_BASE=/sw/oracle
export ORACLE_HOME=/sw/oracle/product/11.2.0.4/client_1
export LD_LIBRARY_PATH=/sw/oracle/product/11.2.0.4/client_1/lib:/sw/oracle/product/11.2.0.4/client_1/lib:
export PATH=/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/sw/oracle/product/11.2.0.4/client_1/bin:/sw/oracle/product/11.2.0.4/client_1/OPatch:/usr/lib64/qt-3.3/bin:/usr/hdp/3.0.0.0-1634/spark2/bin/:/var/opt/node/bin/:/opt/maven/bin:/usr/local/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/home/hdpapp/workspace/data-science-at-the-command-line/tools:/home/hdpapp/.local/bin:/home/hdpapp/bin
export TNS_ADMIN=/sw/oracle/product/11.2.0.4/client_1/network/admin
export ORACLE_SID=DBEDWP2
export NLS_LANG=American_America.KO16MSWIN949

#----------------------------------------------------#
# 작업내용 : TMLMB_COVACMSBCA 테이블 sqoop 복제 작업
# 작업주기 :  
#----------------------------------------------------#

    echo " "
    echo "*-----------[ TMLMB_COVACMSBCA.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ TMLMB_COVACMSBCA.sh ] [PROCESS_START -->] " `date '+%Y-%m-%d %T'`  >  ${SHLOG_DIR}/TMLMB_COVACMSBCA.shlog

#----------------------------------------------------#
# 테이블별 전체 데이터를 받아 오는 부분
#----------------------------------------------------#
    /usr/bin/hadoop fs -rm -r -f  /tmp2/LAST_TMLMB_COVACMSBCA_OLD  >> ${SHLOG_DIR}/TMLMB_COVACMSBCA.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.LAST_TMLMB_COVACMSBCA_OLD ; " >> ${SHLOG_DIR}/TMLMB_COVACMSBCA.shlog 2>&1 &&
    /usr/hdp/3.0.0.0-1634/sqoop/bin/sqoop import -D mapred.child.java.opts="-Djava.security.egd=file:/dev/../dev/urandom" \
    --connect jdbc:oracle:thin:EDWHADOOP/wjdqhrP\!23@10.91.41.172:12560:DBEDWP2 \
    --username  EDWHADOOP \
    --password wjdqhrP\!23 \
    --query "SELECT /*+ FULL(TMLMB_COVACMSBCA) */ REPLACE(REPLACE(STD_YYMM,CHR(13),''),CHR(10),'') STD_YYMM
, REPLACE(REPLACE(OBJ_ID,CHR(13),''),CHR(10),'') OBJ_ID
, REPLACE(REPLACE(ACCM_COV_CD,CHR(13),''),CHR(10),'') ACCM_COV_CD
, REPLACE(REPLACE(CUS_NO,CHR(13),''),CHR(10),'') CUS_NO
, REPLACE(REPLACE(ACCM_COV_NM,CHR(13),''),CHR(10),'') ACCM_COV_NM
, ACCM_SBC_AMT
, EIH_LDG_DTM FROM TMLMB_COVACMSBCA
                       WHERE \$CONDITIONS AND STD_YYMM <= 201712"\
    --m 8 \
    --boundary-query "SELECT 0, 7 FROM DUAL"\
    --split-by "ORA_HASH(CUS_NO, 7)"\
    --target-dir /tmp2/LAST_TMLMB_COVACMSBCA_OLD \
    --hive-import \
    --external-table-dir hdfs:///tmp2/temp_tbl/LAST_TMLMB_COVACMSBCA_OLD \
    --hive-overwrite \
    --hive-table DEFAULT.LAST_TMLMB_COVACMSBCA_OLD  >> ${SHLOG_DIR}/TMLMB_COVACMSBCA.shlog 2>&1 &&

#----------------------------------------------------#
# Hadoop 원본테이블에 변경분 최종 적용
#----------------------------------------------------#
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.TMLMB_COVACMSBCA_OLD_TMP ; " >> ${SHLOG_DIR}/TMLMB_COVACMSBCA.shlog 2>&1 &&
    /usr/bin/hive -e "CREATE EXTERNAL TABLE MERITZ.TMLMB_COVACMSBCA_OLD_TMP STORED AS PARQUET TBLPROPERTIES ('PARQUET.COMPRESS'='SNAPPY') AS
                                SELECT *
                                FROM DEFAULT.LAST_TMLMB_COVACMSBCA_OLD ;" >> ${SHLOG_DIR}/TMLMB_COVACMSBCA.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS DEFAULT.LAST_TMLMB_COVACMSBCA_OLD ;" >> ${SHLOG_DIR}/TMLMB_COVACMSBCA.shlog 2>&1 &&
    /usr/bin/hdfs dfs -rm -r -f -skipTrash /tmp2/temp_tbl/LAST_TMLMB_COVACMSBCA_OLD >> ${SHLOG_DIR}/TMLMB_COVACMSBCA.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.TMLMB_COVACMSBCA_OLD ;" >> ${SHLOG_DIR}/TMLMB_COVACMSBCA.shlog 2>&1 &&
    /usr/bin/hive -e "ALTER TABLE MERITZ.TMLMB_COVACMSBCA_OLD_TMP RENAME TO MERITZ.TMLMB_COVACMSBCA_OLD ;" >> ${SHLOG_DIR}/TMLMB_COVACMSBCA.shlog 2>&1 &&
    /usr/bin/hive -e "DROP TABLE IF EXISTS MERITZ.TMLMB_COVACMSBCA_OLD_TMP ;" >> ${SHLOG_DIR}/TMLMB_COVACMSBCA.shlog 2>&1 

if [ $? -ne 0 ]
then             
    echo "*-----------[ TMLMB_COVACMSBCA.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/TMLMB_COVACMSBCA.shlog"
    echo "*-----------[ TMLMB_COVACMSBCA.sh ] [실행 에러 *** -->] Log = ${SHLOG_DIR}/TMLMB_COVACMSBCA.shlog"  >>  ${SHLOG_DIR}/TMLMB_COVACMSBCA.shlog
    echo "*-----------[ TMLMB_COVACMSBCA.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ TMLMB_COVACMSBCA.sh ] [실행 에러 *** -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/TMLMB_COVACMSBCA.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/TMLMB_COVACMSBCA.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/TMLMB_COVACMSBCA.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/TMLMB_COVACMSBCA.shlog /sqoopbin/scripts/etlpgm/his_log/TMLMB_COVACMSBCA_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  TMLMB_COVACMSBCA.sh cmd command error !! ***
    fi               

    exit -1      

else             
    echo "*-----------[ TMLMB_COVACMSBCA.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`
    echo "*-----------[ TMLMB_COVACMSBCA.sh ] [PROCESS_GOOD  -->] " `date '+%Y-%m-%d %T'`  >>  ${SHLOG_DIR}/TMLMB_COVACMSBCA.shlog
    echo " "
    echo " "  >>  ${SHLOG_DIR}/TMLMB_COVACMSBCA.shlog

    chmod 777  /sqoopbin/scripts/etlpgm/cur_log/TMLMB_COVACMSBCA.shlog
    cp  /sqoopbin/scripts/etlpgm/cur_log/TMLMB_COVACMSBCA.shlog /sqoopbin/scripts/etlpgm/his_log/TMLMB_COVACMSBCA_${NOW}.shlog

    if [ $? -ne 0 ]
    then             
        echo  ****  TMLMB_COVACMSBCA.sh cmd command error !! ***
        exit -1      
    else             
        exit 0       
    fi               
fi               
