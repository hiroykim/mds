#!/bin/bash

grep -Iirn 'Transfer' ./cur_log/ | sed -e "s/\,//g" | sort -k9,9rn | grep -v INIT_ > jdbc_time.log
cat jdbc_time.log | awk 'BEGIN {TOTAL=0} {TOTAL+=$9} END {printf "total jdbc time : %f\n", TOTAL}'
cat jdbc_time.log | grep "GB in" | awk 'BEGIN {TOTAL=0} {TOTAL+=$6} END {printf "total jdbc data : %f GB\n", TOTAL}'
echo -e "table_info\tjdbc_time" > jdbc_time_hdfs.txt
cat jdbc_time.log | sed -e "s/\.\/cur_log\///g" | awk '{print $1,"\t", $9}' >> jdbc_time_hdfs.txt

grep -Iirn "DAG finished" ./cur_log/ | sort -k8,8rn | grep -v INIT_ > hive_time.log
cat hive_time.log | awk 'BEGIN {TOTAL=0} {TOTAL+=$8} END {printf "total hive time : %f\n", TOTAL}'
echo -e "table_info\thive_time" > hive_time_hdfs.txt
cat hive_time.log | sed -e "s/\.\/cur_log\///g" | awk '{print $1,"\t", $8}' >> hive_time_hdfs.txt




find /sqoopbin/scripts/etlpgm/his_log -name "**" -mtime +24 -exec rm -f {} \;

find ./cur_log/ -mtime -30 -exec grep -Iin 'Transfer' {}  \; | wc

find ./cur_log/ -mtime -30 -exec grep -Iin 'Transfer' {}  \; | sed -e "s/\,//g" | sort -k9,9rn | grep -v INIT_


cat jdbc_time.log | sed -e "s/\.\/cur_log\///g" | awk '{print $1,"|",$6,"|",$7,"|", $9, "|", $11,$12}'

hdfs dfs -get "/meritz/tmp/sqoop_dir/it_jdbc_time_hdfs_211210.txt" ./